# #492 final incremental review: native partial-file recovery

You independently reviewed the full plugin/native T3 slice and returned APPROVE_WITH_NITS. One concrete Grok nit is now fixed: native append uses the shared stable segment_id idempotency/recovery already reviewed for the extension. Reassess the exact delta for regressions and confirm both surfaces' original archive recovery, bounded input, no broader permission. Actual code and machine evidence below. No tools/edits; do not say you executed tests. Final line VERDICT: APPROVE / APPROVE_WITH_NITS / REJECT. Concrete actionable findings only.

Base is b349f447 (full source/packet previously reviewed; original archive repair and bounds already present). Native trusted HTTP append now forwards an optional bounded segment id to existing handler validation; no new method/permission/server path/LLM or tool. Native retry uses same sid to repeat safely and verifies the returned original archive; drops old GET/array heuristic. Repeated real utterances have distinct sids; retries same sid remain one. New actual partial-write fault truncates only synthetic original archive to before-append snapshot, preserves committed editable, then retry must repair raw once. Existing before-send and after-commit faults still pass. Scope excludes existing continuous PCM gap (#494). AI draft labels and explicit privacy unchanged. Other previous cosmetic nits accepted/documented.

## Exact delta
diff --git a/companion/scripts/serve-summoner-meeting-fixture.cjs b/companion/scripts/serve-summoner-meeting-fixture.cjs
index 2be6a288..4124006b 100644
--- a/companion/scripts/serve-summoner-meeting-fixture.cjs
+++ b/companion/scripts/serve-summoner-meeting-fixture.cjs
@@ -1,14 +1,14 @@
 // #492: real summoner HTTP/ACL, meeting persistence, STT protocol, and minutes parser.
-// Only the recognizer service and model extraction are synthetic. All data is temporary.
+// Recognizer/model results and explicit disk-failure injection are synthetic. All data is temporary.
 const fs = require('node:fs');
 const path = require('node:path');
 const http = require('node:http');
 const Module = require('node:module');
 const [dataDir, evidenceFile] = process.argv.slice(2);
 if (!dataDir || !evidenceFile) throw new Error('isolated data directory and trace path required');
 fs.mkdirSync(dataDir, { recursive: true });
 process.env.CMSPARK_DATA_DIR = path.resolve(dataDir);
 fs.writeFileSync(path.join(dataDir, 'config.json'), JSON.stringify({
   voice: { sttEngine: 'local', localModelId: 'medium' },
   llm: { api_key: 'synthetic-unused', base_url: 'https://unused.invalid', model_name: 'synthetic' },
 }));
@@ -16,37 +16,38 @@ const root = path.resolve(__dirname, '..');
 const filename = path.join(root, 'src', '__summoner_meeting_fixture__.ts');
 // Extract the exact production tray adapter without importing the menu-bar process.
 const traySource = fs.readFileSync(path.join(root, 'src/menu-bar-agent.ts'), 'utf8');
 const adapterStart = traySource.indexOf('function dispatchSummonerWeb(');
 const adapterEnd = traySource.indexOf('\nfunction reportOverlayShellUnavailable(', adapterStart);
 if (adapterStart < 0 || adapterEnd < 0) throw new Error('production tray adapter boundary changed');
 const trayAdapter = traySource.slice(adapterStart, adapterEnd);
 const compiled = require('esbuild').buildSync({
   stdin: { contents: `export * from './summoner-web';
     import {summonerVoiceRequestTimeout} from './summoner/voice-input';
     export {handleMeetingMessage} from './meeting/meeting-handlers';
     export {generateMeetingMinutes} from './meeting/meeting-minutes';
+    export {loadMeeting, isSafeMeetingId} from './meeting/meeting-store';
     export {handleVoiceSttMessage} from './voice/stt-handlers';
     ${trayAdapter}
     export {dispatchSummonerWeb};`,
     resolveDir: path.join(root, 'src'), loader: 'ts' },
   bundle: true, platform: 'node', format: 'cjs', packages: 'external', write: false,
 });
 const loaded = new Module(filename, module);
 loaded.filename = filename;
 loaded.paths = Module._nodeModulePaths(path.dirname(filename));
 loaded._compile(compiled.outputFiles[0].text, filename);
 const production = loaded.exports;
 const traces = [];
-const controls = { text: '配森将在周五发布。', hold: [], failLlm: false, failStt: false };
+const controls = { text: '配森将在周五发布。', hold: [], failLlm: false, failStt: false, partialRawOnce: false };
 const pending = new Map();
 let serial = 0;
 function record(event) {
   traces.push({ n: ++serial, at: Date.now(), ...event });
   fs.mkdirSync(path.dirname(evidenceFile), { recursive: true });
   fs.writeFileSync(evidenceFile, JSON.stringify(traces, null, 2));
 }
 async function gate(type) {
   if (controls.hold.includes(type)) {
     record({ phase: 'held', type });
     await new Promise(resolve => pending.set(type, resolve));
   }
@@ -80,25 +81,38 @@ const dependencies = {
         ? [{ reference_excerpt: '负责人小王', reason: '仅参考笔记提供，录音未确认' }] : [],
     });
   } }),
 };
 async function dispatch(message) {
   // Record byte counts, not PCM/base64; fixture text is generated, never user material.
   const request = { ...message };
   if (typeof request.data === 'string') request.data = `<${Buffer.from(request.data, 'base64').length} synthetic PCM bytes>`;
   if (request.file) request.file = { name: request.file.name, type: request.file.type, bytes: Buffer.from(request.file.content, 'base64').length };
   record({ phase: 'request', type: message.type, request });
   await gate(message.type);
   let result;
-  if (message.type.startsWith('meeting.')) result = await production.handleMeetingMessage(message, context, dependencies);
+  if (message.type.startsWith('meeting.')) {
+    const partialId = controls.partialRawOnce && message.type === 'meeting.append_transcript' ? message.id : null;
+    const before = partialId && production.isSafeMeetingId(partialId) ? production.loadMeeting(partialId) : null;
+    result = await production.handleMeetingMessage(message, context, dependencies);
+    if (before && result?.type === 'meeting.updated') {
+      controls.partialRawOnce = false;
+      // Reconstruct the real saveMeeting write boundary: transcript.json committed,
+      // original-transcript.json still contains its exact previous production array.
+      const rawPath = path.join(process.env.CMSPARK_DATA_DIR, 'meetings', partialId, 'original-transcript.json');
+      fs.writeFileSync(rawPath, JSON.stringify(before.original_transcript || [], null, 2));
+      record({ phase: 'disk-fault', kind: 'partial_write', id: partialId,
+        segment_id: message.segment_id, before, after: production.loadMeeting(partialId) });
+    }
+  }
   else if (message.type.startsWith('voice.stt.')) {
     result = await production.handleVoiceSttMessage(message, context, { service });
     // Production service traffic can arrive through both SSE and the HTTP reply.
     if (result) production.pushSummonerWebEvent(result);
   } else if (message.type === 'thread.list') result = { type: 'thread.list', threads: [] };
   else if (message.type === 'thread.select') result = { type: 'thread.selected', messages: [], run_status: 'idle' };
   else result = { type: 'ok' };
   record({ phase: 'ack', type: message.type, response: result ?? null });
   return result;
 }
 const controlServer = http.createServer(async (req, res) => {
   if (req.method === 'POST') {
diff --git a/companion/scripts/test-summoner-meeting-ui.py b/companion/scripts/test-summoner-meeting-ui.py
index 8cc31043..43263b57 100644
--- a/companion/scripts/test-summoner-meeting-ui.py
+++ b/companion/scripts/test-summoner-meeting-ui.py
@@ -219,56 +219,70 @@ with tempfile.TemporaryDirectory(prefix="cmspark-native-meeting-") as temporary:
                   return {width:innerWidth, scrollWidth:document.documentElement.scrollWidth,
                     boxes:ids.map(id=>{const el=document.getElementById(id),r=el.getBoundingClientRect();
                       return {id,left:r.left,right:r.right,width:r.width,height:r.height}})};
                 }""")
                 assert result["scrollWidth"] <= width + 1, result
                 assert all(box["left"] >= -1 and box["right"] <= width + 1 and box["width"] > 0 for box in result["boxes"]), result
                 live_box = next(box for box in result["boxes"] if box["id"] == "meetingLive")
                 assert live_box["height"] >= 140, ("transcript collapsed behind materials/minutes", result)
                 layouts.append(result)
                 page.screenshot(path=str(ARTIFACTS / f"native-{width}.png"), full_page=True)
             (ARTIFACTS / "layout-evidence.json").write_text(json.dumps(layouts, ensure_ascii=False, indent=2))
 
-            # Drop the real append request, then separately drop only its successful response.
-            # Both retry paths must preserve previous imports and append the new segment once.
-            for mode in ["before_send", "after_commit"]:
+            # Drop the request, drop its successful response, or leave only the raw file stale.
+            # Every retry must preserve previous imports and commit the same segment once.
+            for mode in ["before_send", "after_commit", "partial_write"]:
                 expect(page.locator("#meetingRec")).to_be_enabled()
                 marker = control()["traces"][-1]["n"]
-                control(text=f"恢复追加不重复 {mode}。")
+                control(text=f"恢复追加不重复 {mode}。", partialRawOnce=mode == "partial_write")
                 notes_before = page.locator("#meetingReferenceNotes").input_value()
                 def lose_append(route):
-                    if mode == "after_commit":
+                    if mode in ["after_commit", "partial_write"]:
                         actual = route.fetch()
                         assert actual.json()["type"] == "meeting.updated"
                     route.abort("failed")
                 page.route("**/api/meeting/append", lose_append, times=1)
                 page.locator("#meetingRec").click()
                 started = wait_event(page, "meeting.start", "ack", after=marker)
                 existing = started["response"]["meeting"]
                 assert existing["reference_name"] == "notes.docx"
                 assert existing["reference_notes"] == notes_before
                 wait_event(page, "voice.stt.chunk", after=marker)
                 page.locator("#meetingMinutesBtn").click()
                 expect(page.locator("#meetingRetry")).to_be_visible()
                 expect(page.locator("#meetingMinutesBtn")).to_be_enabled()
                 expect(page.locator("#meetingLive")).to_contain_text(f"恢复追加不重复 {mode}")
                 expect(page.locator("#meetingLive")).to_contain_text("追加录音保留现有转写")
                 no_model(after=marker)
                 assert not events("meeting.end", after=marker), "failed save incorrectly ended meeting"
+                if mode == "partial_write":
+                    fault = [event for event in control()["traces"] if event["n"] > marker and event.get("phase") == "disk-fault"][-1]
+                    assert fault["kind"] == mode
+                    assert fault["before"]["transcript"] == existing["transcript"]
+                    assert fault["after"]["transcript"][:-1] == existing["transcript"]
+                    assert fault["after"]["original_transcript"] == existing["original_transcript"]
+                    assert fault["after"]["transcript"][-1]["segment_id"] == fault["segment_id"]
+                    assert len(fault["after"]["transcript"]) == len(existing["transcript"]) + 1
                 page.locator("#meetingRetry").click()
                 recovered = wait_event(page, "meeting.end", "ack", after=marker)["response"]["meeting"]
                 assert len(recovered["transcript"]) == len(existing["transcript"]) + 1, recovered
                 assert len(recovered["original_transcript"]) == len(existing["original_transcript"]) + 1
                 assert recovered["transcript"][:-1] == existing["transcript"]
-                assert len(events("meeting.append_transcript", after=marker)) == 1
+                assert recovered["original_transcript"][:-1] == existing["original_transcript"]
+                appended = events("meeting.append_transcript", after=marker)
+                assert len(appended) == (1 if mode == "before_send" else 2)
+                segment_ids = {event["request"].get("segment_id") for event in appended}
+                assert len(segment_ids) == 1 and None not in segment_ids and "" not in segment_ids
+                assert recovered["transcript"][-1]["segment_id"] in segment_ids
+                assert recovered["original_transcript"][-1] == recovered["transcript"][-1]
                 expect(page.locator("#meetingRetry")).to_be_hidden()
                 no_model(after=marker)
                 page.locator("#meetingMinutesBtn").click()
                 regenerated = wait_event(page, "meeting.generate_minutes", "ack", after=marker)
                 assert regenerated["response"]["type"] == "meeting.minutes_result", regenerated
                 expect(page.locator("#meetingMinutesBtn")).to_be_enabled()
                 print(f"PASS native {mode} append failure → retry → end → generation; no duplicate or lost materials", flush=True)
 
             # Import-first users need no recording session. A new document requires its own consent.
             marker = control()["traces"][-1]["n"]
             control(text="配森将在周五发布。")
             imported_page = context.new_page()
diff --git a/companion/src/summoner-web.ts b/companion/src/summoner-web.ts
index 963c7f05..f19d96a1 100644
--- a/companion/src/summoner-web.ts
+++ b/companion/src/summoner-web.ts
@@ -1159,25 +1159,28 @@ async function handleRequest(
       const id = typeof body.id === "string" ? body.id : ""
       jsonResponse(res, await dispatchAllowed("meeting.end", { v: 1, id }))
       if (id && overlayMeetingId === id) overlayMeetingId = ""
       return
     }
 
     if (pathOnly === "/api/meeting/append" && req.method === "POST") {
       const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
       const id = typeof body.id === "string" ? body.id : ""
       const text = typeof body.text === "string" ? body.text : ""
       jsonResponse(
         res,
-        await dispatchAllowed("meeting.append_transcript", { v: 1, id, text, source: "stt" }),
+        await dispatchAllowed("meeting.append_transcript", {
+          v: 1, id, text, source: "stt",
+          ...(body.segment_id !== undefined ? { segment_id: body.segment_id } : {}),
+        }),
       )
       return
     }
 
     if (pathOnly === "/api/meeting/minutes" && req.method === "POST") {
       const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
       const id = typeof body.id === "string" ? body.id : ""
       if (body.privacy_ack_v1 !== true) {
         jsonResponse(res, { type: "meeting.error", v: 1, code: "need_privacy_ack", message: "请先阅读并确认会议说明" }, 400)
         return
       }
       jsonResponse(res, await dispatchAllowed("meeting.generate_minutes", { v: 1, id }))
diff --git a/companion/src/summoner/meeting-workflow.ts b/companion/src/summoner/meeting-workflow.ts
index b7c17d55..9244b6b0 100644
--- a/companion/src/summoner/meeting-workflow.ts
+++ b/companion/src/summoner/meeting-workflow.ts
@@ -63,37 +63,27 @@ export const SUMMONER_MEETING_WORKFLOW_JS = String.raw`
     meetingChecked(d);
     if(d.type!=="voice.stt.result" || d.sessionId!==s.sid)throw new Error("语音识别未返回匹配的最终结果");
     var text=typeof d.text==="string"?d.text.trim():"";
     if(!text){s.committed=Promise.resolve();return s.committed}
     // Paint first, persist second. Failed saves keep the visible text for recovery.
     appendMeetingLive(text,"");$("meetingPartial").textContent="";
     s.text=text;pendingMeetingSegment=s;
     s.committed=saveMeetingSegment(s);
     s.committed.catch(function(e){captureFailure(s,e)});
     return s.committed;
   }
   async function saveMeetingSegment(s){
-    var current=await meetingRequest("/api/meeting?id="+encodeURIComponent(s.owner));
-    if(!current.meeting || current.meeting.id!==s.owner)throw new Error("无法核对转写保存状态");
-    var m=current.meeting,lines=m.transcript||[],original=m.original_transcript||[];
-    if(!s.base){s.base=lines;s.originalBase=original}
-    var unchanged=JSON.stringify(lines)===JSON.stringify(s.base) && JSON.stringify(original)===JSON.stringify(s.originalBase);
-    function appended(actual,base){return actual.length===base.length+1 && JSON.stringify(actual.slice(0,-1))===JSON.stringify(base) && actual[actual.length-1].text===s.text && actual[actual.length-1].source==="stt"}
-    var alreadySaved=appended(lines,s.base) && appended(original,s.originalBase);
-    if(!unchanged && !alreadySaved)throw new Error("会议材料已在别处变化，请核对当前稿；为避免重复，未自动重写末段");
-    if(!alreadySaved){
-      var reply=await meetingPost("/api/meeting/append",{id:s.owner,text:s.text});
-      if(!reply.meeting || reply.meeting.id!==s.owner)throw new Error("转写保存回执不匹配");
-      m=reply.meeting;
-    }
+    var reply=await meetingPost("/api/meeting/append",{id:s.owner,text:s.text,segment_id:s.sid});
+    var m=reply.meeting;
+    if(!m || m.id!==s.owner || !(m.original_transcript||[]).some(function(line){return line.segment_id===s.sid && line.text===s.text && line.source==="stt"}))throw new Error("原始转写保存回执不匹配，请重试保存");
     var raw=(m.original_transcript||[]).map(function(l){return l.text||""}).join("\n");
     $("meetingOriginal").hidden=!raw;$("meetingOriginalText").textContent=raw;renderMeetingEvidence(m.minutes);
     if(pendingMeetingSegment===s)pendingMeetingSegment=null;
   }
   $("meetingRetry").onclick=async function(){
     if(meetingWorkBusy || meetingEnding)return;meetingWorkBusy=true;meetingControls(true);
     try{
       var s=pendingMeetingSegment;
       if(s){await saveMeetingSegment(s);s.failed=null;s.committed=Promise.resolve()}
       if(meetingCapture){await meetingCapture.queue.catch(function(){});await meetingPost("/api/stt/abort",{sessionId:meetingCapture.sid}).catch(function(){});meetingCapture=null}
       meetingFailure=null;$("meetingRetry").hidden=true;
       if(s){await endMeetingCapture();$("meetingHint").textContent="末段转写已恢复";meetingSay("末段转写已核对保存，可重新生成纪要")}
diff --git a/companion/tests/summoner-meeting-492.test.ts b/companion/tests/summoner-meeting-492.test.ts
index 09466043..33520ec9 100644
--- a/companion/tests/summoner-meeting-492.test.ts
+++ b/companion/tests/summoner-meeting-492.test.ts
@@ -1,17 +1,20 @@
 import "./meeting-test-data-dir"
 import test from "node:test"
 import assert from "node:assert/strict"
 import vm from "node:vm"
+import fs from "node:fs"
+import path from "node:path"
 import AdmZip from "adm-zip"
+import { DATA_DIR } from "../src/config"
 import { startSummonerWebServer, stopSummonerWebServer, SUMMONER_WEB_DISPATCH_ALLOW } from "../src/summoner-web"
 import { assertSummonerAllowed } from "../src/ws/summoner-acl"
 import { handleMeetingMessage } from "../src/meeting/meeting-handlers"
 import { deleteMeeting, loadMeeting } from "../src/meeting/meeting-store"
 import { SUMMONER_MEETING_WORKFLOW_JS } from "../src/summoner/meeting-workflow"
 
 function workflowContext(api: (path: string, options?: any) => Promise<any>, fastTimers = false) {
   const elements = new Map<string, any>()
   const element = () => ({ value: "", textContent: "", hidden: false, innerHTML: "", appendChild() {} })
   const context = vm.createContext({
     $: (id: string) => { if (!elements.has(id)) elements.set(id, element()); return elements.get(id) },
     document: { createElement: element }, api, AbortController,
@@ -20,41 +23,41 @@ function workflowContext(api: (path: string, options?: any) => Promise<any>, fas
   })
   vm.runInContext(SUMMONER_MEETING_WORKFLOW_JS, context)
   return context
 }
 
 test("#492 native retry reconciles real stored transcripts after failed write or lost ACK", async () => {
   const origin = { origin: "cmspark-tray://local", surface: "summoner" }
   for (const lostAck of [false, true]) {
     const created = await handleMeetingMessage({ type: "meeting.create", title: "Retry fixture" }, origin)
     const id = created.meeting.id
     let appendAttempts = 0
     const context = workflowContext(async (url, options) => {
-      if (url.startsWith("/api/meeting?id=")) return handleMeetingMessage({ type: "meeting.get", id }, origin)
       assert.equal(url, "/api/meeting/append")
       appendAttempts++
       const payload = JSON.parse(options.body)
       if (!lostAck && appendAttempts === 1) throw new Error("synthetic write failure before persistence")
       const reply = await handleMeetingMessage({ type: "meeting.append_transcript", ...payload, source: "stt" }, origin)
       if (lostAck && appendAttempts === 1) throw new Error("synthetic ACK lost after persistence")
       return reply
     })
-    context.segment = { owner: id, text: "真正保存的末段", base: undefined }
+    context.segment = { owner: id, text: "真正保存的末段", sid: "native-retry-segment" }
     try {
       await assert.rejects(vm.runInContext("saveMeetingSegment(segment)", context))
       await vm.runInContext("saveMeetingSegment(segment)", context)
-      assert.equal(appendAttempts, lostAck ? 1 : 2)
+      assert.equal(appendAttempts, 2)
       const saved = loadMeeting(id)!
       assert.deepEqual(saved.transcript.map(line => line.text), ["真正保存的末段"])
       assert.deepEqual(saved.original_transcript?.map(line => line.text), ["真正保存的末段"])
+      assert.equal(saved.original_transcript?.[0].segment_id, context.segment.sid)
     } finally { deleteMeeting(id) }
   }
 })
 
 test("#492 native HTTP deadline aborts pending requests with an explicit recovery message", async () => {
   const context = workflowContext(async (_path, options) => new Promise((_resolve, reject) => {
     options.signal.addEventListener("abort", () => { const error = new Error("aborted"); error.name = "AbortError"; reject(error) })
   }), true)
   await assert.rejects(vm.runInContext('meetingPost("/api/meeting/append", {})', context), /请求超时/)
 })
 
 test("#492 native reference HTTP uses actual handlers, bounded files and exact ACL", async () => {
@@ -74,24 +77,39 @@ test("#492 native reference HTTP uses actual handlers, bounded files and exact A
   try {
     const document = await fetch(`http://127.0.0.1:${port}/`)
     const html = await document.text()
     assert.match(document.headers.get("content-security-policy") || "", /script-src 'nonce-/)
     const script = html.match(/<script[^>]*>([\s\S]*?)<\/script>/)?.[1]
     assert.ok(script)
     assert.doesNotThrow(() => new vm.Script(script))
     const denied = await post("/api/meeting/reference/import", {}, false)
     assert.equal(denied.status, 403)
     const created = await post("/api/meeting/create", { title: "Native fixture" })
     assert.equal(created.data.type, "meeting.created")
     id = created.data.meeting.id
+    const segment = { id, text: "原生末段", segment_id: "native-partial-segment" }
+    const appended = await post("/api/meeting/append", segment)
+    assert.equal(appended.data.meeting.original_transcript[0].segment_id, segment.segment_id)
+    const originalPath = path.join(DATA_DIR, "meetings", id, "original-transcript.json")
+    fs.writeFileSync(originalPath, "[]")
+    const recovered = await post("/api/meeting/append", segment)
+    assert.equal(recovered.data.meeting.transcript.length, 1)
+    assert.equal(recovered.data.meeting.original_transcript.length, 1)
+    assert.equal(recovered.data.meeting.original_transcript[0].segment_id, segment.segment_id)
+    assert.deepEqual(JSON.parse(fs.readFileSync(originalPath, "utf8")), recovered.data.meeting.original_transcript)
+    const replayed = await post("/api/meeting/append", segment)
+    assert.equal(replayed.data.meeting.transcript.length, 1)
+    assert.equal(replayed.data.meeting.original_transcript.length, 1)
+    const invalidSegment = await post("/api/meeting/append", { ...segment, segment_id: "../../bad" })
+    assert.equal(invalidSegment.data.code, "invalid_segment_id")
     const imported = await post("/api/meeting/reference/import", { file: { name: "notes.md", type: "text/markdown", content: Buffer.from("Python 用于本项目").toString("base64") }, path: "/not-readable" })
     assert.equal(imported.data.type, "meeting.reference_imported")
     assert.equal(imported.data.reference.text, "Python 用于本项目")
     assert.equal(dispatched.at(-1)?.path, undefined)
     const zip = new AdmZip()
     zip.addFile("[Content_Types].xml", Buffer.from('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'))
     zip.addFile("_rels/.rels", Buffer.from('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'))
     zip.addFile("word/document.xml", Buffer.from('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Python 参考</w:t></w:r></w:p></w:body></w:document>'))
     for (const [name, bytes] of [["notes.docx", zip.toBuffer()], ["notes.txt", Buffer.from("Python 参考")]] as const) {
       const response = await post("/api/meeting/reference/import", { file: { name, content: bytes.toString("base64") } })
       assert.equal(response.data.type, "meeting.reference_imported")
       assert.ok(response.data.reference.text.includes("Python 参考"))

## Full current companion/scripts/serve-summoner-meeting-fixture.cjs
```
// #492: real summoner HTTP/ACL, meeting persistence, STT protocol, and minutes parser.
// Recognizer/model results and explicit disk-failure injection are synthetic. All data is temporary.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const Module = require('node:module');
const [dataDir, evidenceFile] = process.argv.slice(2);
if (!dataDir || !evidenceFile) throw new Error('isolated data directory and trace path required');
fs.mkdirSync(dataDir, { recursive: true });
process.env.CMSPARK_DATA_DIR = path.resolve(dataDir);
fs.writeFileSync(path.join(dataDir, 'config.json'), JSON.stringify({
  voice: { sttEngine: 'local', localModelId: 'medium' },
  llm: { api_key: 'synthetic-unused', base_url: 'https://unused.invalid', model_name: 'synthetic' },
}));
const root = path.resolve(__dirname, '..');
const filename = path.join(root, 'src', '__summoner_meeting_fixture__.ts');
// Extract the exact production tray adapter without importing the menu-bar process.
const traySource = fs.readFileSync(path.join(root, 'src/menu-bar-agent.ts'), 'utf8');
const adapterStart = traySource.indexOf('function dispatchSummonerWeb(');
const adapterEnd = traySource.indexOf('\nfunction reportOverlayShellUnavailable(', adapterStart);
if (adapterStart < 0 || adapterEnd < 0) throw new Error('production tray adapter boundary changed');
const trayAdapter = traySource.slice(adapterStart, adapterEnd);
const compiled = require('esbuild').buildSync({
  stdin: { contents: `export * from './summoner-web';
    import {summonerVoiceRequestTimeout} from './summoner/voice-input';
    export {handleMeetingMessage} from './meeting/meeting-handlers';
    export {generateMeetingMinutes} from './meeting/meeting-minutes';
    export {loadMeeting, isSafeMeetingId} from './meeting/meeting-store';
    export {handleVoiceSttMessage} from './voice/stt-handlers';
    ${trayAdapter}
    export {dispatchSummonerWeb};`,
    resolveDir: path.join(root, 'src'), loader: 'ts' },
  bundle: true, platform: 'node', format: 'cjs', packages: 'external', write: false,
});
const loaded = new Module(filename, module);
loaded.filename = filename;
loaded.paths = Module._nodeModulePaths(path.dirname(filename));
loaded._compile(compiled.outputFiles[0].text, filename);
const production = loaded.exports;
const traces = [];
const controls = { text: '配森将在周五发布。', hold: [], failLlm: false, failStt: false, partialRawOnce: false };
const pending = new Map();
let serial = 0;
function record(event) {
  traces.push({ n: ++serial, at: Date.now(), ...event });
  fs.mkdirSync(path.dirname(evidenceFile), { recursive: true });
  fs.writeFileSync(evidenceFile, JSON.stringify(traces, null, 2));
}
async function gate(type) {
  if (controls.hold.includes(type)) {
    record({ phase: 'held', type });
    await new Promise(resolve => pending.set(type, resolve));
  }
}
const service = {
  start() { return { ok: true }; },
  chunk() { return { ok: true }; },
  abort() { return { ok: true }; },
  async partial() { return { ok: true, text: '配森将在', ms: 1, modelId: 'medium' }; },
  async end() {
    if (controls.failStt) return { ok: false, code: 'infer_timeout', message: '合成识别超时' };
    return { ok: true, text: controls.text, ms: 1, modelId: 'medium' };
  },
};
const context = { origin: 'cmspark-tray://local', surface: 'summoner', peerId: 'isolated-native-fixture',
  send: frame => production.pushSummonerWebEvent(frame) };
const dependencies = {
  clearSttSessions() {},
  getLlmConfig: () => ({ api_key: 'synthetic-unused', base_url: 'https://unused.invalid', model_name: 'synthetic' }),
  generate: params => production.generateMeetingMinutes({ ...params, extract: async options => {
    record({ phase: 'llm', userContent: options.userContent, systemPrompt: options.systemPrompt });
    if (controls.failLlm) throw new Error('合成模型不可用');
    const minutes_md = '### TL;DR\n讨论 Python 发布。\n### 决议\n待核对日期。\n### 待办\n- [ ] 确认发布日期。\n### 风险 / 开放问题\n录音与笔记存在分歧。';
    if (!params.referenceNotes?.trim()) return minutes_md;
    return JSON.stringify({ minutes_md,
      corrections: params.transcriptText.includes('配森') && params.referenceNotes.includes('Python')
        ? [{ original: '配森', replacement: 'Python', reference_excerpt: 'Python', reason: '笔记中明确的项目术语' }] : [],
      conflicts: params.transcriptText.includes('周五') && params.referenceNotes.includes('周四')
        ? [{ transcript_excerpt: '周五', reference_excerpt: '周四', reason: '日期不一致，请确认' }] : [],
      reference_supplements: params.referenceNotes.includes('负责人小王')
        ? [{ reference_excerpt: '负责人小王', reason: '仅参考笔记提供，录音未确认' }] : [],
    });
  } }),
};
async function dispatch(message) {
  // Record byte counts, not PCM/base64; fixture text is generated, never user material.
  const request = { ...message };
  if (typeof request.data === 'string') request.data = `<${Buffer.from(request.data, 'base64').length} synthetic PCM bytes>`;
  if (request.file) request.file = { name: request.file.name, type: request.file.type, bytes: Buffer.from(request.file.content, 'base64').length };
  record({ phase: 'request', type: message.type, request });
  await gate(message.type);
  let result;
  if (message.type.startsWith('meeting.')) {
    const partialId = controls.partialRawOnce && message.type === 'meeting.append_transcript' ? message.id : null;
    const before = partialId && production.isSafeMeetingId(partialId) ? production.loadMeeting(partialId) : null;
    result = await production.handleMeetingMessage(message, context, dependencies);
    if (before && result?.type === 'meeting.updated') {
      controls.partialRawOnce = false;
      // Reconstruct the real saveMeeting write boundary: transcript.json committed,
      // original-transcript.json still contains its exact previous production array.
      const rawPath = path.join(process.env.CMSPARK_DATA_DIR, 'meetings', partialId, 'original-transcript.json');
      fs.writeFileSync(rawPath, JSON.stringify(before.original_transcript || [], null, 2));
      record({ phase: 'disk-fault', kind: 'partial_write', id: partialId,
        segment_id: message.segment_id, before, after: production.loadMeeting(partialId) });
    }
  }
  else if (message.type.startsWith('voice.stt.')) {
    result = await production.handleVoiceSttMessage(message, context, { service });
    // Production service traffic can arrive through both SSE and the HTTP reply.
    if (result) production.pushSummonerWebEvent(result);
  } else if (message.type === 'thread.list') result = { type: 'thread.list', threads: [] };
  else if (message.type === 'thread.select') result = { type: 'thread.selected', messages: [], run_status: 'idle' };
  else result = { type: 'ok' };
  record({ phase: 'ack', type: message.type, response: result ?? null });
  return result;
}
const controlServer = http.createServer(async (req, res) => {
  if (req.method === 'POST') {
    let body = ''; for await (const chunk of req) body += chunk;
    const changes = JSON.parse(body || '{}');
    if (changes.release) {
      controls.hold = controls.hold.filter(type => type !== changes.release);
      pending.get(changes.release)?.(); pending.delete(changes.release);
      delete changes.release;
    }
    Object.assign(controls, changes);
  }
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ traces, controls, pending: [...pending.keys()] }));
});
(async () => {
  const client = {
    sendAppRequest: (type, params) => dispatch({ ...params, type }),
    sendAppMessage: (type, params) => {
      void dispatch({ ...params, type }).catch(error => record({ phase: 'transport-error', message: error.message }));
      return true;
    },
  };
  const server = await production.startSummonerWebServer({ preferredPort: 23791,
    dispatch: message => production.dispatchSummonerWeb(client, message),
    attachChrome: () => { throw new Error('fixture must never launch normal Chrome'); },
    hasExtensionPeer: () => false });
  await new Promise(resolve => controlServer.listen(0, '127.0.0.1', resolve));
  console.log(JSON.stringify({ port: server.port, controlPort: controlServer.address().port }));
})().catch(error => { console.error(error); process.exitCode = 1; });
process.on('SIGTERM', () => { production.stopSummonerWebServer(); controlServer.close(); process.exit(0); });

```

## Full current companion/scripts/test-summoner-meeting-ui.py
```
"""#492 real native summoner, HTTP/ACL/store/parsers; synthetic microphone and model.

Run from companion after `nvm use 22`:
uv run --no-project --with playwright python scripts/test-summoner-meeting-ui.py
No installed app, ordinary Chrome profile, user configuration, or user audio is used.
"""
from pathlib import Path
import io
import json
import math
import struct
import subprocess
import tempfile
import time
import urllib.request
import wave
import zipfile

from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent.parent
ARTIFACTS = ROOT.parent / ".omx/artifacts/meeting-492/native"
ARTIFACTS.mkdir(parents=True, exist_ok=True)


def wav_bytes(seconds=2):
    out = io.BytesIO()
    with wave.open(out, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(16000)
        wav.writeframes(b"".join(struct.pack("<h", int(5000 * math.sin(2 * math.pi * 220 * i / 16000)))
                                  for i in range(int(16000 * seconds))))
    return out.getvalue()


def docx_bytes():
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as docx:
        docx.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        docx.writestr("_rels/.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        docx.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Python 周四发布，负责人小王。</w:t></w:r></w:p></w:body></w:document>')
    return out.getvalue()


with tempfile.TemporaryDirectory(prefix="cmspark-native-meeting-") as temporary:
    work = Path(temporary)
    microphone = work / "synthetic-microphone.wav"
    microphone.write_bytes(wav_bytes(12))
    server_log = (ARTIFACTS / "server.log").open("w")
    server = subprocess.Popen(
        ["node", "scripts/serve-summoner-meeting-fixture.cjs", str(work / "data"), str(ARTIFACTS / "native-handler-trace.json")],
        cwd=ROOT, stdout=subprocess.PIPE, stderr=server_log, text=True,
    )
    try:
        while True:
            line = server.stdout.readline()
            if not line:
                raise RuntimeError("native fixture exited: " + (ARTIFACTS / "server.log").read_text())
            if line.startswith('{"port":'):
                addresses = json.loads(line)
                break
        origin = f"http://127.0.0.1:{addresses['port']}"
        control_url = f"http://127.0.0.1:{addresses['controlPort']}"
        local_http = urllib.request.build_opener(urllib.request.ProxyHandler({}))

        def control(**changes):
            request = urllib.request.Request(control_url, data=json.dumps(changes).encode() if changes else None,
                                             headers={"Content-Type": "application/json"})
            return json.load(local_http.open(request, timeout=5))

        def events(kind, phase="request", after=0):
            return [item for item in control()["traces"] if item["n"] > after and item.get("phase") == phase and item.get("type") == kind]

        def wait_event(page, kind, phase="request", after=0, timeout=20000):
            deadline = time.monotonic() + timeout / 1000
            while time.monotonic() < deadline:
                matches = events(kind, phase, after)
                if matches:
                    return matches[-1]
                page.wait_for_timeout(50)
            raise AssertionError(f"No {phase} {kind} after {after}; recent trace: {control()['traces'][-8:]}")

        def no_model(after=0):
            assert not events("meeting.generate_minutes", after=after)
            assert not [item for item in control()["traces"] if item["n"] > after and item.get("phase") == "llm"]

        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(channel="chrome", headless=True, args=[
                "--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream",
                f"--use-file-for-fake-audio-capture={microphone}", "--autoplay-policy=no-user-gesture-required",
            ])
            context = browser.new_context(viewport={"width": 390, "height": 780}, permissions=["microphone"])
            page = context.new_page()
            page.set_default_timeout(12000)
            errors, requests = [], []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.on("request", lambda request: requests.append(request.url))
            page.add_init_script("window.resizeTo=()=>{};window.moveTo=()=>{};")
            page.goto(origin)
            expect(page.locator("#meetingStart")).to_be_visible()
            no_model()

            page.locator("#meetingOpen").click()
            expect(page.locator("#meetingDesk")).to_be_visible()
            assert not events("voice.stt.start"), "opening materials must not start capture"
            no_model()
            page.locator("#meetingBack").click()

            # The start entry may open the materials desk; mic starts only on the explicit record button.
            page.locator("#meetingStart").click()
            if page.locator("#meetingPrivacyAck").is_visible():
                page.locator("#meetingPrivacyAck").click()
            expect(page.locator("#meetingDesk")).to_be_visible()
            control(hold=["meeting.append_transcript", "meeting.end"])
            expect(page.locator("#meetingRec")).to_have_attribute("aria-pressed", "true")
            wait_event(page, "voice.stt.start")
            # Live raw text must be visible while its persistence ACK is deliberately pending.
            first_append = wait_event(page, "meeting.append_transcript", "held", timeout=22000)
            expect(page.locator("#meetingLive")).to_contain_text("配森")
            page.screenshot(path=str(ARTIFACTS / "native-live-390.png"), full_page=True)
            no_model()
            assert not events("meeting.end")
            page.locator("#meetingReferenceSection > summary").click()
            page.locator("#meetingReferenceNotes").fill("Python 周四发布，负责人小王。")
            page.locator("#meetingMinutesBtn").click()
            page.wait_for_timeout(250)
            assert not events("meeting.end"), "end ran before the raw append ACK"
            no_model()
            control(release="meeting.append_transcript")
            end_held = wait_event(page, "meeting.end", "held")
            no_model()
            control(release="meeting.end")
            generated = wait_event(page, "meeting.generate_minutes", "ack")
            assert generated["response"]["type"] == "meeting.minutes_result", generated
            append_acks = events("meeting.append_transcript", "ack")
            end_ack = events("meeting.end", "ack")[-1]
            generate_request = events("meeting.generate_minutes")[-1]
            assert all(event["n"] < end_held["n"] for event in append_acks)
            assert end_ack["n"] < generate_request["n"]
            expect(page.locator("#meetingMinutes")).to_contain_text("Python")
            expect(page.locator("#meetingEvidence")).to_contain_text("周四")
            expect(page.locator("#meetingEvidence")).to_contain_text("负责人小王")
            expect(page.locator("#meetingLive")).to_contain_text("配森")
            page.screenshot(path=str(ARTIFACTS / "native-correction-390.png"), full_page=True)
            # HTTP and SSE duplicate delivery must append each STT session exactly once.
            finalized = events("voice.stt.end", "ack")
            assert len(append_acks) == len(finalized), (append_acks, finalized)
            print("PASS native raw immediate, SSE/HTTP dedup, append ACK → end ACK → explicit minutes", flush=True)

            # A failed model call preserves the current transcript/reference and completed draft.
            before_text = page.locator("#meetingLive").inner_text()
            marker = control()["traces"][-1]["n"]
            control(failLlm=True)
            page.locator("#meetingMinutesBtn").click()
            failed = wait_event(page, "meeting.generate_minutes", "ack", after=marker)
            assert failed["response"]["type"] == "meeting.error"
            assert page.locator("#meetingLive").inner_text() == before_text
            expect(page.locator("#meetingReferenceNotes")).to_have_value("Python 周四发布，负责人小王。")
            control(failLlm=False)
            print("PASS native generation failure preserves materials", flush=True)

            marker = control()["traces"][-1]["n"]
            for filename, mime, data, phrase in [
                ("notes.md", "text/markdown", "Python 周四发布，负责人小王。\n".encode(), "Python"),
                ("notes.docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", docx_bytes(), "Python"),
            ]:
                with page.expect_file_chooser() as chooser:
                    page.locator("#meetingReferenceImport").click()
                chooser.value.set_files({"name": filename, "mimeType": mime, "buffer": data})
                expect(page.locator("#meetingReferenceName")).to_contain_text(filename)
                expect(page.locator("#meetingReferenceImport")).to_be_enabled()
                parsed = events("meeting.import_reference", "ack")[-1]["response"]["reference"]
                assert phrase in parsed["text"]
                expect(page.locator("#meetingReferenceNotes")).to_have_value(parsed["text"])
                no_model(after=marker)
            marker = control()["traces"][-1]["n"]
            page.locator("#meetingReferenceSave").click()
            saved = wait_event(page, "meeting.set_reference", "ack", after=marker)
            assert saved["response"]["meeting"]["reference_name"] == "notes.docx"
            expect(page.locator("#meetingAudioImport")).to_be_enabled()
            print("PASS native md/docx production parser and saved reference; no automatic model", flush=True)

            # Decode a real generated WAV with browser WebAudio, then send PCM to the local STT handler.
            marker = control()["traces"][-1]["n"]
            control(text="追加录音保留现有转写。")
            with page.expect_file_chooser() as chooser:
                page.locator("#meetingAudioImport").click()
            chooser.value.set_files({"name": "synthetic.wav", "mimeType": "audio/wav", "buffer": wav_bytes()})
            imported = wait_event(page, "meeting.append_transcript", "ack", after=marker)
            assert imported["response"]["type"] != "meeting.error", imported
            expect(page.locator("#meetingLive")).to_contain_text("追加录音保留现有转写")
            expect(page.locator("#meetingLive")).to_contain_text("配森")
            expect(page.locator("#meetingAudioImport")).to_be_enabled()
            assert events("voice.stt.chunk", after=marker), "audio import never reached PCM upload"
            no_model(after=marker)
            print("PASS native real WAV decode/import appends to existing raw text without generation", flush=True)

            marker = control()["traces"][-1]["n"]
            preserved = page.locator("#meetingLive").inner_text()
            control(failStt=True)
            with page.expect_file_chooser() as chooser:
                page.locator("#meetingAudioImport").click()
            chooser.value.set_files({"name": "failed.wav", "mimeType": "audio/wav", "buffer": wav_bytes()})
            failed_stt = wait_event(page, "voice.stt.end", "ack", after=marker)
            assert failed_stt["response"]["type"] == "voice.stt.error"
            page.wait_for_timeout(100)
            assert page.locator("#meetingLive").inner_text() == preserved
            no_model(after=marker)
            control(failStt=False)
            print("PASS native failed audio import keeps prior materials", flush=True)

            layouts = []
            for width in [390, 960]:
                page.set_viewport_size({"width": width, "height": 780})
                page.wait_for_timeout(100)
                result = page.evaluate("""() => {
                  const ids=['meetingDesk','meetingLive','meetingReferenceNotes','meetingAudioImport','meetingReferenceImport'];
                  return {width:innerWidth, scrollWidth:document.documentElement.scrollWidth,
                    boxes:ids.map(id=>{const el=document.getElementById(id),r=el.getBoundingClientRect();
                      return {id,left:r.left,right:r.right,width:r.width,height:r.height}})};
                }""")
                assert result["scrollWidth"] <= width + 1, result
                assert all(box["left"] >= -1 and box["right"] <= width + 1 and box["width"] > 0 for box in result["boxes"]), result
                live_box = next(box for box in result["boxes"] if box["id"] == "meetingLive")
                assert live_box["height"] >= 140, ("transcript collapsed behind materials/minutes", result)
                layouts.append(result)
                page.screenshot(path=str(ARTIFACTS / f"native-{width}.png"), full_page=True)
            (ARTIFACTS / "layout-evidence.json").write_text(json.dumps(layouts, ensure_ascii=False, indent=2))

            # Drop the request, drop its successful response, or leave only the raw file stale.
            # Every retry must preserve previous imports and commit the same segment once.
            for mode in ["before_send", "after_commit", "partial_write"]:
                expect(page.locator("#meetingRec")).to_be_enabled()
                marker = control()["traces"][-1]["n"]
                control(text=f"恢复追加不重复 {mode}。", partialRawOnce=mode == "partial_write")
                notes_before = page.locator("#meetingReferenceNotes").input_value()
                def lose_append(route):
                    if mode in ["after_commit", "partial_write"]:
                        actual = route.fetch()
                        assert actual.json()["type"] == "meeting.updated"
                    route.abort("failed")
                page.route("**/api/meeting/append", lose_append, times=1)
                page.locator("#meetingRec").click()
                started = wait_event(page, "meeting.start", "ack", after=marker)
                existing = started["response"]["meeting"]
                assert existing["reference_name"] == "notes.docx"
                assert existing["reference_notes"] == notes_before
                wait_event(page, "voice.stt.chunk", after=marker)
                page.locator("#meetingMinutesBtn").click()
                expect(page.locator("#meetingRetry")).to_be_visible()
                expect(page.locator("#meetingMinutesBtn")).to_be_enabled()
                expect(page.locator("#meetingLive")).to_contain_text(f"恢复追加不重复 {mode}")
                expect(page.locator("#meetingLive")).to_contain_text("追加录音保留现有转写")
                no_model(after=marker)
                assert not events("meeting.end", after=marker), "failed save incorrectly ended meeting"
                if mode == "partial_write":
                    fault = [event for event in control()["traces"] if event["n"] > marker and event.get("phase") == "disk-fault"][-1]
                    assert fault["kind"] == mode
                    assert fault["before"]["transcript"] == existing["transcript"]
                    assert fault["after"]["transcript"][:-1] == existing["transcript"]
                    assert fault["after"]["original_transcript"] == existing["original_transcript"]
                    assert fault["after"]["transcript"][-1]["segment_id"] == fault["segment_id"]
                    assert len(fault["after"]["transcript"]) == len(existing["transcript"]) + 1
                page.locator("#meetingRetry").click()
                recovered = wait_event(page, "meeting.end", "ack", after=marker)["response"]["meeting"]
                assert len(recovered["transcript"]) == len(existing["transcript"]) + 1, recovered
                assert len(recovered["original_transcript"]) == len(existing["original_transcript"]) + 1
                assert recovered["transcript"][:-1] == existing["transcript"]
                assert recovered["original_transcript"][:-1] == existing["original_transcript"]
                appended = events("meeting.append_transcript", after=marker)
                assert len(appended) == (1 if mode == "before_send" else 2)
                segment_ids = {event["request"].get("segment_id") for event in appended}
                assert len(segment_ids) == 1 and None not in segment_ids and "" not in segment_ids
                assert recovered["transcript"][-1]["segment_id"] in segment_ids
                assert recovered["original_transcript"][-1] == recovered["transcript"][-1]
                expect(page.locator("#meetingRetry")).to_be_hidden()
                no_model(after=marker)
                page.locator("#meetingMinutesBtn").click()
                regenerated = wait_event(page, "meeting.generate_minutes", "ack", after=marker)
                assert regenerated["response"]["type"] == "meeting.minutes_result", regenerated
                expect(page.locator("#meetingMinutesBtn")).to_be_enabled()
                print(f"PASS native {mode} append failure → retry → end → generation; no duplicate or lost materials", flush=True)

            # Import-first users need no recording session. A new document requires its own consent.
            marker = control()["traces"][-1]["n"]
            control(text="配森将在周五发布。")
            imported_page = context.new_page()
            imported_page.set_default_timeout(12000)
            imported_page.on("pageerror", lambda error: errors.append(str(error)))
            imported_page.on("request", lambda request: requests.append(request.url))
            imported_page.add_init_script("window.resizeTo=()=>{};window.moveTo=()=>{};")
            imported_page.goto(origin)
            imported_page.locator("#meetingOpen").click()
            with imported_page.expect_file_chooser() as chooser:
                imported_page.locator("#meetingReferenceImport").click()
            chooser.value.set_files({"name": "import-first.md", "mimeType": "text/markdown", "buffer": "Python 周四发布，负责人小王。".encode()})
            expect(imported_page.locator("#meetingReferenceName")).to_contain_text("import-first.md")
            expect(imported_page.locator("#meetingAudioImport")).to_be_enabled()
            assert not events("voice.stt.start", after=marker)
            no_model(after=marker)
            imported_page.locator("#meetingAudioImport").click()
            expect(imported_page.locator("#meetingPrivacyAck")).to_be_visible()
            assert not events("voice.stt.start", after=marker)
            imported_page.screenshot(path=str(ARTIFACTS / "native-import-consent-390.png"), full_page=True)
            with imported_page.expect_file_chooser() as chooser:
                imported_page.locator("#meetingPrivacyAck").click()
            chooser.value.set_files({"name": "import-first.wav", "mimeType": "audio/wav", "buffer": wav_bytes()})
            wait_event(imported_page, "meeting.append_transcript", "ack", after=marker)
            expect(imported_page.locator("#meetingAudioImport")).to_be_enabled()
            expect(imported_page.locator("#meetingLive")).to_contain_text("配森")
            expect(imported_page.locator("#meetingReferenceNotes")).to_have_value("Python 周四发布，负责人小王。")
            assert not events("meeting.start", after=marker), "import unexpectedly started microphone recording"
            assert len(events("voice.stt.start", after=marker)) == 1
            no_model(after=marker)
            imported_page.locator("#meetingMinutesBtn").click()
            imported_minutes = wait_event(imported_page, "meeting.generate_minutes", "ack", after=marker)
            assert imported_minutes["response"]["type"] == "meeting.minutes_result", imported_minutes
            expect(imported_page.locator("#meetingEvidence")).to_contain_text("Python")
            print("PASS native import-first materials preserve notes, require explicit audio consent, and generate only on click", flush=True)
            assert not errors, errors
            assert all(url.startswith(origin) for url in requests), requests
            (ARTIFACTS / "browser-evidence.json").write_text(json.dumps({"errors": errors, "requests": requests, "layouts": layouts}, ensure_ascii=False, indent=2))
            print("PASS native 390/960 layouts, no page errors or external requests", flush=True)
            browser.close()
    finally:
        server.terminate()
        server.wait(timeout=8)
        server_log.close()

```

## Full current companion/src/summoner/meeting-workflow.ts
```
/** Native meeting page workflow. Uses the shell's authenticated HTTP API only. */
export const SUMMONER_MEETING_WORKFLOW_JS = String.raw`
  var meetingEnding=null,meetingWorkBusy=false,meetingFailure=null;
  var meetingReferenceName="",meetingCapture=null,meetingConsentResume=null,pendingMeetingSegment=null,meetingViewRev=0;
  function requestMeetingConsent(resume){
    meetingConsentResume=resume;$("meetingVoiceSection").hidden=voiceAck;$("meetingPrivacy").hidden=false;
  }
  $("meetingOpen").onclick=function(){showMeetingDesk(true)};
  $("meetingNew").onclick=async function(){
    if(meetingWorkBusy)return;meetingWorkBusy=true;meetingControls(true);
    try{await prepareMeetingSwitch();meetingViewRev++;lastMeetingId="";meetingReferenceName="";meetingFailure=null;pendingMeetingSegment=null;$("meetingReferenceName").textContent="";$("meetingReferenceNotes").value="";paintTranscript([]);$("meetingMinutes").hidden=true;$("meetingEvidence").hidden=true;$("meetingOriginal").hidden=true;$("meetingRetry").hidden=true;setRecordingUi(false);meetingSay("新会议：可开始录制或导入材料")}catch(e){meetingProblem(e)}finally{meetingWorkBusy=false;meetingControls(false)}
  };
  async function prepareMeetingSwitch(){
    await endMeetingCapture();
    if(lastMeetingId || $("meetingReferenceNotes").value){await saveMeetingReference(await ensureMeeting())}
  }
  function meetingSay(text){$("meetingWorkflowStatus").textContent=text||"";setStatus(text)}
  function meetingProblem(e){meetingSay(e&&e.message||String(e)||"会议操作失败")}
  function meetingChecked(d){
    if(!d || d.error || d.type==="error" || d.type==="meeting.error" || d.type==="voice.stt.error"){
      var e=new Error(d&&(d.message||d.error)||"会议服务未返回结果");e.code=d&&(d.code||d.error_code);throw e;
    }
    return d;
  }
  function meetingRequest(path,body){
    var controller=new AbortController(),ms=path==="/api/stt/end"?305000:path==="/api/meeting/minutes"?100000:15000;
    var timer=setTimeout(function(){controller.abort()},ms);
    var opts={signal:controller.signal};
    if(body!==undefined){opts.method="POST";opts.headers={"Content-Type":"application/json"};opts.body=JSON.stringify(body)}
    return api(path,opts).then(meetingChecked).catch(function(e){if(e.name==="AbortError")throw new Error("请求超时，请保留当前稿并重试");throw e}).finally(function(){clearTimeout(timer)});
  }
  function meetingPost(path,body){return meetingRequest(path,body)}
  function meetingControls(disabled){
    ["meetingRec","meetingMinutesBtn","meetingAudioImport","meetingReferenceImport","meetingReferenceSave","meetingHistToggle","meetingNew"].forEach(function(id){$(id).disabled=disabled});
    $("meetingReferenceNotes").disabled=disabled;
  }
  function applyMeetingMaterials(m){
    meetingReferenceName=m.reference_name||"";
    $("meetingReferenceName").textContent=meetingReferenceName;
    $("meetingReferenceNotes").value=m.reference_notes||"";
    var original=(m.original_transcript||[]).map(function(l){return l.text||""}).join("\n");
    $("meetingOriginal").hidden=!original;$("meetingOriginalText").textContent=original;
    renderMeetingEvidence(m.minutes);
  }
  function renderMeetingEvidence(minutes){
    var box=$("meetingEvidence");box.innerHTML="";box.hidden=!minutes;
    if(!minutes)return;
    if(minutes.stale){var stale=document.createElement("p");stale.textContent="材料已修改，当前纪要待重新生成。";box.appendChild(stale)}
    function detail(title,text){if(!text)return;var d=document.createElement("details"),s=document.createElement("summary"),p=document.createElement("pre");s.textContent=title;p.textContent=text;d.appendChild(s);d.appendChild(p);box.appendChild(d)}
    detail("独立校正稿",minutes.corrected_transcript);
    detail("本次生成使用的转写",minutes.source_transcript);
    detail("修改依据",(minutes.corrections||[]).map(function(c){return c.original+" → "+c.replacement+"\n参考原句："+c.reference_excerpt+"\n依据："+c.reason}).join("\n\n"));
    detail("参考补充（不代表会议决定）",(minutes.reference_supplements||[]).map(function(c){return c.reference_excerpt+"\n"+c.reason}).join("\n\n"));
    detail("待确认冲突",(minutes.conflicts||[]).map(function(c){return "转写："+c.transcript_excerpt+"\n参考："+c.reference_excerpt+"\n"+c.reason}).join("\n\n"));
  }
  function captureFailure(s,e){
    if(s.failed)return;
    s.failed=e;meetingFailure=e;$("meetingRetry").hidden=false;meetingProblem(new Error(sttUserCopy(e.code,e.message)));
    if(meetingCapture===s){teardownStt();sttSid="";stopRecClock();$("meetingHint").textContent="转写失败，请保留当前稿并重试"}
  }
  function commitMeetingSegment(s,d){
    if(s.committed)return s.committed;
    meetingChecked(d);
    if(d.type!=="voice.stt.result" || d.sessionId!==s.sid)throw new Error("语音识别未返回匹配的最终结果");
    var text=typeof d.text==="string"?d.text.trim():"";
    if(!text){s.committed=Promise.resolve();return s.committed}
    // Paint first, persist second. Failed saves keep the visible text for recovery.
    appendMeetingLive(text,"");$("meetingPartial").textContent="";
    s.text=text;pendingMeetingSegment=s;
    s.committed=saveMeetingSegment(s);
    s.committed.catch(function(e){captureFailure(s,e)});
    return s.committed;
  }
  async function saveMeetingSegment(s){
    var reply=await meetingPost("/api/meeting/append",{id:s.owner,text:s.text,segment_id:s.sid});
    var m=reply.meeting;
    if(!m || m.id!==s.owner || !(m.original_transcript||[]).some(function(line){return line.segment_id===s.sid && line.text===s.text && line.source==="stt"}))throw new Error("原始转写保存回执不匹配，请重试保存");
    var raw=(m.original_transcript||[]).map(function(l){return l.text||""}).join("\n");
    $("meetingOriginal").hidden=!raw;$("meetingOriginalText").textContent=raw;renderMeetingEvidence(m.minutes);
    if(pendingMeetingSegment===s)pendingMeetingSegment=null;
  }
  $("meetingRetry").onclick=async function(){
    if(meetingWorkBusy || meetingEnding)return;meetingWorkBusy=true;meetingControls(true);
    try{
      var s=pendingMeetingSegment;
      if(s){await saveMeetingSegment(s);s.failed=null;s.committed=Promise.resolve()}
      if(meetingCapture){await meetingCapture.queue.catch(function(){});await meetingPost("/api/stt/abort",{sessionId:meetingCapture.sid}).catch(function(){});meetingCapture=null}
      meetingFailure=null;$("meetingRetry").hidden=true;
      if(s){await endMeetingCapture();$("meetingHint").textContent="末段转写已恢复";meetingSay("末段转写已核对保存，可重新生成纪要")}
      else if(meetingId){startStt();startRecClock();meetingSay("正在重试录制；已保存转写保留")}
    }catch(e){meetingProblem(e)}finally{meetingWorkBusy=false;meetingControls(false)}
  };
  function meetingSttEvent(d){
    var s=meetingCapture;if(!s || d.sessionId!==s.sid)return;
    if(d.type==="voice.stt.partial"){$("meetingPartial").textContent=d.text||"";return}
    if(d.type==="voice.stt.error"){captureFailure(s,{code:d.code,message:d.message||d.error});return}
    if(d.type==="voice.stt.result"){
      try{commitMeetingSegment(s,d).catch(function(){})}catch(e){captureFailure(s,e)}
    }
  }
  function queueMeetingPcm(s,bytes){
    var seq=s.seq++,data=uint8ToB64(bytes);
    s.queue=s.queue.then(function(){if(s.failed)throw s.failed;return meetingPost("/api/stt/chunk",{sessionId:s.sid,seq:seq,data:data})});
    s.queue.catch(function(e){captureFailure(s,e)});
  }
  function flushStt(force){
    var s=meetingCapture;if(!s || !sttSid)return;
    var min=force?1:STT_FLUSH;
    while(sttBuf.length>=min){
      var n=Math.min(STT_CHUNK,sttBuf.length);
      queueMeetingPcm(s,new Uint8Array(sttBuf.subarray(0,n)));
      sttSeq=s.seq;sttBuf=new Uint8Array(sttBuf.subarray(n));
    }
  }
  function stopStt(abort){
    var s=meetingCapture;if(!s)return Promise.resolve();
    if(s.finishing)return s.finishing;
    if(!abort)flushStt(true);
    teardownStt();sttSid="";
    if(!abort && !meetingEnding)$("meetingHint").textContent="分段识别中，麦克风暂时暂停";
    s.finishing=s.queue.then(function(){
      if(abort || s.failed)return meetingPost("/api/stt/abort",{sessionId:s.sid}).then(function(){throw s.failed||new Error("已取消转写")});
      return meetingPost("/api/stt/end",{sessionId:s.sid,totalSeq:s.seq}).then(function(d){return commitMeetingSegment(s,d)});
    }).then(function(){if(s.failed)throw s.failed}).catch(function(e){captureFailure(s,e);return meetingPost("/api/stt/abort",{sessionId:s.sid}).catch(function(){}).then(function(){throw e})}).finally(function(){
      if(meetingCapture===s)meetingCapture=null;
      if(meetingId===s.owner && !meetingEnding && !meetingFailure)startStt();
    });
    s.finishing.catch(function(){});
    return s.finishing;
  }
  function startStt(){
    if(meetingCapture || meetingEnding || !meetingId)return;
    if(summonerVoice)summonerVoice.cancel();
    var s={owner:meetingId,sid:"ov-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10),seq:0,failed:null,committed:null,finishing:null};
    meetingCapture=s;$("meetingHint").textContent="正在准备下一段录音…";sttSid=s.sid;sttSeq=0;sttBuf=new Uint8Array(0);sttFloat=new Float32Array(0);sttLive=true;
    s.queue=Promise.resolve().then(function(){
      if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia)throw new Error(STT_MIC_FAIL);
      return new Promise(function(resolve,reject){
        var expired=false,timer=setTimeout(function(){expired=true;reject(new Error("等待麦克风授权超时，请允许麦克风后重试"))},30000);
        navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}}).then(function(stream){
          clearTimeout(timer);if(expired || !sttLive || sttSid!==s.sid){stream.getTracks().forEach(function(t){t.stop()});reject(new Error("录制已停止"));return}resolve(stream);
        },function(e){clearTimeout(timer);reject(e)});
      });
    }).then(function(stream){
      if(!sttLive || sttSid!==s.sid){stream.getTracks().forEach(function(t){t.stop()});throw new Error("录制尚未就绪，已停止")}
      sttStream=stream;
      return meetingPost("/api/stt/start",{sessionId:s.sid,modelId:voiceSettings.localModelId||"medium",privacy_ack_v2:true,lang:voiceSettings.lang||"zh",maxMs:STT_MEETING_MS});
    }).then(function(){if(sttLive && sttSid===s.sid){$("meetingHint").textContent="录制中";beginPcm(s.sid,sttStream)}});
    s.queue.catch(function(e){captureFailure(s,e)});
  }
  function endMeetingCapture(){
    if(meetingEnding)return meetingEnding;
    if(!meetingId)return Promise.resolve();
    var id=meetingId;stopRecClock();meetingControls(true);
    $("meetingHint").textContent="正在保存最后一段…";
    // Assign before stopping: final callbacks must not start another capture window.
    meetingEnding=Promise.resolve().then(function(){return stopStt(false)}).then(function(){
      if(meetingFailure)throw meetingFailure;
      return meetingPost("/api/meeting/end",{id:id});
    }).then(function(d){
      if(!d.meeting || d.meeting.id!==id)throw new Error("结束会议回执不匹配");
      lastMeetingId=id;meetingId="";setRecordingUi(false);
      $("meetingHint").textContent="已结束 · 可生成纪要";meetingSay("录制已结束，转写已保存");loadMeetingHistory();
    }).catch(function(e){meetingProblem(e);throw e}).finally(function(){meetingEnding=null;meetingControls(meetingWorkBusy)});
    meetingEnding.catch(function(){});return meetingEnding;
  }
  async function ensureMeeting(){
    var id=meetingId||lastMeetingId;if(id)return id;
    var d=await meetingPost("/api/meeting/create",{title:"导入会议"});
    if(!d.meeting || !d.meeting.id)throw new Error("创建会议失败");
    lastMeetingId=d.meeting.id;setRecordingUi(false);return lastMeetingId;
  }
  async function saveMeetingReference(id){
    var notes=$("meetingReferenceNotes").value,name=meetingReferenceName;
    if(notes.length>100000)throw new Error("参考笔记不能超过 100000 字符");
    var d=await meetingPost("/api/meeting/reference",{id:id,reference_notes:notes,reference_name:name});
    if(!d.meeting || d.meeting.id!==id || d.meeting.reference_notes!==notes || d.meeting.reference_name!==name)throw new Error("参考笔记保存回执不匹配");
    renderMeetingEvidence(d.meeting.minutes);return d.meeting;
  }
  async function requestMeetingMinutes(){
    if(meetingWorkBusy)return;
    if(!meetingAck || !voiceAck){requestMeetingConsent(requestMeetingMinutes);return}
    meetingWorkBusy=true;meetingControls(true);
    try{
      await endMeetingCapture();
      var id=lastMeetingId;if(!id)throw new Error("请先录制或导入录音");
      await saveMeetingReference(id);
      meetingSay("正在生成纪要…");$("meetingHint").textContent="正在生成纪要…";
      var d=await meetingPost("/api/meeting/minutes",{id:id,privacy_ack_v1:true});
      var md=d.minutes&&(d.minutes.raw_md||d.minutes.md);
      if(!md)throw new Error("纪要生成失败：未返回正文");
      $("meetingMinutes").hidden=false;$("meetingMinutes").innerHTML="<p>会议纪要 · AI 草稿，请核对</p>"+renderMd(md);renderMeetingEvidence(d.minutes);
      meetingSay(d.minutes.stale?"材料已变化，请重新生成纪要":"AI 纪要草稿已生成，请核对");$("meetingHint").textContent="AI 纪要草稿";
    }catch(e){meetingProblem(e);$("meetingHint").textContent="纪要生成失败"}
    finally{meetingWorkBusy=false;meetingControls(false)}
  }
  $("meetingReferenceImport").onclick=function(){if(!meetingWorkBusy)$("meetingReferenceFile").click()};
  $("meetingReferenceFile").onchange=async function(){
    var file=this.files&&this.files[0];this.value="";if(!file || meetingWorkBusy)return;
    meetingWorkBusy=true;meetingControls(true);
    try{
      if(!/\.(docx|md|txt)$/i.test(file.name))throw new Error("请选择 Word（DOCX）、MD 或 TXT 文件");
      if(file.size>7*1024*1024)throw new Error("参考文件不能超过 7 MiB");
      var d=await meetingPost("/api/meeting/reference/import",{file:{name:file.name,type:file.type,content:uint8ToB64(new Uint8Array(await file.arrayBuffer()))}});
      if(!d.reference || typeof d.reference.text!=="string")throw new Error("参考文件解析失败");
      meetingReferenceName=d.reference.name;$("meetingReferenceName").textContent=meetingReferenceName;$("meetingReferenceNotes").value=d.reference.text;$("meetingReferenceSection").open=true;
      await saveMeetingReference(await ensureMeeting());meetingSay("参考笔记已保存；生成时会保留原始转写并列出校正依据");
    }catch(e){meetingProblem(e)}finally{meetingWorkBusy=false;meetingControls(false)}
  };
  $("meetingReferenceSave").onclick=async function(){
    if(meetingWorkBusy)return;meetingWorkBusy=true;meetingControls(true);
    try{await saveMeetingReference(await ensureMeeting());meetingSay("参考笔记已保存")}catch(e){meetingProblem(e)}finally{meetingWorkBusy=false;meetingControls(false)}
  };
  $("meetingReferenceNotes").oninput=function(){meetingSay("参考笔记有未保存修改；生成纪要前会先保存")};
  $("meetingAudioImport").onclick=function(){if(meetingWorkBusy)return;if(!meetingAck || !voiceAck){requestMeetingConsent(function(){$("meetingAudioFile").click()});return}$("meetingAudioFile").click()};
  $("meetingAudioFile").onchange=async function(){
    var file=this.files&&this.files[0];this.value="";if(!file || meetingWorkBusy)return;
    if(!meetingAck || !voiceAck){meetingSay("请先阅读并确认会议及语音说明，再导入录音");return}
    meetingWorkBusy=true;meetingControls(true);var ctx=null,s=null;
    try{
      await endMeetingCapture();await loadVoiceSettings();
      if(voiceSettings.sttEngine!=="local")throw new Error("请在侧栏设置 → 输入与语音中启用本机转写并下载组件和模型");
      if(file.size>100*1024*1024)throw new Error("录音文件不能超过 100 MiB，请分段导入");
      var AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw new Error("当前浏览器无法解码录音");
      ctx=new AC();meetingSay("正在解码录音…");
      var audio=await ctx.decodeAudioData(await file.arrayBuffer());
      if(!audio.length || audio.duration>4*60*60)throw new Error("录音为空或超过 4 小时，请分段导入");
      var id=await ensureMeeting(),chunkFrames=Math.floor(audio.sampleRate*45),chunks=Math.ceil(audio.length/chunkFrames);
      meetingFailure=null;
      for(var offset=0,index=0;offset<audio.length;offset+=chunkFrames,index++){
        meetingSay("正在识别录音 "+(index+1)+" / "+chunks);
        var n=Math.min(chunkFrames,audio.length-offset),mono=new Float32Array(n);
        for(var ch=0;ch<audio.numberOfChannels;ch++){var samples=audio.getChannelData(ch);for(var j=0;j<n;j++)mono[j]+=samples[offset+j]/audio.numberOfChannels}
        var pcm=floatToS16(resampleMono(mono,audio.sampleRate,STT_RATE));
        s={owner:id,sid:"ov-import-"+Date.now().toString(36)+"-"+index,seq:0,failed:null,committed:null};meetingCapture=s;
        s.queue=meetingPost("/api/stt/start",{sessionId:s.sid,modelId:voiceSettings.localModelId,privacy_ack_v2:true,lang:voiceSettings.lang||"zh",maxMs:45000});
        for(var at=0;at<pcm.length;at+=STT_CHUNK)queueMeetingPcm(s,pcm.subarray(at,Math.min(pcm.length,at+STT_CHUNK)));
        await s.queue;
        var result=await meetingPost("/api/stt/end",{sessionId:s.sid,totalSeq:s.seq});await commitMeetingSegment(s,result);
        if(s.failed)throw s.failed;meetingCapture=null;s=null;
      }
      await saveMeetingReference(id);meetingSay("录音转写已保存，可生成会议纪要");$("meetingHint").textContent="录音已导入";loadMeetingHistory();
    }catch(e){
      meetingProblem(e);
      if(s){await s.queue.catch(function(){});await meetingPost("/api/stt/abort",{sessionId:s.sid}).catch(function(){})}
    }finally{meetingCapture=null;if(ctx)await ctx.close().catch(function(){});meetingWorkBusy=false;meetingControls(false);setRecordingUi(false)}
  };
`

```

## Full current companion/tests/summoner-meeting-492.test.ts
```
import "./meeting-test-data-dir"
import test from "node:test"
import assert from "node:assert/strict"
import vm from "node:vm"
import fs from "node:fs"
import path from "node:path"
import AdmZip from "adm-zip"
import { DATA_DIR } from "../src/config"
import { startSummonerWebServer, stopSummonerWebServer, SUMMONER_WEB_DISPATCH_ALLOW } from "../src/summoner-web"
import { assertSummonerAllowed } from "../src/ws/summoner-acl"
import { handleMeetingMessage } from "../src/meeting/meeting-handlers"
import { deleteMeeting, loadMeeting } from "../src/meeting/meeting-store"
import { SUMMONER_MEETING_WORKFLOW_JS } from "../src/summoner/meeting-workflow"

function workflowContext(api: (path: string, options?: any) => Promise<any>, fastTimers = false) {
  const elements = new Map<string, any>()
  const element = () => ({ value: "", textContent: "", hidden: false, innerHTML: "", appendChild() {} })
  const context = vm.createContext({
    $: (id: string) => { if (!elements.has(id)) elements.set(id, element()); return elements.get(id) },
    document: { createElement: element }, api, AbortController,
    setTimeout: fastTimers ? (callback: () => void) => setTimeout(callback, 5) : setTimeout,
    clearTimeout, setStatus() {},
  })
  vm.runInContext(SUMMONER_MEETING_WORKFLOW_JS, context)
  return context
}

test("#492 native retry reconciles real stored transcripts after failed write or lost ACK", async () => {
  const origin = { origin: "cmspark-tray://local", surface: "summoner" }
  for (const lostAck of [false, true]) {
    const created = await handleMeetingMessage({ type: "meeting.create", title: "Retry fixture" }, origin)
    const id = created.meeting.id
    let appendAttempts = 0
    const context = workflowContext(async (url, options) => {
      assert.equal(url, "/api/meeting/append")
      appendAttempts++
      const payload = JSON.parse(options.body)
      if (!lostAck && appendAttempts === 1) throw new Error("synthetic write failure before persistence")
      const reply = await handleMeetingMessage({ type: "meeting.append_transcript", ...payload, source: "stt" }, origin)
      if (lostAck && appendAttempts === 1) throw new Error("synthetic ACK lost after persistence")
      return reply
    })
    context.segment = { owner: id, text: "真正保存的末段", sid: "native-retry-segment" }
    try {
      await assert.rejects(vm.runInContext("saveMeetingSegment(segment)", context))
      await vm.runInContext("saveMeetingSegment(segment)", context)
      assert.equal(appendAttempts, 2)
      const saved = loadMeeting(id)!
      assert.deepEqual(saved.transcript.map(line => line.text), ["真正保存的末段"])
      assert.deepEqual(saved.original_transcript?.map(line => line.text), ["真正保存的末段"])
      assert.equal(saved.original_transcript?.[0].segment_id, context.segment.sid)
    } finally { deleteMeeting(id) }
  }
})

test("#492 native HTTP deadline aborts pending requests with an explicit recovery message", async () => {
  const context = workflowContext(async (_path, options) => new Promise((_resolve, reject) => {
    options.signal.addEventListener("abort", () => { const error = new Error("aborted"); error.name = "AbortError"; reject(error) })
  }), true)
  await assert.rejects(vm.runInContext('meetingPost("/api/meeting/append", {})', context), /请求超时/)
})

test("#492 native reference HTTP uses actual handlers, bounded files and exact ACL", async () => {
  const dispatched: Record<string, unknown>[] = []
  const { port, token } = await startSummonerWebServer({ preferredPort: 23580, dispatch: async msg => {
    dispatched.push(msg)
    return handleMeetingMessage(msg, { origin: "cmspark-tray://local", surface: "summoner" }, { getLlmConfig: () => null })
  } })
  let id = ""
  async function post(route: string, body: unknown, authenticated = true) {
    const response = await fetch(`http://127.0.0.1:${port}${route}`, { method: "POST", headers: {
      "Content-Type": "application/json", Origin: `http://127.0.0.1:${port}`,
      ...(authenticated ? { Cookie: `cmspark_overlay=${token}` } : {}),
    }, body: JSON.stringify(body) })
    return { status: response.status, data: await response.json().catch(() => null) as any }
  }
  try {
    const document = await fetch(`http://127.0.0.1:${port}/`)
    const html = await document.text()
    assert.match(document.headers.get("content-security-policy") || "", /script-src 'nonce-/)
    const script = html.match(/<script[^>]*>([\s\S]*?)<\/script>/)?.[1]
    assert.ok(script)
    assert.doesNotThrow(() => new vm.Script(script))
    const denied = await post("/api/meeting/reference/import", {}, false)
    assert.equal(denied.status, 403)
    const created = await post("/api/meeting/create", { title: "Native fixture" })
    assert.equal(created.data.type, "meeting.created")
    id = created.data.meeting.id
    const segment = { id, text: "原生末段", segment_id: "native-partial-segment" }
    const appended = await post("/api/meeting/append", segment)
    assert.equal(appended.data.meeting.original_transcript[0].segment_id, segment.segment_id)
    const originalPath = path.join(DATA_DIR, "meetings", id, "original-transcript.json")
    fs.writeFileSync(originalPath, "[]")
    const recovered = await post("/api/meeting/append", segment)
    assert.equal(recovered.data.meeting.transcript.length, 1)
    assert.equal(recovered.data.meeting.original_transcript.length, 1)
    assert.equal(recovered.data.meeting.original_transcript[0].segment_id, segment.segment_id)
    assert.deepEqual(JSON.parse(fs.readFileSync(originalPath, "utf8")), recovered.data.meeting.original_transcript)
    const replayed = await post("/api/meeting/append", segment)
    assert.equal(replayed.data.meeting.transcript.length, 1)
    assert.equal(replayed.data.meeting.original_transcript.length, 1)
    const invalidSegment = await post("/api/meeting/append", { ...segment, segment_id: "../../bad" })
    assert.equal(invalidSegment.data.code, "invalid_segment_id")
    const imported = await post("/api/meeting/reference/import", { file: { name: "notes.md", type: "text/markdown", content: Buffer.from("Python 用于本项目").toString("base64") }, path: "/not-readable" })
    assert.equal(imported.data.type, "meeting.reference_imported")
    assert.equal(imported.data.reference.text, "Python 用于本项目")
    assert.equal(dispatched.at(-1)?.path, undefined)
    const zip = new AdmZip()
    zip.addFile("[Content_Types].xml", Buffer.from('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'))
    zip.addFile("_rels/.rels", Buffer.from('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'))
    zip.addFile("word/document.xml", Buffer.from('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Python 参考</w:t></w:r></w:p></w:body></w:document>'))
    for (const [name, bytes] of [["notes.docx", zip.toBuffer()], ["notes.txt", Buffer.from("Python 参考")]] as const) {
      const response = await post("/api/meeting/reference/import", { file: { name, content: bytes.toString("base64") } })
      assert.equal(response.data.type, "meeting.reference_imported")
      assert.ok(response.data.reference.text.includes("Python 参考"))
    }
    const noConsent = await post("/api/meeting/minutes", { id })
    assert.equal(noConsent.data.code, "need_privacy_ack")
    const saved = await post("/api/meeting/reference", { id, reference_notes: imported.data.reference.text, reference_name: "notes.md", tool: "not-allowed" })
    assert.equal(saved.data.type, "meeting.updated")
    assert.equal(loadMeeting(id)?.reference_notes, "Python 用于本项目")
    assert.equal(dispatched.at(-1)?.tool, undefined)
    const invalid = await post("/api/meeting/reference/import", { file: { name: "notes.docx", type: "text/plain", content: Buffer.from("corrupt").toString("base64") } })
    assert.equal(invalid.data.type, "meeting.error")
    const large = await post("/api/meeting/reference/import", { file: { name: "notes.txt", content: Buffer.alloc(7 * 1024 * 1024 + 1, 65).toString("base64") } })
    assert.equal(large.data.code, "reference_file_too_large")
    const atLimit = Buffer.alloc(7 * 1024 * 1024, 32)
    atLimit.write("Python")
    const acceptedLimit = await post("/api/meeting/reference/import", { file: { name: "notes.txt", content: atLimit.toString("base64") } })
    assert.equal(acceptedLimit.data.reference.text, "Python")
    for (const type of ["meeting.import_reference", "meeting.set_reference"]) {
      assert.equal(SUMMONER_WEB_DISPATCH_ALLOW.has(type), true)
      assert.equal(assertSummonerAllowed("summoner", type).ok, true)
    }
    for (const type of ["meeting.import_text", "meeting.auto_diarize", "meeting.set_transcript"]) {
      assert.equal(SUMMONER_WEB_DISPATCH_ALLOW.has(type), false)
      assert.equal(assertSummonerAllowed("summoner", type).ok, false)
      assert.equal((await handleMeetingMessage({ type }, { origin: "cmspark-tray://local", surface: "summoner" })).code, "origin_denied")
    }
  } finally { if (id) deleteMeeting(id); stopSummonerWebServer() }
})

```

## Previous complete report grok-final.md
# #492 Final dual-surface T3 review

Independent reassessment of frozen code + machine evidence (base `e7be0d2f`). Prior Grok plugin **REJECT** is re-checked against the shipped native summoner, not the design checkpoint.

## Outcome

The ticket’s closed loop is present on **both** authorized surfaces: live raw ASR is painted before optional refine; stop-and-generate waits on real write/end receipts; notes are independent of ASR; generation is explicit and ACK-gated; invalid reference JSON fails closed without a silent Markdown fallback; raw archive is not overwritten by edits or AI draft. T3 expansion is the two bounded reference verbs only.

Prior plugin P1 (default **结束并生成纪要** undoing default smart-segment via `silence_cut: false` + 150 ms sleep) is **fixed**: `finalizeCapture` no longer cuts-then-sleeps; `saveMeetingMaterials(..., silenceCut)` ACKs `set_transcript` with `silence_cut: true` and feeds the receipt’s canonical lines to `generate_minutes`. Workflow UI holds append → end → set_transcript → set_reference and asserts segmented source + uncut `original_transcript`.

## Process / evidence used

- **[executed]** extension 1339/1339; extension + companion builds; plugin workflow UI (11 PASS); native summoner UI (9 PASS); close/nav UI; synthetic Mac ASR JSON (medium/large, not a Windows/mic claim).
- **[inspected]** frozen sources in the packet (panel, persistence, handlers/store/reference/minutes, summoner HTTP/ACL/workflow, validators, tests).
- Companion TAP in-packet is truncated to a 20-test settings slice; meeting unit tests are inspected in source, not re-proven by that log. That is an evidence-packaging gap, not a product fail.

## Components (in scope)

Extension `MeetingPanel` / `meeting-close` / `meeting-audio-import` + SW cases; companion `meeting-handlers` / `meeting-store` / `meeting-reference` / `meeting-minutes` / `minutes-prompt`; WS `validate` + `summoner-acl` + `SUMMONER_WEB_DISPATCH_ALLOW`; `summoner-web` HTTP/HTML + `SUMMONER_MEETING_WORKFLOW_JS`. Overlay still denies `import_text` / `auto_diarize` / `set_transcript`.

## Prior REJECT — disposition

| Finding | Now |
|---|---|
| P1 stop-and-generate clobbers segmentation | **Fixed** (`silenceCut` on material save; receipt text is the generate snapshot; UI gate test). |
| P2 new session keeps old original | **Fixed** (`meeting.created`/`started` reset; UI: new session detaches archive). |
| P2 import `waitForWrites` swallowed | **Fixed** (error keeps `cause.message` + 保存转写; UI recovery restores editor **and** raw). |
| NIT template in UI stale vs server fingerprint | **Accepted/documented** (fingerprint = text+notes+name). |
| NIT one bad correction fails the job | **Intentional** fail-closed; originals kept; tests. |
| NIT user-guide omits new files | **Fixed** (§3.5). |
| Native incomplete | **Shipped** with HTTP/ACL/parser/UI evidence. |

## T3 boundary (exact)

- Allowlist increment is only `meeting.import_reference` + `meeting.set_reference` (WS ACL, web dispatch, overlay type set, SW switch).
- HTTP import forwards `{name,type,content}` only; test proves `path` / `tool` are dropped.
- Unstamped tray and random Origin stay `origin_denied`; cookie/Origin/nonce/CSP nonce still required (403 without cookie).
- `import_text` / `auto_diarize` / `set_transcript` remain summoner-denied.
- Native **HTTP minutes** requires `privacy_ack_v1 === true` (400 `need_privacy_ack` otherwise). Local STT still sends `privacy_ack_v2`.
- No new outbound deps; notes are JSON data under a “never instructions” prompt; LLM runs only after material ACK (or native disk save) on an explicit minutes action.
- Known live-path mic pause is disclosed; #494 not claimed.

Native minutes send `{id}` after `end` + `set_reference` receipts (not inline text). That matches T3 (no `set_transcript` on overlay) and is gated in UI: held append ACK blocks end and blocks `generate_minutes`.

## Findings (actionable only)

**NIT — native STT append has no stable `segment_id`; split-archive retry cannot repair like the extension**  
`companion/src/summoner-web.ts` (`/api/meeting/append` dispatches `id+text+source` only); `companion/src/summoner/meeting-workflow.ts` `saveMeetingSegment`.  
Trigger: `saveMeeting` writes `transcript.json` then `original-transcript.json`. If the process dies between those files, native GET sees transcript length+1 but original unchanged → throws `会议材料已在别处变化`, shows `#meetingRetry`, and **cannot** replay a unique segment key. Extension persistence + `appendTranscript` collision/repair path *does* this (`meeting-segment-idempotency-492.test.ts`). Common lost-HTTP-ACK paths **are** covered (`before_send` / `after_commit` PASS). Same words in later windows still append (new `s.base`). Not a duplicate-on-ACK-loss bug; it is a dual-surface hole vs the stated “bounded stable per-segment id” retry rule.

**NIT — abort / “保存会议材料…” depend on refs that do not re-render**  
`MeetingPanel.tsx`: `{importDoneRef.current && <button … 中止导入>}` and `{generatingRef.current ? "保存会议材料…" : …}`.  
Trigger: abort only appears because `setImportStatus`/`setBusy` happen to re-render; the generating label never flips from the ref. Behavior of save-then-LLM is still driven by `pendingGenerate` + `busy`. Cosmetic / fragile UI, not an ACK skip.

**NIT — canonical generate snapshot joins with `\n`, live editor uses `\n\n`**  
`meeting-close.ts` `saveMeetingMaterials` vs `formatLinesFromMeeting`. After stop-and-generate the textarea flattens blank lines. Data/speakers/raw archive remain; tested canonical == `source_transcript`.

Not scored as regressions: template-only stale is live-panel by design; whole-job reject on one unverified correction is declared; native import has timeouts/abort-on-failure but no user **中止** control (extension does); native `/api/meeting/start` still server-stamps `privacy_ack_v1` (pre-existing; minutes was correctly *not* stamped).

## Trajectory

Plugin REJECT cause is gone and locked with receipt-order UI. Native is a real HTML/HTTP/SSE implementation with production handlers, not a panel reuse claim. T3 allowlist matches the authorized increment. Remaining nits are recovery-symmetry and render hygiene, not “generate from unconfirmed text” or privacy/ACL overreach.

VERDICT: APPROVE_WITH_NITS

## Previous complete report deepseek-final.md
## Issue #492 final dual-surface T3 code review

### Outcome

The frozen code now includes the native summoner slice and fixes the prior Grok REJECT issues. The primary stop-and-generate path preserves default silence segmentation and gates generation behind real `append`, `end`, `set_transcript`, and `set_reference` receipts. The original raw ASR archive is written via stable per-segment IDs before replacement writes, and both UI tests demonstrate that live raw text, local original, and preserved prior materials survive failure injection. Native HTTP/ACL/store paths are covered by real browser tests. No claim of continuous recording is made; BOTH surfaces disclose the pause.

### Findings

**P1 — `meeting-handlers.ts` unauthenticated `meeting.get` via HTTP leaks the entire reference/original archive**
`handleRequest` in `summoner-web.ts` has the reference/material POST routes behind cookie/session, but the pre-existing GET route exists at `/api/meeting`. The native browser **page** itself is authenticated (the shell enforces it over the entire HTML/JS origin). A same-origin attacker or an overlayed page in the authenticated context is not a meaningful new threat. However, the new `original-transcript.json` and `reference.json` are not rate limited or filtered from the existing `/api/meeting` GET. Since `meeting.get` is not newly introduced, and the authenticated native page is the only consumer, this is a **NIT** at most; the changed path does not newly expose unauthenticated read.

**P2 — native `meetingWorkflow.ts` `prepareMeetingSwitch()` throws away the `await` of `saveMeetingReference` on the reference-only path**
`prepareMeetingSwitch`:
```
await endMeetingCapture();
if(lastMeetingId || $("meetingReferenceNotes").value){await saveMeetingReference(await ensureMeeting())}
```
`endMeetingCapture` already returns a Promise; the reference save is awaited correctly. No dropped promise in the actual source.

**P3 — `MeetingPanel.tsx` `onMsg` `meeting.updated` handler sets `minutesMd` but not `minutesStale` when `msg.meeting.minutes.stale` is false**
`setMinutesStale` is only set when true; a later readback of a cleaned minutes object with `stale: false` will not clear the live-panel stale badge. This is cosmetic state; a subsequent edit will set it true again. **NIT.**

**P4 — `meeting-close.ts` `waitForWrites` considers earlier write `confirmation` and `waitForWrites(id)` ordered write behavior under a replacing set_transcript**
`writes` list is append-only. `replacements` map is per-meeting `sequence`. A `set_transcript` with `sequence` N does not remove earlier records from the `writes` array. `hasUnconfirmedWrites` checks `sequence > replacedThrough && !confirmed`, so OK. `waitForWrites` owns all writes and `failed` uses `sequence > replacedThrough`, so a failed original write before a successful replacement is correctly skipped as superseded. **OK.**

**P5 — `meeting-store.ts` `setTranscript` bulk initialization of original from first STT list is deliberately coarse**
This is covered by tests: two identical utterances are preserved because the first `set_transcript` filters STT lines into `original_transcript`, then later live appends create separate archive lines. For the initial `set_transcript` with multiple STT lines, each line receives no `segment_id`; later retries of the bulk `set_transcript` replace the editable transcript but `original_transcript` remains fixed. That is acceptable, because bulk STT import is not a per-line append. **OK.**

**P6 — native `meetingWorkflow.ts` `requestMeetingMinutes` calls `saveMeetingReference` even when no notes, which can create an unnecessary `reference.json { notes:"", name:"" }`**
This persists empty reference, which is fine; it does not erase prior reference material and the fingerprint includes empty reference. **NIT.**

**P7 — native `saveMeetingSegment` does not persist a stable segment ID**
The native append path sends `/api/meeting/append` with `{id, text}` and no `segment_id`. Replayed append after a lost ACK relies on `appendTransientState` vs fetched base and `alreadySaved` content equality. The handler supports optional segment IDs; lacking one means retry dedup is heuristic. However, the native fixture explicitly tests both drop-before-send and drop-after-commit append exactly once. Since the native browser does not persist pending writes across dialog reload, this heuristic is sufficient and the stated requirement bounds retry to the same conversation context. **OK.**

**P8 — native reference import allows MIME mismatch but derives type from extension**
`importMeetingReference` ignores `type` for MIME and uses `extname`, exactly as tested. The `validateWsMessage` for `meeting.import_reference` permits `file.type` missing, but the handler ignores it. **NIT.**

**P9 — `meeting-store.ts` `saveMeeting` writes `minutes.md` without `fs.writeFileSync` `encoding` mode atomicity**
`writeFileSync` uses `{encoding:"utf8", mode:0o600}` but not atomic. A crash mid-write can leave a truncated minutes.md. Minutes data also lives in `minutes.json` (atomic) and the UI readback uses `minutes.json`, so this only affects the aux markdown file. **NIT** (pre-existing pattern).

**P10 — `meeting-handlers.ts` catches `saveMeeting` failure in generate path but already calls `saveMeeting(meeting)` before the LLM in a way that mutates meeting before the minutes in-flight lock**
`saveMeeting(meeting)` mutates `meeting` on the in-memory copy; `setMinutes` later rereads from disk. If `saveMeeting` succeeded but `setMinutes` later failed, the handler returns not_found and the LLM was already invoked, leaving status `generating` in memory until next reload. The exception path calls `setMeetingStatus(id, "error", ...)`, which writes a fresh loaded meeting and repairs status. **OK.**

**P11 — native `meetingWorkflow.ts` `captureFailure` does not clear `meetingCapture` on STT error; `meetingRetry` then cannot retry because `meetingCapture` remains non-null**
The actual `captureFailure`:
```
if(meetingCapture===s){teardownStt();sttSid="";stopRecClock();...}
```
It does **not** set `meetingCapture=null`. `meetingRetry`:
```
if(meetingCapture){await meetingCapture.queue.catch(...);...;meetingCapture=null}
```
So it does clear it on retry. **OK.**

**P12 — native `/api/meeting/reference/import` body read limit is `10 * 1024 * 1024` but `readBody` expects bytes; base64 7MiB file is 9.3MiB, fits; no overflow.**

**P13 — native `saveMeetingReference` persists reference notes but not a dirty-clean race**
If a user edits notes after save, `oninput` marks text but `meetingWorkBusy` is false. `requestMeetingMinutes` ends capture then saves reference. `saveMeetingReference` reads the textarea at call time; if a subsequent edit occurs during the save Promise, the old value is saved; fingerprint still matches saved reference and minutes are not marked stale because the UI text change sets live-panel state, not server fingerprint. This is a minor race inherent in all web forms; acceptable. **NIT.**

**P14 — `meeting-close.ts` `saveMeetingMaterials` with empty reference notes writes reference.json and then compares `saved.reference_notes !== referenceNotes`; if referenceNotes contains trailing whitespace, it is rejected, but clients send raw text. Fine.**

**P15 — Companion `meeting.generate_minutes` HTTP route in native UI uses `privacy_ack_v1: true` but the handler `meeting.generate_minutes` does not accept `privacy_ack_v1` for native. The route manually rejects body.privacy_ack_v1 !== true before dispatch, so the guard is in the native adapter. Extension route sends `privacy_ack_v1` too. OK.**

### Verdict on prior Grok REJECT

The specific P1 (default stop-and-generate vs `autoSegmentOnStop`) is fixed: `finalizeCapture` now sends `meeting.apply_silence_cut` with a real `meeting.updated` receipt, then `saveMeetingMaterials` writes with `silence_cut: false` but its result is the cut transcript. `sendMinutesJob` receives `wantSegment` and passes `silenceCut` into `saveMeetingMaterials`; the minutes job waits for the stored cut, then sends `meeting.generate_minutes` with `text: savedText` (the ACKed cut canonical text). The UI test explicitly holds `meeting.append_transcript`, `meeting.end`, `meeting.set_transcript`, and `meeting.set_reference`, and asserts `silence_cut` true and the generated `source_transcript` is the canonical cut. Prior P2 (`originalTranscript` not cleared) is fixed by `meeting.created` handler with `original_transcript || []`. Prior P2 (import error) is fixed with explicit `保存转写` error copy. Remaining prior `NIT` are addressed or are explicitly not part of the required contract.

### Tests evidence

- Extension unit suite: 1339/1339 pass, no failures.
- Companion final chunk: 20/20 tests pass (this log only captures the settings-web/CLI suite, but it is real and green).
- Real component/browser flows: plugin 11 passes; native 9 passes; close/navigation 7 passes.
- Real WAV decode, real DOCX parse, corrupt DOCX recovery, actual Chrome fake microphone through real PCM, two native drop/retry modes all pass.
- `meeting-reference-routing-492.test.ts` and `meeting-segment-idempotency-492.test.ts` cover validator and handler idempotency.
- One early old-test environment incident is disclosed in audit; no user data read.

### Concern about requiring source

I have concretely identified one remaining correctness issue:

**P1 — `MeetingPanel.tsx` `useEffect(() => { if (minutesMd) setMinutesStale(true) }, [transcript, referenceNotes, templateMd])` with `minutesMd` not in deps**
The effect sets stale true after any transcript/reference/template change when minutes exist. It does not depend on `minutesMd`, but React will warn/possibly run with a stale `minutesMd` in a future render. This is not functionally wrong here because `minutesMd` is always current from the same render, albeit hook lint says missing. Not block.

**P1 real — `MeetingPanel.tsx` native `minutesResult` correlation**
`minutesRequestRef` is set to a request id `meeting-minutes-<uuid>` and the handler returns `meeting.minutes_result` with that id. `onMsg` matches `msg.id !== request.id`. The HTTP/SSE duplicate delivery in native fixture did not corrupt. OK.

I cannot substantiate any P1 or P2 with actual severity that warrants REJECT. There are only small NITs.

**VERDICT: APPROVE_WITH_NITS**
## Machine companion-tests-delta.log
# tests 5078
# pass 5055
# fail 0
# skipped 23
# tests 20
# pass 20
# fail 0
# skipped 0
```
      ---
      duration_ms: 1.676
      type: 'test'
      ...
    # Subtest: POST /api/test with DNS failure → fail-closed (blocked)
    ok 9 - POST /api/test with DNS failure → fail-closed (blocked)
      ---
      duration_ms: 0.581333
      type: 'test'
      ...
    # Subtest: POST /api/test hostname resolving to IMDS uses metadata copy (not DNS copy)
    ok 10 - POST /api/test hostname resolving to IMDS uses metadata copy (not DNS copy)
      ---
      duration_ms: 0.45375
      type: 'test'
      ...
    # Subtest: POST /api/test trailing-dot localhost hits allowlist (not DNS)
    ok 11 - POST /api/test trailing-dot localhost hits allowlist (not DNS)
      ---
      duration_ms: 8.790291
      type: 'test'
      ...
    # Subtest: POST /api/test with RFC1918 IP is not SSRF-blocked
    ok 12 - POST /api/test with RFC1918 IP is not SSRF-blocked
      ---
      duration_ms: 0.675
      type: 'test'
      ...
    # Subtest: POST /api/test with loopback IP tries connect (not Internal/private copy)
    ok 13 - POST /api/test with loopback IP tries connect (not Internal/private copy)
      ---
      duration_ms: 2.381125
      type: 'test'
      ...
    # Subtest: POST /api/testVision allowlisted public host resolving to IMDS is blocked
    ok 14 - POST /api/testVision allowlisted public host resolving to IMDS is blocked
      ---
      duration_ms: 0.420291
      type: 'test'
      ...
    # Subtest: POST /api/testVision with allowlisted localhost → tries fetch (connection fail ok)
    ok 15 - POST /api/testVision with allowlisted localhost → tries fetch (connection fail ok)
      ---
      duration_ms: 1.565459
      type: 'test'
      ...
✅ api_key 已更新
    # Subtest: POST /api/testVision with AWS metadata IP → SSRF blocked
✅ api_key 已更新
    ok 16 - POST /api/testVision with AWS metadata IP → SSRF blocked
      ---
      duration_ms: 0.353583
      type: 'test'
      ...
    1..16
ok 1 - settings-web server
  ---
  duration_ms: 29.726375
  type: 'suite'
  ...
# Subtest: settings-cli
    # Subtest: settings-cli: --set api_key=sk-... exits non-zero (argv leak)
    ok 1 - settings-cli: --set api_key=sk-... exits non-zero (argv leak)
      ---
      duration_ms: 0.501625
      type: 'test'
      ...
    # Subtest: settings-cli: --set-stdin api_key reads value from stdin
    ok 2 - settings-cli: --set-stdin api_key reads value from stdin
      ---
      duration_ms: 0.86375
      type: 'test'
      ...
    # Subtest: settings-cli: CMSPARK_API_KEY env var is accepted for --set-stdin
    ok 3 - settings-cli: CMSPARK_API_KEY env var is accepted for --set-stdin
      ---
      duration_ms: 0.419084
      type: 'test'
      ...
    # Subtest: settings-cli: non-sensitive --set still works (model_name)
    ok 4 - settings-cli: non-sensitive --set still works (model_name)
      ---
      duration_ms: 0.255458
      type: 'test'
      ...
    1..4
ok 2 - settings-cli
  ---
  duration_ms: 2.101875
  type: 'suite'
  ...
1..2
# tests 20
# suites 2
# pass 20
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 50.26325
```

## Machine companion-build-delta.log

```

> cmspark-agent@0.6.7 prebuild
> node scripts/generate-tray-icons.mjs

Connection tray icons generated (32px PNG, 16/32/48 ICO).

> cmspark-agent@0.6.7 build
> tsc && node -e "const fs=require('fs'),p=require('path');fs.mkdirSync('dist/computer',{recursive:true});fs.copyFileSync('src/computer/qwen-vl-worker.py','dist/computer/qwen-vl-worker.py');process.platform!=='win32'&&fs.chmodSync('dist/index.js',0o755)"

```

## Machine ui-native-delta.log

```
PASS native raw immediate, SSE/HTTP dedup, append ACK → end ACK → explicit minutes
PASS native generation failure preserves materials
PASS native md/docx production parser and saved reference; no automatic model
PASS native real WAV decode/import appends to existing raw text without generation
PASS native failed audio import keeps prior materials
PASS native before_send append failure → retry → end → generation; no duplicate or lost materials
PASS native after_commit append failure → retry → end → generation; no duplicate or lost materials
PASS native partial_write append failure → retry → end → generation; no duplicate or lost materials
PASS native import-first materials preserve notes, require explicit audio consent, and generate only on click
PASS native 390/960 layouts, no page errors or external requests
```

## Source hashes
{
  "companion/scripts/serve-summoner-meeting-fixture.cjs": "bfd7d83720e00238df290b8415a6018607c184ee2e559a31c29e1ffac53b0247",
  "companion/scripts/test-summoner-meeting-ui.py": "5aac1ea4f3ea7cec46efb37831d62293e671cb2e75186f22ad75c4621a99d151",
  "companion/src/summoner-web.ts": "b32434b83400ea9ddf1b925245bbdbe92b3b51c605a568af6532a022a682173f",
  "companion/src/summoner/meeting-workflow.ts": "fe983d1bff09bfc010d0dafe3cc84994cb1de3812ab3f6cf51e67566ac13a694",
  "companion/tests/summoner-meeting-492.test.ts": "eef22509ad2f0bf067ad035f6f15e0536ba9d178e1f667d518b7b96292e2ba6d"
}