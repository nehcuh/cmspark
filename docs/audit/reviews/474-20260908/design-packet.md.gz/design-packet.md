Independent design review #474. Read only this packet, no other reports, no edits. Assess product clarity, small icon legibility, state correctness, accessibility, build portability. P0/P1/MAJOR/NIT and VERDICT APPROVE/APPROVE_WITH_NITS/REJECT. Max 700 words. User explicitly requested green running/red stopped/no adjacent CMspark Agent running label and authorized icon redesign. T2 visual only.
# 清晰连接图标与托盘状态

GitHub: #474 · 2026-09-08

沿用用户认可的简洁聊天风格。品牌含义为多系统信息汇聚到一个工作入口：三个端点连接中心的四角 spark，24×24 几何网格，粗线、少节点，无光晕、噪声和纹理。扩展使用透明底绿色标记；应用图标以深色圆角底承托同一标记；托盘透明底按状态着色，Swift 原生按目标分辨率绘制，兼容托盘生成 16/32/48 PNG/ICO。

绿色表示 Companion 运行，红色已停止，黄色检测中/未知。WebSocket 是独立连接状态，继续放状态详情，不把断开 WS 等同停止进程。菜单栏不显示状态标题，菜单不重复 Agent 状态头。悬浮 tooltip、VoiceOver label 和状态详情保留文本用于准确识别及色觉差异，状态未知不再写成已停止。所有启动/停止/重启处理器保持原绑定。

单一 JS 几何/PNG 导出模块供扩展与兼容托盘构建复用，输出 SVG 作为可审计矢量资产；Swift 使用同一24网格原生路径。验证导出尺寸/透明边界/状态色、16–32小尺寸明暗背景预览、Swift编译与实际离屏渲染、托盘标题为空而tooltip存在、菜单action映射不漂移。独立 Grok4.6 + DeepSeekV4Pro 设计/实现复审，机核绿后合并。不在此票执行安装替换。
