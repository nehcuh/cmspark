Independently review #474 final icon implementation and Windows completion. No other judge reports. User now explicitly asks actual Mac tray update AND Windows icon update. Prior reviews failed transport, not approvals. T2 visual + artifact integrity pin only; actual installation user-authorized, merge still needs valid dual review. Give VERDICT and actionable P0/P1/MAJOR/NIT <=600words. Code from frozen core below plus exact current Windows supplement (supplement supersedes old generator): new application ICO16/24/32/48/64/128/256, desktop/start menu already reference cmspark.ico, installer/uninstaller MUI and registry DisplayIcon now wired, staging must include all ICOs. Machine131 package tests PASS; makensis compiled actual ICO; native+JS18cases IoU.894 and core suites/builds passed; current macOS package build in progress, Windows native build not yet claimed. This is code gate, not approval that installation happened. No startup/shutdown/permission policy changes.
Independently review final #474 code. Full previous transport attempts failed, not approvals. No other judge reports. Max400 words. P0/P1/MAJOR/NIT + final VERDICT APPROVE/APPROVE_WITH_NITS/REJECT. User authorized clearer icon, green running/red stopped and removing adjacent redundant status text. T2 visual only; integrity pin updated to actual compiled binary, same fail-closed logic. Need green solid/red hollow/yellow unknown, tooltip+native AX, blank titles/no duplicate header, unchanged action bindings, static app/extension vs live tray. All actual tests/builds pass: ext production, comp4999pass/23skip+20aux, nativearm64 build, checkIntegrity true, PNG/ICO sizes; real Swift/JS18combinations minimumIoU.894, colors+alpha verified. Implementer inspected16/18/22/32light/dark and Retina preview; no installed tray/specific wallpaper guarantee, no app replacement. No need speculative state-machine expansion. All changed code is below: shared encoder retained from old generator; scripts consume shared module.


### FULL scripts/lib/brand-icon.mjs

import { deflateSync } from "node:zlib"
// CMspark: independent systems converge at one spark. 24-unit geometry, no blur.
export const BRAND_COLORS = { green: [22, 132, 93], red: [213, 67, 67], yellow: [182, 124, 24], template: [0, 0, 0] }
const endpoints = [[5, 5], [5, 19], [20, 12]]
function segmentDistance(x, y, ax, ay, bx, by) {
  const t = Math.max(0, Math.min(1, ((x-ax)*(bx-ax)+(y-ay)*(by-ay))/((bx-ax)**2+(by-ay)**2)))
  return Math.hypot(x-ax-t*(bx-ax), y-ay-t*(by-ay))
}
function insideMark(x, y) {
  return endpoints.some(([a,b]) => Math.hypot(x-a,y-b) <= 2.3 || segmentDistance(x,y,a,b,12,12) <= 1.15)
    || Math.abs(x-12)+Math.abs(y-12) <= 4.5
}
/** Coverage supersampling only at silhouette edges; interiors are solid color. */
export function renderMark(size, scheme = "green", tile = false) {
  const out = Buffer.alloc(size*size*4), samples = 4
  const mark = tile ? [76, 224, 170] : BRAND_COLORS[scheme]
  if (!mark) throw new Error("Unknown icon scheme")
  for (let py=0;py<size;py++) for(let px=0;px<size;px++) {
    let a=0,r=0,g=0,b=0
    for(let sy=0;sy<samples;sy++) for(let sx=0;sx<samples;sx++) {
      const x=(px+(sx+.5)/samples)*24/size,y=(py+(sy+.5)/samples)*24/size
      const mx=tile?(x-12)/.78+12:x,my=tile?(y-12)/.78+12:y
      let color = insideMark(mx,my) && !(scheme === "red" && Math.hypot(mx-12,my-12)<1.9) ? mark : null
      if (!color && tile) {
        const dx=Math.max(Math.abs(x-12)-6.5,0),dy=Math.max(Math.abs(y-12)-6.5,0)
        if (Math.hypot(dx,dy)<=4.5) color=[21,29,44]
      }
      if(color){a++;r+=color[0];g+=color[1];b+=color[2]}
    }
    const i=(py*size+px)*4
    if(a){out[i]=Math.round(r/a);out[i+1]=Math.round(g/a);out[i+2]=Math.round(b/a);out[i+3]=Math.round(a/(samples*samples)*255)}
  }
  return out
}
export function markSvg(color = "#16845d") {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${color}"><path d="M5 5 12 12 5 19M12 12H20" fill="none" stroke="${color}" stroke-width="2.3" stroke-linecap="round"/>${endpoints.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.3"/>`).join("")}<path d="m12 7.5 4.5 4.5-4.5 4.5L7.5 12Z"/></svg>
`
}
export function encodeICO(images) {
  const header=Buffer.alloc(6+16*images.length);header.writeUInt16LE(1,2);header.writeUInt16LE(images.length,4)
  let offset=header.length
  images.forEach(({size,png},i)=>{const p=6+i*16;header[p]=size===256?0:size;header[p+1]=header[p];header.writeUInt16LE(1,p+4);header.writeUInt16LE(32,p+6);header.writeUInt32LE(png.length,p+8);header.writeUInt32LE(offset,p+12);offset+=png.length})
  return Buffer.concat([header,...images.map(i=>i.png)])
}

export function encodePNG(width, height, rgbaPixels) {
  const scanlines = []
  for (let y = 0; y < height; y++) {
    const row = rgbaPixels.slice(y * width * 4, (y + 1) * width * 4)
    scanlines.push(Buffer.from([0]))  // filter: None
    scanlines.push(row)
  }
  const raw = Buffer.concat(scanlines)
  const compressed = deflateSync(raw, { level: 9 })

  const chunks = []
  chunks.push(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))

  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0)
  ihdr.writeUInt32BE(height, 4)
  ihdr.writeUInt8(8, 8)   // bit depth
  ihdr.writeUInt8(6, 9)   // RGBA
  chunks.push(pngChunk("IHDR", ihdr))
  chunks.push(pngChunk("IDAT", compressed))
  chunks.push(pngChunk("IEND", Buffer.alloc(0)))

  return Buffer.concat(chunks)
}

function pngChunk(type, data) {
  const t = Buffer.from(type, "ascii")
  const len = Buffer.alloc(4)
  len.writeUInt32BE(data.length)
  const crcBuf = Buffer.alloc(4)
  crcBuf.writeUInt32BE(crc32(Buffer.concat([t, data])) >>> 0)
  return Buffer.concat([len, t, data, crcBuf])
}

function crc32(buf) {
  let crc = 0xffffffff
  const table = new Int32Array(256)
  for (let i = 0; i < 256; i++) {
    let c = i
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1)
    table[i] = c
  }
  for (let i = 0; i < buf.length; i++) crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8)
  return (crc ^ 0xffffffff) >>> 0
}



### FULL chrome-extension/scripts/generate-icons.mjs

// Generate crisp extension and app icons from the shared CMspark geometry.
import { writeFileSync, mkdirSync, existsSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { renderMark, encodePNG, markSvg } from "../../scripts/lib/brand-icon.mjs"
const assetsDir = join(dirname(fileURLToPath(import.meta.url)), "..", "assets")
if (!existsSync(assetsDir)) mkdirSync(assetsDir, { recursive: true })

// Chrome extension icons (connection mark)
for (const size of [16, 32, 48, 64, 128]) {
  const pixels = renderMark(size, "green")
  const png = encodePNG(size, size, pixels)
  const out = join(assetsDir, `icon${size}.png`)
  writeFileSync(out, png)
  console.log(`  icon${size}.png (${png.length} bytes)`)
}

// Also write the base icon.png (128px master)
const master128 = encodePNG(128, 128, renderMark(128, "green"))
writeFileSync(join(assetsDir, "icon.png"), master128)
console.log(`  icon.png (${master128.length} bytes)`)

// Larger icons for macOS .icns (.iconset folder)
const iconsetDir = join(assetsDir, "CMspark.iconset")
if (!existsSync(iconsetDir)) mkdirSync(iconsetDir, { recursive: true })

const iconsetSizes = [
  [16, "icon_16x16.png"],
  [32, "icon_16x16@2x.png"],
  [32, "icon_32x32.png"],
  [64, "icon_32x32@2x.png"],
  [128, "icon_128x128.png"],
  [256, "icon_128x128@2x.png"],
  [256, "icon_256x256.png"],
  [512, "icon_256x256@2x.png"],
  [512, "icon_512x512.png"],
  [1024, "icon_512x512@2x.png"],
]
for (const [size, name] of iconsetSizes) {
  const png = encodePNG(size, size, renderMark(size, "green", true))
  writeFileSync(join(iconsetDir, name), png)
  console.log(`  ${name} (${png.length} bytes)`)
}

console.log("\nConnection icon generation complete!")

writeFileSync(join(assetsDir, "brand-mark.svg"), markSvg())


### FULL companion/scripts/generate-tray-icons.mjs

// Crisp state-colored connection marks; 1x/2x PNG and multi-size Windows ICO.
import { writeFileSync, mkdirSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { renderMark, encodePNG, encodeICO } from "../../scripts/lib/brand-icon.mjs"
const assetsDir=join(dirname(fileURLToPath(import.meta.url)), "..", "assets")
mkdirSync(assetsDir,{recursive:true})
for(const scheme of ["green","red","yellow","template"]) {
  const images=[16,32,48].map(size=>({size,png:encodePNG(size,size,renderMark(size,scheme))}))
  writeFileSync(join(assetsDir,`tray-icon-${scheme}.png`),images[1].png)
  writeFileSync(join(assetsDir,`tray-icon-${scheme}.ico`),encodeICO(images))
}
console.log("Connection tray icons generated (32px PNG, 16/32/48 ICO).")


### FULL companion/scripts/test-brand-rendering.py

"""macOS offscreen comparison of the production Swift path and shared JS exporter.
Run from repo root: uv run --no-project --with pillow python companion/scripts/test-brand-rendering.py
Does not launch tray or touch user configuration.
"""
from pathlib import Path
import subprocess,tempfile,json
from PIL import Image
root=Path(__file__).resolve().parents[2]
s=(root/'companion/src/tray/Tray.swift').read_text()
body=s[s.index('func makeStatusIcon('):s.index('// ---------------------------------------------------------------------------\n// Menu tag')]
with tempfile.TemporaryDirectory() as temp:
 out=Path(temp)
 swift='import AppKit\nenum CompanionStatus { case running, stopped, unknown }\n'+body+'''
let out = CommandLine.arguments[1]
for (name,status) in [("green",CompanionStatus.running),("red",.stopped),("yellow",.unknown)] {
 for size in [16,18,22,32,36,54] {
  let rep = NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:size,pixelsHigh:size,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
  NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep)
  makeStatusIcon(status,ws:false,size:NSSize(width:size,height:size)).draw(in:NSRect(x:0,y:0,width:size,height:size))
  NSGraphicsContext.restoreGraphicsState()
  try rep.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:"\\(out)/swift-\\(name)-\\(size).png"))
 }
}
'''
 (out/'render.swift').write_text(swift)
 subprocess.run(['swift',str(out/'render.swift'),str(out)],check=True)
 module=(root/'scripts/lib/brand-icon.mjs').as_uri()
 code=f'''import {{renderMark,encodePNG}} from {json.dumps(module)};import {{writeFileSync}} from 'node:fs';for(const color of ['green','red','yellow'])for(const size of [16,18,22,32,36,54])writeFileSync({json.dumps(str(out))}+`/js-${{color}}-${{size}}.png`,encodePNG(size,size,renderMark(size,color)))'''
 subprocess.run(['node','--input-type=module','-e',code],check=True)
 minimum=1
 for color in ['green','red','yellow']:
  for size in [16,18,22,32,36,54]:
   a=Image.open(out/f'swift-{color}-{size}.png').convert('RGBA');b=Image.open(out/f'js-{color}-{size}.png').convert('RGBA')
   assert a.size==b.size==(size,size)
   am=[p[3]>127 for p in a.getdata()];bm=[p[3]>127 for p in b.getdata()]
   iou=sum(x and y for x,y in zip(am,bm))/sum(x or y for x,y in zip(am,bm));minimum=min(minimum,iou)
   assert iou>=.85,(color,size,iou)
   assert a.getpixel((0,0))[3]==b.getpixel((0,0))[3]==0
   ac=a.getpixel((size//2,size//2));bc=b.getpixel((size//2,size//2))
   if color == 'red': assert max(ac[3],bc[3]) <= 32,(color,size,ac,bc)
   else: assert max(abs(x-y) for x,y in zip(ac,bc))<=2,(color,size,ac,bc)
   node=(round(size*5/24),round(size*5/24))
   assert max(abs(x-y) for x,y in zip(a.getpixel(node),b.getpixel(node)))<=2,(color,size,'node color')
 print(f'PASS: Swift/JS 18 combinations, silhouette IoU >= {minimum:.3f}; state color, dimensions, transparency verified.')


### FULL companion/tests/tray-status-474.test.ts

import test from "node:test"
import assert from "node:assert/strict"
import { SysTray2Adapter } from "../src/tray/systray2-bridge"

test("tray has no adjacent title and status changes preserve menu action routing", () => {
  const tray = new SysTray2Adapter() as any
  for (const [status, color, word] of [["running","green","运行中"],["stopped","red","已停止"],["unknown","yellow","状态未知"]]) {
    tray.status = status
    const menu = tray.buildMenu()
    assert.equal(menu.title, "")
    assert.ok(menu.tooltip.includes(word))
    assert.ok(menu.icon.includes(`tray-icon-${color}`))
    assert.equal(menu.isTemplateIcon, false)
    assert.equal(menu.items[0].title, "启动 Companion")
    assert.equal(menu.items[0].enabled, status !== "running")
    assert.equal(menu.items[1].enabled, status === "running")
    assert.equal(tray.seqMap[0].type, "start")
    assert.equal(tray.seqMap[1].type, "stop")
    assert.equal(tray.seqMap[2].type, "restart")
  }
})


### DIFF companion/src/tray/Tray.swift

diff --git a/companion/src/tray/Tray.swift b/companion/src/tray/Tray.swift
index fc9180d1..93eacd4a 100644
--- a/companion/src/tray/Tray.swift
+++ b/companion/src/tray/Tray.swift
@@ -88,42 +88,39 @@ var recentThreads: [RecentThread] = []
 // Icon generation (programmatic — no asset files needed)
 // ---------------------------------------------------------------------------
 
+// Same 24-unit geometry as scripts/lib/brand-icon.mjs, drawn at native backing scale.
 func makeStatusIcon(_ status: CompanionStatus, ws: Bool, size: NSSize = NSSize(width: 18, height: 18)) -> NSImage {
-  let image = NSImage(size: size)
-  image.lockFocus()
-
-  let fullRect = NSRect(origin: .zero, size: size)
-  let outer = NSBezierPath(ovalIn: fullRect.insetBy(dx: 2, dy: 2))
-
-  // Alpha-only fill — macOS tints for dark/light mode
-  let fillAlpha: CGFloat
+  let color: NSColor
   switch status {
-  case .running:  fillAlpha = 0.85
-  case .stopped:  fillAlpha = 0.45
-  case .unknown:  fillAlpha = 0.6
+  case .running: color = NSColor(srgbRed: 22/255, green: 132/255, blue: 93/255, alpha: 1)
+  case .stopped: color = NSColor(srgbRed: 213/255, green: 67/255, blue: 67/255, alpha: 1)
+  case .unknown: color = NSColor(srgbRed: 182/255, green: 124/255, blue: 24/255, alpha: 1)
   }
-
-  NSColor.white.withAlphaComponent(fillAlpha).setFill()
-  outer.fill()
-
-  NSColor.white.withAlphaComponent(0.3).setStroke()
-  outer.lineWidth = 0.5
-  outer.stroke()
-
-  // Inner dot when running + WS connected
-  if status == .running && ws {
-    let dotSize = NSSize(width: 6, height: 6)
-    let dotOrigin = NSPoint(
-      x: (size.width - dotSize.width) / 2,
-      y: (size.height - dotSize.height) / 2
-    )
-    let dot = NSBezierPath(ovalIn: NSRect(origin: dotOrigin, size: dotSize))
-    NSColor.white.withAlphaComponent(0.95).setFill()
-    dot.fill()
+  let image = NSImage(size: size, flipped: false) { rect in
+    NSGraphicsContext.saveGraphicsState()
+    defer { NSGraphicsContext.restoreGraphicsState() }
+    let transform = NSAffineTransform()
+    transform.translateX(by: rect.minX, yBy: rect.minY)
+    transform.scaleX(by: rect.width / 24, yBy: rect.height / 24)
+    transform.concat()
+    // A hollow center distinguishes stopped even without red/green perception.
+    if status == .stopped {
+      let clip = NSBezierPath(rect: NSRect(x: 0, y: 0, width: 24, height: 24))
+      clip.appendOval(in: NSRect(x: 10.1, y: 10.1, width: 3.8, height: 3.8))
+      clip.windingRule = .evenOdd; clip.addClip()
+    }
+    color.setStroke(); color.setFill()
+    for point in [NSPoint(x: 5, y: 5), NSPoint(x: 5, y: 19), NSPoint(x: 20, y: 12)] {
+      let line = NSBezierPath(); line.move(to: point); line.line(to: NSPoint(x: 12, y: 12))
+      line.lineWidth = 2.3; line.lineCapStyle = .round; line.stroke()
+      NSBezierPath(ovalIn: NSRect(x: point.x-2.3, y: point.y-2.3, width: 4.6, height: 4.6)).fill()
+    }
+    let spark = NSBezierPath()
+    spark.move(to: NSPoint(x: 12, y: 7.5)); spark.line(to: NSPoint(x: 16.5, y: 12))
+    spark.line(to: NSPoint(x: 12, y: 16.5)); spark.line(to: NSPoint(x: 7.5, y: 12)); spark.close(); spark.fill()
+    return true
   }
-
-  image.unlockFocus()
-  image.isTemplate = true
+  image.isTemplate = false // Preserve explicit run/stop colors in both menu-bar appearances.
   return image
 }
 
@@ -158,21 +155,6 @@ func buildMenu(target: AnyObject?, action: Selector?) -> NSMenu {
   let menu = NSMenu()
   let running = currentStatus == .running
 
-  // -- Header (non-interactive status display). Text carries the status (#396
-  // menu copy norm: no emoji as sole semantic carrier). --
-  let statusWord: String
-  switch currentStatus {
-  case .running:  statusWord = "运行中"
-  case .stopped:  statusWord = "已停止"
-  case .unknown:  statusWord = "状态未知"
-  }
-  let header = NSMenuItem(title: "CMspark Agent · \(statusWord)", action: nil, keyEquivalent: "")
-  header.tag = MenuTag.header.rawValue
-  header.isEnabled = false
-  menu.addItem(header)
-
-  menu.addItem(NSMenuItem.separator())
-
   // -- Start / Stop / Restart --
   let startItem = NSMenuItem(title: "启动 Companion", action: action, keyEquivalent: "s")
   startItem.target = target
@@ -198,7 +180,7 @@ func buildMenu(target: AnyObject?, action: Selector?) -> NSMenu {
   let statusMenuItem = NSMenuItem(title: "状态详情", action: nil, keyEquivalent: "")
   let statusMenu = NSMenu()
 
-  let compLabel = running ? "运行中" : "已停止"
+  let compLabel = currentStatus == .unknown ? "状态未知" : (running ? "运行中" : "已停止")
   statusMenu.addItem(makeInfoItem("Companion: \(compLabel)"))
 
   let wsLabel = wsConnected ? "已连接" : "未连接"
@@ -325,7 +307,9 @@ class TrayDelegate: NSObject {
 
     guard let button = statusItem?.button else { return }
     button.image = makeStatusIcon(currentStatus, ws: wsConnected)
+    button.title = ""
     button.toolTip = tooltipForStatus(currentStatus)
+    button.setAccessibilityLabel(tooltipForStatus(currentStatus))
 
     // Explicitly handle both left and right mouse clicks so the menu pops up
     // reliably on either button (macOS default only shows the menu on left-click).
@@ -351,7 +335,9 @@ class TrayDelegate: NSObject {
   func updateAppearance() {
     guard let button = statusItem?.button else { return }
     button.image = makeStatusIcon(currentStatus, ws: wsConnected)
+    button.title = ""
     button.toolTip = tooltipForStatus(currentStatus)
+    button.setAccessibilityLabel(tooltipForStatus(currentStatus))
   }
 
   @objc func menuAction(_ sender: NSMenuItem) {
@@ -404,9 +390,9 @@ class TrayDelegate: NSObject {
 
 private func tooltipForStatus(_ status: CompanionStatus) -> String {
   switch status {
-  case .running:  return "CMspark Agent — 运行中"
-  case .stopped:  return "CMspark Agent — 已停止"
-  case .unknown:  return "CMspark Agent — 检测中..."
+  case .running:  return "CMspark — 运行中"
+  case .stopped:  return "CMspark — 已停止"
+  case .unknown:  return "CMspark — 状态未知"
   }
 }
 


### DIFF companion/src/tray/systray2-bridge.ts

diff --git a/companion/src/tray/systray2-bridge.ts b/companion/src/tray/systray2-bridge.ts
index 7a238aad..c8df558e 100644
--- a/companion/src/tray/systray2-bridge.ts
+++ b/companion/src/tray/systray2-bridge.ts
@@ -53,9 +53,9 @@ function getIcon(status: string): string {
 
 function getTooltip(status: string): string {
   switch (status) {
-    case "running": return "CMspark Agent - 运行中"
-    case "stopped": return "CMspark Agent - 已停止"
-    default: return "CMspark Agent - 检测中..."
+    case "running": return "CMspark — 运行中"
+    case "stopped": return "CMspark — 已停止"
+    default: return "CMspark — 状态未知"
   }
 }
 
@@ -206,17 +206,6 @@ export class SysTray2Adapter implements UnifiedTray {
       this.seqMap.push(mapping)
     }
 
-    // Status header
-    const statusLabel = this.status === "running"
-      ? "[运行中] CMspark Agent"
-      : this.status === "stopped"
-        ? "[已停止] CMspark Agent"
-        : "[检测中] CMspark Agent"
-    push(statusLabel, { type: "status" }, { enabled: false })
-
-    items.push(SEP)
-    this.seqMap.push({ type: "status" })
-
     // Start / Stop / Restart
     push("启动 Companion", { type: "start" }, { enabled: !running })
     push("停止 Companion", { type: "stop" }, { enabled: running })
@@ -269,7 +258,7 @@ export class SysTray2Adapter implements UnifiedTray {
 
     return {
       icon: getIcon(this.status),
-      title: getTooltip(this.status),
+      title: "",
       tooltip: getTooltip(this.status),
       isTemplateIcon: false,
       items,


### DIFF companion/src/tray/swift-tray-bridge.ts

diff --git a/companion/src/tray/swift-tray-bridge.ts b/companion/src/tray/swift-tray-bridge.ts
index 57313193..d6532266 100644
--- a/companion/src/tray/swift-tray-bridge.ts
+++ b/companion/src/tray/swift-tray-bridge.ts
@@ -54,9 +54,9 @@ import {
 // ---------------------------------------------------------------------------
 
 /** Expected SHA256 of the Swift tray binary (update via build-tray.sh) */
-// Updated 2026-09-06 #433 P0 — SummonerOverlay command palette (NSTableView + 动效)
+// Updated 2026-09-08 #474 — native connection icon; local arm64 build-tray.sh output
 /** Mac 菜单/热键「召唤器」= HTML Capture 卡（与侧栏弹出对话框同一出口）。 */
-const SWIFT_TRAY_SHA256 = "af1d5d790242685826d315360087c490f68f3d235ed06d62bb3625a14ef7df91"
+const SWIFT_TRAY_SHA256 = "e184528cf908e639cca2ec63c596471a6fae2992f4e7e1dca400107810c14fbb"
 
 function getSwiftTrayBinPath(): string {
   const { getSwiftTrayPath } = require("../paths")


### DIFF companion/tests/tray-tokens-396.test.ts

diff --git a/companion/tests/tray-tokens-396.test.ts b/companion/tests/tray-tokens-396.test.ts
index f88e06ef..f0dcdc88 100644
--- a/companion/tests/tray-tokens-396.test.ts
+++ b/companion/tests/tray-tokens-396.test.ts
@@ -135,11 +135,11 @@ test("#396 behavior freeze: selectors, key equivalents, protocol, sanitization u
 
 test("#396 tray NSMenu copy carries semantics without emoji", () => {
   const menu = buildMenuBody()
-  // Header status is text
+  // #474: details retain text; the redundant status header is removed.
   for (const word of ["运行中", "已停止", "状态未知"]) {
     assert.ok(menu.includes(word), `status word ${word} missing`)
   }
-  assert.match(menu, /CMspark Agent · \\\(statusWord\)/)
+  assert.doesNotMatch(menu, /CMspark Agent/)
   // WS line text label
   assert.match(menu, /已连接/)
   assert.match(menu, /未连接/)


Integrity actual existing source: digest===SWIFT_TRAY_SHA256, mismatch throws before spawn; auto-compile only if binary missing. Pin=e184528cf908e639cca2ec63c596471a6fae2992f4e7e1dca400107810c14fbb from actual build; compiled checkIntegrity returnedtrue. No check disabled. Native source diff only icon, menu header, title/tooltip/AX and unknown detail. Existing raw enum .running/.stopped/.unknown unchanged.

### CURRENT companion/scripts/generate-tray-icons.mjs
// Crisp state-colored connection marks; 1x/2x PNG and multi-size Windows ICO.
import { writeFileSync, mkdirSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { renderMark, encodePNG, encodeICO } from "../../scripts/lib/brand-icon.mjs"
const assetsDir=join(dirname(fileURLToPath(import.meta.url)), "..", "assets")
mkdirSync(assetsDir,{recursive:true})
for(const scheme of ["green","red","yellow","template"]) {
  const images=[16,32,48].map(size=>({size,png:encodePNG(size,size,renderMark(size,scheme))}))
  writeFileSync(join(assetsDir,`tray-icon-${scheme}.png`),images[1].png)
  writeFileSync(join(assetsDir,`tray-icon-${scheme}.ico`),encodeICO(images))
}
console.log("Connection tray icons generated (32px PNG, 16/32/48 ICO).")

// Windows desktop/Start menu/installer: static brand, independent of live tray status.
const appImages=[16,24,32,48,64,128,256].map(size=>({size,png:encodePNG(size,size,renderMark(size,"green",true))}))
writeFileSync(join(assetsDir,"cmspark.ico"),encodeICO(appImages))

### CURRENT scripts/installer.nsi
; CMspark Windows Installer (NSIS)
; Official producer: scripts/build-windows-installer.sh
;   (called from scripts/package.sh windows-x64 after staging)
;   makensis -DPRODUCT_VERSION=x.y.z scripts/installer.nsi
; Manual: makensis -DPRODUCT_VERSION=x.y.z scripts/installer.nsi
; Requires: makensis (https://nsis.sourceforge.io/ or choco install nsis --version=3.12.0)
;
; Payload MUST be package.sh staging (node.exe + cmspark-agent.js).
; build-windows-exe.ps1 (SEA) must NOT emit this OutFile.

!define PRODUCT_NAME "CMspark"
; Prefer -DPRODUCT_VERSION= from build-windows-installer.sh; fallback must match companion/package.json.
!ifndef PRODUCT_VERSION
  !define PRODUCT_VERSION "0.6.6"
!endif
!define PRODUCT_PUBLISHER "CMspark"
!define PRODUCT_UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${PRODUCT_NAME}"

; Shared app icon for Setup and generated uninstaller.
!define MUI_ICON "..\companion\assets\cmspark.ico"
!define MUI_UNICON "..\companion\assets\cmspark.ico"

; Modern UI
!include "MUI2.nsh"
!include "FileFunc.nsh"

; Installer settings
Name "${PRODUCT_NAME} ${PRODUCT_VERSION}"
OutFile "..\dist-package\CMspark-Setup-v${PRODUCT_VERSION}.exe"
InstallDir "$LOCALAPPDATA\${PRODUCT_NAME}"
RequestExecutionLevel user
SetCompressor /SOLID lzma

; Variables
Var /GLOBAL START_MENU_FOLDER

; --- Pages ---
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_STARTMENU "StartMenu" $START_MENU_FOLDER
!insertmacro MUI_PAGE_INSTFILES

; Custom finish page
!define MUI_FINISHPAGE_TITLE "Installation Complete"
!define MUI_FINISHPAGE_TEXT "CMspark is now installed.$\r$\n$\r$\nTo use CMspark, load the Chrome extension:$\r$\n$\r$\n  1. Open Chrome and go to chrome://extensions$\r$\n  2. Enable 'Developer mode' (top-right)$\r$\n  3. Click 'Load unpacked'$\r$\n  4. Select: $INSTDIR\chrome-extension$\r$\n$\r$\nThen click the CMspark icon in the Chrome toolbar to open the Side Panel."
!define MUI_FINISHPAGE_LINK "Open chrome://extensions now"
!define MUI_FINISHPAGE_LINK_LOCATION "chrome://extensions"
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Start CMspark now (system tray)"
!define MUI_FINISHPAGE_RUN_FUNCTION "StartAgent"
!insertmacro MUI_PAGE_FINISH

; Uninstaller pages
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

; Stop tray + daemon whose ExecutablePath lives under $INSTDIR.
; `daemon stop` only kills daemon.pid - tray is a second node.exe.
; Do not use WMIC (removed/optional on Windows 11 24H2+).
; Quote rule (Claude dual-review B1, makensis 3.12 executed): NSIS does NOT
; treat '' as an escaped quote. Backtick strings may contain both ' and ".
; Residual nit: an apostrophe in $INSTDIR (username O'Brien) still breaks the
; PowerShell single-quoted GetFullPath; daemon stop + taskkill still run.
!macro StopInstalledAgentUnshared
  IfFileExists "$INSTDIR\node.exe" 0 +3
    nsExec::ExecToLog `"$INSTDIR\node.exe" "$INSTDIR\cmspark-agent.js" daemon stop`
    Sleep 200
  nsExec::ExecToLog `taskkill /F /IM cmspark-agent.exe`
  nsExec::ExecToLog `powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$$r = [IO.Path]::GetFullPath('$INSTDIR').TrimEnd('\') + '\'; Get-CimInstance Win32_Process | ForEach-Object { if ($$_.ExecutablePath -and $$_.ExecutablePath.StartsWith($$r, [StringComparison]::OrdinalIgnoreCase)) { Stop-Process -Id $$_.ProcessId -Force -ErrorAction SilentlyContinue } }"`
  Sleep 400
!macroend

Function StopInstalledAgent
  !insertmacro StopInstalledAgentUnshared
FunctionEnd

Function un.StopInstalledAgent
  !insertmacro StopInstalledAgentUnshared
FunctionEnd

; --- Install Section ---
Section "CMspark Agent" SecMain
  SectionIn RO

  Call StopInstalledAgent
  ; Leftover SEA from a previous local build must not stay (VBS prefers it).
  Delete "$INSTDIR\cmspark-agent.exe"

  SetOutPath "$INSTDIR"

  ; Trailing slash copies the complete tree, including extensionless files.
  File /r "..\dist-package\cmspark-windows-x64\"

  ; Write registry for Add/Remove Programs
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "DisplayName" "${PRODUCT_NAME}"
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "DisplayIcon" '"$INSTDIR\assets\cmspark.ico",0'
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "DisplayVersion" "${PRODUCT_VERSION}"
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "Publisher" "${PRODUCT_PUBLISHER}"
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${PRODUCT_UNINST_KEY}" "QuietUninstallString" '"$INSTDIR\uninstall.exe" /S'
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  IntFmt $0 "0x%08X" $0
  WriteRegDWORD HKCU "${PRODUCT_UNINST_KEY}" "EstimatedSize" "$0"

  ; Single autostart path - HKCU Run only (not also Startup folder).
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${PRODUCT_NAME}" 'wscript.exe "$INSTDIR\launch-hidden.vbs"'

  ; --- Shortcuts ---
  CreateShortCut "$DESKTOP\CMspark Agent.lnk" "wscript.exe" '"$INSTDIR\launch-hidden.vbs"' "$INSTDIR\assets\cmspark.ico" 0

  !insertmacro MUI_STARTMENU_WRITE_BEGIN "StartMenu"
    CreateDirectory "$SMPROGRAMS\$START_MENU_FOLDER"
    CreateShortCut "$SMPROGRAMS\$START_MENU_FOLDER\CMspark Agent.lnk" "wscript.exe" '"$INSTDIR\launch-hidden.vbs"' "$INSTDIR\assets\cmspark.ico" 0
    CreateShortCut "$SMPROGRAMS\$START_MENU_FOLDER\Uninstall CMspark.lnk" "$INSTDIR\uninstall.exe"
  !insertmacro MUI_STARTMENU_WRITE_END

  WriteUninstaller "$INSTDIR\uninstall.exe"
SectionEnd

; --- Uninstall Section ---
Section "Uninstall"
  Call un.StopInstalledAgent

  nsExec::ExecToLog 'schtasks /delete /tn "cmspark-companion" /f'

  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "${PRODUCT_NAME}"

  Delete "$DESKTOP\CMspark Agent.lnk"
  Delete "$SMSTARTUP\CMspark Agent.lnk"
  !insertmacro MUI_STARTMENU_GETFOLDER "StartMenu" $0
  Delete "$SMPROGRAMS\$0\CMspark Agent.lnk"
  Delete "$SMPROGRAMS\$0\Uninstall CMspark.lnk"
  RMDir "$SMPROGRAMS\$0"

  DeleteRegKey HKCU "${PRODUCT_UNINST_KEY}"

  RMDir /r "$INSTDIR"
SectionEnd

; --- Custom function: start tray agent ---
Function StartAgent
  Exec 'wscript.exe "$INSTDIR\launch-hidden.vbs"'
FunctionEnd

### CURRENT scripts/build-windows-installer.sh
diff --git a/scripts/build-windows-installer.sh b/scripts/build-windows-installer.sh
index db23b97f..64af4a16 100755
--- a/scripts/build-windows-installer.sh
+++ b/scripts/build-windows-installer.sh
@@ -86,7 +86,7 @@ if [ ! -d "${STAGING}" ]; then
 fi
 
 missing=0
-for rel in node.exe cmspark-agent.js launch-hidden.vbs chrome-extension; do
+for rel in node.exe cmspark-agent.js launch-hidden.vbs chrome-extension assets/cmspark.ico assets/tray-icon-green.ico assets/tray-icon-red.ico assets/tray-icon-yellow.ico; do
   if [ ! -e "${STAGING}/${rel}" ]; then
     echo "ERROR: official installer staging missing ${rel}" >&2
     missing=1

### CURRENT scripts/tests/test-package-gates.sh
diff --git a/scripts/tests/test-package-gates.sh b/scripts/tests/test-package-gates.sh
index e937d241..a7c186d4 100755
--- a/scripts/tests/test-package-gates.sh
+++ b/scripts/tests/test-package-gates.sh
@@ -321,7 +321,8 @@ if [ -x /usr/bin/true ] || [ -x /bin/true ]; then
   _TRUE="/usr/bin/true"
   [ -x "${_TRUE}" ] || _TRUE="/bin/true"
   _STAGE="$(mktemp -d "${TMPDIR:-/tmp}/cmspark-nsis-stage.XXXXXX")"
-  mkdir -p "${_STAGE}/chrome-extension"
+  mkdir -p "${_STAGE}/chrome-extension" "${_STAGE}/assets"
+  cp "${ROOT}/companion/assets/"*.ico "${_STAGE}/assets/"
   touch "${_STAGE}/node.exe" "${_STAGE}/cmspark-agent.js" "${_STAGE}/launch-hidden.vbs" "${_STAGE}/cmspark-agent.exe"
   set +e
   OUT_SEA="$(
@@ -342,6 +343,22 @@ else
   echo "  skip: no true(1) for fake makensis"
 fi
 
+echo "[dynamic] wrapper refuses a missing Windows application icon"
+_STAGE="$(mktemp -d "${TMPDIR:-/tmp}/cmspark-nsis-icon.XXXXXX")"
+mkdir -p "${_STAGE}/chrome-extension" "${_STAGE}/assets"
+touch "${_STAGE}/node.exe" "${_STAGE}/cmspark-agent.js" "${_STAGE}/launch-hidden.vbs"
+cp "${ROOT}/companion/assets/"tray-icon-*.ico "${_STAGE}/assets/"
+set +e
+OUT_ICON="$(CMSPARK_STAGING_DIR="${_STAGE}" CMSPARK_MAKENSIS="${_TRUE:-/usr/bin/true}" bash "${WIN_NSIS}" 2>&1)"
+RC_ICON=$?
+set -e
+rm -rf "${_STAGE}"
+if [ "${RC_ICON}" != "0" ] && echo "${OUT_ICON}" | grep -q 'assets/cmspark.ico'; then
+  PASS=$((PASS + 1))
+else
+  FAIL=$((FAIL + 1)); echo "  FAIL: missing application icon must fail before installer generation" >&2
+fi
+
 echo "[dynamic] missing makensis without REQUIRE → skip (exit 0)"
 set +e
 OUT_SKIP="$(

### CURRENT docs/superpowers/plans/2026-09-08-brand-icon-status.md
diff --git a/docs/superpowers/plans/2026-09-08-brand-icon-status.md b/docs/superpowers/plans/2026-09-08-brand-icon-status.md
index 89fa9686..93b8cd38 100644
--- a/docs/superpowers/plans/2026-09-08-brand-icon-status.md
+++ b/docs/superpowers/plans/2026-09-08-brand-icon-status.md
@@ -11,3 +11,7 @@ GitHub: #474 · 2026-09-08
 ## 设计复审落实
 
 仅托盘表达进程状态；扩展与应用图标是静态品牌。坐标契约固定端点 (5,5)/(5,19)/(20,12)，半径2.3，连接线宽2.3，中心菱形边界(12,7.5)/(16.5,12)/(12,16.5)/(7.5,12)。停止态中心额外挖空半径1.9，以轮廓补充颜色。颜色 sRGB green #16845d / red #d54343 / unknown #b67c18，原生 isTemplate=false。未知只有既有 unknown 枚举，统一说明“状态未知”，不伪称持续检测；本票不新增状态机/超时逻辑。Swift 与 JS 离屏轮廓交并比至少0.85，颜色/尺寸/透明边界一致；16/18/22/32 明暗预览必须人工检查。Swift AX name明确设置；保留 tooltip 与详情。任意壁纸对比不作未经验证的保证，当前明暗背景通过后可交付。
+
+## 安装验证补充（用户截图后）
+
+Windows官方NSIS安装路径：桌面/开始菜单引用 assets/cmspark.ico，必须由同一生成器生成16/24/32/48/64/128/256多尺寸应用ICO；安装器和卸载器使用该图标，已安装应用列表DisplayIcon显式绑定。三色托盘ICO独立保留。Windows打包前检查这些必需资产，不再悄悄产生缺图标的包。Mac本轮用户明确要求修正实际桌面显示，构建DMG并替换正在运行安装；不得用源码截图代替运行态验证。

NSIS proof: actual generated cmspark.ico successfully compiled into a PE with Icon and UninstallIcon directives. Final official Windows native package to be built with workflow_dispatch (release publish tag gate stays false).
