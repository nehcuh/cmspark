Independent implementation/design closure #474. Read only frozen packet, no other reports/edits. T2 visual, user requested green running/red stopped/remove adjacent CMspark Agent text and authorized redesigned icon. Requirements: native vector at backing scale, common JS export geometry; static app/extension vs live tray; unknown honestly unknown, don't invent new probing state; green solid / red hollow central spark offers shape cue; AX label+tooltip present; no visible tray title or duplicate menu header; command mappings unchanged. No app replacement. Return P0/P1/MAJOR/NIT and VERDICT APPROVE/APPROVE_WITH_NITS/REJECT. Max 900 words. Outcome/trajectory/components. Don't claim viewing unseen images: implementer visually inspected generated 16/18/22/32 light/dark preview and native Retina; not an actual installed tray screenshot. Cross-render pixel tests independently pin geometry. Design concerns close with actual implementation and tests below.


### scripts/lib/brand-icon.mjs

import { deflateSync } from "node:zlib"
// CMspark: independent systems converge at one spark. 24-unit geometry, no blur.
export const BRAND_COLORS = { green: [22, 132, 93], red: [213, 67, 67], yellow: [182, 124, 24], template: [0, 0, 0] }
const endpoints = [[5, 5], [5, 19], [20, 12]]
function segmentDistance(x, y, ax, ay, bx, by) {
  const t = Math.max(0, Math.min(1, ((x-ax)*(bx-ax)+(y-ay)*(by-ay))/((bx-ax)**2+(by-ay)**2)))
  return Math.hypot(x-ax-t*(bx-ax), y-ay-t*(by-ay))
}
function insideMark(x, y) {
  return endpoints.some(([a,b]) => Math.hypot(x-a,y-b) <= 2.3 || segmentDistance(x,y,a,b,12,12) <= 1.15)
    || Math.abs(x-12)+Math.abs(y-12) <= 4.5
}
/** Coverage supersampling only at silhouette edges; interiors are solid color. */
export function renderMark(size, scheme = "green", tile = false) {
  const out = Buffer.alloc(size*size*4), samples = 4
  const mark = tile ? [76, 224, 170] : BRAND_COLORS[scheme]
  if (!mark) throw new Error("Unknown icon scheme")
  for (let py=0;py<size;py++) for(let px=0;px<size;px++) {
    let a=0,r=0,g=0,b=0
    for(let sy=0;sy<samples;sy++) for(let sx=0;sx<samples;sx++) {
      const x=(px+(sx+.5)/samples)*24/size,y=(py+(sy+.5)/samples)*24/size
      const mx=tile?(x-12)/.78+12:x,my=tile?(y-12)/.78+12:y
      let color = insideMark(mx,my) && !(scheme === "red" && Math.hypot(mx-12,my-12)<1.9) ? mark : null
      if (!color && tile) {
        const dx=Math.max(Math.abs(x-12)-6.5,0),dy=Math.max(Math.abs(y-12)-6.5,0)
        if (Math.hypot(dx,dy)<=4.5) color=[21,29,44]
      }
      if(color){a++;r+=color[0];g+=color[1];b+=color[2]}
    }
    const i=(py*size+px)*4
    if(a){out[i]=Math.round(r/a);out[i+1]=Math.round(g/a);out[i+2]=Math.round(b/a);out[i+3]=Math.round(a/(samples*samples)*255)}
  }
  return out
}
export function markSvg(color = "#16845d") {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${color}"><path d="M5 5 12 12 5 19M12 12H20" fill="none" stroke="${color}" stroke-width="2.3" stroke-linecap="round"/>${endpoints.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.3"/>`).join("")}<path d="m12 7.5 4.5 4.5-4.5 4.5L7.5 12Z"/></svg>
`
}
export function encodeICO(images) {
  const header=Buffer.alloc(6+16*images.length);header.writeUInt16LE(1,2);header.writeUInt16LE(images.length,4)
  let offset=header.length
  images.forEach(({size,png},i)=>{const p=6+i*16;header[p]=size===256?0:size;header[p+1]=header[p];header.writeUInt16LE(1,p+4);header.writeUInt16LE(32,p+6);header.writeUInt32LE(png.length,p+8);header.writeUInt32LE(offset,p+12);offset+=png.length})
  return Buffer.concat([header,...images.map(i=>i.png)])
}

export function encodePNG(width, height, rgbaPixels) {
  const scanlines = []
  for (let y = 0; y < height; y++) {
    const row = rgbaPixels.slice(y * width * 4, (y + 1) * width * 4)
    scanlines.push(Buffer.from([0]))  // filter: None
    scanlines.push(row)
  }
  const raw = Buffer.concat(scanlines)
  const compressed = deflateSync(raw, { level: 9 })

  const chunks = []
  chunks.push(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))

  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0)
  ihdr.writeUInt32BE(height, 4)
  ihdr.writeUInt8(8, 8)   // bit depth
  ihdr.writeUInt8(6, 9)   // RGBA
  chunks.push(pngChunk("IHDR", ihdr))
  chunks.push(pngChunk("IDAT", compressed))
  chunks.push(pngChunk("IEND", Buffer.alloc(0)))

  return Buffer.concat(chunks)
}

function pngChunk(type, data) {
  const t = Buffer.from(type, "ascii")
  const len = Buffer.alloc(4)
  len.writeUInt32BE(data.length)
  const crcBuf = Buffer.alloc(4)
  crcBuf.writeUInt32BE(crc32(Buffer.concat([t, data])) >>> 0)
  return Buffer.concat([len, t, data, crcBuf])
}

function crc32(buf) {
  let crc = 0xffffffff
  const table = new Int32Array(256)
  for (let i = 0; i < 256; i++) {
    let c = i
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1)
    table[i] = c
  }
  for (let i = 0; i < buf.length; i++) crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8)
  return (crc ^ 0xffffffff) >>> 0
}



### chrome-extension/scripts/generate-icons.mjs

// Generate crisp extension and app icons from the shared CMspark geometry.
import { writeFileSync, mkdirSync, existsSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { renderMark, encodePNG, markSvg } from "../../scripts/lib/brand-icon.mjs"
const assetsDir = join(dirname(fileURLToPath(import.meta.url)), "..", "assets")
if (!existsSync(assetsDir)) mkdirSync(assetsDir, { recursive: true })

// Chrome extension icons (connection mark)
for (const size of [16, 32, 48, 64, 128]) {
  const pixels = renderMark(size, "green")
  const png = encodePNG(size, size, pixels)
  const out = join(assetsDir, `icon${size}.png`)
  writeFileSync(out, png)
  console.log(`  icon${size}.png (${png.length} bytes)`)
}

// Also write the base icon.png (128px master)
const master128 = encodePNG(128, 128, renderMark(128, "green"))
writeFileSync(join(assetsDir, "icon.png"), master128)
console.log(`  icon.png (${master128.length} bytes)`)

// Larger icons for macOS .icns (.iconset folder)
const iconsetDir = join(assetsDir, "CMspark.iconset")
if (!existsSync(iconsetDir)) mkdirSync(iconsetDir, { recursive: true })

const iconsetSizes = [
  [16, "icon_16x16.png"],
  [32, "icon_16x16@2x.png"],
  [32, "icon_32x32.png"],
  [64, "icon_32x32@2x.png"],
  [128, "icon_128x128.png"],
  [256, "icon_128x128@2x.png"],
  [256, "icon_256x256.png"],
  [512, "icon_256x256@2x.png"],
  [512, "icon_512x512.png"],
  [1024, "icon_512x512@2x.png"],
]
for (const [size, name] of iconsetSizes) {
  const png = encodePNG(size, size, renderMark(size, "green", true))
  writeFileSync(join(iconsetDir, name), png)
  console.log(`  ${name} (${png.length} bytes)`)
}

console.log("\nConnection icon generation complete!")

writeFileSync(join(assetsDir, "brand-mark.svg"), markSvg())


### companion/scripts/generate-tray-icons.mjs

// Crisp state-colored connection marks; 1x/2x PNG and multi-size Windows ICO.
import { writeFileSync, mkdirSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { renderMark, encodePNG, encodeICO } from "../../scripts/lib/brand-icon.mjs"
const assetsDir=join(dirname(fileURLToPath(import.meta.url)), "..", "assets")
mkdirSync(assetsDir,{recursive:true})
for(const scheme of ["green","red","yellow","template"]) {
  const images=[16,32,48].map(size=>({size,png:encodePNG(size,size,renderMark(size,scheme))}))
  writeFileSync(join(assetsDir,`tray-icon-${scheme}.png`),images[1].png)
  writeFileSync(join(assetsDir,`tray-icon-${scheme}.ico`),encodeICO(images))
}
console.log("Connection tray icons generated (32px PNG, 16/32/48 ICO).")


### companion/src/tray/Tray.swift

diff --git a/companion/src/tray/Tray.swift b/companion/src/tray/Tray.swift
index fc9180d1..93eacd4a 100644
--- a/companion/src/tray/Tray.swift
+++ b/companion/src/tray/Tray.swift
@@ -88,42 +88,39 @@ var recentThreads: [RecentThread] = []
 // Icon generation (programmatic — no asset files needed)
 // ---------------------------------------------------------------------------
 
+// Same 24-unit geometry as scripts/lib/brand-icon.mjs, drawn at native backing scale.
 func makeStatusIcon(_ status: CompanionStatus, ws: Bool, size: NSSize = NSSize(width: 18, height: 18)) -> NSImage {
-  let image = NSImage(size: size)
-  image.lockFocus()
-
-  let fullRect = NSRect(origin: .zero, size: size)
-  let outer = NSBezierPath(ovalIn: fullRect.insetBy(dx: 2, dy: 2))
-
-  // Alpha-only fill — macOS tints for dark/light mode
-  let fillAlpha: CGFloat
+  let color: NSColor
   switch status {
-  case .running:  fillAlpha = 0.85
-  case .stopped:  fillAlpha = 0.45
-  case .unknown:  fillAlpha = 0.6
+  case .running: color = NSColor(srgbRed: 22/255, green: 132/255, blue: 93/255, alpha: 1)
+  case .stopped: color = NSColor(srgbRed: 213/255, green: 67/255, blue: 67/255, alpha: 1)
+  case .unknown: color = NSColor(srgbRed: 182/255, green: 124/255, blue: 24/255, alpha: 1)
   }
-
-  NSColor.white.withAlphaComponent(fillAlpha).setFill()
-  outer.fill()
-
-  NSColor.white.withAlphaComponent(0.3).setStroke()
-  outer.lineWidth = 0.5
-  outer.stroke()
-
-  // Inner dot when running + WS connected
-  if status == .running && ws {
-    let dotSize = NSSize(width: 6, height: 6)
-    let dotOrigin = NSPoint(
-      x: (size.width - dotSize.width) / 2,
-      y: (size.height - dotSize.height) / 2
-    )
-    let dot = NSBezierPath(ovalIn: NSRect(origin: dotOrigin, size: dotSize))
-    NSColor.white.withAlphaComponent(0.95).setFill()
-    dot.fill()
+  let image = NSImage(size: size, flipped: false) { rect in
+    NSGraphicsContext.saveGraphicsState()
+    defer { NSGraphicsContext.restoreGraphicsState() }
+    let transform = NSAffineTransform()
+    transform.translateX(by: rect.minX, yBy: rect.minY)
+    transform.scaleX(by: rect.width / 24, yBy: rect.height / 24)
+    transform.concat()
+    // A hollow center distinguishes stopped even without red/green perception.
+    if status == .stopped {
+      let clip = NSBezierPath(rect: NSRect(x: 0, y: 0, width: 24, height: 24))
+      clip.appendOval(in: NSRect(x: 10.1, y: 10.1, width: 3.8, height: 3.8))
+      clip.windingRule = .evenOdd; clip.addClip()
+    }
+    color.setStroke(); color.setFill()
+    for point in [NSPoint(x: 5, y: 5), NSPoint(x: 5, y: 19), NSPoint(x: 20, y: 12)] {
+      let line = NSBezierPath(); line.move(to: point); line.line(to: NSPoint(x: 12, y: 12))
+      line.lineWidth = 2.3; line.lineCapStyle = .round; line.stroke()
+      NSBezierPath(ovalIn: NSRect(x: point.x-2.3, y: point.y-2.3, width: 4.6, height: 4.6)).fill()
+    }
+    let spark = NSBezierPath()
+    spark.move(to: NSPoint(x: 12, y: 7.5)); spark.line(to: NSPoint(x: 16.5, y: 12))
+    spark.line(to: NSPoint(x: 12, y: 16.5)); spark.line(to: NSPoint(x: 7.5, y: 12)); spark.close(); spark.fill()
+    return true
   }
-
-  image.unlockFocus()
-  image.isTemplate = true
+  image.isTemplate = false // Preserve explicit run/stop colors in both menu-bar appearances.
   return image
 }
 
@@ -158,21 +155,6 @@ func buildMenu(target: AnyObject?, action: Selector?) -> NSMenu {
   let menu = NSMenu()
   let running = currentStatus == .running
 
-  // -- Header (non-interactive status display). Text carries the status (#396
-  // menu copy norm: no emoji as sole semantic carrier). --
-  let statusWord: String
-  switch currentStatus {
-  case .running:  statusWord = "运行中"
-  case .stopped:  statusWord = "已停止"
-  case .unknown:  statusWord = "状态未知"
-  }
-  let header = NSMenuItem(title: "CMspark Agent · \(statusWord)", action: nil, keyEquivalent: "")
-  header.tag = MenuTag.header.rawValue
-  header.isEnabled = false
-  menu.addItem(header)
-
-  menu.addItem(NSMenuItem.separator())
-
   // -- Start / Stop / Restart --
   let startItem = NSMenuItem(title: "启动 Companion", action: action, keyEquivalent: "s")
   startItem.target = target
@@ -198,7 +180,7 @@ func buildMenu(target: AnyObject?, action: Selector?) -> NSMenu {
   let statusMenuItem = NSMenuItem(title: "状态详情", action: nil, keyEquivalent: "")
   let statusMenu = NSMenu()
 
-  let compLabel = running ? "运行中" : "已停止"
+  let compLabel = currentStatus == .unknown ? "状态未知" : (running ? "运行中" : "已停止")
   statusMenu.addItem(makeInfoItem("Companion: \(compLabel)"))
 
   let wsLabel = wsConnected ? "已连接" : "未连接"
@@ -325,7 +307,9 @@ class TrayDelegate: NSObject {
 
     guard let button = statusItem?.button else { return }
     button.image = makeStatusIcon(currentStatus, ws: wsConnected)
+    button.title = ""
     button.toolTip = tooltipForStatus(currentStatus)
+    button.setAccessibilityLabel(tooltipForStatus(currentStatus))
 
     // Explicitly handle both left and right mouse clicks so the menu pops up
     // reliably on either button (macOS default only shows the menu on left-click).
@@ -351,7 +335,9 @@ class TrayDelegate: NSObject {
   func updateAppearance() {
     guard let button = statusItem?.button else { return }
     button.image = makeStatusIcon(currentStatus, ws: wsConnected)
+    button.title = ""
     button.toolTip = tooltipForStatus(currentStatus)
+    button.setAccessibilityLabel(tooltipForStatus(currentStatus))
   }
 
   @objc func menuAction(_ sender: NSMenuItem) {
@@ -404,9 +390,9 @@ class TrayDelegate: NSObject {
 
 private func tooltipForStatus(_ status: CompanionStatus) -> String {
   switch status {
-  case .running:  return "CMspark Agent — 运行中"
-  case .stopped:  return "CMspark Agent — 已停止"
-  case .unknown:  return "CMspark Agent — 检测中..."
+  case .running:  return "CMspark — 运行中"
+  case .stopped:  return "CMspark — 已停止"
+  case .unknown:  return "CMspark — 状态未知"
   }
 }
 


### companion/src/tray/systray2-bridge.ts

// SysTray2 Bridge — manages the systray2 cross-platform tray
//
// systray2 does not support submenus, so Quick Actions and Recent Threads
// are rendered as flat items with emoji prefixes and separator dividers.

import * as path from "path"
import * as fs from "fs"

import {
  UnifiedTray,
  TrayConfig,
  TrayMenuAction,
  TrayDataProvider,
  QuickActionItem,
  RecentThreadItem,
} from "./tray-adapter"

// ---------------------------------------------------------------------------
// Icon loading (base64 for systray2) — ICO → PNG → inline fallback
// ---------------------------------------------------------------------------

const FALLBACK_ICON = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="

// systray2's resolveIcon() calls fs.pathExists() on the icon value —
// if it's a file path it reads & base64-encodes it, otherwise it's skipped.
// On Windows we MUST pass the file path; raw base64 is silently ignored.
function resolveIconPath(name: string): string {
  try {
    const { getAssetsDir } = require("../paths")
    const iconPath = path.join(getAssetsDir(), name)
    if (fs.existsSync(iconPath)) return iconPath
  } catch { /* fall through */ }
  console.warn(`[systray2] Icon file not found: ${name}, using fallback`)
  return FALLBACK_ICON
}

function getPlatformIconFile(status: string): string {
  if (process.platform === "win32") {
    return resolveIconPath(`tray-icon-${status}.ico`)
  }
  return resolveIconPath(`tray-icon-${status}.png`)
}

const SEP = { title: "---" }

function getIcon(status: string): string {
  switch (status) {
    case "running": return getPlatformIconFile("green")
    case "stopped": return getPlatformIconFile("red")
    default: return getPlatformIconFile("yellow")
  }
}

function getTooltip(status: string): string {
  switch (status) {
    case "running": return "CMspark — 运行中"
    case "stopped": return "CMspark — 已停止"
    default: return "CMspark — 状态未知"
  }
}

// ---------------------------------------------------------------------------
// SysTray2Adapter
// ---------------------------------------------------------------------------

export class SysTray2Adapter implements UnifiedTray {
  private systray: any = null
  private actionCallback: ((action: TrayMenuAction) => void) | null = null
  private dataProvider: TrayDataProvider | null = null
  private shuttingDown = false

  // Cached state
  private status: string = "unknown"
  private autostartEnabled = false
  private quickActions: QuickActionItem[] = []
  private recentThreads: RecentThreadItem[] = []

  // seq_id → action mapping (rebuilt each time menu is constructed)
  private seqMap: TrayMenuAction[] = []

  // Debounce rebuild to avoid rapid kill/recreate cycles
  private rebuildTimer: ReturnType<typeof setTimeout> | null = null

  // --- UnifiedTray ---

  async start(_config: TrayConfig): Promise<void> {
    const Tray = this.loadModule()
    const menu = this.buildMenu()

    const instance = new Tray({ menu, debug: !!process.env.CMSPARK_DEBUG, copyDir: true })
    await instance.ready()
    console.log("[tray] Started with systray2 backend")
    console.log("[tray] Platform:", process.platform, "Arch:", process.arch)

    instance.onClick((action: any) => {
      const seqId = action?.seq_id
      console.log("[systray2] onClick seq_id:", seqId, "seqMap length:", this.seqMap.length)
      if (typeof seqId !== "number" || seqId < 0 || seqId >= this.seqMap.length) {
        console.error("[systray2] Invalid seq_id:", seqId, "seqMap length:", this.seqMap.length)
        return
      }
      const mapped = this.seqMap[seqId]
      console.log("[systray2] Mapped action:", mapped?.type)
      if (mapped && this.actionCallback) {
        this.actionCallback(mapped)
      }
      if (mapped?.type === "quit") {
        this.shuttingDown = true
        // kill(false): let handleAction('quit') call process.exit(0) explicitly,
        // don't let systray2 do it — that would skip our cleanup.
        instance.kill(false).catch(() => {})
      }
    })

    instance.onExit(() => {
      this.systray = null
      if (this.shuttingDown) return
      console.warn("[systray2] Tray process exited unexpectedly, attempting restart in 3s...")
      setTimeout(async () => {
        if (this.shuttingDown) return
        try {
          await this.start({} as TrayConfig)
          console.log("[systray2] Tray restarted successfully")
        } catch (err: any) {
          console.error("[systray2] Tray restart failed:", err.message)
        }
      }, 3000)
    })

    instance.onError((err: any) => console.error("[systray2] Error:", err))
    this.systray = instance
  }

  updateStatus(status: "running" | "stopped" | "unknown", _wsConnected: boolean, _pid: number | null): void {
    if (this.status === status) return
    this.status = status
    this.rebuild()
  }

  updateAutostart(enabled: boolean): void {
    if (this.autostartEnabled === enabled) return
    this.autostartEnabled = enabled
    this.rebuild()
  }

  setQuickActions(actions: QuickActionItem[]): void {
    if (JSON.stringify(this.quickActions) === JSON.stringify(actions)) return
    this.quickActions = actions
    this.rebuild()
  }

  setRecentThreads(threads: RecentThreadItem[]): void {
    if (JSON.stringify(this.recentThreads) === JSON.stringify(threads)) return
    this.recentThreads = threads
    this.rebuild()
  }

  onAction(callback: (action: TrayMenuAction) => void): void {
    this.actionCallback = callback
  }

  setDataProvider(provider: TrayDataProvider): void {
    this.dataProvider = provider
  }

  // systray2 is menu-only (no rich window). The launcher handles the pairing-code
  // popup for this backend itself via clipboard-copy + notification.
  showPairingWindow(_secret: string, _paired: boolean): void { /* no-op */ }

  // P0a: systray2 has no native confirmation dialog. Returns a promise that never
  // resolves so Promise.race falls back to the WS Side Panel. Swift is the only
  // backend that implements showConfirmDialog for real.
  showConfirmDialog(): Promise<never> { return new Promise(() => {}) }
  cancelConfirm(_id: string): void { /* no-op */ }

  // Native overlay chrome is Swift-only. C-thin HTML shell is opened via menu action "summoner".
  sendSummoner(_cmd: import("../summoner/protocol").SummonerOutboundCmd): void { /* no-op */ }
  openSummoner(_threadId: string): void {
    this.actionCallback?.({ type: "summoner" })
  }
  hydrateSummoner(_payload: import("../summoner/protocol").SummonerHydratePayload): void { /* no-op */ }

  async stop(): Promise<void> {
    this.shuttingDown = true
    if (this.systray) {
      // kill(false): caller (stopMenuBarAgent/handleAction) handles process.exit(0)
      await this.systray.kill(false).catch(() => {})
      this.systray = null
    }
  }

  // --- Internals ---

  private buildMenu() {
    this.seqMap = []
    const running = this.status === "running"
    const items: any[] = []

    const push = (title: string, mapping: TrayMenuAction, opts?: { enabled?: boolean; checked?: boolean }) => {
      items.push({
        title,
        tooltip: title,
        checked: opts?.checked ?? false,
        enabled: opts?.enabled ?? true,
      })
      this.seqMap.push(mapping)
    }

    // Start / Stop / Restart
    push("启动 Companion", { type: "start" }, { enabled: !running })
    push("停止 Companion", { type: "stop" }, { enabled: running })
    push("重启 Companion", { type: "restart" }, { enabled: running })

    items.push(SEP)
    this.seqMap.push({ type: "status" })

    // Status detail
    push("状态详情", { type: "status" })

    // Quick Actions
    if (this.quickActions.length > 0) {
      items.push(SEP)
      this.seqMap.push({ type: "status" })
      push("快速操作", { type: "status" }, { enabled: false })
      for (const qa of this.quickActions) {
        push(`  ${qa.title}`, { type: "quick-action", payload: { id: qa.id } })
      }
    }

    // Recent Threads
    if (this.recentThreads.length > 0) {
      items.push(SEP)
      this.seqMap.push({ type: "status" })
      push("最近对话", { type: "status" }, { enabled: false })
      for (const t of this.recentThreads) {
        push(`  > ${t.title}`, { type: "recent-thread", payload: { id: t.id } })
      }
    }

    items.push(SEP)
    this.seqMap.push({ type: "status" })

    push("打开日志目录", { type: "logs" })
    push("打开 Chrome", { type: "chrome" })
    push("显示配对码", { type: "show-pairing" })
    push("召唤器（实验）…", { type: "summoner" })
    push("设置", { type: "settings" })

    items.push(SEP)
    this.seqMap.push({ type: "status" })

    push("开机自启", { type: "autostart" }, { checked: this.autostartEnabled })

    items.push(SEP)
    this.seqMap.push({ type: "status" })

    push("退出（停止服务）", { type: "quit" })

    return {
      icon: getIcon(this.status),
      title: "",
      tooltip: getTooltip(this.status),
      isTemplateIcon: false,
      items,
    }
  }

  private isRebuilding = false
  private needsRebuild = false

  private async rebuild(): Promise<void> {
    if (!this.systray) return
    if (this.isRebuilding) {
      // Coalesce concurrent rebuild requests while a rebuild is in flight
      this.needsRebuild = true
      return
    }
    if (this.rebuildTimer) {
      clearTimeout(this.rebuildTimer)
    }
    this.rebuildTimer = setTimeout(async () => {
      this.rebuildTimer = null
      this.isRebuilding = true
      // systray2's update-menu does not refresh the internalIdMap, causing click
      // events to map to stale items after the menu structure changes.
      // Work around by killing and recreating the tray instance.
      // IMPORTANT: kill(false) — do NOT let systray2 call process.exit(0).
      // The default kill() has exitNode=true which terminates the whole Node process,
      // which would kill the app on every status change that triggers a rebuild.
      const wasShuttingDown = this.shuttingDown
      this.shuttingDown = true
      try {
        await this.systray.kill(false)
      } catch {
        // ignore
      }
      this.systray = null
      this.shuttingDown = wasShuttingDown
      try {
        await this.start({} as TrayConfig)
      } catch (err: any) {
        console.error("[systray2] Failed to recreate tray:", err.message)
      } finally {
        this.isRebuilding = false
        if (this.needsRebuild) {
          this.needsRebuild = false
          this.rebuild()
        }
      }
    }, 500)
  }

  private loadModule(): any {
    // In Node.js SEA mode, the standard require() cannot resolve npm packages
    // from the filesystem — it only finds built-in modules.
    // Module.createRequire(process.execPath) creates a resolver that searches
    // node_modules/ relative to the exe, which is where we place systray2.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const Module = require("module") as typeof import("module")
    const seaRequire = Module.createRequire(process.execPath)
    const mod = seaRequire("systray2")
    return (mod as any).default || (mod as any).SysTray || mod
  }
}


### companion/scripts/test-brand-rendering.py

"""macOS offscreen comparison of the production Swift path and shared JS exporter.
Run from repo root: uv run --no-project --with pillow python companion/scripts/test-brand-rendering.py
Does not launch tray or touch user configuration.
"""
from pathlib import Path
import subprocess,tempfile,json
from PIL import Image
root=Path(__file__).resolve().parents[2]
s=(root/'companion/src/tray/Tray.swift').read_text()
body=s[s.index('func makeStatusIcon('):s.index('// ---------------------------------------------------------------------------\n// Menu tag')]
with tempfile.TemporaryDirectory() as temp:
 out=Path(temp)
 swift='import AppKit\nenum CompanionStatus { case running, stopped, unknown }\n'+body+'''
let out = CommandLine.arguments[1]
for (name,status) in [("green",CompanionStatus.running),("red",.stopped),("yellow",.unknown)] {
 for size in [16,18,22,32,36,54] {
  let rep = NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:size,pixelsHigh:size,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
  NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep)
  makeStatusIcon(status,ws:false,size:NSSize(width:size,height:size)).draw(in:NSRect(x:0,y:0,width:size,height:size))
  NSGraphicsContext.restoreGraphicsState()
  try rep.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:"\\(out)/swift-\\(name)-\\(size).png"))
 }
}
'''
 (out/'render.swift').write_text(swift)
 subprocess.run(['swift',str(out/'render.swift'),str(out)],check=True)
 module=(root/'scripts/lib/brand-icon.mjs').as_uri()
 code=f'''import {{renderMark,encodePNG}} from {json.dumps(module)};import {{writeFileSync}} from 'node:fs';for(const color of ['green','red','yellow'])for(const size of [16,18,22,32,36,54])writeFileSync({json.dumps(str(out))}+`/js-${{color}}-${{size}}.png`,encodePNG(size,size,renderMark(size,color)))'''
 subprocess.run(['node','--input-type=module','-e',code],check=True)
 minimum=1
 for color in ['green','red','yellow']:
  for size in [16,18,22,32,36,54]:
   a=Image.open(out/f'swift-{color}-{size}.png').convert('RGBA');b=Image.open(out/f'js-{color}-{size}.png').convert('RGBA')
   assert a.size==b.size==(size,size)
   am=[p[3]>127 for p in a.getdata()];bm=[p[3]>127 for p in b.getdata()]
   iou=sum(x and y for x,y in zip(am,bm))/sum(x or y for x,y in zip(am,bm));minimum=min(minimum,iou)
   assert iou>=.85,(color,size,iou)
   assert a.getpixel((0,0))[3]==b.getpixel((0,0))[3]==0
   ac=a.getpixel((size//2,size//2));bc=b.getpixel((size//2,size//2))
   if color == 'red': assert max(ac[3],bc[3]) <= 32,(color,size,ac,bc)
   else: assert max(abs(x-y) for x,y in zip(ac,bc))<=2,(color,size,ac,bc)
   node=(round(size*5/24),round(size*5/24))
   assert max(abs(x-y) for x,y in zip(a.getpixel(node),b.getpixel(node)))<=2,(color,size,'node color')
 print(f'PASS: Swift/JS 18 combinations, silhouette IoU >= {minimum:.3f}; state color, dimensions, transparency verified.')


### companion/tests/tray-status-474.test.ts

import test from "node:test"
import assert from "node:assert/strict"
import { SysTray2Adapter } from "../src/tray/systray2-bridge"

test("tray has no adjacent title and status changes preserve menu action routing", () => {
  const tray = new SysTray2Adapter() as any
  for (const [status, color, word] of [["running","green","运行中"],["stopped","red","已停止"],["unknown","yellow","状态未知"]]) {
    tray.status = status
    const menu = tray.buildMenu()
    assert.equal(menu.title, "")
    assert.ok(menu.tooltip.includes(word))
    assert.ok(menu.icon.includes(`tray-icon-${color}`))
    assert.equal(menu.isTemplateIcon, false)
    assert.equal(menu.items[0].title, "启动 Companion")
    assert.equal(menu.items[0].enabled, status !== "running")
    assert.equal(menu.items[1].enabled, status === "running")
    assert.equal(tray.seqMap[0].type, "start")
    assert.equal(tray.seqMap[1].type, "stop")
    assert.equal(tray.seqMap[2].type, "restart")
  }
})


### companion/tests/tray-tokens-396.test.ts

/**
 * #396 — Swift tray token adoption (source-level).
 *
 * ConfirmController consumes SummonerTokens (type scale / semantic risk colors /
 * button hierarchy mirroring MinimalConfirm), tray NSMenu copy is emoji-free,
 * and the confirmation flow behavior (selectors, key equivalents, response
 * protocol, sanitization) is byte-for-byte unchanged.
 */
import test from "node:test"
import assert from "node:assert/strict"
import * as fs from "node:fs"
import * as path from "node:path"

const ROOT = path.resolve(__dirname, "..", "..")
function srcFile(...parts: string[]): string {
  const candidates = [
    path.join(ROOT, "src", ...parts),
    path.join(__dirname, "..", "src", ...parts),
  ]
  for (const p of candidates) {
    if (fs.existsSync(p)) return p
  }
  return candidates[0]
}

function traySrc(): string {
  return fs.readFileSync(srcFile("tray", "Tray.swift"), "utf8")
}

function overlaySrc(): string {
  return fs.readFileSync(srcFile("tray", "SummonerOverlay.swift"), "utf8")
}

function slice(src: string, startMark: string, endMark: string, label: string): string {
  const start = src.indexOf(startMark)
  assert.ok(start >= 0, `${label} start marker missing`)
  const end = src.indexOf(endMark, start)
  assert.ok(end > start, `${label} end marker missing`)
  return src.slice(start, end)
}

function confirmControllerBody(): string {
  return slice(traySrc(), "class ConfirmController", "extension ConfirmController", "ConfirmController")
}

function buildMenuBody(): string {
  return slice(traySrc(), "func buildMenu(", "private func makeInfoItem", "buildMenu")
}

// Emoji / pictographic ranges: symbols, dingbats, misc-technical, emoji blocks.
const EMOJI_RE = /[\u{1F000}-\u{1FAFF}\u{2300}-\u{23FF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}]/u

test("#396 SummonerTokens mirrors sidepanel tokens.ts canon values", () => {
  const overlay = overlaySrc()
  const start = overlay.indexOf("enum SummonerTokens")
  const end = overlay.indexOf("}", start)
  assert.ok(start >= 0 && end > start, "SummonerTokens block missing")
  const block = overlay.slice(start, end)
  // Leading comment keeps the mirror + Never-Material ban auditable
  assert.match(overlay.slice(Math.max(0, start - 400), start), /#4CAF50/)

  // tokens.success #059669 — primary (允许) fill
  assert.match(block, /static let success = NSColor\(calibratedRed: 5\/255, green: 150\/255, blue: 105\/255/)
  // tokens.danger #dc2626 — riskColor high+
  assert.match(block, /static let danger = NSColor\(calibratedRed: 220\/255, green: 38\/255, blue: 38\/255/)
  // tokens.warning #d97706 — riskColor low/medium
  assert.match(block, /static let warning = NSColor\(calibratedRed: 217\/255, green: 119\/255, blue: 6\/255/)
  // tokens.dangerSoft #fef2f2
  assert.match(block, /static let dangerBg = NSColor\(calibratedRed: 254\/255, green: 242\/255, blue: 242\/255/)
  // tokens.dangerBorder rgba(220, 38, 38, 0.28)
  assert.match(block, /static let dangerBorder = NSColor\(calibratedRed: 220\/255, green: 38\/255, blue: 38\/255, alpha: 0\.28\)/)
  // mapping comments keep the mirror auditable
  assert.match(block, /tokens\.success #059669/)
  assert.match(block, /tokens\.danger #dc2626/)
})

test("#396 SummonerTokens type scale is the 15/13/11 canon (no 13/11 roulette)", () => {
  const overlay = overlaySrc()
  const start = overlay.indexOf("enum SummonerTokens")
  const end = overlay.indexOf("}", start)
  const block = overlay.slice(start, end)
  assert.match(block, /static let fontTitle: CGFloat = 15/)
  assert.match(block, /static let fontBody: CGFloat = 13/)
  assert.match(block, /static let fontCaption: CGFloat = 11/)
  assert.match(block, /static let radiusSm: CGFloat = 6/)
})

test("#396 risk chip: color AND text label coexist (never color-only)", () => {
  const body = confirmControllerBody()
  const showBody = slice(body, "func show(", "private func updateCountdown", "ConfirmController.show")
  // Text labels (tokens.ts riskLabel)
  for (const label of ["高风险", "中风险", "低风险"]) {
    assert.ok(showBody.includes(label), `risk label ${label} missing`)
  }
  // Coordinate-injection suffix survives the copy migration
  assert.match(showBody, /高风险 · 不可逆操作/)
  // Semantic colors bound to the SAME switch (chip surface set from tokens)
  assert.match(showBody, /chipFg = SummonerTokens\.danger/)
  assert.match(showBody, /chipBg = SummonerTokens\.dangerBg/)
  assert.match(showBody, /chipBg = SummonerTokens\.warnBg/)
  assert.match(showBody, /chipBorder = SummonerTokens\.dangerBorder/)
  // Emoji badge is gone from the window title (risk lives in the chip)
  assert.match(showBody, /window\.title = "CMspark · 确认操作"/)
  assert.doesNotMatch(showBody, EMOJI_RE)
})

test("#396 buttons: 允许=primary (success fill), 拒绝=secondary — MinimalConfirm semantics", () => {
  const body = confirmControllerBody()
  const winStart = body.indexOf("private func makeWindow()")
  assert.ok(winStart >= 0, "ConfirmController.makeWindow missing")
  const winBody = body.slice(winStart)
  assert.match(winBody, /allowBtn\.bezelColor = SummonerTokens\.success/)
  assert.match(winBody, /allowBtn\.contentTintColor = \.white/)
  assert.doesNotMatch(winBody, /denyBtn\.bezelColor = SummonerTokens\.success/)
})

test("#396 behavior freeze: selectors, key equivalents, protocol, sanitization unchanged", () => {
  const body = confirmControllerBody()
  // Actions/targets
  assert.match(body, /NSButton\(title: "拒绝", target: self, action: #selector\(denyClicked\)\)/)
  assert.match(body, /NSButton\(title: "允许", target: self, action: #selector\(allowClicked\)\)/)
  // Key equivalents: Esc = deny, Return = allow
  assert.match(body, /denyBtn\.keyEquivalent = "\\u\{1b\}"/)
  assert.match(body, /allowBtn\.keyEquivalent = "\\r"/)
  // Response protocol identical
  assert.match(body, /jsonLine\(\["type": "confirm-response", "id": id, "approved": approved\]\)/)
  // Close = deny guard still present
  assert.match(body, /windowWillClose[\s\S]*?emitResponse\(id: id, approved: false\)/)
  // Summary sanitization (0x7F + C0 strip) survives untouched
  assert.match(body, /\$0\.value != 0x7F && !\(\$0\.value >= 0 && \$0\.value < 0x20\)/)
  // Non-activating panel (P0a: must not steal foreground) untouched
  assert.match(body, /\.nonactivatingPanel/)
  assert.match(body, /panel\.level = \.floating/)
})

test("#396 tray NSMenu copy carries semantics without emoji", () => {
  const menu = buildMenuBody()
  // #474: details retain text; the redundant status header is removed.
  for (const word of ["运行中", "已停止", "状态未知"]) {
    assert.ok(menu.includes(word), `status word ${word} missing`)
  }
  assert.doesNotMatch(menu, /CMspark Agent/)
  // WS line text label
  assert.match(menu, /已连接/)
  assert.match(menu, /未连接/)
  // No emoji anywhere in menu construction (titles no longer depend on them)
  assert.doesNotMatch(menu, EMOJI_RE)
})


### docs/superpowers/plans/2026-09-08-brand-icon-status.md

# 清晰连接图标与托盘状态

GitHub: #474 · 2026-09-08

沿用用户认可的简洁聊天风格。品牌含义为多系统信息汇聚到一个工作入口：三个端点连接中心的四角 spark，24×24 几何网格，粗线、少节点，无光晕、噪声和纹理。扩展使用透明底绿色标记；应用图标以深色圆角底承托同一标记；托盘透明底按状态着色，Swift 原生按目标分辨率绘制，兼容托盘生成 16/32/48 PNG/ICO。

绿色表示 Companion 运行，红色已停止，黄色检测中/未知。WebSocket 是独立连接状态，继续放状态详情，不把断开 WS 等同停止进程。菜单栏不显示状态标题，菜单不重复 Agent 状态头。悬浮 tooltip、VoiceOver label 和状态详情保留文本用于准确识别及色觉差异，状态未知不再写成已停止。所有启动/停止/重启处理器保持原绑定。

单一 JS 几何/PNG 导出模块供扩展与兼容托盘构建复用，输出 SVG 作为可审计矢量资产；Swift 使用同一24网格原生路径。验证导出尺寸/透明边界/状态色、16–32小尺寸明暗背景预览、Swift编译与实际离屏渲染、托盘标题为空而tooltip存在、菜单action映射不漂移。独立 Grok4.6 + DeepSeekV4Pro 设计/实现复审，机核绿后合并。不在此票执行安装替换。

## 设计复审落实

仅托盘表达进程状态；扩展与应用图标是静态品牌。坐标契约固定端点 (5,5)/(5,19)/(20,12)，半径2.3，连接线宽2.3，中心菱形边界(12,7.5)/(16.5,12)/(12,16.5)/(7.5,12)。停止态中心额外挖空半径1.9，以轮廓补充颜色。颜色 sRGB green #16845d / red #d54343 / unknown #b67c18，原生 isTemplate=false。未知只有既有 unknown 枚举，统一说明“状态未知”，不伪称持续检测；本票不新增状态机/超时逻辑。Swift 与 JS 离屏轮廓交并比至少0.85，颜色/尺寸/透明边界一致；16/18/22/32 明暗预览必须人工检查。Swift AX name明确设置；保留 tooltip 与详情。任意壁纸对比不作未经验证的保证，当前明暗背景通过后可交付。


### MACHINE exit 0 comp-finalbuild


> cmspark-agent@0.6.6 prebuild
> node scripts/generate-tray-icons.mjs

Connection tray icons generated (32px PNG, 16/32/48 ICO).

> cmspark-agent@0.6.6 build
> tsc && node -e "const fs=require('fs'),p=require('path');fs.mkdirSync('dist/computer',{recursive:true});fs.copyFileSync('src/computer/qwen-vl-worker.py','dist/computer/qwen-vl-worker.py');process.platform!=='win32'&&fs.chmodSync('dist/index.js',0o755)"


### MACHINE exit 0 comp-finaltest

      duration_ms: 0.247042
      type: 'test'
      ...
    1..4
ok 2 - settings-cli
  ---
  duration_ms: 2.087333
  type: 'suite'
  ...
1..2
# tests 20
# suites 2
# pass 20
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 51.998542

### MACHINE exit 0 ext-build

  icon_128x128.png (1235 bytes)
  icon_128x128@2x.png (2619 bytes)
  icon_256x256.png (2619 bytes)
  icon_256x256@2x.png (5904 bytes)
  icon_512x512.png (5904 bytes)
  icon_512x512@2x.png (15004 bytes)

Connection icon generation complete!

> cmspark-browser-agent@0.6.6 build
> tsc --noEmit && plasmo build

🟣 Plasmo v0.90.5
🔴 The Browser Extension Framework
🔵 INFO   | Prepare to bundle the extension...
🔵 INFO   | Building for target: chrome-mv3
🔵 INFO   | Loaded environment variables from: []
🟢 DONE   | Finished in 8590ms!

### MACHINE exit 0 render-test

WARN `--no-project` was provided, but no project was found
/Users/huchen/Projects/cmspark/companion/scripts/test-brand-rendering.py:35: DeprecationWarning: Image.Image.getdata is deprecated and will be removed in Pillow 14 (2027-10-15). Use get_flattened_data instead.
  am=[p[3]>127 for p in a.getdata()];bm=[p[3]>127 for p in b.getdata()]
PASS: Swift/JS 18 combinations, silhouette IoU >= 0.894; state color, dimensions, transparency verified.

### MACHINE exit 0 swiftbuild

[build-tray] Building CMspark Swift Tray...
[build-tray] Source: /Users/huchen/Projects/cmspark/companion/src/tray/Tray.swift
[build-tray] Output: /Users/huchen/Projects/cmspark/companion/dist/cmspark-tray
[build-tray] SUCCESS: Binary built at /Users/huchen/Projects/cmspark/companion/dist/cmspark-tray
[build-tray]         Size: 612864 bytes
[build-tray]         Arch: arm64
[build-tray]         Verified: Mach-O binary
[build-tray]         SHA256: e184528cf908e639cca2ec63c596471a6fae2992f4e7e1dca400107810c14fbb
[build-tray]         Update SWIFT_TRAY_SHA256 in menu-bar-agent.ts with this hash

Actual exported PNG sizes 16/32/48/64/128 and ICO all three embedded sizes/offsets validated with node assert, exit 0.
