Independent implementation re-review for #469, Grok4.6 + DeepSeekV4Pro. Read only this packet. Return APPROVE/APPROVE_WITH_NITS/REJECT and severity, precise evidence. Explicitly close or retain each prior blocker listed below. Do not infer missing definitions as defects; all files shown as diffs are changed TOGETHER. No confirmation handlers/policy changed. No release/app install. No cross-reviewer reports shared.
Previous blocking findings and dispositions to verify:
- Navigation modal obscures gate/Stop: replaced by in-flow nonmodal max28dvh disclosure, no scrim/focus trap. Browser hit-tests all confirmation buttons and composer Stop with navigation OPEN at320x480 PASS.
- Conversation/history classes missing: previous packet split omitted changed ChatView/ThreadList; both diffs now included. They have cm-chat-content/cm-chat-scroll/cm-history-panel.
- OPEN_SETTINGS_SECTION absent / label selectors wrong: source dependency evidence below includes REAL action/reducer and SettingsSection data attr; browser actual settings category click passes.
- Capability filtering: mode-controller below proves primary+overflow UNION contains EVERY registry ID at every level, so no disallowed flash-close. Resource selected state now aria-pressed. Do not invent permission bypass from primary presentation grouping.
- History chevron dead: moved INSIDE nativebutton.
- Escape closes history+context: scoped history handler stopPropagation now prevents window handler; no confirmation handler modified.
Other addressed: explicit recency sort using existing threadRecency, title single resolver/tooltip, noninteractive thread/card wrappers, select/trash accessible names, stale empty copy, explicit terminal-header class,36px buttons, narrow settings aligned bottom, settings opening closes context centrally, explicit navigation expanded state, stronger focus ring.
Tests currently: actual App browser PASS including latest fixes before final title/context cleanup; capture/settings actual HTML presentation-only reflow PASS with all non-style source byte-identical; terminal real UI PASS before header selector cleanup. Full extension1281 tests+productionbuild previously passed; final extension/companion builds/fulltests underway, do not assume final pass.
Additional web surfaces: only style blocks in companion; dark surface tokens in Cockpit/graphs; CodingAgentPanel top measures actual rail via CSSvar+ResizeObserver. No claim native Swift/Windows chrome certified.


DESIGN
# Design

## Source of truth
Active · 2026-09-07 · GitHub #469. This file owns product-wide UI/UX direction.
`docs/DESIGN.md` retains detailed capability and safety contracts; this revision
supersedes its consumer-mascot-first layout, tiny chrome and narrow-only shell.
Evidence: Sidepanel App, StatusRail, ThreadList, ChatView, ComposerDock,
ContextPanelHost, SettingsSlideout, shared tokens/Modal, Cockpit, graphs, terminal, capture and standalone web settings.
No current Codex screenshot was accessed: the reference is the user's stated
preference for quiet, spacious hierarchy, not a pixel-matching target.

## Brand
Calm, precise, capable. CMspark remains its own identity. Neutral paper and ink,
small existing mark, restrained indigo links/focus, semantic risk colors.
Avoid promotional dashboards, gradients, oversized mascots, dense icon ribbons,
unexplained technical acronyms and decorative status lights.

## Product goals
Make the next action obvious; keep conversation readable; let users find prior
work and supporting capabilities without remembering hidden menus. Preserve all
existing functions, confirmations, busy states and honest evidence gaps.
Success: no horizontal page overflow at 320px; usable content at 1440px; keyboard
reachable navigation/history/settings; input and stop remain reachable at short
height; dangerous actions never gain an implicit approval.
Non-goals: runtime redesign, new permission model, copying Codex assets, release.

## Personas and jobs
Enterprise change manager assembles sourced material across websites; developer
connects requirements/code/tests and optionally uses a terminal; everyday user
reads and acts on the current page. Each needs a quiet primary conversation and
clear separation of supporting configuration from execution.

## Information architecture
One responsive conversation workspace. At wide width, a quiet left navigation
shows new conversation, recent conversations and supporting resources. At narrow
width, navigation opens through the text-labeled header control 导航 as an in-flow, nonmodal disclosure (maximum28dvh, independently scrollable); primary conversation keeps full
width. Existing full history preserves search, folders, trash and bulk actions.
StatusRail remains the single conversation header: 导航 (narrow only), task title, existing popout/history/status/more. New conversation is owned by WorkspaceNavigation; no second new-thread control in the header. Recent rows are a projection of the existing store, while full history preserves its original owner. Conversation header shows task title (existing title resolver, 新对话 fallback); page/context and pending confirmation stay
in the existing FocusBand. Knowledge/scenes/skills/MCP/apps/meetings use existing
ContextPanelHost. The host is already vertically stacked, not a fixed-width side column: preserve that safe layout, cap it to36dvh (28dvh below560px height), and close supporting panels before opening configuration. Do not overlay pending confirmation. Settings is one named dialog with grouped sections.
No duplicated data loader, thread cache, Agent or confirmation center.

## Design principles
One dominant action per area. Progressive disclosure keeps tools/details on
demand; pending confirmation and stop stay visible. Text labels explain navigation.
Layout changes never change trust policy. Confirmation modifications are limited to shared surface colors, type, spacing and focus visibility; component handlers, button order/roles, initial focus, timeout, whitelist and auto-approve copy/defaults stay unchanged. Decision-critical evidence remains at least as visible as baseline. FocusBand confirmation/stop priority remains authoritative, with no second sticky header. Cockpit is in shared visual-token scope; confirmation DOM/handlers remain byte-unchanged. Small screens are a first-class surface.

## Visual language
Keep shared `sidepanel/ui/tokens.ts` the only new React color-value owner. Companion HTML constants mirror the palette without a new bundling dependency; their non-style source stays unchanged. Neutral
surfaces and subtle borders, readable secondary text; charcoal primary composer
action, indigo links/focus. Font system sans; body14–15, chrome12–13, headings
15–24. Spacing4/8/12/16/24/32; rounded controls8, cards12, composer20.
Flat navigation, quiet user bubble, unboxed assistant prose, restrained shadows
for floating surfaces only. Existing SVG icons; no added font/network assets.
Respect reduced motion and use short feedback transitions.

## Components
Responsive WorkspaceNavigation plus existing StatusRail/ThreadList; shared
Workspace styles, tokens and Modal. Conversation/readable-width wrappers,
ComposerDock, settings sections, tool disclosure cards, ContextPanelHost and
terminal adopt the same spacing and hierarchy. New classes are explicit, scoped,
and do not infer semantic roles from arbitrary inline-style selectors.

## Accessibility
Target WCAG 2.2 AA practices: text contrast at least4.5:1 for newly styled ordinary text, non-color risk labels, visible
focus, semantic buttons, keyboard Enter/Space, Escape and focus return for
drawers/dialogs, no nested interactive elements. Essential controls at least32px
and primary actions36px; preserve live status and destructive confirmation copy.
Do not claim formal conformance certification from automated testing.

## Responsive behavior
320–759px: full-width chat, nonmodal navigation disclosure, narrow dialogs and no fixed wide
columns. At760px+: persistent220px navigation, central conversation max780px;
wide settings use bounded centered dialog. Short screens scroll the content,
not the entire composer; supporting panel has viewport-relative height cap (min36dvh/360px, or28dvh below560px). Only message space may shrink; if confirmation competes, supporting context must yield.
Browser zoom and long titles/URLs must wrap or truncate without hiding actions.

## Interaction states
Empty state: a short invitation and useful action suggestions; suggestions fill
input, never send. Loading/streaming keeps stop; errors show recovery near source;
offline retains explicit reconnect. Selected navigation uses text plus background.
Confirmation remains distinct from normal tool success; disconnection does not
invent completion. Details expand deliberately without dumping raw JSON first.

## Content voice
Chinese product chrome, clear verbs, short labels. Prefer 对话/知识/场景/设置.
Technical detail belongs inside relevant settings or expanded evidence. Never
relabel an unverified report as approval, a process exit as task success, or a
permission setting as mere appearance.

## Implementation constraints
React18/Plasmo, inline styles plus scoped CSS, existing token owner and icons.
No new production dependency. Real component browser harness with synthetic
transport for wide/narrow/short layouts including759/760 breakpoints and200% equivalent CSS-viewport reflow, keyboard, message/tool/confirmation and
settings flows; production build, full suites and external dual reviews.
Native Swift/Windows platform chrome cannot be certified by the browser harness;
shared web surfaces are verified here, native surfaces remain separately tracked.

## Open questions
- [ ] #469: native host-window visuals on Windows require platform validation;
  owner maintainers. No claim of native cross-platform pixel acceptance.
- [ ] User can refine density after using the shipped redesign; current default
  assumes readable enterprise work rather than dense diagnostics.

diff --git a/chrome-extension/src/cockpit/CockpitApp.tsx b/chrome-extension/src/cockpit/CockpitApp.tsx
index 5a1d5ad3..50f1ebbb 100644
--- a/chrome-extension/src/cockpit/CockpitApp.tsx
+++ b/chrome-extension/src/cockpit/CockpitApp.tsx
@@ -793,11 +793,11 @@ const s: Record<string, CSSProperties> = {
     alignItems: "center",
     gap: 12,
     padding: "10px 14px",
     minHeight: 44,
     borderBottom: `1px solid ${tokens.darkBorder}`,
-    background: `linear-gradient(180deg, ${tokens.darkElevated} 0%, ${tokens.darkBg} 100%)`,
+    background: tokens.darkElevated,
     flexShrink: 0,
   },
   railLeft: {
     display: "flex",
     gap: 10,
@@ -866,11 +866,11 @@ const s: Record<string, CSSProperties> = {
     fontFamily: tokens.font,
   },
   confirmElevated: {
     margin: "12px 14px",
     padding: 14,
-    background: "linear-gradient(180deg, #2f1818 0%, #241414 100%)",
+    background: tokens.darkDangerBg,
     border: "1px solid #7f1d1d",
     borderRadius: tokens.radiusLg,
     boxShadow: "0 8px 24px rgba(0,0,0,0.28)",
   },
   unattendedStrip: {
@@ -914,11 +914,11 @@ const s: Record<string, CSSProperties> = {
     flexShrink: 0,
   },
   emptyGuide: {
     margin: "12px 14px 0",
     padding: "12px 14px",
-    background: "linear-gradient(180deg, #151a24 0%, #12161e 100%)",
+    background: tokens.darkElevated,
     border: `1px solid ${tokens.darkBorder}`,
     borderRadius: tokens.radiusLg,
     borderLeft: `3px solid ${tokens.darkAccent}`,
   },
   emptyGuideTitle: {
@@ -961,11 +961,11 @@ const s: Record<string, CSSProperties> = {
     marginBottom: 8,
     overflow: "hidden",
   },
   progressFill: {
     height: "100%",
-    background: `linear-gradient(90deg, ${tokens.accent}, ${tokens.darkAccent})`,
+    background: tokens.darkAccent,
     borderRadius: tokens.radiusPill,
   },
   dual: {
     flex: 1,
     display: "flex",
diff --git a/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx b/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
index d8cbc820..eb09a6ef 100644
--- a/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
+++ b/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
@@ -58,11 +58,11 @@ import {
 } from "./wire"
 
 type GraphDrawEdge = { a: string; b: string; score: number; dashed?: boolean; reason?: string }
 
 const G = {
-  canvas: "#0d0f14",
+  canvas: tokens.darkBg,
   edgeSoft: "rgba(148, 163, 184, 0.22)",
   edgeHot: "rgba(165, 180, 252, 0.75)",
   edgeDim: "rgba(148, 163, 184, 0.06)",
   labelFocus: "rgba(248, 250, 252, 0.95)",
 } as const
@@ -773,14 +773,14 @@ export function KnowledgeGraphApp() {
     </div>
   )
 }
 
 const glass: CSSProperties = {
-  background: "rgba(20, 24, 32, 0.88)",
+  background: tokens.darkElevated,
   border: `1px solid ${tokens.darkBorder}`,
   boxShadow: "0 8px 28px rgba(0,0,0,0.35)",
-  backdropFilter: "blur(12px)",
+  // Solid surface keeps graph controls legible without translucent layering.
 }
 
 const styles: Record<string, CSSProperties> = {
   page: {
     position: "relative",
diff --git a/chrome-extension/src/sidepanel/App.tsx b/chrome-extension/src/sidepanel/App.tsx
index 6f7f2039..34bc56b9 100644
--- a/chrome-extension/src/sidepanel/App.tsx
+++ b/chrome-extension/src/sidepanel/App.tsx
@@ -1,11 +1,6 @@
-/* THESIS: Side Panel is a consumer assistant empty, not an instrument desk — first viewport is a person who greets you.
-   OWN-WORLD: White surface, ink type, 22px greeting, sentence rows, circular send, indigo spark only on the companion mark.
-   STORY: Open → meet someone → type or tap a sentence → work still fits 320px.
-   FIRST VIEWPORT: Centered CompanionMark, 要我帮你做什么？, sentence invitations, quiet composer, 新对话.
-   FORM: Canon (知乎看山 quality bar) · seed e96a500f · Comp A approved.
-   FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, and DESIGN.md */
+// #469: responsive conversation workspace; root DESIGN.md.
 // CMspark Browser Agent — Root App Component
 
 import { Component, useState, useRef, useCallback, useEffect } from "react"
 import { useWebSocket } from "./hooks/useWebSocket"
 import { useCapabilityMode } from "./hooks/useCapabilityMode"
@@ -25,10 +20,12 @@ import { AtThreadPopover } from "./components/AtThreadPopover"
 import { SkillCraftPanel } from "./components/SkillCraftPanel"
 import { NotebooklmImporterPanel } from "./components/NotebooklmImporterPanel"
 import { StatusRail } from "./components/StatusRail"
 import { ComposerChips } from "./components/ComposerChips"
 import { ComposerCruisePicker } from "./components/ComposerCruisePicker"
+import { WorkspaceFrame } from "./components/WorkspaceFrame"
+import { workspaceCSS } from "./ui/workspace-styles"
 import { ComposerDock } from "./components/ComposerDock"
 import { ComposeDrawer } from "./components/ComposeDrawer"
 import { ThreadRefChips } from "./components/ThreadRefChips"
 import { UploadChips } from "./components/UploadChips"
 import { VoiceBanner } from "./components/VoiceBanner"
@@ -209,12 +206,13 @@ function AppContent() {
     })
   }, [isComputer])
 
   return (
     <ContextPanelHostProvider capabilityLevel={level}>
+    <WorkspaceFrame>
     <div style={styles.container}>
-      <style>{globalCSS}</style>
+      <style>{globalCSS + workspaceCSS}</style>
       <StatusRail
         connectionState={connectionState}
         capabilityLevel={level}
         badgeLabel={badgeLabel}
         onCraft={() => setCraftOpen(true)}
@@ -222,19 +220,20 @@ function AppContent() {
         onOpenNotebooklmImporter={() => setNbImporterOpen(true)}
         onToast={showToast}
         onPopout={handlePopout}
         canPopout={!!appState.activeThreadId}
       />
-      {/* #321 PR-3: toast host lives in a zero-height slot right under the rail —
-          its top is DOM-anchored to the rail, so no `top:52` rail-height magic. */}
-      <div style={{ position: "relative", height: 0, flexShrink: 0 }}>
-        <ToastHost toasts={toasts} onClose={closeToast} />
-      </div>
       {/* UIUX v2 §4.3 FocusBand: Confirm > L2 Safety+急停 > Fleet > L1 Context; ≤80px.
           #321 PR-2「一条 Now」: SceneStatusBar / RunBusyChip / WorkerScopeBar merged
           into FocusBand slots — no fourth band above the conversation. */}
       <FocusBand capabilityLevel={level} />
+      {/* #321 PR-3: toast host lives in a zero-height slot after the priority FocusBand —
+          its top is DOM-anchored below confirmation, so no `top:52` height magic. */}
+      <div style={{ position: "relative", height: 0, flexShrink: 0 }}>
+        <ToastHost toasts={toasts} onClose={closeToast} />
+      </div>
+
       <ChatView />
       <FleetWorkerListPortal />
       {/* R3: ComputerTaskBar removed — step timeline only in Cockpit dual-track */}
       {/* #321 PR-1: legacy BottomBar strip deleted (was permanently gated off). Host is SoT. */}
       <ContextPanelHost />
@@ -293,10 +292,11 @@ function AppContent() {
             })
           })
         }}
       />
     </div>
+    </WorkspaceFrame>
     </ContextPanelHostProvider>
   )
 }
 
 
@@ -824,11 +824,11 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
 
   gestureSendRef.current = (files) => handleSend(files)
 
   return (
     <div
-      style={{ borderTop: `1px solid ${tokens.border}`, flexShrink: 0, position: "relative" as const, background: tokens.bg }}
+      style={{ flexShrink: 0, position: "relative" as const, background: tokens.bg }}
       onPaste={handleComposerPaste}
       onDragEnter={handleComposerDragEnter}
       onDragOver={handleComposerDragOver}
       onDragLeave={handleComposerDragLeave}
       onDrop={handleComposerDrop}
@@ -874,34 +874,21 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
       {/* PR4: ComposerDock chips + capsule; 装配 lives on the chip, not in the field */}
       <ComposerDock
         chips={<ComposerChips capabilityLevel={capabilityLevel} onAction={handleChipAction} />}
       >
         <div
+          className="cm-composer-capsule"
           style={{
             ...styles.composerCapsule,
             opacity: needsThread || needsConnection ? 0.85 : 1,
             background: needsThread || needsConnection ? tokens.bgMuted : tokens.bgElevated,
             borderColor: dragOver ? tokens.accent : tokens.borderStrong,
             boxShadow: dragOver ? `0 0 0 1px ${tokens.accent}` : tokens.shadowSm,
           }}
         >
-          {/* Attach stays visible in the empty composer — first-run affordance. */}
-          {!showStop && !(voice.listening && showVoiceMic) && (
-            <button
-              type="button"
-              style={styles.attachBtn}
-              onClick={() => fileInputRef.current?.click()}
-              // l2_task: ingest is blocked for an active computer task — don't
-              // present a clickable affordance whose selection is silently dropped.
-              disabled={needsThread || needsConnection || threadBusy || composerMode === "l2_task" || !!overlayStandby}
-              title="添加文件或图片"
-              aria-label="添加文件或图片"
-            >
-              <IconAttach size={16} />
-            </button>
-          )}
           <textarea
+            aria-label="消息内容"
             ref={textareaRef}
             style={styles.textarea}
             placeholder={getPlaceholder()}
             rows={1}
             value={voice.liveOverlay !== null ? voice.liveOverlay : text}
@@ -915,10 +902,27 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
             }
             onChange={handleChange}
             onKeyDown={handleKeyDown}
             onPaste={handleComposerPaste}
           />
+          <div className="cm-composer-actions">
+          {/* Attach stays visible in the empty composer — first-run affordance. */}
+          {!showStop && !(voice.listening && showVoiceMic) && (
+            <button
+              type="button"
+              style={styles.attachBtn}
+              onClick={() => fileInputRef.current?.click()}
+              // l2_task: ingest is blocked for an active computer task — don't
+              // present a clickable affordance whose selection is silently dropped.
+              disabled={needsThread || needsConnection || threadBusy || composerMode === "l2_task" || !!overlayStandby}
+              title="添加文件或图片"
+              aria-label="添加文件或图片"
+            >
+              <IconAttach size={16} />
+            </button>
+          )}
+          <span style={{ flex: 1 }} />
           {showVoiceMic && (
             <VoiceMicButton
               listening={voice.listening && !voice.processing}
               processing={voice.processing}
               disabled={voiceMicDisabled && !voice.listening}
@@ -969,11 +973,11 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
           ) : (
             <button
               type="button"
               style={{
                 ...styles.sendBtn,
-                background: canSend ? tokens.accent : tokens.sendDisabledBg,
+                background: canSend ? tokens.actionPrimary : tokens.sendDisabledBg,
                 color: canSend ? tokens.userBubbleText : tokens.textMuted,
                 cursor: canSend ? "pointer" : "not-allowed",
               }}
               onClick={() => handleSend()}
               disabled={!canSend}
@@ -993,10 +997,11 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
             >
               <IconSend size={15} />
             </button>
           )}
 
+          </div>
         </div>
         <VoiceBanner
           banner={voice.banner}
           engineSwitchNote={engineSwitchNote}
           rawSnapshot={voice.rawSnapshot}
@@ -1181,25 +1186,27 @@ const globalCSS = `
 const styles: Record<string, React.CSSProperties> = {
   // Precision Instrument Desk — solid canvas, flat composer (Phase 1)
   container: {
     display: "flex",
     flexDirection: "column",
-    height: "100vh",
+    height: "100%",
+    minHeight: 0,
     fontFamily: tokens.font,
     fontSize: 13,
     color: tokens.text,
     background: tokens.bg,
     WebkitFontSmoothing: "antialiased",
     position: "relative" as const,
   },
   composerCapsule: {
     display: "flex",
-    alignItems: "flex-end",
+    flexDirection: "column",
+    alignItems: "stretch",
     gap: 8,
     border: `1px solid ${tokens.border}`,
     borderRadius: tokens.radiusComposer,
-    padding: "6px 10px 6px 12px",
+    padding: "10px 12px 10px 14px",
     background: tokens.bgElevated,
     minHeight: 52,
     transition: `border-color ${tokens.transitionFast} ease, box-shadow ${tokens.transitionFast} ease`,
   },
   textarea: {
diff --git a/chrome-extension/src/sidepanel/components/ChatView.tsx b/chrome-extension/src/sidepanel/components/ChatView.tsx
index f88b7375..fe378357 100644
--- a/chrome-extension/src/sidepanel/components/ChatView.tsx
+++ b/chrome-extension/src/sidepanel/components/ChatView.tsx
@@ -341,12 +341,12 @@ export function ChatView() {
 
   return (
     <div style={styles.shell}>
       <style>{quietActionsCSS}</style>
       {/* #321 PR-2: popout bar removed — the 弹出对话框 affordance lives on StatusRail now. */}
-      <div style={styles.container} ref={containerRef} onScroll={handleScroll}>
-      <div ref={contentRef} style={styles.contentInner}>
+      <div className="cm-chat-scroll" style={styles.container} ref={containerRef} onScroll={handleScroll}>
+      <div className="cm-chat-content" ref={contentRef} style={styles.contentInner}>
         {showCompactBanner && (
           <NoticeCard tone="warning" role="status" testId="context-notice-card">
             {compactBanner === "shrink" ? (
               <>
                 <strong>工具结果已截断</strong>
@@ -1101,24 +1101,21 @@ function ToolCallCard({ tc }: { tc: any }) {
   const progressErr =
     typeof tc.progress_stderr_tail === "string" ? tc.progress_stderr_tail : ""
   const showLiveProgress =
     derivedStatus === "running" && (progressElapsed != null || progressOut || progressErr)
 
-  // Generic tools: click card to expand JSON. Shell uses its own expand control.
+  // Generic tools use the named disclosure button. Shell owns its own control.
   // Redacted stubs never expand — there is no content to reveal.
   const canExpandGeneric = hasResult && isLongResult && !isShellExec && !redactedStub
 
   return (
     <div
       style={{
         ...styles.toolCard,
         // G3: status via left hairline only — not a full-border cage
         borderLeftColor: shellFailed ? tokens.danger : statusTone,
-        cursor: canExpandGeneric ? "pointer" : "default",
-      }}
-      onClick={() => {
-        if (canExpandGeneric) setExpanded(!expanded)
+        cursor: "default",
       }}
       data-testid="tool-call-card"
       data-tool={tc.tool_name || ""}
     >
       <div style={styles.toolHeader}>
@@ -1147,11 +1144,11 @@ function ToolCallCard({ tc }: { tc: any }) {
         )}
         {isVisionTool && tc.vision_status === "error" && (
           <span style={{ ...styles.toolMeta, color: tokens.warning }}>Vision failed</span>
         )}
         {canExpandGeneric && (
-          <span style={styles.toolExpandHint}>{expanded ? "收起" : "展开"}</span>
+          <button type="button" aria-label={`${expanded ? "收起" : "展开"} ${tc.tool_name} 详情`} aria-expanded={expanded} style={{ ...styles.toolExpandHint, border: "none", background: "transparent", cursor: "pointer", minHeight: 32 }} onClick={e => { e.stopPropagation(); setExpanded(!expanded) }}>{expanded ? "收起" : "详情"}</button>
         )}
         {showLiveProgress && progressElapsed != null && (
           <span style={styles.toolMeta} data-testid="tool-progress-elapsed">
             {Math.floor(progressElapsed / 1000)}s
           </span>
@@ -1778,11 +1775,11 @@ export function EmptyState({ level }: { level: "chat" | "browser" | "computer" }
   const testId =
     level === "browser" ? "empty-state-browser" : level === "computer" ? "empty-state-computer" : "empty-state-chat"
 
   return (
     <div style={styles.empty} data-testid={testId}>
-      <CompanionMark size={48} />
+      <CompanionMark size={36} />
       <div style={styles.emptyTitle}>{title}</div>
       {hint ? <div style={styles.emptyHint}>{hint}</div> : null}
       {rows.length > 0 ? <InvitationRows items={rows} /> : null}
       {pageChip ? (
         <div style={styles.pageChip} data-testid="empty-page-chip">
@@ -1913,11 +1910,11 @@ const styles: Record<string, React.CSSProperties> = {
     flexDirection: "column",
     alignItems: "center",
     justifyContent: "flex-start",
     color: tokens.text,
     textAlign: "center",
-    padding: "16px 8px 8px",
+    padding: "clamp(16px, 6vh, 56px) 8px 16px",
     fontFamily: tokens.font,
   },
   emptyTitle: {
     fontSize: tokens.emptyTitle,
     fontWeight: 600,
@@ -1968,39 +1965,40 @@ const styles: Record<string, React.CSSProperties> = {
     fontFamily: tokens.font,
   },
   inviteCol: {
     display: "flex",
     flexDirection: "column",
-    gap: 8,
+    gap: 4,
     width: "100%",
-    maxWidth: 260,
+    maxWidth: 340,
     alignItems: "flex-start",
   },
   inviteRow: {
     display: "flex",
     alignItems: "center",
     gap: 10,
     width: "100%",
-    padding: 0,
-    border: "none",
+    padding: "10px 12px",
+    border: `1px solid ${tokens.border}`,
     background: "transparent",
     fontSize: 14,
     fontWeight: 400,
+    borderRadius: tokens.radiusLg,
     lineHeight: 1.4,
     cursor: "pointer",
     fontFamily: tokens.font,
     textAlign: "left" as const,
   },
   userMsg: {
     display: "flex",
     justifyContent: "flex-end",
-    marginBottom: 10,
+    marginBottom: 24,
   },
   agentMsg: {
     display: "flex",
     justifyContent: "flex-start",
-    marginBottom: 10,
+    marginBottom: 24,
   },
   messageCol: {
     display: "flex",
     flexDirection: "column",
     maxWidth: "90%",
@@ -2054,27 +2052,27 @@ const styles: Record<string, React.CSSProperties> = {
   userBubble: {
     background: tokens.userBubbleBg,
     color: tokens.userBubbleInk,
     border: `1px solid ${tokens.userBubbleBorder}`,
     borderRadius: `${tokens.radiusBubble}px ${tokens.radiusBubble}px 4px ${tokens.radiusBubble}px`,
-    padding: "9px 13px",
-    fontSize: 13,
+    padding: "12px 16px",
+    fontSize: 14,
     lineHeight: 1.5,
     wordBreak: "break-word" as const,
     whiteSpace: "pre-wrap",
-    boxShadow: tokens.shadowSm,
+    boxShadow: "none",
   },
   agentBubble: {
     background: tokens.assistantBubbleBg,
     color: tokens.assistantBubbleText,
     borderRadius: `${tokens.radiusBubble}px ${tokens.radiusBubble}px ${tokens.radiusBubble}px 4px`,
-    padding: "9px 13px",
-    fontSize: 13,
-    lineHeight: 1.5,
+    padding: "8px 2px",
+    fontSize: 14,
+    lineHeight: 1.75,
     wordBreak: "break-word" as const,
-    border: `1px solid ${tokens.border}`,
-    boxShadow: tokens.shadowSm,
+    border: "none",
+    boxShadow: "none",
   },
   truncChip: {
     marginTop: 6,
     alignSelf: "flex-start" as const,
     fontSize: 11,
@@ -2234,19 +2232,19 @@ const styles: Record<string, React.CSSProperties> = {
     border: `1px solid ${tokens.border}`,
     borderLeft: `2px solid ${tokens.accent}`,
     borderRadius: tokens.radiusMd,
     padding: "8px 10px",
     background: tokens.bgElevated,
-    fontSize: 11,
-    boxShadow: tokens.shadowSm,
+    fontSize: 12,
+    boxShadow: "none",
   },
   toolHeader: {
     display: "flex",
     alignItems: "center",
     gap: 5,
     marginBottom: 0,
-    minHeight: 18,
+    minHeight: 28,
   },
   toolStatusGlyph: {
     fontSize: 10,
     fontWeight: 700,
     width: 12,
diff --git a/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx b/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx
index 88b927c1..55d32fd8 100644
--- a/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx
+++ b/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx
@@ -1206,27 +1206,27 @@ function kindIcon(kind?: string): string {
 }
 
 const styles: Record<string, CSSProperties> = {
   overlay: {
     position: "absolute",
-    // Leave StatusRail (~40px) visible so connection / settings still reachable
-    top: 40,
+    // Match the measured rail at all widths; standalone mounts have no rail.
+    top: "var(--cm-status-height, 0px)",
     left: 0,
     right: 0,
     bottom: 0,
     zIndex: 40,
     display: "flex",
     flexDirection: "column",
-    background: tokens.bg || "#f8fafc",
+    background: tokens.bg,
   },
   panel: {
     flex: 1,
     display: "flex",
     flexDirection: "column",
     minHeight: 0,
-    padding: 10,
-    gap: 8,
+    padding: 16,
+    gap: 12,
   },
   confirmHost: {
     border: `1px solid ${tokens.border || "#fecaca"}`,
     borderRadius: 8,
     padding: 8,
@@ -1514,11 +1514,11 @@ const styles: Record<string, CSSProperties> = {
     whiteSpace: "pre-wrap",
     wordBreak: "break-word",
   },
   tlRow: { display: "flex", gap: 6, alignItems: "flex-start", fontSize: 12 },
   tlRowMsg: {
-    background: tokens.bg || "#f8fafc",
+    background: tokens.bg,
     borderRadius: 6,
     padding: "4px 6px",
   },
   tlKind: { width: 16, flexShrink: 0, textAlign: "center" },
   tlBody: { flex: 1, minWidth: 0 },
diff --git a/chrome-extension/src/sidepanel/components/ComposerDock.tsx b/chrome-extension/src/sidepanel/components/ComposerDock.tsx
index 71f43daa..6bb36258 100644
--- a/chrome-extension/src/sidepanel/components/ComposerDock.tsx
+++ b/chrome-extension/src/sidepanel/components/ComposerDock.tsx
@@ -10,11 +10,11 @@ export type ComposerDockProps = {
   children: ReactNode
 }
 
 export function ComposerDock({ chips, children }: ComposerDockProps) {
   return (
-    <div style={styles.inputArea}>
+    <div className="cm-composer-dock" style={styles.inputArea}>
       {chips}
       {children}
     </div>
   )
 }
diff --git a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
index 39f2c5c0..a6c7d258 100644
--- a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
+++ b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
@@ -168,10 +168,14 @@ export function ContextPanelHostProvider({
 
   const closePanel = useCallback(() => {
     setActivePanel(null)
   }, [])
 
+  useEffect(() => {
+    if (state.settingsOpen) closePanel()
+  }, [state.settingsOpen, closePanel])
+
   const openPanelForce = useCallback(
     (id: ContextPanelId) => {
       setActivePanel(id)
       loadPanelData(id, activeThreadId, dispatch)
     },
@@ -273,11 +277,11 @@ export function ContextPanelHost() {
   if (!activePanel) return null
 
   const label = contextPanelLabel(activePanel)
 
   return (
-    <div style={styles.panel} data-testid="context-panel-host">
+    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
       <div style={styles.panelHeader}>
         <span style={styles.panelTitle}>{label}</span>
         <button
           type="button"
           style={styles.panelCloseBtn}
diff --git a/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx b/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
index c9861cf0..067d999c 100644
--- a/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
+++ b/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
@@ -844,18 +844,31 @@ export function SettingsSlideout() {
     <Modal
       open={state.settingsOpen}
       onClose={() => dispatch({ type: "TOGGLE_SETTINGS" })}
       overlayStyle={styles.backdrop}
       panelStyle={styles.panel}
+      panelClassName="cm-settings-panel"
       ariaLabel="设置"
     >
-        <div style={styles.header}>
+        <div className="cm-settings-header" style={styles.header}>
           <h3 style={{ margin: 0, fontSize: 15 }}>设置</h3>
-          <button style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
+          <button type="button" aria-label="关闭设置" className="cm-icon-button" style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
         </div>
 
-        <div style={{ ...styles.body, display: "flex", flexDirection: "column" }}>
+        <nav aria-label="设置分类" className="cm-settings-categories">
+          {[
+            ["model", "模型与推理"], ["connection", "连接与配对"], ["security", "安全与信任"],
+            ["secrets", "密钥与环境"], ["integrations", "本机与集成"], ["export", "导出与集成"], ["experimental", "实验功能"],
+          ].map(([id, label]) => <button key={id} type="button" onClick={() => {
+            dispatch({ type: "OPEN_SETTINGS_SECTION", section: id })
+            requestAnimationFrame(() => requestAnimationFrame(() => {
+              const heading = document.querySelector<HTMLElement>(`[data-settings-section="${label}"] > button`)
+              heading?.focus(); heading?.scrollIntoView({ block: "start" })
+            }))
+          }}>{label}</button>)}
+        </nav>
+        <div className="cm-settings-body" style={{ ...styles.body, display: "flex", flexDirection: "column" }}>
           {/* D2+ : configure CMspark itself via text or voice */}
           <div style={{ order: 0 }}>
             <SettingsIntentBar onIntent={applySettingsIntent} />
           </div>
 
@@ -4266,15 +4279,15 @@ export function SettingsSlideout() {
 
 const styles: Record<string, React.CSSProperties> = {
   backdrop: {
     position: "fixed",
     inset: 0,
-    background: "rgba(0,0,0,0.3)",
+    background: tokens.scrim,
     zIndex: 200,
     display: "flex",
-    alignItems: "flex-end",
-    justifyContent: "stretch",
+    alignItems: "center",
+    justifyContent: "center",
   },
   panel: {
     width: "100%",
     maxHeight: "80vh",
     background: tokens.bgElevated,
diff --git a/chrome-extension/src/sidepanel/components/StatusRail.tsx b/chrome-extension/src/sidepanel/components/StatusRail.tsx
index c229091e..af94a9db 100644
--- a/chrome-extension/src/sidepanel/components/StatusRail.tsx
+++ b/chrome-extension/src/sidepanel/components/StatusRail.tsx
@@ -1,33 +1,34 @@
 // StatusRail — Zone A (UIUX v2 PR1)
 // Mode badge + pin · connection (token colors) · thread switcher · ⋯ menu
 
 import { useState, useRef, useEffect, type CSSProperties } from "react"
-import { ThreadList, createBlankThread } from "./ThreadList"
+import { ThreadList } from "./ThreadList"
 import { useAgentStore } from "../store/agentStore"
 import type { ConnectionState, CapabilityLevel } from "../types"
 import {
   tokens,
   connectionColor,
   connectionLabel,
   connectionDotShadow,
 } from "../ui/tokens"
+import { displayThreadTitle } from "../utils/thread-timeline"
 import { popupMenuStyles } from "../ui/popupMenuStyles"
 import { ModeBadge } from "../ui/ModeBadge"
 
 import {
+  IconList,
   IconCraft,
   IconDownload,
   IconNotebook,
   IconSave,
   IconBrain,
   IconLogs,
   IconSettings,
   IconAlert,
   IconSpinner,
   IconMore,
-  IconNewChat,
   IconExternal,
   CompanionMark,
 } from "../ui/icons"
 import { disarmAllFlags, trustStatusChip, trustStatusChipShort } from "./autopilot-tier"
 
@@ -52,10 +53,22 @@ export function StatusRail({
   /** #321 PR-2: pop the active thread into a dialog window (former ChatView bar). */
   onPopout: () => void
   canPopout: boolean
 }) {
   const { state, dispatch } = useAgentStore()
+  const railRef = useRef<HTMLDivElement>(null)
+  useEffect(() => {
+    const rail = railRef.current
+    const workspace = rail?.closest<HTMLElement>(".cm-workspace-main")
+    if (!rail || !workspace) return
+    const measure = () => workspace.style.setProperty("--cm-status-height", `${rail.getBoundingClientRect().height}px`)
+    measure()
+    const observer = new ResizeObserver(measure)
+    observer.observe(rail)
+    return () => { observer.disconnect(); workspace.style.removeProperty("--cm-status-height") }
+  }, [])
+
   const pinned = state.modePin === capabilityLevel
   const togglePin = () => {
     if (pinned) {
       dispatch({ type: "SET_MODE_PIN", pin: null })
       onToast?.("已取消钉住 — 层级可自动降级")
@@ -64,10 +77,12 @@ export function StatusRail({
       onToast?.(`已钉住「${badgeLabel}」— 阻止自动降级`)
     }
   }
   const hasMessages = state.messages.length > 0 && !!state.activeThreadId
   const activeThreadId = state.activeThreadId
+  const activeThread = state.threads.find(t => t.id === activeThreadId)
+  const taskTitle = activeThread ? displayThreadTitle(activeThread) : "新对话"
   const [nbState, setNbState] = useState<"idle" | "working" | "warning">("idle")
   const [nbTooltip, setNbTooltip] = useState<string>(
     "离线导出当前页为 Markdown（拖入 NotebookLM 作为来源）",
   )
   const [menuOpen, setMenuOpen] = useState(false)
@@ -195,17 +210,19 @@ export function StatusRail({
         ? tokens.modeComputerLine
         : null
 
   return (
     <div
+      ref={railRef} className="cm-status-rail"
       role="banner"
       aria-label="状态栏"
       style={{
         ...railStyles.rail,
         ...(modeLine ? { boxShadow: `inset 0 -2px 0 ${modeLine}` } : null),
       }}
     >
+      <button type="button" className="cm-icon-button cm-navigation-toggle" aria-label="打开工作区导航" aria-haspopup="dialog" onClick={() => window.dispatchEvent(new Event("cmspark:toggle-navigation"))}><IconList size={16} /><span style={{ fontSize: 12 }}>导航</span></button>
       <ModeBadge
         level={capabilityLevel}
         label={badgeLabel}
         pinned={pinned}
         onTogglePin={togglePin}
@@ -214,20 +231,12 @@ export function StatusRail({
       {/* Brand point (small CompanionMark) — #321 PR-3: resident, no longer hidden
           on cruise / disconnect. Decorative (CompanionMark stays aria-hidden). */}
       <div style={railStyles.brand} title="CMspark" aria-label="CMspark">
         <CompanionMark size={16} />
       </div>
+      <div className="cm-task-title" title={taskTitle}>{taskTitle}</div>
       <div style={railStyles.cluster}>
-      <button
-        type="button"
-        style={railStyles.ghostBtn}
-        title="新增对话"
-        aria-label="新增对话"
-        onClick={() => createBlankThread(dispatch)}
-      >
-        <IconNewChat size={18} />
-      </button>
       <button
         type="button"
         style={{
           ...railStyles.ghostBtn,
           ...(canPopout ? {} : { opacity: 0.45, cursor: "not-allowed" }),
diff --git a/chrome-extension/src/sidepanel/components/ThreadList.tsx b/chrome-extension/src/sidepanel/components/ThreadList.tsx
index 263df286..e841ce96 100644
--- a/chrome-extension/src/sidepanel/components/ThreadList.tsx
+++ b/chrome-extension/src/sidepanel/components/ThreadList.tsx
@@ -3,11 +3,11 @@
 
 import { useCallback, useEffect, useMemo, useRef, useState } from "react"
 import { createPortal } from "react-dom"
 import { useAgentStore } from "../store/agentStore"
 import { tokens } from "../ui/tokens"
-import { IconChevronDown } from "../ui/icons"
+import { IconHistory } from "../ui/icons"
 import { popupMenuStyles } from "../ui/popupMenuStyles"
 import type { Thread } from "../types"
 import {
   batchNeedsForceExtract,
   buildTagIndex,
@@ -118,13 +118,16 @@ export function ThreadList() {
   const [selectMode, setSelectMode] = useState(false)
   const [selected, setSelected] = useState<Set<string>>(() => new Set())
   const [expandState, setExpandState] = useState<ThreadListExpandState>(loadExpandState)
   const [expandedDays, setExpandedDays] = useState<Set<string>>(() => new Set())
   const [menuOpen, setMenuOpen] = useState(false)
+  const menuOpenRef = useRef(menuOpen)
+  menuOpenRef.current = menuOpen
   const [menuPos, setMenuPos] = useState<{ top: number; right: number } | null>(null)
   const menuBtnRef = useRef<HTMLButtonElement | null>(null)
   const triggerRef = useRef<HTMLButtonElement | null>(null)
+  const historyRef = useRef<HTMLDivElement>(null)
   const [panelBox, setPanelBox] = useState<{ top: number; maxHeight: number } | null>(null)
   const [activeTag, setActiveTag] = useState<string | null>(null)
   const [extractingIds, setExtractingIds] = useState<Set<string>>(() => new Set())
   /** A-7 batch progress: done/total while untagged or multi extract runs. */
   const [extractProgress, setExtractProgress] = useState<{
@@ -852,10 +855,27 @@ export function ThreadList() {
     place()
     window.addEventListener("resize", place)
     return () => window.removeEventListener("resize", place)
   }, [open, selectMode, view])
 
+  // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
+  // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
+  useEffect(() => {
+    if (!open || !panelBox) return
+    historyRef.current?.querySelector<HTMLInputElement>('input[type="text"], input:not([type])')?.focus()
+    const key = (event: KeyboardEvent) => {
+      if (event.key !== "Escape" || event.defaultPrevented) return
+      if (!historyRef.current?.contains(event.target as Node) && event.target !== triggerRef.current && !menuOpenRef.current) return
+      event.preventDefault()
+      event.stopPropagation()
+      if (menuOpenRef.current) { setMenuOpen(false); menuBtnRef.current?.focus(); return }
+      setOpen(false); triggerRef.current?.focus()
+    }
+    document.addEventListener("keydown", key)
+    return () => document.removeEventListener("keydown", key)
+  }, [open, !!panelBox])
+
   const renderThreadRow = (t: Thread) => {
     const busy = !!threadBusyById[t.id]
     const isActive = t.id === activeThreadId
     const badge = roleBadge(t.agent_role)
     const title = displayThreadTitle(t)
@@ -875,15 +895,10 @@ export function ThreadList() {
           ...styles.threadItem,
           background: isActive ? tokens.accentSoft : "transparent",
           opacity: selectMode && busy ? 0.45 : 1,
         }}
         aria-label={accessibleName}
-        onClick={() => {
-          const sel = window.getSelection?.()
-          if (sel && sel.toString().length > 0) return
-          handleSelect(t.id)
-        }}
       >
         {selectMode && (
           <input
             type="checkbox"
             checked={selected.has(t.id)}
@@ -895,11 +910,11 @@ export function ThreadList() {
             aria-label={`选择 ${accessibleName}`}
           />
         )}
         <div style={{ flex: 1, minWidth: 0 }}>
           <div style={styles.threadAliasRow}>
-            <span style={styles.threadAlias}>{title}</span>
+            <button type="button" className="cm-thread-open" style={{ ...styles.threadAlias, border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "pointer", padding: "6px 0", minHeight: 32 }} disabled={trashView} aria-label={`${selectMode ? "选择" : trashView ? "已删除" : "打开"} ${accessibleName}`} onClick={e => { e.stopPropagation(); handleSelect(t.id) }}>{title}</button>
             {chip ? <span style={styles.badge}>{chip}</span> : null}
             {idBadge ? (
               <button
                 type="button"
                 style={{
@@ -1071,16 +1086,13 @@ export function ThreadList() {
       hasMatches: searchActive && month.count > 0,
     })
     const ids = threadIdsInMonth(month)
     return (
       <div key={month.monthKey}>
-        <div style={styles.groupHeader} onClick={() => toggleMonth(month.monthKey)}>
+        <div style={styles.groupHeader}>
           {renderGroupCheckbox(ids, month.label)}
-          <span style={styles.groupChevron}>{openMonth ? "▼" : "▶"}</span>
-          <span style={styles.groupLabel}>
-            {month.label} · {month.count}
-          </span>
+          <button type="button" className="cm-history-group" aria-expanded={openMonth} onClick={() => toggleMonth(month.monthKey)}><span aria-hidden="true" style={styles.groupChevron}>{openMonth ? "▼" : "▶"}</span> {month.label} · {month.count}</button>
         </div>
         {openMonth && month.days.map((day) => renderDay(day))}
       </div>
     )
   }
@@ -1092,17 +1104,13 @@ export function ThreadList() {
     const ids = threadIdsInDay(day)
     return (
       <div key={day.dayKey}>
         <div
           style={{ ...styles.groupHeader, paddingLeft: 20 }}
-          onClick={() => toggleDay(day.dayKey)}
         >
           {renderGroupCheckbox(ids, day.label)}
-          <span style={styles.groupChevron}>{openDay ? "▼" : "▶"}</span>
-          <span style={styles.groupLabel}>
-            {day.label} · {day.threads.length}
-          </span>
+          <button type="button" className="cm-history-group" aria-expanded={openDay} onClick={() => toggleDay(day.dayKey)}><span aria-hidden="true" style={styles.groupChevron}>{openDay ? "▼" : "▶"}</span> {day.label} · {day.threads.length}</button>
         </div>
         {openDay && day.threads.map((t) => renderThreadRow(t as Thread))}
       </div>
     )
   }
@@ -1118,41 +1126,39 @@ export function ThreadList() {
     })
     return (
       <>
         {timeline.today.length > 0 && (
           <div>
-            <div style={styles.groupHeader} onClick={() => togglePinned("today")}>
+            <div style={styles.groupHeader}>
               {renderGroupCheckbox(
                 timeline.today.map((t) => t.id),
                 "今天",
               )}
-              <span style={styles.groupChevron}>{todayOpen ? "▼" : "▶"}</span>
-              <span style={styles.groupLabel}>今天 · {timeline.today.length}</span>
+              <button type="button" className="cm-history-group" aria-expanded={todayOpen} onClick={() => togglePinned("today")}><span aria-hidden="true" style={styles.groupChevron}>{todayOpen ? "▼" : "▶"}</span> 今天 · {timeline.today.length}</button>
             </div>
             {todayOpen && timeline.today.map((t) => renderThreadRow(t as Thread))}
           </div>
         )}
 
         {timeline.yesterday.length > 0 && (
           <div>
-            <div style={styles.groupHeader} onClick={() => togglePinned("yesterday")}>
+            <div style={styles.groupHeader}>
               {renderGroupCheckbox(
                 timeline.yesterday.map((t) => t.id),
                 "昨天",
               )}
-              <span style={styles.groupChevron}>{yesterdayOpen ? "▼" : "▶"}</span>
-              <span style={styles.groupLabel}>昨天 · {timeline.yesterday.length}</span>
+              <button type="button" className="cm-history-group" aria-expanded={yesterdayOpen} onClick={() => togglePinned("yesterday")}><span aria-hidden="true" style={styles.groupChevron}>{yesterdayOpen ? "▼" : "▶"}</span> 昨天 · {timeline.yesterday.length}</button>
             </div>
             {yesterdayOpen && timeline.yesterday.map((t) => renderThreadRow(t as Thread))}
           </div>
         )}
 
         {timeline.months.map(renderMonth)}
 
         {filtered.length === 0 && (
           <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
-            {threads.length === 0 ? "暂无线程，点击「+ 新建」" : "无匹配线程"}
+            {threads.length === 0 ? "暂无线程，可从导航创建新对话" : "无匹配线程"}
           </div>
         )}
       </>
     )
   }
@@ -1334,11 +1340,11 @@ export function ThreadList() {
         onClick={() => setOpen(!open)}
         title="历史对话"
         aria-label="历史对话"
         aria-expanded={open}
       >
-        <IconChevronDown size={18} />
+        <IconHistory size={17} />
       </button>
 
       {open &&
         panelBox &&
         typeof document !== "undefined" &&
@@ -1351,10 +1357,11 @@ export function ThreadList() {
               setMenuOpen(false)
               if (selectMode) exitSelectMode()
             }}
           />
           <div
+            ref={historyRef} className="cm-history-panel" role="dialog" aria-label="历史对话列表" aria-modal="false"
             style={{
               ...styles.panel,
               position: "fixed",
               top: panelBox.top,
               left: 8,
@@ -1362,10 +1369,11 @@ export function ThreadList() {
               width: "auto",
               maxHeight: Math.min(panelMaxHeight, panelBox.maxHeight),
               zIndex: 10050,
             }}
           >
+            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>历史对话</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
             <div style={styles.panelHeader}>
               <div style={styles.viewToggle}>
                 <button
                   type="button"
                   style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
diff --git a/chrome-extension/src/sidepanel/ui/tokens.ts b/chrome-extension/src/sidepanel/ui/tokens.ts
index 0f952bd2..c1db5edf 100644
--- a/chrome-extension/src/sidepanel/ui/tokens.ts
+++ b/chrome-extension/src/sidepanel/ui/tokens.ts
@@ -1,6 +1,6 @@
-// Shared visual tokens — consumer assistant canon (看山 quality bar, Comp A).
+// Shared visual tokens — #469 calm workspace; root DESIGN.md governs direction.
 // White companion surface. Indigo spark: character pupils + armed send + a
 // hairline on the user bubble. The user bubble is NOT a filled indigo slab.
 // (#321 PR-4 canon revision: the old header said "indigo only on character +
 // armed send" while userBubbleBg === accent — that contradiction is closed here,
 // not papered over as "aligning with canon".)
@@ -12,18 +12,20 @@ export const tokens = {
   fontMono: "ui-monospace, 'SF Mono', Menlo, Consolas, monospace",
 
   // Light companion canvas
   bg: "#ffffff",
   bgElevated: "#ffffff",
-  bgMuted: "#f4f4f5",
-  bgHover: "#f4f4f5",
+  bgMuted: "#f7f7f5",
+  bgHover: "#eeeeec",
+  actionPrimary: "#242424",
+  navSelected: "#e9e9e6",
   bgActive: "#eef2ff",
   border: "rgba(23, 23, 23, 0.10)",
   borderStrong: "rgba(23, 23, 23, 0.14)",
   text: "#171717",
-  textSecondary: "#737373",
-  textMuted: "#a3a3a3",
+  textSecondary: "#666666",
+  textMuted: "#767676",
   /** Empty-state hero only — not chrome. */
   emptyTitle: 22,
 
   // Indigo accent — spark for CTA / focus / armed send / bubble hairline
   accent: "#4f46e5",
@@ -73,12 +75,12 @@ export const tokens = {
   /** 3–4px accent line under StatusRail when L1/L2 (not full tint fill) */
   modeBrowserLine: "rgba(79, 70, 229, 0.35)",
   modeComputerLine: "rgba(52, 211, 153, 0.45)",
 
   // Dark surface (L2 / Cockpit)
-  darkBg: "#0b0d12",
-  darkElevated: "#141820",
+  darkBg: "#171717",
+  darkElevated: "#222222",
   darkBorder: "rgba(255, 255, 255, 0.08)",
   darkText: "#f1f5f9",
   darkMuted: "#94a3b8",
   darkAccent: "#818cf8",
   darkLive: "#34d399",
@@ -88,14 +90,14 @@ export const tokens = {
   darkWarningBg: "#422006",
   darkSuccess: "#34d399",
 
   // Chat bubbles — PR-4 shipped variant A (paper + hairline). Variant B
   // (left indigo bar) is a screenshot alternative, not the live token.
-  userBubbleBg: "#ffffff",
+  userBubbleBg: "#f3f3f1",
   /** User-bubble copy. Distinct from userBubbleText (on-accent/on-danger glyphs). */
   userBubbleInk: "#171717",
-  userBubbleBorder: "rgba(79, 70, 229, 0.18)",
+  userBubbleBorder: "rgba(23, 23, 23, 0.04)",
   /**
    * On-accent / on-danger glyph (send armed, filled buttons). Historical name
    * `userBubbleText` kept so Settings/danger buttons do not silently go dark.
    * User bubble copy uses `userBubbleInk`.
    */
@@ -109,11 +111,11 @@ export const tokens = {
 
   // Shape: controls 6/8/12; composer matches 看山 invitation (16)
   radiusSm: 6,
   radiusMd: 8,
   radiusLg: 12,
-  radiusComposer: 16,
+  radiusComposer: 20,
   radiusBubble: 14,
   /** Bottom sheet / 装配 drawer top corners */
   radiusSheet: 16,
   /** Popup menus (StatusRail ⋯ / panel ⋮) */
   radiusMenu: 10,
diff --git a/chrome-extension/src/terminal/TerminalApp.tsx b/chrome-extension/src/terminal/TerminalApp.tsx
index e9f06f93..d82dd934 100644
--- a/chrome-extension/src/terminal/TerminalApp.tsx
+++ b/chrome-extension/src/terminal/TerminalApp.tsx
@@ -45,12 +45,12 @@ export function TerminalApp() {
       fontSize: 13,
       cursorBlink: true,
       convertEol: false,
       scrollback: 5000,
       theme: {
-        background: "#1e1e28",
-        foreground: "#e8e8ee",
+        background: tokens.darkBg,
+        foreground: tokens.darkText,
       },
     })
     const fit = new FitAddon()
     term.loadAddon(fit)
     term.open(host)
@@ -214,21 +214,31 @@ export function TerminalApp() {
       submitRef.current = null
     }
   }, [])
 
   return (
-    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#1e1e28" }}>
-      <div
+    <div className="cm-terminal" style={{ display: "flex", flexDirection: "column", height: "100dvh", background: tokens.darkBg, fontFamily: tokens.font }}>
+      <style>{`
+        .cm-terminal{font-size:13px;line-height:1.6}
+        .cm-terminal button{min-height:36px;border:1px solid ${tokens.darkBorder};border-radius:8px;background:${tokens.darkElevated};color:${tokens.darkText};padding:6px 12px;cursor:pointer;font:inherit}
+        .cm-terminal button:disabled{opacity:.5;cursor:not-allowed}
+        .cm-terminal textarea{box-sizing:border-box;border:1px solid ${tokens.darkBorder};border-radius:8px;background:${tokens.darkElevated};color:${tokens.darkText};padding:12px;font-family:${tokens.fontMono};font-size:12px;resize:vertical}
+        .cm-terminal :focus-visible{outline:2px solid ${tokens.darkAccent};outline-offset:2px}
+        .cm-terminal summary{cursor:pointer;font-weight:600;min-height:32px}
+        .cm-terminal [role=status]{display:block;margin-top:8px;color:${tokens.darkMuted}}
+        @media(max-width:480px){.cm-terminal-header{flex-wrap:wrap;gap:6px!important}.cm-terminal details{padding:10px 12px!important}}
+      `}</style>
+      <div className="cm-terminal-header"
         style={{
           display: "flex",
           alignItems: "center",
           gap: 12,
-          padding: "8px 14px",
-          background: "#262631",
-          color: "#e8e8ee",
+          padding: "14px 20px",
+          background: tokens.darkElevated,
+          color: tokens.darkText,
           fontSize: 12,
-          borderBottom: "1px solid rgba(255,255,255,0.08)",
+          borderBottom: `1px solid ${tokens.darkBorder}`,
         }}
       >
         <strong>内嵌终端</strong>
         <span style={{ opacity: 0.7 }}>
           {status === "running" ? "运行中" : STATUS_COPY[status]}
@@ -242,11 +252,11 @@ export function TerminalApp() {
         >
           关闭
         </button>
       </div>
       {reviewPrompt && (
-        <details style={{ color: "#e8e8ee", padding: "8px 14px", maxHeight: "48vh", overflow: "auto", flexShrink: 0 }} open>
+        <details style={{ color: tokens.darkText, padding: "14px 20px", maxHeight: "48vh", overflow: "auto", flexShrink: 0 }} open>
           <summary>代码审阅任务与报告回传</summary>
           <p>在下方终端自行启动已安装的 Agent，再将提示词粘贴到 Agent 内。请勿粘贴到 shell 命令行。</p>
           <textarea aria-label="审阅提示词" readOnly value={reviewPrompt} style={{ width: "100%", height: 100 }} />
           <button type="button" onClick={() => navigator.clipboard.writeText(reviewPrompt).catch(() => setReportStatus("复制失败，请手动复制提示词"))}>复制审阅提示词</button>
           <p>将 Agent 输出的 JSON 报告粘贴在此，核对完整内容后提交。确认表示同意导入，不代表代码或测试通过。</p>
diff --git a/chrome-extension/src/thread-graph/ThreadGraphApp.tsx b/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
index feec310a..948e0099 100644
--- a/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
+++ b/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
@@ -40,11 +40,11 @@ import {
 } from "./tag-colors"
 import { buildLayoutSignature } from "./layout-signature"
 
 /** Obsidian-adjacent local palette (graph canvas). */
 const G = {
-  canvas: "#0d0f14",
+  canvas: tokens.darkBg,
   edgeHard: "rgba(148, 163, 184, 0.42)",
   edgeSoft: "rgba(148, 163, 184, 0.18)",
   edgeDim: "rgba(148, 163, 184, 0.06)",
   edgeHot: "rgba(165, 180, 252, 0.75)",
   label: "rgba(226, 232, 240, 0.7)",
@@ -979,14 +979,14 @@ export function ThreadGraphApp() {
     </div>
   )
 }
 
 const glass: CSSProperties = {
-  background: "rgba(20, 24, 32, 0.88)",
+  background: tokens.darkElevated,
   border: `1px solid ${tokens.darkBorder}`,
   boxShadow: "0 8px 28px rgba(0,0,0,0.35), 0 1px 0 rgba(255,255,255,0.04) inset",
-  backdropFilter: "blur(12px)",
+  // Solid surface keeps graph controls legible without translucent layering.
   WebkitBackdropFilter: "blur(12px)",
 }
 
 const styles: Record<string, CSSProperties> = {
   page: {
diff --git a/companion/src/settings-web.ts b/companion/src/settings-web.ts
index 639aabf4..8bf684d6 100644
--- a/companion/src/settings-web.ts
+++ b/companion/src/settings-web.ts
@@ -524,17 +524,17 @@ export const SETTINGS_HTML = `<!DOCTYPE html>
  * ~1157; it mirrors the light family, this surface mirrors the dark family).
  * NEVER reintroduce Material palette hexes here (tokens.ts:185 bans them on
  * the side panel; same rule now applies to this surface).
  */
 :root{
-  --bg:#0b0d12;            /* tokens.darkBg */
-  --elevated:#141820;      /* tokens.darkElevated */
+  --bg:#171717;            /* tokens.darkBg */
+  --elevated:#222222;      /* tokens.darkElevated */
   --border:rgba(255,255,255,0.08);  /* tokens.darkBorder */
   --border-strong:rgba(255,255,255,0.16);
   --text:#f1f5f9;          /* tokens.darkText */
   --muted:#94a3b8;         /* tokens.darkMuted */
-  --faint:#64748b;         /* muted-2 级（hint/env 弱文本） */
+  --faint:#94a3b8;         /* muted-2 级（hint/env 弱文本） */
   --accent:#818cf8;        /* tokens.darkAccent (indigo-400) */
   --on-accent:#fff;
   --success:#34d399;       /* tokens.darkSuccess */
   --success-soft:rgba(52,211,153,0.12);
   --danger:#f87171;        /* tokens.darkDanger */
@@ -542,19 +542,19 @@ export const SETTINGS_HTML = `<!DOCTYPE html>
   --warning:#fbbf24;       /* tokens.darkWarning */
   --warning-soft:rgba(251,191,36,0.12);
   --success-border:rgba(52,211,153,0.3);
   --danger-border:rgba(248,113,113,0.3);
   --warning-border:rgba(251,191,36,0.25);
-  --field-bg:#1c2230;      /* input 底：darkElevated 上加一层（替代原 Material 输入蓝） */
+  --field-bg:#2a2a2a;      /* input 底：darkElevated 上加一层（替代原 Material 输入蓝） */
   --field-border:rgba(255,255,255,0.12);
   --radius:12px;--radius-sm:8px;
   --font-ui:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
 }
 *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
 body{font-family:var(--font-ui);background:var(--bg);color:var(--text);min-height:100vh;display:flex;justify-content:center;padding:24px 16px}
-.container{max-width:600px;width:100%}
-.card{background:var(--elevated);border-radius:var(--radius);padding:28px 32px;box-shadow:0 4px 24px rgba(0,0,0,0.3)}
+.container{max-width:720px;width:100%}
+.card{background:var(--elevated);border-radius:var(--radius);padding:28px 32px;border:1px solid var(--border);box-shadow:none}
 h1{font-size:20px;font-weight:600;margin-bottom:4px;display:flex;align-items:center;gap:8px}
 .status-dot{width:8px;height:8px;border-radius:50%;background:var(--success);margin-left:auto;flex-shrink:0}
 .status-dot.offline{background:var(--danger)}
 .subtitle{font-size:12px;color:var(--muted);margin-bottom:24px}
 .divider{height:1px;background:var(--border);margin:20px 0}
@@ -578,17 +578,23 @@ input:focus{border-color:var(--accent)}
 .result.error{display:block;background:var(--danger-soft);color:var(--danger);border:1px solid var(--danger-border)}
 .input-row{display:flex;gap:6px}
 .input-row input{flex:1}
 .btn-icon{padding:8px 10px;background:var(--field-bg);border:1px solid var(--field-border);border-radius:var(--radius-sm);color:var(--muted);cursor:pointer;font-size:13px;line-height:1}
 .btn-icon:hover{color:var(--text);border-color:var(--accent)}
-.hint{font-size:11px;color:var(--faint);margin-top:4px}
+.hint{font-size:12px;color:var(--faint);margin-top:4px}
 .presets{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
 .preset{padding:3px 10px;background:var(--field-bg);border:1px solid var(--border);border-radius:12px;font-size:11px;color:var(--muted);cursor:pointer;transition:all 0.2s}
 .preset:hover{color:var(--text);border-color:var(--accent)}
 .env-banner{display:none;margin-top:16px;padding:10px 14px;background:var(--warning-soft);border:1px solid var(--warning-border);border-radius:var(--radius-sm);font-size:12px;color:var(--warning);line-height:1.5}
 .saved-flash{position:fixed;top:20px;left:50%;transform:translateX(-50%);background:var(--success);color:var(--bg);padding:8px 20px;border-radius:var(--radius-sm);font-size:13px;opacity:0;transition:opacity 0.3s;pointer-events:none}
 .saved-flash.show{opacity:1}
+
+/* #469 visual-only: API, secrets and confirmation behavior unchanged. */
+button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--accent);outline-offset:3px}
+.btn,.btn-icon{min-height:36px}.input-row input{min-width:0}
+@media(max-width:480px){body{padding:12px 8px}.card{padding:20px 16px}h1{font-size:18px}.actions{gap:8px}}
+@media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
 </style>
 </head>
 <body>
 <div class="container">
   <div class="card">
diff --git a/companion/src/summoner-web.ts b/companion/src/summoner-web.ts
index 061a5a5f..5df4fa21 100644
--- a/companion/src/summoner-web.ts
+++ b/companion/src/summoner-web.ts
@@ -1152,20 +1152,20 @@ const SUMMONER_HTML = `<!DOCTYPE html>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>CMspark</title>
 <style>
 :root{
-  --paper:#fff;--canvas:#f4f4f5;--rail-bg:#fafafa;--text:#171717;--secondary:#525252;
-  --faint:#737373;--line:rgba(23,23,23,.08);--indigo:#4f46e5;--indigo-soft:#eef2ff;
-  --radius:16px;--radius-sm:10px;--rail:52px;--list:216px;
+  --paper:#fff;--canvas:#f7f7f5;--rail-bg:#f7f7f5;--text:#171717;--secondary:#525252;
+  --faint:#666666;--line:rgba(23,23,23,.08);--indigo:#4f46e5;--indigo-soft:#eef2ff;
+  --radius:20px;--radius-sm:10px;--rail:52px;--list:216px;
   --focus:0 0 0 2px #fff,0 0 0 4px var(--indigo);
   --shadow:0 1px 0 var(--line),0 18px 40px rgba(23,23,23,.10);
 }
 *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
 html,body{height:100%;width:100%;overflow:hidden}
 body{
-  font:13px/1.45 "Segoe UI","Microsoft YaHei UI","PingFang SC","Noto Sans SC",sans-serif;
+  font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei UI","PingFang SC","Noto Sans SC",sans-serif;
   color:var(--text);background:var(--paper);
 }
 .hud{height:100%;display:flex;flex-direction:column;background:var(--paper);overflow:hidden;position:relative}
 .body{display:none;flex:1;min-height:0;border-bottom:1px solid var(--line);overflow:hidden}
 .hud.expanded .body{display:flex;flex-direction:column}
@@ -1307,11 +1307,11 @@ body{
   width:52px;height:52px;border-radius:50%;background:#171717;color:#fff;
   display:grid;place-items:center;font-size:20px;font-weight:600;margin:0 auto 10px;
 }
 .mark.sm{width:26px;height:26px;font-size:11px;margin:0}
 .log{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding:20px 22px;display:flex;flex-direction:column;gap:16px}
-.msg{max-width:36rem;font-size:14px;line-height:1.55;word-break:break-word}
+.msg{max-width:46rem;font-size:14px;line-height:1.7;word-break:break-word}
 .msg.user{align-self:flex-end;background:var(--canvas);padding:8px 12px;border-radius:12px 12px 4px 12px;white-space:pre-wrap}
 .msg.assistant{align-self:flex-start;color:var(--text);white-space:normal}
 .msg.assistant p{margin:0 0 8px}
 .msg.assistant p:last-child{margin:0}
 .msg.assistant h1,.msg.assistant h2,.msg.assistant h3{font-size:15px;font-weight:600;margin:10px 0 6px}
@@ -1339,19 +1339,19 @@ body{
 .icon-btn:hover{background:var(--canvas)}
 .icon-btn:focus-visible{outline:none;box-shadow:var(--focus)}
 .icon-btn:disabled{opacity:.35;cursor:not-allowed}
 .field{
   flex:1;display:flex;align-items:flex-end;gap:4px;min-height:48px;padding:4px 8px 4px 14px;
-  background:var(--canvas);border-radius:14px;min-width:0;overflow:hidden;
+  background:var(--paper);border:1px solid var(--line);border-radius:20px;min-width:0;overflow:hidden;
 }
 .field:focus-within{box-shadow:inset 0 0 0 1.5px rgba(79,70,229,.45);background:var(--paper)}
 .field textarea{
   flex:1;min-width:0;width:100%;border:0;background:transparent;outline:none;resize:none;min-height:36px;max-height:120px;
   font:15px/1.35 inherit;color:var(--text);padding:8px 0;
 }
 .field .icon-btn{position:relative;z-index:1}
-.field textarea::placeholder{color:#a3a3a3}
+.field textarea::placeholder{color:var(--faint)}
 .ghosts{display:flex;gap:4px;padding:0 12px 4px}
 .ghost{
   border:0;background:transparent;color:var(--faint);font:11px inherit;padding:6px 8px;border-radius:8px;cursor:pointer;min-height:32px;
 }
 .ghost:hover{background:var(--canvas);color:var(--text)}
@@ -1394,10 +1394,15 @@ body{
 #meetingStart[aria-pressed="true"]{background:var(--indigo-soft);color:var(--indigo)}
 #mic[aria-pressed="true"]{background:var(--indigo-soft);color:var(--indigo)}
 .hud:not(.expanded) .ghosts{display:none}
 .hud.expanded .ghosts{display:none}
 .hud.expanded .hint{display:none}
+
+/* #469 shared workspace craft; transport and capture ACL are unchanged. */
+button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid var(--indigo);outline-offset:2px}
+@media(min-width:760px){.log,.composer{width:100%;max-width:780px;margin-left:auto;margin-right:auto}.brand{padding:16px 24px 12px}}
+@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
 </style>
 </head>
 <body>
 <div class="hud expanded" id="hud">
   <div class="body">


FULL chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
import { useEffect, useRef, useState, type ReactNode } from "react"
import { useAgentStore } from "../store/agentStore"
import { displayThreadTitle, threadRecency } from "../utils/thread-timeline"
import { tokens } from "../ui/tokens"
import { CompanionMark, IconNewChat, IconSettings } from "../ui/icons"
import { CONTEXT_PANEL_TABS, useContextPanelHost } from "./ContextPanelHost"
import { createBlankThread } from "./ThreadList"

/** Presentation only: existing store, context loaders and thread.select own data. */
export function WorkspaceFrame({ children }: { children: ReactNode }) {
  const [wide, setWide] = useState(() => window.matchMedia("(min-width: 760px)").matches)
  const [open, setOpen] = useState(false)
  const navRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLElement | null>(null)
  useEffect(() => {
    const trigger = document.querySelector<HTMLElement>(".cm-navigation-toggle")
    trigger?.setAttribute("aria-expanded", String(!wide && open))
    if (!wide && open) {
      triggerRef.current = trigger
      navRef.current?.querySelector<HTMLButtonElement>("button")?.focus()
    }
  }, [wide, open])
  const close = () => { setOpen(false); triggerRef.current?.focus() }
  useEffect(() => {
    const query = window.matchMedia("(min-width: 760px)")
    const resize = () => { setWide(query.matches); setOpen(false) }
    const toggle = () => setOpen(value => !value)
    query.addEventListener("change", resize)
    window.addEventListener("cmspark:toggle-navigation", toggle)
    return () => { query.removeEventListener("change", resize); window.removeEventListener("cmspark:toggle-navigation", toggle) }
  }, [])
  return <div className="cm-workspace">
    {wide && <WorkspaceNavigation onNavigate={() => {}} />}
    {!wide && open && <div ref={navRef} className="cm-navigation-disclosure" role="dialog" aria-modal="false" aria-label="工作区导航" onKeyDown={event => {
      if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); close() }
    }}>
      <WorkspaceNavigation onNavigate={close} onClose={close} />
    </div>}
    <main className="cm-workspace-main" aria-label="对话工作区">{children}</main>
  </div>
}

function WorkspaceNavigation({ onNavigate, onClose }: { onNavigate: () => void; onClose?: () => void }) {
  const { state, dispatch } = useAgentStore()
  const { activePanel, openPanelForce, closePanel } = useContextPanelHost()
  const [query, setQuery] = useState("")
  const recent = state.threads.filter(t => !t.trashed_at && displayThreadTitle(t).toLocaleLowerCase().includes(query.toLocaleLowerCase())).sort((a, b) => threadRecency(b).localeCompare(threadRecency(a))).slice(0, 30)
  return <aside className="cm-navigation" aria-label="工作区">
    <div className="cm-nav-brand"><CompanionMark size={24} /><strong>CMspark</strong>
      {onClose && <button type="button" className="cm-icon-button" aria-label="关闭导航" onClick={onClose}>×</button>}
    </div>
    <button type="button" className="cm-nav-new" onClick={() => { createBlankThread(dispatch); onNavigate() }}><IconNewChat size={17} />新对话</button>
    <nav aria-label="资源与能力" className="cm-nav-resources">
      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" aria-pressed={activePanel === id} onClick={() => {
        dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
      }}><Icon size={16} /><span>{label}</span></button>)}
    </nav>
    <div className="cm-nav-section"><span>最近对话</span></div>
    <input className="cm-nav-search" aria-label="筛选最近对话" placeholder="查找对话…" value={query} onChange={e => setQuery(e.target.value)} />
    <div className="cm-nav-threads">
      {recent.map(thread => <button type="button" className="cm-nav-thread" key={thread.id} aria-current={thread.id === state.activeThreadId ? "page" : undefined}
        title={displayThreadTitle(thread)} onClick={() => {
          dispatch({ type: "SET_ACTIVE_THREAD", threadId: thread.id }); chrome.runtime.sendMessage({ type: "thread.select", threadId: thread.id }); onNavigate()
        }}><span>{displayThreadTitle(thread)}</span>{state.threadBusyById[thread.id] && <span className="cm-nav-running" aria-label="运行中">·</span>}</button>)}
      {!recent.length && <p className="cm-nav-empty">{query ? "没有匹配的对话" : "新对话会保存在这里"}</p>}
    </div>
    <button type="button" className="cm-nav-item cm-nav-settings" onClick={() => { closePanel(); dispatch({ type: "SET_SETTINGS_OPEN", open: true }); onNavigate() }}><IconSettings size={16} />设置</button>
  </aside>
}


FULL chrome-extension/src/sidepanel/ui/workspace-styles.ts
import { tokens } from "./tokens"

/** Scoped shell styles; colors remain owned by tokens.ts. */
export const workspaceCSS = `
.cm-workspace{display:flex;height:100dvh;min-height:0;width:100%;overflow:hidden;background:${tokens.bg};font-family:${tokens.font};color:${tokens.text}}
.cm-workspace-main{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;position:relative}
.cm-navigation{width:220px;height:100%;box-sizing:border-box;flex-shrink:0;display:flex;flex-direction:column;padding:20px 12px 12px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};gap:6px;overflow-y:auto}
[aria-label="工作区导航"] .cm-navigation{width:100%}
.cm-nav-brand{display:flex;align-items:center;gap:10px;padding:0 8px 20px;font-size:15px;letter-spacing:-.03em}
.cm-nav-brand .cm-icon-button{margin-left:auto}
.cm-nav-new,.cm-nav-item,.cm-nav-thread{font:inherit;border:0;border-radius:${tokens.radiusMd}px;cursor:pointer;display:flex;align-items:center;gap:10px;text-align:left;min-height:36px;width:100%;padding:8px 10px;color:${tokens.text};background:transparent;font-size:13px;flex-shrink:0}
.cm-nav-new{background:${tokens.bgElevated};border:1px solid ${tokens.border};margin-bottom:10px;font-weight:500}
.cm-nav-item:hover,.cm-nav-thread:hover,.cm-icon-button:hover{background:${tokens.bgHover}}
.cm-nav-resources{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-bottom:16px}
.cm-nav-resources .cm-nav-item{font-size:12px;gap:6px;padding:8px 6px;min-width:0}
.cm-nav-resources .cm-nav-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cm-nav-section{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:${tokens.textSecondary};padding:0 8px}
.cm-nav-search{box-sizing:border-box;width:100%;border:1px solid ${tokens.border};border-radius:${tokens.radiusMd}px;padding:9px 10px;font:inherit;font-size:12px;background:${tokens.bgElevated};color:${tokens.text}}
.cm-nav-threads{flex:1;min-height:80px;overflow-y:auto;margin-top:4px}
.cm-nav-thread{min-height:38px;color:${tokens.textSecondary}}
.cm-nav-thread>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.cm-nav-item[aria-pressed="true"],.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
.cm-nav-running{color:${tokens.success};font-size:20px}
.cm-nav-empty{font-size:12px;color:${tokens.textSecondary};padding:8px}
.cm-nav-settings{margin-top:12px;border-top:1px solid ${tokens.border};border-radius:0;padding-top:14px}
.cm-icon-button{display:inline-flex;align-items:center;justify-content:center;min-width:32px;min-height:32px;border:0;background:transparent;color:${tokens.textSecondary};border-radius:${tokens.radiusMd}px;cursor:pointer;font-size:18px}
.cm-task-title{font-size:13px;font-weight:500;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-left:8px}
.cm-chat-content,.cm-composer-dock{width:100%;max-width:780px;margin-left:auto;margin-right:auto;box-sizing:border-box}
.cm-composer-dock{padding:12px 20px 18px!important}
.cm-composer-actions{display:flex;align-items:center;gap:8px;min-width:0}
.cm-composer-capsule:focus-within{border-color:${tokens.accent}!important;box-shadow:${tokens.shadowFocus}!important}
.cm-workspace button:focus-visible,.cm-workspace [role="button"]:focus-visible,.cm-workspace input:focus-visible,.cm-workspace textarea:focus-visible,[role="dialog"] button:focus-visible,[role="dialog"] input:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
.cm-workspace button:disabled{cursor:not-allowed}
.cm-settings-categories{display:flex;gap:6px;flex-wrap:wrap;padding:12px 24px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
.cm-settings-categories button{font:inherit;font-size:12px;border:1px solid ${tokens.border};background:${tokens.bgMuted};color:${tokens.text};border-radius:8px;min-height:32px;padding:4px 10px;cursor:pointer}
.cm-settings-panel{width:min(780px,100vw - 32px)!important;max-height:88dvh!important;border-radius:${tokens.radiusSheet}px!important;box-shadow:${tokens.shadowLg}}
.cm-settings-header{padding:20px 24px!important}
.cm-settings-body{padding:8px 24px 24px!important}
.cm-context-panel{max-height:min(36dvh,360px)!important;margin:0 16px;border:1px solid ${tokens.border};border-radius:${tokens.radiusLg}px;box-shadow:${tokens.shadowSm}}
.cm-history-group{flex:1;border:0;background:transparent;color:inherit;font:inherit;text-align:left;min-height:32px;cursor:pointer;padding:4px 0}
.cm-navigation-toggle{gap:4px;flex-shrink:0}
.cm-history-panel{max-width:720px;margin:0 auto}
.cm-history-panel button:focus-visible,.cm-history-panel [role="button"]:focus-visible{outline:2px solid ${tokens.accent};outline-offset:-2px}
@media(min-width:760px){.cm-navigation-toggle{display:none!important}.cm-status-rail{padding:12px 24px!important;border-bottom:1px solid ${tokens.border}!important}.cm-chat-scroll{padding:28px 32px!important}.cm-composer-dock{padding-bottom:24px!important}}
@media(max-width:759px){.cm-workspace{flex-direction:column}.cm-navigation-disclosure{flex-shrink:0;max-height:28dvh;overflow:auto;border-bottom:1px solid ${tokens.border}}.cm-navigation-disclosure .cm-navigation{height:auto;width:100%}.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-panel{align-self:flex-end;width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-categories{padding:8px 16px;max-height:100px;overflow:auto}.cm-settings-body{padding:8px 16px 16px!important}}
@media(max-height:560px){.cm-context-panel{max-height:28dvh!important}.cm-composer-dock{padding-top:4px!important;padding-bottom:6px!important}.cm-navigation{padding-top:10px}.cm-nav-brand{padding-bottom:8px}.cm-nav-resources{margin-bottom:4px}.cm-nav-new{margin-bottom:2px}}
@media(prefers-reduced-motion:reduce){.cm-workspace *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
`


FULL chrome-extension/scripts/test-workspace-ui.py
"""Real App UI, synthetic transport. Run after nvm use22 with uv --with playwright.
No live Companion, external account, installed extension or native shell is used.
"""
import json
import subprocess
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

project = Path(__file__).resolve().parent.parent
shots = Path('/private/tmp/cmspark-469-shots')
shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
    subprocess.run(['node', 'scripts/render-workspace-fixture.cjs', directory], cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width':1440,'height':900})
        page.set_default_timeout(6000)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory)/'index.html').as_uri())
        composer = page.get_by_role('textbox', name='消息内容', exact=True)
        composer.wait_for()
        page.wait_for_function('window.dispatchUI && document.querySelector("textarea") && !document.querySelector("textarea").disabled')
        for width,height in [(1440,900),(800,700),(760,640),(759,640),(390,740),(320,480)]:
            page.set_viewport_size({'width':width,'height':height})
            page.wait_for_timeout(120)
            assert not page.evaluate('document.documentElement.scrollWidth > innerWidth'), (width,height,'horizontal overflow')
            box = composer.bounding_box()
            assert box and box['width'] >= min(220,width-60), (width,box)
            assert box['y'] >= 0 and box['y']+box['height'] <= height, (width,box)
            assert page.get_by_role('button',name='打开工作区导航',exact=True).is_visible() == (width<760)
            if width in (1440,390,320):page.screenshot(path=str(shots/f'empty-{width}.png'))
        # Narrow drawer: initial focus, keyboard close and focus return.
        toggle=page.get_by_role('button',name='打开工作区导航',exact=True)
        toggle.click()
        nav=page.get_by_role('dialog',name='工作区导航',exact=True)
        nav.wait_for()
        assert page.evaluate('document.querySelector("[aria-label=工作区导航]").contains(document.activeElement)')
        page.keyboard.press('Escape')
        assert not nav.is_visible()
        assert toggle.evaluate('(el)=>el===document.activeElement')
        # New task preserves existing action, never sends an Agent message.
        toggle.click()
        nav.get_by_role('button',name='新对话',exact=True).click()
        page.wait_for_function('window.sent.some(x=>x.type==="thread.create")')
        assert not page.evaluate('window.sent.some(x=>x.type==="chat.send" || x.type==="chat.create")')
        # Use original demo thread to keep subsequent fixtures explicitly scoped.
        page.evaluate("window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'demo-0'});window.dispatchUI({type:'SET_MESSAGES',messages:[]})")
        toggle.click()
        nav.get_by_role('button',name='设置',exact=True).click()
        settings=page.get_by_role('dialog',name='设置',exact=True)
        settings.wait_for()
        settings.get_by_role('navigation',name='设置分类').get_by_role('button',name='安全与信任',exact=True).click()
        page.wait_for_timeout(100)
        assert page.locator('[data-settings-section=安全与信任] > button').get_attribute('aria-expanded')=='true'
        page.screenshot(path=str(shots/'settings-320.png'))
        assert page.evaluate('document.querySelector("[aria-label=设置]").contains(document.activeElement)')
        settings.get_by_role('button',name='关闭设置',exact=True).click()
        # Existing history is named and keyboard operable; Escape returns focus.
        history=page.get_by_role('button',name='历史对话',exact=True)
        history.click()
        dialog=page.get_by_role('dialog',name='历史对话列表',exact=True)
        dialog.wait_for()
        row=dialog.get_by_role('button',name='打开 发布 v2.8',exact=False).first
        row.focus();page.keyboard.press('Enter')
        assert not dialog.is_visible()
        assert page.evaluate('window.sent.some(x=>x.type==="thread.select" && x.threadId==="demo-0")')
        history.click();dialog.wait_for();page.wait_for_timeout(100);page.keyboard.press('Escape')
        assert not dialog.is_visible()
        assert history.evaluate('(el)=>el===document.activeElement')
        # Context panel fits the short viewport; closes without losing composer.
        toggle.click();nav.get_by_role('button',name='知识',exact=True).click()
        context=page.get_by_test_id('context-panel-host')
        context.wait_for()
        assert context.bounding_box()['height'] <= 480*.28+2
        assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
        page.get_by_role('button',name='收起面板',exact=True).click()
        # Long content + actual tool card disclosure are keyboard operable.
        messages=[{'id':'u1','thread_id':'demo-0','role':'user','content':'请核对支付服务 v2.8 的需求、代码与测试，整理变更材料。','created_at':'2026-09-07T10:00:00Z'},
          {'id':'a1','thread_id':'demo-0','role':'assistant','content':'已整理当前证据。\n\n### 需要补充的内容\n\n- 需求与开发任务已建立关联。\n- 测试对应提交仍待核对。\n\n'+'`https://devops.example.test/'+('long-path/'*25)+'`', 'created_at':'2026-09-07T10:01:00Z',
           'tool_calls':[{'id':'tc1','tool_name':'get_page_text','params':{},'status':'success','result':{'success':True,'data':{'content':'这是来自合成测试网页的实际展示文本。'*80}}}]}]
        page.evaluate('(messages)=>window.dispatchUI({type:"SET_MESSAGES",messages})',messages)
        page.set_viewport_size({'width':1440,'height':900})
        details=page.get_by_role('button',name='展开 get_page_text 详情',exact=True)
        details.focus();page.keyboard.press('Enter')
        assert page.get_by_role('button',name='收起 get_page_text 详情',exact=True).get_attribute('aria-expanded')=='true'
        page.screenshot(path=str(shots/'conversation-1440.png'))
        # Confirmation queue is still rendered by the unchanged production gate.
        confirmation={'confirmation_id':'fixture-confirm','tool_name':'shell_exec','dangerous_apis':['shell'], 'code_preview':'git diff base..head','risk_level':'high','requested_at':'2026-09-07T10:00:00Z','timeout_ms':45000}
        page.get_by_role('navigation',name='资源与能力').get_by_role('button',name='知识',exact=True).click()
        page.evaluate('(request)=>window.dispatchUI({type:"ADD_SECURITY_CONFIRMATION",request})',confirmation)
        page.set_viewport_size({'width':320,'height':480})
        page.wait_for_timeout(100)
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
        gate=page.get_by_role('alertdialog').first
        for name in ['允许','拒绝','停止']:
            button=gate.get_by_role('button',name=name,exact=True)
            box=button.bounding_box()
            assert box and 0 <= box['y'] and box['y']+box['height'] <= 480
            assert button.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        toggle.click();nav.wait_for()
        for name in ['允许','拒绝','停止']:
            assert gate.get_by_role('button',name=name,exact=True).evaluate('(el)=>{const r=el.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        nav.get_by_role('button',name='关闭导航').click()
        page.screenshot(path=str(shots/'confirmation-320.png'))
        assert not page.evaluate('window.sent.some(x=>x.type==="security.confirmation.response")')
        page.evaluate("window.dispatchUI({type:'REMOVE_SECURITY_CONFIRMATION',confirmationId:'fixture-confirm'});window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:true})")
        stop=page.get_by_role('button',name='停止本轮',exact=True)
        stop.wait_for()
        assert stop.bounding_box()['y']+stop.bounding_box()['height'] <= 480
        page.get_by_role('button',name='纠偏',exact=True).wait_for()
        page.get_by_role('button',name='排队',exact=True).wait_for()
        toggle.click();nav.wait_for()
        assert stop.evaluate('(el)=>{const r=el.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        nav.get_by_role('button',name='关闭导航').click()
        page.screenshot(path=str(shots/'running-320.png'))
        page.evaluate("window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:false});window.dispatchUI({type:'SET_CONNECTION',state:'disconnected'})")
        page.get_by_role('button',name='重新连接',exact=True).wait_for()
        assert composer.is_disabled()
        page.screenshot(path=str(shots/'offline-320.png'))
        # 200% equivalent CSS viewport reflow + reduced motion (actual media).
        page.emulate_media(reduced_motion='reduce')
        page.set_viewport_size({'width':720,'height':450})
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert page.locator('.cm-workspace').evaluate('(el)=>getComputedStyle(el).scrollBehavior')=='auto'
        assert not errors, errors
        browser.close()
print('PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, reflow/reduced motion. Synthetic transport only.')


FULL companion/scripts/test-web-surfaces-ui.py
"""Presentation-only checks of the real HTML constants; scripts removed, no services."""
from pathlib import Path
import re, subprocess, tempfile
from playwright.sync_api import sync_playwright
project=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-469-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
    subprocess.run(['node','scripts/render-web-surface-fixtures.cjs',out],cwd=project,check=True)
    with sync_playwright() as p:
        browser=p.chromium.launch(channel='chrome',headless=True)
        page=browser.new_page()
        page.route('**/*',lambda route:route.abort())
        for name in ['capture','settings']:
            html=(Path(out)/(name+'.html')).read_text()
            base=subprocess.check_output(['git','show','8656df94:companion/src/'+('summoner-web.ts' if name=='capture' else 'settings-web.ts')],cwd=project,text=True)
            current=(project/'src'/('summoner-web.ts' if name=='capture' else 'settings-web.ts')).read_text()
            assert re.sub(r'<style>.*?</style>','<style/>',base,flags=re.S)==re.sub(r'<style>.*?</style>','<style/>',current,flags=re.S), 'HTML behavior changed'
            page.set_content(re.sub(r'<script\b[^>]*>.*?</script>','',html,flags=re.S))
            for width,height in [(320,480),(390,740),(900,800)]:
                page.set_viewport_size({'width':width,'height':height})
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),(name,width)
                page.screenshot(path=str(shots/f'{name}-{width}.png'))
        browser.close()
print('PASS: capture/settings real HTML CSS reflow; non-style source byte-identical to base. Scripts not executed.')


DEPENDENCY chrome-extension/src/sidepanel/mode/mode-controller.ts
// Pure ModeController — no React, no chrome APIs.
// Spec: docs/superpowers/specs/2026-07-26-ui-three-mode-redesign.md
// C11: tool class tables derived from SURFACE_BY_TOOL (surface-by-tool.ts).

import type { CapabilityLevel } from "../types"
import { toolsAtSurface } from "./surface-by-tool"

/** Browser CDP/extension tools that elevate to L1 (not host_*). */
export const BROWSER_TOOL_NAMES: ReadonlySet<string> = toolsAtSurface("L1")

/** Desktop-class tools that elevate to L2 via confirm queue even without live task. */
export const COMPUTER_CLASS_TOOLS: ReadonlySet<string> = toolsAtSurface("L2")

export const DEFAULT_QUIESCENCE_MS = 30_000

export type ComputerTaskStatusInput = "running" | "paused" | "finished" | null

export interface ModeInput {
  now: number
  computerTaskStatus: ComputerTaskStatusInput
  /** When status is finished, keep L2 until now - finishedAt <= quiescenceMs (D15 stub). */
  computerTaskFinishedAt: number | null
  pendingConfirmToolNames: string[]
  lastBrowserToolAt: number | null
  quiescenceMs: number
  /** User pin: blocks auto-down only (never blocks up). */
  modePin: CapabilityLevel | null
}

export function isBrowserTool(name: string): boolean {
  return BROWSER_TOOL_NAMES.has(name)
}

export function isComputerClassTool(name: string): boolean {
  return COMPUTER_CLASS_TOOLS.has(name)
}

/**
 * Highest-wins derivation.
 * L2: active computer task (running|paused) OR computer-class confirm pending
 * L1: last browser tool within quiescence window
 * L0: else
 * Pin: max(derived, pin) with level order chat < browser < computer
 */
export function deriveCapabilityLevel(input: ModeInput): CapabilityLevel {
  const order: Record<CapabilityLevel, number> = {
    chat: 0,
    browser: 1,
    computer: 2,
  }

  let derived: CapabilityLevel = "chat"

  const taskActive =
    input.computerTaskStatus === "running" ||
    input.computerTaskStatus === "paused"
  const taskFinishedInWindow =
    input.computerTaskStatus === "finished" &&
    input.computerTaskFinishedAt != null &&
    input.now - input.computerTaskFinishedAt <= input.quiescenceMs
  const pendingNames = Array.isArray(input.pendingConfirmToolNames)
    ? input.pendingConfirmToolNames
    : []
  const confirmComputer = pendingNames.some((n) => isComputerClassTool(n))
  const confirmBrowser = pendingNames.some((n) => isBrowserTool(n))

  if (taskActive || taskFinishedInWindow || confirmComputer) {
    derived = "computer"
  } else if (
    confirmBrowser ||
    (input.lastBrowserToolAt != null &&
      input.now - input.lastBrowserToolAt <= input.quiescenceMs)
  ) {
    derived = "browser"
  }

  if (input.modePin) {
    if (order[input.modePin] > order[derived]) {
      return input.modePin
    }
  }

  return derived
}

export type ContextBarTabId =
  | "tabs"
  | "history"
  | "skills"
  | "knowledge"
  | "packs"
  | "meeting"
  | "board"
  | "mcp"
  | "apps"

/**
 * Mode-split context bar tab sets (spec D5 / §4 / P0 IA cut 2026-07-27).
 * L0 Skills·Know·Hist · L1 Tabs·Skills · L2 Panel empty (Cockpit owns Tabs·Apps·MCP).
 * packs/board/mcp/apps demoted from permanent chrome.
 * #321 PR-1: the legacy permanent BottomBar strip is deleted (was PR5-gated off);
 * these helpers still document demotion order and drive Host overflow grouping.
 */
export function contextBarTabsForLevel(
  level: CapabilityLevel,
): ContextBarTabId[] {
  switch (level) {
    case "chat":
      return ["skills", "knowledge", "history"]
    case "browser":
      return ["tabs", "skills"]
    case "computer":
      return []
  }
}

/** Secondary panels (legacy BottomBar overflow set; not permanent tabs). */
export function contextBarOverflowTabsForLevel(
  level: CapabilityLevel,
): ContextBarTabId[] {
  const primary = new Set(contextBarTabsForLevel(level))
  // Prefer product-useful demotions; keep stable order
  const candidates: ContextBarTabId[] = [
    "packs",
    "meeting",
    "board",
    "knowledge",
    "history",
    "tabs",
    "skills",
    "mcp",
    "apps",
  ]
  return candidates.filter((id) => !primary.has(id))
}

export function levelBadgeLabel(
  level: CapabilityLevel,
  opts?: { live?: boolean },
): string {
  switch (level) {
    case "chat":
      return "聊"
    case "browser":
      return "网页"
    case "computer":
      return opts?.live ? "计算机 · LIVE" : "计算机"
  }
}

export function levelEscalateToast(level: CapabilityLevel): string | null {
  switch (level) {
    case "browser":
      return "已升级至网页 Agent — 可操作浏览器标签页"
    case "computer":
      return "已升级至 Computer Use — 桌面操控进行中"
    default:
      return null
  }
}


DEPENDENCY chrome-extension/src/sidepanel/components/SettingsSection.tsx
// Collapsible settings section shell (settings-thread-compact W1).

import type { ReactNode } from "react"
import { tokens } from "../ui/tokens"

export function SettingsSection({
  title,
  open,
  onToggle,
  badge,
  children,
  forceHint,
}: {
  title: string
  open: boolean
  onToggle: () => void
  /** Always-visible when collapsed (e.g. armed trust). */
  badge?: ReactNode
  children: ReactNode
  /** Optional subline under header when force-open (e.g. 未配对). */
  forceHint?: string | null
}) {
  return (
    <section style={styles.section} data-settings-section={title}>
      <button
        type="button"
        style={styles.header}
        onClick={onToggle}
        aria-expanded={open}
      >
        <span style={styles.chevron} aria-hidden>
          {open ? "▼" : "▶"}
        </span>
        <span style={styles.title}>{title}</span>
        {badge != null && <span style={styles.badgeSlot}>{badge}</span>}
      </button>
      {forceHint && !open && (
        <div style={styles.forceHint}>{forceHint}</div>
      )}
      {/* Keep children mounted when closed so arm phrase panels / forms are not torn down (D-S8). */}
      <div
        style={{
          display: open ? "block" : "none",
          paddingTop: 4,
          paddingBottom: 8,
        }}
        aria-hidden={!open}
      >
        {children}
      </div>
    </section>
  )
}

const styles: Record<string, React.CSSProperties> = {
  section: {
    borderBottom: `1px solid ${tokens.border}`,
    marginBottom: 4,
  },
  header: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 0",
    border: "none",
    background: "transparent",
    cursor: "pointer",
    textAlign: "left",
    minHeight: 40,
  },
  chevron: {
    fontSize: 10,
    color: tokens.textMuted,
    width: 12,
    flexShrink: 0,
  },
  title: {
    fontSize: 13,
    fontWeight: 600,
    color: tokens.text,
    flex: 1,
    letterSpacing: "-0.01em",
  },
  badgeSlot: {
    flexShrink: 0,
  },
  forceHint: {
    fontSize: 11,
    color: tokens.warning,
    padding: "0 0 6px 20px",
  },
}


DEPENDENCY chrome-extension/src/sidepanel/utils/settings-sections.ts
// Settings accordion expand state — pure helpers (settings-thread-compact W1).
// Spec: docs/superpowers/specs/2026-08-06-settings-thread-compact-ux.md

export const LS_SETTINGS_EXPAND = "cmspark.settings.expandSections"

/** Canonical section ids (order = IA). */
export const SETTINGS_SECTION_IDS = [
  "connection",
  "model",
  "secrets",
  "security",
  "integrations",
  "export",
  "experimental",
] as const

export type SettingsSectionId = (typeof SETTINGS_SECTION_IDS)[number]

export type SettingsExpandInput = {
  /** User LS preference (section open). */
  userOpen: Set<SettingsSectionId>
  /** WS pairing known + paired */
  wsPaired: boolean | null
  /** F-S3 elevated trust */
  elevatedTrust: boolean
}

/** Default open set when LS empty (before force rules). */
export function defaultUserOpenSections(wsPaired: boolean | null): Set<SettingsSectionId> {
  // Unpaired / unknown: connection + model. Paired: model only (F-UX3).
  if (wsPaired === true) return new Set<SettingsSectionId>(["model"])
  return new Set<SettingsSectionId>(["connection", "model"])
}

export function parseSettingsExpand(raw: string | null): Set<SettingsSectionId> | null {
  if (!raw) return null
  try {
    const arr = JSON.parse(raw)
    if (!Array.isArray(arr)) return null
    const next = new Set<SettingsSectionId>()
    for (const x of arr) {
      if (typeof x === "string" && (SETTINGS_SECTION_IDS as readonly string[]).includes(x)) {
        next.add(x as SettingsSectionId)
      }
    }
    return next
  } catch {
    return null
  }
}

export function serializeSettingsExpand(open: Set<SettingsSectionId>): string {
  return JSON.stringify([...open])
}

/** Elevated trust flags (F-S3 set) — used for armed header badge, not force-open. */
export function isElevatedTrust(flags: {
  auto_approve_dangerous?: boolean
  auto_approve_enterprise_tools?: boolean
  allow_all_schemes?: boolean
  unattendedArmed?: boolean
}): boolean {
  return (
    flags.auto_approve_dangerous === true ||
    flags.auto_approve_enterprise_tools === true ||
    flags.allow_all_schemes === true ||
    flags.unattendedArmed === true
  )
}

/**
 * Effective open map: force rules beat LS (F-UX3 unpaired connection only).
 * - unpaired → force connection open
 * - elevatedTrust no longer force-opens security (2026-08-08 UX): section stays
 *   collapsible; SettingsSlideout still shows armed badge on the header (F-S2).
 * - model default-open on first load via defaultUserOpenSections
 *
 * `elevatedTrust` remains on the input for callers / future soft-open policies.
 */
export function isSectionEffectivelyOpen(
  id: SettingsSectionId,
  input: SettingsExpandInput,
): boolean {
  if (id === "connection" && input.wsPaired !== true) return true
  // elevatedTrust: badge only (SettingsSlideout); do not force-open security
  return input.userOpen.has(id)
}

export function toggleSectionOpen(
  id: SettingsSectionId,
  userOpen: Set<SettingsSectionId>,
): Set<SettingsSectionId> {
  const next = new Set(userOpen)
  if (next.has(id)) next.delete(id)
  else next.add(id)
  return next
}


DEPENDENCY chrome-extension/src/sidepanel/components/ui/Modal.tsx
// Shared modal/overlay primitive (audit M18).
//
// Wraps useModalDialog (focus trap + Escape + focus restore) and applies the
// dialog ARIA contract (role + aria-modal + aria-label/labelledby) so every
// overlay dialog gets consistent keyboard + screen-reader behavior.
//
// Callers pass their OWN overlay + panel styles (position fixed vs absolute,
// z-index, backdrop color, alignment differ per dialog and are kept verbatim)
// and their panel content as children. The outer overlay receives role/aria and
// the backdrop-dismiss click; the inner panel stops propagation so clicks inside
// don't close the dialog.
//
// NOTE: this is for DIALOGS only — things that take focus and trap it. Popovers
// that should NOT steal focus (e.g. SlashCommandPopover, a combobox/listbox) must
// NOT use this; they need listbox semantics instead. See ARIA guidance in WCAG.

import type { CSSProperties, ReactNode, RefObject } from "react"
import { useModalDialog, type UseModalDialogOptions } from "../../hooks/useModalDialog"

export interface ModalProps {
  /** Gate visibility + focus management. Renders null when false. */
  open: boolean
  /** Called on Escape, and on overlay click when backdropDismiss is true. */
  onClose: () => void
  /** Accessible role. Use "alertdialog" for destructive-action gates. */
  role?: "dialog" | "alertdialog"
  /** Accessible name when there's no visible title to point at. */
  ariaLabel?: string
  /** Accessible name pointing at a visible title element's id. Preferred over ariaLabel. */
  ariaLabelledBy?: string
  /** Click on the overlay/backdrop calls onClose. Default true. */
  backdropDismiss?: boolean
  /** Element to focus on open (passed through to useModalDialog). */
  initialFocusRef?: RefObject<HTMLElement>
  /** Restore focus on close (passed through to useModalDialog). */
  restoreFocus?: boolean
  /** Extra effect deps (e.g. a dialog id) — passed through to useModalDialog. */
  deps?: UseModalDialogOptions["deps"]
  /** Style for the overlay/backdrop element (position, z-index, bg, alignment). */
  overlayStyle?: CSSProperties
  /** Style for the inner panel. */
  panelStyle?: CSSProperties
  /** Extra className on the panel if a caller uses CSS classes. */
  panelClassName?: string
  children: ReactNode
}

export function Modal(props: ModalProps) {
  const {
    open,
    onClose,
    role = "dialog",
    ariaLabel,
    ariaLabelledBy,
    backdropDismiss = true,
    initialFocusRef,
    restoreFocus,
    deps,
    overlayStyle,
    panelStyle,
    panelClassName,
    children,
  } = props

  const overlayRef = useModalDialog({ open, onClose, initialFocusRef, restoreFocus, deps })

  if (!open) return null

  const aria = ariaLabelledBy ? { "aria-labelledby": ariaLabelledBy } : { "aria-label": ariaLabel }

  return (
    <div
      ref={overlayRef}
      role={role}
      aria-modal="true"
      {...aria}
      style={overlayStyle}
      onClick={backdropDismiss ? onClose : undefined}
    >
      <div style={panelStyle} className={panelClassName} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  )
}


REAL STORE ACTION
  | { type: "OPEN_SETTINGS_SECTION"; section: string }
  | { type: "CLEAR_SETTINGS_FOCUS" }
  | { type: "SET_TAB_LIST"; tabs: chrome.tabs.Tab[] }
  | { type: "TOGGLE_PIN_TAB"; tabI

REAL STORE REDUCER
    case "OPEN_SETTINGS_SECTION":
      return {
        ...state,
        settingsOpen: true,
        settingsFocusSection: action.section,
      }
    case "CLEAR_SETTINGS_FOCUS":
      return { ...state, settingsFocusSection: null }
    case "SET_TAB_LIST":
      return { ...state, tabList: action.tabs }
    case "TOGGLE_PIN_TAB":
      return {
        ...state,
        pinnedTabIds: state.pinnedTabIds.includes(action.tabId)
          ? state

REAL HOST API AND GATING
// ContextPanelHost — single owner of context panel state, loaders, mounts,
// and cmspark:open-context-panel (UIUX v2 §4.7 M1). Host is SoT for panels.
// #321 PR-1: legacy permanent BottomBar tab strip deleted (was PR5-gated off).

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
} from "react"
import { useAgentStore } from "../store/agentStore"
import {
  contextBarTabsForLevel,
  contextBarOverflowTabsForLevel,
} from "../mode/mode-controller"
import type { CapabilityLevel } from "../types"
import { KnowledgeSubPanel } from "./KnowledgeSubPanel"
import { McpPanel } from "./McpPanel"
import { AppsPanel } from "./AppsPanel"
import { PacksPanel } from "./PacksPanel"
import { BoardPanel } from "./BoardPanel"
import { MeetingPanel } from "./MeetingPanel"
import { tokens } from "../ui/tokens"
import {
  IconTabs,
  IconHistory,
  IconSkills,
  IconKnowledge,
  IconMcp,
  IconApps,
  IconPacks,
  IconMic,
  IconList,
} from "../ui/icons"

// ── Registry ───────────────────────────────────────────────────────────────

export type ContextPanelId =
  | "tabs"
  | "history"
  | "skills"
  | "knowledge"
  | "packs"
  | "board"
  | "mcp"
  | "apps"
  | "meeting"

export type ContextPanelTabDef = {
  id: ContextPanelId
  label: string
  Icon: ComponentType<{ size?: number }>
}

/** Canonical panel registry (labels + icons). Strip and Host share this. */
// #321 PR-5: packs/meeting/board each get their own icon (were all IconSkills
// collisions); icons come from the existing ui/icons set — nothing new drawn.
export const CONTEXT_PANEL_TABS: ContextPanelTabDef[] = [
  { id: "tabs", label: "标签", Icon: IconTabs },
  { id: "history", label: "历史", Icon: IconHistory },
  { id: "skills", label: "技能", Icon: IconSkills },
  { id: "knowledge", label: "知识", Icon: IconKnowledge },
  { id: "packs", label: "场景与专家", Icon: IconPacks },
  { id: "meeting", label: "会议", Icon: IconMic },
  { id: "board", label: "任务板", Icon: IconList },
  { id: "mcp", label: "MCP", Icon: IconMcp },
  { id: "apps", label: "应用", Icon: IconApps },
]

const KNOWN_IDS = new Set(CONTEXT_PANEL_TABS.map((t) => t.id))

export function isContextPanelId(id: string): id is ContextPanelId {
  return KNOWN_IDS.has(id as ContextPanelId)
}

export function contextPanelLabel(id: ContextPanelId): string {
  return CONTEXT_PANEL_TABS.find((t) => t.id === id)?.label ?? id
}

// ── Loaders ────────────────────────────────────────────────────────────────

export function loadPanelData(
  id: ContextPanelId,
  activeThreadId: string | null,
  dispatch: ReturnType<typeof useAgentStore>["dispatch"],
) {
  if (id === "tabs") {
    chrome.tabs.query({}, (tabs) => {
      dispatch({ type: "SET_TAB_LIST", tabs })
    })
  }
  if (id === "history") {
    chrome.runtime.sendMessage({ type: "history.query", limit: 50, thread_id: activeThreadId })
  }
  if (id === "skills") {
    // Force rescan when opening Skills — picks up Finder drops / external edits
    // even if mtime fingerprint was edge-case stale; cheap after ensureFresh path.
    chrome.runtime.sendMessage({ type: "skill.refresh" })
  }
  if (id === "knowledge") {
    chrome.runtime.sendMessage({ type: "knowledge.list" })
  }
  if (id === "packs") {
    chrome.runtime.sendMessage({ type: "pack.list" })
    chrome.runtime.sendMessage({ type: "modules.list" })
  }
  if (id === "mcp") {
    chrome.runtime.sendMessage({ type: "mcp.list" })
  }
  if (id === "apps") {
    chrome.runtime.sendMessage({ type: "apps.list" })
  }
}

// ── Host API context ───────────────────────────────────────────────────────

export type ContextPanelHostApi = {
  activePanel: ContextPanelId | null
  /** Toggle: same id closes; different id opens + loads. */
  openPanel: (id: ContextPanelId) => void
  /** Force-open (no toggle) — used by slash / custom events. */
  openPanelForce: (id: ContextPanelId) => void
  closePanel: () => void
}

const ContextPanelHostContext = createContext<ContextPanelHostApi | null>(null)

export function useContextPanelHost(): ContextPanelHostApi {
  const ctx = useContext(ContextPanelHostContext)
  if (!ctx) {
    throw new Error("useContextPanelHost must be used within ContextPanelHostProvider")
  }
  return ctx
}

/** Soft read for optional chrome that may render outside provider in tests. */
export function useContextPanelHostOptional(): ContextPanelHostApi | null {
  return useContext(ContextPanelHostContext)
}

// ── Provider ───────────────────────────────────────────────────────────────

export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const closePanel = useCallback(() => {
    setActivePanel(null)
  }, [])

  useEffect(() => {
    if (state.settingsOpen) closePanel()
  }, [state.settingsOpen, closePanel])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activeThreadId, dispatch],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      if (activePanel === id) {
        setActivePanel(null)
        return
      }
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activePanel, activeThreadId, dispatch],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      setActivePanel(null)
    }
  }, [activePanel, allowedIds, overflowIds])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      setActivePanel(raw)
      loadPanelData(raw, activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [activeThreadId, dispatch])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      setActivePanel(null)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel }),
    [activePanel, openPanel, openPanelForce, closePanel],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel } = useContextPanelHost()
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        <button
          type="button"
          style={styles.panelCloseBtn}
          title="收起面板 (Esc)"
          aria-label="收起面板"
          onClick={closePanel}
        >
          收起
        </button>
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}

// ── Built-in panel bodies (moved from BottomBar) ───────────────────────────

function TabsPanel() {
  const { state, dispatch } = useAgentStore()

  const handleTogglePin = (tabId: number) => {
    const pinnedTabIds = state.pinnedTabIds.includes(tabId)
      ? state.pinnedTabIds.filter((id) => id !== tabId)
      : [...state.pinnedTabIds, tabId]

    dispatch({ type: "SET_PINNED_TABS", tabIds: pinnedTabIds })

    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { pinned_tabs: pinnedTabIds },
      })
    }
  }

  return (
    <div style={styles.panelContent}>
      {state.tabList.length === 0 && (
        <div style={styles.emptyText}>暂无标签页数据</div>
      )}
      {state.tabList.map((tab) => (
        <label key={tab.id} style={styles.tabRow}>
          <input
            type="checkbox"
            checked={state.pinnedTabIds.includes(tab.id!)}
            onChange={() => handleTogglePin(tab.id!)}
            style={{ marginRight: 8 }}
          />
          <span style={styles.tabTitle}>{tab.title || tab.url}</span>
          <span style={styles.tabUrl}>{tab.id}</span>
        </label>
      ))}
    </div>
  )
}

function HistoryPanel() {
  const { state } = useAgentStore()
  const operations = state.operations || []
  const groups = groupBy(operations, "t