READ-ONLY independent final delta review #469. Base code freeze de83b15e (both origin reviewer implementation verdicts APPROVE_WITH_NITS; yours archived separately, no other reviewer report shared). Scope only diff below plus actual dependencies/harness. Return concise VERDICT: APPROVE/APPROVE_WITH_NITS/REJECT, no length reward. Confirm no new P0/P1/MAJOR. Explicitly CLOSE or retain original Escape-history-plus-context P1: new handler stopPropagation and browser row-Escape context-retention test. Then CLOSE/retain followup N1 residual Webkit blur, N2 global Escape with menu open, N3 one-way aria-pressed semantics.
Changes: removed inert WebkitBackdropFilter; resource selected state uses aria-current instead of aria-pressed; History handler limited to history/menu/trigger, ref updated in effect, search autofocus actually targets type=search. New tests prove Escape outside history does not consume menu; inside menu closes only menu; inside history closes only history. No confirmation files changed. Other code has not changed since reviewed freeze; tokens.ts only comments cleaned before commit. New fixture scripts shown for final completeness.
MACHINE checks green BEFORE this review: extensionbuild and1281pass0fail after code delta; actualApp UI matrix passes. Companion unchanged since primary4996pass+20pass/23skip0fail and build. Terminal actualReact/xterm pass; HTML actualconstants presentation-only and source-minus-style unchanged pass. Latest-head CI will be rechecked after audit commit; no release/install.

diff --git a/chrome-extension/src/sidepanel/components/ThreadList.tsx b/chrome-extension/src/sidepanel/components/ThreadList.tsx
index e841ce96..e6333099 100644
--- a/chrome-extension/src/sidepanel/components/ThreadList.tsx
+++ b/chrome-extension/src/sidepanel/components/ThreadList.tsx
@@ -116,20 +116,21 @@ export function ThreadList() {
   const [query, setQuery] = useState("")
   const [view, setView] = useState<ListView>("time")
   const [selectMode, setSelectMode] = useState(false)
   const [selected, setSelected] = useState<Set<string>>(() => new Set())
   const [expandState, setExpandState] = useState<ThreadListExpandState>(loadExpandState)
   const [expandedDays, setExpandedDays] = useState<Set<string>>(() => new Set())
   const [menuOpen, setMenuOpen] = useState(false)
   const menuOpenRef = useRef(menuOpen)
-  menuOpenRef.current = menuOpen
+  useEffect(() => { menuOpenRef.current = menuOpen }, [menuOpen])
   const [menuPos, setMenuPos] = useState<{ top: number; right: number } | null>(null)
   const menuBtnRef = useRef<HTMLButtonElement | null>(null)
   const triggerRef = useRef<HTMLButtonElement | null>(null)
+  const historyMenuRef = useRef<HTMLDivElement>(null)
   const historyRef = useRef<HTMLDivElement>(null)
   const [panelBox, setPanelBox] = useState<{ top: number; maxHeight: number } | null>(null)
   const [activeTag, setActiveTag] = useState<string | null>(null)
   const [extractingIds, setExtractingIds] = useState<Set<string>>(() => new Set())
   /** A-7 batch progress: done/total while untagged or multi extract runs. */
   const [extractProgress, setExtractProgress] = useState<{
     done: number
     total: number
@@ -856,20 +857,20 @@ export function ThreadList() {
     window.addEventListener("resize", place)
     return () => window.removeEventListener("resize", place)
   }, [open, selectMode, view])
 
   // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
   // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
   useEffect(() => {
     if (!open || !panelBox) return
-    historyRef.current?.querySelector<HTMLInputElement>('input[type="text"], input:not([type])')?.focus()
+    historyRef.current?.querySelector<HTMLInputElement>('input[type="search"]')?.focus()
     const key = (event: KeyboardEvent) => {
       if (event.key !== "Escape" || event.defaultPrevented) return
-      if (!historyRef.current?.contains(event.target as Node) && event.target !== triggerRef.current && !menuOpenRef.current) return
+      if (!historyRef.current?.contains(event.target as Node) && event.target !== triggerRef.current && !historyMenuRef.current?.contains(event.target as Node)) return
       event.preventDefault()
       event.stopPropagation()
       if (menuOpenRef.current) { setMenuOpen(false); menuBtnRef.current?.focus(); return }
       setOpen(false); triggerRef.current?.focus()
     }
     document.addEventListener("keydown", key)
     return () => document.removeEventListener("keydown", key)
   }, [open, !!panelBox])
@@ -1431,17 +1432,17 @@ export function ThreadList() {
                     typeof document !== "undefined" &&
                     createPortal(
                       <div
                         style={{
                           ...styles.menuPortal,
                           top: menuPos.top,
                           right: menuPos.right,
                         }}
-                        role="menu"
+                        ref={historyMenuRef} role="menu"
                       >
                         <button
                           type="button"
                           style={styles.menuItem}
                           onClick={handleGenerateTitle}
                         >
                           ✨ AI 生成标题
                         </button>
diff --git a/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx b/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
index 6aef6f87..822fdd5d 100644
--- a/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
+++ b/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
@@ -46,17 +46,17 @@ function WorkspaceNavigation({ onNavigate, onClose }: { onNavigate: () => void;
   const [query, setQuery] = useState("")
   const recent = state.threads.filter(t => !t.trashed_at && displayThreadTitle(t).toLocaleLowerCase().includes(query.toLocaleLowerCase())).sort((a, b) => threadRecency(b).localeCompare(threadRecency(a))).slice(0, 30)
   return <aside className="cm-navigation" aria-label="工作区">
     <div className="cm-nav-brand"><CompanionMark size={24} /><strong>CMspark</strong>
       {onClose && <button type="button" className="cm-icon-button" aria-label="关闭导航" onClick={onClose}>×</button>}
     </div>
     <button type="button" className="cm-nav-new" onClick={() => { createBlankThread(dispatch); onNavigate() }}><IconNewChat size={17} />新对话</button>
     <nav aria-label="资源与能力" className="cm-nav-resources">
-      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" aria-pressed={activePanel === id} onClick={() => {
+      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" aria-current={activePanel === id ? "true" : undefined} onClick={() => {
         dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
       }}><Icon size={16} /><span>{label}</span></button>)}
     </nav>
     <div className="cm-nav-section"><span>最近对话</span></div>
     <input className="cm-nav-search" aria-label="筛选最近对话" placeholder="查找对话…" value={query} onChange={e => setQuery(e.target.value)} />
     <div className="cm-nav-threads">
       {recent.map(thread => <button type="button" className="cm-nav-thread" key={thread.id} aria-current={thread.id === state.activeThreadId ? "page" : undefined}
         title={displayThreadTitle(thread)} onClick={() => {
diff --git a/chrome-extension/src/sidepanel/ui/workspace-styles.ts b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
index afa8e522..8cb55371 100644
--- a/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -14,17 +14,17 @@ export const workspaceCSS = `
 .cm-nav-resources{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-bottom:16px}
 .cm-nav-resources .cm-nav-item{font-size:12px;gap:6px;padding:8px 6px;min-width:0}
 .cm-nav-resources .cm-nav-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
 .cm-nav-section{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:${tokens.textSecondary};padding:0 8px}
 .cm-nav-search{box-sizing:border-box;width:100%;border:1px solid ${tokens.border};border-radius:${tokens.radiusMd}px;padding:9px 10px;font:inherit;font-size:12px;background:${tokens.bgElevated};color:${tokens.text}}
 .cm-nav-threads{flex:1;min-height:80px;overflow-y:auto;margin-top:4px}
 .cm-nav-thread{min-height:38px;color:${tokens.textSecondary}}
 .cm-nav-thread>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
-.cm-nav-item[aria-pressed="true"],.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
+.cm-nav-item[aria-current="true"],.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
 .cm-nav-running{color:${tokens.success};font-size:20px}
 .cm-nav-empty{font-size:12px;color:${tokens.textSecondary};padding:8px}
 .cm-nav-settings{margin-top:12px;border-top:1px solid ${tokens.border};border-radius:0;padding-top:14px}
 .cm-icon-button{display:inline-flex;align-items:center;justify-content:center;min-width:32px;min-height:32px;border:0;background:transparent;color:${tokens.textSecondary};border-radius:${tokens.radiusMd}px;cursor:pointer;font-size:18px}
 .cm-task-title{font-size:13px;font-weight:500;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-left:8px}
 .cm-chat-content,.cm-composer-dock{width:100%;max-width:780px;margin-left:auto;margin-right:auto;box-sizing:border-box}
 .cm-composer-dock{padding:12px 20px 18px!important}
 .cm-composer-actions{display:flex;align-items:center;gap:8px;min-width:0}
diff --git a/chrome-extension/src/thread-graph/ThreadGraphApp.tsx b/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
index 948e0099..41594b1d 100644
--- a/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
+++ b/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
@@ -980,17 +980,16 @@ export function ThreadGraphApp() {
   )
 }
 
 const glass: CSSProperties = {
   background: tokens.darkElevated,
   border: `1px solid ${tokens.darkBorder}`,
   boxShadow: "0 8px 28px rgba(0,0,0,0.35), 0 1px 0 rgba(255,255,255,0.04) inset",
   // Solid surface keeps graph controls legible without translucent layering.
-  WebkitBackdropFilter: "blur(12px)",
 }
 
 const styles: Record<string, CSSProperties> = {
   page: {
     position: "relative",
     height: "100vh",
     margin: 0,
     fontFamily: tokens.font,


FILE chrome-extension/scripts/test-workspace-ui.py
"""Real App UI, synthetic transport. Run after nvm use22 with uv --with playwright.
No live Companion, external account, installed extension or native shell is used.
"""
import json
import subprocess
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

project = Path(__file__).resolve().parent.parent
shots = Path('/private/tmp/cmspark-469-shots')
shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
    subprocess.run(['node', 'scripts/render-workspace-fixture.cjs', directory], cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width':1440,'height':900})
        page.set_default_timeout(6000)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory)/'index.html').as_uri())
        composer = page.get_by_role('textbox', name='消息内容', exact=True)
        composer.wait_for()
        page.wait_for_function('window.dispatchUI && document.querySelector("textarea") && !document.querySelector("textarea").disabled')
        for width,height in [(1440,900),(800,700),(760,640),(759,640),(390,740),(320,480)]:
            page.set_viewport_size({'width':width,'height':height})
            page.wait_for_timeout(120)
            assert not page.evaluate('document.documentElement.scrollWidth > innerWidth'), (width,height,'horizontal overflow')
            box = composer.bounding_box()
            assert box and box['width'] >= min(220,width-60), (width,box)
            assert box['y'] >= 0 and box['y']+box['height'] <= height, (width,box)
            assert page.get_by_role('button',name='打开工作区导航',exact=True).is_visible() == (width<760)
            if width in (1440,390,320):page.screenshot(path=str(shots/f'empty-{width}.png'))
        # Narrow drawer: initial focus, keyboard close and focus return.
        toggle=page.get_by_role('button',name='打开工作区导航',exact=True)
        toggle.click()
        nav=page.get_by_role('dialog',name='工作区导航',exact=True)
        nav.wait_for()
        assert page.evaluate('document.querySelector("[aria-label=工作区导航]").contains(document.activeElement)')
        page.keyboard.press('Escape')
        assert not nav.is_visible()
        assert toggle.evaluate('(el)=>el===document.activeElement')
        # New task preserves existing action, never sends an Agent message.
        toggle.click()
        nav.get_by_role('button',name='新对话',exact=True).click()
        page.wait_for_function('window.sent.some(x=>x.type==="thread.create")')
        assert not page.evaluate('window.sent.some(x=>x.type==="chat.send" || x.type==="chat.create")')
        # Use original demo thread to keep subsequent fixtures explicitly scoped.
        page.evaluate("window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'demo-0'});window.dispatchUI({type:'SET_MESSAGES',messages:[]})")
        toggle.click()
        nav.get_by_role('button',name='设置',exact=True).click()
        settings=page.get_by_role('dialog',name='设置',exact=True)
        settings.wait_for()
        settings.get_by_role('navigation',name='设置分类').get_by_role('button',name='安全与信任',exact=True).click()
        page.wait_for_timeout(100)
        assert page.locator('[data-settings-section=安全与信任] > button').get_attribute('aria-expanded')=='true'
        page.screenshot(path=str(shots/'settings-320.png'))
        assert page.evaluate('document.querySelector("[aria-label=设置]").contains(document.activeElement)')
        settings.get_by_role('button',name='关闭设置',exact=True).click()
        # Existing history is named and keyboard operable; Escape returns focus.
        history=page.get_by_role('button',name='历史对话',exact=True)
        history.click()
        dialog=page.get_by_role('dialog',name='历史对话列表',exact=True)
        dialog.wait_for()
        page.wait_for_function('document.activeElement?.getAttribute("aria-label")==="搜索线程"')
        row=dialog.get_by_role('button',name='打开 发布 v2.8',exact=False).first
        row.focus();page.keyboard.press('Enter')
        assert not dialog.is_visible()
        assert page.evaluate('window.sent.some(x=>x.type==="thread.select" && x.threadId==="demo-0")')
        history.click();dialog.wait_for();page.wait_for_timeout(100);page.keyboard.press('Escape')
        assert not dialog.is_visible()
        assert history.evaluate('(el)=>el===document.activeElement')
        # Context panel fits the short viewport; closes without losing composer.
        toggle.click();nav.get_by_role('button',name='知识',exact=True).click()
        context=page.get_by_test_id('context-panel-host')
        context.wait_for()
        assert context.bounding_box()['height'] <= 480*.28+2
        assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
        history.click();dialog.wait_for();page.wait_for_timeout(100)
        row=dialog.get_by_role('button',name='打开 发布 v2.8',exact=False).first
        row.focus();page.keyboard.press('Escape')
        assert not dialog.is_visible() and context.is_visible(), 'Escape must close only history'
        history.click();dialog.wait_for();page.wait_for_timeout(100)
        dialog.get_by_title('更多',exact=True).click()
        menu=page.get_by_role('menu').last;menu.wait_for()
        composer.focus();page.keyboard.press('Escape')
        assert menu.is_visible(), 'History must not consume Escape from another surface'
        menu.get_by_role('button').first.focus();page.keyboard.press('Escape')
        assert not menu.is_visible() and dialog.is_visible()
        dialog.get_by_role('searchbox',name='搜索线程').focus();page.keyboard.press('Escape')
        assert not dialog.is_visible() and context.is_visible()
        page.get_by_role('button',name='收起面板',exact=True).click()
        # Long content + actual tool card disclosure are keyboard operable.
        messages=[{'id':'u1','thread_id':'demo-0','role':'user','content':'请核对支付服务 v2.8 的需求、代码与测试，整理变更材料。','created_at':'2026-09-07T10:00:00Z'},
          {'id':'a1','thread_id':'demo-0','role':'assistant','content':'已整理当前证据。\n\n### 需要补充的内容\n\n- 需求与开发任务已建立关联。\n- 测试对应提交仍待核对。\n\n'+'`https://devops.example.test/'+('long-path/'*25)+'`', 'created_at':'2026-09-07T10:01:00Z',
           'tool_calls':[{'id':'tc1','tool_name':'get_page_text','params':{},'status':'success','result':{'success':True,'data':{'content':'这是来自合成测试网页的实际展示文本。'*80}}}]}]
        page.evaluate('(messages)=>window.dispatchUI({type:"SET_MESSAGES",messages})',messages)
        page.set_viewport_size({'width':1440,'height':900})
        details=page.get_by_role('button',name='展开 get_page_text 详情',exact=True)
        details.focus();page.keyboard.press('Enter')
        assert page.get_by_role('button',name='收起 get_page_text 详情',exact=True).get_attribute('aria-expanded')=='true'
        page.screenshot(path=str(shots/'conversation-1440.png'))
        assert page.get_by_role('complementary',name='工作区',exact=True).bounding_box()['width']==220
        assert page.locator('.cm-chat-content').bounding_box()['width']<=780
        assert page.locator('.cm-composer-dock').bounding_box()['width']<=780
        page.evaluate("window.dispatchEvent(new Event('cmspark:open-coding-handoff'))")
        coding=page.get_by_role('dialog',name='编程接力 面板',exact=True)
        coding.wait_for()
        for width,height in [(1440,900),(320,480)]:
            page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(100)
            rail=page.locator('.cm-status-rail').bounding_box()
            assert coding.bounding_box()['y'] >= rail['y']+rail['height']-1
        coding.get_by_role('button',name='关闭',exact=True).click()
        page.set_viewport_size({'width':1440,'height':900})
        # Confirmation queue is still rendered by the unchanged production gate.
        confirmation={'confirmation_id':'fixture-confirm','tool_name':'shell_exec','dangerous_apis':['shell'], 'code_preview':'git diff base..head','risk_level':'high','requested_at':'2026-09-07T10:00:00Z','timeout_ms':45000}
        page.get_by_role('navigation',name='资源与能力').get_by_role('button',name='知识',exact=True).click()
        page.evaluate('(request)=>window.dispatchUI({type:"ADD_SECURITY_CONFIRMATION",request})',confirmation)
        page.set_viewport_size({'width':320,'height':480})
        page.wait_for_timeout(100)
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
        gate=page.get_by_role('alertdialog').first
        for name in ['允许','拒绝','停止']:
            button=gate.get_by_role('button',name=name,exact=True)
            box=button.bounding_box()
            assert box and 0 <= box['y'] and box['y']+box['height'] <= 480
            assert button.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        toggle.click();nav.wait_for()
        for name in ['允许','拒绝','停止']:
            assert gate.get_by_role('button',name=name,exact=True).evaluate('(el)=>{const r=el.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        nav.get_by_role('button',name='关闭导航').click()
        page.screenshot(path=str(shots/'confirmation-320.png'))
        assert not page.evaluate('window.sent.some(x=>x.type==="security.confirmation.response")')
        page.evaluate("window.dispatchUI({type:'REMOVE_SECURITY_CONFIRMATION',confirmationId:'fixture-confirm'});window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:true})")
        stop=page.get_by_role('button',name='停止本轮',exact=True)
        stop.wait_for()
        assert stop.bounding_box()['y']+stop.bounding_box()['height'] <= 480
        page.get_by_role('button',name='纠偏',exact=True).wait_for()
        page.get_by_role('button',name='排队',exact=True).wait_for()
        toggle.click();nav.wait_for()
        assert stop.evaluate('(el)=>{const r=el.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        nav.get_by_role('button',name='关闭导航').click()
        page.screenshot(path=str(shots/'running-320.png'))
        page.evaluate("window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:false});window.dispatchUI({type:'SET_CONNECTION',state:'disconnected'})")
        page.get_by_role('button',name='重新连接',exact=True).wait_for()
        assert composer.is_disabled()
        page.screenshot(path=str(shots/'offline-320.png'))
        # 200% equivalent CSS viewport reflow + reduced motion (actual media).
        page.emulate_media(reduced_motion='reduce')
        page.set_viewport_size({'width':720,'height':450})
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert page.locator('.cm-workspace').evaluate('(el)=>getComputedStyle(el).scrollBehavior')=='auto'
        assert not errors, errors
        browser.close()
print('PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, reflow/reduced motion. Synthetic transport only.')


FILE chrome-extension/scripts/render-workspace-fixture.cjs
// Synthetic transport fixture for actual App components. Never connects to live Companion.
const fs=require('fs'),path=require('path');
const root=process.cwd(),out=process.argv[2] || '/private/tmp/cmspark-workspace-ui';fs.mkdirSync(out,{recursive:true});
const store=path.join(root,'src/sidepanel/store/agentStore.tsx');
const hook=`import {useEffect} from 'react';import {useAgentStore} from ${JSON.stringify(store)};
export const shouldApplyStreamEvent=()=>true;
export function useWebSocket(){const {state,dispatch}=useAgentStore();useEffect(()=>{window.dispatchUI=dispatch;const threads=window.demoThreads;dispatch({type:'SET_CONNECTION',state:'connected'});dispatch({type:'SET_THREADS',threads});dispatch({type:'SET_ACTIVE_THREAD',threadId:threads[0].id});dispatch({type:'SET_MESSAGES',messages:[]});},[]);return {connectionState:state.connectionState};}`;
const source=`import {CockpitRoot} from ${JSON.stringify(path.join(root,'src/cockpit/CockpitApp.tsx'))};import React from 'react';import{createRoot}from'react-dom/client';import{App}from${JSON.stringify(path.join(root,'src/sidepanel/App.tsx'))};
const event={addListener(){},removeListener(){}};window.sent=[];
window.demoThreads=['发布 v2.8 · 变更材料','支付服务 · 需求与测试追溯','本周运行状态巡检','整理架构评审记录'].map((alias,i)=>({id:'demo-'+i,alias,created_at:new Date().toISOString(),updated_at:new Date().toISOString(),config_override:{},tool_whitelist:null,pinned_tabs:[],active_skill_ids:[],agent_role:'normal'}));
const tabs=[{id:1,title:'支付服务 · 版本 v2.8 — DevOps',url:'https://devops.example.test/releases/2.8',active:true}];
const respond=(value,cb)=>{if(typeof cb==='function')queueMicrotask(()=>cb(value));return Promise.resolve(value)};
window.chrome={runtime:{id:'preview',getURL:p=>p,onMessage:event,onConnect:event,sendMessage:(m,cb)=>{window.sent.push(m);let value={ok:true};if(m.type==='thread.create')value={thread:{...window.demoThreads[0],id:'created-'+Date.now(),alias:''}};if(m.type==='thread.select')setTimeout(()=>window.dispatchUI({type:'SET_MESSAGES',messages:[]}),0);return respond(value,cb)},connect:()=>({onMessage:event,onDisconnect:event,postMessage(){},disconnect(){}})},storage:{local:{get:(keys,cb)=>respond({},cb),set:(v,cb)=>respond({},cb)},onChanged:event},tabs:{query:(q,cb)=>respond(tabs,cb),onActivated:event,onUpdated:event},windows:{getCurrent:(o,cb)=>respond({id:1},cb)},commands:{onCommand:event}};
createRoot(document.getElementById('root')).render(location.search.includes('cockpit') ? <CockpitRoot/> : <App/>);`;
require(path.join(root,'node_modules/esbuild')).build({stdin:{contents:source,resolveDir:root,loader:'tsx'},bundle:true,outfile:path.join(out,'app.js'),jsx:'automatic',loader:{'.css':'css','.woff2':'dataurl','.woff':'dataurl','.ttf':'dataurl'},plugins:[{name:'synthetic-transport',setup(b){b.onResolve({filter:/hooks\/useWebSocket$/},()=>({path:'fixture-hook',namespace:'fixture'}));b.onLoad({filter:/.*/,namespace:'fixture'},()=>({contents:hook,loader:'tsx',resolveDir:root}));}}]}).then(()=>{fs.writeFileSync(path.join(out,'index.html'),'<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="app.css"><body style="margin:0"><div id="root"></div><script src="app.js"></script></body></html>');console.log(out)}).catch(e=>{console.error(e);process.exit(1)});


FILE companion/scripts/render-web-surface-fixtures.cjs
// Real HTML templates in an isolated data directory. No server is started.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const Module = require('node:module');
const root = path.resolve(__dirname, '..');
const out = path.resolve(process.argv[2]);
fs.mkdirSync(out, { recursive: true });
const isolated = fs.mkdtempSync(path.join(os.tmpdir(), 'cmspark-surface-data-'));
process.env.CMSPARK_DATA_DIR = isolated;
try {
  for (const [file, symbol, name] of [['summoner-web.ts', 'SUMMONER_HTML', 'capture'], ['settings-web.ts', 'SETTINGS_HTML', 'settings']]) {
    const filename = path.join(root, 'src', file);
    const contents = fs.readFileSync(filename, 'utf8') + `\nexport { ${symbol} as fixtureHtml };`;
    const result = require('esbuild').buildSync({ stdin: { contents, resolveDir: path.dirname(filename), loader: 'ts' }, bundle: true, platform: 'node', format: 'cjs', packages: 'external', write: false });
    const mod = new Module(filename, module);
    mod.filename = filename; mod.paths = Module._nodeModulePaths(path.dirname(filename));
    mod._compile(result.outputFiles[0].text, filename);
    fs.writeFileSync(path.join(out, name + '.html'), mod.exports.fixtureHtml);
  }
} finally { fs.rmSync(isolated, { recursive: true, force: true }); }
console.log(out);


FILE companion/scripts/test-web-surfaces-ui.py
"""Presentation-only checks of the real HTML constants; scripts removed, no services."""
from pathlib import Path
import re, subprocess, tempfile
from playwright.sync_api import sync_playwright
project=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-469-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
    subprocess.run(['node','scripts/render-web-surface-fixtures.cjs',out],cwd=project,check=True)
    with sync_playwright() as p:
        browser=p.chromium.launch(channel='chrome',headless=True)
        page=browser.new_page()
        page.route('**/*',lambda route:route.abort())
        for name in ['capture','settings']:
            html=(Path(out)/(name+'.html')).read_text()
            base=subprocess.check_output(['git','show','8656df94:companion/src/'+('summoner-web.ts' if name=='capture' else 'settings-web.ts')],cwd=project,text=True)
            current=(project/'src'/('summoner-web.ts' if name=='capture' else 'settings-web.ts')).read_text()
            assert re.sub(r'<style>.*?</style>','<style/>',base,flags=re.S)==re.sub(r'<style>.*?</style>','<style/>',current,flags=re.S), 'HTML behavior changed'
            page.set_content(re.sub(r'<script\b[^>]*>.*?</script>','',html,flags=re.S))
            for width,height in [(320,480),(390,740),(900,800)]:
                page.set_viewport_size({'width':width,'height':height})
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),(name,width)
                page.screenshot(path=str(shots/f'{name}-{width}.png'))
        browser.close()
print('PASS: capture/settings real HTML CSS reflow; non-style source byte-identical to base. Scripts not executed.')


CONTEXT ESCAPE DEPENDENCY
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      setActivePanel(null)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel }),
    [activePanel, openPanel, openPanelForce, closePanel],
  )

  return (
    <ContextP