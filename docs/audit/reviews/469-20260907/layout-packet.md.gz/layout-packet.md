You are an independent LAYOUT PRODUCT-UX/CORRECTNESS/SAFETY adversarial reviewer for CMspark #469. READ-ONLY, inspect only packet. Base8656df94, uncommitted frozen scoped files below. User requests comprehensive simple spacious Codex-inspired redesign, no copy assets. Distinct implementation gate, not design approval. Outcome/trajectory/component: find concrete bugs, lost affordances, keyboard/confirmation regressions, maintainability. T3 unchanged origin/L2/stop; no backend/policy/default changes. Confirmation source handlers/DOM remain byte-unchanged; only token consumers and toast placement. No new production deps.
Machine: latest production extension build exit0 (tsc+Plasmo), full1281/1281 exit0; actual React App synthetic Chrome/transport matrix passed320/390/759/760/800/1440, short-window composer, drawer focus/Escape, settings deep links, history keyboard, tool disclosure, simultaneous context+confirmation buttons hit-tested visible and no approval sent, reduced-motion/equivalent200% CSS reflow. Actual xterm report UI test pass after style changes. Additional running/offline test is being exercised separately, not claimed yet.
Scope claim: main React web workspace redesigned; Cockpit/graphs inherit token surfaces only; native Swift/Windows and independent HTML capture not redesigned or certified. No release/appreplace. Previous design MAJOR locks closed by actual pair; require code review independent now. Any P0/P1/MAJOR concrete defect blocks merge regardless positive label. End VERDICT APPROVE|APPROVE_WITH_NITS|REJECT. No reward for verbosity or stylistic preference.

DESIGN CONTRACT
# Design

## Source of truth
Active · 2026-09-07 · GitHub #469. This file owns product-wide UI/UX direction.
`docs/DESIGN.md` retains detailed capability and safety contracts; this revision
supersedes its consumer-mascot-first layout, tiny chrome and narrow-only shell.
Evidence: Sidepanel App, StatusRail, ThreadList, ChatView, ComposerDock,
ContextPanelHost, SettingsSlideout, shared tokens/Modal, Cockpit and terminal.
No current Codex screenshot was accessed: the reference is the user's stated
preference for quiet, spacious hierarchy, not a pixel-matching target.

## Brand
Calm, precise, capable. CMspark remains its own identity. Neutral paper and ink,
small existing mark, restrained indigo links/focus, semantic risk colors.
Avoid promotional dashboards, gradients, oversized mascots, dense icon ribbons,
unexplained technical acronyms and decorative status lights.

## Product goals
Make the next action obvious; keep conversation readable; let users find prior
work and supporting capabilities without remembering hidden menus. Preserve all
existing functions, confirmations, busy states and honest evidence gaps.
Success: no horizontal page overflow at 320px; usable content at 1440px; keyboard
reachable navigation/history/settings; input and stop remain reachable at short
height; dangerous actions never gain an implicit approval.
Non-goals: runtime redesign, new permission model, copying Codex assets, release.

## Personas and jobs
Enterprise change manager assembles sourced material across websites; developer
connects requirements/code/tests and optionally uses a terminal; everyday user
reads and acts on the current page. Each needs a quiet primary conversation and
clear separation of supporting configuration from execution.

## Information architecture
One responsive conversation workspace. At wide width, a quiet left navigation
shows new conversation, recent conversations and supporting resources. At narrow
width, navigation opens through the text-labeled header control 导航 as an explicit drawer; primary conversation keeps full
width. Existing full history preserves search, folders, trash and bulk actions.
StatusRail remains the single conversation header: 导航 (narrow only), task title, existing popout/history/status/more. New conversation is owned by WorkspaceNavigation; no second new-thread control in the header. Recent rows are a projection of the existing store, while full history preserves its original owner. Conversation header shows task title (existing title resolver, 新对话 fallback); page/context and pending confirmation stay
in the existing FocusBand. Knowledge/scenes/skills/MCP/apps/meetings use existing
ContextPanelHost. The host is already vertically stacked, not a fixed-width side column: preserve that safe layout, cap it to36dvh (28dvh below560px height), and close supporting panels before opening configuration. Do not overlay pending confirmation. Settings is one named dialog with grouped sections.
No duplicated data loader, thread cache, Agent or confirmation center.

## Design principles
One dominant action per area. Progressive disclosure keeps tools/details on
demand; pending confirmation and stop stay visible. Text labels explain navigation.
Layout changes never change trust policy. Confirmation modifications are limited to shared surface colors, type, spacing and focus visibility; component handlers, button order/roles, initial focus, timeout, whitelist and auto-approve copy/defaults stay unchanged. Decision-critical evidence remains at least as visible as baseline. FocusBand confirmation/stop priority remains authoritative, with no second sticky header. Cockpit is in shared visual-token scope; confirmation DOM/handlers remain byte-unchanged. Small screens are a first-class surface.

## Visual language
Keep shared `sidepanel/ui/tokens.ts` the only new color-value owner. Neutral
surfaces and subtle borders, readable secondary text; charcoal primary composer
action, indigo links/focus. Font system sans; body14–15, chrome12–13, headings
15–24. Spacing4/8/12/16/24/32; rounded controls8, cards12, composer20.
Flat navigation, quiet user bubble, unboxed assistant prose, restrained shadows
for floating surfaces only. Existing SVG icons; no added font/network assets.
Respect reduced motion and use short feedback transitions.

## Components
Responsive WorkspaceNavigation plus existing StatusRail/ThreadList; shared
Workspace styles, tokens and Modal. Conversation/readable-width wrappers,
ComposerDock, settings sections, tool disclosure cards, ContextPanelHost and
terminal adopt the same spacing and hierarchy. New classes are explicit, scoped,
and do not infer semantic roles from arbitrary inline-style selectors.

## Accessibility
Target WCAG 2.2 AA practices: text contrast at least4.5:1 for newly styled ordinary text, non-color risk labels, visible
focus, semantic buttons, keyboard Enter/Space, Escape and focus return for
drawers/dialogs, no nested interactive elements. Essential controls at least32px
and primary actions36px; preserve live status and destructive confirmation copy.
Do not claim formal conformance certification from automated testing.

## Responsive behavior
320–759px: full-width chat, navigation drawer, narrow dialogs and no fixed wide
columns. At760px+: persistent220px navigation, central conversation max780px;
wide settings use bounded centered dialog. Short screens scroll the content,
not the entire composer; supporting panel has viewport-relative height cap (min36dvh/360px, or28dvh below560px). Only message space may shrink; if confirmation competes, supporting context must yield.
Browser zoom and long titles/URLs must wrap or truncate without hiding actions.

## Interaction states
Empty state: a short invitation and useful action suggestions; suggestions fill
input, never send. Loading/streaming keeps stop; errors show recovery near source;
offline retains explicit reconnect. Selected navigation uses text plus background.
Confirmation remains distinct from normal tool success; disconnection does not
invent completion. Details expand deliberately without dumping raw JSON first.

## Content voice
Chinese product chrome, clear verbs, short labels. Prefer 对话/知识/场景/设置.
Technical detail belongs inside relevant settings or expanded evidence. Never
relabel an unverified report as approval, a process exit as task success, or a
permission setting as mere appearance.

## Implementation constraints
React18/Plasmo, inline styles plus scoped CSS, existing token owner and icons.
No new production dependency. Real component browser harness with synthetic
transport for wide/narrow/short layouts including759/760 breakpoints and200% equivalent CSS-viewport reflow, keyboard, message/tool/confirmation and
settings flows; production build, full suites and external dual reviews.
Native Swift/Windows platform chrome cannot be certified by the browser harness;
shared web surfaces are verified here, native surfaces remain separately tracked.

## Open questions
- [ ] #469: native host-window visuals on Windows require platform validation;
  owner maintainers. No claim of native cross-platform pixel acceptance.
- [ ] User can refine density after using the shipped redesign; current default
  assumes readable enterprise work rather than dense diagnostics.

FILE chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
```tsx
import { useEffect, useState, type ReactNode } from "react"
import { useAgentStore } from "../store/agentStore"
import { displayThreadTitle } from "../utils/thread-timeline"
import { tokens } from "../ui/tokens"
import { CompanionMark, IconNewChat, IconSettings } from "../ui/icons"
import { CONTEXT_PANEL_TABS, useContextPanelHost } from "./ContextPanelHost"
import { createBlankThread } from "./ThreadList"
import { Modal } from "./ui/Modal"

/** Presentation only: existing store, context loaders and thread.select own data. */
export function WorkspaceFrame({ children }: { children: ReactNode }) {
  const [wide, setWide] = useState(() => window.matchMedia("(min-width: 760px)").matches)
  const [open, setOpen] = useState(false)
  useEffect(() => {
    const query = window.matchMedia("(min-width: 760px)")
    const resize = () => { setWide(query.matches); setOpen(false) }
    const toggle = () => setOpen(value => !value)
    query.addEventListener("change", resize)
    window.addEventListener("cmspark:toggle-navigation", toggle)
    return () => { query.removeEventListener("change", resize); window.removeEventListener("cmspark:toggle-navigation", toggle) }
  }, [])
  return <div className="cm-workspace">
    {wide && <WorkspaceNavigation onNavigate={() => {}} />}
    <main className="cm-workspace-main" aria-label="对话工作区">{children}</main>
    <Modal open={!wide && open} onClose={() => setOpen(false)} ariaLabel="工作区导航"
      overlayStyle={{ position: "fixed", inset: 0, zIndex: 10060, background: tokens.scrim, display: "flex" }}
      panelStyle={{ width: "min(288px, calc(100vw - 40px))", height: "100%", background: tokens.bgMuted }}>
      <WorkspaceNavigation onNavigate={() => setOpen(false)} onClose={() => setOpen(false)} />
    </Modal>
  </div>
}

function WorkspaceNavigation({ onNavigate, onClose }: { onNavigate: () => void; onClose?: () => void }) {
  const { state, dispatch } = useAgentStore()
  const { openPanelForce, closePanel } = useContextPanelHost()
  const [query, setQuery] = useState("")
  const recent = state.threads.filter(t => !t.trashed_at && displayThreadTitle(t).toLocaleLowerCase().includes(query.toLocaleLowerCase())).slice(0, 30)
  return <aside className="cm-navigation" aria-label="工作区">
    <div className="cm-nav-brand"><CompanionMark size={24} /><strong>CMspark</strong>
      {onClose && <button type="button" className="cm-icon-button" aria-label="关闭导航" onClick={onClose}>×</button>}
    </div>
    <button type="button" className="cm-nav-new" onClick={() => { createBlankThread(dispatch); onNavigate() }}><IconNewChat size={17} />新对话</button>
    <nav aria-label="资源与能力" className="cm-nav-resources">
      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" onClick={() => {
        dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
      }}><Icon size={16} /><span>{label}</span></button>)}
    </nav>
    <div className="cm-nav-section"><span>最近对话</span></div>
    <input className="cm-nav-search" aria-label="筛选最近对话" placeholder="查找对话…" value={query} onChange={e => setQuery(e.target.value)} />
    <div className="cm-nav-threads">
      {recent.map(thread => <button type="button" className="cm-nav-thread" key={thread.id} aria-current={thread.id === state.activeThreadId ? "page" : undefined}
        title={displayThreadTitle(thread)} onClick={() => {
          dispatch({ type: "SET_ACTIVE_THREAD", threadId: thread.id }); chrome.runtime.sendMessage({ type: "thread.select", threadId: thread.id }); onNavigate()
        }}><span>{displayThreadTitle(thread)}</span>{state.threadBusyById[thread.id] && <span className="cm-nav-running" aria-label="运行中">·</span>}</button>)}
      {!recent.length && <p className="cm-nav-empty">{query ? "没有匹配的对话" : "新对话会保存在这里"}</p>}
    </div>
    <button type="button" className="cm-nav-item cm-nav-settings" onClick={() => { closePanel(); dispatch({ type: "SET_SETTINGS_OPEN", open: true }); onNavigate() }}><IconSettings size={16} />设置</button>
  </aside>
}

```

FILE chrome-extension/src/sidepanel/ui/workspace-styles.ts
```tsx
import { tokens } from "./tokens"

/** Scoped shell styles; colors remain owned by tokens.ts. */
export const workspaceCSS = `
.cm-workspace{display:flex;height:100dvh;min-height:0;width:100%;overflow:hidden;background:${tokens.bg};font-family:${tokens.font};color:${tokens.text}}
.cm-workspace-main{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;position:relative}
.cm-navigation{width:220px;height:100%;box-sizing:border-box;flex-shrink:0;display:flex;flex-direction:column;padding:20px 12px 12px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};gap:6px;overflow-y:auto}
[aria-label="工作区导航"] .cm-navigation{width:100%}
.cm-nav-brand{display:flex;align-items:center;gap:10px;padding:0 8px 20px;font-size:15px;letter-spacing:-.03em}
.cm-nav-brand .cm-icon-button{margin-left:auto}
.cm-nav-new,.cm-nav-item,.cm-nav-thread{font:inherit;border:0;border-radius:${tokens.radiusMd}px;cursor:pointer;display:flex;align-items:center;gap:10px;text-align:left;min-height:36px;width:100%;padding:8px 10px;color:${tokens.text};background:transparent;font-size:13px;flex-shrink:0}
.cm-nav-new{background:${tokens.bgElevated};border:1px solid ${tokens.border};margin-bottom:10px;font-weight:500}
.cm-nav-item:hover,.cm-nav-thread:hover,.cm-icon-button:hover{background:${tokens.bgHover}}
.cm-nav-resources{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-bottom:16px}
.cm-nav-resources .cm-nav-item{font-size:12px;gap:6px;padding:8px 6px;min-width:0}
.cm-nav-resources .cm-nav-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cm-nav-section{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:${tokens.textSecondary};padding:0 8px}
.cm-nav-search{box-sizing:border-box;width:100%;border:1px solid ${tokens.border};border-radius:${tokens.radiusMd}px;padding:9px 10px;font:inherit;font-size:12px;background:${tokens.bgElevated};color:${tokens.text}}
.cm-nav-threads{flex:1;min-height:80px;overflow-y:auto;margin-top:4px}
.cm-nav-thread{min-height:38px;color:${tokens.textSecondary}}
.cm-nav-thread>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
.cm-nav-running{color:${tokens.success};font-size:20px}
.cm-nav-empty{font-size:12px;color:${tokens.textSecondary};padding:8px}
.cm-nav-settings{margin-top:12px;border-top:1px solid ${tokens.border};border-radius:0;padding-top:14px}
.cm-icon-button{display:inline-flex;align-items:center;justify-content:center;min-width:32px;min-height:32px;border:0;background:transparent;color:${tokens.textSecondary};border-radius:${tokens.radiusMd}px;cursor:pointer;font-size:18px}
.cm-task-title{font-size:13px;font-weight:500;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-left:8px}
.cm-chat-content,.cm-composer-dock{width:100%;max-width:780px;margin-left:auto;margin-right:auto;box-sizing:border-box}
.cm-composer-dock{padding:12px 20px 18px!important}
.cm-composer-actions{display:flex;align-items:center;gap:8px;min-width:0}
.cm-composer-capsule:focus-within{border-color:${tokens.accent}!important;box-shadow:${tokens.shadowFocus}}
.cm-workspace button:focus-visible,.cm-workspace [role="button"]:focus-visible,.cm-workspace input:focus-visible,.cm-workspace textarea:focus-visible,[role="dialog"] button:focus-visible,[role="dialog"] input:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
.cm-workspace button:disabled{cursor:not-allowed}
.cm-settings-categories{display:flex;gap:6px;flex-wrap:wrap;padding:12px 24px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
.cm-settings-categories button{font:inherit;font-size:12px;border:1px solid ${tokens.border};background:${tokens.bgMuted};color:${tokens.text};border-radius:8px;min-height:32px;padding:4px 10px;cursor:pointer}
.cm-settings-panel{width:min(780px,100vw - 32px)!important;max-height:88dvh!important;border-radius:${tokens.radiusSheet}px!important;box-shadow:${tokens.shadowLg}}
.cm-settings-header{padding:20px 24px!important}
.cm-settings-body{padding:8px 24px 24px!important}
.cm-context-panel{max-height:min(36dvh,360px)!important;margin:0 16px;border:1px solid ${tokens.border};border-radius:${tokens.radiusLg}px;box-shadow:${tokens.shadowSm}}
.cm-history-group{flex:1;border:0;background:transparent;color:inherit;font:inherit;text-align:left;min-height:32px;cursor:pointer;padding:4px 0}
.cm-navigation-toggle{gap:4px;flex-shrink:0}
.cm-history-panel{max-width:720px;margin:0 auto}
.cm-history-panel button:focus-visible,.cm-history-panel [role="button"]:focus-visible{outline:2px solid ${tokens.accent};outline-offset:-2px}
@media(min-width:760px){.cm-navigation-toggle{display:none!important}.cm-status-rail{padding:12px 24px!important;border-bottom:1px solid ${tokens.border}!important}.cm-chat-scroll{padding:28px 32px!important}.cm-composer-dock{padding-bottom:24px!important}}
@media(max-width:759px){.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-categories{display:flex;gap:6px;flex-wrap:wrap;padding:12px 24px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
.cm-settings-categories button{font:inherit;font-size:12px;border:1px solid ${tokens.border};background:${tokens.bgMuted};color:${tokens.text};border-radius:8px;min-height:32px;padding:4px 10px;cursor:pointer}
.cm-settings-panel{width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-categories{padding:8px 16px;max-height:100px;overflow:auto}.cm-settings-body{padding:8px 16px 16px!important}}
@media(max-height:560px){.cm-context-panel{max-height:28dvh!important}.cm-composer-dock{padding-top:4px!important;padding-bottom:6px!important}.cm-navigation{padding-top:10px}.cm-nav-brand{padding-bottom:8px}.cm-nav-resources{margin-bottom:4px}.cm-nav-new{margin-bottom:2px}}
@media(prefers-reduced-motion:reduce){.cm-workspace *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
`

```

FILE chrome-extension/src/sidepanel/components/ui/Modal.tsx
```tsx
// Shared modal/overlay primitive (audit M18).
//
// Wraps useModalDialog (focus trap + Escape + focus restore) and applies the
// dialog ARIA contract (role + aria-modal + aria-label/labelledby) so every
// overlay dialog gets consistent keyboard + screen-reader behavior.
//
// Callers pass their OWN overlay + panel styles (position fixed vs absolute,
// z-index, backdrop color, alignment differ per dialog and are kept verbatim)
// and their panel content as children. The outer overlay receives role/aria and
// the backdrop-dismiss click; the inner panel stops propagation so clicks inside
// don't close the dialog.
//
// NOTE: this is for DIALOGS only — things that take focus and trap it. Popovers
// that should NOT steal focus (e.g. SlashCommandPopover, a combobox/listbox) must
// NOT use this; they need listbox semantics instead. See ARIA guidance in WCAG.

import type { CSSProperties, ReactNode, RefObject } from "react"
import { useModalDialog, type UseModalDialogOptions } from "../../hooks/useModalDialog"

export interface ModalProps {
  /** Gate visibility + focus management. Renders null when false. */
  open: boolean
  /** Called on Escape, and on overlay click when backdropDismiss is true. */
  onClose: () => void
  /** Accessible role. Use "alertdialog" for destructive-action gates. */
  role?: "dialog" | "alertdialog"
  /** Accessible name when there's no visible title to point at. */
  ariaLabel?: string
  /** Accessible name pointing at a visible title element's id. Preferred over ariaLabel. */
  ariaLabelledBy?: string
  /** Click on the overlay/backdrop calls onClose. Default true. */
  backdropDismiss?: boolean
  /** Element to focus on open (passed through to useModalDialog). */
  initialFocusRef?: RefObject<HTMLElement>
  /** Restore focus on close (passed through to useModalDialog). */
  restoreFocus?: boolean
  /** Extra effect deps (e.g. a dialog id) — passed through to useModalDialog. */
  deps?: UseModalDialogOptions["deps"]
  /** Style for the overlay/backdrop element (position, z-index, bg, alignment). */
  overlayStyle?: CSSProperties
  /** Style for the inner panel. */
  panelStyle?: CSSProperties
  /** Extra className on the panel if a caller uses CSS classes. */
  panelClassName?: string
  children: ReactNode
}

export function Modal(props: ModalProps) {
  const {
    open,
    onClose,
    role = "dialog",
    ariaLabel,
    ariaLabelledBy,
    backdropDismiss = true,
    initialFocusRef,
    restoreFocus,
    deps,
    overlayStyle,
    panelStyle,
    panelClassName,
    children,
  } = props

  const overlayRef = useModalDialog({ open, onClose, initialFocusRef, restoreFocus, deps })

  if (!open) return null

  const aria = ariaLabelledBy ? { "aria-labelledby": ariaLabelledBy } : { "aria-label": ariaLabel }

  return (
    <div
      ref={overlayRef}
      role={role}
      aria-modal="true"
      {...aria}
      style={overlayStyle}
      onClick={backdropDismiss ? onClose : undefined}
    >
      <div style={panelStyle} className={panelClassName} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  )
}

```

FILE chrome-extension/src/sidepanel/hooks/useModalDialog.ts
```tsx
// Reusable modal-dialog behavior: focus trap + Escape-to-close + focus restore.
//
// Extracted 1:1 from the inline effect that shipped in SecurityConfirmationDialog
// (audit H10 / PR #19). Generalized so every overlay dialog (settings, MCP form,
// skill craft, security confirm) shares one correctness-checked implementation
// instead of each rolling its own — or (as most did) shipping with none at all.
//
// The focus-wrap logic lives in two PURE helpers below (getFocusableEdges /
// computeTabWrap) plus the FOCUSABLE_SELECTOR constant, all unit-tested without
// a DOM dep (see tests/use-modal-dialog.test.ts — computeTabWrap is
// identity-based; getFocusableEdges takes a stubbed root; the selector is pinned
// as an exact string). The hook itself is a thin, manually-verified effect shell
// over them (its listener wiring is identical to the effect that shipped in
// SecurityConfirmationDialog PR #19).

import { useEffect, useRef } from "react"

export interface UseModalDialogOptions {
  /** Gate: when false the effect is a no-op (and <Modal> renders null). */
  open: boolean
  /** Invoked on Escape. Use a ref-backed handler (this hook stores the latest). */
  onClose: () => void
  /**
   * Element to focus when the dialog opens. Defaults to the first focusable
   * element inside the overlay. SecurityConfirmationDialog points this at the
   * safe non-destructive action ("拒绝") to preserve its shipped behavior.
   */
  initialFocusRef?: React.RefObject<HTMLElement>
  /** Restore focus to the element that was focused before opening. Default true. */
  restoreFocus?: boolean
  /**
   * Extra deps that re-run the effect (re-trap + re-focus) without toggling
   * `open`. Used by SecurityConfirmationDialog to re-focus on each new
   * confirmation_id while the dialog stays open across a queue.
   */
  deps?: ReadonlyArray<unknown>
}

// Focusable elements inside a modal. Mirrors the original query selector, plus
// textarea/select/link for the broader set of dialogs this now serves.
export const FOCUSABLE_SELECTOR =
  'button, input, textarea, select, a[href], [tabindex]:not([tabindex="-1"])'

/**
 * Return the first and last focusable elements under `root`, or null if none.
 * Pure + DOM-driven so it can be unit-tested without React.
 */
export function getFocusableEdges(
  root: HTMLElement,
): { first: HTMLElement; last: HTMLElement } | null {
  const list = root.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)
  if (!list.length) return null
  return { first: list[0], last: list[list.length - 1] }
}

/**
 * Decide whether a Tab keypress at the edge of the focus cycle should wrap.
 * Returns "first" (move focus to first), "last" (move to last), or null (let
 * the browser handle it natively). Pure for testability.
 */
export function computeTabWrap(
  active: Element | null,
  first: HTMLElement,
  last: HTMLElement,
  shiftKey: boolean,
): "first" | "last" | null {
  if (shiftKey && active === first) return "last"
  if (!shiftKey && active === last) return "first"
  return null
}

export function useModalDialog(opts: UseModalDialogOptions) {
  const overlayRef = useRef<HTMLDivElement>(null)
  // Keep the latest onClose without re-subscribing the listener each render
  // (mirrors the denyRef pattern the security dialog already used).
  const onCloseRef = useRef(opts.onClose)
  onCloseRef.current = opts.onClose

  const { open, initialFocusRef, restoreFocus = true, deps = [] } = opts

  useEffect(() => {
    if (!open) return
    const overlay = overlayRef.current
    if (!overlay) return

    const prevFocus = document.activeElement as HTMLElement | null

    // Initial focus: caller-specified element, else first focusable in the overlay.
    if (initialFocusRef?.current) {
      initialFocusRef.current.focus()
    } else {
      const edges = getFocusableEdges(overlay)
      edges?.first.focus()
    }

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault()
        e.stopPropagation()
        onCloseRef.current()
        return
      }
      if (e.key === "Tab") {
        const edges = getFocusableEdges(overlay)
        if (!edges) return
        const wrap = computeTabWrap(document.activeElement, edges.first, edges.last, e.shiftKey)
        if (wrap === "last") {
          e.preventDefault()
          edges.last.focus()
        } else if (wrap === "first") {
          e.preventDefault()
          edges.first.focus()
        }
      }
    }

    overlay.addEventListener("keydown", onKeyDown)
    return () => {
      overlay.removeEventListener("keydown", onKeyDown)
      if (restoreFocus) prevFocus?.focus()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialFocusRef, ...deps])

  return overlayRef
}

```

DIFF chrome-extension/src/sidepanel/App.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/App.tsx b/chrome-extension/src/sidepanel/App.tsx
index 6f7f2039..34bc56b9 100644
--- a/chrome-extension/src/sidepanel/App.tsx
+++ b/chrome-extension/src/sidepanel/App.tsx
@@ -1,47 +1,44 @@
-/* THESIS: Side Panel is a consumer assistant empty, not an instrument desk — first viewport is a person who greets you.
-   OWN-WORLD: White surface, ink type, 22px greeting, sentence rows, circular send, indigo spark only on the companion mark.
-   STORY: Open → meet someone → type or tap a sentence → work still fits 320px.
-   FIRST VIEWPORT: Centered CompanionMark, 要我帮你做什么？, sentence invitations, quiet composer, 新对话.
-   FORM: Canon (知乎看山 quality bar) · seed e96a500f · Comp A approved.
-   FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, and DESIGN.md */
+// #469: responsive conversation workspace; root DESIGN.md.
 // CMspark Browser Agent — Root App Component
 
 import { Component, useState, useRef, useCallback, useEffect } from "react"
 import { useWebSocket } from "./hooks/useWebSocket"
 import { useCapabilityMode } from "./hooks/useCapabilityMode"
 import { ToastHost, useToastQueue } from "./components/ToastHost"
 import { ChatView } from "./components/ChatView"
 import {
   ContextPanelHost,
   ContextPanelHostProvider,
   useContextPanelHost,
 } from "./components/ContextPanelHost"
 import { FocusBand } from "./components/FocusBand"
 import { CodingAgentPanel } from "./components/CodingAgentPanel"
 import { SettingsSlideout } from "./components/SettingsSlideout"
 import { McpServerForm } from "./components/McpServerForm"
 import { SlashCommandPopover } from "./components/SlashCommandPopover"
 import { AtThreadPopover } from "./components/AtThreadPopover"
 import { SkillCraftPanel } from "./components/SkillCraftPanel"
 import { NotebooklmImporterPanel } from "./components/NotebooklmImporterPanel"
 import { StatusRail } from "./components/StatusRail"
 import { ComposerChips } from "./components/ComposerChips"
 import { ComposerCruisePicker } from "./components/ComposerCruisePicker"
+import { WorkspaceFrame } from "./components/WorkspaceFrame"
+import { workspaceCSS } from "./ui/workspace-styles"
 import { ComposerDock } from "./components/ComposerDock"
 import { ComposeDrawer } from "./components/ComposeDrawer"
 import { ThreadRefChips } from "./components/ThreadRefChips"
 import { UploadChips } from "./components/UploadChips"
 import { VoiceBanner } from "./components/VoiceBanner"
 import { AgentStoreProvider, useAgentStore } from "./store/agentStore"
 import type { CapabilityLevel, FileAttachment } from "./types"
 import {
   composerPlaceholder,
   type ComposerChipAction,
 } from "./composer/meta-slash"
 import { tokens } from "./ui/tokens"
 import { PanelBanner, panelBannerBtnStyles } from "./ui/PanelBanner"
 import {
   IconSend,
   IconStop,
   IconAttach,
   IconAlert,
@@ -196,58 +193,60 @@ function AppContent() {
       showToast(detail)
     }
     window.addEventListener("cmspark:toast", onToast as EventListener)
     return () => window.removeEventListener("cmspark:toast", onToast as EventListener)
   }, [showToast])
   const { level, badgeLabel } = useCapabilityMode(onEscalate)
   const isComputer = level === "computer"
 
   // P1: auto-open Cockpit when entering L2 (openOrFocus is idempotent)
   useEffect(() => {
     if (!isComputer) return
     chrome.runtime.sendMessage({ type: "cockpit.open" }, () => {
       void chrome.runtime.lastError
     })
   }, [isComputer])
 
   return (
     <ContextPanelHostProvider capabilityLevel={level}>
+    <WorkspaceFrame>
     <div style={styles.container}>
-      <style>{globalCSS}</style>
+      <style>{globalCSS + workspaceCSS}</style>
       <StatusRail
         connectionState={connectionState}
         capabilityLevel={level}
         badgeLabel={badgeLabel}
         onCraft={() => setCraftOpen(true)}
         onToggleLogs={() => setShowLogs(!showLogs)}
         onOpenNotebooklmImporter={() => setNbImporterOpen(true)}
         onToast={showToast}
         onPopout={handlePopout}
         canPopout={!!appState.activeThreadId}
       />
-      {/* #321 PR-3: toast host lives in a zero-height slot right under the rail —
-          its top is DOM-anchored to the rail, so no `top:52` rail-height magic. */}
-      <div style={{ position: "relative", height: 0, flexShrink: 0 }}>
-        <ToastHost toasts={toasts} onClose={closeToast} />
-      </div>
       {/* UIUX v2 §4.3 FocusBand: Confirm > L2 Safety+急停 > Fleet > L1 Context; ≤80px.
           #321 PR-2「一条 Now」: SceneStatusBar / RunBusyChip / WorkerScopeBar merged
           into FocusBand slots — no fourth band above the conversation. */}
       <FocusBand capabilityLevel={level} />
+      {/* #321 PR-3: toast host lives in a zero-height slot after the priority FocusBand —
+          its top is DOM-anchored below confirmation, so no `top:52` height magic. */}
+      <div style={{ position: "relative", height: 0, flexShrink: 0 }}>
+        <ToastHost toasts={toasts} onClose={closeToast} />
+      </div>
+
       <ChatView />
       <FleetWorkerListPortal />
       {/* R3: ComputerTaskBar removed — step timeline only in Cockpit dual-track */}
       {/* #321 PR-1: legacy BottomBar strip deleted (was permanently gated off). Host is SoT. */}
       <ContextPanelHost />
       <InputArea capabilityLevel={level} />
       {showLogs && <LogBar onClose={() => setShowLogs(false)} />}
       <SettingsSlideout />
       {/* Full-height 编程接力 壳 — replaces old task-package-only modal as primary UX */}
       <CodingAgentPanel
         open={codingPanelOpen}
         onClose={() => setCodingPanelOpen(false)}
         workspaceRoot={
           (
             appState.threads.find((t) => t.id === appState.activeThreadId) as
               | { workspace_root?: string | null }
               | undefined
           )?.workspace_root ?? null
@@ -280,36 +279,37 @@ function AppContent() {
               showToast("无法联系扩展后台，请刷新 Side Panel 后重试", "error")
               return
             }
             chrome.runtime.sendMessage({ type: "getStatus" }, (response) => {
               if (chrome.runtime.lastError) {
                 showToast("正在尝试重新连接…", "warning")
                 return
               }
               if (response?.connectionState === "connected") {
                 showToast("已连接 Companion", "info")
                 return
               }
               showToast("正在尝试重新连接…若 Companion 已启动将自动恢复", "warning")
             })
           })
         }}
       />
     </div>
+    </WorkspaceFrame>
     </ContextPanelHostProvider>
   )
 }
 
 
 function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityLevel }) {
   const { state, dispatch } = useAgentStore()
   const { openPanelForce, closePanel, activePanel } = useContextPanelHost()
   const [text, setText] = useState("")
 
   useEffect(() => {
     const restore = state.composerRestore
     if (!restore?.text) return
     setText((prev) => nextComposerText(prev, restore.text))
     dispatch({ type: "CLEAR_COMPOSER_RESTORE" })
   }, [state.composerRestore?.token])
   const [composeOpen, setComposeOpen] = useState(false)
   const textareaRef = useRef<HTMLTextAreaElement>(null)
@@ -811,37 +811,37 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
 
   const handleStop = () => {
     // SoT §6.4: abort recognition first, then chat.abort
     voice.abortForChatStop()
     chrome.runtime.sendMessage({
       type: "chat.abort",
       threadId: state.activeThreadId,
     })
     dispatch({ type: "SET_STREAMING", content: "" })
     dispatch({ type: "SET_STREAMING_REASONING", content: "" })
     dispatch({ type: "SET_PROCESSING_STATUS", status: null })
     dispatch({ type: "SET_PROCESSING", isProcessing: false })
   }
 
   gestureSendRef.current = (files) => handleSend(files)
 
   return (
     <div
-      style={{ borderTop: `1px solid ${tokens.border}`, flexShrink: 0, position: "relative" as const, background: tokens.bg }}
+      style={{ flexShrink: 0, position: "relative" as const, background: tokens.bg }}
       onPaste={handleComposerPaste}
       onDragEnter={handleComposerDragEnter}
       onDragOver={handleComposerDragOver}
       onDragLeave={handleComposerDragLeave}
       onDrop={handleComposerDrop}
     >
       <input
         ref={fileInputRef}
         type="file"
         hidden
         multiple
         accept={IMAGE_ACCEPT}
         onChange={handleFileSelect}
       />
       <UploadChips
         fileError={fileError}
         onDismissError={() => setFileError("")}
         destAck={destAck}
@@ -861,77 +861,81 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
         onDismiss={() => setAtVisible(false)}
       />
       <VoiceStatusCapsule
         view={capsuleView({
           phase: voice.phase,
           engine: sttEngine === "local" ? "local" : "browser",
           locked: pttLocked,
           level: voiceLevel,
         })}
         level={voiceLevel}
         extraHint={voiceCapsuleHint}
         badge={postprocessedBadge ? POSTPROCESS_BADGE_LABEL : null}
       />
       {/* PR4: ComposerDock chips + capsule; 装配 lives on the chip, not in the field */}
       <ComposerDock
         chips={<ComposerChips capabilityLevel={capabilityLevel} onAction={handleChipAction} />}
       >
         <div
+          className="cm-composer-capsule"
           style={{
             ...styles.composerCapsule,
             opacity: needsThread || needsConnection ? 0.85 : 1,
             background: needsThread || needsConnection ? tokens.bgMuted : tokens.bgElevated,
             borderColor: dragOver ? tokens.accent : tokens.borderStrong,
             boxShadow: dragOver ? `0 0 0 1px ${tokens.accent}` : tokens.shadowSm,
           }}
         >
-          {/* Attach stays visible in the empty composer — first-run affordance. */}
-          {!showStop && !(voice.listening && showVoiceMic) && (
-            <button
-              type="button"
-              style={styles.attachBtn}
-              onClick={() => fileInputRef.current?.click()}
-              // l2_task: ingest is blocked for an active computer task — don't
-              // present a clickable affordance whose selection is silently dropped.
-              disabled={needsThread || needsConnection || threadBusy || composerMode === "l2_task" || !!overlayStandby}
-              title="添加文件或图片"
-              aria-label="添加文件或图片"
-            >
-              <IconAttach size={16} />
-            </button>
-          )}
           <textarea
+            aria-label="消息内容"
             ref={textareaRef}
             style={styles.textarea}
             placeholder={getPlaceholder()}
             rows={1}
             value={voice.liveOverlay !== null ? voice.liveOverlay : text}
             // Disable whenever live overlay owns the value (listening + processing gaps).
             // Otherwise keystrokes are invisible and next final flush overwrites them.
             disabled={
               needsThread ||
               needsConnection ||
               voice.liveOverlay !== null ||
               !!overlayStandby
             }
             onChange={handleChange}
             onKeyDown={handleKeyDown}
             onPaste={handleComposerPaste}
           />
+          <div className="cm-composer-actions">
+          {/* Attach stays visible in the empty composer — first-run affordance. */}
+          {!showStop && !(voice.listening && showVoiceMic) && (
+            <button
+              type="button"
+              style={styles.attachBtn}
+              onClick={() => fileInputRef.current?.click()}
+              // l2_task: ingest is blocked for an active computer task — don't
+              // present a clickable affordance whose selection is silently dropped.
+              disabled={needsThread || needsConnection || threadBusy || composerMode === "l2_task" || !!overlayStandby}
+              title="添加文件或图片"
+              aria-label="添加文件或图片"
+            >
+              <IconAttach size={16} />
+            </button>
+          )}
+          <span style={{ flex: 1 }} />
           {showVoiceMic && (
             <VoiceMicButton
               listening={voice.listening && !voice.processing}
               processing={voice.processing}
               disabled={voiceMicDisabled && !voice.listening}
               title={voiceMicTitle}
               timerLabel={voiceMicTimerLabel}
               liveStatus={voiceMicLiveStatus}
               onClick={() => voice.toggle()}
             />
           )}
           {showStop && threadBusy && !taskActive && (
             <button
               type="button"
               style={styles.sendBtn}
               onClick={() => handleSend()}
               disabled={!canSend}
               title="纠偏当前这一轮"
@@ -956,60 +960,61 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
               type="button"
               style={styles.stopBtn}
               onClick={handleStop}
               title={
                 voice.listening
                   ? "停止听写并停止本轮"
                   : isWorker
                     ? "停止该子任务（本轮）"
                     : "停止本轮"
               }
             >
               <IconStop size={14} />
             </button>
           ) : (
             <button
               type="button"
               style={{
                 ...styles.sendBtn,
-                background: canSend ? tokens.accent : tokens.sendDisabledBg,
+                background: canSend ? tokens.actionPrimary : tokens.sendDisabledBg,
                 color: canSend ? tokens.userBubbleText : tokens.textMuted,
                 cursor: canSend ? "pointer" : "not-allowed",
               }}
               onClick={() => handleSend()}
               disabled={!canSend}
               title={
                 overlayStandby
                   ? overlayStandby.label
                   : needsThread
                     ? "请先创建线程"
                     : needsConnection
                       ? "Companion 未连接"
                       : taskActive
                         ? "任务进行中，请在确认台发送"
                         : threadBusy
                           ? "本对话处理中"
                           : "发送"
               }
             >
               <IconSend size={15} />
             </button>
           )}
 
+          </div>
         </div>
         <VoiceBanner
           banner={voice.banner}
           engineSwitchNote={engineSwitchNote}
           rawSnapshot={voice.rawSnapshot}
           refining={voice.refining}
           voiceBannerCta={voiceBannerCta}
           onRestoreRaw={() => voice.restoreRaw()}
           onSwitchBrowser={handleSwitchBrowserEngine}
           onOpenSettings={handleOpenVoiceSettings}
           onDismiss={() => {
             voice.dismissBanner()
             setEngineSwitchNote(null)
           }}
         />
         <VoicePrivacySheet
           open={voicePrivacyOpen}
           kind={voicePrivacyKind}
@@ -1168,51 +1173,53 @@ const globalCSS = `
   button:active:not(:disabled) {
     transform: scale(0.98);
   }
   @media (prefers-reduced-motion: reduce) {
     *, *::before, *::after {
       animation-duration: 0.01ms !important;
       animation-iteration-count: 1 !important;
       transition-duration: 0.01ms !important;
     }
     button:active:not(:disabled) { transform: none; }
   }
 `
 
 const styles: Record<string, React.CSSProperties> = {
   // Precision Instrument Desk — solid canvas, flat composer (Phase 1)
   container: {
     display: "flex",
     flexDirection: "column",
-    height: "100vh",
+    height: "100%",
+    minHeight: 0,
     fontFamily: tokens.font,
     fontSize: 13,
     color: tokens.text,
     background: tokens.bg,
     WebkitFontSmoothing: "antialiased",
     position: "relative" as const,
   },
   composerCapsule: {
     display: "flex",
-    alignItems: "flex-end",
+    flexDirection: "column",
+    alignItems: "stretch",
     gap: 8,
     border: `1px solid ${tokens.border}`,
     borderRadius: tokens.radiusComposer,
-    padding: "6px 10px 6px 12px",
+    padding: "10px 12px 10px 14px",
     background: tokens.bgElevated,
     minHeight: 52,
     transition: `border-color ${tokens.transitionFast} ease, box-shadow ${tokens.transitionFast} ease`,
   },
   textarea: {
     flex: 1,
     // Replaced element: without minWidth 0 the cols=20 min-content overflows
     // the 4-element capsule row (attach/textarea/mic/send) in narrow panels.
     minWidth: 0,
     border: "none",
     borderRadius: tokens.radiusMd,
     padding: "4px 0",
     fontSize: 14,
     fontFamily: "inherit",
     resize: "none" as const,
     outline: "none",
     minHeight: 32,
     maxHeight: 120,

```

DIFF chrome-extension/src/sidepanel/components/StatusRail.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/components/StatusRail.tsx b/chrome-extension/src/sidepanel/components/StatusRail.tsx
index c229091e..19f6b0f7 100644
--- a/chrome-extension/src/sidepanel/components/StatusRail.tsx
+++ b/chrome-extension/src/sidepanel/components/StatusRail.tsx
@@ -1,35 +1,37 @@
 // StatusRail — Zone A (UIUX v2 PR1)
 // Mode badge + pin · connection (token colors) · thread switcher · ⋯ menu
 
 import { useState, useRef, useEffect, type CSSProperties } from "react"
 import { ThreadList, createBlankThread } from "./ThreadList"
 import { useAgentStore } from "../store/agentStore"
 import type { ConnectionState, CapabilityLevel } from "../types"
 import {
   tokens,
   connectionColor,
   connectionLabel,
   connectionDotShadow,
 } from "../ui/tokens"
+import { displayThreadTitle } from "../utils/thread-timeline"
 import { popupMenuStyles } from "../ui/popupMenuStyles"
 import { ModeBadge } from "../ui/ModeBadge"
 
 import {
+  IconList,
   IconCraft,
   IconDownload,
   IconNotebook,
   IconSave,
   IconBrain,
   IconLogs,
   IconSettings,
   IconAlert,
   IconSpinner,
   IconMore,
   IconNewChat,
   IconExternal,
   CompanionMark,
 } from "../ui/icons"
 import { disarmAllFlags, trustStatusChip, trustStatusChipShort } from "./autopilot-tier"
 
 export function StatusRail({
   connectionState,
@@ -182,65 +184,59 @@ export function StatusRail({
   const cruiseDetail = trustStatusChip(armFlags, unattendedArmed)
   const cruiseLabel = trustStatusChipShort(armFlags, unattendedArmed)
   const disarmCruise = () => {
     // Full disarm: unattended grant + cruise flags (clear_cruise on companion)
     chrome.runtime.sendMessage({ type: "security.unattended.disarm", clear_cruise: true })
     chrome.runtime.sendMessage({ type: "config.set", config: disarmAllFlags() })
   }
 
   // G1: no full-rail mode fill — badge carries mode; L1/L2 get a 3px accent line only.
   const modeLine =
     capabilityLevel === "browser"
       ? tokens.modeBrowserLine
       : capabilityLevel === "computer"
         ? tokens.modeComputerLine
         : null
 
   return (
     <div
+      className="cm-status-rail"
       role="banner"
       aria-label="状态栏"
       style={{
         ...railStyles.rail,
         ...(modeLine ? { boxShadow: `inset 0 -2px 0 ${modeLine}` } : null),
       }}
     >
+      <button type="button" className="cm-icon-button cm-navigation-toggle" aria-label="打开工作区导航" onClick={() => window.dispatchEvent(new Event("cmspark:toggle-navigation"))}><IconList size={16} /><span style={{ fontSize: 12 }}>导航</span></button>
       <ModeBadge
         level={capabilityLevel}
         label={badgeLabel}
         pinned={pinned}
         onTogglePin={togglePin}
         whisper
       />
       {/* Brand point (small CompanionMark) — #321 PR-3: resident, no longer hidden
           on cruise / disconnect. Decorative (CompanionMark stays aria-hidden). */}
       <div style={railStyles.brand} title="CMspark" aria-label="CMspark">
         <CompanionMark size={16} />
       </div>
+      <div className="cm-task-title" title={state.threads.find(t => t.id === activeThreadId)?.alias || "新对话"}>{state.threads.find(t => t.id === activeThreadId) ? displayThreadTitle(state.threads.find(t => t.id === activeThreadId)!) : "新对话"}</div>
       <div style={railStyles.cluster}>
-      <button
-        type="button"
-        style={railStyles.ghostBtn}
-        title="新增对话"
-        aria-label="新增对话"
-        onClick={() => createBlankThread(dispatch)}
-      >
-        <IconNewChat size={18} />
-      </button>
       <button
         type="button"
         style={{
           ...railStyles.ghostBtn,
           ...(canPopout ? {} : { opacity: 0.45, cursor: "not-allowed" }),
         }}
         title="弹出对话框"
         aria-label="弹出对话框"
         onClick={() => {
           if (canPopout) onPopout()
         }}
         disabled={!canPopout}
       >
         <IconExternal size={16} />
       </button>
       <ThreadList />
       </div>
       {cruiseLabel && (

```

DIFF chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx b/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
index c9861cf0..067d999c 100644
--- a/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
+++ b/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
@@ -831,44 +831,57 @@ export function SettingsSlideout() {
       chrome.runtime.sendMessage({ type: "config.testVision" })
     }
   }
 
   const toggleSafetySkill = (skillId: string) => {
     const current = config.safety_skills_enabled || []
     const next = current.includes(skillId)
       ? current.filter(id => id !== skillId)
       : [...current, skillId]
     dispatch({ type: "SET_CONFIG", config: { safety_skills_enabled: next } })
   }
 
   return (
     <Modal
       open={state.settingsOpen}
       onClose={() => dispatch({ type: "TOGGLE_SETTINGS" })}
       overlayStyle={styles.backdrop}
       panelStyle={styles.panel}
+      panelClassName="cm-settings-panel"
       ariaLabel="设置"
     >
-        <div style={styles.header}>
+        <div className="cm-settings-header" style={styles.header}>
           <h3 style={{ margin: 0, fontSize: 15 }}>设置</h3>
-          <button style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
+          <button type="button" aria-label="关闭设置" className="cm-icon-button" style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
         </div>
 
-        <div style={{ ...styles.body, display: "flex", flexDirection: "column" }}>
+        <nav aria-label="设置分类" className="cm-settings-categories">
+          {[
+            ["model", "模型与推理"], ["connection", "连接与配对"], ["security", "安全与信任"],
+            ["secrets", "密钥与环境"], ["integrations", "本机与集成"], ["export", "导出与集成"], ["experimental", "实验功能"],
+          ].map(([id, label]) => <button key={id} type="button" onClick={() => {
+            dispatch({ type: "OPEN_SETTINGS_SECTION", section: id })
+            requestAnimationFrame(() => requestAnimationFrame(() => {
+              const heading = document.querySelector<HTMLElement>(`[data-settings-section="${label}"] > button`)
+              heading?.focus(); heading?.scrollIntoView({ block: "start" })
+            }))
+          }}>{label}</button>)}
+        </nav>
+        <div className="cm-settings-body" style={{ ...styles.body, display: "flex", flexDirection: "column" }}>
           {/* D2+ : configure CMspark itself via text or voice */}
           <div style={{ order: 0 }}>
             <SettingsIntentBar onIntent={applySettingsIntent} />
           </div>
 
           {/* IA order via flex order (settings-thread-compact W1) */}
 
           <div style={{ order: 1 }}>
             <SettingsSection
               title="连接与配对"
               open={isSectionOpen("connection")}
               onToggle={() => handleToggleSection("connection")}
               badge={wsPaired === false ? (
                 <span style={{
                   fontSize: 10,
                   fontWeight: 600,
                   padding: "1px 6px",
                   borderRadius: 8,
@@ -4253,41 +4266,41 @@ export function SettingsSlideout() {
           <div style={{
             fontSize: 11,
             color: tokens.textMuted,
             padding: "8px 16px",
             borderTop: `1px solid ${tokens.border}`,
             textAlign: "center",
           }}>
             Companion 全局配置已同步{state.companionConfig.model_name ? ` (${state.companionConfig.model_name})` : ""}
           </div>
         )}
     </Modal>
   )
 }
 
 const styles: Record<string, React.CSSProperties> = {
   backdrop: {
     position: "fixed",
     inset: 0,
-    background: "rgba(0,0,0,0.3)",
+    background: tokens.scrim,
     zIndex: 200,
     display: "flex",
-    alignItems: "flex-end",
-    justifyContent: "stretch",
+    alignItems: "center",
+    justifyContent: "center",
   },
   panel: {
     width: "100%",
     maxHeight: "80vh",
     background: tokens.bgElevated,
     borderRadius: "12px 12px 0 0",
     overflow: "hidden",
     display: "flex",
     flexDirection: "column",
   },
   header: {
     display: "flex",
     justifyContent: "space-between",
     alignItems: "center",
     padding: "14px 16px",
     borderBottom: `1px solid ${tokens.border}`,
   },
   closeBtn: {

```

DIFF chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
index 39f2c5c0..35a41503 100644
--- a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
+++ b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
@@ -260,37 +260,37 @@ export function ContextPanelHostProvider({
       {children}
     </ContextPanelHostContext.Provider>
   )
 }
 
 // ── Panel body mount ───────────────────────────────────────────────────────
 
 /**
  * Renders the open context panel body (header + body). Place above ComposerDock
  * (Host is SoT for panels).
  */
 export function ContextPanelHost() {
   const { activePanel, closePanel } = useContextPanelHost()
   if (!activePanel) return null
 
   const label = contextPanelLabel(activePanel)
 
   return (
-    <div style={styles.panel} data-testid="context-panel-host">
+    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
       <div style={styles.panelHeader}>
         <span style={styles.panelTitle}>{label}</span>
         <button
           type="button"
           style={styles.panelCloseBtn}
           title="收起面板 (Esc)"
           aria-label="收起面板"
           onClick={closePanel}
         >
           收起
         </button>
       </div>
       {activePanel === "tabs" && <TabsPanel />}
       {activePanel === "history" && <HistoryPanel />}
       {activePanel === "skills" && <SkillsPanel />}
       {activePanel === "knowledge" && <KnowledgeSubPanel />}
       {activePanel === "packs" && <PacksPanel />}
       {activePanel === "meeting" && (

```

DIFF chrome-extension/src/sidepanel/components/ComposerDock.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/components/ComposerDock.tsx b/chrome-extension/src/sidepanel/components/ComposerDock.tsx
index 71f43daa..6bb36258 100644
--- a/chrome-extension/src/sidepanel/components/ComposerDock.tsx
+++ b/chrome-extension/src/sidepanel/components/ComposerDock.tsx
@@ -1,31 +1,31 @@
 // ComposerChips container — cut out of App.tsx InputArea in #321 PR-7.
 // Pure move of the `styles.inputArea` wrapper. Chips still render via ComposerChips;
 // the capsule / send cluster stays the caller's child (send-matrix visuals untouched).
 
 import type { CSSProperties, ReactNode } from "react"
 import { tokens } from "../ui/tokens"
 
 export type ComposerDockProps = {
   chips: ReactNode
   children: ReactNode
 }
 
 export function ComposerDock({ chips, children }: ComposerDockProps) {
   return (
-    <div style={styles.inputArea}>
+    <div className="cm-composer-dock" style={styles.inputArea}>
       {chips}
       {children}
     </div>
   )
 }
 
 const styles: Record<string, CSSProperties> = {
   inputArea: {
     display: "flex",
     flexDirection: "column",
     padding: "8px 14px 12px",
     background: tokens.bgElevated,
     flexShrink: 0,
     position: "relative" as const,
   },
 }

```

Existing context owner
export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const closePanel = useCallback(() => {
    setActivePanel(null)
  }, [])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activeThreadId, dispatch],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      if (activePanel === id) {
        setActivePanel(null)
        return
      }
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activePanel, activeThreadId, dispatch],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      setActivePanel(null)
    }
  }, [activePanel, allowedIds, overflowIds])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      setActivePanel(raw)
      loadPanelData(raw, activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [activeThreadId, dispatch])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      setActivePanel(null)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel }),
    [activePanel, openPanel, openPanelForce, closePanel],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel } = useContextPanelHost()
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        <button
          type="button"
          style={styles.panelCloseBtn}
          title="收起面板 (Esc)"
          aria-label="收起面板"
          onClick={closePanel}
        >
          收起
        </button>
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}


Existing thread select behavior
  const handleSelect = (threadId: string) => {
    if (selectMode) {
      if (threadBusyById[threadId]) return
      setSelected((prev) => {
        const next = new Set(prev)
        if (next.has(threadId)) next.delete(threadId)
        else next.add(threadId)
        return next
      })
      return
    }
    // Dual-review residual: do not activate soft-deleted threads into main chat
    if (trashView) return
    const thr = threads.find((t) => t.id === threadId)
    if (thr?.trashed_at) return
    dispatch({ type: "SET_ACTIVE_THREAD", threadId })
    chrome.runtime.sendMessage({ type: "thread.select", threadId })
    setOpen(false)
  }


Existing settings section deep link
  // F-UX7 deep-link: open target accordion section once settings opens.
  useEffect(() => {
    if (!state.settingsOpen || !state.settingsFocusSection) return
    const id = state.settingsFocusSection as SettingsSectionId
    if (!(SETTINGS_SECTION_IDS as readonly string[]).includes(id)) {
      dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
      return
    }
    setUserOpenSections((prev) => {
      if (prev.has(id)) return prev
      const next = new Set(prev)
      next.add(id)
      try {
        localStorage.setItem(LS_SETTINGS_EXPAND, serializeSettingsExpand(next))
      } catch {
        /* ignore */
      }
      return next
    })
    dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
  }, [state.settingsOpen, state.settingsFocusSection, dispatch])


Existing recent title resolver
// Thread History IA — calendar grouping + filter helpers (pure).
// Spec: docs/superpowers/specs/2026-08-06-thread-history-ia-product-design.md

export type AcpListMeta = {
  outcome?: "ok" | "partial" | "fail" | "cancelled"
  agent_id?: string
  goal_preview?: string
}

export type TimelineThread = {
  id: string
  alias?: string
  created_at?: string
  updated_at?: string
  /** Last persisted transcript row. Human-facing recency; never `updated_at`. */
  last_message_at?: string | null
  /** First user message preview (optional, from companion list enrichment). */
  first_user_preview?: string | null
  agent_role?: "normal" | "orchestrator" | "worker" | string
  message_count?: number
  user_message_count?: number
  /** First-party ACP list meta from companion — never parsed from handback body. */
  acp_list?: AcpListMeta | null
  digest?: {
    tldr?: string
    tags?: string[]
    bullets?: string[]
    extracted_at?: string
    content_fingerprint?: string
    stale?: boolean
  } | null
}

export type DayGroup = {
  /** Local calendar day key YYYY-MM-DD */
  dayKey: string
  /** Display label e.g. 07-28 */
  label: string
  threads: TimelineThread[]
}

export type MonthGroup = {
  /** Local calendar month key YYYY-MM */
  monthKey: string
  /** Display label e.g. 2026-07 */
  label: string
  days: DayGroup[]
  /** Flat count of threads in this month */
  count: number
}

export type TimelineModel = {
  today: TimelineThread[]
  /** Local calendar yesterday (default collapsed — 2026-08-06 adversary lock) */
  yesterday: TimelineThread[]
  months: MonthGroup[]
}

/** Unified fold memory (History IA + settings-thread-compact). */
export const LS_THREAD_LIST_EXPAND = "cmspark.threadList.expand"
/** Legacy key — migrated once into LS_THREAD_LIST_EXPAND. */
export const LS_THREAD_LIST_EXPAND_MONTHS_LEGACY = "cmspark.threadList.expandMonths"

export type ThreadListExpandState = {
  months: string[]
  /** Default true when missing */
  today: boolean
  /** Default false when missing (yesterday collapsed) */
  yesterday: boolean
}

export const DEFAULT_THREAD_LIST_EXPAND: ThreadListExpandState = {
  months: [],
  today: true,
  yesterday: false,
}

export function parseThreadListExpand(raw: string | null): ThreadListExpandState {
  if (!raw) return { ...DEFAULT_THREAD_LIST_EXPAND, months: [] }
  try {
    const parsed = JSON.parse(raw)
    // Legacy: bare string[] of month keys
    if (Array.isArray(parsed)) {
      return {
        months: parsed.filter((x): x is string => typeof x === "string"),
        today: DEFAULT_THREAD_LIST_EXPAND.today,
        yesterday: DEFAULT_THREAD_LIST_EXPAND.yesterday,
      }
    }
    if (parsed && typeof parsed === "object") {
      const months = Array.isArray(parsed.months)
        ? parsed.months.filter((x: unknown): x is string => typeof x === "string")
        : []
      return {
        months,
        today: typeof parsed.today === "boolean" ? parsed.today : DEFAULT_THREAD_LIST_EXPAND.today,
        yesterd