You are an independent INTERACTION PRODUCT-UX/CORRECTNESS/SAFETY adversarial reviewer for CMspark #469. READ-ONLY, inspect only packet. Base8656df94, uncommitted frozen scoped files below. User requests comprehensive simple spacious Codex-inspired redesign, no copy assets. Distinct implementation gate, not design approval. Outcome/trajectory/component: find concrete bugs, lost affordances, keyboard/confirmation regressions, maintainability. T3 unchanged origin/L2/stop; no backend/policy/default changes. Confirmation source handlers/DOM remain byte-unchanged; only token consumers and toast placement. No new production deps.
Machine: latest production extension build exit0 (tsc+Plasmo), full1281/1281 exit0; actual React App synthetic Chrome/transport matrix passed320/390/759/760/800/1440, short-window composer, drawer focus/Escape, settings deep links, history keyboard, tool disclosure, simultaneous context+confirmation buttons hit-tested visible and no approval sent, reduced-motion/equivalent200% CSS reflow. Actual xterm report UI test pass after style changes. Additional running/offline test is being exercised separately, not claimed yet.
Scope claim: main React web workspace redesigned; Cockpit/graphs inherit token surfaces only; native Swift/Windows and independent HTML capture not redesigned or certified. No release/appreplace. Previous design MAJOR locks closed by actual pair; require code review independent now. Any P0/P1/MAJOR concrete defect blocks merge regardless positive label. End VERDICT APPROVE|APPROVE_WITH_NITS|REJECT. No reward for verbosity or stylistic preference.

DESIGN CONTRACT
# Design

## Source of truth
Active · 2026-09-07 · GitHub #469. This file owns product-wide UI/UX direction.
`docs/DESIGN.md` retains detailed capability and safety contracts; this revision
supersedes its consumer-mascot-first layout, tiny chrome and narrow-only shell.
Evidence: Sidepanel App, StatusRail, ThreadList, ChatView, ComposerDock,
ContextPanelHost, SettingsSlideout, shared tokens/Modal, Cockpit and terminal.
No current Codex screenshot was accessed: the reference is the user's stated
preference for quiet, spacious hierarchy, not a pixel-matching target.

## Brand
Calm, precise, capable. CMspark remains its own identity. Neutral paper and ink,
small existing mark, restrained indigo links/focus, semantic risk colors.
Avoid promotional dashboards, gradients, oversized mascots, dense icon ribbons,
unexplained technical acronyms and decorative status lights.

## Product goals
Make the next action obvious; keep conversation readable; let users find prior
work and supporting capabilities without remembering hidden menus. Preserve all
existing functions, confirmations, busy states and honest evidence gaps.
Success: no horizontal page overflow at 320px; usable content at 1440px; keyboard
reachable navigation/history/settings; input and stop remain reachable at short
height; dangerous actions never gain an implicit approval.
Non-goals: runtime redesign, new permission model, copying Codex assets, release.

## Personas and jobs
Enterprise change manager assembles sourced material across websites; developer
connects requirements/code/tests and optionally uses a terminal; everyday user
reads and acts on the current page. Each needs a quiet primary conversation and
clear separation of supporting configuration from execution.

## Information architecture
One responsive conversation workspace. At wide width, a quiet left navigation
shows new conversation, recent conversations and supporting resources. At narrow
width, navigation opens through the text-labeled header control 导航 as an explicit drawer; primary conversation keeps full
width. Existing full history preserves search, folders, trash and bulk actions.
StatusRail remains the single conversation header: 导航 (narrow only), task title, existing popout/history/status/more. New conversation is owned by WorkspaceNavigation; no second new-thread control in the header. Recent rows are a projection of the existing store, while full history preserves its original owner. Conversation header shows task title (existing title resolver, 新对话 fallback); page/context and pending confirmation stay
in the existing FocusBand. Knowledge/scenes/skills/MCP/apps/meetings use existing
ContextPanelHost. The host is already vertically stacked, not a fixed-width side column: preserve that safe layout, cap it to36dvh (28dvh below560px height), and close supporting panels before opening configuration. Do not overlay pending confirmation. Settings is one named dialog with grouped sections.
No duplicated data loader, thread cache, Agent or confirmation center.

## Design principles
One dominant action per area. Progressive disclosure keeps tools/details on
demand; pending confirmation and stop stay visible. Text labels explain navigation.
Layout changes never change trust policy. Confirmation modifications are limited to shared surface colors, type, spacing and focus visibility; component handlers, button order/roles, initial focus, timeout, whitelist and auto-approve copy/defaults stay unchanged. Decision-critical evidence remains at least as visible as baseline. FocusBand confirmation/stop priority remains authoritative, with no second sticky header. Cockpit is in shared visual-token scope; confirmation DOM/handlers remain byte-unchanged. Small screens are a first-class surface.

## Visual language
Keep shared `sidepanel/ui/tokens.ts` the only new color-value owner. Neutral
surfaces and subtle borders, readable secondary text; charcoal primary composer
action, indigo links/focus. Font system sans; body14–15, chrome12–13, headings
15–24. Spacing4/8/12/16/24/32; rounded controls8, cards12, composer20.
Flat navigation, quiet user bubble, unboxed assistant prose, restrained shadows
for floating surfaces only. Existing SVG icons; no added font/network assets.
Respect reduced motion and use short feedback transitions.

## Components
Responsive WorkspaceNavigation plus existing StatusRail/ThreadList; shared
Workspace styles, tokens and Modal. Conversation/readable-width wrappers,
ComposerDock, settings sections, tool disclosure cards, ContextPanelHost and
terminal adopt the same spacing and hierarchy. New classes are explicit, scoped,
and do not infer semantic roles from arbitrary inline-style selectors.

## Accessibility
Target WCAG 2.2 AA practices: text contrast at least4.5:1 for newly styled ordinary text, non-color risk labels, visible
focus, semantic buttons, keyboard Enter/Space, Escape and focus return for
drawers/dialogs, no nested interactive elements. Essential controls at least32px
and primary actions36px; preserve live status and destructive confirmation copy.
Do not claim formal conformance certification from automated testing.

## Responsive behavior
320–759px: full-width chat, navigation drawer, narrow dialogs and no fixed wide
columns. At760px+: persistent220px navigation, central conversation max780px;
wide settings use bounded centered dialog. Short screens scroll the content,
not the entire composer; supporting panel has viewport-relative height cap (min36dvh/360px, or28dvh below560px). Only message space may shrink; if confirmation competes, supporting context must yield.
Browser zoom and long titles/URLs must wrap or truncate without hiding actions.

## Interaction states
Empty state: a short invitation and useful action suggestions; suggestions fill
input, never send. Loading/streaming keeps stop; errors show recovery near source;
offline retains explicit reconnect. Selected navigation uses text plus background.
Confirmation remains distinct from normal tool success; disconnection does not
invent completion. Details expand deliberately without dumping raw JSON first.

## Content voice
Chinese product chrome, clear verbs, short labels. Prefer 对话/知识/场景/设置.
Technical detail belongs inside relevant settings or expanded evidence. Never
relabel an unverified report as approval, a process exit as task success, or a
permission setting as mere appearance.

## Implementation constraints
React18/Plasmo, inline styles plus scoped CSS, existing token owner and icons.
No new production dependency. Real component browser harness with synthetic
transport for wide/narrow/short layouts including759/760 breakpoints and200% equivalent CSS-viewport reflow, keyboard, message/tool/confirmation and
settings flows; production build, full suites and external dual reviews.
Native Swift/Windows platform chrome cannot be certified by the browser harness;
shared web surfaces are verified here, native surfaces remain separately tracked.

## Open questions
- [ ] #469: native host-window visuals on Windows require platform validation;
  owner maintainers. No claim of native cross-platform pixel acceptance.
- [ ] User can refine density after using the shipped redesign; current default
  assumes readable enterprise work rather than dense diagnostics.

FILE chrome-extension/src/sidepanel/ui/tokens.ts
```tsx
// Shared visual tokens — #469 calm workspace; root DESIGN.md governs direction.
// White companion surface. Indigo spark: character pupils + armed send + a
// hairline on the user bubble. The user bubble is NOT a filled indigo slab.
// (#321 PR-4 canon revision: the old header said "indigo only on character +
// armed send" while userBubbleBg === accent — that contradiction is closed here,
// not papered over as "aligning with canon".)
// Chrome stays 11 / 12 / 13 / 15. Empty greeting is the one 22px exemption.

export const tokens = {
  font:
    "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', 'PingFang SC', 'Helvetica Neue', sans-serif",
  fontMono: "ui-monospace, 'SF Mono', Menlo, Consolas, monospace",

  // Light companion canvas
  bg: "#ffffff",
  bgElevated: "#ffffff",
  bgMuted: "#f7f7f5",
  bgHover: "#eeeeec",
  actionPrimary: "#242424",
  navSelected: "#e9e9e6",
  bgActive: "#eef2ff",
  border: "rgba(23, 23, 23, 0.10)",
  borderStrong: "rgba(23, 23, 23, 0.14)",
  text: "#171717",
  textSecondary: "#666666",
  textMuted: "#767676",
  /** Empty-state hero only — not chrome. */
  emptyTitle: 22,

  // Indigo accent — spark for CTA / focus / armed send / bubble hairline
  accent: "#4f46e5",
  accentSoft: "#eef2ff",
  accentText: "#3730a3",
  accentHover: "#4338ca",
  /** Hairline indigo border on soft accent surfaces (status bubble). */
  accentBorderSoft: "rgba(79, 70, 229, 0.12)",

  /**
   * Brand red (terracotta / coral) — empty-state calf mark ONLY.
   * Independent of the danger family: hue 15° vs danger 0°, lighter + higher
   * chroma, so protanopia/deuteranopia simulation keeps ΔE00 ≫ 5 from
   * danger (#c96033 previously collapsed to ~3 under deutan). NEVER reuse
   * danger / dangerSoft / dangerSurface as brand red. Value pinned by
   * tests/calf-mark-323.test.ts (normal ≥10 AND Machado-deutan ≥5).
   */
  brandRed: "#d97757",

  success: "#059669",
  successSoft: "#ecfdf5",
  warning: "#d97706",
  warningSoft: "#fffbeb",
  /** Amber-200 border on warning surfaces (fakeEnd / compact banner). */
  warningBorder: "#fde68a",
  /** Amber-800 text on warningSoft surfaces. */
  warningText: "#92400e",
  danger: "#dc2626",
  dangerSoft: "#fef2f2",
  /** Soft confirm / FocusBand tint (G3; defined early for one SoT) */
  dangerSurface: "rgba(220, 38, 38, 0.08)",
  /** Danger border on light confirm surfaces (FocusBand confirm card). */
  dangerBorder: "rgba(220, 38, 38, 0.28)",
  /** Deep danger border on dark surfaces (急停 / abort buttons). */
  dangerDeep: "#7f1d1d",
  /** Mic-pulse keyframe ring (rgba of danger, start / fade-out end). */
  dangerPulse: "rgba(220, 38, 38, 0.35)",
  dangerPulseFade: "rgba(220, 38, 38, 0)",

  // Mode chips (badge only — no full-rail fill on L0/L1)
  modeChatBg: "#f1f5f9",
  modeChatText: "#334155",
  modeBrowserBg: "#eef2ff",
  modeBrowserText: "#3730a3",
  modeComputerBg: "#052e16",
  modeComputerText: "#6ee7b7",
  /** 3–4px accent line under StatusRail when L1/L2 (not full tint fill) */
  modeBrowserLine: "rgba(79, 70, 229, 0.35)",
  modeComputerLine: "rgba(52, 211, 153, 0.45)",

  // Dark surface (L2 / Cockpit)
  darkBg: "#171717",
  darkElevated: "#222222",
  darkBorder: "rgba(255, 255, 255, 0.08)",
  darkText: "#f1f5f9",
  darkMuted: "#94a3b8",
  darkAccent: "#818cf8",
  darkLive: "#34d399",
  darkDanger: "#f87171",
  darkDangerBg: "#3b1f1f",
  darkWarning: "#fbbf24",
  darkWarningBg: "#422006",
  darkSuccess: "#34d399",

  // Chat bubbles — PR-4 shipped variant A (paper + hairline). Variant B
  // (left indigo bar) is a screenshot alternative, not the live token.
  userBubbleBg: "#f3f3f1",
  /** User-bubble copy. Distinct from userBubbleText (on-accent/on-danger glyphs). */
  userBubbleInk: "#171717",
  userBubbleBorder: "rgba(23, 23, 23, 0.04)",
  /**
   * On-accent / on-danger glyph (send armed, filled buttons). Historical name
   * `userBubbleText` kept so Settings/danger buttons do not silently go dark.
   * User bubble copy uses `userBubbleInk`.
   */
  userBubbleText: "#ffffff",
  assistantBubbleBg: "#ffffff",
  assistantBubbleText: "#0f172a",

  // Motion (Phase 3 — tightened from 150/220)
  transitionFast: "120ms",
  transition: "180ms",

  // Shape: controls 6/8/12; composer matches 看山 invitation (16)
  radiusSm: 6,
  radiusMd: 8,
  radiusLg: 12,
  radiusComposer: 20,
  radiusBubble: 14,
  /** Bottom sheet / 装配 drawer top corners */
  radiusSheet: 16,
  /** Popup menus (StatusRail ⋯ / panel ⋮) */
  radiusMenu: 10,
  radiusPill: 999,

  // One soft elevation ladder — hairline borders do most of the work
  shadowSm: "0 1px 2px rgba(15, 23, 42, 0.04)",
  shadowMd: "0 1px 3px rgba(15, 23, 42, 0.06), 0 4px 12px rgba(15, 23, 42, 0.04)",
  shadowLg: "0 4px 16px rgba(15, 23, 42, 0.08), 0 12px 28px rgba(15, 23, 42, 0.05)",
  shadowFocus: "0 0 0 3px rgba(79, 70, 229, 0.16)",
  /** Quiet indigo glow (armed send / focus). Not a user-bubble fill. */
  shadowAccent: "0 2px 10px rgba(79, 70, 229, 0.20)",
  /** Lightweight popover/dialog elevation (summary card). */
  shadowPopover: "0 4px 16px rgba(0, 0, 0, 0.08)",

  /** Near-transparent tint for quiet containers (reasoning wrap). */
  bgSubtle: "rgba(15, 23, 42, 0.03)",
  /** Mono output surfaces inside bubbles (shell stdout / tool-progress tail). */
  shellOutputBg: "rgba(0, 0, 0, 0.28)",
  toolTailBg: "rgba(0, 0, 0, 0.25)",

  /**
   * Unarmed send button SoT (#321 PR-4). Dedicated zinc fill — not `bgMuted`
   * (canvas mute). FINAL-SYNTHESIS said "bgMuted"; PR-1 added this token for
   * the circular send and it remains the button-specific SoT.
   */
  sendDisabledBg: "#e4e4e7",

  /** Thin, quiet global scrollbar (App global css). */
  scrollbar: "rgba(15, 23, 42, 0.18)",
  scrollbarThumb: "rgba(15, 23, 42, 0.16)",

  /** Modal / drawer scrim */
  scrim: "rgba(15, 23, 42, 0.28)",
  /** Stronger scrim for blocking import/confirm overlays. */
  scrimStrong: "rgba(0, 0, 0, 0.35)",
} as const

export type Tokens = typeof tokens

/** Risk level → light-surface color (never color-only; pair with text label). */
export function riskColor(level?: string): string {
  if (level === "low") return tokens.warning
  if (level === "medium") return tokens.warning
  return tokens.danger
}

/** Risk level → dark-surface color (SafetyStrip / MinimalConfirm). */
export function riskColorDark(level?: string): string {
  if (level === "low") return tokens.darkWarning
  if (level === "medium") return "#fb923c"
  return tokens.darkDanger
}

export function riskLabel(level?: string): string {
  if (level === "low") return "低风险"
  if (level === "medium") return "中风险"
  return "高风险"
}

/** Tool / task status → semantic color. */
export function statusColor(status?: string): string {
  if (status === "error" || status === "failed") return tokens.danger
  if (status === "success" || status === "ok" || status === "finished") return tokens.success
  if (status === "running" || status === "paused") return tokens.warning
  return tokens.textMuted
}

/** WS connection state — StatusRail / popup dots. Never Material #4CAF50/#FF9800/#F44336. */
export type ConnectionStatus = "connected" | "connecting" | "disconnected"

export function connectionColor(state: ConnectionStatus): string {
  if (state === "connected") return tokens.success
  if (state === "connecting") return tokens.warning
  return tokens.danger
}

export function connectionLabel(state: ConnectionStatus): string {
  if (state === "connected") return "已连接"
  if (state === "connecting") return "连接中"
  return "未连接"
}

/** Soft glow under connected dot (rgba of tokens.success #059669). */
export function connectionDotShadow(state: ConnectionStatus): string {
  if (state === "connected") return "0 0 0 3px rgba(5, 150, 105, 0.18)"
  return "none"
}

/**
 * Connection colors for dark surfaces (Cockpit title bar / L2 chrome).
 */
export function connectionColorDark(state: ConnectionStatus): string {
  if (state === "connected") return tokens.darkLive
  if (state === "connecting") return tokens.darkWarning
  return tokens.darkDanger
}

/** Soft glow under connected dot on dark (rgba of tokens.darkLive #34d399). */
export function connectionDotShadowDark(state: ConnectionStatus): string {
  if (state === "connected") return "0 0 0 3px rgba(52, 211, 153, 0.22)"
  return "none"
}

```

FILE chrome-extension/src/terminal/TerminalApp.tsx
```tsx
// #432 内嵌终端 tab 主体（spec §1/§3/§5）。
// xterm.js（canvas 渲染器，无 webgl/wasm CSP 争议）+ Port ⇄ background ⇄ companion PTY。
// 诚实状态机：connecting → running → closed/unsupported/error；不做只读假终端。

import { useEffect, useRef, useState } from "react"
import { Terminal } from "@xterm/xterm"
import { FitAddon } from "@xterm/addon-fit"
import "@xterm/xterm/css/xterm.css"

import { TERMINAL_PORT_NAME } from "../background/terminal"
import {
  terminalB64Decode,
  terminalB64Encode,
  type TerminalServerFrame,
} from "./wire"
import { tokens } from "../sidepanel/ui/tokens"

type TermStatus = "connecting" | "running" | "closed" | "error"

const STATUS_COPY: Record<TermStatus, string> = {
  connecting: "正在开门并启动终端…（首次需确认）",
  running: "",
  closed: "终端会话已结束",
  error: "终端不可用",
}

let sessionSeq = 0

export function TerminalApp() {
  const hostRef = useRef<HTMLDivElement>(null)
  const [status, setStatus] = useState<TermStatus>("connecting")
  const [detail, setDetail] = useState("")
  const [reviewPrompt, setReviewPrompt] = useState("")
  const [reportText, setReportText] = useState("")
  const [reportStatus, setReportStatus] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const submitRef = useRef<((report: unknown) => void) | null>(null)

  useEffect(() => {
    const host = hostRef.current
    if (!host) return

    const term = new Terminal({
      fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
      fontSize: 13,
      cursorBlink: true,
      convertEol: false,
      scrollback: 5000,
      theme: {
        background: tokens.darkBg,
        foreground: tokens.darkText,
      },
    })
    const fit = new FitAddon()
    term.loadAddon(fit)
    term.open(host)
    fit.fit()

    const sessionId = `term.${Date.now().toString(36)}.${(sessionSeq += 1)}`
    const query = new URLSearchParams(window.location.search)
    const threadId = query.get("thread_id"), reviewId = query.get("review_id")
    let inputSeq = 0
    let closedByUs = false
    let sessionEnded = false
    // 会话 keepalive：静默（无输入无输出）不等于孤儿——每 25s ping 重置服务端心跳（spec §4）
    const pingTimer = setInterval(() => {
      send({ type: "terminal.ping", id: sessionId })
    }, 25_000)
    // pi MAJOR-1 ③：开门 watchdog——12s 无 opened/error 一律落 error，不永转圈
    const OPEN_WATCHDOG_MS = 12_000
    let opened = false
    const watchdog = setTimeout(() => {
      if (!opened) {
        setStatus("error")
        setDetail("companion 未响应：请确认 CMspark 在运行，且设置中已开启「内嵌终端」")
      }
    }, OPEN_WATCHDOG_MS)

    const port = chrome.runtime.connect({ name: TERMINAL_PORT_NAME })

    const send = (frame: unknown) => {
      if (sessionEnded) return
      try {
        port.postMessage(frame)
      } catch {
        // SW 已走 — 下面 onDisconnect 不保证触发，直接落终态
        setStatus("closed")
        sessionEnded = true
        clearInterval(pingTimer)
      }
    }
    submitRef.current = report => send({ type: "terminal.review.submit", id: sessionId, user_gesture: true, report })

    const open = () => {
      fit.fit()
      send({
        type: "terminal.open",
        id: sessionId,
        cols: term.cols,
        rows: term.rows,
        user_gesture: true,
        ...(threadId ? { thread_id: threadId } : {}),
        ...(reviewId ? { review_id: reviewId } : {}),
      })
    }

    port.onMessage.addListener((raw: unknown) => {
      const frame = raw as TerminalServerFrame
      if (!frame) return
      // 扩展级错误无会话 id（busy/disconnected/watchdog 同类），不受会话过滤
      if (frame.type === "terminal.error") {
        if (opened) {
          setDetail(frame.error)
          setReportStatus(frame.error)
          setSubmitting(false)
          if (frame.code === "disconnected") { sessionEnded = true; clearInterval(pingTimer); setStatus("closed"); subData.dispose() }
          return
        }
        opened = true // 停 watchdog
        setStatus("error")
        setDetail(frame.error)
        subData.dispose()
        return
      }
      if ((frame as { id?: string }).id !== sessionId) return
      switch (frame.type) {
        case "terminal.opened":
          opened = true
          setStatus("running")
          term.focus()
          if (frame.review_prompt) setReviewPrompt(frame.review_prompt)
          break
        case "terminal.review.received":
          setDetail("")
          setSubmitting(false)
          setReportStatus(`已回传原任务。回执：${frame.receipt_id}。报告与覆盖仍待核实。`)
          break
        case "terminal.data": {
          const seq = frame.seq
          // write 回调 = 「已解析」信号（xterm flowcontrol 指南同构），ack 驱动服务端水位
          term.write(terminalB64Decode(frame.b64), () => {
            send({ type: "terminal.ack", id: sessionId, seq })
          })
          break
        }
        case "terminal.closed": {
          sessionEnded = true
          clearInterval(pingTimer)
          setSubmitting(false)
          opened = true // 终态到达，停 watchdog
          subData.dispose() // pi NIT-2：closed 后不再发 input
          setStatus(frame.error ? "error" : "closed")
          if (frame.error) setDetail(frame.error)
          else if (frame.code === "unsupported") setDetail("当前平台暂不支持内嵌终端（首发仅 macOS）")
          else if (typeof frame.code === "number") setDetail(`进程退出码 ${frame.code}`)
          break
        }
        default:
          break
      }
    })

    port.onDisconnect.addListener(() => {
      if (closedByUs) return
      sessionEnded = true
      clearInterval(pingTimer)
      subData.dispose()
      setSubmitting(false)
      opened = true // 停 watchdog
      setStatus((s) => (s === "running" ? "closed" : s === "connecting" ? "error" : s))
      setDetail((d) => d || "连接中断")
    })

    const subData = term.onData((data) => {
      inputSeq += 1
      send({ type: "terminal.input", id: sessionId, seq: inputSeq, b64: terminalB64Encode(data) })
    })

    let resizeTimer: ReturnType<typeof setTimeout> | null = null
    let pendingResize: { cols: number; rows: number } | null = null
    const subResize = term.onResize(({ cols, rows }) => {
      pendingResize = { cols, rows }
      if (resizeTimer) return
      resizeTimer = setTimeout(() => {
        resizeTimer = null
        if (pendingResize) send({ type: "terminal.resize", id: sessionId, ...pendingResize })
        pendingResize = null
      }, 50)
    })

    const onWinResize = () => fit.fit()
    window.addEventListener("resize", onWinResize)
    const observer = new ResizeObserver(onWinResize)
    observer.observe(host)

    open()

    return () => {
      closedByUs = true
      clearInterval(pingTimer)
      clearTimeout(watchdog)
      if (resizeTimer) clearTimeout(resizeTimer)
      window.removeEventListener("resize", onWinResize)
      observer.disconnect()
      subData.dispose()
      subResize.dispose()
      try {
        port.postMessage({ type: "terminal.close", id: sessionId })
        port.disconnect()
      } catch {
        // 已断
      }
      term.dispose()
      submitRef.current = null
    }
  }, [])

  return (
    <div className="cm-terminal" style={{ display: "flex", flexDirection: "column", height: "100dvh", background: tokens.darkBg, fontFamily: tokens.font }}>
      <style>{`
        .cm-terminal{font-size:13px;line-height:1.6}
        .cm-terminal button{min-height:34px;border:1px solid ${tokens.darkBorder};border-radius:8px;background:${tokens.darkElevated};color:${tokens.darkText};padding:6px 12px;cursor:pointer;font:inherit}
        .cm-terminal button:disabled{opacity:.5;cursor:not-allowed}
        .cm-terminal textarea{box-sizing:border-box;border:1px solid ${tokens.darkBorder};border-radius:8px;background:${tokens.darkElevated};color:${tokens.darkText};padding:12px;font-family:${tokens.fontMono};font-size:12px;resize:vertical}
        .cm-terminal :focus-visible{outline:2px solid ${tokens.darkAccent};outline-offset:2px}
        .cm-terminal summary{cursor:pointer;font-weight:600;min-height:32px}
        .cm-terminal [role=status]{display:block;margin-top:8px;color:${tokens.darkMuted}}
        @media(max-width:480px){.cm-terminal>div:first-of-type{flex-wrap:wrap;gap:6px!important}.cm-terminal details{padding:10px 12px!important}}
      `}</style>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: "14px 20px",
          background: tokens.darkElevated,
          color: tokens.darkText,
          fontSize: 12,
          borderBottom: `1px solid ${tokens.darkBorder}`,
        }}
      >
        <strong>内嵌终端</strong>
        <span style={{ opacity: 0.7 }}>
          {status === "running" ? "运行中" : STATUS_COPY[status]}
          {detail ? ` · ${detail}` : ""}
        </span>
        <span style={{ flex: 1 }} />
        <button
          type="button"
          style={{ fontSize: 12, padding: "2px 10px", cursor: "pointer" }}
          onClick={() => window.close()}
        >
          关闭
        </button>
      </div>
      {reviewPrompt && (
        <details style={{ color: tokens.darkText, padding: "14px 20px", maxHeight: "48vh", overflow: "auto", flexShrink: 0 }} open>
          <summary>代码审阅任务与报告回传</summary>
          <p>在下方终端自行启动已安装的 Agent，再将提示词粘贴到 Agent 内。请勿粘贴到 shell 命令行。</p>
          <textarea aria-label="审阅提示词" readOnly value={reviewPrompt} style={{ width: "100%", height: 100 }} />
          <button type="button" onClick={() => navigator.clipboard.writeText(reviewPrompt).catch(() => setReportStatus("复制失败，请手动复制提示词"))}>复制审阅提示词</button>
          <p>将 Agent 输出的 JSON 报告粘贴在此，核对完整内容后提交。确认表示同意导入，不代表代码或测试通过。</p>
          <textarea aria-label="Agent 审阅报告 JSON" value={reportText} maxLength={65536} onChange={event => setReportText(event.target.value)} style={{ width: "100%", height: 100 }} />
          <button type="button" disabled={status !== "running" || submitting || !reportText.trim()} onClick={() => {
            try {
              if (new TextEncoder().encode(reportText).length > 65536) throw new Error("报告不得超过 64 KiB")
              const report = JSON.parse(reportText)
              setSubmitting(true); setReportStatus("等待确认并保存…")
              submitRef.current?.(report)
            } catch (error) { setReportStatus((error as Error).message) }
          }}>确认内容并发送到 CMspark</button>
          <span role="status">{reportStatus}</span>
        </details>
      )}
      <div ref={hostRef} style={{ flex: 1, minHeight: 0, overflow: "hidden", padding: "4px 0 0 8px" }} />
    </div>
  )
}

```

FILE chrome-extension/scripts/test-workspace-ui.py
```tsx
"""Real App UI, synthetic transport. Run after nvm use22 with uv --with playwright.
No live Companion, external account, installed extension or native shell is used.
"""
import json
import subprocess
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

project = Path(__file__).resolve().parent.parent
shots = Path('/private/tmp/cmspark-469-shots')
shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
    subprocess.run(['node', 'scripts/render-workspace-fixture.cjs', directory], cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width':1440,'height':900})
        page.set_default_timeout(6000)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory)/'index.html').as_uri())
        composer = page.get_by_role('textbox', name='消息内容', exact=True)
        composer.wait_for()
        page.wait_for_function('window.dispatchUI && document.querySelector("textarea") && !document.querySelector("textarea").disabled')
        for width,height in [(1440,900),(800,700),(760,640),(759,640),(390,740),(320,480)]:
            page.set_viewport_size({'width':width,'height':height})
            page.wait_for_timeout(120)
            assert not page.evaluate('document.documentElement.scrollWidth > innerWidth'), (width,height,'horizontal overflow')
            box = composer.bounding_box()
            assert box and box['width'] >= min(220,width-60), (width,box)
            assert box['y'] >= 0 and box['y']+box['height'] <= height, (width,box)
            assert page.get_by_role('button',name='打开工作区导航',exact=True).is_visible() == (width<760)
            if width in (1440,390,320):page.screenshot(path=str(shots/f'empty-{width}.png'))
        # Narrow drawer: initial focus, keyboard close and focus return.
        toggle=page.get_by_role('button',name='打开工作区导航',exact=True)
        toggle.click()
        nav=page.get_by_role('dialog',name='工作区导航',exact=True)
        nav.wait_for()
        assert page.evaluate('document.querySelector("[aria-label=工作区导航]").contains(document.activeElement)')
        page.keyboard.press('Escape')
        assert not nav.is_visible()
        assert toggle.evaluate('(el)=>el===document.activeElement')
        # New task preserves existing action, never sends an Agent message.
        toggle.click()
        nav.get_by_role('button',name='新对话',exact=True).click()
        page.wait_for_function('window.sent.some(x=>x.type==="thread.create")')
        assert not page.evaluate('window.sent.some(x=>x.type==="chat.send" || x.type==="chat.create")')
        # Use original demo thread to keep subsequent fixtures explicitly scoped.
        page.evaluate("window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'demo-0'});window.dispatchUI({type:'SET_MESSAGES',messages:[]})")
        toggle.click()
        nav.get_by_role('button',name='设置',exact=True).click()
        settings=page.get_by_role('dialog',name='设置',exact=True)
        settings.wait_for()
        settings.get_by_role('navigation',name='设置分类').get_by_role('button',name='安全与信任',exact=True).click()
        page.wait_for_timeout(100)
        assert page.locator('[data-settings-section=安全与信任] > button').get_attribute('aria-expanded')=='true'
        page.screenshot(path=str(shots/'settings-320.png'))
        assert page.evaluate('document.querySelector("[aria-label=设置]").contains(document.activeElement)')
        settings.get_by_role('button',name='关闭设置',exact=True).click()
        # Existing history is named and keyboard operable; Escape returns focus.
        history=page.get_by_role('button',name='历史对话',exact=True)
        history.click()
        dialog=page.get_by_role('dialog',name='历史对话列表',exact=True)
        dialog.wait_for()
        row=dialog.get_by_role('button',name='打开 发布 v2.8',exact=False).first
        row.focus();page.keyboard.press('Enter')
        assert not dialog.is_visible()
        assert page.evaluate('window.sent.some(x=>x.type==="thread.select" && x.threadId==="demo-0")')
        history.click();dialog.wait_for();page.keyboard.press('Escape')
        assert not dialog.is_visible()
        assert history.evaluate('(el)=>el===document.activeElement')
        # Context panel fits the short viewport; closes without losing composer.
        toggle.click();nav.get_by_role('button',name='知识',exact=True).click()
        context=page.get_by_test_id('context-panel-host')
        context.wait_for()
        assert context.bounding_box()['height'] <= 480*.28+2
        assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
        page.get_by_role('button',name='收起面板',exact=True).click()
        # Long content + actual tool card disclosure are keyboard operable.
        messages=[{'id':'u1','thread_id':'demo-0','role':'user','content':'请核对支付服务 v2.8 的需求、代码与测试，整理变更材料。','created_at':'2026-09-07T10:00:00Z'},
          {'id':'a1','thread_id':'demo-0','role':'assistant','content':'已整理当前证据。\n\n### 需要补充的内容\n\n- 需求与开发任务已建立关联。\n- 测试对应提交仍待核对。\n\n'+'`https://devops.example.test/'+('long-path/'*25)+'`', 'created_at':'2026-09-07T10:01:00Z',
           'tool_calls':[{'id':'tc1','tool_name':'get_page_text','params':{},'status':'success','result':{'success':True,'data':{'content':'这是来自合成测试网页的实际展示文本。'*80}}}]}]
        page.evaluate('(messages)=>window.dispatchUI({type:"SET_MESSAGES",messages})',messages)
        page.set_viewport_size({'width':1440,'height':900})
        details=page.get_by_role('button',name='展开 get_page_text 详情',exact=True)
        details.focus();page.keyboard.press('Enter')
        assert page.get_by_role('button',name='收起 get_page_text 详情',exact=True).get_attribute('aria-expanded')=='true'
        page.screenshot(path=str(shots/'conversation-1440.png'))
        # Confirmation queue is still rendered by the unchanged production gate.
        confirmation={'confirmation_id':'fixture-confirm','tool_name':'shell_exec','dangerous_apis':['shell'], 'code_preview':'git diff base..head','risk_level':'high','requested_at':'2026-09-07T10:00:00Z','timeout_ms':45000}
        page.get_by_role('navigation',name='资源与能力').get_by_role('button',name='知识',exact=True).click()
        page.evaluate('(request)=>window.dispatchUI({type:"ADD_SECURITY_CONFIRMATION",request})',confirmation)
        page.set_viewport_size({'width':320,'height':480})
        page.wait_for_timeout(100)
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
        gate=page.get_by_role('alertdialog').first
        for name in ['允许','拒绝','停止']:
            button=gate.get_by_role('button',name=name,exact=True)
            box=button.bounding_box()
            assert box and 0 <= box['y'] and box['y']+box['height'] <= 480
            assert button.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
        page.screenshot(path=str(shots/'confirmation-320.png'))
        assert not page.evaluate('window.sent.some(x=>x.type==="security.confirmation.response")')
        page.evaluate("window.dispatchUI({type:'REMOVE_SECURITY_CONFIRMATION',confirmationId:'fixture-confirm'});window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:true})")
        stop=page.get_by_role('button',name='停止本轮',exact=True)
        stop.wait_for()
        assert stop.bounding_box()['y']+stop.bounding_box()['height'] <= 480
        assert page.get_by_role('button',name='纠偏当前这一轮',exact=True).is_visible()
        assert page.get_by_role('button',name='排队到本轮结束后',exact=True).is_visible()
        page.screenshot(path=str(shots/'running-320.png'))
        page.evaluate("window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:false});window.dispatchUI({type:'SET_CONNECTION',state:'disconnected'})")
        page.get_by_role('button',name='重新连接',exact=True).wait_for()
        assert composer.is_disabled()
        page.screenshot(path=str(shots/'offline-320.png'))
        # 200% equivalent CSS viewport reflow + reduced motion (actual media).
        page.emulate_media(reduced_motion='reduce')
        page.set_viewport_size({'width':720,'height':450})
        assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
        assert page.locator('.cm-workspace').evaluate('(el)=>getComputedStyle(el).scrollBehavior')=='auto'
        assert not errors, errors
        browser.close()
print('PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, reflow/reduced motion. Synthetic transport only.')

```

DIFF chrome-extension/src/sidepanel/components/ThreadList.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/components/ThreadList.tsx b/chrome-extension/src/sidepanel/components/ThreadList.tsx
index 263df286..03dd6424 100644
--- a/chrome-extension/src/sidepanel/components/ThreadList.tsx
+++ b/chrome-extension/src/sidepanel/components/ThreadList.tsx
@@ -1,26 +1,26 @@
 // Thread list — Timeline IA: today/yesterday + month→day, multi-select, tags view (P1).
 // Wave A: untagged batch extract, tldr row, portal menu, tag cloud fold, N/M progress.
 
 import { useCallback, useEffect, useMemo, useRef, useState } from "react"
 import { createPortal } from "react-dom"
 import { useAgentStore } from "../store/agentStore"
 import { tokens } from "../ui/tokens"
-import { IconChevronDown } from "../ui/icons"
+import { IconHistory } from "../ui/icons"
 import { popupMenuStyles } from "../ui/popupMenuStyles"
 import type { Thread } from "../types"
 import {
   batchNeedsForceExtract,
   buildTagIndex,
   collapseTagKeys,
   digestQuotaDayKey,
   acpOutcomeChip,
   countAliases,
   displayThreadEvidence,
   displayThreadTitle,
   EXTRACT_DIGEST_MAX,
   threadAccessibleName,
   filterThreadsByQuery,
   formatThreadIdBadge,
   formatThreadListTime,
   groupThreadsByCalendar,
   isMonthGroupOpen,
@@ -105,39 +105,42 @@ function saveExpandState(state: ThreadListExpandState) {
     localStorage.setItem(LS_THREAD_LIST_EXPAND, JSON.stringify(state))
   } catch {
     /* ignore quota */
   }
 }
 
 type ListView = "time" | "tags" | "topics"
 
 export function ThreadList() {
   const { state, dispatch } = useAgentStore()
   const [open, setOpen] = useState(false)
   const [query, setQuery] = useState("")
   const [view, setView] = useState<ListView>("time")
   const [selectMode, setSelectMode] = useState(false)
   const [selected, setSelected] = useState<Set<string>>(() => new Set())
   const [expandState, setExpandState] = useState<ThreadListExpandState>(loadExpandState)
   const [expandedDays, setExpandedDays] = useState<Set<string>>(() => new Set())
   const [menuOpen, setMenuOpen] = useState(false)
+  const menuOpenRef = useRef(menuOpen)
+  menuOpenRef.current = menuOpen
   const [menuPos, setMenuPos] = useState<{ top: number; right: number } | null>(null)
   const menuBtnRef = useRef<HTMLButtonElement | null>(null)
   const triggerRef = useRef<HTMLButtonElement | null>(null)
+  const historyRef = useRef<HTMLDivElement>(null)
   const [panelBox, setPanelBox] = useState<{ top: number; maxHeight: number } | null>(null)
   const [activeTag, setActiveTag] = useState<string | null>(null)
   const [extractingIds, setExtractingIds] = useState<Set<string>>(() => new Set())
   /** A-7 batch progress: done/total while untagged or multi extract runs. */
   const [extractProgress, setExtractProgress] = useState<{
     done: number
     total: number
   } | null>(null)
   /** Fingerprint/extracted_at snapshot at batch start — progress via UPSERT (S5). */
   const extractBatchRef = useRef<{
     /** Monotonic id so a late completed event cannot corrupt a newer batch. */
     batchId: number
     remaining: Set<string>
     total: number
     startMark: Map<string, string>
     /** Charge daily lazy quota only after successful ok[] (Wave B nit). */
     countTowardQuota: boolean
   } | null>(null)
@@ -839,36 +842,51 @@ export function ThreadList() {
   useEffect(() => {
     if (!open) {
       setPanelBox(null)
       return
     }
     const place = () => {
       const r = triggerRef.current?.getBoundingClientRect()
       const top = Math.round((r?.bottom ?? 48) + 6)
       setPanelBox({
         top,
         maxHeight: Math.max(180, window.innerHeight - top - 12),
       })
     }
     place()
     window.addEventListener("resize", place)
     return () => window.removeEventListener("resize", place)
   }, [open, selectMode, view])
 
+  // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
+  // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
+  useEffect(() => {
+    if (!open || !panelBox) return
+    historyRef.current?.querySelector<HTMLInputElement>('input[type="text"], input:not([type])')?.focus()
+    const key = (event: KeyboardEvent) => {
+      if (event.key !== "Escape") return
+      event.preventDefault()
+      if (menuOpenRef.current) { setMenuOpen(false); menuBtnRef.current?.focus(); return }
+      setOpen(false); triggerRef.current?.focus()
+    }
+    document.addEventListener("keydown", key)
+    return () => document.removeEventListener("keydown", key)
+  }, [open, !!panelBox])
+
   const renderThreadRow = (t: Thread) => {
     const busy = !!threadBusyById[t.id]
     const isActive = t.id === activeThreadId
     const badge = roleBadge(t.agent_role)
     const title = displayThreadTitle(t)
     const accessibleName = threadAccessibleName(t)
     const idBadge = formatThreadIdBadge(t.id)
     const rel = formatThreadListTime(t, now, aliasDupCount)
     const tags = t.digest?.tags || []
     const extracting = extractingIds.has(t.id)
     const evidence = displayThreadEvidence(t)
     const chip = acpOutcomeChip(t)
     const justCopied = copiedId === t.id
 
     return (
       <div
         key={t.id}
         style={{
@@ -882,37 +900,37 @@ export function ThreadList() {
           if (sel && sel.toString().length > 0) return
           handleSelect(t.id)
         }}
       >
         {selectMode && (
           <input
             type="checkbox"
             checked={selected.has(t.id)}
             disabled={busy}
             onChange={() => handleSelect(t.id)}
             onClick={(e) => e.stopPropagation()}
             title={busy ? "运行中，不可选" : undefined}
             style={styles.checkbox}
             aria-label={`选择 ${accessibleName}`}
           />
         )}
         <div style={{ flex: 1, minWidth: 0 }}>
           <div style={styles.threadAliasRow}>
-            <span style={styles.threadAlias}>{title}</span>
+            <button type="button" className="cm-thread-open" style={{ ...styles.threadAlias, border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "pointer", padding: "6px 0", minHeight: 32 }} aria-label={`打开 ${accessibleName}`} onClick={e => { e.stopPropagation(); handleSelect(t.id) }}>{title}</button>
             {chip ? <span style={styles.badge}>{chip}</span> : null}
             {idBadge ? (
               <button
                 type="button"
                 style={{
                   ...styles.threadIdBadge,
                   color: justCopied ? tokens.accentText : tokens.textMuted,
                 }}
                 title={`复制编号 ${idBadge}（可在搜索框粘贴定位）`}
                 aria-label={`复制会话编号 ${idBadge}`}
                 onClick={(e) => {
                   e.stopPropagation()
                   void copyThreadId(t.id)
                 }}
               >
                 {justCopied ? "已复制" : idBadge}
               </button>
             ) : null}
@@ -1058,104 +1076,99 @@ export function ThreadList() {
         onChange={() => {
           setSelected((prev) => toggleGroupSelection(ids, prev, selectableIds))
         }}
         onClick={(e) => e.stopPropagation()}
         aria-label={`选择 ${label}`}
         style={styles.checkbox}
       />
     )
   }
 
   const renderMonth = (month: MonthGroup) => {
     const openMonth = isMonthGroupOpen(month.monthKey, expandState, {
       searchActive,
       hasMatches: searchActive && month.count > 0,
     })
     const ids = threadIdsInMonth(month)
     return (
       <div key={month.monthKey}>
-        <div style={styles.groupHeader} onClick={() => toggleMonth(month.monthKey)}>
+        <div style={styles.groupHeader}>
           {renderGroupCheckbox(ids, month.label)}
           <span style={styles.groupChevron}>{openMonth ? "▼" : "▶"}</span>
-          <span style={styles.groupLabel}>
-            {month.label} · {month.count}
-          </span>
+          <button type="button" className="cm-history-group" aria-expanded={openMonth} onClick={() => toggleMonth(month.monthKey)}>{month.label} · {month.count}</button>
         </div>
         {openMonth && month.days.map((day) => renderDay(day))}
       </div>
     )
   }
 
   const renderDay = (day: DayGroup) => {
     // Search: force-open days that still have matches (parity with month groups).
     const openDay =
       expandedDays.has(day.dayKey) || (searchActive && day.threads.length > 0)
     const ids = threadIdsInDay(day)
     return (
       <div key={day.dayKey}>
         <div
           style={{ ...styles.groupHeader, paddingLeft: 20 }}
-          onClick={() => toggleDay(day.dayKey)}
         >
           {renderGroupCheckbox(ids, day.label)}
           <span style={styles.groupChevron}>{openDay ? "▼" : "▶"}</span>
-          <span style={styles.groupLabel}>
-            {day.label} · {day.threads.length}
-          </span>
+          <button type="button" className="cm-history-group" aria-expanded={openDay} onClick={() => toggleDay(day.dayKey)}>{day.label} · {day.threads.length}</button>
         </div>
         {openDay && day.threads.map((t) => renderThreadRow(t as Thread))}
       </div>
     )
   }
 
   const renderTimeline = () => {
     const todayOpen = isPinnedGroupOpen("today", expandState, {
       searchActive,
       hasMatches: searchActive && timeline.today.length > 0,
     })
     const yesterdayOpen = isPinnedGroupOpen("yesterday", expandState, {
       searchActive,
       hasMatches: searchActive && timeline.yesterday.length > 0,
     })
     return (
       <>
         {timeline.today.length > 0 && (
           <div>
-            <div style={styles.groupHeader} onClick={() => togglePinned("today")}>
+            <div style={styles.groupHeader}>
               {renderGroupCheckbox(
                 timeline.today.map((t) => t.id),
                 "今天",
               )}
               <span style={styles.groupChevron}>{todayOpen ? "▼" : "▶"}</span>
-              <span style={styles.groupLabel}>今天 · {timeline.today.length}</span>
+              <button type="button" className="cm-history-group" aria-expanded={todayOpen} onClick={() => togglePinned("today")}>今天 · {timeline.today.length}</button>
             </div>
             {todayOpen && timeline.today.map((t) => renderThreadRow(t as Thread))}
           </div>
         )}
 
         {timeline.yesterday.length > 0 && (
           <div>
-            <div style={styles.groupHeader} onClick={() => togglePinned("yesterday")}>
+            <div style={styles.groupHeader}>
               {renderGroupCheckbox(
                 timeline.yesterday.map((t) => t.id),
                 "昨天",
               )}
               <span style={styles.groupChevron}>{yesterdayOpen ? "▼" : "▶"}</span>
-              <span style={styles.groupLabel}>昨天 · {timeline.yesterday.length}</span>
+              <button type="button" className="cm-history-group" aria-expanded={yesterdayOpen} onClick={() => togglePinned("yesterday")}>昨天 · {timeline.yesterday.length}</button>
             </div>
             {yesterdayOpen && timeline.yesterday.map((t) => renderThreadRow(t as Thread))}
           </div>
         )}
 
         {timeline.months.map(renderMonth)}
 
         {filtered.length === 0 && (
           <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
             {threads.length === 0 ? "暂无线程，点击「+ 新建」" : "无匹配线程"}
           </div>
         )}
       </>
     )
   }
 
   const renderTagsView = () => {
     const untagged = tagIndex.get("__untagged__") || []
@@ -1321,64 +1334,66 @@ export function ThreadList() {
       </>
     )
   }
 
   return (
     <div style={{ position: "relative" }}>
       <button
         ref={triggerRef}
         type="button"
         style={{
           ...styles.hamburger,
           ...(open ? { color: tokens.text } : null),
         }}
         onClick={() => setOpen(!open)}
         title="历史对话"
         aria-label="历史对话"
         aria-expanded={open}
       >
-        <IconChevronDown size={18} />
+        <IconHistory size={17} />
       </button>
 
       {open &&
         panelBox &&
         typeof document !== "undefined" &&
         createPortal(
         <>
           <div
             style={styles.backdrop}
             onClick={() => {
               setOpen(false)
               setMenuOpen(false)
               if (selectMode) exitSelectMode()
             }}
           />
           <div
+            ref={historyRef} className="cm-history-panel" role="dialog" aria-label="历史对话列表" aria-modal="false"
             style={{
               ...styles.panel,
               position: "fixed",
               top: panelBox.top,
               left: 8,
               right: 8,
               width: "auto",
               maxHeight: Math.min(panelMaxHeight, panelBox.maxHeight),
               zIndex: 10050,
             }}
           >
+            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>历史对话</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
             <div style={styles.panelHeader}>
               <div style={styles.viewToggle}>
                 <button
                   type="button"
                   style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
                   onClick={() => setView("time")}
                 >
                   时间
                 </button>
                 <button
                   type="button"
                   style={view === "tags" ? styles.viewBtnActive : styles.viewBtn}
                   onClick={() => setView("tags")}
                 >
                   标签
                 </button>
                 <button
                   type="button"

```

DIFF chrome-extension/src/sidepanel/components/ChatView.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/components/ChatView.tsx b/chrome-extension/src/sidepanel/components/ChatView.tsx
index f88b7375..7b5b18bf 100644
--- a/chrome-extension/src/sidepanel/components/ChatView.tsx
+++ b/chrome-extension/src/sidepanel/components/ChatView.tsx
@@ -328,38 +328,38 @@ export function ChatView() {
   // Export the Q&A pair containing this message as Markdown (UI-side download).
   const handleExport = useCallback((messageId: string) => {
     if (!activeThreadId) return
     chrome.runtime.sendMessage({
       type: "thread.export_obsidian",
       thread_id: activeThreadId,
       // "single" = export just the clicked message (e.g. one response), not the whole
       // Q&A turn. (qa_pair would include the preceding question too.)
       scope: "single",
       anchor_message_id: messageId,
       include_reasoning: exportIncludeReasoning === true,
     })
   }, [activeThreadId, exportIncludeReasoning])
 
   return (
     <div style={styles.shell}>
       <style>{quietActionsCSS}</style>
       {/* #321 PR-2: popout bar removed — the 弹出对话框 affordance lives on StatusRail now. */}
-      <div style={styles.container} ref={containerRef} onScroll={handleScroll}>
-      <div ref={contentRef} style={styles.contentInner}>
+      <div className="cm-chat-scroll" style={styles.container} ref={containerRef} onScroll={handleScroll}>
+      <div className="cm-chat-content" ref={contentRef} style={styles.contentInner}>
         {showCompactBanner && (
           <NoticeCard tone="warning" role="status" testId="context-notice-card">
             {compactBanner === "shrink" ? (
               <>
                 <strong>工具结果已截断</strong>
                 （自动压缩未丢掉更早轮次，但最长工具正文改成了占位，避免半截 JSON）。
                 下方消息列表仍为完整原文。
               </>
             ) : compactBanner === "unknown" ? (
               <>
                 <strong>上下文可能已被压缩</strong>
                 （当前 companion 版本未报告压缩细节）。
                 下方消息列表仍为完整原文；升级 companion 到 0.5.8+ 可查看准确信息。
               </>
             ) : compactBanner === "prompt" ? (
               <>
                 <strong>上下文可能超预算</strong>
                 （当前为「仅提示」模式，未压缩）。
@@ -1134,37 +1134,37 @@ function ToolCallCard({ tc }: { tc: any }) {
         <span style={styles.toolName}>
           {isShellExec ? "shell_exec · 本机命令" : tc.tool_name}
         </span>
         {isVisionTool && tc.vision_status === "analyzing" && (
           <span style={styles.toolMeta}>Analyzing…</span>
         )}
         {isVisionTool && tc.vision_status === "done" && (
           <span style={styles.toolMeta}>
             Vision {tc.vision_latency_ms ? `${(tc.vision_latency_ms / 1000).toFixed(1)}s` : ""}
           </span>
         )}
         {isVisionTool && tc.vision_status === "cached" && (
           <span style={{ ...styles.toolMeta, color: tokens.textMuted }}>Vision cached</span>
         )}
         {isVisionTool && tc.vision_status === "error" && (
           <span style={{ ...styles.toolMeta, color: tokens.warning }}>Vision failed</span>
         )}
         {canExpandGeneric && (
-          <span style={styles.toolExpandHint}>{expanded ? "收起" : "展开"}</span>
+          <button type="button" aria-label={`${expanded ? "收起" : "展开"} ${tc.tool_name} 详情`} aria-expanded={expanded} style={{ ...styles.toolExpandHint, border: "none", background: "transparent", cursor: "pointer", minHeight: 32 }} onClick={e => { e.stopPropagation(); setExpanded(!expanded) }}>{expanded ? "收起" : "详情"}</button>
         )}
         {showLiveProgress && progressElapsed != null && (
           <span style={styles.toolMeta} data-testid="tool-progress-elapsed">
             {Math.floor(progressElapsed / 1000)}s
           </span>
         )}
         {isShellExec && derivedStatus === "running" && typeof tc.id === "string" && tc.id && (
           <button
             type="button"
             data-testid="shell-stop-btn"
             title="停止此 shell 命令（不中断整轮对话）"
             onClick={(e) => {
               e.stopPropagation()
               chrome.runtime.sendMessage({
                 type: "shell.exec.abort",
                 tool_call_id: tc.id,
                 thread_id: agentState.activeThreadId || undefined,
               })
@@ -1765,37 +1765,37 @@ export function EmptyState({ level }: { level: "chat" | "browser" | "computer" }
     chrome.tabs.onUpdated.addListener(onUpdated)
     return () => {
       chrome.tabs.onActivated.removeListener(onActivated)
       chrome.tabs.onUpdated.removeListener(onUpdated)
     }
   }, [])
 
   const { title, hint, items, pageChip } = emptyStateCopy(level, omitPage ? null : pageTitle)
   const rows: SuggestItem[] = items.map((it) =>
     it.kind === "fill"
       ? { label: it.label, fill: it.fill, Icon: inviteIcon(it) }
       : { label: it.label, action: it.action, Icon: inviteIcon(it) },
   )
   const testId =
     level === "browser" ? "empty-state-browser" : level === "computer" ? "empty-state-computer" : "empty-state-chat"
 
   return (
     <div style={styles.empty} data-testid={testId}>
-      <CompanionMark size={48} />
+      <CompanionMark size={36} />
       <div style={styles.emptyTitle}>{title}</div>
       {hint ? <div style={styles.emptyHint}>{hint}</div> : null}
       {rows.length > 0 ? <InvitationRows items={rows} /> : null}
       {pageChip ? (
         <div style={styles.pageChip} data-testid="empty-page-chip">
           <span style={styles.pageChipText}>{pageChip}</span>
           <button
             type="button"
             style={styles.pageChipHide}
             aria-label="隐藏当前页"
             onClick={() => setOmitPage(true)}
           >
             ×
           </button>
         </div>
       ) : null}
     </div>
   )
@@ -1900,37 +1900,37 @@ const styles: Record<string, React.CSSProperties> = {
     // Disable scroll-anchoring so late inserts (tools/markdown) cannot yank
     // long threads toward the top; stick-to-bottom is handled in JS.
     overflowAnchor: "none" as any,
   },
   contentInner: {
     minHeight: "100%",
     flex: 1,
     display: "flex",
     flexDirection: "column",
   },
   empty: {
     flex: 1,
     display: "flex",
     flexDirection: "column",
     alignItems: "center",
     justifyContent: "flex-start",
     color: tokens.text,
     textAlign: "center",
-    padding: "16px 8px 8px",
+    padding: "clamp(16px, 6vh, 56px) 8px 16px",
     fontFamily: tokens.font,
   },
   emptyTitle: {
     fontSize: tokens.emptyTitle,
     fontWeight: 600,
     color: tokens.text,
     margin: "12px 0 10px",
     letterSpacing: "-0.035em",
     lineHeight: 1.25,
   },
   emptyHint: {
     fontSize: 13,
     color: tokens.textSecondary,
     lineHeight: 1.5,
     maxWidth: 260,
     margin: "0 0 28px",
   },
   pageChip: {
@@ -1955,65 +1955,66 @@ const styles: Record<string, React.CSSProperties> = {
     whiteSpace: "nowrap" as const,
     flex: 1,
     textAlign: "left" as const,
   },
   pageChipHide: {
     flexShrink: 0,
     border: "none",
     background: "transparent",
     cursor: "pointer",
     color: tokens.textMuted,
     fontSize: 14,
     lineHeight: 1,
     padding: "0 4px",
     fontFamily: tokens.font,
   },
   inviteCol: {
     display: "flex",
     flexDirection: "column",
-    gap: 8,
+    gap: 4,
     width: "100%",
-    maxWidth: 260,
+    maxWidth: 340,
     alignItems: "flex-start",
   },
   inviteRow: {
     display: "flex",
     alignItems: "center",
     gap: 10,
     width: "100%",
-    padding: 0,
-    border: "none",
+    padding: "10px 12px",
+    border: `1px solid ${tokens.border}`,
     background: "transparent",
     fontSize: 14,
     fontWeight: 400,
+    borderRadius: tokens.radiusLg,
     lineHeight: 1.4,
     cursor: "pointer",
     fontFamily: tokens.font,
     textAlign: "left" as const,
   },
   userMsg: {
     display: "flex",
     justifyContent: "flex-end",
-    marginBottom: 10,
+    marginBottom: 24,
   },
   agentMsg: {
     display: "flex",
     justifyContent: "flex-start",
-    marginBottom: 10,
+    marginBottom: 24,
   },
   messageCol: {
     display: "flex",
     flexDirection: "column",
     maxWidth: "90%",
     width: "fit-content" as const,
   },
   thumbRow: {
     display: "flex",
     flexWrap: "wrap" as const,
     gap: 6,
     marginTop: 6,
     alignSelf: "flex-end" as const,
     maxWidth: "100%",
   },
   thumbImg: {
     width: 48,
     height: 48,
@@ -2041,53 +2042,53 @@ const styles: Record<string, React.CSSProperties> = {
     overflow: "hidden",
     wordBreak: "break-all" as const,
   },
   attachMeta: {
     alignSelf: "flex-end" as const,
     marginTop: 4,
     fontSize: 11,
     color: tokens.textSecondary,
     maxWidth: "100%",
     overflow: "hidden",
     textOverflow: "ellipsis",
     whiteSpace: "nowrap" as const,
   },
   userBubble: {
     background: tokens.userBubbleBg,
     color: tokens.userBubbleInk,
     border: `1px solid ${tokens.userBubbleBorder}`,
     borderRadius: `${tokens.radiusBubble}px ${tokens.radiusBubble}px 4px ${tokens.radiusBubble}px`,
-    padding: "9px 13px",
-    fontSize: 13,
+    padding: "12px 16px",
+    fontSize: 14,
     lineHeight: 1.5,
     wordBreak: "break-word" as const,
     whiteSpace: "pre-wrap",
-    boxShadow: tokens.shadowSm,
+    boxShadow: "none",
   },
   agentBubble: {
     background: tokens.assistantBubbleBg,
     color: tokens.assistantBubbleText,
     borderRadius: `${tokens.radiusBubble}px ${tokens.radiusBubble}px ${tokens.radiusBubble}px 4px`,
-    padding: "9px 13px",
-    fontSize: 13,
-    lineHeight: 1.5,
+    padding: "8px 2px",
+    fontSize: 14,
+    lineHeight: 1.75,
     wordBreak: "break-word" as const,
-    border: `1px solid ${tokens.border}`,
-    boxShadow: tokens.shadowSm,
+    border: "none",
+    boxShadow: "none",
   },
   truncChip: {
     marginTop: 6,
     alignSelf: "flex-start" as const,
     fontSize: 11,
     lineHeight: 1.4,
     color: tokens.warning,
     background: tokens.warningSoft,
     border: `1px solid ${tokens.border}`,
     borderRadius: 10,
     padding: "2px 8px",
   },
   statusBubble: {
     background: tokens.accentSoft,
     borderRadius: `${tokens.radiusBubble}px ${tokens.radiusBubble}px ${tokens.radiusBubble}px 4px`,
     padding: "8px 12px",
     maxWidth: "88%",
     fontSize: 12,
@@ -2221,45 +2222,45 @@ const styles: Record<string, React.CSSProperties> = {
   expandBtn: {
     background: "none",
     border: "none",
     color: tokens.accent,
     cursor: "pointer",
     fontSize: 12,
     padding: "4px 0",
     marginTop: 4,
     fontWeight: 500,
   },
   // G3: elevated card + 2px left accent hairline (status overrides color)
   toolCard: {
     marginTop: 8,
     border: `1px solid ${tokens.border}`,
     borderLeft: `2px solid ${tokens.accent}`,
     borderRadius: tokens.radiusMd,
     padding: "8px 10px",
     background: tokens.bgElevated,
-    fontSize: 11,
-    boxShadow: tokens.shadowSm,
+    fontSize: 12,
+    boxShadow: "none",
   },
   toolHeader: {
     display: "flex",
     alignItems: "center",
     gap: 5,
     marginBottom: 0,
-    minHeight: 18,
+    minHeight: 28,
   },
   toolStatusGlyph: {
     fontSize: 10,
     fontWeight: 700,
     width: 12,
     textAlign: "center" as const,
     flexShrink: 0,
   },
   toolName: {
     fontWeight: 600,
     fontFamily: tokens.fontMono,
     fontSize: 11,
     color: tokens.text,
   },
   toolMeta: {
     fontSize: 10,
     color: tokens.accent,
     marginLeft: 4,

```

DIFF chrome-extension/src/sidepanel/App.tsx
```diff
diff --git a/chrome-extension/src/sidepanel/App.tsx b/chrome-extension/src/sidepanel/App.tsx
index 6f7f2039..34bc56b9 100644
--- a/chrome-extension/src/sidepanel/App.tsx
+++ b/chrome-extension/src/sidepanel/App.tsx
@@ -1,47 +1,44 @@
-/* THESIS: Side Panel is a consumer assistant empty, not an instrument desk — first viewport is a person who greets you.
-   OWN-WORLD: White surface, ink type, 22px greeting, sentence rows, circular send, indigo spark only on the companion mark.
-   STORY: Open → meet someone → type or tap a sentence → work still fits 320px.
-   FIRST VIEWPORT: Centered CompanionMark, 要我帮你做什么？, sentence invitations, quiet composer, 新对话.
-   FORM: Canon (知乎看山 quality bar) · seed e96a500f · Comp A approved.
-   FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, and DESIGN.md */
+// #469: responsive conversation workspace; root DESIGN.md.
 // CMspark Browser Agent — Root App Component
 
 import { Component, useState, useRef, useCallback, useEffect } from "react"
 import { useWebSocket } from "./hooks/useWebSocket"
 import { useCapabilityMode } from "./hooks/useCapabilityMode"
 import { ToastHost, useToastQueue } from "./components/ToastHost"
 import { ChatView } from "./components/ChatView"
 import {
   ContextPanelHost,
   ContextPanelHostProvider,
   useContextPanelHost,
 } from "./components/ContextPanelHost"
 import { FocusBand } from "./components/FocusBand"
 import { CodingAgentPanel } from "./components/CodingAgentPanel"
 import { SettingsSlideout } from "./components/SettingsSlideout"
 import { McpServerForm } from "./components/McpServerForm"
 import { SlashCommandPopover } from "./components/SlashCommandPopover"
 import { AtThreadPopover } from "./components/AtThreadPopover"
 import { SkillCraftPanel } from "./components/SkillCraftPanel"
 import { NotebooklmImporterPanel } from "./components/NotebooklmImporterPanel"
 import { StatusRail } from "./components/StatusRail"
 import { ComposerChips } from "./components/ComposerChips"
 import { ComposerCruisePicker } from "./components/ComposerCruisePicker"
+import { WorkspaceFrame } from "./components/WorkspaceFrame"
+import { workspaceCSS } from "./ui/workspace-styles"
 import { ComposerDock } from "./components/ComposerDock"
 import { ComposeDrawer } from "./components/ComposeDrawer"
 import { ThreadRefChips } from "./components/ThreadRefChips"
 import { UploadChips } from "./components/UploadChips"
 import { VoiceBanner } from "./components/VoiceBanner"
 import { AgentStoreProvider, useAgentStore } from "./store/agentStore"
 import type { CapabilityLevel, FileAttachment } from "./types"
 import {
   composerPlaceholder,
   type ComposerChipAction,
 } from "./composer/meta-slash"
 import { tokens } from "./ui/tokens"
 import { PanelBanner, panelBannerBtnStyles } from "./ui/PanelBanner"
 import {
   IconSend,
   IconStop,
   IconAttach,
   IconAlert,
@@ -196,58 +193,60 @@ function AppContent() {
       showToast(detail)
     }
     window.addEventListener("cmspark:toast", onToast as EventListener)
     return () => window.removeEventListener("cmspark:toast", onToast as EventListener)
   }, [showToast])
   const { level, badgeLabel } = useCapabilityMode(onEscalate)
   const isComputer = level === "computer"
 
   // P1: auto-open Cockpit when entering L2 (openOrFocus is idempotent)
   useEffect(() => {
     if (!isComputer) return
     chrome.runtime.sendMessage({ type: "cockpit.open" }, () => {
       void chrome.runtime.lastError
     })
   }, [isComputer])
 
   return (
     <ContextPanelHostProvider capabilityLevel={level}>
+    <WorkspaceFrame>
     <div style={styles.container}>
-      <style>{globalCSS}</style>
+      <style>{globalCSS + workspaceCSS}</style>
       <StatusRail
         connectionState={connectionState}
         capabilityLevel={level}
         badgeLabel={badgeLabel}
         onCraft={() => setCraftOpen(true)}
         onToggleLogs={() => setShowLogs(!showLogs)}
         onOpenNotebooklmImporter={() => setNbImporterOpen(true)}
         onToast={showToast}
         onPopout={handlePopout}
         canPopout={!!appState.activeThreadId}
       />
-      {/* #321 PR-3: toast host lives in a zero-height slot right under the rail —
-          its top is DOM-anchored to the rail, so no `top:52` rail-height magic. */}
-      <div style={{ position: "relative", height: 0, flexShrink: 0 }}>
-        <ToastHost toasts={toasts} onClose={closeToast} />
-      </div>
       {/* UIUX v2 §4.3 FocusBand: Confirm > L2 Safety+急停 > Fleet > L1 Context; ≤80px.
           #321 PR-2「一条 Now」: SceneStatusBar / RunBusyChip / WorkerScopeBar merged
           into FocusBand slots — no fourth band above the conversation. */}
       <FocusBand capabilityLevel={level} />
+      {/* #321 PR-3: toast host lives in a zero-height slot after the priority FocusBand —
+          its top is DOM-anchored below confirmation, so no `top:52` height magic. */}
+      <div style={{ position: "relative", height: 0, flexShrink: 0 }}>
+        <ToastHost toasts={toasts} onClose={closeToast} />
+      </div>
+
       <ChatView />
       <FleetWorkerListPortal />
       {/* R3: ComputerTaskBar removed — step timeline only in Cockpit dual-track */}
       {/* #321 PR-1: legacy BottomBar strip deleted (was permanently gated off). Host is SoT. */}
       <ContextPanelHost />
       <InputArea capabilityLevel={level} />
       {showLogs && <LogBar onClose={() => setShowLogs(false)} />}
       <SettingsSlideout />
       {/* Full-height 编程接力 壳 — replaces old task-package-only modal as primary UX */}
       <CodingAgentPanel
         open={codingPanelOpen}
         onClose={() => setCodingPanelOpen(false)}
         workspaceRoot={
           (
             appState.threads.find((t) => t.id === appState.activeThreadId) as
               | { workspace_root?: string | null }
               | undefined
           )?.workspace_root ?? null
@@ -280,36 +279,37 @@ function AppContent() {
               showToast("无法联系扩展后台，请刷新 Side Panel 后重试", "error")
               return
             }
             chrome.runtime.sendMessage({ type: "getStatus" }, (response) => {
               if (chrome.runtime.lastError) {
                 showToast("正在尝试重新连接…", "warning")
                 return
               }
               if (response?.connectionState === "connected") {
                 showToast("已连接 Companion", "info")
                 return
               }
               showToast("正在尝试重新连接…若 Companion 已启动将自动恢复", "warning")
             })
           })
         }}
       />
     </div>
+    </WorkspaceFrame>
     </ContextPanelHostProvider>
   )
 }
 
 
 function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityLevel }) {
   const { state, dispatch } = useAgentStore()
   const { openPanelForce, closePanel, activePanel } = useContextPanelHost()
   const [text, setText] = useState("")
 
   useEffect(() => {
     const restore = state.composerRestore
     if (!restore?.text) return
     setText((prev) => nextComposerText(prev, restore.text))
     dispatch({ type: "CLEAR_COMPOSER_RESTORE" })
   }, [state.composerRestore?.token])
   const [composeOpen, setComposeOpen] = useState(false)
   const textareaRef = useRef<HTMLTextAreaElement>(null)
@@ -811,37 +811,37 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
 
   const handleStop = () => {
     // SoT §6.4: abort recognition first, then chat.abort
     voice.abortForChatStop()
     chrome.runtime.sendMessage({
       type: "chat.abort",
       threadId: state.activeThreadId,
     })
     dispatch({ type: "SET_STREAMING", content: "" })
     dispatch({ type: "SET_STREAMING_REASONING", content: "" })
     dispatch({ type: "SET_PROCESSING_STATUS", status: null })
     dispatch({ type: "SET_PROCESSING", isProcessing: false })
   }
 
   gestureSendRef.current = (files) => handleSend(files)
 
   return (
     <div
-      style={{ borderTop: `1px solid ${tokens.border}`, flexShrink: 0, position: "relative" as const, background: tokens.bg }}
+      style={{ flexShrink: 0, position: "relative" as const, background: tokens.bg }}
       onPaste={handleComposerPaste}
       onDragEnter={handleComposerDragEnter}
       onDragOver={handleComposerDragOver}
       onDragLeave={handleComposerDragLeave}
       onDrop={handleComposerDrop}
     >
       <input
         ref={fileInputRef}
         type="file"
         hidden
         multiple
         accept={IMAGE_ACCEPT}
         onChange={handleFileSelect}
       />
       <UploadChips
         fileError={fileError}
         onDismissError={() => setFileError("")}
         destAck={destAck}
@@ -861,77 +861,81 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
         onDismiss={() => setAtVisible(false)}
       />
       <VoiceStatusCapsule
         view={capsuleView({
           phase: voice.phase,
           engine: sttEngine === "local" ? "local" : "browser",
           locked: pttLocked,
           level: voiceLevel,
         })}
         level={voiceLevel}
         extraHint={voiceCapsuleHint}
         badge={postprocessedBadge ? POSTPROCESS_BADGE_LABEL : null}
       />
       {/* PR4: ComposerDock chips + capsule; 装配 lives on the chip, not in the field */}
       <ComposerDock
         chips={<ComposerChips capabilityLevel={capabilityLevel} onAction={handleChipAction} />}
       >
         <div
+          className="cm-composer-capsule"
           style={{
             ...styles.composerCapsule,
             opacity: needsThread || needsConnection ? 0.85 : 1,
             background: needsThread || needsConnection ? tokens.bgMuted : tokens.bgElevated,
             borderColor: dragOver ? tokens.accent : tokens.borderStrong,
             boxShadow: dragOver ? `0 0 0 1px ${tokens.accent}` : tokens.shadowSm,
           }}
         >
-          {/* Attach stays visible in the empty composer — first-run affordance. */}
-          {!showStop && !(voice.listening && showVoiceMic) && (
-            <button
-              type="button"
-              style={styles.attachBtn}
-              onClick={() => fileInputRef.current?.click()}
-              // l2_task: ingest is blocked for an active computer task — don't
-              // present a clickable affordance whose selection is silently dropped.
-              disabled={needsThread || needsConnection || threadBusy || composerMode === "l2_task" || !!overlayStandby}
-              title="添加文件或图片"
-              aria-label="添加文件或图片"
-            >
-              <IconAttach size={16} />
-            </button>
-          )}
           <textarea
+            aria-label="消息内容"
             ref={textareaRef}
             style={styles.textarea}
             placeholder={getPlaceholder()}
             rows={1}
             value={voice.liveOverlay !== null ? voice.liveOverlay : text}
             // Disable whenever live overlay owns the value (listening + processing gaps).
             // Otherwise keystrokes are invisible and next final flush overwrites them.
             disabled={
               needsThread ||
               needsConnection ||
               voice.liveOverlay !== null ||
               !!overlayStandby
             }
             onChange={handleChange}
             onKeyDown={handleKeyDown}
             onPaste={handleComposerPaste}
           />
+          <div className="cm-composer-actions">
+          {/* Attach stays visible in the empty composer — first-run affordance. */}
+          {!showStop && !(voice.listening && showVoiceMic) && (
+            <button
+              type="button"
+              style={styles.attachBtn}
+              onClick={() => fileInputRef.current?.click()}
+              // l2_task: ingest is blocked for an active computer task — don't
+              // present a clickable affordance whose selection is silently dropped.
+              disabled={needsThread || needsConnection || threadBusy || composerMode === "l2_task" || !!overlayStandby}
+              title="添加文件或图片"
+              aria-label="添加文件或图片"
+            >
+              <IconAttach size={16} />
+            </button>
+          )}
+          <span style={{ flex: 1 }} />
           {showVoiceMic && (
             <VoiceMicButton
               listening={voice.listening && !voice.processing}
               processing={voice.processing}
               disabled={voiceMicDisabled && !voice.listening}
               title={voiceMicTitle}
               timerLabel={voiceMicTimerLabel}
               liveStatus={voiceMicLiveStatus}
               onClick={() => voice.toggle()}
             />
           )}
           {showStop && threadBusy && !taskActive && (
             <button
               type="button"
               style={styles.sendBtn}
               onClick={() => handleSend()}
               disabled={!canSend}
               title="纠偏当前这一轮"
@@ -956,60 +960,61 @@ function InputArea({ capabilityLevel = "chat" }: { capabilityLevel?: CapabilityL
               type="button"
               style={styles.stopBtn}
               onClick={handleStop}
               title={
                 voice.listening
                   ? "停止听写并停止本轮"
                   : isWorker
                     ? "停止该子任务（本轮）"
                     : "停止本轮"
               }
             >
               <IconStop size={14} />
             </button>
           ) : (
             <button
               type="button"
               style={{
                 ...styles.sendBtn,
-                background: canSend ? tokens.accent : tokens.sendDisabledBg,
+                background: canSend ? tokens.actionPrimary : tokens.sendDisabledBg,
                 color: canSend ? tokens.userBubbleText : tokens.textMuted,
                 cursor: canSend ? "pointer" : "not-allowed",
               }}
               onClick={() => handleSend()}
               disabled={!canSend}
               title={
                 overlayStandby
                   ? overlayStandby.label
                   : needsThread
                     ? "请先创建线程"
                     : needsConnection
                       ? "Companion 未连接"
                       : taskActive
                         ? "任务进行中，请在确认台发送"
                         : threadBusy
                           ? "本对话处理中"
                           : "发送"
               }
             >
               <IconSend size={15} />
             </button>
           )}
 
+          </div>
         </div>
         <VoiceBanner
           banner={voice.banner}
           engineSwitchNote={engineSwitchNote}
           rawSnapshot={voice.rawSnapshot}
           refining={voice.refining}
           voiceBannerCta={voiceBannerCta}
           onRestoreRaw={() => voice.restoreRaw()}
           onSwitchBrowser={handleSwitchBrowserEngine}
           onOpenSettings={handleOpenVoiceSettings}
           onDismiss={() => {
             voice.dismissBanner()
             setEngineSwitchNote(null)
           }}
         />
         <VoicePrivacySheet
           open={voicePrivacyOpen}
           kind={voicePrivacyKind}
@@ -1168,51 +1173,53 @@ const globalCSS = `
   button:active:not(:disabled) {
     transform: scale(0.98);
   }
   @media (prefers-reduced-motion: reduce) {
     *, *::before, *::after {
       animation-duration: 0.01ms !important;
       animation-iteration-count: 1 !important;
       transition-duration: 0.01ms !important;
     }
     button:active:not(:disabled) { transform: none; }
   }
 `
 
 const styles: Record<string, React.CSSProperties> = {
   // Precision Instrument Desk — solid canvas, flat composer (Phase 1)
   container: {
     display: "flex",
     flexDirection: "column",
-    height: "100vh",
+    height: "100%",
+    minHeight: 0,
     fontFamily: tokens.font,
     fontSize: 13,
     color: tokens.text,
     background: tokens.bg,
     WebkitFontSmoothing: "antialiased",
     position: "relative" as const,
   },
   composerCapsule: {
     display: "flex",
-    alignItems: "flex-end",
+    flexDirection: "column",
+    alignItems: "stretch",
     gap: 8,
     border: `1px solid ${tokens.border}`,
     borderRadius: tokens.radiusComposer,
-    padding: "6px 10px 6px 12px",
+    padding: "10px 12px 10px 14px",
     background: tokens.bgElevated,
     minHeight: 52,
     transition: `border-color ${tokens.transitionFast} ease, box-shadow ${tokens.transitionFast} ease`,
   },
   textarea: {
     flex: 1,
     // Replaced element: without minWidth 0 the cols=20 min-content overflows
     // the 4-element capsule row (attach/textarea/mic/send) in narrow panels.
     minWidth: 0,
     border: "none",
     borderRadius: tokens.radiusMd,
     padding: "4px 0",
     fontSize: 14,
     fontFamily: "inherit",
     resize: "none" as const,
     outline: "none",
     minHeight: 32,
     maxHeight: 120,

```

Existing context owner
export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const closePanel = useCallback(() => {
    setActivePanel(null)
  }, [])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activeThreadId, dispatch],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      if (activePanel === id) {
        setActivePanel(null)
        return
      }
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activePanel, activeThreadId, dispatch],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      setActivePanel(null)
    }
  }, [activePanel, allowedIds, overflowIds])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      setActivePanel(raw)
      loadPanelData(raw, activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [activeThreadId, dispatch])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      setActivePanel(null)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel }),
    [activePanel, openPanel, openPanelForce, closePanel],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel } = useContextPanelHost()
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        <button
          type="button"
          style={styles.panelCloseBtn}
          title="收起面板 (Esc)"
          aria-label="收起面板"
          onClick={closePanel}
        >
          收起
        </button>
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}


Existing thread select behavior
  const handleSelect = (threadId: string) => {
    if (selectMode) {
      if (threadBusyById[threadId]) return
      setSelected((prev) => {
        const next = new Set(prev)
        if (next.has(threadId)) next.delete(threadId)
        else next.add(threadId)
        return next
      })
      return
    }
    // Dual-review residual: do not activate soft-deleted threads into main chat
    if (trashView) return
    const thr = threads.find((t) => t.id === threadId)
    if (thr?.trashed_at) return
    dispatch({ type: "SET_ACTIVE_THREAD", threadId })
    chrome.runtime.sendMessage({ type: "thread.select", threadId })
    setOpen(false)
  }


Existing settings section deep link
  // F-UX7 deep-link: open target accordion section once settings opens.
  useEffect(() => {
    if (!state.settingsOpen || !state.settingsFocusSection) return
    const id = state.settingsFocusSection as SettingsSectionId
    if (!(SETTINGS_SECTION_IDS as readonly string[]).includes(id)) {
      dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
      return
    }
    setUserOpenSections((prev) => {
      if (prev.has(id)) return prev
      const next = new Set(prev)
      next.add(id)
      try {
        localStorage.setItem(LS_SETTINGS_EXPAND, serializeSettingsExpand(next))
      } catch {
        /* ignore */
      }
      return next
    })
    dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
  }, [state.settingsOpen, state.settingsFocusSection, dispatch])


Existing recent title resolver
// Thread History IA — calendar grouping + filter helpers (pure).
// Spec: docs/superpowers/specs/2026-08-06-thread-history-ia-product-design.md

export type AcpListMeta = {
  outcome?: "ok" | "partial" | "fail" | "cancelled"
  agent_id?: string
  goal_preview?: string
}

export type TimelineThread = {
  id: string
  alias?: string
  created_at?: string
  updated_at?: string
  /** Last persisted transcript row. Human-facing recency; never `updated_at`. */
  last_message_at?: string | null
  /** First user message preview (optional, from companion list enrichment). */
  first_user_preview?: string | null
  agent_role?: "normal" | "orchestrator" | "worker" | string
  message_count?: number
  user_message_count?: number
  /** First-party ACP list meta from companion — never parsed from handback body. */
  acp_list?: AcpListMeta | null
  digest?: {
    tldr?: string
    tags?: string[]
    bullets?: string[]
    extracted_at?: string
    content_fingerprint?: string
    stale?: boolean
  } | null
}

export type DayGroup = {
  /** Local calendar day key YYYY-MM-DD */
  dayKey: string
  /** Display label e.g. 07-28 */
  label: string
  threads: TimelineThread[]
}

export type MonthGroup = {
  /** Local calendar month key YYYY-MM */
  monthKey: string
  /** Display label e.g. 2026-07 */
  label: string
  days: DayGroup[]
  /** Flat count of threads in this month */
  count: number
}

export type TimelineModel = {
  today: TimelineThread[]
  /** Local calendar yesterday (default collapsed — 2026-08-06 adversary lock) */
  yesterday: TimelineThread[]
  months: MonthGroup[]
}

/** Unified fold memory (History IA + settings-thread-compact). */
export const LS_THREAD_LIST_EXPAND = "cmspark.threadList.expand"
/** Legacy key — migrated once into LS_THREAD_LIST_EXPAND. */
export const LS_THREAD_LIST_EXPAND_MONTHS_LEGACY = "cmspark.threadList.expandMonths"

export type ThreadListExpandState = {
  months: string[]
  /** Default true when missing */
  today: boolean
  /** Default false when missing (yesterday collapsed) */
  yesterday: boolean
}

export const DEFAULT_THREAD_LIST_EXPAND: ThreadListExpandState = {
  months: [],
  today: true,
  yesterday: false,
}

export function parseThreadListExpand(raw: string | null): ThreadListExpandState {
  if (!raw) return { ...DEFAULT_THREAD_LIST_EXPAND, months: [] }
  try {
    const parsed = JSON.parse(raw)
    // Legacy: bare string[] of month keys
    if (Array.isArray(parsed)) {
      return {
        months: parsed.filter((x): x is string => typeof x === "string"),
        today: DEFAULT_THREAD_LIST_EXPAND.today,
        yesterday: DEFAULT_THREAD_LIST_EXPAND.yesterday,
      }
    }
    if (parsed && typeof parsed === "object") {
      const months = Array.isArray(parsed.months)
        ? parsed.months.filter((x: unknown): x is string => typeof x === "string")
        : []
      return {
        months,
        today: typeof parsed.today === "boolean" ? parsed.today : DEFAULT_THREAD_LIST_EXPAND.today,
        yesterd