Independent READ-ONLY design gate #473. User wants narrow topbar + new chat, conversation labels/manual groups/AI auto grouping, restore AI organizing and graph entry points. Review proposed scoped design against existing code evidence, no commands/edits, no other reviewer reports. Output concise P0/P1/MAJOR/NIT and VERDICT APPROVE/APPROVE_WITH_NITS/REJECT. Capability T2 metadata/UI, no new permission defaults. AI grouping is explicitly derived view from existing AI digest primary label, NOT a new clustering backend nor persisted manual folder writes. Manual tags separate user_tags; UI distinguishes AI read-only labels versus editable human labels. Existing AI extract preserves root metadata (updates only digest); tests will prove. Protocol already supports correlation via envelope id and lifecycle echoes id on responses/errors; SW thread.update needs to forward optional id, editor listens for matching thread.updated/error and never treats send ACK as save. Groups remain one manual folder perthread; batch moves/global renaming not promised. No live configuration/data manipulation for tests. Please gate concrete requested experience, not an invented full taxonomy management platform.
# 对话管理可发现性

GitHub: #473 · Base: 913c328e · 2026-09-08

用户认可当前简洁视觉，恢复遗漏入口并补实际能力。窄栏顶栏保留常驻“+”（aria-label 新对话）调用 createBlankThread；宽屏仍以左导航创建，不重复主入口。标题区域可收缩，风险/停止不被遮盖。

单一 ThreadList 所有者继续提供历史与管理，不新增线程缓存。顶栏历史图标增加“对话管理”文字（窄屏也可辨识）；左侧最近对话旁提供“管理”，通过专用 UI event 打开同一面板。保留旧历史 accessible name 兼容已有入口。管理面板增加一排明确的 AI 提取、整理助手、关系图和回收站按钮，不藏在更多里。整理助手是规则扫描，不能误标为 AI 智能分组。更多仍保留起名/清理等操作。

视图为时间、标签、手动分组、AI 分组。AI 分组按 digest.tags 的首个主题标签派生显示，每个会话只归一个 AI 组，无标签显示“待 AI 整理”；可显式启动既有最多20条未标注 AI 提取，展示既有进度。它不是新聚类模型、不写 topic_folder，不覆盖手动分组。后台自动提取仍遵循既有配置/配额，不新增默认任务。

手动分组以应用内编辑表单替代“夹”prompt，允许选择现有名称、输入新组或移出。人工标签新增独立 user_tags 元数据，最多20个、每个40字符，去控制符/规范空白/去重；AI digest 的整体替换保留 user_tags。编辑表单明确“人工标签”与只读“AI 标签”，本轮不支持删除 AI 生成标签或重命名整个全局标签。标签筛选/搜索/行展示汇总两类标签并去重；AI 分组仅依据 AI 标签，不把人工标签伪装成 AI。表单只提交 user_tags/topic_folder，不能写其他权限字段。

保存必须收到已持久化的 thread.updated 才显示成功，传输 ACK 不算保存；错误/超时显示失败保留草稿。复用 SW 请求响应规则，先核对再实现。不会操作真实用户数据作为验证。手动分组现有一对一模型保留，批量移动和全局标签重命名不是首版承诺。

验证实际 App 320/390/759/760/1440及320短屏：顶栏新对话可达；从导航及顶栏进入同一管理面板；所有视图/AI提取/规则整理/关系图可见可调用；人工标签保存、AI提取不覆盖、分组保存/清空/失败；列表标签搜索；AI分组不修改手动归属；旧历史与确认回归。后端元数据持久化和非法输入边界测试。设计与实现 Grok4.6 + DeepSeekV4Pro独立复审，机核优先、CI绿后合并；不打包换装。

CURRENT chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
import { useEffect, useRef, useState, type ReactNode } from "react"
import { useAgentStore } from "../store/agentStore"
import { displayThreadTitle, threadRecency } from "../utils/thread-timeline"
import { tokens } from "../ui/tokens"
import { CompanionMark, IconNewChat, IconSettings } from "../ui/icons"
import { CONTEXT_PANEL_TABS, useContextPanelHost } from "./ContextPanelHost"
import { createBlankThread } from "./ThreadList"

/** Presentation only: existing store, context loaders and thread.select own data. */
export function WorkspaceFrame({ children }: { children: ReactNode }) {
  const [wide, setWide] = useState(() => window.matchMedia("(min-width: 760px)").matches)
  const [open, setOpen] = useState(false)
  const navRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLElement | null>(null)
  useEffect(() => {
    const trigger = document.querySelector<HTMLElement>(".cm-navigation-toggle")
    trigger?.setAttribute("aria-expanded", String(!wide && open))
    if (!wide && open) {
      triggerRef.current = trigger
      navRef.current?.querySelector<HTMLButtonElement>("button")?.focus()
    }
  }, [wide, open])
  const close = () => { setOpen(false); triggerRef.current?.focus() }
  useEffect(() => {
    const query = window.matchMedia("(min-width: 760px)")
    const resize = () => { setWide(query.matches); setOpen(false) }
    const toggle = () => setOpen(value => !value)
    query.addEventListener("change", resize)
    window.addEventListener("cmspark:toggle-navigation", toggle)
    return () => { query.removeEventListener("change", resize); window.removeEventListener("cmspark:toggle-navigation", toggle) }
  }, [])
  return <div className="cm-workspace">
    {wide && <WorkspaceNavigation onNavigate={() => {}} />}
    {!wide && open && <div ref={navRef} className="cm-navigation-disclosure" role="dialog" aria-modal="false" aria-label="工作区导航" onKeyDown={event => {
      if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); close() }
    }}>
      <WorkspaceNavigation onNavigate={close} onClose={close} />
    </div>}
    <main className="cm-workspace-main" aria-label="对话工作区">{children}</main>
  </div>
}

function WorkspaceNavigation({ onNavigate, onClose }: { onNavigate: () => void; onClose?: () => void }) {
  const { state, dispatch } = useAgentStore()
  const { activePanel, openPanelForce, closePanel } = useContextPanelHost()
  const [query, setQuery] = useState("")
  const recent = state.threads.filter(t => !t.trashed_at && displayThreadTitle(t).toLocaleLowerCase().includes(query.toLocaleLowerCase())).sort((a, b) => threadRecency(b).localeCompare(threadRecency(a))).slice(0, 30)
  return <aside className="cm-navigation" aria-label="工作区">
    <div className="cm-nav-brand"><CompanionMark size={24} /><strong>CMspark</strong>
      {onClose && <button type="button" className="cm-icon-button" aria-label="关闭导航" onClick={onClose}>×</button>}
    </div>
    <button type="button" className="cm-nav-new" onClick={() => { createBlankThread(dispatch); onNavigate() }}><IconNewChat size={17} />新对话</button>
    <nav aria-label="资源与能力" className="cm-nav-resources">
      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" aria-current={activePanel === id ? "true" : undefined} onClick={() => {
        dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
      }}><Icon size={16} /><span>{label}</span></button>)}
    </nav>
    <div className="cm-nav-section"><span>最近对话</span></div>
    <input className="cm-nav-search" aria-label="筛选最近对话" placeholder="查找对话…" value={query} onChange={e => setQuery(e.target.value)} />
    <div className="cm-nav-threads">
      {recent.map(thread => <button type="button" className="cm-nav-thread" key={thread.id} aria-current={thread.id === state.activeThreadId ? "page" : undefined}
        title={displayThreadTitle(thread)} onClick={() => {
          dispatch({ type: "SET_ACTIVE_THREAD", threadId: thread.id }); chrome.runtime.sendMessage({ type: "thread.select", threadId: thread.id }); onNavigate()
        }}><span>{displayThreadTitle(thread)}</span>{state.threadBusyById[thread.id] && <span className="cm-nav-running" aria-label="运行中">·</span>}</button>)}
      {!recent.length && <p className="cm-nav-empty">{query ? "没有匹配的对话" : "新对话会保存在这里"}</p>}
    </div>
    <button type="button" className="cm-nav-item cm-nav-settings" onClick={() => { closePanel(); dispatch({ type: "SET_SETTINGS_OPEN", open: true }); onNavigate() }}><IconSettings size={16} />设置</button>
  </aside>
}
CURRENT chrome-extension/src/sidepanel/components/ThreadList.tsx
    )
  }

  const renderTopicsView = () => {
    const groups = new Map<string, Thread[]>()
    for (const t of filtered as Thread[]) {
      const key = t.topic_folder || "未分组"
      const arr = groups.get(key) || []
      arr.push(t)
      groups.set(key, arr)
    }
    const keys = [...groups.keys()].sort((a, b) => {
      if (a === "未分组") return 1
      if (b === "未分组") return -1
      return a.localeCompare(b, "zh")
    })
    return (
      <>
        {keys.map((key) => (
          <div key={key}>
            <div style={styles.groupHeader}>
              <span style={styles.groupLabel}>
                {key} · {groups.get(key)!.length}
              </span>
            </div>
            {groups.get(key)!.map((t) => renderThreadRow(t))}
          </div>
        ))}
        {keys.length === 1 && keys[0] === "未分组" && filtered.length > 0 && (
          <div style={{ color: tokens.textMuted, fontSize: 11, padding: "8px 12px" }}>
            点行上的「夹」把会话放进话题夹
          </div>
        )}
        {filtered.length === 0 && (
          <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
            无匹配线程
          </div>
        )}
      </>
    )
  }

  return (
    <div style={{ position: "relative" }}>
      <button
        ref={triggerRef}
        type="button"
        style={{
          ...styles.hamburger,
          ...(open ? { color: tokens.text } : null),
        }}
        onClick={() => setOpen(!open)}
        title="历史对话"
        aria-label="历史对话"
        aria-expanded={open}
      >
        <IconHistory size={17} />
      </button>

      {open &&
        panelBox &&
        typeof document !== "undefined" &&
        createPortal(
        <>
          <div
            style={styles.backdrop}
            onClick={() => {
              setOpen(false)
              setMenuOpen(false)
              if (selectMode) exitSelectMode()
            }}
          />
          <div
            ref={historyRef} className="cm-history-panel" role="dialog" aria-label="历史对话列表" aria-modal="false"
            style={{
              ...styles.panel,
              position: "fixed",
              top: panelBox.top,
              left: 8,
              right: 8,
              width: "auto",
              maxHeight: Math.min(panelMaxHeight, panelBox.maxHeight),
              zIndex: 10050,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>历史对话</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
            <div style={styles.panelHeader}>
              <div style={styles.viewToggle}>
                <button
                  type="button"
                  style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("time")}
                >
                  时间
                </button>
                <button
                  type="button"
                  style={view === "tags" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("tags")}
                >
                  标签
                </button>
                <button
                  type="button"
                  style={view === "topics" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("topics")}
                >
                  话题
                </button>
              </div>
              <div style={{ display: "flex", gap: 6, flexShrink: 0, alignItems: "center" }}>
                <button
                  type="button"
                  style={selectMode ? styles.selectBtnActive : styles.selectBtn}
                  onClick={() => {
                    if (selectMode) exitSelectMode()
                    else {
                      setSelectMode(true)
                      setSelected(new Set())
                    }
                  }}
                  title="多选"
                >
                  {selectMode ? "取消" : "选择"}
                </button>
                <button style={styles.newBtn} onClick={handleNewThread} title="新建线程">
                  + 新建
                </button>
                <div style={{ position: "relative" }}>
                  <button
                    ref={menuBtnRef}
                    type="button"
                    style={styles.menuBtn}
                    onClick={() => setMenuOpen((v) => !v)}
                    title="更多"
                    aria-haspopup="menu"
                    aria-expanded={menuOpen}
                  >
                    ⋯
                  </button>
                  {menuOpen &&
                    menuPos &&
                    typeof document !== "undefined" &&
                    createPortal(
                      <div
                        style={{
                          ...styles.menuPortal,
                          top: menuPos.top,
                          right: menuPos.right,
                        }}
                        ref={historyMenuRef} role="menu"
                      >
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={handleGenerateTitle}
                        >
                          ✨ AI 生成标题
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() => handleBatchAutoTitle()}
                        >
                          📝 未命名→首条起名
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={handleCleanupEmpty}
                        >
                          🧹 清理空白
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() => {
                            setCleanupOpen(true)
                            setMenuOpen(false)
                            runCleanupScan()
                          }}
                        >
                          🗂 整理助手
                        </button>
                        <button
                          type="button"
                          style={{
                            ...styles.menuItem,
                            opacity: untaggedExtract.ids.length === 0 ? 0.45 : 1,
                            cursor:
                              untaggedExtract.ids.length === 0
                                ? "not-allowed"
                                : "pointer",
                          }}
                          disabled={untaggedExtract.ids.length === 0}
                          onClick={handleExtractUntagged}
                          title={
                            untaggedExtract.ids.length === 0
                              ? "没有可提取的未标注会话"
                              : `为最多 ${untaggedExtract.ids.length} 个未标注会话提取要点`
                          }
                        >
                          🏷 为未标注提取要点
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={openThreadGraph}
                          title="在新标签页打开会话关系图"
                        >
                          会话关系图
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() =>
                            trashView ? closeTrashView() : openTrashView()
                          }
                        >
                          {trashView ? "← 返回列表" : "🗑 回收站"}
                        </button>
                      </div>,
                      document.body,
                    )}
                </div>
              </div>
            </div>

            {extractProgress && extractProgress.total > 0 && (
              <div style={styles.progressBar} role="status" aria-live="polite">
                提取要点 {extractProgress.done}/{extractProgress.total}
Server transport evidence: companion/src/ws/lifecycle.ts:1472 ws.send(JSON.stringify({ ...response, id: msg?.id })); catch sends {type:error,id:msg?.id,error:e.message}. Thread update router allowlist currently includes digest/topic_folder, will add user_tags. ThreadManager.update sanitizes topic_folder and digest independently.
