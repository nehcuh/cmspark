Independent supplemental closure #473. Narrow evidence question after implementation gate: does production Companion echo the request envelope id for thread.update success and errors? Previous gate packet omitted unchanged lifecycle context. The router is NOT responsible for id stamping; don't demand result.id on handleMessage because the outer authenticated WS lifecycle stamps it. Read the actual unchanged wrapper below; determine whether this closes the evidence gap. All other #473 source is frozen as in /private/tmp/cmspark-473-closure/packet.md (available only if needed), and tests build/1285 ext + 4998 comp/23 skipped +20 auxiliary +both browser checks passed before review. No source changes needed for this supplement. Separate icon work #474 is outside this gate. No other reviewer reports. Output P0/P1/MAJOR if any and VERDICT: APPROVE / APPROVE_WITH_NITS / REJECT, max 400 words. Review only the evidence gap, not speculative rewrites.


### companion/src/ws/lifecycle.ts

1371:         // current. validateWsMessage already enforced tabId:number + url:string.
1372:         // Fire-and-forget — no ack needed.
1373:         if (msg.type === "tab.navigated") {
1374:           const origin = wsAuth.get(ws)?.origin
1375:           if (!isChromeExtensionWsOrigin(origin)) return
1376:           applyTabNavigated(msg.tabId, msg.url)
1377:           return
1378:         }
1379: 
1380:         let response: any
1381:         try {
1382:           response = await handleMessage(
1383:             msg,
1384:             { threadManager: requireRt().getThreadManager(), skillEngine: requireRt().getSkillEngine(), historyStore: requireRt().getHistoryStore() },
1385:             {
1386:               sendToExtension: (data: any) => {
1387:                 if (ws.readyState === WebSocket.OPEN) {
1388:                   ws.send(JSON.stringify(data))
1389:                 }
1390:                 const t = data?.type
1391:                 if (
1392:                   t !== "chat.token" &&
1393:                   t !== "chat.user" &&
1394:                   t !== "chat.done" &&
1395:                   t !== "chat.error" &&
1396:                   t !== "chat.aborted" &&
1397:                   t !== "run_status" &&
1398:                   t !== "thread.updated"
1399:                 ) {
1400:                   return
1401:                 }
1402:                 try {
1403:                   const { pushSummonerWebEvent } = require("../summoner-web") as typeof import("../summoner-web")
1404:                   const surface = wsAuth.get(ws)?.surface
1405:                   if (surface !== "summoner") {
1406:                     pushSummonerWebEvent(data)
1407:                   } else {
1408:                     const payload = JSON.stringify(data)
1409:                     for (const c of clients) {
1410:                       if (c === ws || c.readyState !== WebSocket.OPEN) continue
1411:                       const st = wsAuth.get(c)
1412:                       if (st?.authenticated && st.surface !== "summoner") c.send(payload)
1413:                     }
1414:                   }
1415:                 } catch {
1416:                   /* overlay SSE optional */
1417:                 }
1418:               },
1419:               executeTool,
1420:               // App tab D2 biometric gates (apps.add/set_policy →auto): same
1421:               // origin-bound confirmation channel as executeTool's
1422:               // sendConfirmation above — nonce-carrying confirmations resolve
1423:               // only on the socket that requested them (amendment A1).
1424:               requestConfirmation: (details) =>
1425:                 requireRt().securityConfirmations.request(
1426:                   (data) => {
1427:                     if (ws.readyState === WebSocket.OPEN) {
1428:                       ws.send(JSON.stringify(data))
1429:                     }
1430:                   },
1431:                   details,
1432:                   { originWs: ws },
1433:                 ),
1434:               broadcast: (data: any) => {
1435:                 const message = JSON.stringify(data)
1436:                 for (const client of clients) {
1437:                   try {
1438:                     // Y-e: mirror broadcastToClients (X3) — never fan out to
1439:                     // unauthenticated connections inside the handshake window.
1440:                     if (client.readyState === WebSocket.OPEN && wsAuth.get(client)?.authenticated === true) {
1441:                       client.send(message)
1442:                     }
1443:                   } catch { /* ignore disconnected */ }
1444:                 }
1445:               },
1446:               // WP4: 每连接面板标识(computer.evidence.open P6 频率上限计数)。
1447:               panelId,
1448:               // Path B M1: origin class for voice.stt.* (chrome-extension vs tray).
1449:               origin: peerOrigin,
1450:               surface: wsAuth.get(ws)?.surface,
1451:               originWs: ws,
1452:             },
1453:           )
1454:         } catch (handlerErr: any) {
1455:           // Keep Companion alive on STT/tool handler throws (was process-killing via unhandledRejection).
1456:           logger.error("ws.handleMessage.threw", {
1457:             type: typeof msg?.type === "string" ? msg.type : undefined,
1458:             error: handlerErr?.message || String(handlerErr),
1459:           })
1460:           response = {
1461:             type: "error",
1462:             error: handlerErr?.message || "handler failed",
1463:             family: typeof msg?.type === "string" ? String(msg.type).split(".")[0] : "ws",
1464:           }
1465:         }
1466: 
1467:         if (response && ws.readyState === WebSocket.OPEN) {
1468:           // Echo the request id so clients can match this response to a pending
1469:           // request. Without it, request-type responses (e.g. skill.list) are
1470:           // indistinguishable from server pushes and may be re-issued by clients
1471:           // that dispatch by type.
1472:           ws.send(JSON.stringify({ ...response, id: msg?.id }))
1473:         }
1474:       } catch (e: any) {
1475:         logger.error("ws.message_error", { error: e.message || String(e) })
1476:         if (ws.readyState === WebSocket.OPEN) {
1477:           ws.send(JSON.stringify({ type: "error", id: msg?.id, error: e.message }))
1478:         }
1479:       }
1480:     })
1481: 

### companion/src/message-router.ts

2984:     case "thread.update": {
2985:       if (!rest.thread_id) return { type: "error", error: "thread_id required" }
2986:       const allowedUpdates: Record<string, any> = {}
2987:       const updates = rest.updates || {}
2988:       for (const key of [
2989:         "alias",
2990:         "config_override",
2991:         "tool_whitelist",
2992:         "pinned_tabs",
2993:         "active_skill_ids",
2994:         "active_knowledge_ids",
2995:         "skill_selection_mode",
2996:         "knowledge_selection_mode",
2997:         "knowledge_smart_match",
2998:         "knowledge_route_by_group",
2999:         "mcp_selection_mode",
3000:         "active_mcp_server_ids",
3001:         "digest",
3002:         "topic_folder",
3003:         "user_tags",
3004:       ]) {
3005:         if (Object.prototype.hasOwnProperty.call(updates, key)) {
3006:           allowedUpdates[key] = updates[key]
3007:         }
3008:       }
3009:       // C6 multi-adv: worker cannot open full surface or re-add HARD_DENY tools via update
3010:       if (Object.prototype.hasOwnProperty.call(allowedUpdates, "tool_whitelist")) {
3011:         const existing = threadManager.get(rest.thread_id)
3012:         if (existing?.agent_role === "worker") {
3013:           const { WORKER_HARD_DENY } = await import("./orchestrator/constants")
3014:           const wl = allowedUpdates.tool_whitelist
3015:           if (wl === null) {
3016:             return {
3017:               type: "error",
3018:               error:
3019:                 "thread.update: worker cannot set tool_whitelist=null (full surface). HARD_DENY tools remain denied.",
3020:               code: "worker_whitelist_elevation",
3021:             }
3022:           }
3023:           if (Array.isArray(wl)) {
3024:             allowedUpdates.tool_whitelist = wl.filter(
3025:               (t: unknown) => typeof t === "string" && !WORKER_HARD_DENY.has(t),
3026:             )
3027:           }
3028:         }
3029:       }
3030:       try {
3031:         const thread = threadManager.update(rest.thread_id, allowedUpdates)
3032:         if (!thread) return { type: "error", error: `Thread not found: ${rest.thread_id}` }
3033:         return { type: "thread.updated", thread }
3034:       } catch (e: any) {
3035:         return { type: "error", error: e.message || String(e) }
3036:       }
3037:     }
3038: 
3039:     case "thread.run_progress.toggle":
3040:       return handleRunProgressToggle(rest, threadManager)
3041: 
3042:     // --- #327: thread execution cap (plan_readonly). user_gesture-only write;
3043:     // workers inherit (set it on the orchestrator thread).
3044:     // #433 P2: summoner may only tighten (→ plan_readonly); upgrade/arm stays panel. ---
3045:     case "thread.execution_policy.set": {
3046:       if (stampedSurface === "summoner" && rest.policy !== "plan_readonly") {
3047:         return {
3048:           type: "error",
3049:           error: "SUMMONER_ACL: summoner may only downgrade execution_policy; upgrade/arm in the panel confirm center",
3050:           error_code: "SUMMONER_ACL",
3051:         }
3052:       }
3053:       if (rest.user_gesture !== true) {
3054:         return { type: "error", error: "thread.execution_policy.set requires user_gesture:true (user-initiated only)" }
3055:       }
3056:       if (typeof rest.thread_id !== "string" || !rest.thread_id) {
3057:         return { type: "error", error: "thread.execution_policy.set requires thread_id" }
3058:       }
3059:       const { isExecutionPolicy } = await import("./tool/plan-readonly")
3060:       if (!isExecutionPolicy(rest.policy)) {
3061:         return { type: "error", error: "thread.execution_policy.set requires policy: \"default\" | \"plan_readonly\"" }
3062:       }
3063:       const targetThread = threadManager.get(rest.thread_id)
3064:       if (!targetThread) {
3065:         return { type: "error", error: `Thread not found: ${rest.thread_id}` }
3066:       }
3067:       if (targetThread.agent_role === "worker") {
3068:         return {
3069:           type: "error",
3070:           error:
3071:             "thread.execution_policy.set: workers inherit their orchestrator's execution_policy — set it on the orchestrator thread",
3072:           code: "worker_policy_inherited",
3073:         }
3074:       }
3075:       try {
3076:         // capture BEFORE update: get() returns the live thread object
3077:         const from = targetThread.execution_policy ?? "default"
3078:         const thread = threadManager.update(rest.thread_id, {
3079:           execution_policy: rest.policy,
3080:         } as any)
3081:         if (!thread) return { type: "error", error: `Thread not found: ${rest.thread_id}` }
3082:         const { appendCapabilityAudit } = await import("./packs/audit-log")
3083:         appendCapabilityAudit({

### chrome-extension/src/background/index.ts

976:         // add_to_thread_whitelist, stop_thread. Companion handleSecurityConfirmationResponse
977:         // already consumes these (server.ts ~1481-1515). Dropping them silently
978:         // breaks whitelist persistence, nonce challenge, and thread trust.
979:         noteSecurityConfirmationGone(message.confirmation_id)
980:         wsClient.send(buildSecurityConfirmationWsPayload(message))
981:         sendResponse({ ok: true })
982:         return true
983: 
984:       case "thread.select":
985:         wsClient.send({ type: "thread.select", thread_id: message.threadId })
986:         sendResponse({ ok: true })
987:         return true
988: 
989:       case "thread.update":
990:         if (message.require_connected && wsClient.getState() !== "connected") {
991:           sendResponse({ ok: false, error: "Companion 未连接，尚未保存" })
992:           return false
993:         }
994:         const metadataSent = wsClient.send({ type: "thread.update", id: message.id, thread_id: message.threadId || message.thread_id, updates: message.updates })
995:         sendResponse({ ok: metadataSent })
996:         return true
997: 
998:       case "thread.run_progress.toggle":
999:         wsClient.send({
1000:           type: "thread.run_progress.toggle",
1001:           thread_id: message.thread_id || message.threadId,
1002:           item_id: message.item_id,
1003:         })
1004:         sendResponse({ ok: true })
1005:         return true
1006: 
1007:       case "thread.delete":
1008:         // Align with companion: omit/unknown → hard; only explicit "trash" soft-deletes.
1009:         wsClient.send({
1010:           type: "thread.delete",

### chrome-extension/src/sidepanel/utils/thread-management.ts

1: type TaggedThread = { user_tags?: string[]; digest?: { tags?: string[] } | null }
2: 
3: export function threadTags(thread: TaggedThread): string[] {
4:   return [...new Set([...(thread.user_tags || []), ...(thread.digest?.tags || [])]
5:     .filter(tag => typeof tag === "string" && tag.trim()).map(tag => tag.trim().toLowerCase()))]
6: }
7: 
8: /** A derived AI view; never writes or overrides a user's manual folder. */
9: export function aiThreadGroup(thread: TaggedThread): string | null {
10:   return thread.digest?.tags?.find(tag => typeof tag === "string" && tag.trim())?.trim().toLowerCase() || null
11: }
12: 
13: /** Wait for the server's persisted response, not the service worker transport ACK. */
14: export function saveThreadMetadata(threadId: string, updates: { user_tags: string[]; topic_folder: string | null }, signal: AbortSignal): Promise<any> {
15:   return new Promise((resolve, reject) => {
16:     if (signal.aborted) { reject(new Error("已取消等待")); return }
17:     const id = `thread-metadata-${crypto.randomUUID()}`
18:     let timer: ReturnType<typeof setTimeout>
19:     let settled = false
20:     const finish = (error?: Error, thread?: any) => {
21:       if (settled) return
22:       settled = true
23:       clearTimeout(timer)
24:       chrome.runtime.onMessage.removeListener(receive)
25:       signal.removeEventListener("abort", cancel)
26:       if (error) reject(error)
27:       else resolve(thread)
28:     }
29:     const cancel = () => finish(new Error("已取消等待；已发送的保存可能仍会完成"))
30:     const receive = (message: any) => {
31:       if (message?.id !== id) return
32:       if (message.type === "thread.updated" && message.thread?.id === threadId) {
33:         const actualTags = threadTags({ user_tags: message.thread.user_tags }).sort()
34:         const wantedTags = threadTags({ user_tags: updates.user_tags }).sort()
35:         if (JSON.stringify(actualTags) !== JSON.stringify(wantedTags) || (message.thread.topic_folder || null) !== updates.topic_folder) {
36:           finish(new Error("服务端未确认所提交的分类，请确认 Companion 已更新后重试"))
37:         } else finish(undefined, message.thread)
38:       }
39:       else if (message.type === "error") finish(new Error(message.error || "保存失败"))
40:     }
41:     chrome.runtime.onMessage.addListener(receive)
42:     signal.addEventListener("abort", cancel, { once: true })
43:     timer = setTimeout(() => finish(new Error("尚未收到保存确认，请检查连接后重试")), 15_000)
44:     chrome.runtime.sendMessage({ type: "thread.update", id, thread_id: threadId, updates, require_connected: true }).then(response => {
45:       if (response?.ok === false) finish(new Error(response.error || "连接不可用"))
46:     }).catch(error => finish(new Error(error?.message || "发送失败")))
47:   })
48: }

### companion/tests/thread-digest.test.ts

212: test("human tags persist independently when AI digest is replaced, including after reload", async () => {
213:   const manager = new ThreadManager()
214:   const thread = manager.create("human classifications")
215:   const result = await handleMessage({ type: "thread.update", thread_id: thread.id, updates: { user_tags: [" 支付 ", "PAY", "pay"], topic_folder: "发布" } } as any, { threadManager: manager, skillEngine: {} as any, historyStore: {} as any }, { sendToExtension: () => {}, executeTool: async () => ({ success: true }), broadcast: () => {} } as any)
216:   assert.equal(result.type, "thread.updated")
217:   assert.deepEqual((result as any).thread.user_tags, ["支付", "PAY"])
218:   assert.equal((result as any).thread.topic_folder, "发布")
219:   assert.deepEqual(manager.get(thread.id)?.user_tags, ["支付", "PAY"])
220:   manager.update(thread.id, { digest: { extracted_at: new Date().toISOString(), content_fingerprint: "0:empty", tldr: "AI result", tags: ["模型建议"], source: "manual" } })
221:   const persisted = new ThreadManager().get(thread.id)
222:   assert.deepEqual(persisted?.user_tags, ["支付", "PAY"])
223:   assert.equal(persisted?.topic_folder, "发布")
224:   assert.deepEqual(persisted?.digest?.tags, ["模型建议"])
225:   manager.update(thread.id, { user_tags: [], topic_folder: null })
226:   const cleared = new ThreadManager().get(thread.id)
227:   assert.deepEqual(cleared?.user_tags, [])
228:   assert.equal(cleared?.topic_folder, null)
229:   assert.deepEqual(cleared?.digest?.tags, ["模型建议"])
230: })
231: 
232: test("human tag writes reject malformed and oversized inputs without overwriting existing labels", () => {
233:   const manager = new ThreadManager();const thread=manager.create("guard tags")
234:   manager.update(thread.id,{user_tags:["keep"]})
235:   for (const value of [null, "not-array", [42], Array(21).fill("tag")]) {
236:     assert.throws(()=>manager.update(thread.id,{user_tags:value as any}),/user_tags/)
237:     assert.deepEqual(manager.get(thread.id)?.user_tags,["keep"])
238:   }
239:   manager.update(thread.id,{user_tags:["a\u0000b", "", "x".repeat(50)]})
240:   assert.deepEqual(manager.get(thread.id)?.user_tags,["ab", "x".repeat(40)])
241: })