Provide a plain-text independent design review, not tool calls or execution plans. No tools exist in this review. Prior attempt emitted XML tool calls and contained no verdict, so it was invalid. Review ONLY the following design and state whether any P0/P1/MAJOR blockers exist. Be concise (500 words). End VERDICT: APPROVE, APPROVE_WITH_NITS, or REJECT. User wants a narrow + button, discoverable existing management/AI/graph, manual labels/groups and AI grouping. Existing AI digest extraction is reused; AI grouping is a derived view, explicitly named as such, never writes a manual folder. Transport already echoes envelope id on response/errors; use matching reply, no ACK-success. No live data altered by development tests.
# 对话管理可发现性

GitHub: #473 · Base: 913c328e · 2026-09-08

用户认可当前简洁视觉，恢复遗漏入口并补实际能力。窄栏顶栏保留常驻“+”（aria-label 新对话）调用 createBlankThread；宽屏仍以左导航创建，不重复主入口。标题区域可收缩，风险/停止不被遮盖。

单一 ThreadList 所有者继续提供历史与管理，不新增线程缓存。顶栏历史图标增加“对话管理”文字（窄屏也可辨识）；左侧最近对话旁提供“管理”，通过专用 UI event 打开同一面板。保留旧历史 accessible name 兼容已有入口。管理面板增加一排明确的 AI 提取、整理助手、关系图和回收站按钮，不藏在更多里。整理助手是规则扫描，不能误标为 AI 智能分组。更多仍保留起名/清理等操作。

视图为时间、标签、手动分组、AI 分组。AI 分组按 digest.tags 的首个主题标签派生显示，每个会话只归一个 AI 组，无标签显示“待 AI 整理”；可显式启动既有最多20条未标注 AI 提取，展示既有进度。它不是新聚类模型、不写 topic_folder，不覆盖手动分组。后台自动提取仍遵循既有配置/配额，不新增默认任务。

手动分组以应用内编辑表单替代“夹”prompt，允许选择现有名称、输入新组或移出。人工标签新增独立 user_tags 元数据，最多20个、每个40字符，去控制符/规范空白/去重；AI digest 的整体替换保留 user_tags。编辑表单明确“人工标签”与只读“AI 标签”，本轮不支持删除 AI 生成标签或重命名整个全局标签。标签筛选/搜索/行展示汇总两类标签并去重；AI 分组仅依据 AI 标签，不把人工标签伪装成 AI。表单只提交 user_tags/topic_folder，不能写其他权限字段。

保存必须收到已持久化的 thread.updated 才显示成功，传输 ACK 不算保存；错误/超时显示失败保留草稿。复用 SW 请求响应规则，先核对再实现。不会操作真实用户数据作为验证。手动分组现有一对一模型保留，批量移动和全局标签重命名不是首版承诺。

验证实际 App 320/390/759/760/1440及320短屏：顶栏新对话可达；从导航及顶栏进入同一管理面板；所有视图/AI提取/规则整理/关系图可见可调用；人工标签保存、AI提取不覆盖、分组保存/清空/失败；列表标签搜索；AI分组不修改手动归属；旧历史与确认回归。后端元数据持久化和非法输入边界测试。设计与实现 Grok4.6 + DeepSeekV4Pro独立复审，机核优先、CI绿后合并；不打包换装。
