Independent implementation closure #473. Read only this frozen packet. Do not read other judge reports. Give P0/P1/MAJOR/NIT then VERDICT: APPROVE / APPROVE_WITH_NITS / REJECT. Max 1000 words. Scope T2 thread metadata, T3 visibility-only Stop/confirm priority; no permission/default/job change. Assess outcome/trajectory/components. User asked narrow +, visible management, human tags/manual and AI grouping, restored AI cleanup and graph. AI group is explicitly first AI tag derived view, no new clusterer. This packet includes all diff/new files and relevant complete dependencies.
Closure targets independently verify: graph human-only tags remain eligible for AI extract and retain digest-only color; actual handler thread.updated fields tested; outside close exits selection; timeout listener cleanup and matching-envelope wrong-thread test; nav management disabled under confirmation. All machine commands below exit 0 before review. No real user mutations. Other new user request #474 is separate future icon scope and excluded here.

diff --git a/CHANGELOG.md b/CHANGELOG.md
index bba1f6dc..a2a7d16b 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -4,6 +4,8 @@
 
 ## [Unreleased]
 
+- 对话管理入口与分类（#473）：窄栏顶栏常驻“+”，显式对话管理/AI提取/规则整理/图谱入口；新增独立人工标签、应用内手动分组编辑及按 AI 主标签派生的分组视图。匹配服务端确认后才显示保存成功，管理面板让出停止和待确认操作。
+
 - 召唤器与设置重设计（#471）：删除召唤器所有装饰性“山”，统一聊天输入和操作布局；设置改为八类导航页面，保留草稿和深链，明确保存范围，补齐语音取消及许可证弹窗键盘隔离。
 
 - 整体 UI/UX 工作区重设计（#469）：宽屏常驻导航与可读对话列，窄屏非遮罩导航，统一输入区、历史键盘操作、设置分类和上下文布局；终端、确认台、图谱、召唤窗口和独立设置页同步视觉语言。保持现有确认和执行策略，未发版或替换安装程序。
diff --git a/DESIGN.md b/DESIGN.md
index 10c18bd2..27e66cfe 100644
--- a/DESIGN.md
+++ b/DESIGN.md
@@ -35,7 +35,7 @@ One responsive conversation workspace. At wide width, a quiet left navigation
 shows new conversation, recent conversations and supporting resources. At narrow
 width, navigation opens through the text-labeled header control 导航 as an in-flow, nonmodal disclosure (maximum28dvh, independently scrollable); primary conversation keeps full
 width. Existing full history preserves search, folders, trash and bulk actions.
-StatusRail remains the single conversation header: 导航 (narrow only), task title, existing popout/history/status/more. New conversation is owned by WorkspaceNavigation; no second new-thread control in the header. Recent rows are a projection of the existing store, while full history preserves its original owner. Conversation header shows task title (existing title resolver, 新对话 fallback); page/context and pending confirmation stay
+StatusRail remains the single conversation header: 导航 (narrow only), task title, existing popout/history/status/more. New conversation uses the existing createBlankThread owner: WorkspaceNavigation on wide screens and a persistent header + below760px (#473). Recent rows are a projection of the existing store, while full history preserves its original owner. Conversation header shows task title (existing title resolver, 新对话 fallback); page/context and pending confirmation stay
 in the existing FocusBand. Knowledge/scenes/skills/MCP/apps/meetings use existing
 ContextPanelHost. The host is already vertically stacked, not a fixed-width side column: preserve that safe layout, cap it to36dvh (28dvh below560px height), and close supporting panels before opening configuration. Do not overlay pending confirmation. Settings is one named dialog with category pages; the #471 refinement below owns its navigation.
 No duplicated data loader, thread cache, Agent or confirmation center.
@@ -113,3 +113,7 @@ and file/knowledge from model configuration. Keep all pages mounted so drafts
 and safety forms survive switching; retain stable deep-link IDs and save semantics.
 Pairing/elevated-trust status remains visible across categories. Root specification:
 `docs/superpowers/plans/2026-09-08-summoner-settings-redesign.md`.
+
+## 2026-09-08 conversation management · #473
+
+Keep the approved chat visual. Narrow headers retain a + button and named conversation management; wide navigation exposes management beside recent conversations. A single ThreadList owns time/tags/manual groups/derived AI groups and visible AI extraction, rules cleanup, graph and trash entry points. Manual labels persist separately from AI digest. AI grouping is a view of the first extracted AI label and can change on re-extraction, never rewriting manual folders. Replies must confirm the matching persisted update and its fields before showing save success. The nonmodal manager stays above the composer and yields immediately to pending confirmations; it never intercepts Stop. Narrow rows put actions below readable titles. See #473 plan and tests.
diff --git a/chrome-extension/scripts/render-workspace-fixture.cjs b/chrome-extension/scripts/render-workspace-fixture.cjs
index 736ba08e..a3267846 100644
--- a/chrome-extension/scripts/render-workspace-fixture.cjs
+++ b/chrome-extension/scripts/render-workspace-fixture.cjs
@@ -6,10 +6,10 @@ const hook=`import {useEffect} from 'react';import {useAgentStore} from ${JSON.s
 export const shouldApplyStreamEvent=()=>true;
 export function useWebSocket(){const {state,dispatch}=useAgentStore();window.fixtureState=state;useEffect(()=>{window.dispatchUI=dispatch;const threads=window.demoThreads;dispatch({type:'SET_CONNECTION',state:'connected'});dispatch({type:'SET_THREADS',threads});dispatch({type:'SET_ACTIVE_THREAD',threadId:threads[0].id});dispatch({type:'SET_MESSAGES',messages:[]});},[]);return {connectionState:state.connectionState};}`;
 const source=`import {CockpitRoot} from ${JSON.stringify(path.join(root,'src/cockpit/CockpitApp.tsx'))};import React from 'react';import{createRoot}from'react-dom/client';import{App}from${JSON.stringify(path.join(root,'src/sidepanel/App.tsx'))};
-const event={addListener(){},removeListener(){}};window.sent=[];
+const event={addListener(){},removeListener(){}};window.sent=[];window.runtimeListeners=new Set();window.emitRuntime=message=>{for(const fn of window.runtimeListeners)fn(message)};const runtimeEvent={addListener:fn=>window.runtimeListeners.add(fn),removeListener:fn=>window.runtimeListeners.delete(fn)};
 window.demoThreads=['发布 v2.8 · 变更材料','支付服务 · 需求与测试追溯','本周运行状态巡检','整理架构评审记录'].map((alias,i)=>({id:'demo-'+i,alias,created_at:new Date().toISOString(),updated_at:new Date().toISOString(),config_override:{},tool_whitelist:null,pinned_tabs:[],active_skill_ids:[],agent_role:'normal'}));
 const tabs=[{id:1,title:'支付服务 · 版本 v2.8 — DevOps',url:'https://devops.example.test/releases/2.8',active:true}];
 const respond=(value,cb)=>{if(typeof cb==='function')queueMicrotask(()=>cb(value));return Promise.resolve(value)};
-window.chrome={runtime:{id:'preview',getURL:p=>p,onMessage:event,onConnect:event,sendMessage:(m,cb)=>{window.sent.push(m);let value={ok:true};if(m.type==='thread.create')value={thread:{...window.demoThreads[0],id:'created-'+Date.now(),alias:''}};if(m.type==='thread.select')setTimeout(()=>window.dispatchUI({type:'SET_MESSAGES',messages:[]}),0);return respond(value,cb)},connect:()=>({onMessage:event,onDisconnect:event,postMessage(){},disconnect(){}})},storage:{local:{get:(keys,cb)=>respond({},cb),set:(v,cb)=>respond({},cb)},onChanged:event},tabs:{query:(q,cb)=>respond(tabs,cb),onActivated:event,onUpdated:event},windows:{getCurrent:(o,cb)=>respond({id:1},cb)},commands:{onCommand:event}};
+window.chrome={runtime:{id:'preview',getURL:p=>p,onMessage:runtimeEvent,onConnect:event,sendMessage:(m,cb)=>{window.sent.push(m);let value={ok:true};if(m.type==='thread.update' && m.id && window.metadataReply!=='ack-only')setTimeout(()=>window.emitRuntime(window.metadataReply==='error'?{type:'error',id:m.id,error:'Fixture persistence failed'}:{type:'thread.updated',id:m.id,thread:{...window.fixtureState.threads.find(t=>t.id===m.thread_id),...m.updates}}),25);if(m.type==='thread.create')value={thread:{...window.demoThreads[0],id:'created-'+Date.now(),alias:''}};if(m.type==='thread.select')setTimeout(()=>window.dispatchUI({type:'SET_MESSAGES',messages:[]}),0);return respond(value,cb)},connect:()=>({onMessage:event,onDisconnect:event,postMessage(){},disconnect(){}})},storage:{local:{get:(keys,cb)=>respond({},cb),set:(v,cb)=>respond({},cb)},onChanged:event},tabs:{query:(q,cb)=>respond(tabs,cb),onActivated:event,onUpdated:event},windows:{getCurrent:(o,cb)=>respond({id:1},cb)},commands:{onCommand:event}};
 createRoot(document.getElementById('root')).render(location.search.includes('cockpit') ? <CockpitRoot/> : <App/>);`;
 require(path.join(root,'node_modules/esbuild')).build({stdin:{contents:source,resolveDir:root,loader:'tsx'},bundle:true,outfile:path.join(out,'app.js'),jsx:'automatic',loader:{'.css':'css','.woff2':'dataurl','.woff':'dataurl','.ttf':'dataurl'},plugins:[{name:'synthetic-transport',setup(b){b.onResolve({filter:/hooks\/useWebSocket$/},()=>({path:'fixture-hook',namespace:'fixture'}));b.onLoad({filter:/.*/,namespace:'fixture'},()=>({contents:hook,loader:'tsx',resolveDir:root}));}}]}).then(()=>{fs.writeFileSync(path.join(out,'index.html'),'<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="app.css"><body style="margin:0"><div id="root"></div><script src="app.js"></script></body></html>');console.log(out)}).catch(e=>{console.error(e);process.exit(1)});
diff --git a/chrome-extension/scripts/test-workspace-ui.py b/chrome-extension/scripts/test-workspace-ui.py
index eeabe7ba..40688847 100644
--- a/chrome-extension/scripts/test-workspace-ui.py
+++ b/chrome-extension/scripts/test-workspace-ui.py
@@ -58,7 +58,7 @@ with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
         assert page.evaluate('document.querySelector("[aria-label=设置]").contains(document.activeElement)')
         settings.get_by_role('button',name='关闭设置',exact=True).click()
         # Existing history is named and keyboard operable; Escape returns focus.
-        history=page.get_by_role('button',name='历史对话',exact=True)
+        history=page.get_by_role('button',name='对话管理（历史对话）',exact=True)
         history.click()
         dialog=page.get_by_role('dialog',name='历史对话列表',exact=True)
         dialog.wait_for()
diff --git a/chrome-extension/src/background/index.ts b/chrome-extension/src/background/index.ts
index f906795a..584714f2 100644
--- a/chrome-extension/src/background/index.ts
+++ b/chrome-extension/src/background/index.ts
@@ -987,8 +987,12 @@ function handleRuntimeMessage(message: any, sendResponse: (r?: any) => void): bo
         return true
 
       case "thread.update":
-        wsClient.send({ type: "thread.update", thread_id: message.threadId || message.thread_id, updates: message.updates })
-        sendResponse({ ok: true })
+        if (message.require_connected && wsClient.getState() !== "connected") {
+          sendResponse({ ok: false, error: "Companion 未连接，尚未保存" })
+          return false
+        }
+        const metadataSent = wsClient.send({ type: "thread.update", id: message.id, thread_id: message.threadId || message.thread_id, updates: message.updates })
+        sendResponse({ ok: metadataSent })
         return true
 
       case "thread.run_progress.toggle":
diff --git a/chrome-extension/src/background/thread-graph.ts b/chrome-extension/src/background/thread-graph.ts
index 5d1bae4b..922cf0b4 100644
--- a/chrome-extension/src/background/thread-graph.ts
+++ b/chrome-extension/src/background/thread-graph.ts
@@ -9,6 +9,7 @@ export const THREAD_GRAPH_SNAPSHOT_KEY = "cmspark.thread_graph_snapshot"
 /** Slim thread seed — digest only, never message bodies (R5). */
 export type ThreadGraphSlim = {
   id: string
+  user_tags?: string[]
   alias?: string
   updated_at?: string
   created_at?: string
@@ -84,6 +85,7 @@ export function slimThreadGraphRow(raw: unknown): ThreadGraphSlim | null {
   }
   return {
     id,
+    user_tags: Array.isArray(t.user_tags) ? t.user_tags.filter((tag): tag is string => typeof tag === "string").slice(0, 20).map(tag => tag.slice(0, 40)) : undefined,
     alias: typeof t.alias === "string" ? t.alias.slice(0, 200) : undefined,
     updated_at: typeof t.updated_at === "string" ? t.updated_at : undefined,
     created_at: typeof t.created_at === "string" ? t.created_at : undefined,
diff --git a/chrome-extension/src/sidepanel/components/StatusRail.tsx b/chrome-extension/src/sidepanel/components/StatusRail.tsx
index af94a9db..0ac52418 100644
--- a/chrome-extension/src/sidepanel/components/StatusRail.tsx
+++ b/chrome-extension/src/sidepanel/components/StatusRail.tsx
@@ -2,7 +2,7 @@
 // Mode badge + pin · connection (token colors) · thread switcher · ⋯ menu
 
 import { useState, useRef, useEffect, type CSSProperties } from "react"
-import { ThreadList } from "./ThreadList"
+import { ThreadList, createBlankThread } from "./ThreadList"
 import { useAgentStore } from "../store/agentStore"
 import type { ConnectionState, CapabilityLevel } from "../types"
 import {
@@ -230,11 +230,12 @@ export function StatusRail({
       />
       {/* Brand point (small CompanionMark) — #321 PR-3: resident, no longer hidden
           on cruise / disconnect. Decorative (CompanionMark stays aria-hidden). */}
-      <div style={railStyles.brand} title="CMspark" aria-label="CMspark">
+      <div className="cm-rail-brand" style={railStyles.brand} title="CMspark" aria-label="CMspark">
         <CompanionMark size={16} />
       </div>
       <div className="cm-task-title" title={taskTitle}>{taskTitle}</div>
       <div style={railStyles.cluster}>
+      <button type="button" className="cm-icon-button cm-header-new" title="新对话" aria-label="新对话" onClick={() => createBlankThread(dispatch)}>+</button>
       <button
         type="button"
         style={{
diff --git a/chrome-extension/src/sidepanel/components/ThreadList.tsx b/chrome-extension/src/sidepanel/components/ThreadList.tsx
index e6333099..44f6a695 100644
--- a/chrome-extension/src/sidepanel/components/ThreadList.tsx
+++ b/chrome-extension/src/sidepanel/components/ThreadList.tsx
@@ -5,6 +5,8 @@ import { useCallback, useEffect, useMemo, useRef, useState } from "react"
 import { createPortal } from "react-dom"
 import { useAgentStore } from "../store/agentStore"
 import { tokens } from "../ui/tokens"
+import { ThreadMetadataEditor } from "./ThreadMetadataEditor"
+import { aiThreadGroup, threadTags } from "../utils/thread-management"
 import { IconHistory } from "../ui/icons"
 import { popupMenuStyles } from "../ui/popupMenuStyles"
 import type { Thread } from "../types"
@@ -108,11 +110,20 @@ function saveExpandState(state: ThreadListExpandState) {
   }
 }
 
-type ListView = "time" | "tags" | "topics"
+type ListView = "time" | "tags" | "topics" | "ai"
 
 export function ThreadList() {
   const { state, dispatch } = useAgentStore()
   const [open, setOpen] = useState(false)
+  const [editingThread, setEditingThread] = useState<Thread | null>(null)
+  const [metadataNotice, setMetadataNotice] = useState("")
+  useEffect(() => { if (!open) { setEditingThread(null); setMetadataNotice("") } }, [open])
+  useEffect(() => {
+    const show = () => { if (!state.pendingSecurityConfirmations.length) setOpen(true) }
+    window.addEventListener("cmspark:open-thread-manager", show)
+    return () => window.removeEventListener("cmspark:open-thread-manager", show)
+  }, [state.pendingSecurityConfirmations.length])
+  useEffect(() => { if (state.pendingSecurityConfirmations.length) setOpen(false) }, [state.pendingSecurityConfirmations.length])
   const [query, setQuery] = useState("")
   const [view, setView] = useState<ListView>("time")
   const [selectMode, setSelectMode] = useState(false)
@@ -453,12 +464,13 @@ export function ThreadList() {
       last_message_at: t.last_message_at ?? null,
       agent_role: t.agent_role,
       trashed_at: t.trashed_at ?? null,
+      user_tags: t.user_tags,
       digest: t.digest
         ? {
-            tldr: t.digest.tldr,
+            tldr: t.digest?.tldr || "",
             tags: t.digest.tags,
-            bullets: t.digest.bullets,
-            stale: t.digest.stale,
+            bullets: t.digest?.bullets || [],
+            stale: t.digest?.stale,
           }
         : null,
     }))
@@ -838,7 +850,7 @@ export function ThreadList() {
     beginExtractBatch(ids, force)
   }
 
-  const panelMaxHeight = selectMode || view === "tags" || view === "topics" ? 480 : 360
+  const panelMaxHeight = selectMode || view === "tags" || view === "topics" || view === "ai" ? 480 : 360
 
   useEffect(() => {
     if (!open) {
@@ -850,14 +862,32 @@ export function ThreadList() {
       const top = Math.round((r?.bottom ?? 48) + 6)
       setPanelBox({
         top,
-        maxHeight: Math.max(180, window.innerHeight - top - 12),
+        maxHeight: Math.max(0, Math.min(window.innerHeight - top - 12, (document.querySelector<HTMLElement>(".cm-composer-dock")?.getBoundingClientRect().top ?? window.innerHeight) - top - 8)),
       })
     }
     place()
     window.addEventListener("resize", place)
-    return () => window.removeEventListener("resize", place)
+    const observer = new ResizeObserver(place)
+    const dock = document.querySelector(".cm-composer-dock")
+    const rail = document.querySelector(".cm-status-rail")
+    if (dock) observer.observe(dock)
+    if (rail) observer.observe(rail)
+    return () => { window.removeEventListener("resize", place); observer.disconnect() }
   }, [open, selectMode, view])
 
+  // Outside actions remain directly usable (not intercepted by a transparent backdrop).
+  useEffect(() => {
+    if (!open) return
+    const outside = (event: MouseEvent) => {
+      const target = event.target as Node
+      if (!historyRef.current?.contains(target) && !triggerRef.current?.contains(target) && !historyMenuRef.current?.contains(target)) {
+        setOpen(false); setMenuOpen(false); exitSelectMode()
+      }
+    }
+    document.addEventListener("mousedown", outside)
+    return () => document.removeEventListener("mousedown", outside)
+  }, [open, exitSelectMode])
+
   // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
   // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
   useEffect(() => {
@@ -875,6 +905,15 @@ export function ThreadList() {
     return () => document.removeEventListener("keydown", key)
   }, [open, !!panelBox])
 
+  const closeMetadataEditor = (threadId = editingThread?.id) => {
+    setEditingThread(null)
+    requestAnimationFrame(() => {
+      const row = threadId ? historyRef.current?.querySelector(`[data-thread-id="${CSS.escape(threadId)}"]`) : null
+      const target = row?.querySelector<HTMLElement>('button[title="编辑标签与分组"]') || historyRef.current?.querySelector<HTMLElement>('input[type="search"]')
+      target?.focus()
+    })
+  }
+
   const renderThreadRow = (t: Thread) => {
     const busy = !!threadBusyById[t.id]
     const isActive = t.id === activeThreadId
@@ -883,7 +922,7 @@ export function ThreadList() {
     const accessibleName = threadAccessibleName(t)
     const idBadge = formatThreadIdBadge(t.id)
     const rel = formatThreadListTime(t, now, aliasDupCount)
-    const tags = t.digest?.tags || []
+    const tags = threadTags(t)
     const extracting = extractingIds.has(t.id)
     const evidence = displayThreadEvidence(t)
     const chip = acpOutcomeChip(t)
@@ -892,6 +931,8 @@ export function ThreadList() {
     return (
       <div
         key={t.id}
+        className={selectMode ? "cm-thread-row cm-thread-selecting" : "cm-thread-row"}
+        data-thread-id={t.id}
         style={{
           ...styles.threadItem,
           background: isActive ? tokens.accentSoft : "transparent",
@@ -911,7 +952,7 @@ export function ThreadList() {
             aria-label={`选择 ${accessibleName}`}
           />
         )}
-        <div style={{ flex: 1, minWidth: 0 }}>
+        <div className="cm-thread-row-content" style={{ flex: 1, minWidth: 0 }}>
           <div style={styles.threadAliasRow}>
             <button type="button" className="cm-thread-open" style={{ ...styles.threadAlias, border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "pointer", padding: "6px 0", minHeight: 32 }} disabled={trashView} aria-label={`${selectMode ? "选择" : trashView ? "已删除" : "打开"} ${accessibleName}`} onClick={e => { e.stopPropagation(); handleSelect(t.id) }}>{title}</button>
             {chip ? <span style={styles.badge}>{chip}</span> : null}
@@ -958,7 +999,7 @@ export function ThreadList() {
                     setActiveTag(tag)
                   }}
                 >
-                  #{tag}
+                  #{tag} <span className="cm-thread-tag-origin">{(t.user_tags || []).some(value => value.toLowerCase() === tag) ? "人工" : "AI"}</span>
                 </button>
               ))}
             </div>
@@ -966,7 +1007,7 @@ export function ThreadList() {
           {rel && <div style={styles.relTime}>{rel}</div>}
           {t.topic_folder ? (
             <div style={styles.relTime} title="话题夹">
-              夹 · {t.topic_folder}
+              分组 · {t.topic_folder}
             </div>
           ) : null}
         </div>
@@ -1007,26 +1048,12 @@ export function ThreadList() {
               style={styles.iconBtn}
               onClick={(e) => {
                 e.stopPropagation()
-                const name = window.prompt("话题夹名称（空则移出）", t.topic_folder || "")
-                if (name === null) return
-                const folder = name
-                  .normalize("NFC")
-                  .replace(/[\x00-\x1F\x7F\\/]/g, "")
-                  .trim()
-                  .slice(0, 40) || null
-                chrome.runtime.sendMessage({
-                  type: "thread.update",
-                  thread_id: t.id,
-                  updates: { topic_folder: folder },
-                })
-                dispatch({
-                  type: "UPSERT_THREAD",
-                  thread: { ...t, topic_folder: folder },
-                })
+                setEditingThread(t)
+                setMetadataNotice("")
               }}
-              title="移入话题夹"
+              title="编辑标签与分组"
             >
-              夹
+              分类
             </button>
             <button
               style={styles.iconBtn}
@@ -1290,17 +1317,18 @@ export function ThreadList() {
     )
   }
 
-  const renderTopicsView = () => {
+  const renderTopicsView = (ai = false) => {
     const groups = new Map<string, Thread[]>()
     for (const t of filtered as Thread[]) {
-      const key = t.topic_folder || "未分组"
+      const key = ai ? aiThreadGroup(t) || "待 AI 整理" : t.topic_folder || "未分组"
       const arr = groups.get(key) || []
       arr.push(t)
       groups.set(key, arr)
     }
     const keys = [...groups.keys()].sort((a, b) => {
-      if (a === "未分组") return 1
-      if (b === "未分组") return -1
+      const ungrouped = ai ? "待 AI 整理" : "未分组"
+      if (a === ungrouped) return 1
+      if (b === ungrouped) return -1
       return a.localeCompare(b, "zh")
     })
     return (
@@ -1317,7 +1345,7 @@ export function ThreadList() {
         ))}
         {keys.length === 1 && keys[0] === "未分组" && filtered.length > 0 && (
           <div style={{ color: tokens.textMuted, fontSize: 11, padding: "8px 12px" }}>
-            点行上的「夹」把会话放进话题夹
+            点对话右侧「分类」编辑标签、选择或新建分组
           </div>
         )}
         {filtered.length === 0 && (
@@ -1334,31 +1362,25 @@ export function ThreadList() {
       <button
         ref={triggerRef}
         type="button"
+        className="cm-thread-manager-trigger"
         style={{
           ...styles.hamburger,
           ...(open ? { color: tokens.text } : null),
         }}
+        disabled={state.pendingSecurityConfirmations.length > 0}
         onClick={() => setOpen(!open)}
-        title="历史对话"
-        aria-label="历史对话"
+        title="对话管理：历史、标签、分组与图谱"
+        aria-label="对话管理（历史对话）"
         aria-expanded={open}
       >
-        <IconHistory size={17} />
+        <IconHistory size={17} /><span>对话管理</span>
       </button>
 
-      {open &&
+      {open && !state.pendingSecurityConfirmations.length &&
         panelBox &&
         typeof document !== "undefined" &&
         createPortal(
         <>
-          <div
-            style={styles.backdrop}
-            onClick={() => {
-              setOpen(false)
-              setMenuOpen(false)
-              if (selectMode) exitSelectMode()
-            }}
-          />
           <div
             ref={historyRef} className="cm-history-panel" role="dialog" aria-label="历史对话列表" aria-modal="false"
             style={{
@@ -1372,9 +1394,9 @@ export function ThreadList() {
               zIndex: 10050,
             }}
           >
-            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>历史对话</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
-            <div style={styles.panelHeader}>
-              <div style={styles.viewToggle}>
+            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>对话管理</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
+            <div className="cm-thread-management-header" style={styles.panelHeader}>
+              <div className="cm-thread-management-views" style={styles.viewToggle}>
                 <button
                   type="button"
                   style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
@@ -1394,8 +1416,9 @@ export function ThreadList() {
                   style={view === "topics" ? styles.viewBtnActive : styles.viewBtn}
                   onClick={() => setView("topics")}
                 >
-                  话题
+                  手动分组
                 </button>
+                <button type="button" style={view === "ai" ? styles.viewBtnActive : styles.viewBtn} onClick={() => setView("ai")}>AI 分组</button>
               </div>
               <div style={{ display: "flex", gap: 6, flexShrink: 0, alignItems: "center" }}>
                 <button
@@ -1436,6 +1459,8 @@ export function ThreadList() {
                           ...styles.menuPortal,
                           top: menuPos.top,
                           right: menuPos.right,
+                          maxHeight: Math.max(0, panelBox.top + panelBox.maxHeight - menuPos.top),
+                          overflowY: "auto",
                         }}
                         ref={historyMenuRef} role="menu"
                       >
@@ -1515,6 +1540,16 @@ export function ThreadList() {
               </div>
             </div>
 
+            <div className="cm-thread-management-actions" aria-label="对话整理工具">
+              <button type="button" onClick={handleExtractUntagged} disabled={untaggedExtract.ids.length === 0 || !!extractProgress}>AI 提取标签</button>
+              <button type="button" onClick={() => { setCleanupOpen(true); runCleanupScan() }}>整理助手</button>
+              <button type="button" onClick={openThreadGraph}>关系图谱</button>
+              <button type="button" onClick={() => trashView ? closeTrashView() : openTrashView()}>{trashView ? "返回对话" : "回收站"}</button>
+            </div>
+            {view === "ai" && <p className="cm-thread-management-help">按 AI 提取的首个主题标签自动分组；重新提取可能调整 AI 分组，不改变手动分组。点击“AI 提取标签”为最多20个未标注对话提取标签。</p>}
+            {view === "tags" && <p className="cm-thread-management-help">汇总人工与 AI 标签；点对话右侧“分类”管理人工标签。</p>}
+            {metadataNotice && <p className="cm-thread-management-help" role="status">{metadataNotice}</p>}
+            {editingThread && <ThreadMetadataEditor key={editingThread.id} thread={editingThread} folders={[...new Set(threads.map(t => t.topic_folder).filter((name): name is string => !!name))]} onClose={() => closeMetadataEditor()} onSaved={thread => { dispatch({ type: "UPSERT_THREAD", thread }); closeMetadataEditor(thread.id); setMetadataNotice("分类已保存") }} />}
             {extractProgress && extractProgress.total > 0 && (
               <div style={styles.progressBar} role="status" aria-live="polite">
                 提取要点 {extractProgress.done}/{extractProgress.total}
@@ -1610,8 +1645,8 @@ export function ThreadList() {
               />
             </div>
 
-            <div style={styles.list}>
-              {view === "time" ? renderTimeline() : view === "tags" ? renderTagsView() : renderTopicsView()}
+            <div className="cm-thread-management-list" style={styles.list}>
+              {view === "time" ? renderTimeline() : view === "tags" ? renderTagsView()  : renderTopicsView(view === "ai")}
             </div>
 
             {selectMode && (
@@ -1818,11 +1853,6 @@ const styles: Record<string, React.CSSProperties> = {
     flexShrink: 0,
     fontFamily: tokens.font,
   },
-  backdrop: {
-    position: "fixed",
-    inset: 0,
-    zIndex: 10040,
-  },
   panel: {
     position: "fixed",
     left: 8,
diff --git a/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx b/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
index 822fdd5d..8f8b832b 100644
--- a/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
+++ b/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
@@ -55,7 +55,7 @@ function WorkspaceNavigation({ onNavigate, onClose }: { onNavigate: () => void;
         dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
       }}><Icon size={16} /><span>{label}</span></button>)}
     </nav>
-    <div className="cm-nav-section"><span>最近对话</span></div>
+    <div className="cm-nav-section"><span>最近对话</span><button type="button" className="cm-nav-manage" disabled={state.pendingSecurityConfirmations.length > 0} onClick={() => { onNavigate(); window.dispatchEvent(new Event("cmspark:open-thread-manager")) }}>管理对话</button></div>
     <input className="cm-nav-search" aria-label="筛选最近对话" placeholder="查找对话…" value={query} onChange={e => setQuery(e.target.value)} />
     <div className="cm-nav-threads">
       {recent.map(thread => <button type="button" className="cm-nav-thread" key={thread.id} aria-current={thread.id === state.activeThreadId ? "page" : undefined}
diff --git a/chrome-extension/src/sidepanel/types.ts b/chrome-extension/src/sidepanel/types.ts
index 2d57db62..3bfd8e23 100644
--- a/chrome-extension/src/sidepanel/types.ts
+++ b/chrome-extension/src/sidepanel/types.ts
@@ -76,6 +76,7 @@ export interface Thread {
   } | null
   /** Wave 2 话题夹 — not Project */
   topic_folder?: string | null
+  user_tags?: string[]
   /** P1: short searchable index from extract_digest */
   digest?: {
     extracted_at?: string
diff --git a/chrome-extension/src/sidepanel/ui/workspace-styles.ts b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
index cb9edf1e..77f1dcb3 100644
--- a/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -72,4 +72,22 @@ export const workspaceCSS = `
 .cm-settings-body input,.cm-settings-body select,.cm-settings-body textarea{max-width:100%;box-sizing:border-box}
 @media(max-width:759px){.cm-settings-panel{height:94dvh;max-height:94dvh!important;width:100%!important}.cm-settings-layout{flex-direction:column}.cm-settings-nav{display:none}.cm-settings-mobile-category{display:flex;align-items:center;gap:12px;padding:10px 16px;background:${tokens.bgMuted};border-bottom:1px solid ${tokens.border};font-size:12px;color:${tokens.textSecondary}}.cm-settings-mobile-category select{flex:1;min-width:0;min-height:36px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;background:${tokens.bg};color:${tokens.text};font:inherit}.cm-settings-layout .cm-settings-body{padding:16px!important}.cm-settings-status{padding:0 16px 8px}.cm-settings-page-heading h3{font-size:18px}.cm-settings-footer{padding:10px 16px!important}}
 .cm-settings-body input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),.cm-settings-body select{min-height:36px}
+
+.cm-header-new{display:none;font-size:24px}
+.cm-nav-manage{border:0;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:12px;padding:6px;cursor:pointer}
+.cm-thread-manager-trigger{width:auto!important;gap:5px;padding:0 5px;font-size:12px;white-space:nowrap}
+.cm-history-panel{display:block!important;overflow-y:auto!important;overscroll-behavior:contain}
+.cm-thread-management-header{flex-wrap:wrap}
+.cm-thread-management-views{flex-wrap:wrap}
+.cm-thread-management-list{overflow:visible!important;max-height:none!important}
+.cm-thread-management-actions{display:flex;gap:6px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid ${tokens.border}}
+.cm-thread-management-actions button,.cm-thread-editor button{font:inherit;font-size:12px;min-height:32px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 9px;background:${tokens.bgMuted};color:${tokens.text};cursor:pointer}
+.cm-thread-management-actions button:disabled,.cm-thread-editor button:disabled{opacity:.5;cursor:not-allowed}
+.cm-thread-management-help{font-size:12px;line-height:1.6;color:${tokens.textSecondary};padding:0 12px}
+.cm-thread-editor{padding:16px;display:flex;flex-direction:column;gap:10px;border-bottom:1px solid ${tokens.border};background:${tokens.bgMuted}}
+.cm-thread-editor label{display:flex;flex-direction:column;gap:6px;font-size:12px}.cm-thread-editor input{box-sizing:border-box;width:100%;min-width:0;border:1px solid ${tokens.border};border-radius:8px;padding:8px;font:inherit;background:${tokens.bg}}
+.cm-thread-editor p{font-size:12px;line-height:1.5;margin:0;color:${tokens.textSecondary};overflow-wrap:anywhere}.cm-thread-editor [role="alert"]{color:${tokens.danger}}.cm-thread-editor-actions{display:flex;justify-content:flex-end;gap:8px}
+@media(max-width:759px){.cm-header-new{display:inline-flex;flex-shrink:0}.cm-status-rail{flex-wrap:wrap}.cm-thread-manager-trigger{min-height:32px}.cm-thread-management-header{align-items:flex-start!important}}
+@media(max-width:520px){.cm-thread-row{flex-wrap:wrap}.cm-thread-row:not(.cm-thread-selecting) .cm-thread-row-content{flex-basis:100%!important}.cm-rail-brand{display:none}}
+.cm-thread-tag-origin{font-size:10px;opacity:.8}
 `
diff --git a/chrome-extension/src/sidepanel/utils/thread-related.ts b/chrome-extension/src/sidepanel/utils/thread-related.ts
index 47a0c491..c20418a8 100644
--- a/chrome-extension/src/sidepanel/utils/thread-related.ts
+++ b/chrome-extension/src/sidepanel/utils/thread-related.ts
@@ -9,6 +9,7 @@ export const RELATED_TF_MIN = 0.08
 export const RELATED_TIME_WINDOW_DAYS = 7
 
 export interface RelatedThreadInput {
+  user_tags?: string[]
   id: string
   alias?: string
   updated_at?: string
@@ -94,7 +95,7 @@ function cosineSimilarity(a: Record<string, number>, b: Record<string, number>):
 }
 
 function tagSet(t: RelatedThreadInput): Set<string> {
-  const tags = t.digest?.tags
+  const tags = [...(t.user_tags || []), ...(t.digest?.tags || [])]
   if (!Array.isArray(tags)) return new Set()
   return new Set(tags.map((x) => String(x).toLowerCase()).filter(Boolean))
 }
diff --git a/chrome-extension/src/sidepanel/utils/thread-timeline.ts b/chrome-extension/src/sidepanel/utils/thread-timeline.ts
index ac24e435..b220fc4e 100644
--- a/chrome-extension/src/sidepanel/utils/thread-timeline.ts
+++ b/chrome-extension/src/sidepanel/utils/thread-timeline.ts
@@ -1,3 +1,4 @@
+import { threadTags } from "./thread-management"
 // Thread History IA — calendar grouping + filter helpers (pure).
 // Spec: docs/superpowers/specs/2026-08-06-thread-history-ia-product-design.md
 
@@ -9,6 +10,7 @@ export type AcpListMeta = {
 
 export type TimelineThread = {
   id: string
+  user_tags?: string[]
   alias?: string
   created_at?: string
   updated_at?: string
@@ -269,7 +271,7 @@ export function filterThreadsByQuery(
     const alias = (t.alias || "").toLowerCase()
     const id = (t.id || "").toLowerCase()
     const preview = (t.first_user_preview || "").toLowerCase()
-    const tags = (t.digest?.tags || []).join(" ").toLowerCase()
+    const tags = threadTags(t).join(" ").toLowerCase()
     const tldr = (t.digest?.tldr || "").toLowerCase()
     const bullets = (t.digest?.bullets || []).join(" ").toLowerCase()
     const goal = (t.acp_list?.goal_preview || "").toLowerCase()
@@ -458,7 +460,7 @@ export function buildTagIndex(
 ): Map<string, TimelineThread[]> {
   const map = new Map<string, TimelineThread[]>()
   for (const t of threads) {
-    const tags = t.digest?.tags
+    const tags = threadTags(t)
     if (!tags || tags.length === 0) {
       const list = map.get("__untagged__") || []
       list.push(t)
@@ -678,7 +680,7 @@ export function selectLazyDigestCandidates(
 /** Show digest stale badge: tags/topics always; time view only non-today (B-3). */
 export function showDigestStaleBadge(
   t: TimelineThread,
-  view: "time" | "tags" | "topics",
+  view: "time" | "tags" | "topics" | "ai",
   now: Date = new Date(),
 ): boolean {
   if (!t.digest?.stale) return false
diff --git a/chrome-extension/src/thread-graph/ThreadGraphApp.tsx b/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
index 41594b1d..b471c85f 100644
--- a/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
+++ b/chrome-extension/src/thread-graph/ThreadGraphApp.tsx
@@ -1,3 +1,4 @@
+import { threadTags, aiThreadGroup } from "../sidepanel/utils/thread-management"
 // Full-page Obsidian-like thread graph.
 // Spec: docs/superpowers/specs/2026-08-11-thread-graph-obsidian-view-design.md
 // v1.1+: tag colors · hover labels · floating chrome · nit closeout
@@ -68,8 +69,8 @@ function radiusForDegree(deg: number): number {
 }
 
 function isUntaggedSlim(t: ThreadGraphSlim): boolean {
-  const tags = t.digest?.tags
-  return !tags || tags.length === 0
+  // Extraction eligibility is AI-only; human labels do not replace a digest.
+  return !aiThreadGroup(t)
 }
 
 export function ThreadGraphApp() {
@@ -216,7 +217,7 @@ export function ThreadGraphApp() {
         const t = threads.find((x) => x.id === id)
         if (!t) return false
         const title = displayTitle(t).toLowerCase()
-        const tags = (t.digest?.tags || []).join(" ").toLowerCase()
+        const tags = threadTags(t).join(" ").toLowerCase()
         return title.includes(q) || tags.includes(q) || id.toLowerCase().includes(q)
       })
     }
@@ -865,6 +866,7 @@ export function ThreadGraphApp() {
                 >
                   {displayTitle(focusThread)}
                 </div>
+                {!!focusThread.user_tags?.length && <div style={styles.tags}>人工标签：{focusThread.user_tags.join("、")}</div>}
                 {(focusThread.digest?.tags || []).length > 0 && (
                   <div style={styles.tags}>
                     {(focusThread.digest?.tags || []).map((tg) => {
diff --git a/chrome-extension/tests/thread-graph-bg.test.ts b/chrome-extension/tests/thread-graph-bg.test.ts
index c4f3fe1e..f533619e 100644
--- a/chrome-extension/tests/thread-graph-bg.test.ts
+++ b/chrome-extension/tests/thread-graph-bg.test.ts
@@ -31,6 +31,7 @@ test("slimThreadGraphRow drops unknown keys / message bodies", () => {
   const slim = slimThreadGraphRow({
     id: "t1",
     alias: "hello",
+    user_tags: ["人工", 7],
     workspace_root: "/secret",
     first_user_preview: "should not leak",
     messages: [{ role: "user", content: "nope" }],
@@ -50,6 +51,7 @@ test("slimThreadGraphRow drops unknown keys / message bodies", () => {
   assert.equal((slim as any).first_user_preview, undefined)
   assert.equal((slim as any).messages, undefined)
   assert.deepEqual(slim!.digest?.tags, ["a", "b"])
+  assert.deepEqual(slim!.user_tags, ["人工"])
   assert.equal((slim!.digest as any).secret_field, undefined)
   assert.equal(slim!.digest?.stale, true)
   assert.equal(slimThreadGraphRow({}), null)
diff --git a/companion/src/message-router.ts b/companion/src/message-router.ts
index e4da2cbd..4cd89b94 100644
--- a/companion/src/message-router.ts
+++ b/companion/src/message-router.ts
@@ -3000,6 +3000,7 @@ export async function handleMessage(
         "active_mcp_server_ids",
         "digest",
         "topic_folder",
+        "user_tags",
       ]) {
         if (Object.prototype.hasOwnProperty.call(updates, key)) {
           allowedUpdates[key] = updates[key]
diff --git a/companion/src/threads/related.ts b/companion/src/threads/related.ts
index aca3acbb..0131d02a 100644
--- a/companion/src/threads/related.ts
+++ b/companion/src/threads/related.ts
@@ -14,6 +14,7 @@ export const RELATED_TF_MIN = 0.08
 export const RELATED_TIME_WINDOW_DAYS = 7
 
 export interface RelatedThreadInput {
+  user_tags?: string[]
   id: string
   alias?: string
   updated_at?: string
@@ -36,7 +37,7 @@ export interface RelatedHit {
 }
 
 function tagSet(t: RelatedThreadInput): Set<string> {
-  const tags = t.digest?.tags
+  const tags = [...(t.user_tags || []), ...(t.digest?.tags || [])]
   if (!Array.isArray(tags)) return new Set()
   return new Set(tags.map((x) => String(x).toLowerCase()).filter(Boolean))
 }
diff --git a/companion/src/threads/thread-manager.ts b/companion/src/threads/thread-manager.ts
index 1719a11a..3de392e3 100644
--- a/companion/src/threads/thread-manager.ts
+++ b/companion/src/threads/thread-manager.ts
@@ -7,6 +7,7 @@ import { atomicWriteJSON } from "../io"
 import type { MissionBoard } from "../board/schema"
 import type { ThreadDigest } from "./digest"
 import { isDigestStale, sanitizeDigest } from "./digest"
+import { sanitizeUserTags } from "./user-tags"
 import { sanitizeTopicFolder } from "./distill"
 import { inspectThreadMessages } from "./thread-inspect"
 import {
@@ -147,6 +148,7 @@ interface Thread {
   trashed_at?: string | null
   /** Wave 2 话题夹 — user folder label, not Project/Pack. */
   topic_folder?: string | null
+  user_tags?: string[]
 }
 
 // Allowed config_override keys and their expected types
@@ -897,6 +899,9 @@ export class ThreadManager {
     if (updates.alias !== undefined) {
       updates = { ...updates, alias: this.sanitizeAlias(String(updates.alias)) }
     }
+    if (updates.user_tags !== undefined) {
+      updates = { ...updates, user_tags: sanitizeUserTags(updates.user_tags) }
+    }
     if (updates.topic_folder !== undefined) {
       updates = { ...updates, topic_folder: sanitizeTopicFolder(updates.topic_folder) }
     }
diff --git a/companion/tests/thread-digest.test.ts b/companion/tests/thread-digest.test.ts
index e2cf3de0..32129956 100644
--- a/companion/tests/thread-digest.test.ts
+++ b/companion/tests/thread-digest.test.ts
@@ -208,3 +208,34 @@ test("listWithPreviews single-pass marks digest stale without second API", () =>
   assert.match(row!.first_user_preview, /hello/)
   assert.equal((row!.digest as any)?.stale, true)
 })
+
+test("human tags persist independently when AI digest is replaced, including after reload", async () => {
+  const manager = new ThreadManager()
+  const thread = manager.create("human classifications")
+  const result = await handleMessage({ type: "thread.update", thread_id: thread.id, updates: { user_tags: [" 支付 ", "PAY", "pay"], topic_folder: "发布" } } as any, { threadManager: manager, skillEngine: {} as any, historyStore: {} as any }, { sendToExtension: () => {}, executeTool: async () => ({ success: true }), broadcast: () => {} } as any)
+  assert.equal(result.type, "thread.updated")
+  assert.deepEqual((result as any).thread.user_tags, ["支付", "PAY"])
+  assert.equal((result as any).thread.topic_folder, "发布")
+  assert.deepEqual(manager.get(thread.id)?.user_tags, ["支付", "PAY"])
+  manager.update(thread.id, { digest: { extracted_at: new Date().toISOString(), content_fingerprint: "0:empty", tldr: "AI result", tags: ["模型建议"], source: "manual" } })
+  const persisted = new ThreadManager().get(thread.id)
+  assert.deepEqual(persisted?.user_tags, ["支付", "PAY"])
+  assert.equal(persisted?.topic_folder, "发布")
+  assert.deepEqual(persisted?.digest?.tags, ["模型建议"])
+  manager.update(thread.id, { user_tags: [], topic_folder: null })
+  const cleared = new ThreadManager().get(thread.id)
+  assert.deepEqual(cleared?.user_tags, [])
+  assert.equal(cleared?.topic_folder, null)
+  assert.deepEqual(cleared?.digest?.tags, ["模型建议"])
+})
+
+test("human tag writes reject malformed and oversized inputs without overwriting existing labels", () => {
+  const manager = new ThreadManager();const thread=manager.create("guard tags")
+  manager.update(thread.id,{user_tags:["keep"]})
+  for (const value of [null, "not-array", [42], Array(21).fill("tag")]) {
+    assert.throws(()=>manager.update(thread.id,{user_tags:value as any}),/user_tags/)
+    assert.deepEqual(manager.get(thread.id)?.user_tags,["keep"])
+  }
+  manager.update(thread.id,{user_tags:["a\u0000b", "", "x".repeat(50)]})
+  assert.deepEqual(manager.get(thread.id)?.user_tags,["ab", "x".repeat(40)])
+})
diff --git a/docs/TESTING.md b/docs/TESTING.md
index 0a0ca046..804b19e1 100644
--- a/docs/TESTING.md
+++ b/docs/TESTING.md
@@ -188,3 +188,7 @@ uv run --no-project --with playwright python companion/scripts/test-web-surfaces
 ## #471 设置与召唤器交互
 
 在 `nvm use 22` 后，从仓库根运行 `uv run --no-project --with playwright python chrome-extension/scripts/test-settings-pages-ui.py` 与 `uv run --no-project --with playwright python companion/scripts/test-summoner-workspace-ui.py`。使用本机 Chrome headless、真实 React/HTML 和隔离传输，覆盖四档宽度、分类草稿与深链、语音迟到回调取消、隐藏快捷键录制、许可焦点隔离及召唤器输入操作顺序；不会改写已安装程序或真实配置。
+
+## #473 对话管理
+
+`uv run --no-project --with playwright python chrome-extension/scripts/test-thread-management-ui.py`（先 `nvm use 22`）验证真实 App 在320/390/759/760/1440宽度的创建/管理入口、手动分类保存与拒绝、AI标签保留、AI提取/规则整理/图谱调用，以及320短屏下停止/风险/确认优先级。运行时传输为隔离 fixture，不连接真实 Companion。后端 `thread-digest.test.ts` 验证分类字段通过真实路由写入、AI digest 替换后 reload 仍保留、非法输入拒绝；扩展 `thread-management.test.ts` 验证 ACK/错请求/未回显字段不构成保存成功。
diff --git a/docs/workspace-ui.md b/docs/workspace-ui.md
index ea4aab29..801339df 100644
--- a/docs/workspace-ui.md
+++ b/docs/workspace-ui.md
@@ -2,8 +2,8 @@
 
 CMspark 的主界面围绕当前对话展开。宽屏左侧显示最近对话、资源和设置；在浏览器窄侧栏中，点击顶栏「导航」展开这些入口。导航展开时仍能操作当前任务的确认和停止按钮。
 
-- **新对话**：在导航中创建空白对话。输入内容后再发送；空白页建议只填入输入框。
-- **最近对话**：按最后消息时间排列，可以筛选标题。顶栏「历史对话」保留完整检索、分组、回收站和批量操作。
+- **新对话**：窄侧栏从顶栏“+”创建，宽屏从左侧导航创建空白对话。输入内容后再发送；空白页建议只填入输入框。
+- **最近对话**：按最后消息时间排列，可以筛选标题。点击最近对话旁“管理对话”或顶栏“对话管理”，进入完整检索、分组、回收站和批量操作。
 - **资源**：标签、技能、知识、场景与专家、会议、任务板、MCP 和应用使用原有面板。点击「收起面板」返回完整对话空间。
 - **设置**：宽屏左侧导航、窄屏下拉选择分类；模型与推理、输入与语音、文件与知识、连接与配对、安全与信任、本机与工具、密钥与环境和实验功能各自成页，切换保留草稿。公共“保存并关闭”提交配置草稿；密钥、授权、模型下载等仍需各自提交。设置打开时收起辅助面板。
 - **输入与执行**：输入区在上，附件、语音和发送操作在下。运行中的停止、纠偏与排队沿用原有含义。
@@ -14,3 +14,9 @@ CMspark 的主界面围绕当前对话展开。宽屏左侧显示最近对话、
 本轮覆盖扩展网页、终端、确认台、图谱和 Companion 辅助网页。原生 macOS/Windows 窗口另行平台验证；当前开发改动不会自动替换已安装程序。
 
 召唤器采用同样的浅色聊天布局，删除装饰性“山”标识。输入框下依次为附件、听写、发送，历史与新对话保留在页头。“用一句话调整设置”展开后可输入或说出设置命令，折叠会取消尚未结束的语音输入。
+
+对话管理包含“时间”“标签”“手动分组”“AI 分组”。对话行的“分类”可编辑人工标签、选择/新建手动分组或留空移出；人工标签与只读 AI 标签独立保存。AI 分组根据 AI 标签的首项动态显示，重新提取可能改变 AI 归组，不会覆盖手动分组。点击“AI 提取标签”每次处理最多20个未标注对话；完成后可再次处理剩余。
+
+“整理助手”是规则扫描，供核对后提取要点或移入回收站；“关系图谱”打开原有会话关系图。管理面板不会阻挡运行中的停止按钮，待确认操作到达时会自动收起。分类保存需收到服务端确认；如果旧 Companion 未支持人工标签，会提示更新，不会显示假成功。
+
+标签视图的“未标注”表示人工和 AI 标签均为空；图谱的“为未标注提取要点”仅检查 AI 标签，只有人工标签的对话仍可提取。


### FULL companion/tests/thread-digest.test.ts

/**
 * Thread History IA — digest normalize + batch_auto_title (no live LLM).
 */
import "./_threads-history-setup.js"
import test, { after, before, beforeEach } from "node:test"
import assert from "node:assert/strict"
import * as fs from "node:fs"
import * as path from "node:path"

let ThreadManager: typeof import("../src/threads/thread-manager").ThreadManager
let getConfigDir: typeof import("../src/config").getConfigDir
let initDataDir: typeof import("../src/config").initDataDir
let handleMessage: typeof import("../src/message-router").handleMessage
let normalizeTag: typeof import("../src/threads/digest").normalizeTag
let normalizeTags: typeof import("../src/threads/digest").normalizeTags
let contentFingerprint: typeof import("../src/threads/digest").contentFingerprint
let aliasFromFirstUserText: typeof import("../src/threads/digest").aliasFromFirstUserText
let isDigestStale: typeof import("../src/threads/digest").isDigestStale
let sanitizeDigest: typeof import("../src/threads/digest").sanitizeDigest

before(async () => {
  const configMod = await import("../src/config")
  getConfigDir = configMod.getConfigDir
  initDataDir = configMod.initDataDir
  await initDataDir()

  ThreadManager = (await import("../src/threads/thread-manager")).ThreadManager
  handleMessage = (await import("../src/message-router")).handleMessage
  const dig = await import("../src/threads/digest")
  normalizeTag = dig.normalizeTag
  normalizeTags = dig.normalizeTags
  contentFingerprint = dig.contentFingerprint
  aliasFromFirstUserText = dig.aliasFromFirstUserText
  isDigestStale = dig.isDigestStale
  sanitizeDigest = dig.sanitizeDigest
})

after(() => {
  /* setup tmp cleaned on process exit */
})

beforeEach(() => {
  const threadsDir = path.join(getConfigDir(), "threads")
  if (fs.existsSync(threadsDir)) {
    for (const f of fs.readdirSync(threadsDir)) {
      try {
        fs.rmSync(path.join(threadsDir, f), { recursive: true, force: true })
      } catch {
        /* ignore */
      }
    }
  }
})

test("normalizeTag: lower, strip #, reject secrets", () => {
  assert.equal(normalizeTag("#竞品"), "竞品")
  assert.equal(normalizeTag("  Alpha  "), "alpha")
  assert.equal(normalizeTag("sk-abc123secret"), null)
  assert.equal(normalizeTag("api_key"), null)
  assert.equal(normalizeTag("bearer token-ish"), null)
  assert.equal(normalizeTag(""), null)
})

test("normalizeTags: dedupe + max 8", () => {
  const tags = normalizeTags(["A", "a", "B", "c", "d", "e", "f", "g", "h", "i", "j"])
  assert.equal(tags.length, 8)
  assert.deepEqual(tags.slice(0, 2), ["a", "b"])
})

test("contentFingerprint pin", () => {
  assert.equal(contentFingerprint([]), "0:empty")
  assert.equal(
    contentFingerprint([
      { id: "m1", role: "user" },
      { id: "m2", role: "assistant" },
    ]),
    "2:m2",
  )
})

test("isDigestStale", () => {
  const msgs = [{ id: "a", role: "user", content: "hi" }]
  const dig = {
    extracted_at: "2026-01-01T00:00:00.000Z",
    content_fingerprint: "1:a",
    tldr: "x",
    tags: [],
    source: "manual" as const,
  }
  assert.equal(isDigestStale(dig, msgs), false)
  assert.equal(isDigestStale(dig, [...msgs, { id: "b", role: "assistant", content: "y" }]), true)
})

test("sanitizeDigest clamps fields", () => {
  const d = sanitizeDigest({
    tldr: "x".repeat(200),
    tags: ["#OK", "sk-bad"],
    bullets: ["one", "two"],
    content_fingerprint: "1:x",
    source: "manual",
  })
  assert.ok(d)
  assert.ok(d!.tldr.length <= 120)
  assert.deepEqual(d!.tags, ["ok"])
  assert.deepEqual(d!.bullets, ["one", "two"])
})

test("aliasFromFirstUserText", () => {
  assert.equal(aliasFromFirstUserText("帮我对比定价"), "对比定价")
})

test("batch_auto_title fills empty aliases from first user message", async () => {
  const tm = new ThreadManager()
  const a = tm.create("", "ta")
  tm.addMessage(a.id, { thread_id: a.id, role: "user", content: "帮我写一份竞品分析大纲" })
  const b = tm.create("已有标题", "tb")
  tm.addMessage(b.id, { thread_id: b.id, role: "user", content: "不会被覆盖" })
  const c = tm.create("", "tc") // no messages

  const broadcasts: any[] = []
  const resp = await handleMessage(
    { type: "thread.batch_auto_title", only_empty: true },
    { threadManager: tm, skillEngine: {} as any, historyStore: {} as any },
    {
      sendToExtension: () => {},
      executeTool: async () => ({ success: true }),
      broadcast: (m: any) => broadcasts.push(m),
    } as any,
  )

  assert.equal(resp.type, "thread.batch_auto_title.completed")
  assert.equal(resp.updated_count, 1)
  assert.equal(tm.get("ta")?.alias.includes("竞品") || tm.get("ta")?.alias.includes("分析"), true)
  assert.equal(tm.get("tb")?.alias, "已有标题")
  assert.equal(tm.get("tc")?.alias, "")
  assert.ok(broadcasts.some((m) => m.type === "thread.updated" && m.thread?.id === "ta"))
})

test("thread update persists digest on index", () => {
  const tm = new ThreadManager()
  const t = tm.create("D", "td")
  const next = tm.update(t.id, {
    digest: {
      extracted_at: "2026-08-06T00:00:00.000Z",
      content_fingerprint: "0:empty",
      tldr: "摘要",
      tags: ["测试", "Digest"],
      source: "manual",
    },
  })
  assert.ok(next?.digest)
  assert.deepEqual(next!.digest!.tags, ["测试", "digest"])
  const reloaded = new ThreadManager().get("td")
  assert.equal(reloaded?.digest?.tldr, "摘要")
})

test("saveIndex merges peer digests so stale process cannot wipe tags", () => {
  // Process A: write digest
  const a = new ThreadManager()
  const t = a.create("peer", "peer1")
  a.update(t.id, {
    digest: {
      extracted_at: "2026-08-08T00:00:00.000Z",
      content_fingerprint: "0:empty",
      tldr: "peer-tldr",
      tags: ["标签甲", "标签乙"],
      source: "manual",
    },
  })
  assert.ok(a.get("peer1")?.digest?.tags?.length)

  // Process B: loaded before digests existed — only has alias/messages, then saveIndex
  // Simulate by constructing a manager that shares the same data dir but drops digest in memory.
  const b = new ThreadManager()
  const row = b.get("peer1")
  assert.ok(row)
  // Stale in-memory wipe: clear digest on the object without going through update(null)
  delete (row as { digest?: unknown }).digest
  assert.equal(b.get("peer1")?.digest, undefined)
  // Any index write (e.g. addMessage / alias bump) must not erase disk digests
  b.update("peer1", { alias: "peer-renamed" })
  const after = b.get("peer1")
  assert.equal(after?.alias, "peer-renamed")
  assert.ok(after?.digest, "digest restored from disk on save")
  assert.deepEqual(after!.digest!.tags, ["标签甲", "标签乙"])

  // Fresh process still sees tags
  const c = new ThreadManager()
  assert.deepEqual(c.get("peer1")?.digest?.tags, ["标签甲", "标签乙"])
})

test("listWithPreviews single-pass marks digest stale without second API", () => {
  const tm = new ThreadManager()
  const t = tm.create("S", "stale1")
  tm.addMessage(t.id, { thread_id: t.id, role: "user", content: "hello world preview" })
  tm.update(t.id, {
    digest: {
      extracted_at: "2026-01-01T00:00:00.000Z",
      content_fingerprint: "0:empty", // wrong on purpose
      tldr: "old",
      tags: ["x"],
      source: "manual",
    },
  })
  const list = tm.listWithPreviews()
  const row = list.find((x) => x.id === "stale1")
  assert.ok(row)
  assert.match(row!.first_user_preview, /hello/)
  assert.equal((row!.digest as any)?.stale, true)
})

test("human tags persist independently when AI digest is replaced, including after reload", async () => {
  const manager = new ThreadManager()
  const thread = manager.create("human classifications")
  const result = await handleMessage({ type: "thread.update", thread_id: thread.id, updates: { user_tags: [" 支付 ", "PAY", "pay"], topic_folder: "发布" } } as any, { threadManager: manager, skillEngine: {} as any, historyStore: {} as any }, { sendToExtension: () => {}, executeTool: async () => ({ success: true }), broadcast: () => {} } as any)
  assert.equal(result.type, "thread.updated")
  assert.deepEqual((result as any).thread.user_tags, ["支付", "PAY"])
  assert.equal((result as any).thread.topic_folder, "发布")
  assert.deepEqual(manager.get(thread.id)?.user_tags, ["支付", "PAY"])
  manager.update(thread.id, { digest: { extracted_at: new Date().toISOString(), content_fingerprint: "0:empty", tldr: "AI result", tags: ["模型建议"], source: "manual" } })
  const persisted = new ThreadManager().get(thread.id)
  assert.deepEqual(persisted?.user_tags, ["支付", "PAY"])
  assert.equal(persisted?.topic_folder, "发布")
  assert.deepEqual(persisted?.digest?.tags, ["模型建议"])
  manager.update(thread.id, { user_tags: [], topic_folder: null })
  const cleared = new ThreadManager().get(thread.id)
  assert.deepEqual(cleared?.user_tags, [])
  assert.equal(cleared?.topic_folder, null)
  assert.deepEqual(cleared?.digest?.tags, ["模型建议"])
})

test("human tag writes reject malformed and oversized inputs without overwriting existing labels", () => {
  const manager = new ThreadManager();const thread=manager.create("guard tags")
  manager.update(thread.id,{user_tags:["keep"]})
  for (const value of [null, "not-array", [42], Array(21).fill("tag")]) {
    assert.throws(()=>manager.update(thread.id,{user_tags:value as any}),/user_tags/)
    assert.deepEqual(manager.get(thread.id)?.user_tags,["keep"])
  }
  manager.update(thread.id,{user_tags:["a\u0000b", "", "x".repeat(50)]})
  assert.deepEqual(manager.get(thread.id)?.user_tags,["ab", "x".repeat(40)])
})


### FULL chrome-extension/src/sidepanel/components/ThreadMetadataEditor.tsx

import { useEffect, useRef, useState } from "react"
import type { Thread } from "../types"
import { saveThreadMetadata } from "../utils/thread-management"

export function ThreadMetadataEditor({ thread, folders, onSaved, onClose }: {
  thread: Thread; folders: string[]; onSaved: (thread: Thread) => void; onClose: () => void
}) {
  const [tags, setTags] = useState((thread.user_tags || []).join("，"))
  const [folder, setFolder] = useState(thread.topic_folder || "")
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const controller = useRef<AbortController | null>(null)
  const firstInput = useRef<HTMLInputElement>(null)
  useEffect(() => { firstInput.current?.focus(); return () => controller.current?.abort() }, [])
  return <form className="cm-thread-editor" aria-label="编辑对话分类" onSubmit={async event => {
    event.preventDefault()
    if (controller.current) return
    const userTags = tags.split(/[,，\n]/).map(tag => tag.normalize("NFC").replace(/[\x00-\x1f\x7f]/g, "").replace(/\s+/g, " ").trim()).filter(Boolean)
    if (userTags.length > 20 || userTags.some(tag => tag.length > 40)) { setError("最多20个标签，每个不超过40字"); return }
    const request = new AbortController()
    controller.current = request
    setSaving(true); setError("")
    try {
      const saved = await saveThreadMetadata(thread.id, { user_tags: userTags, topic_folder: folder.normalize("NFC").replace(/[\x00-\x1F\x7F\\/]/g, "").trim() || null }, request.signal)
      if (!request.signal.aborted) onSaved(saved)
    } catch (error) {
      if (!request.signal.aborted) setError(error instanceof Error ? error.message : "保存失败")
    } finally {
      controller.current = null
      if (!request.signal.aborted) setSaving(false)
    }
  }}>
    <strong>编辑标签与分组</strong>
    <label>人工标签<input ref={firstInput} value={tags} onChange={event => setTags(event.target.value)} disabled={saving} placeholder="用逗号分隔，例如：支付，待跟进" /></label>
    <p>人工标签单独保存，不会被 AI 提取覆盖。AI 标签：{thread.digest?.tags?.join("、") || "尚未提取"}（只读）</p>
    <label>手动分组<input list="cm-thread-folders" value={folder} onChange={event => setFolder(event.target.value)} disabled={saving} maxLength={40} placeholder="选择已有分组或输入新名称；留空移出" /></label>
    <datalist id="cm-thread-folders">{folders.map(name => <option key={name} value={name} />)}</datalist>
    {error && <p role="alert">{error}</p>}
    <div className="cm-thread-editor-actions"><button type="button" onClick={onClose} disabled={saving}>取消</button><button type="submit" disabled={saving}>{saving ? "等待保存确认…" : "保存分类"}</button></div>
  </form>
}


### FULL chrome-extension/src/sidepanel/utils/thread-management.ts

type TaggedThread = { user_tags?: string[]; digest?: { tags?: string[] } | null }

export function threadTags(thread: TaggedThread): string[] {
  return [...new Set([...(thread.user_tags || []), ...(thread.digest?.tags || [])]
    .filter(tag => typeof tag === "string" && tag.trim()).map(tag => tag.trim().toLowerCase()))]
}

/** A derived AI view; never writes or overrides a user's manual folder. */
export function aiThreadGroup(thread: TaggedThread): string | null {
  return thread.digest?.tags?.find(tag => typeof tag === "string" && tag.trim())?.trim().toLowerCase() || null
}

/** Wait for the server's persisted response, not the service worker transport ACK. */
export function saveThreadMetadata(threadId: string, updates: { user_tags: string[]; topic_folder: string | null }, signal: AbortSignal): Promise<any> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(new Error("已取消等待")); return }
    const id = `thread-metadata-${crypto.randomUUID()}`
    let timer: ReturnType<typeof setTimeout>
    let settled = false
    const finish = (error?: Error, thread?: any) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      chrome.runtime.onMessage.removeListener(receive)
      signal.removeEventListener("abort", cancel)
      if (error) reject(error)
      else resolve(thread)
    }
    const cancel = () => finish(new Error("已取消等待；已发送的保存可能仍会完成"))
    const receive = (message: any) => {
      if (message?.id !== id) return
      if (message.type === "thread.updated" && message.thread?.id === threadId) {
        const actualTags = threadTags({ user_tags: message.thread.user_tags }).sort()
        const wantedTags = threadTags({ user_tags: updates.user_tags }).sort()
        if (JSON.stringify(actualTags) !== JSON.stringify(wantedTags) || (message.thread.topic_folder || null) !== updates.topic_folder) {
          finish(new Error("服务端未确认所提交的分类，请确认 Companion 已更新后重试"))
        } else finish(undefined, message.thread)
      }
      else if (message.type === "error") finish(new Error(message.error || "保存失败"))
    }
    chrome.runtime.onMessage.addListener(receive)
    signal.addEventListener("abort", cancel, { once: true })
    timer = setTimeout(() => finish(new Error("尚未收到保存确认，请检查连接后重试")), 15_000)
    chrome.runtime.sendMessage({ type: "thread.update", id, thread_id: threadId, updates, require_connected: true }).then(response => {
      if (response?.ok === false) finish(new Error(response.error || "连接不可用"))
    }).catch(error => finish(new Error(error?.message || "发送失败")))
  })
}


### FULL companion/src/threads/user-tags.ts

/** Human labels are independent of the rebuildable AI digest. */
export function sanitizeUserTags(value: unknown): string[] {
  if (!Array.isArray(value) || value.length > 20 || value.some(tag => typeof tag !== "string")) {
    throw new Error("user_tags must be an array of at most 20 strings")
  }
  const seen = new Set<string>()
  return value.map(tag => tag.normalize("NFC").replace(/[\x00-\x1f\x7f]/g, "").replace(/\s+/g, " ").trim().slice(0, 40))
    .filter(tag => {
      const key = tag.toLowerCase()
      if (!key || seen.has(key)) return false
      seen.add(key)
      return true
    })
}


### FULL chrome-extension/tests/thread-management.test.ts

import test from "node:test"
import assert from "node:assert/strict"
import { threadTags, aiThreadGroup, saveThreadMetadata } from "../src/sidepanel/utils/thread-management"
import { buildTagColorIndex, UNTAGGED_COLOR } from "../src/thread-graph/tag-colors"
import { buildTagIndex, filterThreadsByQuery } from "../src/sidepanel/utils/thread-timeline"

test("human labels join AI labels for search while AI grouping never uses manual labels or folder", () => {
  const thread = { id: "one", user_tags: ["Owner", "PAY"], topic_folder: "My folder", digest: { tags: ["pay", "AI"] } }
  assert.deepEqual(threadTags(thread), ["owner", "pay", "ai"])
  assert.equal(buildTagIndex([thread]).get("pay")?.length, 1)
  assert.equal(filterThreadsByQuery([thread], "owner").length, 1)
  assert.equal(aiThreadGroup(thread), "pay")
  assert.equal(aiThreadGroup({user_tags:["Human"]}), null)
  assert.equal(thread.topic_folder, "My folder")
})

test("metadata save waits for matching persisted reply, ignores ACK and unrelated replies, rejects server errors", async () => {
  const previous=(globalThis as any).chrome
  const listeners=new Set<(message:any)=>void>();let request:any
  ;(globalThis as any).chrome={runtime:{onMessage:{addListener:(fn:any)=>listeners.add(fn),removeListener:(fn:any)=>listeners.delete(fn)},sendMessage:async(message:any)=>{request=message;return {ok:true}}}}
  try {
    let completed=false
    const saved=saveThreadMetadata("one",{user_tags:["pay"],topic_folder:null},new AbortController().signal).then(value=>{completed=true;return value})
    await Promise.resolve();assert.equal(completed,false)
    for(const listener of listeners) listener({type:"thread.updated",id:"another",thread:{id:"one"}})
    assert.equal(completed,false)
    for(const listener of listeners) listener({type:"thread.updated",id:request.id,thread:{id:"wrong-thread",user_tags:["pay"],topic_folder:null}})
    assert.equal(completed,false)
    const actual={id:"one",user_tags:["pay"],topic_folder:null}
    for(const listener of listeners) listener({type:"thread.updated",id:request.id,thread:actual})
    assert.equal(await saved,actual);assert.equal(listeners.size,0)
    const ignored=saveThreadMetadata("one",{user_tags:["new tag"],topic_folder:null},new AbortController().signal)
    for(const listener of listeners) listener({type:"thread.updated",id:request.id,thread:{id:"one",topic_folder:null}})
    assert.equal(await ignored.then(()=>"unexpected",error=>error.message.includes("未确认")),true)
    const aborter=new AbortController()
    const aborted=saveThreadMetadata("one",{user_tags:[],topic_folder:null},aborter.signal)
    aborter.abort()
    assert.equal(await aborted.then(()=>"unexpected",error=>error.message.includes("已取消等待")),true)
    assert.equal(listeners.size,0)
    const failed=saveThreadMetadata("one",{user_tags:[],topic_folder:null},new AbortController().signal)
    for(const listener of listeners) listener({type:"error",id:request.id,error:"Disk full"})
    assert.equal(await failed.then(()=>"unexpected success",error=>error.message),"Disk full");assert.equal(listeners.size,0)
  } finally { (globalThis as any).chrome=previous }
})


test("metadata timeout releases listeners and cannot become success from a late reply", async () => {
  const originalChrome = (globalThis as any).chrome
  const originalSetTimeout = globalThis.setTimeout
  const originalClearTimeout = globalThis.clearTimeout
  const listeners = new Set<(message: any) => void>()
  let expire: () => void = () => {}
  let request: any
  let cleared = false
  ;(globalThis as any).chrome = { runtime: {
    onMessage: { addListener: (fn: any) => listeners.add(fn), removeListener: (fn: any) => listeners.delete(fn) },
    sendMessage: async (message: any) => { request = message; return { ok: true } },
  } }
  ;(globalThis as any).setTimeout = (fn: () => void, ms: number) => { assert.equal(ms, 15_000); expire = fn; return 1 }
  ;(globalThis as any).clearTimeout = () => { cleared = true }
  try {
    const result = saveThreadMetadata("one", { user_tags: ["human"], topic_folder: null }, new AbortController().signal)
      .then(() => "unexpected", error => error.message)
    expire()
    assert.equal(await result, "尚未收到保存确认，请检查连接后重试")
    assert.equal(cleared, true)
    assert.equal(listeners.size, 0)
    for (const listener of listeners) listener({ type: "thread.updated", id: request.id, thread: { id: "one", user_tags: ["human"] } })
    assert.equal(await result, "尚未收到保存确认，请检查连接后重试")
  } finally {
    ;(globalThis as any).chrome = originalChrome
    globalThis.setTimeout = originalSetTimeout
    globalThis.clearTimeout = originalClearTimeout
  }
})


test("graph human-only tags retain AI extraction eligibility and untagged color", () => {
  const thread = { id: "human-only", user_tags: ["负责人"], digest: { tags: [] } }
  assert.equal(aiThreadGroup(thread), null)
  const colors = buildTagColorIndex([thread])
  assert.equal(colors.tagById.get(thread.id), null)
  assert.equal(colors.colorById.get(thread.id), UNTAGGED_COLOR)
  assert.equal(colors.groups[0].tag, "未标注")
  assert.equal(threadTags(thread)[0], "负责人")
})


### FULL chrome-extension/scripts/test-thread-management-ui.py

"""Real App, isolated runtime transport. No live threads or configuration."""
from pathlib import Path
import subprocess,tempfile
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-473-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':390,'height':740});page.set_default_timeout(7000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
  page.evaluate("window.dispatchUI({type:'SET_THREADS',threads:window.demoThreads.map((t,i)=>({...t,message_count:4,user_message_count:2,topic_folder:i===0?'人工项目':null,digest:i<2?{tldr:'发布与测试',tags:['支付','发布'],bullets:['核对版本'],extracted_at:new Date().toISOString(),source:'manual'}:null}))})")
  manager=page.get_by_role('dialog',name='历史对话列表',exact=True)
  for width,height in [(320,480),(390,740),(759,740),(760,740),(1440,900)]:
   page.set_viewport_size({'width':width,'height':height})
   if width<760:
    new=page.locator('.cm-header-new');assert new.is_visible();box=new.bounding_box();assert box['x']>=0 and box['x']+box['width']<=width
   else:assert not page.locator('.cm-header-new').is_visible()
   page.get_by_role('button',name='对话管理（历史对话）',exact=True).click();manager.wait_for()
   for label in ['时间','标签','手动分组','AI 分组']:
    manager.get_by_role('button',name=label,exact=True).click()
    assert manager.evaluate('(el)=>el.scrollWidth<=el.clientWidth'),(width,label)
   for label in ['AI 提取标签','整理助手','关系图谱','回收站']:
    button=manager.get_by_role('button',name=label,exact=True);button.scroll_into_view_if_needed();assert button.is_visible()
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
   manager.evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(shots/f'manager-{width}.png'))
   manager.get_by_role('button',name='关闭历史对话',exact=True).click()
  page.get_by_role('button',name='对话管理（历史对话）',exact=True).click()
  manager.get_by_role('button',name='选择',exact=True).click()
  page.locator('.cm-composer-dock textarea').click()
  assert not manager.is_visible()
  page.get_by_role('button',name='对话管理（历史对话）',exact=True).click()
  manager.get_by_role('button',name='选择',exact=True).wait_for()
  manager.get_by_role('button',name='关闭历史对话',exact=True).click()
  # Existing AI grouping is a read projection; opening it must not write manual folders.
  assert not page.evaluate('window.sent.some(m=>m.type==="thread.update")')
  page.get_by_role('button',name='管理对话',exact=True).click();manager.wait_for()
  manager.get_by_role('button',name='手动分组',exact=True).click()
  manager.get_by_title('编辑标签与分组',exact=True).first.click()
  form=manager.get_by_role('form',name='编辑对话分类');form.wait_for()
  form.get_by_label('人工标签',exact=True).fill('负责人，需复核')
  form.get_by_label('手动分组',exact=True).fill('手动发布')
  form.get_by_role('button',name='保存分类',exact=True).click();manager.get_by_role('status').filter(has_text='分类已保存').wait_for()
  page.wait_for_function('window.fixtureState.threads.some(t=>t.topic_folder==="手动发布" && t.user_tags?.includes("负责人"))')
  saved_id=page.evaluate('window.sent.filter(m=>m.type==="thread.update").at(-1).thread_id')
  page.evaluate('(id)=>{const t=window.fixtureState.threads.find(t=>t.id===id);window.dispatchUI({type:"UPSERT_THREAD",thread:{...t,digest:{...t.digest,tags:["新的AI标签"]}}})}',saved_id)
  manager.get_by_role('button',name='标签',exact=True).click();manager.get_by_role('button',name='#负责人 1',exact=True).click();manager.get_by_role('searchbox').fill('负责人')
  manager.get_by_title('编辑标签与分组',exact=True).first.click();form.wait_for()
  assert form.get_by_label('人工标签',exact=True).input_value()=='负责人，需复核'
  page.evaluate('window.metadataReply="error"')
  form.get_by_label('手动分组',exact=True).fill('不得假保存')
  form.get_by_role('button',name='保存分类',exact=True).click();form.get_by_role('alert').wait_for()
  assert form.get_by_label('手动分组',exact=True).input_value()=='不得假保存'
  assert not page.evaluate('window.fixtureState.threads.some(t=>t.topic_folder==="不得假保存")')
  form.get_by_role('button',name='取消',exact=True).click();manager.get_by_role('searchbox').fill('')
  manager.get_by_role('button',name='关系图谱',exact=True).click()
  assert page.evaluate('window.sent.some(m=>m.type==="thread_graph.open" && m.threads.some(t=>t.user_tags?.includes("负责人") && !t.digest?.tags?.includes("负责人")))')
  page.get_by_role('button',name='对话管理（历史对话）',exact=True).click();manager.wait_for()
  manager.get_by_role('button',name='AI 提取标签',exact=True).click()
  assert page.evaluate('window.sent.some(m=>m.type==="thread.extract_digest" && m.thread_ids.length<=20)')
  manager.get_by_role('button',name='整理助手',exact=True).click()
  assert page.evaluate('window.sent.some(m=>m.type==="thread.suggest_cleanup")')
  manager.get_by_role('button',name='关闭历史对话',exact=True).click()
  page.set_viewport_size({'width':320,'height':480});before=page.evaluate('window.sent.filter(m=>m.type==="thread.create").length')
  page.locator('.cm-header-new').click()
  assert page.evaluate('window.sent.filter(m=>m.type==="thread.create").length')==before+1
  # At 320 short height the header risk control and running stop stay directly hittable.
  page.evaluate("window.dispatchUI({type:'SET_THREAD_BUSY',threadId:window.fixtureState.activeThreadId,busy:true});window.dispatchUI({type:'SET_CONFIG',config:{auto_approve_dangerous:true}})")
  stop=page.get_by_title('停止本轮',exact=True);stop.wait_for()
  page.get_by_role('button',name='对话管理（历史对话）',exact=True).click();manager.wait_for()
  risk=page.locator('.cm-status-rail button[aria-label$="点击解除"]');risk.wait_for()
  for control in [stop,risk,page.locator('.cm-header-new')]:
   assert control.evaluate('(el)=>{const r=el.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
  manager.get_by_title('更多',exact=True).click()
  assert stop.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
  stop.click();manager.wait_for(state='hidden')
  assert page.evaluate('window.sent.some(m=>m.type==="chat.abort")')
  page.get_by_role('button',name='对话管理（历史对话）',exact=True).click();manager.wait_for()
  page.evaluate("window.dispatchUI({type:'ADD_SECURITY_CONFIRMATION',request:{confirmation_id:'management-fixture',tool_name:'shell_exec',dangerous_apis:['shell'],code_preview:'git diff',risk_level:'high',requested_at:new Date().toISOString(),timeout_ms:45000}})")
  manager.wait_for(state='hidden')
  assert page.get_by_role('button',name='对话管理（历史对话）',exact=True).is_disabled()
  gate=page.get_by_role('alertdialog').first
  for label in ['允许','拒绝','停止']:
   assert gate.get_by_role('button',name=label,exact=True).evaluate('(el)=>{const r=el.getBoundingClientRect();return r.top>=0 && r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
  assert not page.evaluate('window.sent.some(m=>m.type==="security.confirmation.response")')
  assert not errors,errors
  b.close()
print('PASS: responsive new chat+manager, tags/manual/AI groups, persisted metadata+failure, AI label retention, explicit AI/cleanup/graph paths, no automatic metadata writes.')


### FULL docs/superpowers/plans/2026-09-08-thread-management-discoverability.md

# 对话管理可发现性

GitHub: #473 · Base: 913c328e · 2026-09-08

用户认可当前简洁视觉，恢复遗漏入口并补实际能力。窄栏顶栏保留常驻“+”（aria-label 新对话）调用 createBlankThread；宽屏仍以左导航创建，不重复主入口。标题区域可收缩，风险/停止不被遮盖。

单一 ThreadList 所有者继续提供历史与管理，不新增线程缓存。顶栏历史图标增加“对话管理”文字（窄屏也可辨识）；左侧最近对话旁提供“管理”，通过专用 UI event 打开同一面板。保留旧历史 accessible name 兼容已有入口。管理面板增加一排明确的 AI 提取、整理助手、关系图和回收站按钮，不藏在更多里。整理助手是规则扫描，不能误标为 AI 智能分组。更多仍保留起名/清理等操作。

视图为时间、标签、手动分组、AI 分组。AI 分组按 digest.tags 的首个主题标签派生显示，每个会话只归一个 AI 组，无标签显示“待 AI 整理”；可显式启动既有最多20条未标注 AI 提取，展示既有进度。它不是新聚类模型、不写 topic_folder，不覆盖手动分组。后台自动提取仍遵循既有配置/配额，不新增默认任务。

手动分组以应用内编辑表单替代“夹”prompt，允许选择现有名称、输入新组或移出。人工标签新增独立 user_tags 元数据，最多20个、每个40字符，去控制符/规范空白/去重；AI digest 的整体替换保留 user_tags。编辑表单明确“人工标签”与只读“AI 标签”，本轮不支持删除 AI 生成标签或重命名整个全局标签。标签筛选/搜索/行展示汇总两类标签并去重；AI 分组仅依据 AI 标签，不把人工标签伪装成 AI。表单只提交 user_tags/topic_folder，不能写其他权限字段。

保存必须收到已持久化的 thread.updated 才显示成功，传输 ACK 不算保存；错误/超时显示失败保留草稿。复用 SW 请求响应规则，先核对再实现。不会操作真实用户数据作为验证。手动分组现有一对一模型保留，批量移动和全局标签重命名不是首版承诺。

验证实际 App 320/390/759/760/1440及320短屏：顶栏新对话可达；从导航及顶栏进入同一管理面板；所有视图/AI提取/规则整理/关系图可见可调用；人工标签保存、AI提取不覆盖、分组保存/清空/失败；列表标签搜索；AI分组不修改手动归属；旧历史与确认回归。后端元数据持久化和非法输入边界测试。设计与实现 Grok4.6 + DeepSeekV4Pro独立复审，机核优先、CI绿后合并；不打包换装。

## 门禁澄清

保存仅接受与本次 envelope id 精确匹配、thread.id 也匹配的 thread.updated；不匹配的广播和传输 ACK 均不成功。失败保留草稿；超时说明“尚未收到保存确认”，不承诺服务器未保存。迟到事件由原全局 store 正常接收，不冒充当前表单成功。编辑表单不随 AI digest 更新重新初始化，服务端 update 基于当前记录合并明确字段，AI 只提交 digest。

AI 组键是经既有 digest normalize 后的第一个非空 AI 标签，按其原序取值；无标签为“待 AI 整理”。重新提取可能调整 AI 组，UI 明说，不保证 AI 标签顺序跨运行不变。人工标签不参与 AI 组键。每次显式提取最多20条，完成后用户可再次点击处理剩余，既有批次 busy/worker/回收站排除与进度机制不变。

顶栏新对话与管理入口不收缩；窄屏顶栏允许换行，任务标题优先截断，装饰品牌在520以下隐藏腾出空间；风险/停止保留原控制与 FocusBand 优先级，以320短屏确认测试验证。管理按钮 accessible name 为“对话管理（历史对话）”，兼顾可见文字与旧历史含义。窄屏会话行操作换到标题下，避免列表标题只剩一个字。

保存分类/取消后将焦点返回原分类按钮，若过滤导致该行消失则回到管理搜索框。整理助手是规则扫描，AI提取标签是既有模型提取，名称不混用。人工标签最大20×40并由服务端强制校验；全局 thread.update 原权限字段白名单不变，编辑器仅构造分类两个字段。

## 实现门禁补充

图谱 slim payload 的 user_tags 与 digest.tags 分开保留。关系评分与搜索可使用两类标签，但 AI 主标签颜色/AI 分组保持 digest-only，详情中人工标签独立列出。无 AI 标签分组固定置底。

管理面板作为非模态弹层：高度上限截止输入区之前，删除全窗透明拦截层；点击面板外关闭且点击继续到目标，停止按钮可直接操作。更多菜单也限定在输入区上方。窗口/顶栏/输入区 ResizeObserver 重算位置。有待确认操作时管理面板立即收起且入口暂禁，不能遮住原允许/拒绝/停止；处理确认后恢复。320×480 实测会覆盖运行态、高权限状态、管理面板/更多菜单与确认到达。

旧 Companion 可能忽略 user_tags；收到匹配 thread.updated 后仍核对返回分类字段，未确认所提交值不得显示成功，提示确认 Companion 更新。人工标签清空不影响 AI 标签。关闭编辑器后恢复分类按钮或搜索焦点。


### FULL chrome-extension/src/thread-graph/tag-colors.ts

// Stable tag → color groups for thread graph (Obsidian-like "颜色组").
// Pure helpers — no DOM / chrome APIs.

/** Soft pastel dots that read well on near-black canvas. */
export const TAG_PALETTE = [
  "#6b9fff", // blue
  "#f472b6", // pink
  "#34d399", // green
  "#fbbf24", // amber
  "#a78bfa", // violet
  "#22d3ee", // cyan
  "#fb923c", // orange
  "#e879f9", // fuchsia
  "#4ade80", // lime
  "#94a3b8", // slate (fallback-ish)
] as const

export const UNTAGGED_COLOR = "#64748b"
export const UNTAGGED_LABEL = "未标注"

/** FNV-1a-ish stable hash for string → palette index. */
export function hashTag(tag: string): number {
  const s = tag.trim().toLowerCase()
  let h = 2166136261
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

export function colorForTag(tag: string | null | undefined): string {
  if (!tag || !tag.trim()) return UNTAGGED_COLOR
  const i = hashTag(tag) % TAG_PALETTE.length
  return TAG_PALETTE[i]
}

/** Primary tag = first non-empty digest tag (stable assignment source). */
export function primaryTag(tags: string[] | undefined | null): string | null {
  if (!tags || tags.length === 0) return null
  for (const t of tags) {
    const s = (t || "").trim()
    if (s) return s
  }
  return null
}

export type ColorGroup = {
  tag: string
  color: string
  count: number
}

/**
 * Build per-node color map + legend groups (sorted by count desc, then tag).
 * `nodeIds` limits which threads appear in the legend counts.
 */
export function buildTagColorIndex(
  threads: Array<{ id: string; digest?: { tags?: string[] } | null }>,
  nodeIds?: Set<string> | string[],
): {
  colorById: Map<string, string>
  tagById: Map<string, string | null>
  groups: ColorGroup[]
} {
  const allow =
    nodeIds == null
      ? null
      : nodeIds instanceof Set
        ? nodeIds
        : new Set(nodeIds)

  const colorById = new Map<string, string>()
  const tagById = new Map<string, string | null>()
  const counts = new Map<string, number>()

  for (const t of threads) {
    if (allow && !allow.has(t.id)) continue
    const tag = primaryTag(t.digest?.tags)
    const key = tag ?? UNTAGGED_LABEL
    tagById.set(t.id, tag)
    colorById.set(t.id, colorForTag(tag))
    counts.set(key, (counts.get(key) || 0) + 1)
  }

  const groups: ColorGroup[] = [...counts.entries()]
    .map(([tag, count]) => ({
      tag,
      count,
      color: tag === UNTAGGED_LABEL ? UNTAGGED_COLOR : colorForTag(tag),
    }))
    .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, "zh"))

  return { colorById, tagById, groups }
}

/** Lighten hex for focus/hover (simple channel blend toward white). */
export function lightenHex(hex: string, amount = 0.35): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return hex
  const n = parseInt(m[1], 16)
  const r = (n >> 16) & 0xff
  const g = (n >> 8) & 0xff
  const b = n & 0xff
  const mix = (c: number) => Math.min(255, Math.round(c + (255 - c) * amount))
  const to = (c: number) => c.toString(16).padStart(2, "0")
  return `#${to(mix(r))}${to(mix(g))}${to(mix(b))}`
}

/** Apply alpha to #rrggbb → rgba(). */
export function hexWithAlpha(hex: string, alpha: number): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return hex
  const n = parseInt(m[1], 16)
  const r = (n >> 16) & 0xff
  const g = (n >> 8) & 0xff
  const b = n & 0xff
  const a = Math.max(0, Math.min(1, alpha))
  return `rgba(${r},${g},${b},${a})`
}


### FULL chrome-extension/src/sidepanel/components/ThreadMetadataEditor.tsx

import { useEffect, useRef, useState } from "react"
import type { Thread } from "../types"
import { saveThreadMetadata } from "../utils/thread-management"

export function ThreadMetadataEditor({ thread, folders, onSaved, onClose }: {
  thread: Thread; folders: string[]; onSaved: (thread: Thread) => void; onClose: () => void
}) {
  const [tags, setTags] = useState((thread.user_tags || []).join("，"))
  const [folder, setFolder] = useState(thread.topic_folder || "")
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")
  const controller = useRef<AbortController | null>(null)
  const firstInput = useRef<HTMLInputElement>(null)
  useEffect(() => { firstInput.current?.focus(); return () => controller.current?.abort() }, [])
  return <form className="cm-thread-editor" aria-label="编辑对话分类" onSubmit={async event => {
    event.preventDefault()
    if (controller.current) return
    const userTags = tags.split(/[,，\n]/).map(tag => tag.normalize("NFC").replace(/[\x00-\x1f\x7f]/g, "").replace(/\s+/g, " ").trim()).filter(Boolean)
    if (userTags.length > 20 || userTags.some(tag => tag.length > 40)) { setError("最多20个标签，每个不超过40字"); return }
    const request = new AbortController()
    controller.current = request
    setSaving(true); setError("")
    try {
      const saved = await saveThreadMetadata(thread.id, { user_tags: userTags, topic_folder: folder.normalize("NFC").replace(/[\x00-\x1F\x7F\\/]/g, "").trim() || null }, request.signal)
      if (!request.signal.aborted) onSaved(saved)
    } catch (error) {
      if (!request.signal.aborted) setError(error instanceof Error ? error.message : "保存失败")
    } finally {
      controller.current = null
      if (!request.signal.aborted) setSaving(false)
    }
  }}>
    <strong>编辑标签与分组</strong>
    <label>人工标签<input ref={firstInput} value={tags} onChange={event => setTags(event.target.value)} disabled={saving} placeholder="用逗号分隔，例如：支付，待跟进" /></label>
    <p>人工标签单独保存，不会被 AI 提取覆盖。AI 标签：{thread.digest?.tags?.join("、") || "尚未提取"}（只读）</p>
    <label>手动分组<input list="cm-thread-folders" value={folder} onChange={event => setFolder(event.target.value)} disabled={saving} maxLength={40} placeholder="选择已有分组或输入新名称；留空移出" /></label>
    <datalist id="cm-thread-folders">{folders.map(name => <option key={name} value={name} />)}</datalist>
    {error && <p role="alert">{error}</p>}
    <div className="cm-thread-editor-actions"><button type="button" onClick={onClose} disabled={saving}>取消</button><button type="submit" disabled={saving}>{saving ? "等待保存确认…" : "保存分类"}</button></div>
  </form>
}


### ThreadList lifecycle and close dependencies

      saveExpandState(next)
      return next
    })
  }

  const toggleDay = (dayKey: string) => {
    setExpandedDays((prev) => {
      const next = new Set(prev)
      if (next.has(dayKey)) next.delete(dayKey)
      else next.add(dayKey)
      return next
    })
  }

  const exitSelectMode = useCallback(() => {
    setSelectMode(false)
    setSelected(new Set())
  }, [])

  /** Copy thread id (without #) for search / support; show brief “已复制” only on success. */
  const copyThreadId = useCallback(async (threadId: string) => {
    const text = String(threadId || "").trim()
    if (!text) return
    let ok = false
    try {
      await navigator.clipboard.writeText(text)
      ok = true
    } catch {
      try {
        const ta = document.createElement("textarea")
        ta.value = text
        ta.style.position = "fixed"
        ta.style.left = "-9999px"
        document.body.appendChild(ta)
        ta.select()
        ok = document.execCommand("copy")
        document.body.removeChild(ta)
      } catch {
        ok = false
      }
    }
    if (!ok) return
    setCopiedId(threadId)
    if (copyIdTimerRef.current) clearTimeout(copyIdTimerRef.current)
    copyIdTimerRef.current = setTimeout(() => {
      setCopiedId((cur) => (cur === threadId ? null : cur))
      copyIdTimerRef.current = null
    }, 1200)
  }, [])

  const handleNewThread = () => {
    createBlankThread(dispatch)
    setOpen(false)
    exitSelectMode()
  }

  const handleCleanupEmpty = () => {
    const emptyN = threads.filter(
      (t) => t.message_count === 0 && t.id !== activeThreadId && !t.trashed_at,
    ).length
    setCleanupOpen(false)
    setCleanupSuggestions([])
  }

  /** B-4: extract digests for cleanup-selected threads only (no delete). */
  const applyCleanupExtractOnly = () => {
    const ids = [...cleanupSelected].slice(0, EXTRACT_DIGEST_MAX)
    if (ids.length === 0) return
    const force = batchNeedsForceExtract(filtered as Thread[], ids)
    beginExtractBatch(ids, force)
  }

  const panelMaxHeight = selectMode || view === "tags" || view === "topics" || view === "ai" ? 480 : 360

  useEffect(() => {
    if (!open) {
      setPanelBox(null)
      return
    }
    const place = () => {
      const r = triggerRef.current?.getBoundingClientRect()
      const top = Math.round((r?.bottom ?? 48) + 6)
      setPanelBox({
        top,
        maxHeight: Math.max(0, Math.min(window.innerHeight - top - 12, (document.querySelector<HTMLElement>(".cm-composer-dock")?.getBoundingClientRect().top ?? window.innerHeight) - top - 8)),
      })
    }
    place()
    window.addEventListener("resize", place)
    const observer = new ResizeObserver(place)
    const dock = document.querySelector(".cm-composer-dock")
    const rail = document.querySelector(".cm-status-rail")
    if (dock) observer.observe(dock)
    if (rail) observer.observe(rail)
    return () => { window.removeEventListener("resize", place); observer.disconnect() }
  }, [open, selectMode, view])

  // Outside actions remain directly usable (not intercepted by a transparent backdrop).
  useEffect(() => {
    if (!open) return
    const outside = (event: MouseEvent) => {
      const target = event.target as Node
      if (!historyRef.current?.contains(target) && !triggerRef.current?.contains(target) && !historyMenuRef.current?.contains(target)) {
        setOpen(false); setMenuOpen(false); exitSelectMode()
      }
    }
    document.addEventListener("mousedown", outside)
    return () => document.removeEventListener("mousedown", outside)
  }, [open, exitSelectMode])

  // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
  // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
  useEffect(() => {
    if (!open || !panelBox) return
    historyRef.current?.querySelector<HTMLInputElement>('input[type="search"]')?.focus()
    const key = (event: KeyboardEvent) => {
      if (event.key !== "Escape" || event.defaultPrevented) return
      if (!historyRef.current?.contains(event.target as Node) && event.target !== triggerRef.current && !historyMenuRef.current?.contains(event.target as Node)) return
      event.preventDefault()
      event.stopPropagation()
      if (menuOpenRef.current) { setMenuOpen(false); menuBtnRef.current?.focus(); return }
      setOpen(false); triggerRef.current?.focus()
    }
    document.addEventListener("keydown", key)
    return () => document.removeEventListener("keydown", key)
  }, [open, !!panelBox])

  const closeMetadataEditor = (threadId = editingThread?.id) => {
    setEditingThread(null)
    requestAnimationFrame(() => {

### MACHINE exit 0 ext-finalbuild

  icon_128x128.png (36424 bytes)
  icon_128x128@2x.png (116683 bytes)
  icon_256x256.png (116683 bytes)
  icon_256x256@2x.png (328574 bytes)
  icon_512x512.png (328574 bytes)
  icon_512x512@2x.png (788319 bytes)

Portal icon generation complete!

> cmspark-browser-agent@0.6.6 build
> tsc --noEmit && plasmo build

🟣 Plasmo v0.90.5
🔴 The Browser Extension Framework
🔵 INFO   | Prepare to bundle the extension...
🔵 INFO   | Building for target: chrome-mv3
🔵 INFO   | Loaded environment variables from: []
🟢 DONE   | Finished in 9232ms!

### MACHINE exit 0 ext-finaltest

  duration_ms: 0.072208
  type: 'test'
  ...
# Subtest: isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
ok 1285 - isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
  ---
  duration_ms: 0.068875
  type: 'test'
  ...
1..1285
# tests 1285
# suites 0
# pass 1285
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 9377.448667

### MACHINE exit 0 comp-closebuild


> cmspark-agent@0.6.6 prebuild
> node scripts/generate-tray-icons.mjs

  tray-icon-green.png (654 bytes)
  tray-icon-red.png (627 bytes)
  tray-icon-yellow.png (683 bytes)

Portal tray icons generated!

> cmspark-agent@0.6.6 build
> tsc && node -e "const fs=require('fs'),p=require('path');fs.mkdirSync('dist/computer',{recursive:true});fs.copyFileSync('src/computer/qwen-vl-worker.py','dist/computer/qwen-vl-worker.py');process.platform!=='win32'&&fs.chmodSync('dist/index.js',0o755)"


### MACHINE exit 0 comp-closetest

      duration_ms: 0.265791
      type: 'test'
      ...
    1..4
ok 2 - settings-cli
  ---
  duration_ms: 2.308334
  type: 'suite'
  ...
1..2
# tests 20
# suites 2
# pass 20
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 53.7585

### MACHINE exit 0 browser-finalgate

WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmp860hf8k_
PASS: responsive new chat+manager, tags/manual/AI groups, persisted metadata+failure, AI label retention, explicit AI/cleanup/graph paths, no automatic metadata writes.

### MACHINE exit 0 workspace-finalgate

WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/cmspark-workspace-qxutgcez
PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, reflow/reduced motion. Synthetic transport only.