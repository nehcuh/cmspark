Independently review incoming CMspark commit 947532a8 against 4a63de56, GitHub #488. Read-only. Other agents already implemented these Windows changes; do not trust their approval or reports. No other judge conclusions are included. We will test on Mac. User requires intuitive clean attractive UI without hiding any existing capability. Scope includes thread management bulk selection/delete/restore and UI hierarchy, args redaction, CLI version, public capability wording, version 0.6.7. No new permissions are authorized by this review. Check outcome, control-flow/data ownership and components. Existing thread actions require actual persisted correlated results; failures must not masquerade as success. Code must not leak raw secrets in persistent assistant calls. Separate newly introduced defects from existing debt. Cite exact paths/lines, severity and reproducible scenario. Do not invent missing endpoints. Include final VERDICT: APPROVE, APPROVE_WITH_NITS, or REJECT. A preface is not a review.

FROZEN DIFF
diff --git a/AGENTS.md b/AGENTS.md
index 863a557a..70959be2 100644
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -1,6 +1,6 @@
 # CMspark Agent Configuration
 
-> **Version**: 0.6.6 (keep in lock-step with companion/package.json)
+> **Version**: 0.6.7 (keep in lock-step with companion/package.json)
 > **Platform**: CMspark Browser Agent
 
 ## Tool Environment
@@ -26,7 +26,7 @@ The following development tools are available on this system. Use them when work
 
 ### 需求设计 Issue-first（锁定 · 2026-08-27）
 
-任何需求设计必须**先**在 GitHub 建 Issue，再写 spec/plan。禁止只在 `docs/superpowers/` 里设计。模板：`.github/ISSUE_TEMPLATE/design.md`。本季余项：#230 冻（F-S-10 / overlay-acl）· #258–#260 语音/会议。T1 #228 已记分，禁扩 outbound profile。例外：无新需求的 typo/文档；已有行为的 bugfix。
+任何需求设计必须**先**在 GitHub 建 Issue，再写 spec/plan。禁止只在 `docs/superpowers/` 里设计。模板：`.github/ISSUE_TEMPLATE/design.md`。本季余项：#230 冻（F-S-10 / overlay-acl）。T1 #228 已记分，禁扩 outbound profile。语音/会议 #258–#260 已在树上（embedding 仍 experimental）。例外：无新需求的 typo/文档；已有行为的 bugfix。
 
 Playbook categories (not executors):
 - `workflows/bridge-*.ts` — bridge/ module fixes and reviews
@@ -66,4 +66,4 @@ When the user types `/dev-*`, map to the matching playbook in `workflows/` (hist
 - MCP meta tools (`mcp_list_resources`, `mcp_read_resource`, `mcp_get_prompt`) are exposed dynamically based on connected server capabilities — they are NOT in the static `getToolDefinitions()` list.
 
 ---
-*CMspark Agent v0.6.6*
+*CMspark Agent v0.6.7*
diff --git a/CHANGELOG.md b/CHANGELOG.md
index c00c0ed4..5ad8a3be 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -4,6 +4,18 @@
 
 ## [Unreleased]
 
+## [0.6.7] — 2026-09-08
+
+S107 六路对抗 + Claude/Kimi dual AWN 关门：活文档与代码锁步，不把 0.7.0 企业双场景验收算进本切点（#230 仍冻，#228 禁扩默认 outbound）。
+
+- **文档诚实**：README / PRODUCT / CLAUDE / GOAL / architecture / 召唤器与听写指南锁 **0.6.7**。Capture 默认 **1040×760**（`OVERLAY_WINDOW_SIZE`），360×420 为紧凑档。知识「全选」改为 TF-IDF top-k（auto 5 / all 8）+ 8000 字预算，不再写灌库。#258–#260 从余项拿掉（embedding 仍 experimental）。GOAL G19 不再把交互式 PTY 当非目标（#432 Darwin-only、默认关、Windows unsupported）。
+- **会议 Host「收起」**：录音进行中文案改为「结束并收起」（unmount 仍 `meeting.end`，防 status=recording 卡住）。恢复路径「设置 → 听写」改为「设置 → 输入与语音」。
+- **CLI**：`--version` / `-V` / `version` 打印一行并 exit 0；`status` / `stop` 不再撒谎，分别等同 `daemon status` / `daemon stop`。
+- **持久化**：assistant `tool_calls[].function.arguments` 落盘前走与 tool-role 同一套 `redactToolPayloadForPersistence`；非法 JSON 不留原文。
+- **版本锚**：companion / extension / NSIS fallback / ACP / outbound serverInfo / lockfile 齐 **0.6.7**（extension lockfile 此前仍写 0.6.3）。
+
+以下条目此前写在 Unreleased、已在 main，随 0.6.7 归档（企业双场景仍非 0.7.0 GA）：
+
 - 听写修复（#482）：召唤器遵循所选引擎，展示启动/识别状态并接收实际 HTTP 转写结果；音频块按序上传，切换对话及取消后丢弃旧结果。插件普通本机听写复用渐进预览，停止后保留完整推理等待，不再套用连续会议的短截止时间。
 - 代码工作归属修复（#483）：按会话缓存、按对话展示代码运行；后台和迟到事件不打开新对话面板，操作携带所属对话并核对服务端会话，目录选择与 Git 状态回包也按归属隔离。
 - 工作空间整理（#481）：召唤器补齐人工标签/手动分组及派生查看方式，使用共享校验和真实保存回执；两端对话优先、辅助入口收纳为“资料与工具”。完成整体 UI/UX 审计和独立项目层级方案；项目实体、原生完整工作台仍未交付。
@@ -16,7 +28,7 @@
 
 - 召唤器与设置重设计（#471）：删除召唤器所有装饰性“山”，统一聊天输入和操作布局；设置改为八类导航页面，保留草稿和深链，明确保存范围，补齐语音取消及许可证弹窗键盘隔离。
 
-- 整体 UI/UX 工作区重设计（#469）：宽屏常驻导航与可读对话列，窄屏非遮罩导航，统一输入区、历史键盘操作、设置分类和上下文布局；终端、确认台、图谱、召唤窗口和独立设置页同步视觉语言。保持现有确认和执行策略，未发版或替换安装程序。
+- 整体 UI/UX 工作区重设计（#469）：宽屏常驻导航与可读对话列，窄屏非遮罩导航，统一输入区、历史键盘操作、设置分类和上下文布局；终端、确认台、图谱、召唤窗口和独立设置页同步视觉语言。保持现有确认和执行策略。
 
 - 代码审阅开发切片（#465/#466/#467）：从网页观察解析实际 unified diff，锁定仓库和完整 base/head；CMspark 网页评语与可选终端 Agent 报告分别保存，关联真实任务引用和材料版本。终端支持登录 shell、连接归属校验、显式确认回传及幂等回执；不自动执行 Agent。通用网页覆盖与业务关系仍待核实，真实企业双场景验收继续作为发布门槛。
 
diff --git a/CLAUDE.md b/CLAUDE.md
index 926e45a0..2cc3771c 100644
--- a/CLAUDE.md
+++ b/CLAUDE.md
@@ -18,7 +18,7 @@
 - spec/plan 文件头写 `GitHub: #N`
 - 实现 PR：`Closes #N` 或 `Refs #N`
 - 例外：无新需求的 typo/文档；已有行为的 bugfix
-- 本季余项：[#230](https://github.com/nehcuh/cmspark/issues/230) 冻（F-S-10 / overlay-acl）· [#258](https://github.com/nehcuh/cmspark/issues/258)–[#260](https://github.com/nehcuh/cmspark/issues/260) 语音/会议。T1 [#228](https://github.com/nehcuh/cmspark/issues/228) 已记分，**禁扩** outbound profile。#229 已关。
+- 本季余项：[#230](https://github.com/nehcuh/cmspark/issues/230) 冻（F-S-10 / overlay-acl）。T1 [#228](https://github.com/nehcuh/cmspark/issues/228) 已记分，**禁扩** outbound profile。#229 已关。Hex PTT / Windows SAPI / speaker embedding 已有实现；embedding 仍实验。
 
 Playbook categories (not executors):
 - `workflows/bridge-*.ts` — bridge/ module fixes and reviews
@@ -34,7 +34,7 @@ CMspark — 浏览器内 AI Agent。通过 Chrome Side Panel 与用户交互，
 
 双层拓扑：Chrome Extension (Plasmo + React) ↔ WebSocket ↔ Companion (Node.js + TypeScript)
 
-当前阶段：**产品 0.6.0**。家 = **已登录 Chrome + 硬闸**，侧栏是 Operate 面之一。Capture HTML 卡 **360×420**（流式出字）· ChatShell「要对这页做什么 / 弹出对话框」· 租手钥匙 CLI + L8 · 知识 CRUD 诚实（AI 草稿 / 检索打分 / 分布视图 / 多级文件夹 / sha256 去重）· 技能 TF-IDF + 当轮活计划（页面工具前必须 propose；成功后才挂卡；放弃/纯问答则无卡）。**不是**召唤器/租手完成里程碑——T1 已记分（CMspark 臂 Y / Playwright `ERR_EMPTY_RESPONSE`），**禁扩**默认 outbound profile（[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）。Side Panel ↔ Companion 闭环、线程持久化、确认台、Pack/MCP/Multi-agent、CU（实验定位仅 **Qwen3-VL**）已交付。**听写+ / 本机 Whisper（含 M2、自动激活、当次会话回退横幅、HF 镜像）/ 会议工作台（说话人「自动」档）** 已交付（[用户指南](docs/meeting-and-dictation-user-guide.md)，ADR-023/024）。**对话框用户附图**（粘贴 / 点选 / 拖入；主模型多模态则原生看图）。**Obsidian 导出**（[ADR-008](docs/adr/008-obsidian-export.md)）· **Mermaid**（[ADR-009](docs/adr/009-mermaid-rendering.md)）· **Mission Pack**（[ADR-014](docs/adr/014-mission-pack-enterprise-modules.md)）见既有文档。
+当前阶段：**产品 0.6.7**。家 = **已登录 Chrome + 硬闸**，侧栏是 Operate 面之一。Capture HTML 卡默认 **1040×760**（紧凑切换 **360×420**；流式出字）· ChatShell「要对这页做什么 / 弹出对话框」· 租手钥匙 CLI + L8 · 知识 CRUD 诚实（AI 草稿 / 检索打分 / 分布视图 / 多级文件夹 / sha256 去重）· 知识默认 TF-IDF top-k 注入 · 知识图谱（#427）· Darwin 内嵌终端（#432，默认关）· `search_threads`/`search_knowledge`（#439）· 技能 TF-IDF + 当轮活计划（页面工具前必须 propose；成功后才挂卡；放弃/纯问答则无卡）。**不是**召唤器/租手完成里程碑——T1 已记分（CMspark 臂 Y / Playwright `ERR_EMPTY_RESPONSE`），**禁扩**默认 outbound profile（[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）。Side Panel ↔ Companion 闭环、线程持久化、确认台、Pack/MCP/Multi-agent、CU（实验定位仅 **Qwen3-VL**；#363 摘帽门未过）已交付。**听写+ / 本机 Whisper（含 M2、自动激活、当次会话回退横幅、HF 镜像）/ 会议工作台（说话人「自动」档）** 已交付（[用户指南](docs/meeting-and-dictation-user-guide.md)，ADR-023/024）。**对话框用户附图**（粘贴 / 点选 / 拖入；主模型多模态则原生看图）。**Obsidian 导出**（[ADR-008](docs/adr/008-obsidian-export.md)）· **Mermaid**（[ADR-009](docs/adr/009-mermaid-rendering.md)）· **Mission Pack**（[ADR-014](docs/adr/014-mission-pack-enterprise-modules.md)）见既有文档。
 
 ## Quick Start
 
@@ -134,7 +134,7 @@ Chrome Extension (Plasmo + React)  ←→  WebSocket (ws://127.0.0.1:23401)  ←
 
 - docs/README.md — 文档导航（用户 / 架构 / ADR / 工程 / 归档）
 - CONTRIBUTING.md — 需求设计 **Issue-first**（新行为必须先开 GitHub Issue）
-- CHANGELOG.md — **活切点** 0.6.0（侧栏 UI 重构 + 自主性三件套 + 专家团队 v1 + CU 完整性链；0.5.9 是 9-04 知识库切点）
+- CHANGELOG.md — **活切点** 0.6.7（知识图谱 / Darwin 内嵌终端 / 检索工具 / Capture 1040×760；0.6.0 是侧栏 UI + 自主性三件套切点；0.5.9 是 9-04 知识库切点）
 - docs/superpowers/specs/2026-08-27-post-227-status.md — **SNAPSHOT** 0.5.3 / #227；不是活状态
 - docs/GOAL.md — 项目目标与阶段规划
 - docs/architecture.md — 完整架构文档（§0 能力三轴 · §7 Packs · §8–11 MCP/CU·Host·Apps/Orchestrator·Board）
diff --git a/CONTRIBUTING.md b/CONTRIBUTING.md
index 67604c97..86d481d4 100644
--- a/CONTRIBUTING.md
+++ b/CONTRIBUTING.md
@@ -113,7 +113,7 @@ cmspark/
 **必须建票**：新产品行为、形态切片、能力边界、用户可见流程、冻结项（否则会「顺便」做掉）。  
 **不必建设计票**：无新需求的 typo/文档；已有行为的 bugfix（用 bug 票即可）。
 
-本季追踪：[#230](https://github.com/nehcuh/cmspark/issues/230) 冻（F-S-10 / overlay-acl）· [#258](https://github.com/nehcuh/cmspark/issues/258)–[#260](https://github.com/nehcuh/cmspark/issues/260) 语音/会议。T1 [#228](https://github.com/nehcuh/cmspark/issues/228) 已记分，**禁扩** outbound profile。正交旧债 #69 / #70 / #71。
+本季追踪：[#230](https://github.com/nehcuh/cmspark/issues/230) 冻（F-S-10 / overlay-acl）。T1 [#228](https://github.com/nehcuh/cmspark/issues/228) 已记分，**禁扩** outbound profile。语音/会议 [#258](https://github.com/nehcuh/cmspark/issues/258)–[#260](https://github.com/nehcuh/cmspark/issues/260) 已在树上（embedding 仍 experimental）。正交旧债 #69 / #70 / #71。
 
 ## 提交规范
 
diff --git a/PRODUCT.md b/PRODUCT.md
index 1d6c2a21..e0b44826 100644
--- a/PRODUCT.md
+++ b/PRODUCT.md
@@ -1,8 +1,8 @@
 # CMspark — Product Context (Impeccable)
 
-> Written 2026-08-11 for design harnesses. **Refreshed 2026-08-26**: home is logged-in Chrome + hard gates, not the Side Panel. **#241:** HTML float is Capture 卡片 (**360×420** inner; code `OVERLAY_WINDOW_SIZE`). HTML 卡跟 `chat.token` 流式出字。  
-> Version lock: companion/extension **0.6.0**。  
-> Remaining work: [#230](https://github.com/nehcuh/cmspark/issues/230) freeze (F-S-10 / overlay-acl) · [#258](https://github.com/nehcuh/cmspark/issues/258)–[#260](https://github.com/nehcuh/cmspark/issues/260) voice/meeting. T1 [#228](https://github.com/nehcuh/cmspark/issues/228) scored, **do not expand** outbound profile. New requirement designs **must** open an Issue first.
+> Written 2026-08-11 for design harnesses. **Refreshed 2026-09-08**: home is logged-in Chrome + hard gates, not the Side Panel. **#241:** HTML float is Capture 卡片 (**1040×760** default inner; code `OVERLAY_WINDOW_SIZE` in `companion/src/summoner/shell-open.ts`). Compact toggle is **360×420**, not the default. HTML 卡跟 `chat.token` 流式出字。  
+> Version lock: companion/extension **0.6.7**。  
+> Remaining work: [#230](https://github.com/nehcuh/cmspark/issues/230) freeze (F-S-10 / overlay-acl). T1 [#228](https://github.com/nehcuh/cmspark/issues/228) scored, **do not expand** outbound profile. Hex PTT / Windows SAPI / speaker embedding exist; embedding stays **experimental**. New requirement designs **must** open an Issue first.
 > Form SoT: [docs/superpowers/specs/2026-08-26-product-form-deepening-design.md](docs/superpowers/specs/2026-08-26-product-form-deepening-design.md) · Capture 怎么用：[docs/summoner-user-guide.md](docs/summoner-user-guide.md)
 
 ## One sentence
@@ -30,7 +30,7 @@
 
 | Surface | Mode | Notes |
 |---------|------|--------|
-| 召唤器 | **Capture** | HTML float = Capture 卡片 **360×420**: 问答（**流式出字**）、📎、听写、开始/结束会议、**打开浏览器并打开侧栏**. Fail toast **请点工具栏 C**. Mac 菜单/热键与侧栏「弹出对话框」同一张卡. Side Panel visual unchanged. Companion never `chrome.sidePanel.open`; extension SW opens the panel after the overlay button. Entry = toolbar C, **not** a tab-strip pill. Never claim CMspark sits beside the tab bar. |
+| 召唤器 | **Capture** | HTML float = Capture 卡片 **1040×760** default（compact **360×420**）: 问答（**流式出字**）、📎、听写、开始/结束会议、**打开浏览器并打开侧栏**. Fail toast **请点工具栏 C**. Mac 菜单/热键与侧栏「弹出对话框」同一张卡. Side Panel visual unchanged. Companion never `chrome.sidePanel.open`; extension SW opens the panel after the overlay button. Entry = toolbar C, **not** a tab-strip pill. Never claim CMspark sits beside the tab bar. |
 | Side Panel | **Operate** | ChatShell empty: **要对这页做什么** / **当前页：** / 3 template chips. Top bar **弹出对话框** opens the HTML float. 装配 stays outside the shell. Watching Chrome; ~320px. |
 | Background CDP | **Operate** | When the human is in summoner or a coding agent; extension must be connected |
 | 确认台 / Cockpit + Mac tray | **Confirm** | Allow/Deny lives here. Overlay never. Win/Linux: open Chrome 确认台, never skip |
diff --git a/README.md b/README.md
index d488d1ac..96a5cf9b 100644
--- a/README.md
+++ b/README.md
@@ -13,7 +13,7 @@ CMspark 是本机 Companion + Chrome 扩展（Plasmo）的双层 Agent。人盯
 
 | 面 | 入口 | 做什么 |
 |----|------|--------|
-| **Capture** | 热键 / 工具栏 C / 侧栏「弹出对话框」 | HTML 卡 **360×420**（流式出字、📎、听写、会议）。**永不** Allow/Deny |
+| **Capture** | 热键 / 工具栏 C / 侧栏「弹出对话框」 | HTML 卡默认 **1040×760**（紧凑切换 **360×420**；流式出字、📎、听写、会议）。**永不** Allow/Deny |
 | **Operate** | Side Panel ~320px，或后台 CDP | 盯着页时聊+点；人不在侧栏时仍可动已登录 Chrome |
 | **Confirm** | 确认台 / Mac 托盘 | 高危审批与急停。Win/Linux 必须开 Chrome 确认台 |
 | **租手** | Outbound MCP + `cmg_` 钥匙 | 外部编程助手当 client，调 `cmspark__*`。实验、非 default-on |
@@ -50,13 +50,15 @@ Companion **从不**调用 `chrome.sidePanel.open`；打不开侧栏时 toast **
 
 | 归属 | 能力 | 说明 | 文档 |
 |------|------|------|------|
-| **Capture** | 召唤器 HTML 卡 | 360×420；流式出字；永不审批 | 本页 [召唤器](#召唤器capture) · [PRODUCT.md](PRODUCT.md) |
+| **Capture** | 召唤器 HTML 卡 | 默认 1040×760；紧凑 360×420；流式出字；永不审批 | 本页 [召唤器](#召唤器capture) · [PRODUCT.md](PRODUCT.md) |
 | **L0 · 主体** | 自然语言 · 多线程 · 历史 | Side Panel ChatShell（空态「要对这页做什么」/「弹出对话框」）；线程隔离；SQLite 操作史 | 本页 [使用指南](#使用指南) |
 | **L0 产品特性** | Obsidian 导出 · Mermaid · NotebookLM | 导出/渲染/导入（**非**组合原语） | [ADR-008](docs/adr/008-obsidian-export.md) · [009](docs/adr/009-mermaid-rendering.md) · [notebooklm-user-guide](docs/notebooklm-user-guide.md) |
 | **L0 输入** | 听写+ · 本机 STT · 会议记录 | classic/连续/按住热键；Whisper 渐进假设；场景「会议」工作台 | [meeting-and-dictation-user-guide](docs/meeting-and-dictation-user-guide.md) · [ADR-023](docs/adr/023-voice-local-stt-path-b.md) · [ADR-024](docs/adr/024-dictation-plus-asr-refiner-meeting.md) |
 | **L1 · 浅层** | 浏览器 CDP 操控 | 标签页、页面读写、点击/填表、截图、导航等 | 本页 [浏览器操作示例](#浏览器操作示例) |
 | **L1** | Cookie 信任域 | `trusted_domains` 门控 cookie；SSO 场景基础 | [Cookie 信任域](#cookie-信任域) · [ADR-005](docs/adr/005-cookie-trust-domain-security.md) |
-| **组合面** | Skills · Knowledge | Markdown+YAML Skills；知识注入 System Prompt | [Skills](#技能系统skills) · [Knowledge](#知识库knowledge) |
+| **组合面** | Skills · Knowledge | Markdown+YAML Skills；知识默认 TF-IDF top-k 注入 System Prompt | [Skills](#技能系统skills) · [Knowledge](#知识库knowledge) |
+| **组合面** | 知识图谱 | 低语料画布 + 可选「让 AI 整理」（#427）；非本体/双链 | 本页 [知识库](#知识库knowledge) |
+| **组合面** | `search_threads` / `search_knowledge` | L1 只读：历史标题/摘要与知识笔记（#439）；不回消息原文 | [CHANGELOG `[0.6.5]`](CHANGELOG.md) |
 | **组合面** | MCP（入站） | 外接 stdio/HTTP server，`mcp__<server>__<tool>` | [mcp.md](docs/mcp.md) |
 | **租手** | Outbound MCP | 我们当 server：`cmspark__*` + `cmg_`（≠ `ws_secret`，≠ 编程接力） | [mcp.md 5 分钟租手](docs/mcp.md#outbound-mcp) · [ADR-022](docs/adr/022-outbound-mcp-server.md) |
 | **组合面** | Mission Pack / 企业模块 | 任务包装配线程；appsec / workspace / shell / netsec | [mission-pack-usage](docs/mission-pack-usage.md) |
@@ -65,7 +67,8 @@ Companion **从不**调用 `chrome.sidePanel.open`；打不开侧栏时 toast **
 | **Autonomy** | Multi-Agent · Mission Board（P0） | Orchestrator + tab 锁；黑板 `board_*` | [multi-agent-user-guide](docs/multi-agent-user-guide.md) |
 | **Autonomy** | 巡航档位 · plan_readonly · 无人值守 loop | 发送键旁四档芯片（#325）；线程级只读计划帽（#327）；L-1/L-3/L-5 loop（#386–#391，**默认关**；独立 ADR 待补） | [CHANGELOG `[0.6.0]`](CHANGELOG.md) |
 | **组合面** | 专家团队（`kind: expert`） | 七个预置角色 Pack + 一张 L2 卡组队（#366–#371；persona ≠ 权限） | [CHANGELOG `[0.6.0]`](CHANGELOG.md) · [ADR-014](docs/adr/014-mission-pack-enterprise-modules.md)/[020](docs/adr/020-capability-model-three-axes.md) 修订段 |
-| **L2 · 深层 / opt-in** | Computer Use · Host Use · Apps | 桌面操控、宿主读写/应用白名单；平台相关、默认关 | [computer-use-user-guide](docs/computer-use-user-guide.md) · [host-and-apps](docs/host-and-apps.md) |
+| **L2 · 深层 / opt-in** | Computer Use · Host Use · Apps | 桌面操控、宿主读写/应用白名单；平台相关、默认关。CU 视觉定位仍 **实验**（仅 Qwen3-VL；#363 摘帽门未过） | [computer-use-user-guide](docs/computer-use-user-guide.md) · [host-and-apps](docs/host-and-apps.md) |
+| **L2 / opt-in** | 内嵌终端（PTY） | Darwin-only；默认关；Windows/Linux `unsupported`（#432） | [CHANGELOG `[0.6.4]`](CHANGELOG.md) |
 | **运维** | Daemon · 托盘 · 配对 | 开机自启；macOS 托盘 + 配对码 | 本页 [后台常驻服务](#后台常驻服务跨平台) |
 
 ### 系统拓扑
@@ -209,7 +212,7 @@ Companion 默认在 `ws://127.0.0.1:23401` 启动 WebSocket 服务。
 ### 快速开始
 
 1. **装好 Companion + 扩展**（见上文 [安装](#安装)）。托盘起来后扩展要配对。
-2. **开口（Capture）**：热键、工具栏 **C**，或侧栏顶栏 **弹出对话框**，打开同一张 HTML 卡（360×420，流式出字）。失败 toast：**请点工具栏 C**。
+2. **开口（Capture）**：热键、工具栏 **C**，或侧栏顶栏 **弹出对话框**，打开同一张 HTML 卡（默认 1040×760，流式出字；可切紧凑 360×420）。失败 toast：**请点工具栏 C**。
 3. **盯着页面时（Operate）**：点工具栏 C 打开 Side Panel；空态是「要对这页做什么」+ 当前页 + 3 个芯片，不是空白聊天机器人。
 4. **危险（Confirm）**：Allow/Deny **只**在确认台 / Mac 托盘。悬浮卡上没有批准按钮。
 5. **租手**：Codex 等走 Outbound MCP（[5 分钟租手](docs/mcp.md#outbound-mcp)），钥匙 `cmg_`，**不要**把 `ws_secret` 当 grant。
@@ -220,7 +223,7 @@ Companion 默认在 `ws://127.0.0.1:23401` 启动 WebSocket 服务。
 
 Mac 菜单/热键与侧栏「弹出对话框」是**同一张卡**。卡上：问答、📎、听写、开始/结束会议、**打开浏览器并打开侧栏**。Companion 进程不调 `chrome.*`；扩展 SW 才开侧栏。
 
-- 尺寸：**360×420**（代码 `OVERLAY_WINDOW_SIZE`）
+- 尺寸：默认 **1040×760**（代码 `OVERLAY_WINDOW_SIZE`）；紧凑切换 **360×420**
 - **永不** Allow/Deny；确认永远在确认台
 - HTML 卡跟 `chat.token` **流式出字**（Swift 旧条本已流式）
 - 不是 WorkBuddy 五轨工作台；禁止「去侧栏批准」文案
@@ -331,7 +334,7 @@ Knowledge 是**背景资料注入机制**，告诉 AI「需要了解什么」。
 
 **两种知识类型**：
 - `domain_knowledge`：全局知识，不绑定网站（如 API 文档、编码规范）
-- `site_knowledge`：绑定特定域名；在**自动**模式下，当前活动标签页域名匹配时自动注入
+- `site_knowledge`：绑定特定域名；在**自动**模式下，当前活动标签页 hostname 命中只做 **候选加权**，再走 TF-IDF top-k / 预算 / 分数门槛（不是该站全灌）
 
 **知识文档格式**：
 
@@ -361,13 +364,17 @@ Sprint 周期两周，每周一开始。
 提交前需关联 Confluence 文档链接。
 ```
 
-**三种注入模式**（在「知识」面板顶部切换，按线程保存）：
-- **自动**（默认，推荐）：手动勾选的知识 ∪ **当前活动标签页 hostname 匹配的 `site_knowledge`**
-- **全选**：所有知识文档全部注入（上下文大，适合文档研读）
-- **按需**：只用手动勾选（✓）的文档
+**三种注入模式**（在「知识」面板顶部切换，按线程保存；默认 **智能匹配**）：
+- **自动**（默认，推荐）：按这轮问题做 TF-IDF 打分，文档级 top-k **`KNOWLEDGE_DOC_TOPK_AUTO=5`**；已勾选（钉住）的优先全入。站点 hostname 命中只做 **候选加权**（`KNOWLEDGE_SITE_BOOST`），**不是**「该站全部文档都灌进 prompt」。
+- **全选**：在**全库**里同样检索，top-k **`KNOWLEDGE_DOC_TOPK_ALL=8`**，仍受条数/长度上限——**不是**「所有知识文档全部注入」。
+- **按需**：只用手动勾选（✓）的文档（不打分；超预算从末尾截断）。
+
+跨文档硬预算 **`KNOWLEDGE_INJECT_BUDGET_CHARS=8000`**；未达分数门槛 **`KNOWLEDGE_SCORE_MIN=0.10`** 的不入选（钉住除外）。关掉智能匹配才退回旧行为（自动 = 勾选 ∪ 站点候选；全选 = 列表序灌库，仍截预算）。
 
 #### 站点知识如何自动匹配
 
+hostname 匹配是 **候选过滤 / 排序加权**，不是「匹配到的站点文档全部注入」。默认智能匹配仍走上面的 top-k + 预算 + 分数门槛。
+
 1. **文档侧**：frontmatter 必须同时具备  
    - `type: site_knowledge`  
    - `site: example.com` 或 `site: *.example.com`  
@@ -405,7 +412,7 @@ Sprint 周期两周，每周一开始。
 **与「技能」面板的边界**：Skills 列表只含流程类 skill（`prompt_template` 等）；`knowledge/` 下的笔记（含 vault 的 goal/task 等）只出现在「知识」面板，不会混进「技能」。
 
 **典型使用场景**：
-1. **内部系统操作**：把 URL 结构、登录方式写成 `site_knowledge`，绑定系统域名；打开该站再聊天即自动带上  
+1. **内部系统操作**：把 URL 结构、登录方式写成 `site_knowledge`，绑定系统域名；打开该站再聊天时该篇进入自动模式候选（仍受 top-k / 预算 / 分数门槛）  
 2. **研发助手**：团队规范、架构说明导入为 `domain_knowledge`  
 3. **产品调研**：竞品资料按域名拆成多篇 `site_knowledge`，浏览对应站时自动对齐上下文  
 
@@ -842,8 +849,8 @@ make package
 ```bash
 make package-macos
 # 产出：
-#   dist-package/CMspark-v0.6.0-macOS.dmg   ← 安装包
-#   dist-package/cmspark-v0.6.0-macos-arm64.zip  ← 原始压缩包
+#   dist-package/CMspark-v0.6.7-macOS.dmg   ← 安装包
+#   dist-package/cmspark-v0.6.7-macos-arm64.zip  ← 原始压缩包
 ```
 
 Windows 打包流程（**官方 zip + Setup.exe / package.sh**）：
@@ -977,4 +984,4 @@ cmspark/
 
 ---
 
-> **当前阶段（0.6.0）**：家 = **已登录 Chrome + 硬闸**（[PRODUCT.md](PRODUCT.md)）。召唤器 HTML **流式出字** · Whisper 自动激活/当次会话回退横幅/HF 镜像 · 会议说话人「自动」档。**听写+ / 会议 / 本机 Whisper** 已交付；**对话框可粘贴/点选/拖入图片**；**Windows 官方 NSIS Setup.exe**；**知识 CRUD 诚实**（AI 草稿 / 检索打分 / 分布视图 / 多级文件夹 / sha256 去重）；**侧栏 UI 重构 + 巡航档位/plan_readonly/无人值守 loop 三件套 + 专家团队 v1 + CU 完整性链**（0.6.0 主题，值守默认关）；**租手钥匙 CLI + L8**；ChatShell 空态 + **弹出对话框**；技能 TF-IDF + 当轮活计划（页面工具前必须 propose；成功后才挂卡；放弃/纯问答则无卡）。**不是**召唤器/租手完成切点——T1 已记分（CMspark 臂 Y / Playwright 打不开门户），**禁扩**默认 outbound profile（[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）。CU 实验定位仅 **Qwen3-VL**。能力按 **[ADR-020](docs/adr/020-capability-model-three-axes.md)** 三轴组织。文档导航：[`docs/README.md`](docs/README.md) · [architecture.md](docs/architecture.md)。
+> **当前阶段（0.6.7）**：家 = **已登录 Chrome + 硬闸**（[PRODUCT.md](PRODUCT.md)）。Capture 默认 **1040×760**（紧凑 **360×420**）· 知识默认 TF-IDF top-k 注入 · 知识图谱（#427）· Darwin 内嵌终端（#432，默认关）· `search_threads`/`search_knowledge`（#439）。召唤器 HTML **流式出字** · Whisper 自动激活/当次会话回退横幅/HF 镜像 · 会议说话人「自动」档。**听写+ / 会议 / 本机 Whisper** 已交付；**对话框可粘贴/点选/拖入图片**；**Windows 官方 NSIS Setup.exe**（`node.exe` + `cmspark-agent.js`）；**知识 CRUD 诚实**（AI 草稿 / 检索打分 / 分布视图 / 多级文件夹 / sha256 去重）；**侧栏 UI 重构 + 巡航档位/plan_readonly/无人值守 loop 三件套 + 专家团队 v1 + CU 完整性链**（0.6.0 主题，值守默认关）；**租手钥匙 CLI + L8**；ChatShell 空态 + **弹出对话框**；技能 TF-IDF + 当轮活计划（页面工具前必须 propose；成功后才挂卡；放弃/纯问答则无卡）。**不是**召唤器/租手完成切点——T1 已记分（CMspark 臂 Y / Playwright 打不开门户），**禁扩**默认 outbound profile（[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）。CU 实验定位仅 **Qwen3-VL**（#363 摘帽门未过）。能力按 **[ADR-020](docs/adr/020-capability-model-three-axes.md)** 三轴组织。文档导航：[`docs/README.md`](docs/README.md) · [architecture.md](docs/architecture.md)。
diff --git a/chrome-extension/package-lock.json b/chrome-extension/package-lock.json
index 30e71fd3..c3ac4228 100644
--- a/chrome-extension/package-lock.json
+++ b/chrome-extension/package-lock.json
@@ -1,12 +1,12 @@
 {
   "name": "cmspark-browser-agent",
-  "version": "0.6.3",
+  "version": "0.6.7",
   "lockfileVersion": 3,
   "requires": true,
   "packages": {
     "": {
       "name": "cmspark-browser-agent",
-      "version": "0.6.3",
+      "version": "0.6.7",
       "hasInstallScript": true,
       "dependencies": {
         "@xterm/addon-fit": "^0.11.0",
diff --git a/chrome-extension/package.json b/chrome-extension/package.json
index 5f272f78..0d25448f 100644
--- a/chrome-extension/package.json
+++ b/chrome-extension/package.json
@@ -1,7 +1,7 @@
 {
   "name": "cmspark-browser-agent",
   "displayName": "CMspark Browser Agent",
-  "version": "0.6.6",
+  "version": "0.6.7",
   "description": "AI-powered browser agent — read, operate tabs, use cookies, configure LLM, support skills",
   "author": "cmspark",
   "scripts": {
diff --git a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
index 75b355b4..e46a3a4b 100644
--- a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
+++ b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
@@ -274,23 +274,37 @@ export function ContextPanelHostProvider({
  */
 export function ContextPanelHost() {
   const { activePanel, closePanel } = useContextPanelHost()
+  const meetingCaptureActive = useAgentStore().state.meetingCaptureActive
   if (!activePanel) return null
 
   const label = contextPanelLabel(activePanel)
+  const closeEndsMeeting = activePanel === "meeting" && meetingCaptureActive
 
   return (
     <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
       <div style={styles.panelHeader}>
         <span style={styles.panelTitle}>{label}</span>
-        <button
-          type="button"
-          style={styles.panelCloseBtn}
-          title="收起面板 (Esc)"
-          aria-label="收起面板"
-          onClick={closePanel}
-        >
-          收起
-        </button>
+        {closeEndsMeeting ? (
+          <button
+            type="button"
+            style={styles.panelCloseBtn}
+            title="结束并收起"
+            aria-label="结束并收起"
+            onClick={closePanel}
+          >
+            结束并收起
+          </button>
+        ) : (
+          <button
+            type="button"
+            style={styles.panelCloseBtn}
+            title="收起面板 (Esc)"
+            aria-label="收起面板"
+            onClick={closePanel}
+          >
+            收起
+          </button>
+        )}
       </div>
       {activePanel === "tabs" && <TabsPanel />}
       {activePanel === "history" && <HistoryPanel />}
diff --git a/chrome-extension/src/sidepanel/components/MeetingPanel.tsx b/chrome-extension/src/sidepanel/components/MeetingPanel.tsx
index aeb8548f..089dfeab 100644
--- a/chrome-extension/src/sidepanel/components/MeetingPanel.tsx
+++ b/chrome-extension/src/sidepanel/components/MeetingPanel.tsx
@@ -503,13 +503,13 @@ export function MeetingPanel(props: {
         return
       }
       if (!state.voicePrivacyAckV2) {
-        setError("请先确认下方「本机语音隐私说明」（或：设置 › 听写 › 启用本机转写）")
+        setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
         setPhase("idle")
         sendViaRuntime({ type: "meeting.end", v: 1, id })
         return
       }
       if (!localModelReady || !localBinaryReady) {
-        setError("本机转写模型或二进制未就绪。请到设置 → 语音 下载模型后再开始会议录音。")
+        setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型后再开始会议录音。")
         setPhase("idle")
         sendViaRuntime({ type: "meeting.end", v: 1, id })
         return
@@ -765,11 +765,11 @@ export function MeetingPanel(props: {
       return
     }
     if (!state.voicePrivacyAckV2) {
-      setError("请先确认下方「本机语音隐私说明」（或：设置 › 听写 › 启用本机转写）")
+      setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
       return
     }
     if (!localModelReady || !localBinaryReady) {
-      setError("本机转写模型或二进制未就绪。请到设置 → 语音 下载模型。")
+      setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型。")
       try {
         chrome.runtime.sendMessage({ type: "voice.model.get_state" })
       } catch {
@@ -933,7 +933,7 @@ export function MeetingPanel(props: {
       return
     }
     if (!state.voicePrivacyAckV2) {
-      setError("导入音频需先确认「本机语音隐私说明」（见下方卡片，或设置 › 听写 › 启用本机转写）")
+      setError("导入音频需先确认「本机语音隐私说明」（见下方卡片，或设置 → 输入与语音 → 启用本机转写）")
       return
     }
     if (!localModelReady || !localBinaryReady) {
@@ -1268,7 +1268,7 @@ export function MeetingPanel(props: {
             本机语音隐私说明
           </div>
           <p style={{ margin: "0 0 6px", fontSize: 10 }}>
-            会议本机录音 / 上传音频转写前须确认。也可在：侧栏 ⋯ → 设置 → 听写 →
+            会议本机录音 / 上传音频转写前须确认。也可在：侧栏 ⋯ → 设置 → 输入与语音 →
             「启用本机转写」。
           </p>
           <ul style={{ margin: 0, paddingLeft: 18 }}>
@@ -1300,7 +1300,7 @@ export function MeetingPanel(props: {
           </button>
           {!localModelReady || !localBinaryReady ? (
             <div style={{ marginTop: 6, fontSize: 10, color: tokens.warning }}>
-              模型或本机组件未就绪时：侧栏 ⋯ → 设置 → 听写 → 下载组件/模型 → 启用本机转写。
+              模型或本机组件未就绪时：侧栏 ⋯ → 设置 → 输入与语音 → 下载组件/模型 → 启用本机转写。
             </div>
           ) : null}
         </div>
@@ -1580,7 +1580,7 @@ export function MeetingPanel(props: {
             disabled={busy || capturing || !ack}
             onClick={() => runAutoDiarize("embedding")}
             style={btnStyle(true)}
-            title="上传音频段 → 本机 ONNX 说话人嵌入 + 聚类；只标匿名发言人N，非身份识别（需先在 设置 → 听写方式 下载说话人分离模型）"
+            title="上传音频段 → 本机 ONNX 说话人嵌入 + 聚类；只标匿名发言人N，非身份识别（需先在 设置 → 输入与语音 → 听写方式 下载说话人分离模型）"
           >
             自动标说话人
           </button>
diff --git a/chrome-extension/src/sidepanel/components/ThreadList.tsx b/chrome-extension/src/sidepanel/components/ThreadList.tsx
index 44f6a695..8e047144 100644
--- a/chrome-extension/src/sidepanel/components/ThreadList.tsx
+++ b/chrome-extension/src/sidepanel/components/ThreadList.tsx
@@ -42,6 +42,8 @@ import {
   threadIdsInDay,
   threadIdsInMonth,
   toggleGroupSelection,
+  selectAllIds,
+  allSelectableSelected,
   type MonthGroup,
   type DayGroup,
   type ThreadListExpandState,
@@ -117,7 +119,7 @@ export function ThreadList() {
   const [open, setOpen] = useState(false)
   const [editingThread, setEditingThread] = useState<Thread | null>(null)
   const [metadataNotice, setMetadataNotice] = useState("")
-  useEffect(() => { if (!open) { setEditingThread(null); setMetadataNotice("") } }, [open])
+  useEffect(() => { if (!open) { setEditingThread(null); setMetadataNotice(""); setPendingDelete(null) } }, [open])
   useEffect(() => {
     const show = () => { if (!state.pendingSecurityConfirmations.length) setOpen(true) }
     window.addEventListener("cmspark:open-thread-manager", show)
@@ -174,6 +176,16 @@ export function ThreadList() {
   const [cleanupSelected, setCleanupSelected] = useState<Set<string>>(() => new Set())
   /** 0 = 全部（含近期） */
   const [cleanupDays, setCleanupDays] = useState(0)
+  /** In-panel confirm: Side Panel often swallows window.confirm (delete looks dead). */
+  const [pendingDelete, setPendingDelete] = useState<{
+    ids: string[]
+    hard: boolean
+    source: "row" | "batch" | "cleanup"
+  } | null>(null)
+  useEffect(() => {
+    if (!pendingDelete) return
+    historyRef.current?.querySelector("[role='alertdialog']")?.scrollIntoView({ block: "nearest" })
+  }, [pendingDelete])
   /** Wave C: seed for related list; graph focus */
   const [relatedSeedId, setRelatedSeedId] = useState<string | null>(null)
   /** Companion thread.related override (local mirror first; WS may refine). */
@@ -747,39 +759,71 @@ export function ThreadList() {
       alert("该线程正在运行，无法删除")
       return
     }
-    if (trashView) {
-      if (!confirm(`永久删除线程 "${threadId}"？不可恢复。`)) return
-      dispatch({ type: "REMOVE_THREAD", threadId })
-      chrome.runtime.sendMessage({ type: "thread.delete", thread_id: threadId, mode: "hard" })
-      return
-    }
-    if (confirm(`将线程移入回收站？\n可在 ⋯ → 回收站 中恢复（约 30 天后自动清理）。`)) {
-      dispatch({ type: "REMOVE_THREAD", threadId })
-      chrome.runtime.sendMessage({ type: "thread.delete", thread_id: threadId, mode: "trash" })
-    }
+    setPendingDelete({ ids: [threadId], hard: trashView, source: "row" })
   }
 
   const handleBatchDelete = () => {
-    const ids = [...selected].filter((id) => selectableIds.has(id))
-    if (ids.length === 0) return
-    const preview = ids.slice(0, 12).join(", ") + (ids.length > 12 ? " …" : "")
-    if (trashView) {
-      if (!confirm(`永久删除 ${ids.length} 个会话？不可恢复。\n\n${preview}`)) return
+    let ids = [...selected].filter((id) => selectableIds.has(id))
+    if (ids.length === 0) {
+      ids = [...selectableIds]
+      if (ids.length === 0) return
+      setSelected(new Set(ids))
+      setSelectMode(true)
+    }
+    setPendingDelete({ ids, hard: trashView, source: "batch" })
+  }
+
+  const executePendingDelete = () => {
+    if (!pendingDelete || pendingDelete.ids.length === 0) return
+    const { ids, hard, source } = pendingDelete
+    const mode = hard ? "hard" : "trash"
+    if (ids.length === 1) {
+      dispatch({ type: "REMOVE_THREAD", threadId: ids[0] })
+      chrome.runtime.sendMessage({ type: "thread.delete", thread_id: ids[0], mode }, () => {
+        void chrome.runtime.lastError
+      })
+    } else {
       dispatch({ type: "REMOVE_THREADS", threadIds: ids })
-      chrome.runtime.sendMessage({ type: "thread.batch_delete", thread_ids: ids, mode: "hard" })
-      exitSelectMode()
-      return
+      chrome.runtime.sendMessage({ type: "thread.batch_delete", thread_ids: ids, mode }, () => {
+        void chrome.runtime.lastError
+      })
     }
-    if (
-      !confirm(
-        `将 ${ids.length} 个会话移入回收站？\n可稍后恢复（约 30 天后自动清理）。\n\n${preview}`,
+    setPendingDelete(null)
+    if (source === "batch") exitSelectMode()
+    if (source === "cleanup") {
+      setCleanupOpen(false)
+      setCleanupSuggestions([])
+      setCleanupSelected(new Set())
+    }
+  }
+
+  const handleSelectAllVisible = () => {
+    if (cleanupOpen && cleanupSuggestions.length > 0) {
+      setCleanupSelected(
+        new Set(cleanupSuggestions.map((s) => s.thread_id).filter(Boolean).slice(0, 50)),
       )
-    ) {
       return
     }
-    dispatch({ type: "REMOVE_THREADS", threadIds: ids })
-    chrome.runtime.sendMessage({ type: "thread.batch_delete", thread_ids: ids, mode: "trash" })
-    exitSelectMode()
+    const ids = selectAllIds(selectableIds)
+    setSelectMode(true)
+    setSelected(ids)
+    const months = timeline.months.map((m) => m.monthKey)
+    const days = new Set<string>()
+    for (const m of timeline.months) {
+      for (const d of m.days) days.add(d.dayKey)
+    }
+    const nextExpand = { months, today: true, yesterday: true }
+    setExpandState(nextExpand)
+    saveExpandState(nextExpand)
+    setExpandedDays(days)
+  }
+
+  const handleClearVisibleSelection = () => {
+    if (cleanupOpen && cleanupSuggestions.length > 0) {
+      setCleanupSelected(new Set())
+      return
+    }
+    setSelected(new Set())
   }
 
   const handleRestore = (ids: string[]) => {
@@ -818,28 +862,13 @@ export function ThreadList() {
   }
 
   const applyCleanupTrash = () => {
-    const ids = [...cleanupSelected].slice(0, 50)
-    if (ids.length === 0) return
-    const picked = cleanupSuggestions.filter((s) => ids.includes(s.thread_id))
-    const hasHusk = picked.some((s) => s.reason === "acp_husk")
-    const lines = picked.slice(0, 12).map((s) => {
-      const thr = threads.find((t) => t.id === s.thread_id)
-      const n = thr?.message_count
-      return `#${s.thread_id}${typeof n === "number" ? ` · ${n} 条消息` : ""}`
-    })
-    const more = picked.length > 12 ? `\n…另 ${picked.length - 12} 个` : ""
-    const warn = hasHusk ? "\n含编程接力记录，请再核对。" : ""
-    if (
-      !confirm(
-        `将把 ${ids.length} 个会话移入回收站（可在 ⋯ → 回收站 恢复，约 30 天后自动清除）。${warn}\n\n${lines.join("\n")}${more}`,
-      )
-    ) {
-      return
+    let ids = [...cleanupSelected].slice(0, 50)
+    if (ids.length === 0) {
+      ids = cleanupSuggestions.map((s) => s.thread_id).filter(Boolean).slice(0, 50)
+      if (ids.length === 0) return
+      setCleanupSelected(new Set(ids))
     }
-    chrome.runtime.sendMessage({ type: "thread.batch_delete", thread_ids: ids, mode: "trash" })
-    dispatch({ type: "REMOVE_THREADS", threadIds: ids })
-    setCleanupOpen(false)
-    setCleanupSuggestions([])
+    setPendingDelete({ ids, hard: false, source: "cleanup" })
   }
 
   /** B-4: extract digests for cleanup-selected threads only (no delete). */
@@ -850,7 +879,7 @@ export function ThreadList() {
     beginExtractBatch(ids, force)
   }
 
-  const panelMaxHeight = selectMode || view === "tags" || view === "topics" || view === "ai" ? 480 : 360
+  const panelMaxHeight = selectMode || cleanupOpen || view === "tags" || view === "topics" || view === "ai" ? 480 : 360
 
   useEffect(() => {
     if (!open) {
@@ -1014,6 +1043,7 @@ export function ThreadList() {
         {!selectMode && (
           <>
             <button
+              type="button"
               style={styles.iconBtn}
               onClick={(e) => {
                 e.stopPropagation()
@@ -1024,6 +1054,7 @@ export function ThreadList() {
               🔗
             </button>
             <button
+              type="button"
               style={styles.iconBtn}
               onClick={(e) => {
                 e.stopPropagation()
@@ -1034,6 +1065,7 @@ export function ThreadList() {
               🏷
             </button>
             <button
+              type="button"
               style={styles.iconBtn}
               onClick={(e) => {
                 e.stopPropagation()
@@ -1045,6 +1077,7 @@ export function ThreadList() {
               知识
             </button>
             <button
+              type="button"
               style={styles.iconBtn}
               onClick={(e) => {
                 e.stopPropagation()
@@ -1056,6 +1089,7 @@ export function ThreadList() {
               分类
             </button>
             <button
+              type="button"
               style={styles.iconBtn}
               onClick={(e) => {
                 e.stopPropagation()
@@ -1074,9 +1108,11 @@ export function ThreadList() {
               {state.summarizingThreadId === t.id ? "⏳" : "🧠"}
             </button>
             <button
+              type="button"
               style={styles.iconBtn}
               onClick={(e) => handleDeleteOne(t.id, e)}
               title="删除线程"
+              aria-label={`删除 ${accessibleName}`}
             >
               🗑️
             </button>
@@ -1300,6 +1336,7 @@ export function ThreadList() {
         {listForTag && (
           <div>
             <div style={styles.groupHeader}>
+              {renderGroupCheckbox(listForTag.map((t) => t.id), activeTag === "__untagged__" ? "未标注" : `#${activeTag}`)}
               <span style={styles.groupLabel}>
                 {activeTag === "__untagged__" ? "未标注" : `#${activeTag}`} ·{" "}
                 {listForTag.length}
@@ -1336,6 +1373,7 @@ export function ThreadList() {
         {keys.map((key) => (
           <div key={key}>
             <div style={styles.groupHeader}>
+              {renderGroupCheckbox(groups.get(key)!.map((t) => t.id), key)}
               <span style={styles.groupLabel}>
                 {key} · {groups.get(key)!.length}
               </span>
@@ -1433,7 +1471,20 @@ export function ThreadList() {
                   }}
                   title="多选"
                 >
-                  {selectMode ? "取消" : "选择"}
+                  {selectMode ? "取消选择" : "选择"}
+                </button>
+                <button
+                  type="button"
+                  style={styles.selectBtn}
+                  disabled={selectableIds.size === 0}
+                  onClick={() =>
+                    allSelectableSelected(selected, selectableIds)
+                      ? handleClearVisibleSelection()
+                      : handleSelectAllVisible()
+                  }
+                  title="全选当前列表中可删除的会话"
+                >
+                  {allSelectableSelected(selected, selectableIds) ? "取消全选" : "全选"}
                 </button>
                 <button style={styles.newBtn} onClick={handleNewThread} title="新建线程">
                   + 新建
@@ -1545,7 +1596,184 @@ export function ThreadList() {
               <button type="button" onClick={() => { setCleanupOpen(true); runCleanupScan() }}>整理助手</button>
               <button type="button" onClick={openThreadGraph}>关系图谱</button>
               <button type="button" onClick={() => trashView ? closeTrashView() : openTrashView()}>{trashView ? "返回对话" : "回收站"}</button>
+              <button
+                type="button"
+                onClick={() =>
+                  (cleanupOpen && cleanupSuggestions.length > 0
+                    ? cleanupSelected.size === cleanupSuggestions.length
+                    : allSelectableSelected(selected, selectableIds))
+                    ? handleClearVisibleSelection()
+                    : handleSelectAllVisible()
+                }
+                disabled={cleanupOpen && cleanupSuggestions.length > 0 ? cleanupSuggestions.length === 0 : selectableIds.size === 0}
+                title={cleanupOpen ? "全选整理助手扫描结果" : "全选当前列表中可删除的会话"}
+              >
+                {(cleanupOpen && cleanupSuggestions.length > 0
+                  ? cleanupSelected.size === cleanupSuggestions.length && cleanupSuggestions.length > 0
+                  : allSelectableSelected(selected, selectableIds))
+                  ? "取消全选"
+                  : "全选"}
+              </button>
             </div>
+            {cleanupOpen && (
+              <div className="cm-thread-cleanup" style={styles.cleanupPanel}>
+                <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 8 }}>整理助手（规则）</div>
+                <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 8, flexWrap: "wrap" }}>
+                  <span style={{ fontSize: 11, color: tokens.textSecondary }}>扫描</span>
+                  <select
+                    value={cleanupDays}
+                    onChange={(e) => setCleanupDays(Number(e.target.value))}
+                    style={{ fontSize: 11, padding: "2px 4px" }}
+                  >
+                    <option value={0}>全部（含近期）</option>
+                    <option value={30}>30 天前以前</option>
+                    <option value={90}>90 天前以前</option>
+                  </select>
+                  <button type="button" style={styles.selectBtn} onClick={runCleanupScan}>
+                    扫描
+                  </button>
+                  <button
+                    type="button"
+                    style={styles.selectBtn}
+                    onClick={() => {
+                      setCleanupOpen(false)
+                      setCleanupSuggestions([])
+                    }}
+                  >
+                    关闭
+                  </button>
+                </div>
+                <div
+                  style={{
+                    fontSize: 10,
+                    color: tokens.textMuted,
+                    marginBottom: 6,
+                  }}
+                >
+                  索引健康：未标注 {lintStats.untagged} · 过期 {lintStats.stale} · 孤立{" "}
+                  {lintStats.isolated}
+                </div>
+                {cleanupSuggestions.length === 0 ? (
+                  <div style={{ fontSize: 11, color: tokens.textMuted }}>
+                    空会话 / 无用户消息 / 极短孤消息 / 过久且少 / 同名薄会话（不含簇主）
+                  </div>
+                ) : (
+                  <>
+                    <div style={{ maxHeight: 160, overflowY: "auto" }}>
+                      {cleanupSuggestions.map((s) => {
+                        const thr = threads.find((t) => t.id === s.thread_id)
+                        const title = thr
+                          ? displayThreadTitle(thr as Thread)
+                          : s.thread_id
+                        return (
+                          <label
+                            key={`${s.thread_id}-${s.reason}`}
+                            style={{
+                              display: "flex",
+                              gap: 6,
+                              alignItems: "flex-start",
+                              fontSize: 11,
+                              padding: "4px 0",
+                              borderBottom: `1px solid ${tokens.border}`,
+                            }}
+                          >
+                            <input
+                              type="checkbox"
+                              checked={cleanupSelected.has(s.thread_id)}
+                              onChange={() => {
+                                setCleanupSelected((prev) => {
+                                  const next = new Set(prev)
+                                  if (next.has(s.thread_id)) next.delete(s.thread_id)
+                                  else next.add(s.thread_id)
+                                  return next
+                                })
+                              }}
+                            />
+                            <span>
+                              <strong>{title}</strong>
+                              <span style={{ color: tokens.textMuted }}>
+                                {" "}
+                                · {s.reason} · {s.detail}
+                              </span>
+                            </span>
+                          </label>
+                        )
+                      })}
+                    </div>
+                    <div
+                      style={{
+                        display: "flex",
+                        gap: 6,
+                        marginTop: 8,
+                        flexWrap: "wrap",
+                      }}
+                    >
+                      <button
+                        type="button"
+                        style={styles.selectBtn}
+                        disabled={cleanupSelected.size === 0}
+                        onClick={applyCleanupExtractOnly}
+                        title="仅提取要点/标签，不删除"
+                      >
+                        仅提取要点（{Math.min(cleanupSelected.size, EXTRACT_DIGEST_MAX)}）
+                      </button>
+                      <button
+                        type="button"
+                        style={styles.selectBtn}
+                        onClick={() => {
+                          const ids = cleanupSuggestions.map((s) => s.thread_id).slice(0, 50)
+                          setCleanupSelected(new Set(ids))
+                        }}
+                      >
+                        全选
+                      </button>
+                      <button
+                        type="button"
+                        style={styles.selectBtn}
+                        onClick={() => setCleanupSelected(new Set())}
+                      >
+                        全不选
+                      </button>
+                      <button
+                        type="button"
+                        style={styles.dangerBtn}
+                        disabled={cleanupSelected.size === 0}
+                        onClick={applyCleanupTrash}
+                      >
+                        移入回收站（{cleanupSelected.size}）
+                      </button>
+                    </div>
+                  </>
+                )}
+              </div>
+            )}
+            {pendingDelete && (
+              <div
+                role="alertdialog"
+                aria-label="确认删除会话"
+                style={styles.pendingDelete}
+              >
+                <p style={{ margin: 0, fontSize: 12, lineHeight: 1.5 }}>
+                  {pendingDelete.hard
+                    ? `永久删除 ${pendingDelete.ids.length} 个会话？不可恢复。`
+                    : `将 ${pendingDelete.ids.length} 个会话移入回收站？可在回收站恢复（约 30 天后自动清理）。`}
+                  {pendingDelete.source === "cleanup" &&
+                  cleanupSuggestions.some(
+                    (s) => pendingDelete.ids.includes(s.thread_id) && s.reason === "acp_husk",
+                  )
+                    ? " 含编程接力记录，请再核对。"
+                    : ""}
+                </p>
+                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
+                  <button type="button" style={styles.dangerBtn} onClick={executePendingDelete}>
+                    {pendingDelete.hard ? "永久删除" : "移入回收站"}
+                  </button>
+                  <button type="button" style={styles.selectBtn} onClick={() => setPendingDelete(null)}>
+                    取消
+                  </button>
+                </div>
+              </div>
+            )}
             {view === "ai" && <p className="cm-thread-management-help">按 AI 提取的首个主题标签自动分组；重新提取可能调整 AI 分组，不改变手动分组。点击“AI 提取标签”为最多20个未标注对话提取标签。</p>}
             {view === "tags" && <p className="cm-thread-management-help">汇总人工与 AI 标签；点对话右侧“分类”管理人工标签。</p>}
             {metadataNotice && <p className="cm-thread-management-help" role="status">{metadataNotice}</p>}
@@ -1655,6 +1883,18 @@ export function ThreadList() {
                   已选 {selected.size}
                 </span>
                 <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
+                  <button
+                    type="button"
+                    style={styles.selectBtn}
+                    disabled={selectableIds.size === 0}
+                    onClick={() =>
+                      allSelectableSelected(selected, selectableIds)
+                        ? handleClearVisibleSelection()
+                        : handleSelectAllVisible()
+                    }
+                  >
+                    {allSelectableSelected(selected, selectableIds) ? "取消全选" : "全选"}
+                  </button>
                   {trashView ? (
                     <button
                       type="button"
@@ -1705,129 +1945,6 @@ export function ThreadList() {
                 </div>
               </div>
             )}
-
-            {cleanupOpen && (
-              <div style={styles.cleanupPanel}>
-                <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 8 }}>整理助手（规则）</div>
-                <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 8 }}>
-                  <span style={{ fontSize: 11, color: tokens.textSecondary }}>扫描</span>
-                  <select
-                    value={cleanupDays}
-                    onChange={(e) => setCleanupDays(Number(e.target.value))}
-                    style={{ fontSize: 11, padding: "2px 4px" }}
-                  >
-                    <option value={0}>全部（含近期）</option>
-                    <option value={30}>30 天前以前</option>
-                    <option value={90}>90 天前以前</option>
-                  </select>
-                  <button type="button" style={styles.selectBtn} onClick={runCleanupScan}>
-                    扫描
-                  </button>
-                  <button
-                    type="button"
-                    style={styles.selectBtn}
-                    onClick={() => {
-                      setCleanupOpen(false)
-                      setCleanupSuggestions([])
-                    }}
-                  >
-                    关闭
-                  </button>
-                </div>
-                <div
-                  style={{
-                    fontSize: 10,
-                    color: tokens.textMuted,
-                    marginBottom: 6,
-                  }}
-                >
-                  索引健康：未标注 {lintStats.untagged} · 过期 {lintStats.stale} · 孤立{" "}
-                  {lintStats.isolated}
-                </div>
-                {cleanupSuggestions.length === 0 ? (
-                  <div style={{ fontSize: 11, color: tokens.textMuted }}>
-                    空会话 / 无用户消息 / 极短孤消息 / 过久且少 / 同名薄会话（不含簇主）
-                  </div>
-                ) : (
-                  <>
-                    <div style={{ maxHeight: 160, overflowY: "auto" }}>
-                      {cleanupSuggestions.map((s) => {
-                        const thr = threads.find((t) => t.id === s.thread_id)
-                        const title = thr
-                          ? displayThreadTitle(thr as Thread)
-                          : s.thread_id
-                        return (
-                          <label
-                            key={`${s.thread_id}-${s.reason}`}
-                            style={{
-                              display: "flex",
-                              gap: 6,
-                              alignItems: "flex-start",
-                              fontSize: 11,
-                              padding: "4px 0",
-                              borderBottom: `1px solid ${tokens.border}`,
-                            }}
-                          >
-                            <input
-                              type="checkbox"
-                              checked={cleanupSelected.has(s.thread_id)}
-                              onChange={() => {
-                                setCleanupSelected((prev) => {
-                                  const next = new Set(prev)
-                                  if (next.has(s.thread_id)) next.delete(s.thread_id)
-                                  else next.add(s.thread_id)
-                                  return next
-                                })
-                              }}
-                            />
-                            <span>
-                              <strong>{title}</strong>
-                              <span style={{ color: tokens.textMuted }}>
-                                {" "}
-                                · {s.reason} · {s.detail}
-                              </span>
-                            </span>
-                          </label>
-                        )
-                      })}
-                    </div>
-                    <div
-                      style={{
-                        display: "flex",
-                        gap: 6,
-                        marginTop: 8,
-                        flexWrap: "wrap",
-                      }}
-                    >
-                      <button
-                        type="button"
-                        style={styles.selectBtn}
-                        disabled={cleanupSelected.size === 0}
-                        onClick={applyCleanupExtractOnly}
-                        title="仅提取要点/标签，不删除"
-                      >
-                        仅提取要点（{Math.min(cleanupSelected.size, EXTRACT_DIGEST_MAX)}）
-                      </button>
-                      <button
-                        type="button"
-                        style={styles.selectBtn}
-                        onClick={() => setCleanupSelected(new Set())}
-                      >
-                        全不选
-                      </button>
-                      <button
-                        type="button"
-                        style={styles.dangerBtn}
-                        disabled={cleanupSelected.size === 0}
-                        onClick={applyCleanupTrash}
-                      >
-                        移入回收站（{cleanupSelected.size}）
-                      </button>
-                    </div>
-                  </>
-                )}
-              </div>
-            )}
           </div>
 
         </>,
@@ -2178,6 +2295,21 @@ const styles: Record<string, React.CSSProperties> = {
     color: tokens.textMuted,
     marginTop: 2,
   },
+  pendingDelete: {
+    display: "flex",
+    flexWrap: "wrap",
+    gap: 8,
+    alignItems: "center",
+    justifyContent: "space-between",
+    padding: "10px 12px",
+    background: tokens.warningSoft,
+    borderBottom: `1px solid ${tokens.border}`,
+    color: tokens.text,
+    position: "sticky",
+    top: 0,
+    zIndex: 6,
+    flexShrink: 0,
+  },
   bottomBar: {
     display: "flex",
     justifyContent: "space-between",
@@ -2197,10 +2329,11 @@ const styles: Record<string, React.CSSProperties> = {
     cursor: "pointer",
   },
   cleanupPanel: {
-    borderTop: `1px solid ${tokens.border}`,
-    padding: "10px",
+    borderBottom: `1px solid ${tokens.border}`,
+    padding: "10px 12px",
     background: tokens.bgMuted,
-    maxHeight: 260,
+    maxHeight: "min(42%, 280px)",
     overflowY: "auto",
+    flexShrink: 0,
   },
 }
diff --git a/chrome-extension/src/sidepanel/ui/workspace-styles.ts b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
index dd10ca00..b863ab01 100644
--- a/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -77,11 +77,12 @@ export const workspaceCSS = `
 .cm-header-new{display:none;font-size:24px}
 .cm-nav-manage{border:0;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:12px;padding:6px;cursor:pointer}
 .cm-thread-manager-trigger{width:auto!important;gap:5px;padding:0 5px;font-size:12px;white-space:nowrap}
-.cm-history-panel{display:block!important;overflow-y:auto!important;overscroll-behavior:contain}
-.cm-thread-management-header{flex-wrap:wrap}
+.cm-history-panel{display:flex!important;flex-direction:column;overflow:hidden!important;overscroll-behavior:contain}
+.cm-thread-management-header{flex-wrap:wrap;flex-shrink:0}
 .cm-thread-management-views{flex-wrap:wrap}
-.cm-thread-management-list{overflow:visible!important;max-height:none!important}
-.cm-thread-management-actions{display:flex;gap:6px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid ${tokens.border}}
+.cm-thread-management-list{flex:1;min-height:0;overflow-y:auto!important;max-height:none!important}
+.cm-thread-management-actions{display:flex;gap:6px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
+.cm-thread-cleanup{flex-shrink:0}
 .cm-thread-management-actions button,.cm-thread-editor button{font:inherit;font-size:12px;min-height:32px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 9px;background:${tokens.bgMuted};color:${tokens.text};cursor:pointer}
 .cm-thread-management-actions button:disabled,.cm-thread-editor button:disabled{opacity:.5;cursor:not-allowed}
 .cm-thread-management-help{font-size:12px;line-height:1.6;color:${tokens.textSecondary};padding:0 12px}
diff --git a/chrome-extension/src/sidepanel/utils/thread-timeline.ts b/chrome-extension/src/sidepanel/utils/thread-timeline.ts
index b220fc4e..439570ad 100644
--- a/chrome-extension/src/sidepanel/utils/thread-timeline.ts
+++ b/chrome-extension/src/sidepanel/utils/thread-timeline.ts
@@ -454,6 +454,27 @@ export function toggleGroupSelection(
   return next
 }
 
+/** Select-all / clear-all for the currently visible selectable set. */
+export function toggleSelectAll(
+  selected: Set<string>,
+  selectableIds: Iterable<string>,
+): Set<string> {
+  return toggleGroupSelection([...selectableIds], selected)
+}
+
+/** Idempotent 全选 — never toggle. Safe under Strict Mode double-updaters. */
+export function selectAllIds(selectableIds: Iterable<string>): Set<string> {
+  return new Set(selectableIds)
+}
+
+export function allSelectableSelected(
+  selected: Set<string>,
+  selectableIds: Iterable<string>,
+): boolean {
+  const ids = [...selectableIds]
+  return ids.length > 0 && selectionState(ids, selected) === "all"
+}
+
 /** Build tag → threadIds index for Tags view (P1). */
 export function buildTagIndex(
   threads: TimelineThread[],
diff --git a/chrome-extension/src/sidepanel/voice/meeting-diarize-copy.ts b/chrome-extension/src/sidepanel/voice/meeting-diarize-copy.ts
index 0d4f311f..dc1d9913 100644
--- a/chrome-extension/src/sidepanel/voice/meeting-diarize-copy.ts
+++ b/chrome-extension/src/sidepanel/voice/meeting-diarize-copy.ts
@@ -21,7 +21,7 @@ export function formatMeetingDiarizeStatus(
  */
 export function mapMeetingDiarizeError(code: string, message?: string): string {
   if (code === "embedding_model_required") {
-    return "说话人分离模型未就绪：请到 设置 → 听写方式 下载「说话人分离模型」后重试（不会静默落回旧引擎）"
+    return "说话人分离模型未就绪：请到 设置 → 输入与语音 → 听写方式 下载「说话人分离模型」后重试（不会静默落回旧引擎）"
   }
   if (code === "diarize_runtime_unavailable") {
     return "本机推理组件不可用（onnxruntime 缺失）：请更新 Companion 后重试"
diff --git a/chrome-extension/tests/meeting-diarize-copy.test.ts b/chrome-extension/tests/meeting-diarize-copy.test.ts
index 46db8b37..82fb6cb7 100644
--- a/chrome-extension/tests/meeting-diarize-copy.test.ts
+++ b/chrome-extension/tests/meeting-diarize-copy.test.ts
@@ -27,7 +27,7 @@ test("formatMeetingDiarizeStatus embedding: 说话人嵌入 · 本机 · 非身
 
 test("mapMeetingDiarizeError: model-missing guidance, no silent fallback (#260)", () => {
   const guidance = mapMeetingDiarizeError("embedding_model_required")
-  assert.match(guidance, /设置 → 听写方式/)
+  assert.match(guidance, /设置 → 输入与语音 → 听写方式/)
   assert.match(guidance, /下载/)
   assert.match(guidance, /不会静默落回/)
   assert.equal(/识别出是谁|声纹身份|声纹/.test(guidance), false, "禁止身份识别暗示")
diff --git a/chrome-extension/tests/thread-timeline.test.ts b/chrome-extension/tests/thread-timeline.test.ts
index fba97b5e..853f7413 100644
--- a/chrome-extension/tests/thread-timeline.test.ts
+++ b/chrome-extension/tests/thread-timeline.test.ts
@@ -10,6 +10,9 @@ import {
   localYesterdayKey,
   selectionState,
   toggleGroupSelection,
+  toggleSelectAll,
+  selectAllIds,
+  allSelectableSelected,
   displayThreadTitle,
   threadAccessibleName,
   threadRecency,
@@ -307,6 +310,27 @@ test("selectionState + toggleGroupSelection", () => {
   assert.deepEqual([...sel].sort(), ["a", "b"])
 })
 
+test("toggleSelectAll kept for group toggling; toolbar 全选 uses selectAllIds", () => {
+  const selectable = ["a", "b", "c"]
+  assert.equal(allSelectableSelected(new Set(), selectable), false)
+  let sel = toggleSelectAll(new Set(), selectable)
+  assert.deepEqual([...sel].sort(), ["a", "b", "c"])
+  assert.equal(allSelectableSelected(sel, selectable), true)
+  sel = toggleSelectAll(sel, selectable)
+  assert.equal(sel.size, 0)
+  sel = toggleSelectAll(new Set(["z"]), ["a", "b"])
+  assert.deepEqual([...sel].sort(), ["a", "b", "z"])
+})
+
+test("selectAllIds is idempotent (double click / Strict updater still all-on)", () => {
+  const selectable = ["a", "b", "c"]
+  const once = selectAllIds(selectable)
+  const twice = selectAllIds(once)
+  assert.deepEqual([...selectAllIds(selectable)].sort(), ["a", "b", "c"])
+  assert.deepEqual([...selectAllIds(twice)].sort(), ["a", "b", "c"])
+  assert.equal(allSelectableSelected(new Set(), []), false)
+})
+
 test("displayThreadTitle fallback", () => {
   // Id lives in list badge (formatThreadIdBadge), not inlined into title
   assert.equal(displayThreadTitle({ id: "abcdefgh", alias: "  " }), "未命名")
diff --git a/companion/README.txt b/companion/README.txt
index 7ff22525..3485534a 100644
--- a/companion/README.txt
+++ b/companion/README.txt
@@ -1,15 +1,19 @@
-CMspark Browser Agent v0.6.0
+CMspark Browser Agent v0.6.7
 ===============================
 
 浏览器 AI 助手 — 让 AI 帮你操作网页
 
 ## 安装
 
-1. 解压 cmspark-v0.6.0.zip 到任意文件夹
-2. 双击 install.bat
-3. 在 Chrome 中加载扩展（按屏幕提示操作）
+官方路径（Windows）：
+
+1. 运行安装向导 CMspark-Setup-v0.6.7.exe（NSIS），或解压 cmspark-v0.6.7-windows-x64.zip
+2. 官方 zip / Setup 入口是包内的 node.exe + cmspark-agent.js（不是 cmspark-agent.exe SEA 单文件）
+3. 在 Chrome 中加载扩展（按屏幕提示 / 安装器说明）
 4. 完成！
 
+便携 zip 也可双击 install.bat / launch.bat。若目录里还有 cmspark-agent.exe，那是可选本机 SEA 形态，不是 GitHub Release 默认。
+
 ## 使用
 
 1. 打开任意网页
@@ -26,7 +30,7 @@ CMspark Browser Agent v0.6.0
 
 ## 卸载
 
-1. 双击 uninstall.bat
+1. 双击 uninstall.bat（zip）或用「添加或删除程序」卸载 Setup.exe
 2. 在 Chrome 中移除扩展
 
 ## 数据位置
@@ -38,8 +42,8 @@ CMspark Browser Agent v0.6.0
 
 ## 本机听写（可选）
 
-- 组件：包内 `bin\cmspark-whisper-win-x64.exe` + DLL（或设置 → 听写 →「下载本机听写组件」）
-- 模型：设置 → 听写 下载 small / medium（推荐）/ large-v3-turbo
+- 组件：包内 `bin\cmspark-whisper-win-x64.exe` + DLL（或设置 → 输入与语音 →「下载本机听写组件」）
+- 模型：设置 → 输入与语音 下载 small / medium（推荐）/ large-v3-turbo
 - large-v3-turbo：终稿识别可能需数十秒～数分钟，无实时出字（仅 medium/small 有渐进假设）
 - 数据目录：%USERPROFILE%\.cmspark-agent\models\whisper\ 与 bin\whisper\
 
@@ -59,9 +63,8 @@ A: 已有 Companion 在跑则无需再启；若需重启，任务管理器结束
    node.exe / cmspark-agent 相关进程后重试（不要只杀 leftover SEA）
 
 Q: 如何更新？
-A: 下载新版本 zip，解压覆盖所有文件，重启 CMspark 即可
+A: 下载新版本 zip 或 Setup.exe，解压覆盖或覆盖安装，重启 CMspark 即可
 
 Q: 需要安装 Node.js 吗？
-A: 不需要。本分发包已内置 Node.js 运行时，开箱即用。
+A: 不需要。官方分发包已内置 node.exe，开箱即用。
    （精简版用户如需使用系统 Node.js，请确保版本 v22+）
-
diff --git a/companion/package-lock.json b/companion/package-lock.json
index 8a47c76c..bb7cf69d 100644
--- a/companion/package-lock.json
+++ b/companion/package-lock.json
@@ -1,12 +1,12 @@
 {
   "name": "cmspark-agent",
-  "version": "0.6.6",
+  "version": "0.6.7",
   "lockfileVersion": 3,
   "requires": true,
   "packages": {
     "": {
       "name": "cmspark-agent",
-      "version": "0.6.6",
+      "version": "0.6.7",
       "hasInstallScript": true,
       "dependencies": {
         "@agentclientprotocol/sdk": "^1.3.0",
@@ -15,7 +15,7 @@
         "@types/js-yaml": "^4.0.9",
         "adm-zip": "^0.6.0",
         "gray-matter": "^4.0.3",
-        "js-yaml": "4.3.1",
+        "js-yaml": "4.3.2",
         "node-notifier": "^10.0.1",
         "officeparser": "^7.2.3",
         "onnxruntime-node": "1.29.0",
@@ -1877,9 +1877,9 @@
       }
     },
     "node_modules/gray-matter/node_modules/js-yaml": {
-      "version": "3.15.1",
-      "resolved": "https://registry.npmjs.org/js-yaml/-/js-yaml-3.15.1.tgz",
-      "integrity": "sha512-S99WuO3HlhO3XN41EtYUNl9zzXjoJx7QvmipxsJVxtCBT0YHEFy+iOJhjSvrmV12nYhWpZaM8lPHkJm0yUMbag==",
+      "version": "3.15.2",
+      "resolved": "https://registry.npmjs.org/js-yaml/-/js-yaml-3.15.2.tgz",
+      "integrity": "sha512-6EuL879VkRA+1Cz578mKMiKvjPNEuk6+r1JaFzoSWejZmtf7xWbIyw1e3KkxlkzTIt9Taw6JBhEppG7utc1P+w==",
       "license": "MIT",
       "dependencies": {
         "argparse": "^1.0.7",
@@ -2114,9 +2114,9 @@
       }
     },
     "node_modules/js-yaml": {
-      "version": "4.3.1",
-      "resolved": "https://registry.npmjs.org/js-yaml/-/js-yaml-4.3.1.tgz",
-      "integrity": "sha512-CY6crGq313MX8GkwvB7tzgp99vjQxY1++5y10/BKN/GUfHqWaOGQMNZkBvqSzsZKWk/ijwHlWzzkLulsGHhjWQ==",
+      "version": "4.3.2",
+      "resolved": "https://registry.npmjs.org/js-yaml/-/js-yaml-4.3.2.tgz",
+      "integrity": "sha512-SFNOvSJ+Dgf/9An904Yx+CgSlIPCkIpao4qo51lpee25TIRejdH3rhR4EZMGoNx3/TP3O+wzWuiTFl4sqbltzA==",
       "funding": [
         {
           "type": "github",
diff --git a/companion/package.json b/companion/package.json
index 000b1079..58910318 100644
--- a/companion/package.json
+++ b/companion/package.json
@@ -1,6 +1,6 @@
 {
   "name": "cmspark-agent",
-  "version": "0.6.6",
+  "version": "0.6.7",
   "description": "Local companion for CMspark Browser Agent — manages LLM calls, skills, threads, and operation history. Now with cross-platform system tray.",
   "bin": {
     "cmspark-agent": "./dist/index.js"
@@ -34,7 +34,7 @@
     "@types/js-yaml": "^4.0.9",
     "adm-zip": "^0.6.0",
     "gray-matter": "^4.0.3",
-    "js-yaml": "4.3.1",
+    "js-yaml": "4.3.2",
     "node-notifier": "^10.0.1",
     "officeparser": "^7.2.3",
     "onnxruntime-node": "1.29.0",
@@ -57,9 +57,9 @@
   },
   "overrides": {
     "adm-zip": "^0.6.0",
-    "js-yaml": "4.3.1",
+    "js-yaml": "4.3.2",
     "gray-matter": {
-      "js-yaml": "3.15.1"
+      "js-yaml": "3.15.2"
     },
     "officeparser": {
       "pdfjs-dist": "6.2.108"
diff --git a/companion/scripts/diarize-eval.ts b/companion/scripts/diarize-eval.ts
index 1cb4ae89..fa686e51 100644
--- a/companion/scripts/diarize-eval.ts
+++ b/companion/scripts/diarize-eval.ts
@@ -211,7 +211,7 @@ async function main(): Promise<number> {
   if (!existsSync(modelPath)) {
     console.error(
       `[abort] 说话人模型缺失：${modelPath}\n` +
-        `  下载：设置 → 听写方式 → 「说话人分离模型」；或手动放置 speaker.onnx 到上述路径\n` +
+        `  下载：设置 → 输入与语音 → 听写方式 → 「说话人分离模型」；或手动放置 speaker.onnx 到上述路径\n` +
         `  或用 --model-root <dir> 指向 <dir>/${DIARIZE_MODEL_ID}/speaker.onnx\n` +
         `（评测门绝不静默跳过 embedding 臂）`,
     )
diff --git a/companion/src/acp/jsonrpc-stdio.ts b/companion/src/acp/jsonrpc-stdio.ts
index 6484d6ca..f1c60cbb 100644
--- a/companion/src/acp/jsonrpc-stdio.ts
+++ b/companion/src/acp/jsonrpc-stdio.ts
@@ -161,7 +161,7 @@ export async function tryAcpInitialize(
       "initialize",
       {
         protocolVersion: 1,
-        clientInfo: { name: "cmspark", version: "0.6.6" },
+        clientInfo: { name: "cmspark", version: "0.6.7" },
         capabilities: {
           fs: { readTextFile: false, writeTextFile: false },
           terminal: false,
diff --git a/companion/src/cli-version.ts b/companion/src/cli-version.ts
new file mode 100644
index 00000000..9eafa6b7
--- /dev/null
+++ b/companion/src/cli-version.ts
@@ -0,0 +1,21 @@
+import * as fs from "fs"
+import * as path from "path"
+
+/** Fallback must stay lock-step with companion/package.json (test-package-gates). */
+export const CLI_VERSION_FALLBACK = "0.6.7"
+
+export function resolveCliVersion(): string {
+  const candidates = [
+    path.join(__dirname, "..", "package.json"),
+    path.join(__dirname, "..", "..", "package.json"),
+  ]
+  for (const pkgPath of candidates) {
+    try {
+      const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8")) as { version?: unknown }
+      if (typeof pkg.version === "string" && pkg.version.trim()) return pkg.version.trim()
+    } catch {
+      /* try next layout (dist/ vs .test-dist/src/) */
+    }
+  }
+  return CLI_VERSION_FALLBACK
+}
diff --git a/companion/src/index.ts b/companion/src/index.ts
index a723a10d..746ae70a 100644
--- a/companion/src/index.ts
+++ b/companion/src/index.ts
@@ -19,6 +19,7 @@ import { startMenuBarAgent } from "./menu-bar-agent"
 import { runInteractiveSettings, runNonInteractiveSettings, runNonInteractiveSettingsCli } from "./settings-cli"
 import { getPlatform } from "./platform"
 import { applyHardenedProcessPath } from "./process-path"
+import { resolveCliVersion } from "./cli-version"
 import * as fs from "fs"
 import * as path from "path"
 import * as child_process from "child_process"
@@ -28,12 +29,13 @@ import * as child_process from "child_process"
 applyHardenedProcessPath()
 
 function printUsage(): void {
-  console.log(`cmspark-agent v0.6.6
+  console.log(`cmspark-agent v${resolveCliVersion()}
 
 Usage:
+  cmspark-agent --version                  打印版本并退出
   cmspark-agent start                      启动 Companion 服务器（前台）
-  cmspark-agent stop                       停止 Companion 服务器
-  cmspark-agent status                     查看服务器状态
+  cmspark-agent stop                       停止 Companion 服务器（同 daemon stop）
+  cmspark-agent status                     查看服务器状态（同 daemon status）
 
   cmspark-agent daemon start [--daemonize]  启动守护进程
   cmspark-agent daemon stop                停止守护进程
@@ -332,12 +334,12 @@ async function main() {
       break
 
     case "stop":
-      console.log("Stop command not yet implemented (use 'daemon stop' instead)")
-      process.exit(0)
+      await handleDaemonStop()
+      break
 
     case "status":
-      console.log("Status command not yet implemented (use 'daemon status' instead)")
-      process.exit(0)
+      await handleDaemonStatus()
+      break
 
     case "daemon": {
       switch (subCommand) {
@@ -471,6 +473,12 @@ async function main() {
       printUsage()
       process.exit(0)
 
+    case "--version":
+    case "-V":
+    case "version":
+      console.log(`cmspark-agent v${resolveCliVersion()}`)
+      process.exit(0)
+
     case undefined:
       // In SEA (packaged exe): double-click → start tray directly
       // In dev mode: show CLI usage
diff --git a/companion/src/llm/adapter.ts b/companion/src/llm/adapter.ts
index 02c61559..89c0148d 100644
--- a/companion/src/llm/adapter.ts
+++ b/companion/src/llm/adapter.ts
@@ -43,6 +43,7 @@ import {
   persistHealedToolRows,
   replaceInterruptedFillerIfPresent,
 } from "./tool-batch-heal"
+import { redactAssistantToolCallsForPersistence } from "../security/tool-persistence-redact"
 import { isContentRiskError, isContextOverflowError, isLengthStop, isTruncatedToolBatch } from "./overflow"
 import { convertLeftoverSteerToNextRun, takeSteer } from "./run-queues"
 import type { RunStats } from "../loop/loop-state"
@@ -1174,7 +1175,7 @@ ${hostUseRule12}${computerUsePlaybook}${appIndexSection ? `\n\n${appIndexSection
       thread_id: threadId,
       role: "assistant",
       content: draft.content,
-      tool_calls: assistantMsg,
+      tool_calls: redactAssistantToolCallsForPersistence(assistantMsg),
     }
     if (draft.reasoning) savedMsg.reasoning_content = draft.reasoning
     if (draft.truncated) savedMsg.truncated = true
diff --git a/companion/src/meeting/diarize-embed.ts b/companion/src/meeting/diarize-embed.ts
index 6a3061fb..9cce831e 100644
--- a/companion/src/meeting/diarize-embed.ts
+++ b/companion/src/meeting/diarize-embed.ts
@@ -96,7 +96,7 @@ export async function embedSegmentsForDiarize(
     return {
       ok: false,
       code: "embedding_model_required",
-      message: `说话人模型未就绪（${probe.status}${probe.error ? ` · ${probe.error}` : ""}）：请到 设置 → 听写方式 下载「说话人分离模型」后重试`,
+      message: `说话人模型未就绪（${probe.status}${probe.error ? ` · ${probe.error}` : ""}）：请到 设置 → 输入与语音 → 听写方式 下载「说话人分离模型」后重试`,
     }
   }
 
diff --git a/companion/src/outbound-mcp/stdio-server.ts b/companion/src/outbound-mcp/stdio-server.ts
index ad879907..20e5458e 100644
--- a/companion/src/outbound-mcp/stdio-server.ts
+++ b/companion/src/outbound-mcp/stdio-server.ts
@@ -249,7 +249,7 @@ export function createOutboundMcpServer(
   // token at wire time; else default (byte-identical to pre-#410 behavior).
   if (profiles) resolvedProfiles = [...profiles]
   const server = new Server(
-    { name: "cmspark-outbound", version: "0.6.6" },
+    { name: "cmspark-outbound", version: "0.6.7" },
     { capabilities: { tools: {} } },
   )
 
diff --git a/companion/src/security/tool-persistence-redact.ts b/companion/src/security/tool-persistence-redact.ts
index 2eb16e74..6452ce55 100644
--- a/companion/src/security/tool-persistence-redact.ts
+++ b/companion/src/security/tool-persistence-redact.ts
@@ -10,7 +10,9 @@
  * amnesia). ALL rules live in the shared module security/redact-rules.ts —
  * history/store.ts consumes the same one (golden fixtures + lock-step tests
  * pin parity). In-flight LLM tool rows stay unredacted; only
- * createToolResultMessage → addMessage goes through here.
+ * createToolResultMessage → addMessage (tool-role) and
+ * persistAssistantDraft → addMessage (assistant tool_calls.arguments)
+ * go through here.
  */
 import {
   EXEC_FOLD_TOOLS,
@@ -266,3 +268,45 @@ export function redactToolPayloadForPersistence(
   }
   return { params: safeParams, result: safeResult }
 }
+
+/** OpenAI-shaped assistant tool_call as stored on the persisted assistant row. */
+export type AssistantToolCallForPersist = {
+  id: string
+  type: "function"
+  function: { name: string; arguments: string }
+}
+
+/**
+ * Redact assistant tool_calls.arguments before durable thread JSON persist.
+ * Clones; does not mutate in-flight LLM rows. Invalid JSON is replaced with a
+ * stub — never stored raw (truncated streams can carry partial secrets).
+ */
+export function redactAssistantToolCallsForPersistence(
+  toolCalls: readonly AssistantToolCallForPersist[] | null | undefined,
+): AssistantToolCallForPersist[] {
+  if (!Array.isArray(toolCalls) || toolCalls.length === 0) return []
+  return toolCalls.map((tc) => redactOneAssistantToolCall(tc))
+}
+
+function redactOneAssistantToolCall(
+  tc: AssistantToolCallForPersist,
+): AssistantToolCallForPersist {
+  const name = typeof tc?.function?.name === "string" ? tc.function.name : ""
+  const rawArgs = typeof tc?.function?.arguments === "string" ? tc.function.arguments : ""
+  let argumentsOut: string
+  try {
+    const params = JSON.parse(rawArgs)
+    const { params: safeParams } = redactToolPayloadForPersistence(name, params, null)
+    argumentsOut = JSON.stringify(safeParams === undefined ? {} : safeParams)
+  } catch {
+    argumentsOut = JSON.stringify({ _redacted: "invalid_json", len: rawArgs.length })
+  }
+  return {
+    id: tc.id,
+    type: tc.type ?? "function",
+    function: {
+      name,
+      arguments: argumentsOut,
+    },
+  }
+}
diff --git a/companion/src/summoner-web.ts b/companion/src/summoner-web.ts
index 6b0c0aff..5a1f261b 100644
--- a/companion/src/summoner-web.ts
+++ b/companion/src/summoner-web.ts
@@ -1746,7 +1746,7 @@ try{
   var STT_DICTATION_MS=45000;
   var STT_MEETING_MS=8000;
   var STT_MIC_FAIL="请在系统设置中打开 127.0.0.1 的麦克风";
-  var STT_NEED_MODEL="侧栏 ⋯ → 设置 → 听写 → 下载组件/模型";
+  var STT_NEED_MODEL="侧栏 ⋯ → 设置 → 输入与语音 → 下载组件/模型";
   function sttUserCopy(code, fallback){
     var c=String(code||"").toLowerCase();
     if(c.indexOf("model")>=0 || c.indexOf("binary")>=0 || c.indexOf("engine")>=0) return STT_NEED_MODEL;
diff --git a/companion/tests/assistant-tool-args-redact.test.ts b/companion/tests/assistant-tool-args-redact.test.ts
new file mode 100644
index 00000000..e9e9baec
--- /dev/null
+++ b/companion/tests/assistant-tool-args-redact.test.ts
@@ -0,0 +1,170 @@
+/**
+ * L4: assistant tool_calls.arguments must be redacted before threads/*.json persist.
+ * persistAssistantDraft is the disk gate; in-flight LLM rows stay raw.
+ */
+import test, { after, before } from "node:test"
+import assert from "node:assert/strict"
+import * as fs from "node:fs"
+import * as os from "node:os"
+import * as path from "node:path"
+import { redactAssistantToolCallsForPersistence } from "../src/security/tool-persistence-redact"
+
+const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "cmspark-assistant-args-redact-"))
+process.env.HOME = tempHome
+process.env.CMSPARK_DATA_DIR = path.join(tempHome, ".cmspark-agent")
+
+const ROOT = path.resolve(__dirname, "..", "..")
+function srcFile(...parts: string[]): string {
+  const candidates = [
+    path.join(ROOT, "src", ...parts),
+    path.join(__dirname, "..", "src", ...parts),
+  ]
+  for (const p of candidates) {
+    if (fs.existsSync(p)) return p
+  }
+  return candidates[candidates.length - 1]
+}
+
+function call(
+  name: string,
+  args: string,
+  id = "call_1",
+): { id: string; type: "function"; function: { name: string; arguments: string } } {
+  return { id, type: "function", function: { name, arguments: args } }
+}
+
+function persistedArgs(toolCalls: ReturnType<typeof redactAssistantToolCallsForPersistence>): string {
+  return JSON.stringify(toolCalls)
+}
+
+let ThreadManager: typeof import("../src/threads/thread-manager").ThreadManager
+let initDataDir: typeof import("../src/config").initDataDir
+
+before(async () => {
+  const config = await import("../src/config")
+  initDataDir = config.initDataDir
+  await initDataDir()
+  ThreadManager = (await import("../src/threads/thread-manager")).ThreadManager
+})
+
+after(() => {
+  try { fs.rmSync(tempHome, { recursive: true, force: true }) } catch { /* best-effort */ }
+})
+
+test("set_cookie value is folded in persisted assistant arguments", () => {
+  const secret = "COOKIE_SECRET_VALUE_DO_NOT_PERSIST"
+  const original = call("set_cookie", JSON.stringify({
+    name: "sid",
+    domain: "example.com",
+    value: secret,
+  }))
+  const out = redactAssistantToolCallsForPersistence([original])
+  const args = JSON.parse(out[0].function.arguments)
+  assert.equal(out[0].id, "call_1")
+  assert.equal(out[0].type, "function")
+  assert.equal(out[0].function.name, "set_cookie")
+  assert.equal(args.name, "sid")
+  assert.equal(args.domain, "example.com")
+  assert.ok(String(args.value).startsWith("<redacted:"))
+  assert.ok(!persistedArgs(out).includes(secret))
+  assert.equal(original.function.arguments.includes(secret), true, "in-flight row stays raw")
+})
+
+test("shell_exec command is folded in persisted assistant arguments", () => {
+  const command = "cat /etc/passwd && echo SHELL_SECRET_PAYLOAD"
+  const original = call("shell_exec", JSON.stringify({ command, cwd: "/tmp" }))
+  const out = redactAssistantToolCallsForPersistence([original])
+  const args = JSON.parse(out[0].function.arguments)
+  assert.ok(String(args.command).startsWith("<redacted:"))
+  assert.equal(args.cwd, "/tmp")
+  assert.ok(!persistedArgs(out).includes(command))
+  assert.ok(!persistedArgs(out).includes("SHELL_SECRET_PAYLOAD"))
+  assert.equal(original.function.arguments.includes(command), true)
+})
+
+test("host_computer task is folded in persisted assistant arguments", () => {
+  const task = "type the password hunter2 into the login form"
+  const original = call("host_computer", JSON.stringify({ task, actions: [{ type: "type", text: "hunter2" }] }))
+  const out = redactAssistantToolCallsForPersistence([original])
+  const args = JSON.parse(out[0].function.arguments)
+  assert.ok(String(args.task).startsWith("<redacted:"))
+  assert.ok(!persistedArgs(out).includes(task))
+  assert.ok(!persistedArgs(out).includes("hunter2"))
+  assert.equal(original.function.arguments.includes("hunter2"), true)
+})
+
+test("evaluate code is folded in persisted assistant arguments", () => {
+  const code = "return document.cookie"
+  const original = call("evaluate", JSON.stringify({ code, tabId: 7 }))
+  const out = redactAssistantToolCallsForPersistence([original])
+  const args = JSON.parse(out[0].function.arguments)
+  assert.ok(String(args.code).startsWith("<redacted:"))
+  assert.equal(args.tabId, 7)
+  assert.ok(!persistedArgs(out).includes(code))
+})
+
+test("list_tabs keeps non-secret args", () => {
+  const original = call("list_tabs", JSON.stringify({ currentWindow: true, tabId: 42 }))
+  const out = redactAssistantToolCallsForPersistence([original])
+  const args = JSON.parse(out[0].function.arguments)
+  assert.equal(args.currentWindow, true)
+  assert.equal(args.tabId, 42)
+  assert.equal(out[0].function.name, "list_tabs")
+})
+
+test("invalid JSON arguments are replaced with a stub, not the raw string", () => {
+  const raw = '{"value":"PARTIAL_SECRET_STILL_LEAK"'
+  const original = call("set_cookie", raw)
+  const out = redactAssistantToolCallsForPersistence([original])
+  const args = JSON.parse(out[0].function.arguments)
+  assert.equal(args._redacted, "invalid_json")
+  assert.equal(args.len, raw.length)
+  assert.ok(!persistedArgs(out).includes("PARTIAL_SECRET_STILL_LEAK"))
+  assert.equal(original.function.arguments, raw)
+})
+
+test("empty tool_calls list stays empty", () => {
+  assert.deepEqual(redactAssistantToolCallsForPersistence([]), [])
+  assert.deepEqual(redactAssistantToolCallsForPersistence(undefined), [])
+})
+
+test("persistAssistantDraft redacts tool_calls before addMessage", () => {
+  const src = fs.readFileSync(srcFile("llm", "adapter.ts"), "utf8")
+  assert.match(src, /redactAssistantToolCallsForPersistence/)
+  const start = src.indexOf("function persistAssistantDraft")
+  assert.ok(start >= 0, "persistAssistantDraft missing")
+  const loopMark = src.indexOf("// Tool calling loop", start)
+  const body = src.slice(start, loopMark > start ? loopMark : start + 1200)
+  assert.match(body, /redactAssistantToolCallsForPersistence/)
+  assert.match(body, /addMessage/)
+  assert.ok(
+    body.indexOf("redactAssistantToolCallsForPersistence") < body.indexOf("addMessage"),
+    "helper must run before addMessage",
+  )
+  assert.ok(
+    /tool_calls:\s*redactAssistantToolCallsForPersistence\(/.test(body)
+      || /const\s+\w+\s*=\s*redactAssistantToolCallsForPersistence\(/.test(body),
+    "addMessage payload must use helper output, not raw assistantMsg",
+  )
+})
+
+test("set_cookie value does not appear in persisted thread JSON", () => {
+  const secret = "COOKIE_SECRET_VALUE_DO_NOT_PERSIST"
+  const tm = new ThreadManager()
+  const th = tm.create("assistant-args-redact")
+  tm.addMessage(th.id, {
+    thread_id: th.id,
+    role: "assistant",
+    content: "",
+    tool_calls: redactAssistantToolCallsForPersistence([
+      call("set_cookie", JSON.stringify({ name: "sid", value: secret, domain: "example.com" })),
+    ]),
+  })
+  const diskPath = path.join(process.env.CMSPARK_DATA_DIR!, "threads", `${th.id}.json`)
+  const disk = fs.readFileSync(diskPath, "utf8")
+  assert.ok(!disk.includes(secret), "cookie value must not persist in threads/*.json")
+  const stored = JSON.parse(disk)
+  const args = JSON.parse(stored.messages[0].tool_calls[0].function.arguments)
+  assert.equal(args.name, "sid")
+  assert.ok(String(args.value).startsWith("<redacted:"))
+})
diff --git a/companion/tests/cli-version.test.ts b/companion/tests/cli-version.test.ts
new file mode 100644
index 00000000..27a13e92
--- /dev/null
+++ b/companion/tests/cli-version.test.ts
@@ -0,0 +1,48 @@
+import assert from "node:assert/strict"
+import { spawnSync } from "node:child_process"
+import * as fs from "node:fs"
+import * as path from "node:path"
+import { describe, it } from "node:test"
+import { CLI_VERSION_FALLBACK, resolveCliVersion } from "../src/cli-version"
+
+function companionRoot(): string {
+  const candidates = [
+    path.join(__dirname, ".."),
+    path.join(__dirname, "..", ".."),
+  ]
+  for (const dir of candidates) {
+    const pkgPath = path.join(dir, "package.json")
+    if (fs.existsSync(pkgPath)) {
+      try {
+        const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8")) as { name?: string }
+        if (pkg.name === "cmspark-agent") return dir
+      } catch {
+        /* next */
+      }
+    }
+  }
+  return path.join(__dirname, "..")
+}
+
+const ROOT = companionRoot()
+const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8")) as { version: string }
+
+describe("cli version", () => {
+  it("resolveCliVersion matches package.json", () => {
+    assert.equal(pkg.version, "0.6.7")
+    assert.equal(resolveCliVersion(), pkg.version)
+    assert.equal(CLI_VERSION_FALLBACK, pkg.version)
+  })
+
+  it("--version prints one line and exits 0", () => {
+    const cli = path.join(__dirname, "..", "src", "index.js")
+    assert.equal(fs.existsSync(cli), true, cli)
+    const r = spawnSync(process.execPath, [cli, "--version"], {
+      encoding: "utf8",
+      env: { ...process.env, CMSPARK_DATA_DIR: path.join(ROOT, ".test-dist", "cli-version") },
+    })
+    assert.equal(r.status, 0, r.stderr)
+    assert.match(r.stdout, /^cmspark-agent v0\.6\.7\r?\n$/)
+    assert.doesNotMatch(r.stdout, /Unknown command/)
+  })
+})
diff --git a/companion/tests/version-lockstep.test.ts b/companion/tests/version-lockstep.test.ts
index 45a5939f..01d0b2c3 100644
--- a/companion/tests/version-lockstep.test.ts
+++ b/companion/tests/version-lockstep.test.ts
@@ -1,7 +1,6 @@
-// Version lockstep: source-embedded version literals must match
-// companion/package.json (the version SoT). These strings ship in the bundled
-// cmspark-agent.js where package.json is unavailable at runtime, so they are
-// hardcoded by necessity — this test is the guard against bump misses.
+// Version lockstep: companion/package.json is the version SoT.
+// CLI usage/--version resolve at runtime (cli-version.ts); ACP/MCP serverInfo
+// and CLI_VERSION_FALLBACK stay as literals — this test guards bump misses.
 
 import { test } from "node:test"
 import assert from "node:assert/strict"
@@ -19,9 +18,13 @@ function src(rel: string): string {
 
 test("version lockstep: embedded literals match package.json", () => {
   assert.ok(VERSION, "package.json must carry a version")
-  assert.match(src("index.ts"), new RegExp(`cmspark-agent v${VERSION.replace(/\./g, "\\.")}`))
-  assert.match(src(path.join("acp", "jsonrpc-stdio.ts")), new RegExp(`version: "${VERSION.replace(/\./g, "\\.")}"`))
-  assert.match(src(path.join("outbound-mcp", "stdio-server.ts")), new RegExp(`version: "${VERSION.replace(/\./g, "\\.")}"`))
+  const v = VERSION.replace(/\./g, "\\.")
+  // CLI banner is runtime-resolved; hardcoded `cmspark-agent vX.Y.Z` in
+  // index.ts would fight --version honesty. Fallback + ACP/MCP stay literals.
+  assert.match(src("index.ts"), /cmspark-agent v\$\{resolveCliVersion\(\)\}/)
+  assert.match(src("cli-version.ts"), new RegExp(`CLI_VERSION_FALLBACK = "${v}"`))
+  assert.match(src(path.join("acp", "jsonrpc-stdio.ts")), new RegExp(`version: "${v}"`))
+  assert.match(src(path.join("outbound-mcp", "stdio-server.ts")), new RegExp(`version: "${v}"`))
 })
 
 test("version lockstep: chrome-extension package.json matches companion", () => {
diff --git a/docs/GOAL.md b/docs/GOAL.md
index 35bcedd8..2c8bd1ab 100644
--- a/docs/GOAL.md
+++ b/docs/GOAL.md
@@ -1,6 +1,6 @@
 # CMspark Browser Agent — 项目目标
 
-> 版本: 1.7.9 | 日期: 2026-09-06 | 当前阶段：安全稳定化 MVP（核心已完成）→ **产品 0.6.0**。T1 bake-off **已记分**：CMspark 臂完成 / Playwright 干净 profile 打不开门户（L7 PASS 带 nit，[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）。**禁扩**默认 outbound profile。冻 [#230](https://github.com/nehcuh/cmspark/issues/230)（F-S-10 / overlay-acl）；语音/会议 [#258](https://github.com/nehcuh/cmspark/issues/258)–[#260](https://github.com/nehcuh/cmspark/issues/260)。0.5.3 快照：[post-227-status](superpowers/specs/2026-08-27-post-227-status.md)（**SNAPSHOT**）。需求设计必须先开 GitHub Issue。
+> 版本: 1.7.9 | 日期: 2026-09-08 | 当前阶段：安全稳定化 MVP（核心已完成）→ **产品 0.6.7**。T1 bake-off **已记分**：CMspark 臂完成 / Playwright 干净 profile 打不开门户（L7 PASS 带 nit，[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）。**禁扩**默认 outbound profile。冻 [#230](https://github.com/nehcuh/cmspark/issues/230)（F-S-10 / overlay-acl）。0.5.3 快照：[post-227-status](superpowers/specs/2026-08-27-post-227-status.md)（**SNAPSHOT**）。需求设计必须先开 GitHub Issue。
 
 ---
 
@@ -8,7 +8,7 @@
 
 一个对着 **已登录 Chrome** 真干活的本机 Agent。热键召唤开口；人在 Chrome 里用侧栏操作；人在 Codex 里**租同一只手**（Outbound MCP）；危险走确认台。Side Panel 是 Operate 面之一，**不是家**。家是 **已登录的 Chrome + 硬闸**。
 
-形态 SoT：[2026-08-26-product-form-deepening-design.md](superpowers/specs/2026-08-26-product-form-deepening-design.md)。活切点：[CHANGELOG](../CHANGELOG.md) **0.6.0**。0.5.3 快照：[post-227-status](superpowers/specs/2026-08-27-post-227-status.md)（SNAPSHOT）。
+形态 SoT：[2026-08-26-product-form-deepening-design.md](superpowers/specs/2026-08-26-product-form-deepening-design.md)。活切点：[CHANGELOG](../CHANGELOG.md) **0.6.7**。0.5.3 快照：[post-227-status](superpowers/specs/2026-08-27-post-227-status.md)（SNAPSHOT）。
 
 通过 CDP/Chrome APIs 操作浏览器，通过本地 Companion 进程管理 LLM 调用、对话状态和技能系统。
 
@@ -267,7 +267,8 @@ Agent 可以在用户授权下对任意标签页执行全部 26 种工具操作
 
 - Pack 平台：install / apply / uninstall + snapshot 回滚 + capability 审计日志
 - 企业模块 opt-in：workspace / shell_exec / netsec（community 默认不开放 shell/netsec）
-- 明确 **非目标**（本阶段）：交互式 PTY、捆绑 nmap、CWS 默认扫描能力
+- **内嵌终端（#432）**：Darwin-only 真 PTY（xterm.js + `@lydell/node-pty`），**默认关**；Windows/Linux 返回 `unsupported`。不是「非目标：交互式 PTY」。
+- 明确 **非目标**（本阶段）：捆绑 nmap、CWS 默认扫描能力
 
 ### G20. MCP / Computer·Host Use / Multi-Agent·Board / NotebookLM ✅ 已实现（0.3.0）
 
diff --git a/docs/README.md b/docs/README.md
index 7980fcee..974cb2c1 100644
--- a/docs/README.md
+++ b/docs/README.md
@@ -1,6 +1,6 @@
 # CMspark 文档导航
 
-> 产品 **0.6.0** · 入口 README：[仓库根 README.md](../README.md)  
+> 产品 **0.6.7** · 入口 README：[仓库根 README.md](../README.md)  
 > 本页只做**导航**，不搬运正文。过程件已于 **Phase 4** 迁入 [`archive/2026-07/`](archive/2026-07/)；`user/` 物理搬家仍可选（见 [docs-reorg-plan-2026-07-28.md](docs-reorg-plan-2026-07-28.md)）。
 
 ---
@@ -14,7 +14,7 @@
 | [workspace-ui.md](workspace-ui.md) | **Operate** | 响应式对话工作区、导航、历史、输入和设置 |
 | [../README.md](../README.md) | 全景 | 家 = 已登录 Chrome；Capture / 租手 / 安装 |
 | [../PRODUCT.md](../PRODUCT.md) | 产品句 | 四面 Capture·Operate·Confirm·租手 |
-| [summoner-user-guide.md](summoner-user-guide.md) | **Capture** | 召唤器 HTML 卡 360×420、流式、永不审批、请点工具栏 C |
+| [summoner-user-guide.md](summoner-user-guide.md) | **Capture** | 召唤器 HTML 卡默认 1040×760（紧凑 360×420）、流式、永不审批、请点工具栏 C |
 | [confirm-center-user-guide.md](confirm-center-user-guide.md) | **横切 Trust UI**（L1/L2） | 确认台 / Cockpit、高危审批、CU 操控台 |
 | [mcp.md](mcp.md) | **Composition** | MCP server（Inbound + **Outbound ADR-022**）、Grok `config.toml`、信任级别、Resources/Prompts、排错 |
 | [enterprise-pilot.md](enterprise-pilot.md) | **Composition · 0.7.0 开发中** | 两个企业材料场景的试点配置、来源契约和真实验收要求；尚未发布 |
@@ -46,7 +46,7 @@
 | [architecture.md](architecture.md) | 活架构：双层拓扑 + 桌面面、MCP/CU/Host/编排/Board/Packs |
 | [enterprise-architecture.md](enterprise-architecture.md) | 企业上下文、证据/核对、Mission 和可选 MCP 的职责边界；[发布验收台账](audit/0.7.0-20260907/release-acceptance.md) |
 | **[ADR-020 能力三轴](adr/020-capability-model-three-axes.md)** | **Surface · Composition · Autonomy** 本体（能力叠加与防「杂」纪律） |
-| [GOAL.md](GOAL.md) | 项目目标与阶段（与 **0.6.0** 对齐；扩展目标带轴标注） |
+| [GOAL.md](GOAL.md) | 项目目标与阶段（与 **0.6.7** 对齐；扩展目标带轴标注） |
 | [../PRODUCT.md](../PRODUCT.md) | 产品一句话 / 四面（Capture·Operate·Confirm·租手）；家 = 已登录 Chrome + 硬闸 |
 | [2026-08-26-product-form-deepening-design.md](superpowers/specs/2026-08-26-product-form-deepening-design.md) | **形态深化 SoT**（定位、文案合同、L8、五分钟租手、切片 DoD） |
 | [2026-08-27-post-227-status.md](superpowers/specs/2026-08-27-post-227-status.md) | **SNAPSHOT** 0.5.3 / #227（T1 已记分；**不是**活状态） |
@@ -120,7 +120,7 @@
 | [superpowers/plans/2026-08-04-outbound-mcp-p0c-eval-gates.md](superpowers/plans/2026-08-04-outbound-mcp-p0c-eval-gates.md) | Outbound MCP P0c 门控卡（M1–M9） |
 | [superpowers/plans/2026-08-04-outbound-mcp-p0d-bakeoff-checklist.md](superpowers/plans/2026-08-04-outbound-mcp-p0d-bakeoff-checklist.md) | P0d 记分表：T1 **已记分**（[#228](https://github.com/nehcuh/cmspark/issues/228) 已关）；**仍禁扩** profile；T2/T3 未跑 |
 | **GitHub [#230](https://github.com/nehcuh/cmspark/issues/230)** | **冻**：F-S-10 / overlay-acl。grant-cli 未知 flag 与 H1 精确勾已不在此清单 |
-| **GitHub [#258](https://github.com/nehcuh/cmspark/issues/258)–[#260](https://github.com/nehcuh/cmspark/issues/260)** | 语音 UX Hex · Windows SAPI 兜底 · speaker embedding diarize |
+| GitHub #258–#260（已实现，非余项） | Hex PTT · Windows SAPI · speaker embedding（**仍实验**） |
 | [skills/eval-engineering-gate/SKILL.md](skills/eval-engineering-gate/SKILL.md) | Eval Engineering 闸门 skill（机核 + dual + blast） |
 | [decisions/daily-content-loop-brief-2026-08-04.md](decisions/daily-content-loop-brief-2026-08-04.md) | **DIRECTION LOCKED**：每日情报环（公开站·本地模型·本机+邮件·代码+网页验证） |
 | [optimization-plan-post-v0.3.0.md](optimization-plan-post-v0.3.0.md) | 历史：v0.3.0 后 P2/P3 闭环考古（**勿再作排序权威**） |
@@ -172,5 +172,5 @@
 ## 维护提示
 
 - 新功能 PR：更新根 README 能力矩阵一行 + 本导航表（若新增用户文档）+ 必要时 ADR + [CONTRIBUTING 文档 checklist](../CONTRIBUTING.md#文档-checklist功能-pr-合并前)。  
-- 事实以 **0.6.0 代码**（`companion`/`chrome-extension` `package.json`）与 live ADR 为准；过程稿冲突时以 ADR / architecture / 用户指南为准。  
+- 事实以 **0.6.7 代码**（`companion`/`chrome-extension` `package.json`）与 live ADR 为准；过程稿冲突时以 ADR / architecture / 用户指南为准。  
 - 详细 DoD 与分阶段： [docs-reorg-plan-2026-07-28.md](docs-reorg-plan-2026-07-28.md)。
diff --git a/docs/architecture.md b/docs/architecture.md
index f879ffbe..2052e3ae 100644
--- a/docs/architecture.md
+++ b/docs/architecture.md
@@ -1,6 +1,6 @@
 # CMspark Browser Agent — 架构文档
 
-> 版本: 2.4.8 | 日期: 2026-09-06 | 状态: 已确认（同步 **0.6.0** + **[ADR-020](adr/020-capability-model-three-axes.md) 能力三轴** · 知识库波次（AI 草稿 / 检索 / 分布 / 文件夹）· context_window 512000 · listen-first · 当轮活计划 · ADR-023/024 语音（含 2026-08-31 L13 非静默回退）· Capture HTML 卡 360×420 流式 · 用户附图 · Windows NSIS · 知识诚实 · ChatShell · 0.6.0 自主性三件套（巡航档位 / plan_readonly / loop L-1–L-5）· 专家团队 v1 · CU 完整性链（后三项索引级，详见 [CHANGELOG](../CHANGELOG.md) `[0.6.0]`，loop/专家独立 ADR 待补）；T1 **已记分、禁扩 profile**）
+> 版本: 2.4.8 | 日期: 2026-09-08 | 状态: 已确认（同步 **0.6.7** + **[ADR-020](adr/020-capability-model-three-axes.md) 能力三轴** · 知识库波次（AI 草稿 / 检索 / 分布 / 文件夹）· context_window 512000 · listen-first · 当轮活计划 · ADR-023/024 语音（含 2026-08-31 L13 非静默回退）· Capture HTML 卡默认 1040×760（紧凑 360×420）流式 · 用户附图 · Windows NSIS · 知识诚实（TF-IDF top-k）· 知识图谱 #427 · Darwin 内嵌终端 #432（默认关）· `search_threads`/`search_knowledge` #439 · ChatShell · 0.6.0 自主性三件套（巡航档位 / plan_readonly / loop L-1–L-5）· 专家团队 v1 · CU 完整性链（后三项索引级，详见 [CHANGELOG](../CHANGELOG.md) `[0.6.0]`，loop/专家独立 ADR 待补；CU 定位仍实验，#363 未过）；T1 **已记分、禁扩 profile**）
 
 ---
 
diff --git a/docs/computer-use-user-guide.md b/docs/computer-use-user-guide.md
index d59b9d56..dee9cde1 100644
--- a/docs/computer-use-user-guide.md
+++ b/docs/computer-use-user-guide.md
@@ -1,7 +1,7 @@
 # Computer Use 使用说明
 
 > **面向使用者**：如何开启桌面坐标操控、确认台里怎么批/急停、session-trust 是什么、平台与限制。  
-> **产品版本**：0.5.0 · **决策摘要**：[ADR-017](adr/017-computer-use.md)  
+> **产品版本**：0.6.7 · **决策摘要**：[ADR-017](adr/017-computer-use.md)  
 > **确认台 UI**：[confirm-center-user-guide.md](confirm-center-user-guide.md) · **Host / Apps**：[host-and-apps.md](host-and-apps.md)  
 > **过程史（非规范）**：[decisions/coordinate-computer-use-plan.md](decisions/coordinate-computer-use-plan.md)
 
@@ -41,7 +41,7 @@
 
 1. **全局坐标开关** `computer.coordinateEnabled === true`  
    - 默认 **false**（fail-closed）。  
-   - **产品 0.5.0 用户路径**：Side Panel → 底栏 **应用（Apps）** → 顶部 **「坐标操作」** 勾选；走 Companion `computer.set_enabled`（可经生物识别/确认台门）。  
+   - **用户路径**：Side Panel → 底栏 **应用（Apps）** → 顶部 **「坐标操作」** 勾选；走 Companion `computer.set_enabled`（可经生物识别/确认台门）。  
    - 仍可直接编辑 `~/.cmspark-agent/config.json` 后重启 Companion。  
    - Apps 面板显示的是 **可切换** 状态（非只读镜像）。
 
@@ -117,7 +117,7 @@ Computer Use 与其它高危工具共用 [确认台](confirm-center-user-guide.m
 
 ## 6. 平台支持
 
-| 平台 | 状态（0.5.0） |
+| 平台 | 状态（0.6.7） |
 |------|----------------|
 | **macOS** | 主路径：原生适配 + 证据/急停；需本机权限（**只认 CMspark**，见下） |
 | **Windows** | 主路径：PowerShell/UIA 脚本族 + 窗口捕获；Hello 等与 host 写路径协同处见 host 指南 |
@@ -143,7 +143,7 @@ Computer Use 截图与键鼠需要系统权限。请 **只** 为 **CMspark** 打
 
 ## 6.1 实验层：Qwen3-VL 本机视觉定位（可选）
 
-默认 **关闭**。开启后作为 UIA/OCR 之后的 **L2 建议点**，**每次命中仍要人工确认**。
+默认 **关闭**。开启后作为 UIA/OCR 之后的 **L2 建议点**，**每次命中仍要人工确认**。定位层保持 **实验**；[#363](https://github.com/nehcuh/cmspark/issues/363) 摘帽门未过（勿当已 GA）。
 
 - **权威在 Companion**：扩展只发 `computer.model.*`，不在浏览器内推理。  
 - **用户路径**：设置 → 看「就绪」预检 → 选下载源（大陆推荐自动/魔搭）→ 选 2B/4B/8B → 下载 → 开启。  
diff --git a/docs/host-and-apps.md b/docs/host-and-apps.md
index ca3d998b..8a328a1d 100644
--- a/docs/host-and-apps.md
+++ b/docs/host-and-apps.md
@@ -1,7 +1,7 @@
 # Host Use 与 Apps 使用说明
 
 > **面向使用者**：本机宿主读写、应用白名单启动、与 Computer Use 的边界。  
-> **产品版本**：0.5.0 · **决策摘要**：[ADR-018](adr/018-host-use.md)  
+> **产品版本**：0.6.7 · **决策摘要**：[ADR-018](adr/018-host-use.md)  
 > **接口史（非唯一规范）**：[decisions/host-adapter-interface.md](decisions/host-adapter-interface.md)  
 > **坐标桌面**：[computer-use-user-guide.md](computer-use-user-guide.md) · **确认台**：[confirm-center-user-guide.md](confirm-center-user-guide.md)
 
diff --git a/docs/meeting-and-dictation-user-guide.md b/docs/meeting-and-dictation-user-guide.md
index 4cef01fc..f4e83075 100644
--- a/docs/meeting-and-dictation-user-guide.md
+++ b/docs/meeting-and-dictation-user-guide.md
@@ -1,6 +1,6 @@
 # 听写+ 与 会议记录 — 用户指南
 
-> 产品 **0.5.0** · Trust SoT：[ADR-024](adr/024-dictation-plus-asr-refiner-meeting.md)  
+> 产品 **0.6.7** · Trust SoT：[ADR-024](adr/024-dictation-plus-asr-refiner-meeting.md)  
 > 听写+ 设计：[dictation-plus SoT](superpowers/specs/2026-08-07-dictation-plus-design.md)  
 > 本机 STT：[ADR-023](adr/023-voice-local-stt-path-b.md) · [local STT SoT](superpowers/specs/2026-08-07-voice-local-stt-design.md)  
 > 会议设计：[meeting-minutes SoT](superpowers/specs/2026-08-07-meeting-minutes-design.md) · [Mtg3 diarize](superpowers/specs/2026-08-08-meeting-mtg3-diarize-design.md)
@@ -64,14 +64,14 @@ OS 级全局热键（失焦仍按住）属后续增强。
 
 ### 2.5 本机组件（cmspark-whisper）与模型
 
-本机听写分两层，都可在 **设置 → 听写** 完成：
+本机听写分两层，都可在 **设置 → 输入与语音** 完成：
 
 | 层 | 内容 | 如何就绪 |
 |----|------|----------|
 | **本机组件** | `cmspark-whisper` + 动态库 | 安装包优先内置；若提示「未找到」→ **「安装本机听写组件」**。Windows：HTTPS 自动下载 + sha256 pin。macOS：安装包内置或从本机 **Homebrew whisper-cpp** 拷贝（需已 `brew install whisper-cpp`） |
 | **模型权重** | ggml-small / medium / large-v3-turbo | 设置页下载到 `~/.cmspark-agent/models/whisper/`；下载完成自动设为活动模型；已下载模型会被自动识别（设置页状态探测） |
 
-下载源默认 huggingface.co，网络受限时在 **设置 → 听写 → 模型下载源** 改填镜像（如 `https://hf-mirror.com`），或设环境变量 `CMSPARK_HF_ENDPOINT`（优先级更高）。
+下载源默认 huggingface.co，网络受限时在 **设置 → 输入与语音 → 模型下载源** 改填镜像（如 `https://hf-mirror.com`），或设环境变量 `CMSPARK_HF_ENDPOINT`（优先级更高）。
 本机模型不可用时：默认**当次会话自动改用浏览器听写**并显示横幅（非静默、不改配置）；可在设置关闭「本机模型不可用时自动使用浏览器听写」。  
 
 打包：`build-package.bat` 在缺少 `companion/dist/bin/cmspark-whisper-win-x64.exe` 时会按 `assets/whisper-binary.manifest.json` **自动拉取**（`CMSPARK_WHISPER_AUTO_FETCH=0` 可关）。  
@@ -115,7 +115,7 @@ Windows pin 与 [whisper.cpp v1.7.6](https://github.com/ggml-org/whisper.cpp/rel
 | **Mtg1** | 显式「开始录制」本机分段 STT；结束生成纪要；`meeting_privacy_ack_v1`；默认删音频 |
 | **Mtg2** | 智能分段（静音/段落/软长度切）；默认/批量说话人；上传 `.txt/.md`；上传音频 → 本机转写 |
 | **Mtg3** | 实验：**自动标「发言人N」**（**非身份识别**）；人数可选「自动」或手动 2–6；弱标交替 |
-| **Mtg3.5 说话人嵌入** | **自动标说话人（说话人嵌入 · 实验）**：上传音频段 → 本机 ONNX 说话人嵌入 + 聚类（需先在 设置 → 听写方式 下载「说话人分离模型」；未就绪会明确提示，**不静默落回旧引擎**）。模型与转写模型共享磁盘预算；音频不出本机。评测：校准集 PASS（2026-09-04）但 **round-2 held-out 门 FAIL**（2026-09-05，全新说话人档案：人数正确率 0.667 < 0.75、过拆 held-long12-K3 k=5/truth 3）→ 保持「实验」标注；门已收紧（held-out 独立过门 + \|k−truth\| ≤ 1 + gate FAIL 默认 exit 1，`companion/scripts/diarize-eval.mjs`）。另有「旧版 3 维（区分度低）」显式回退按钮（实验 · 无需下载模型）与弱标（交替，实验） |
+| **Mtg3.5 说话人嵌入** | **自动标说话人（说话人嵌入 · 实验）**：上传音频段 → 本机 ONNX 说话人嵌入 + 聚类（需先在 设置 → 输入与语音 → 听写方式 下载「说话人分离模型」；未就绪会明确提示，**不静默落回旧引擎**）。模型与转写模型共享磁盘预算；音频不出本机。评测：校准集 PASS（2026-09-04）但 **round-2 held-out 门 FAIL**（2026-09-05，全新说话人档案：人数正确率 0.667 < 0.75、过拆 held-long12-K3 k=5/truth 3）→ 保持「实验」标注；门已收紧（held-out 独立过门 + \|k−truth\| ≤ 1 + gate FAIL 默认 exit 1，`companion/scripts/diarize-eval.mjs`）。另有「旧版 3 维（区分度低）」显式回退按钮（实验 · 无需下载模型）与弱标（交替，实验） |
 | **P1 近实时** | 会议录制默认渐进假设出字 + 约 8s 窗定稿（同听写 M2；非 token 真流式；large 仅终稿） |
 | **P2 长会** | 直播录硬上限 **3 小时**（2 小时软提示）；上传音频同上限；纪要输入抬到 20 万字 |
 | **P4 纠错/分段** | 段定稿 **opt-in AI 纠错**（上文上下文 + correct_only）；段间空行分段；结束时可选自动智能分段 |
@@ -123,7 +123,7 @@ Windows pin 与 [whisper.cpp v1.7.6](https://github.com/ggml-org/whisper.cpp/rel
 ### 3.3 会议录制操作要点
 
 1. 先确认 **本机语音隐私** + **会议隐私**（双 ack 后「开始录制」才可点）  
-2. 设置 → 听写：组件/模型就绪，活动模型建议 **medium**  
+2. 设置 → 输入与语音：组件/模型就绪，活动模型建议 **medium**  
 3. 可选：勾选 **录制 AI 纠错（参考上文）**、**结束时智能分段**  
 4. 录制中段失败：若为 soft 类错误，banner 会说明 **本段字已丢失（不可恢复）**，后续段继续；结束仍默认删音频  
 5. 结束后可再点 **智能分段** / 生成纪要（纪要可套用户模板）
@@ -187,4 +187,4 @@ Windows pin 与 [whisper.cpp v1.7.6](https://github.com/ggml-org/whisper.cpp/rel
 
 - [ADR-023 本机 STT](adr/023-voice-local-stt-path-b.md)  
 - [ADR-024 听写+ · Refiner · 会议落盘](adr/024-dictation-plus-asr-refiner-meeting.md)  
-- Side Panel → **设置 → 语音 / 听写**  
+- Side Panel → **设置 → 输入与语音**  
diff --git a/docs/summoner-user-guide.md b/docs/summoner-user-guide.md
index 376c78d2..21cab51f 100644
--- a/docs/summoner-user-guide.md
+++ b/docs/summoner-user-guide.md
@@ -1,6 +1,6 @@
 # 召唤器（Capture 卡）— 用户指南
 
-> 产品 **0.6.0** · 产品句：[PRODUCT.md](../PRODUCT.md) · 设计：[DESIGN.md](DESIGN.md)  
+> 产品 **0.6.7** · 产品句：[PRODUCT.md](../PRODUCT.md) · 设计：[DESIGN.md](DESIGN.md)  
 > 听写/会议细节：[meeting-and-dictation-user-guide.md](meeting-and-dictation-user-guide.md) · 外部热键：[summoner-launcher-plugins.md](summoner-launcher-plugins.md)
 
 ### 能力坐标
@@ -15,7 +15,7 @@
 
 ## 1. 一句话
 
-召唤器是一张 **360×420** 的 HTML Capture 卡：说话或打字把活交出去。人盯着 Chrome 时用侧栏 Operate；危险只在确认台。
+召唤器是一张 HTML Capture 卡（默认 **1040×760**，`OVERLAY_WINDOW_SIZE`；紧凑切换 **360×420**）：说话或打字把活交出去。人盯着 Chrome 时用侧栏 Operate；危险只在确认台。
 
 Mac 菜单 / 已配置热键 / 工具栏 **C** / 侧栏顶栏 **弹出对话框** 打开的是**同一张卡**。
 
diff --git a/docs/superpowers/plans/2026-09-08-s107-honesty-067.md b/docs/superpowers/plans/2026-09-08-s107-honesty-067.md
new file mode 100644
index 00000000..ab942555
--- /dev/null
+++ b/docs/superpowers/plans/2026-09-08-s107-honesty-067.md
@@ -0,0 +1,39 @@
+# 0.6.7 honesty close — S107 dual AWN
+
+GitHub: n/a (docs honesty + existing-behavior bugfix; Issue-first 例外)  
+HEAD base: `4a63de56`  
+Dual: Claude+Kimi both `APPROVE_WITH_NITS` on `docs/audit/reviews/s107-health-20260908/`
+
+## Goal
+
+Close PRODUCT/SKEPTIC/UX REJECT without new product surface. Bump lockstep **0.6.6 → 0.6.7**. Do **not** call this 0.7.0 (enterprise dual-scene still not accepted). Frozen: #230 overlay-acl, #228 default outbound, #363 eval gate.
+
+## Lanes (file mutex)
+
+| Lane | Owner | Files (ONLY these) |
+|------|--------|-------------------|
+| L0 lockstep | orchestrator | `companion/package.json`, `companion/package-lock.json`, `chrome-extension/package.json`, `chrome-extension/package-lock.json`, `scripts/installer.nsi`, `companion/src/acp/jsonrpc-stdio.ts`, `companion/src/outbound-mcp/stdio-server.ts`, `AGENTS.md` version lines, `CHANGELOG.md` (after code) |
+| L1 docs | grok + claude | README, PRODUCT, CLAUDE, docs/GOAL, docs/README, docs/architecture, docs/summoner-user-guide, docs/meeting-and-dictation-user-guide, docs/computer-use-user-guide, docs/host-and-apps, companion/README.txt |
+| L2 UX copy | grok + pi | ContextPanelHost.tsx, MeetingPanel.tsx, meeting-diarize-copy.ts + test, summoner-web.ts STT strings, diarize-embed.ts user message |
+| L3 CLI | claude | `companion/src/index.ts` only (+ a focused test if one exists / add `companion/tests/cli-version.test.ts`) |
+| L4 redact | pi + grok | `tool-persistence-redact.ts`, `adapter.ts` persistAssistantDraft, tests |
+
+## P0
+
+1. Living docs lock **0.6.7**. Capture default **1040×760**, compact **360×420**. Knowledge inject = TF-IDF top-k (auto 5 / all 8) + 8000 budget. #258–#260 off remaining; embedding stays experimental. GOAL G19 PTY = Darwin shipped / not a non-goal.
+2. Host close: if `activePanel==="meeting" && meetingCaptureActive` label **结束并收起** (keep unmount `meeting.end`).
+3. User-visible 「设置 → 听写」/「设置 › 听写」→ 「设置 → 输入与语音」. 「听写方式」keep as item under that page.
+
+## P1
+
+4. CLI `--version`/`-V`/`version` exit 0; `status`/`stop` alias daemon (no stub lie).
+5. Redact assistant `tool_calls[].function.arguments` before `addMessage`.
+6. Archive CHANGELOG Unreleased into `[0.6.7]` plus this honesty wave.
+
+## Review
+
+Author ≠ reviewer. After impl: claude reviews L4, pi reviews L3, kimi reviews L1+L2 (read-only `-p`). Then dual claude+kimi on full diff.
+
+## Out of scope
+
+NSIS INSTDIR wipe, tray pid file, god-file splits, 0.7.0 enterprise GA, overlay ACL.
diff --git a/docs/workspace-ui.md b/docs/workspace-ui.md
index 801339df..f8d02c50 100644
--- a/docs/workspace-ui.md
+++ b/docs/workspace-ui.md
@@ -17,6 +17,6 @@ CMspark 的主界面围绕当前对话展开。宽屏左侧显示最近对话、
 
 对话管理包含“时间”“标签”“手动分组”“AI 分组”。对话行的“分类”可编辑人工标签、选择/新建手动分组或留空移出；人工标签与只读 AI 标签独立保存。AI 分组根据 AI 标签的首项动态显示，重新提取可能改变 AI 归组，不会覆盖手动分组。点击“AI 提取标签”每次处理最多20个未标注对话；完成后可再次处理剩余。
 
-“整理助手”是规则扫描，供核对后提取要点或移入回收站；“关系图谱”打开原有会话关系图。管理面板不会阻挡运行中的停止按钮，待确认操作到达时会自动收起。分类保存需收到服务端确认；如果旧 Companion 未支持人工标签，会提示更新，不会显示假成功。
+“整理助手”是规则扫描，供核对后提取要点或移入回收站（提供全选/全不选；删除在面板内确认，不走会被侧栏吞掉的系统对话框）。对话管理工具栏有「全选」当前列表可删会话。行内删除同样在面板内确认后移入回收站。“关系图谱”打开原有会话关系图。管理面板不会阻挡运行中的停止按钮，待确认操作到达时会自动收起。分类保存需收到服务端确认；如果旧 Companion 未支持人工标签，会提示更新，不会显示假成功。
 
 标签视图的“未标注”表示人工和 AI 标签均为空；图谱的“为未标注提取要点”仅检查 AI 标签，只有人工标签的对话仍可提取。
diff --git a/memory/overview.md b/memory/overview.md
index cc3fba72..020a6822 100644
--- a/memory/overview.md
+++ b/memory/overview.md
@@ -2,9 +2,9 @@
 
 > Low-frequency status. Prefer session.md for hot work; this file is remote-synced snapshot.
 
-**Updated**: 2026-09-07 (lockstep 0.6.6)
+**Updated**: 2026-09-08 (lockstep 0.6.7)
 
-## CMspark — 产品 0.6.6
+## CMspark — 产品 0.6.7
 
 | 轴 | 状态 |
 |----|------|
@@ -20,10 +20,10 @@
 
 ## Branch lock (S104)
 
-- 包装 **0.6.6**（已装机）：#423 Qwen3-VL 坐标系修复（L-QW-3 修订 always-map，评测门 0/10→6/10）· create-dmg cp -R 封签修复 · installer.nsi 版本锚补钉。0.6.5 = 召唤器全链路 #433 P1–P3 + #439 LLM 检索工具；0.6.4 = 内嵌终端 #432 + 召唤器命令面板。0.6.1 基础上：测试污染根治 #404–#406 · 失败升级链 #409 · outbound MCP 三件 · 全历史专家 #411/#418。
+- 包装 **0.6.7**（S107 诚实关门）：活文档锁步、Capture 1040×760、知识 TF-IDF top-k、会议收起文案、CLI `--version`、assistant args 落盘脱敏。本机此前狗食仍是 0.6.6 NSIS，需再编包才换装。0.6.6 = #423 Qwen3-VL 坐标系。0.7.0 企业双场景仍未验收。
 - **评审弧闭环**：c39d7d3e..26949cbb 四路对抗 7 MAJOR 全修（#261–#264），main tip `18d843d1`。
 - S104 起 origin 已含开闸+查重（#280–#283）；评审波次（#286–#295）十张 PR 已合入，见 GATE-SUMMARY。
-- **活票**：#230 冻 F-S-10 / overlay-acl；#258–#260 语音/会议。T1 #228 已关，**禁扩** profile。
+- **活票**：#230 冻 F-S-10 / overlay-acl。T1 #228 已关，**禁扩** profile。#258–#260 已在树（embedding experimental）。
 - **不要**：overlay Allow/Deny；第二扩展；`ws_secret` 当 grant；#230 整票「继续」；宣称 Capture/CU/F-S-10 闭合；StatusRail 手风琴 / Wave 2 FocusBand。
 
 ## Next
@@ -33,6 +33,6 @@
 
 ## Docs SoT
 
-- 活切点：`CHANGELOG.md` **0.6.6**
+- 活切点：`CHANGELOG.md` **0.6.7**
 - 0.5.3 快照：`docs/superpowers/specs/2026-08-27-post-227-status.md`（SNAPSHOT）
 - 用户 / 架构：`docs/README.md` · `PRODUCT.md`
diff --git a/memory/session.md b/memory/session.md
index b0c7ed44..ea8a6011 100644
--- a/memory/session.md
+++ b/memory/session.md
@@ -2,6 +2,16 @@
 
 ## Current Session
 
+### S107 (2026-09-08) [pull main · NSIS 换装 · 多路对抗体检]
+- **任务**：拉最新 → `package.sh windows-x64` + `/S` 替换本机 → 多路独立对抗彻底体检。
+- **pull** `[executed]`：stash session.md → `main` ff `7ab36063` → **`4a63de56`**（#485 workspace 归属；落后 270 commits）。stash pop 冲突，保留 origin session.md 后写本条。
+- **包装** `[executed]`：`CMSPARK_REQUIRE_NSIS=1` Git Bash `package.sh windows-x64`（先 npm ci companion+extension）。zip **81M** `cmspark-v0.6.6-windows-x64.zip` + **52M** `CMspark-Setup-v0.6.6.exe`。staging **无** SEA；whisper win-x64 + ort napi win32/x64 + @lydell/node-pty 已入。
+- **换装** `[executed]`：daemon 本未跑；`/S` exit 0。ARP **0.6.6**。`wscript launch-hidden.vbs` → **3s** `127.0.0.1:23401` LISTENING（pid 17588 daemon + 17560 tray）。`cmspark-agent v0.6.6`；扩展 manifest 0.6.6。INSTDIR 残留 `gif.jpg`/`gifcode_test`（安装器 overlay 不wipe）。未改用户意图配置。
+- **对抗** `[executed]`：6 路独立。A PRODUCT **REJECT** · B CORR **AWN** · C SEC **AWN** · D SKEPTIC **REJECT** · E ARCH **AWN 6.6/C+** · F UX **REJECT**。A+D 独立命中：文档 0.6.0 vs 锁 0.6.6；README 全选灌库 vs TF-IDF top-k（**S106 同洞**）；Capture 360×420 vs `OVERLAY_WINDOW_SIZE` 1040×760。UX：Host「收起」unmount `meeting.end`；「设置→听写」死路径。合成 `docs/audit/reviews/s107-health-20260908/synthesis.md`。
+- **不阻塞狗食**（已换装 0.6.6）。**阻塞诚实发版**：前门文档 + 知识注入 + Capture 尺寸 + 会议收起文案。
+- **双路复审** `[executed]`：claude **AWN** + kimi **AWN**（`both_ok=true`）。五条 BLOCK 两路独立 TRIGGERED。NIT：听写死路径更宽（506/768/936）；unmount `meeting.end` 勿删、改 Host 文案。`docs/audit/reviews/s107-health-20260908/dual-*.md`。
+- **0.6.7 诚实关门** `[executed]`：lockstep 0.6.7。L1 文档 grok · L2 UX grok · L4 脱敏 grok · L3 CLI 本会话（claude -p 空转）。互审 kimi **AWN** + grok **AWN**；Pi XML 失败；Claude 空转杀掉。折 NIT：MeetingPanel「设置→语音」；AGENTS/CONTRIBUTING 余项。package-gates 125/0；cli+redact 11/11；diarize-copy 5/5；companion tsc clean。未再编 NSIS（本机仍 0.6.6 包）。#230 仍冻。
+
 ### S106 tail (2026-09-06) [0.6.1 打包换装]
 - make package-macos → CMspark-v0.6.1-macOS.dmg（80M）→ /Applications 换装；验证：Info.plist 0.6.1、daemon 23401 LISTEN、tray running、扩展 WS 认证。
 - Recorded: yes — merge-and-cleanup-separate-steps / eval-gate-fail-check-harness-first 入 instincts
diff --git a/scripts/installer.nsi b/scripts/installer.nsi
index 0ad79abd..edd968ad 100644
--- a/scripts/installer.nsi
+++ b/scripts/installer.nsi
@@ -11,7 +11,7 @@
 !define PRODUCT_NAME "CMspark"
 ; Prefer -DPRODUCT_VERSION= from build-windows-installer.sh; fallback must match companion/package.json.
 !ifndef PRODUCT_VERSION
-  !define PRODUCT_VERSION "0.6.6"
+  !define PRODUCT_VERSION "0.6.7"
 !endif
 !define PRODUCT_PUBLISHER "CMspark"
 !define PRODUCT_UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${PRODUCT_NAME}"

FULL FILE chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
// ContextPanelHost — single owner of context panel state, loaders, mounts,
// and cmspark:open-context-panel (UIUX v2 §4.7 M1). Host is SoT for panels.
// #321 PR-1: legacy permanent BottomBar tab strip deleted (was PR5-gated off).

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
} from "react"
import { useAgentStore } from "../store/agentStore"
import {
  contextBarTabsForLevel,
  contextBarOverflowTabsForLevel,
} from "../mode/mode-controller"
import type { CapabilityLevel } from "../types"
import { KnowledgeSubPanel } from "./KnowledgeSubPanel"
import { McpPanel } from "./McpPanel"
import { AppsPanel } from "./AppsPanel"
import { PacksPanel } from "./PacksPanel"
import { BoardPanel } from "./BoardPanel"
import { MeetingPanel } from "./MeetingPanel"
import { tokens } from "../ui/tokens"
import {
  IconTabs,
  IconHistory,
  IconSkills,
  IconKnowledge,
  IconMcp,
  IconApps,
  IconPacks,
  IconMic,
  IconList,
} from "../ui/icons"

// ── Registry ───────────────────────────────────────────────────────────────

export type ContextPanelId =
  | "tabs"
  | "history"
  | "skills"
  | "knowledge"
  | "packs"
  | "board"
  | "mcp"
  | "apps"
  | "meeting"

export type ContextPanelTabDef = {
  id: ContextPanelId
  label: string
  Icon: ComponentType<{ size?: number }>
}

/** Canonical panel registry (labels + icons). Strip and Host share this. */
// #321 PR-5: packs/meeting/board each get their own icon (were all IconSkills
// collisions); icons come from the existing ui/icons set — nothing new drawn.
export const CONTEXT_PANEL_TABS: ContextPanelTabDef[] = [
  { id: "tabs", label: "浏览器标签页", Icon: IconTabs },
  { id: "history", label: "历史", Icon: IconHistory },
  { id: "skills", label: "技能", Icon: IconSkills },
  { id: "knowledge", label: "知识", Icon: IconKnowledge },
  { id: "packs", label: "场景与专家", Icon: IconPacks },
  { id: "meeting", label: "会议", Icon: IconMic },
  { id: "board", label: "任务板", Icon: IconList },
  { id: "mcp", label: "MCP", Icon: IconMcp },
  { id: "apps", label: "应用", Icon: IconApps },
]

const KNOWN_IDS = new Set(CONTEXT_PANEL_TABS.map((t) => t.id))

export function isContextPanelId(id: string): id is ContextPanelId {
  return KNOWN_IDS.has(id as ContextPanelId)
}

export function contextPanelLabel(id: ContextPanelId): string {
  return CONTEXT_PANEL_TABS.find((t) => t.id === id)?.label ?? id
}

// ── Loaders ────────────────────────────────────────────────────────────────

export function loadPanelData(
  id: ContextPanelId,
  activeThreadId: string | null,
  dispatch: ReturnType<typeof useAgentStore>["dispatch"],
) {
  if (id === "tabs") {
    chrome.tabs.query({}, (tabs) => {
      dispatch({ type: "SET_TAB_LIST", tabs })
    })
  }
  if (id === "history") {
    chrome.runtime.sendMessage({ type: "history.query", limit: 50, thread_id: activeThreadId })
  }
  if (id === "skills") {
    // Force rescan when opening Skills — picks up Finder drops / external edits
    // even if mtime fingerprint was edge-case stale; cheap after ensureFresh path.
    chrome.runtime.sendMessage({ type: "skill.refresh" })
  }
  if (id === "knowledge") {
    chrome.runtime.sendMessage({ type: "knowledge.list" })
  }
  if (id === "packs") {
    chrome.runtime.sendMessage({ type: "pack.list" })
    chrome.runtime.sendMessage({ type: "modules.list" })
  }
  if (id === "mcp") {
    chrome.runtime.sendMessage({ type: "mcp.list" })
  }
  if (id === "apps") {
    chrome.runtime.sendMessage({ type: "apps.list" })
  }
}

// ── Host API context ───────────────────────────────────────────────────────

export type ContextPanelHostApi = {
  activePanel: ContextPanelId | null
  /** Toggle: same id closes; different id opens + loads. */
  openPanel: (id: ContextPanelId) => void
  /** Force-open (no toggle) — used by slash / custom events. */
  openPanelForce: (id: ContextPanelId) => void
  closePanel: () => void
}

const ContextPanelHostContext = createContext<ContextPanelHostApi | null>(null)

export function useContextPanelHost(): ContextPanelHostApi {
  const ctx = useContext(ContextPanelHostContext)
  if (!ctx) {
    throw new Error("useContextPanelHost must be used within ContextPanelHostProvider")
  }
  return ctx
}

/** Soft read for optional chrome that may render outside provider in tests. */
export function useContextPanelHostOptional(): ContextPanelHostApi | null {
  return useContext(ContextPanelHostContext)
}

// ── Provider ───────────────────────────────────────────────────────────────

export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const closePanel = useCallback(() => {
    setActivePanel(null)
  }, [])

  useEffect(() => {
    if (state.settingsOpen) closePanel()
  }, [state.settingsOpen, closePanel])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activeThreadId, dispatch],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      if (activePanel === id) {
        setActivePanel(null)
        return
      }
      setActivePanel(id)
      loadPanelData(id, activeThreadId, dispatch)
    },
    [activePanel, activeThreadId, dispatch],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      setActivePanel(null)
    }
  }, [activePanel, allowedIds, overflowIds])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      setActivePanel(raw)
      loadPanelData(raw, activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      setActivePanel("knowledge")
      loadPanelData("knowledge", activeThreadId, dispatch)
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [activeThreadId, dispatch])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      setActivePanel(null)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel }),
    [activePanel, openPanel, openPanelForce, closePanel],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel } = useContextPanelHost()
  const meetingCaptureActive = useAgentStore().state.meetingCaptureActive
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)
  const closeEndsMeeting = activePanel === "meeting" && meetingCaptureActive

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        {closeEndsMeeting ? (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="结束并收起"
            aria-label="结束并收起"
            onClick={closePanel}
          >
            结束并收起
          </button>
        ) : (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="收起面板 (Esc)"
            aria-label="收起面板"
            onClick={closePanel}
          >
            收起
          </button>
        )}
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}

// ── Built-in panel bodies (moved from BottomBar) ───────────────────────────

function TabsPanel() {
  const { state, dispatch } = useAgentStore()

  const handleTogglePin = (tabId: number) => {
    const pinnedTabIds = state.pinnedTabIds.includes(tabId)
      ? state.pinnedTabIds.filter((id) => id !== tabId)
      : [...state.pinnedTabIds, tabId]

    dispatch({ type: "SET_PINNED_TABS", tabIds: pinnedTabIds })

    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { pinned_tabs: pinnedTabIds },
      })
    }
  }

  return (
    <div style={styles.panelContent}>
      {state.tabList.length === 0 && (
        <div style={styles.emptyText}>暂无标签页数据</div>
      )}
      {state.tabList.map((tab) => (
        <label key={tab.id} style={styles.tabRow}>
          <input
            type="checkbox"
            checked={state.pinnedTabIds.includes(tab.id!)}
            onChange={() => handleTogglePin(tab.id!)}
            style={{ marginRight: 8 }}
          />
          <span style={styles.tabTitle}>{tab.title || tab.url}</span>
          <span style={styles.tabUrl}>{tab.id}</span>
        </label>
      ))}
    </div>
  )
}

function HistoryPanel() {
  const { state } = useAgentStore()
  const operations = state.operations || []
  const groups = groupBy(operations, "thread_id")

  return (
    <div style={styles.panelContent}>
      {state.operations.length === 0 && (
        <div style={styles.emptyText}>暂无操作历史</div>
      )}
      {Object.entries(groups).map(([threadId, ops]) => (
        <div key={threadId} style={{ marginBottom: 8 }}>
          <div style={styles.groupHeader}>#{threadId}</div>
          {ops.map((op) => (
            <div key={op.id} style={styles.historyRow}>
              <span style={{ color: op.success ? tokens.success : tokens.danger }}>
                {op.success ? "✓" : "✗"}
              </span>
              <span style={{ flex: 1, marginLeft: 6, fontFamily: "monospace", fontSize: 11 }}>
                {op.tool_name}
              </span>
              <span style={{ color: tokens.textMuted, fontSize: 11 }}>
                {op.created_at?.slice(11, 19)}
              </span>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

function SkillsPanel() {
  const { state, dispatch } = useAgentStore()
  const [importUrl, setImportUrl] = useState("")
  const [showUrlImport, setShowUrlImport] = useState(false)
  const [showPathImport, setShowPathImport] = useState(false)
  const [pathInput, setPathInput] = useState("")
  const [menuOpen, setMenuOpen] = useState<string | null>(null)
  const [currentHostname, setCurrentHostname] = useState<string>("")
  const menuRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const zipInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url
      if (url) {
        try {
          setCurrentHostname(new URL(url).hostname)
        } catch {
          setCurrentHostname("")
        }
      }
    })
  }, [state.tabList])

  const handleModeChange = (mode: "auto" | "all" | "manual") => {
    dispatch({ type: "SET_SKILL_SELECTION_MODE", mode })
    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { skill_selection_mode: mode },
      })
    }
  }

  useEffect(() => {
    if (!menuOpen) return
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(null)
      }
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [menuOpen])

  const handleFolderFiles = async (files: FileList | File[]) => {
    const fileArr = Array.from(files)
    if (fileArr.length === 0) return

    const hasSkillMd = fileArr.some(
      (f) => f.name === "SKILL.md" || f.webkitRelativePath.endsWith("/SKILL.md"),
    )
    if (!hasSkillMd) {
      alert("文件夹中未找到 SKILL.md 文件")
      return
    }

    const payload: { path: string; content: string }[] = []
    for (const file of fileArr) {
      const content = await file.text()
      const filePath = file.webkitRelativePath || file.name
      const parts = filePath.split("/")
      const relPath = parts.length > 1 ? parts.slice(1).join("/") : parts[0]
      payload.push({ path: relPath, content })
    }

    chrome.runtime.sendMessage({ type: "skill.import-files", files: payload })
  }

  const handlePathImport = () => {
    if (pathInput.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import-path", dir_path: pathInput.trim() })
      setPathInput("")
      setShowPathImport(false)
    }
  }

  const handleExport = (skillName: string) => {
    chrome.runtime.sendMessage({ type: "skill.export", skill_name: skillName })
    setMenuOpen(null)
  }

  const handleDelete = (skillName: string) => {
    if (confirm(`确定删除技能 "${skillName}"？`)) {
      chrome.runtime.sendMessage({ type: "skill.delete", skill_name: skillName })
    }
    setMenuOpen(null)
  }

  const handleImportFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const content = reader.result as string
      chrome.runtime.sendMessage({ type: "skill.import", content })
    }
    reader.readAsText(file)
  }

  const handleImportZip = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = reader.result as string
      const base64 = dataUrl.split(",")[1]
      if (base64) {
        chrome.runtime.sendMessage({ type: "skill.import-folder", zip_data: base64 })
      }
    }
    reader.readAsDataURL(file)
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()

    const items = e.dataTransfer.items
    if (items && items.length > 0) {
      const entry = items[0].webkitGetAsEntry()
      if (entry && entry.isDirectory) {
        const files = await readDirectoryEntry(entry as FileSystemDirectoryEntry)
        if (files.length > 0) {
          handleFolderFiles(files)
        }
        return
      }
    }

    const file = e.dataTransfer.files[0]
    if (!file) return
    if (file.name.endsWith(".zip")) {
      handleImportZip(file)
    } else if (file.name.endsWith(".md") || file.name.endsWith(".markdown")) {
      handleImportFile(file)
    }
  }

  const handleUrlImport = () => {
    if (importUrl.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import", url: importUrl.trim() })
      setImportUrl("")
      setShowUrlImport(false)
    }
  }

  const skillList = Array.isArray(state.skills) ? state.skills : []
  const groupedSkills = groupSkillsBySite(skillList, currentHostname)

  const modeLabels: Record<string, string> = { auto: "自动", all: "全选", manual: "按需" }
  const skillMode = state.skillSelectionMode || "auto"
  const skillManual = skillMode === "manual"
  const skillModeHint =
    skillMode === "auto"
      ? "自动：按站点/消息匹配技能，列表勾选不生效（未勾选 ≠ 不会调用）。"
      : skillMode === "all"
        ? "全选：全部技能参与索引，无需单独勾选。"
        : "按需：仅勾选的技能会参与本对话。"

  return (
    <div style={styles.panelContent}>
      <div style={styles.modeSwitcher}>
        {(["auto", "all", "manual"] as const).map((mode) => (
          <button
            key={mode}
            style={{
              ...styles.modeBtn,
              background: skillMode === mode ? tokens.accent : tokens.bgElevated,
              color: skillMode === mode ? "#fff" : tokens.textSecondary,
              borderColor: skillMode === mode ? tokens.accent : tokens.border,
            }}
            onClick={() => handleModeChange(mode)}
            title={
              mode === "auto"
                ? "自动匹配当前站点和消息"
                : mode === "all"
                  ? "注入所有技能索引"
                  : "仅使用勾选技能"
            }
          >
            {modeLabels[mode]}
          </button>
        ))}
      </div>
      <div
        style={{
          fontSize: 10,
          color: tokens.textMuted,
          lineHeight: 1.4,
          marginBottom: 8,
        }}
      >
        {skillModeHint}
      </div>

      <div
        style={{
          fontSize: 10,
          color: tokens.textSecondary,
          lineHeight: 1.4,
          marginBottom: 8,
          padding: "6px 8px",
          background: tokens.accentSoft,
          borderRadius: tokens.radiusSm,
          border: `1px solid ${tokens.border}`,
        }}
      >
        <strong style={{ color: tokens.accentText }}>安装技能（推荐）</strong>
        <div style={{ marginTop: 3 }}>
          GitHub 仓库：下载 ZIP → <strong>导入 ZIP</strong>；或解压后用{" "}
          <strong>导入文件夹</strong>。单文件 skill 用「导入」.md。
        </div>
        <div style={{ marginTop: 3, color: tokens.textMuted }}>
          勿用「场景」里的「应用安全审查」装技能 — 那会限制本对话工具。
        </div>
      </div>

      <div style={styles.skillToolbar}>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => chrome.runtime.sendMessage({ type: "skill.refresh" })}
          title="重新扫描技能目录（含 ~/.cmspark-agent/skills 外部变更）"
        >
          ↻ 刷新
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => fileInputRef.current?.click()}
          title="从文件导入 .md"
        >
          📁 导入
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => zipInputRef.current?.click()}
          title="从 ZIP 导入文件夹技能"
        >
          📦 导入 ZIP
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowPathImport(!showPathImport)}
          title="从文件夹导入"
        >
          📂 导入文件夹
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowUrlImport(!showUrlImport)}
          title="从 URL 导入"
        >
          🔗 URL
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".md,.markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportFile(file)
          }}
        />
        <input
          ref={zipInputRef}
          type="file"
          accept=".zip"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportZip(file)
          }}
        />
      </div>

      {showUrlImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="url"
            placeholder="https://...skill.md"
            value={importUrl}
            onChange={(e) => setImportUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleUrlImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handleUrlImport}>
            安装
          </button>
        </div>
      )}

      {showPathImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="text"
            placeholder="~/.claude/skills/datayes-api-search 或绝对路径"
            value={pathInput}
            onChange={(e) => setPathInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handlePathImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handlePathImport}>
            导入
          </button>
        </div>
      )}

      <div
        style={styles.dropZone}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        {skillList.length === 0 && (
          <div style={styles.emptyText}>暂无技能，拖拽 .md 文件或点击导入</div>
        )}
      </div>

      {groupedSkills.map(([groupName, skills]) => (
        <div key={groupName}>
          <div style={styles.groupHeader}>{groupName}</div>
          {skills.map((skill) => {
            const active = state.activeSkillIds.includes(skill.name)
            return (
              <div
                key={skill.name}
                style={{
                  ...styles.skillRow,
                  background: skillManual && active ? tokens.bgActive : "transparent",
                }}
              >
                {skillManual ? (
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={() => {
                      const activeSkillIds = active
                        ? state.activeSkillIds.filter((id) => id !== skill.name)
                        : [...state.activeSkillIds, skill.name]
                      dispatch({ type: "TOGGLE_SKILL", skillId: skill.name })
                      if (state.activeThreadId) {
                        chrome.runtime.sendMessage({
                          type: "thread.update",
                          threadId: state.activeThreadId,
                          updates: { active_skill_ids: activeSkillIds },
                        })
                      }
                    }}
                    style={{ marginRight: 8, flexShrink: 0 }}
                    title="勾选后参与本对话"
                  />
                ) : (
                  <span
                    style={{
                      width: 16,
                      textAlign: "center",
                      color: tokens.textMuted,
                      fontSize: 11,
                      flexShrink: 0,
                      marginRight: 4,
                    }}
                    title={
                      skillMode === "all"
                        ? "全选模式：全部参与索引"
                        : "自动模式：由匹配决定，与勾选无关"
                    }
                    aria-hidden
                  >
                    {skillMode === "all" ? "◎" : "◇"}
                  </span>
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 500,
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    {skill.name}
                    {skill.site && <span style={styles.siteBadge}>{skill.site}</span>}
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      color: tokens.textSecondary,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {skill.description}
                  </div>
                </div>
                {skill.builtin && <span style={styles.badge}>内置</span>}
                {!skill.builtin && (
                  <div
                    style={{ position: "relative" }}
                    ref={menuOpen === skill.name ? menuRef : undefined}
                  >
                    <button
                      style={styles.menuBtn}
                      onClick={() => setMenuOpen(menuOpen === skill.name ? null : skill.name)}
                      title="更多操作"
                    >
                      ···
                    </button>
                    {menuOpen === skill.name && (
                      <div style={styles.menuDropdown}>
                        <button style={styles.menuItem} onClick={() => handleExport(skill.name)}>
                          📤 导出
                        </button>
                        <button
                          style={{ ...styles.menuItem, color: tokens.danger }}
                          onClick={() => handleDelete(skill.name)}
                        >
                          删除
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}

// ── Helpers ────────────────────────────────────────────────────────────────

async function readDirectoryEntry(dirEntry: FileSystemDirectoryEntry): Promise<File[]> {
  const files: File[] = []
  const folderName = dirEntry.name

  async function readDir(entry: FileSystemDirectoryEntry, prefix: string): Promise<void> {
    const reader = entry.createReader()
    const readBatch = (): Promise<FileSystemEntry[]> => {
      return new Promise((resolve) => {
        reader.readEntries((entries) => resolve(entries))
      })
    }

    let batch = await readBatch()
    while (batch.length > 0) {
      for (const e of batch) {
        if (e.isFile) {
          const file = await new Promise<File>((resolve) => {
            ;(e as FileSystemFileEntry).file(resolve)
          })
          ;(file as File & { webkitRelativePath: string }).webkitRelativePath = prefix + e.name
          files.push(file)
        } else if (e.isDirectory) {
          await readDir(e as FileSystemDirectoryEntry, prefix + e.name + "/")
        }
      }
      batch = await readBatch()
    }
  }

  await readDir(dirEntry, folderName + "/")
  return files
}

function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> {
  return arr.reduce(
    (acc, item) => {
      const k = String(item[key] ?? "unknown")
      if (!acc[k]) acc[k] = []
      acc[k].push(item)
      return acc
    },
    {} as Record<string, T[]>,
  )
}

type SkillListItem = {
  name: string
  description?: string
  site?: string
  builtin?: boolean
}

function groupSkillsBySite(
  skills: SkillListItem[],
  currentHostname: string,
): [string, SkillListItem[]][] {
  const list = Array.isArray(skills) ? skills : []
  const globalSkills = list.filter((s) => !s.site)
  const siteGroups = new Map<string, SkillListItem[]>()
  for (const skill of list.filter((s) => s.site)) {
    const key = skill.site!
    if (!siteGroups.has(key)) siteGroups.set(key, [])
    siteGroups.get(key)!.push(skill)
  }
  const result: [string, SkillListItem[]][] = []
  if (globalSkills.length > 0) {
    result.push(["全局", globalSkills])
  }
  const sortedSites = Array.from(siteGroups.entries()).sort((a, b) => {
    const aMatch = currentHostname && matchesSite(a[0], currentHostname) ? -1 : 0
    const bMatch = currentHostname && matchesSite(b[0], currentHostname) ? -1 : 0
    if (aMatch !== bMatch) return aMatch - bMatch
    return a[0].localeCompare(b[0])
  })
  for (const [site, siteSkills] of sortedSites) {
    result.push([site, siteSkills])
  }
  return result
}

function matchesSite(pattern: string, hostname: string): boolean {
  if (pattern.startsWith("*.")) {
    const suffix = pattern.slice(2)
    return hostname === suffix || hostname.endsWith("." + suffix)
  }
  return hostname === pattern
}

// ── Styles (panel body only) ───────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  panel: {
    borderTop: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    // Apps「添加应用」needs room for search + policy + short list
    maxHeight: 320,
    overflowY: "auto",
    flexShrink: 0,
  },
  panelHeader: {
    position: "sticky",
    top: 0,
    zIndex: 2,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    padding: "6px 12px",
    background: tokens.bgElevated,
    borderBottom: `1px solid ${tokens.border}`,
  },
  panelTitle: {
    fontSize: 15,
    fontWeight: 600,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  panelCloseBtn: {
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusPill,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    fontSize: 11,
    fontWeight: 500,
    padding: "3px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
  },
  panelContent: {
    padding: "10px 12px",
  },
  emptyText: {
    color: tokens.textSecondary,
    fontSize: 12,
    textAlign: "center",
    padding: 12,
  },
  tabRow: {
    display: "flex",
    alignItems: "center",
    padding: "3px 0",
    cursor: "pointer",
    fontSize: 12,
  },
  tabTitle: {
    flex: 1,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  tabUrl: {
    color: tokens.textMuted,
    fontSize: 10,
    fontFamily: tokens.fontMono,
  },
  groupHeader: {
    fontSize: 11,
    fontWeight: 600,
    fontFamily: tokens.fontMono,
    color: tokens.accent,
    marginBottom: 2,
  },
  historyRow: {
    display: "flex",
    alignItems: "center",
    padding: "2px 0",
  },
  skillRow: {
    display: "flex",
    alignItems: "center",
    padding: "6px 0",
    borderBottom: `1px solid ${tokens.bgMuted}`,
  },
  badge: {
    fontSize: 10,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    padding: "1px 6px",
    borderRadius: tokens.radiusSm,
  },
  skillToolbar: {
    display: "flex",
    gap: 6,
    marginBottom: 8,
  },
  skillToolbarBtn: {
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    background: tokens.bgElevated,
    padding: "3px 10px",
    fontSize: 11,
    cursor: "pointer",
  },
  urlImportRow: {
    display: "flex",
    gap: 4,
    marginBottom: 8,
  },
  urlImportInput: {
    flex: 1,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    padding: "4px 8px",
    fontSize: 11,
    fontFamily: tokens.fontMono,
    outline: "none",
  },
  dropZone: {
    minHeight: 24,
  },
  menuBtn: {
    background: "none",
    border: "none",
    fontSize: 14,
    cursor: "pointer",
    padding: "0 4px",
    color: tokens.textMuted,
  },
  menuDropdown: {
    position: "absolute",
    right: 0,
    top: "100%",
    background: tokens.bgElevated,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: tokens.radiusMenu,
    boxShadow: tokens.shadowLg,
    zIndex: 10,
    overflow: "hidden",
    padding: 4,
    minWidth: 120,
  },
  menuItem: {
    display: "block",
    width: "100%",
    border: "none",
    background: "transparent",
    borderRadius: tokens.radiusMd,
    padding: "8px 12px",
    fontSize: 12,
    cursor: "pointer",
    textAlign: "left" as const,
    whiteSpace: "nowrap" as const,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  modeSwitcher: {
    display: "flex",
    gap: 0,
    marginBottom: 8,
    borderRadius: tokens.radiusSm,
    overflow: "hidden",
    border: `1px solid ${tokens.border}`,
  },
  modeBtn: {
    flex: 1,
    border: "none",
    borderRight: `1px solid ${tokens.border}`,
    padding: "4px 0",
    fontSize: 11,
    cursor: "pointer",
    background: tokens.bgElevated,
  },
  siteBadge: {
    fontSize: 9,
    background: tokens.accentSoft,
    color: tokens.accentText,
    padding: "0px 4px",
    borderRadius: tokens.radiusSm,
    fontWeight: 400,
  },
}

FULL FILE chrome-extension/src/sidepanel/components/MeetingPanel.tsx
/**
 * Meeting workbench — Mtg0–Mtg3.
 * SoT: meeting-minutes-design + Mtg3 diarize design.
 * Mtg3: experimental anonymous 发言人N via local feature k-means (NOT identity).
 * Does NOT auto-start mic on pack apply. System audio mix still parking-lot.
 */

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react"
import { useAgentStore } from "../store/agentStore"
import { tokens } from "../ui/tokens"
import { createLocalSttAdapter } from "../voice/local-stt-adapter"
import {
  detectLocalMediaCapture,
  LOCAL_STT_NEAR_REALTIME_SEGMENT_MS,
} from "../voice/local-stt-detect"
import {
  fileToWavSegments,
  transcribeWavViaStt,
} from "../voice/meeting-audio-import"
import {
  loadMeetingTemplate,
  saveMeetingTemplate,
} from "../voice/meeting-template-storage"
import {
  formatMeetingElapsed,
  meetingLiveInterimHint,
  meetingMinutesSendPlan,
  MEETING_DISCONNECT_FINALIZE_MS,
  MEETING_LIVE_HARD_CAP_MS,
  MEETING_LIVE_SOFT_CAP_MS,
  MEETING_MINUTES_WATCHDOG_MS,
  MEETING_NEAR_REALTIME_DEFAULT,
  MEETING_STOP_FAILSAFE_MS,
} from "../voice/meeting-caps"
import { VOICE_DEFAULT_LANG } from "../voice/detect"
import { formatMeetingDiarizeStatus, mapMeetingDiarizeError } from "../voice/meeting-diarize-copy"
import { diarizeViaEmbeddingUpload, wavToRawPcm } from "../voice/meeting-diarize-upload"
import { mapLocalSttError } from "../voice/error-map"
import {
  createSerialRefineQueue,
  formatMeetingSoftSegmentError,
  isMeetingSoftSegmentBanner,
  requestMeetingSegmentRefine,
} from "../voice/meeting-live-refine"
import { VOICE_PRIVACY_ACK_V2_CLAUSES } from "../voice/privacy-copy"
import type { SpeechAdapter } from "../voice/web-speech-adapter"

/** Format companion transcript lines for textarea (Speaker: text). */
function formatLinesFromMeeting(transcript: any[]): string {
  if (!Array.isArray(transcript)) return ""
  return transcript
    .map((l) => {
      const t = typeof l?.text === "string" ? l.text : ""
      const sp = typeof l?.speaker === "string" ? l.speaker.trim() : ""
      return sp ? `${sp}: ${t}` : t
    })
    .filter(Boolean)
    .join("\n\n")
}

type CapturePhase = "idle" | "starting" | "recording" | "processing" | "stopping"

function useMeetingMessages(onMsg: (m: any) => void) {
  useEffect(() => {
    const listener = (msg: any) => {
      if (msg && typeof msg.type === "string" && msg.type.startsWith("meeting.")) {
        onMsg(msg)
      }
      return false
    }
    chrome.runtime.onMessage.addListener(listener)
    return () => chrome.runtime.onMessage.removeListener(listener)
  }, [onMsg])
}

function sendViaRuntime(msg: Record<string, unknown>): void {
  try {
    chrome.runtime.sendMessage(msg)
  } catch {
    /* SW missing */
  }
}

function subscribeVoiceStt(handler: (msg: any) => void): () => void {
  if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
    return () => {}
  }
  const listener = (msg: any) => {
    if (msg && typeof msg.type === "string" && msg.type.startsWith("voice.stt.")) {
      handler(msg)
    }
    return false
  }
  chrome.runtime.onMessage.addListener(listener)
  return () => {
    try {
      chrome.runtime.onMessage.removeListener(listener)
    } catch {
      /* */
    }
  }
}

/** #260: imperative one-shot subscribe for meeting.* (upload client state machine). */
function subscribeMeetingRuntime(handler: (msg: any) => void): () => void {
  if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
    return () => {}
  }
  const listener = (msg: any) => {
    if (msg && typeof msg.type === "string" && msg.type.startsWith("meeting.")) {
      handler(msg)
    }
    return false
  }
  chrome.runtime.onMessage.addListener(listener)
  return () => {
    try {
      chrome.runtime.onMessage.removeListener(listener)
    } catch {
      /* */
    }
  }
}

const formatElapsed = formatMeetingElapsed

export function MeetingPanel(props: {
  onClose: () => void
  onSendToDraft: (text: string) => void
}) {
  const { state, dispatch } = useAgentStore()
  const [title, setTitle] = useState("")
  const [transcript, setTranscript] = useState("")
  const [minutesMd, setMinutesMd] = useState("")
  const [meetingId, setMeetingId] = useState<string | null>(null)
  const [status, setStatus] = useState<string>("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [ack, setAck] = useState(false)
  const [capturePhase, setCapturePhase] = useState<CapturePhase>("idle")
  const [elapsedMs, setElapsedMs] = useState(0)
  const [softCapHint, setSoftCapHint] = useState(false)
  /** P1: progressive hypothesis text (not yet committed to transcript). */
  const [interimText, setInterimText] = useState("")
  const [pendingGenerate, setPendingGenerate] = useState(false)
  /** Mtg2: optional default speaker for STT append / bulk label (manual only). */
  const [defaultSpeaker, setDefaultSpeaker] = useState("")
  const [importStatus, setImportStatus] = useState<string | null>(null)
  const textFileRef = useRef<HTMLInputElement | null>(null)
  const audioFileRef = useRef<HTMLInputElement | null>(null)
  const defaultSpeakerRef = useRef("")
  const importAbortRef = useRef(false)
  /** Skip server→textarea sync while user is typing (dual-review dirty-guard). */
  const transcriptDirtyRef = useRef(false)
  /** #260: per-line raw s16le PCM from last audio import (aligned with append order). */
  const linePcmRef = useRef<Uint8Array[]>([])
  const [diarizeK, setDiarizeK] = useState(0)
  const [autoDiarizeAfterImport, setAutoDiarizeAfterImport] = useState(false)
  /** Optional markdown template for minutes structure (chrome.storage). */
  const [templateMd, setTemplateMd] = useState("")
  const templateMdRef = useRef("")
  /** After stop: re-run silence-cut / soft paragraph split on full transcript. */
  const [autoSegmentOnStop, setAutoSegmentOnStop] = useState(true)
  const autoSegmentOnStopRef = useRef(true)
  /** Live segment AI refine in flight (opt-in via asrRefinerEnabled). */
  const [refinePending, setRefinePending] = useState(0)

  const adapterRef = useRef<SpeechAdapter | null>(null)
  const captureStartRef = useRef<number | null>(null)
  const meetingIdRef = useRef<string | null>(null)
  const phaseRef = useRef<CapturePhase>("idle")
  const wantGenerateRef = useRef(false)
  const transcriptRef = useRef("")
  /** Prevent double meeting.end / finalize. */
  const finalizedRef = useRef(false)
  const titleRef = useRef(title)
  const refineGenRef = useRef(0)
  const refineQueueRef = useRef(createSerialRefineQueue())
  const asrRefinerEnabledRef = useRef(false)
  const companionConnectedRef = useRef(false)
  /** Companion died after 「结束并生成纪要」: retry when WS is back. */
  const retryGenerateOnReconnectRef = useRef(false)

  meetingIdRef.current = meetingId
  transcriptRef.current = transcript
  titleRef.current = title
  phaseRef.current = capturePhase
  defaultSpeakerRef.current = defaultSpeaker
  templateMdRef.current = templateMd
  autoSegmentOnStopRef.current = autoSegmentOnStop
  asrRefinerEnabledRef.current = state.asrRefinerEnabled === true

  const companionConnected = state.connectionState === "connected"
  companionConnectedRef.current = companionConnected
  const activeModelId = state.voiceModel?.localModelId || "medium"
  const localModelReady = state.voiceModel?.models?.[activeModelId]?.status === "ready"
  const localBinaryReady = state.voiceModel?.binary?.status === "ready"
  /** #260: speaker-embedding diarize model (未就绪必须显式引导下载，不静默落回). */
  const diarizeModelReady = state.voiceModel?.diarizeModel?.status === "ready"
  /** P1: near-rt defaults on; honor global voiceRealtimeStreaming toggle. */
  const nearRealtime =
    MEETING_NEAR_REALTIME_DEFAULT &&
    state.voiceRealtimeStreaming !== false &&
    activeModelId !== "large-v3-turbo"
  const localMedia = detectLocalMediaCapture(
    typeof globalThis !== "undefined" ? (globalThis as any) : {},
  )
  const capturing =
    capturePhase === "recording" ||
    capturePhase === "processing" ||
    capturePhase === "starting" ||
    capturePhase === "stopping"

  const setPhase = useCallback((p: CapturePhase) => {
    phaseRef.current = p
    setCapturePhase(p)
  }, [])

  useEffect(() => {
    try {
      chrome.storage.local.get("meeting_privacy_ack_v1", (r) => {
        if (r.meeting_privacy_ack_v1 === true) setAck(true)
      })
    } catch {
      /* */
    }
  }, [])

  const templateLoadedRef = useRef(false)
  useEffect(() => {
    let cancelled = false
    void loadMeetingTemplate().then((t) => {
      if (cancelled) return
      setTemplateMd(t)
      templateMdRef.current = t
      templateLoadedRef.current = true
    })
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    if (!templateLoadedRef.current) return
    const t = setTimeout(() => {
      saveMeetingTemplate(templateMd)
    }, 300)
    return () => clearTimeout(t)
  }, [templateMd])

  useEffect(() => {
    if (!companionConnected) return
    try {
      chrome.runtime.sendMessage({ type: "voice.model.get_state" })
    } catch {
      /* */
    }
  }, [companionConnected])

  useEffect(() => {
    if (!capturing) return
    const id = setInterval(() => {
      if (captureStartRef.current != null) {
        const ms = Date.now() - captureStartRef.current
        setElapsedMs(ms)
        if (ms >= MEETING_LIVE_SOFT_CAP_MS) setSoftCapHint(true)
      }
    }, 250)
    return () => clearInterval(id)
  }, [capturing])

  useEffect(() => {
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: capturing })
    return () => {
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    }
  }, [capturing, dispatch])

  /** Tear down adapter without onEnd (destroy is silent; abort would re-enter finalize). */
  const destroyAdapter = useCallback(() => {
    const a = adapterRef.current
    adapterRef.current = null
    if (!a) return
    try {
      a.destroy()
    } catch {
      /* */
    }
  }, [])

  const appendLocalAndRemote = useCallback(
    (
      chunk: string,
      id: string | null,
      source: "stt" | "asr_refiner" = "stt",
    ) => {
      const t = chunk.trim()
      if (!t) return
      const sp = defaultSpeakerRef.current.trim().slice(0, 32)
      const display = sp ? `${sp}: ${t}` : t
      setTranscript((prev) => {
        // Live STT: blank-line between segments = smart paragraph boundary
        const next = prev ? `${prev}\n\n${display}` : display
        transcriptRef.current = next
        return next
      })
      if (id) {
        sendViaRuntime({
          type: "meeting.append_transcript",
          v: 1,
          id,
          text: t,
          source,
          speaker: sp || undefined,
        })
      }
    },
    [],
  )

  /**
   * Commit a live STT final: optional ADR-024 refine with prior transcript context,
   * then append (paragraph-separated). Serial queue preserves order.
   * Pin meeting id at enqueue so late refine never appends to a newer meeting (Pi nit).
   */
  const commitLiveSegment = useCallback(
    (finalChunk: string, meetingIdForAppend: string) => {
      const raw = finalChunk.trim()
      if (!raw) return
      const pinnedId = meetingIdForAppend
      const wantRefine = asrRefinerEnabledRef.current
      if (!wantRefine) {
        appendLocalAndRemote(raw, pinnedId, "stt")
        return
      }
      refineGenRef.current += 1
      const gen = refineGenRef.current
      const sid = `mtg-refine-${pinnedId}-${gen}`
      const prior = transcriptRef.current
      setRefinePending((n) => n + 1)
      void refineQueueRef.current
        .enqueue(async () => {
          const { text, refined } = await requestMeetingSegmentRefine({
            sessionId: sid,
            refineGen: gen,
            text: raw,
            priorTranscript: prior,
          })
          // Always pin to the meeting that owned this segment (not meetingIdRef after await)
          appendLocalAndRemote(
            text || raw,
            pinnedId,
            refined ? "asr_refiner" : "stt",
          )
        })
        .finally(() => {
          setRefinePending((n) => Math.max(0, n - 1))
        })
    },
    [appendLocalAndRemote],
  )

  /**
   * Fire minutes job or defer until Companion is back.
   * Product adversary B1: dropped WS send used to leave 「生成中…」 forever.
   */
  const sendMinutesJob = useCallback((id: string | null) => {
    if (meetingMinutesSendPlan(companionConnectedRef.current) === "defer-reconnect") {
      retryGenerateOnReconnectRef.current = true
      setBusy(false)
      setPendingGenerate(false)
      setError(
        (prev) =>
          prev ||
          "Companion 未连接；转写已保留，重连后将自动生成纪要（也可手动点「生成会议纪要」）",
      )
      return
    }
    retryGenerateOnReconnectRef.current = false
    setBusy(true)
    setPendingGenerate(true)
    sendViaRuntime({
      type: "meeting.generate_minutes",
      v: 1,
      id: id || undefined,
      text: transcriptRef.current.trim() || undefined,
      template_md: templateMdRef.current.trim() || undefined,
    })
  }, [])

  /**
   * End server session + tear down adapter. Idempotent via finalizedRef.
   * Drains in-flight AI refine before end / silence-cut / minutes (dual-review nit #2).
   */
  const finalizeCapture = useCallback(
    (opts: { generate: boolean; id: string | null }) => {
      if (finalizedRef.current) return
      finalizedRef.current = true
      captureStartRef.current = null
      setPhase("idle")
      setSoftCapHint(false)
      destroyAdapter()
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })

      const id = opts.id || meetingIdRef.current
      const wantGenerate = opts.generate
      const wantSegment = autoSegmentOnStopRef.current

      void (async () => {
        // Wait for segment refine queue (cap ~22s) so minutes see refined text
        try {
          const drained = await refineQueueRef.current.drain()
          if (!drained && wantGenerate) {
            setError((prev) =>
              prev ||
              "部分 AI 纠错未在时限内完成；纪要将基于当前转写（可稍后重新生成）",
            )
          }
        } catch {
          /* best-effort */
        }

        if (id) {
          sendViaRuntime({ type: "meeting.end", v: 1, id })
        }
        // Smart segment after refine drain so silence-cut sees full refined blob
        if (wantSegment && id && transcriptRef.current.trim()) {
          sendViaRuntime({
            type: "meeting.apply_silence_cut",
            v: 1,
            id,
            text: transcriptRef.current,
          })
        }
        if (wantGenerate) {
          // Brief beat for silence-cut server apply before minutes job
          await new Promise((r) => setTimeout(r, 150))
          sendMinutesJob(id)
        }
      })()
    },
    [destroyAdapter, dispatch, sendMinutesJob, setPhase],
  )

  // Companion restart mid-window used to leave phase=stopping forever
  // (adapter awaited a voice.stt.end ACK that never arrived). Force-finalize.
  useEffect(() => {
    if (capturePhase !== "stopping") return
    const t = setTimeout(() => {
      if (phaseRef.current !== "stopping" || finalizedRef.current) return
      setError((prev) => prev || "结束超时：已停止录制。可基于已有转写生成纪要")
      const gen = wantGenerateRef.current
      wantGenerateRef.current = false
      finalizeCapture({ generate: gen, id: meetingIdRef.current })
    }, MEETING_STOP_FAILSAFE_MS)
    return () => clearTimeout(t)
  }, [capturePhase, finalizeCapture])

  // Debounced disconnect: WS auth blips (~1s) must not kill capture; a real
  // Companion death (SIGTERM ~18s this incident) must not leave 「正在听」.
  useEffect(() => {
    if (companionConnected) return
    if (phaseRef.current === "idle") return
    const t = setTimeout(() => {
      if (finalizedRef.current) return
      if (phaseRef.current === "idle") return
      setError((prev) => prev || "Companion 断开，已停止录制。可基于已有转写生成纪要")
      const gen = wantGenerateRef.current
      wantGenerateRef.current = false
      finalizeCapture({ generate: gen, id: meetingIdRef.current })
    }, MEETING_DISCONNECT_FINALIZE_MS)
    return () => clearTimeout(t)
  }, [companionConnected, finalizeCapture])

  useEffect(() => {
    if (!companionConnected) return
    if (!retryGenerateOnReconnectRef.current) return
    if (phaseRef.current !== "idle") return
    retryGenerateOnReconnectRef.current = false
    sendMinutesJob(meetingIdRef.current)
  }, [companionConnected, sendMinutesJob])

  useEffect(() => {
    if (!pendingGenerate) return
    const t = setTimeout(() => {
      setPendingGenerate(false)
      setBusy(false)
      retryGenerateOnReconnectRef.current = false
      setError((prev) => prev || "纪要生成超时。转写已保留，可再点「生成会议纪要」")
    }, MEETING_MINUTES_WATCHDOG_MS)
    return () => clearTimeout(t)
  }, [pendingGenerate])

  const startLocalSegments = useCallback(
    (id: string) => {
      destroyAdapter()
      finalizedRef.current = false

      if (!localMedia.ok) {
        setError("当前环境无法访问麦克风（getUserMedia）")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }
      if (!state.voicePrivacyAckV2) {
        setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }
      if (!localModelReady || !localBinaryReady) {
        setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型后再开始会议录音。")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }

      const adapter = createLocalSttAdapter(
        {
          onStart: () => {
            captureStartRef.current = Date.now()
            setPhase("recording")
            setElapsedMs(0)
            setError(null)
            setInterimText("")
          },
          onResult: ({ interim, finalChunk }) => {
            if (finalChunk?.trim()) {
              setInterimText("")
              commitLiveSegment(finalChunk, meetingIdRef.current || id)
              return
            }
            // Progressive hypothesis only (M2); do not append until window final.
            // Empty interim is a soft/empty window — keep last visible text.
            if (typeof interim === "string" && interim.trim()) {
              setInterimText(interim)
            }
          },
          onError: (code) => {
            if (code === "aborted") return
            const mapped = mapLocalSttError(code)
            if (mapped.severity === "silent") return
            // Soft = adapter continues; honest copy (segment+audio irreversibly lost).
            const soft = isMeetingSoftSegmentBanner(code)
            const msg = mapped.message || `转写错误: ${code}`
            setError(soft ? formatMeetingSoftSegmentError(msg) : msg)
          },
          onEnd: () => {
            setInterimText("")
            const gen = wantGenerateRef.current
            wantGenerateRef.current = false
            if (phaseRef.current === "idle" && finalizedRef.current) return
            finalizeCapture({ generate: gen, id: meetingIdRef.current || id })
          },
          onSegmentContinue: () => {
            if (phaseRef.current !== "stopping") setPhase("recording")
          },
          onCaptureStopped: () => {
            if (phaseRef.current !== "stopping") setPhase("processing")
          },
        },
        {
          send: sendViaRuntime,
          onMessage: subscribeVoiceStt,
          modelId: activeModelId,
        },
      )
      adapterRef.current = adapter
      const sid = `mtg-${id}-${Date.now().toString(36)}`
      // STT slot is force-aborted on companion by meeting.start — do not send
      // voice.stt.abort with a fake sessionId (e.g. "mtg-preempt") from the client.
      // P1 near-rt: streamPartial + ~8s windows; P2 hard cap independent of dictation 15/30m.
      adapter.start({
        lang: VOICE_DEFAULT_LANG,
        sessionId: sid,
        modelId: activeModelId,
        mode: "continuous",
        hardCapMs: MEETING_LIVE_HARD_CAP_MS,
        segmentMs: nearRealtime ? LOCAL_STT_NEAR_REALTIME_SEGMENT_MS : undefined,
        streamPartial: nearRealtime,
      })
    },
    [
      activeModelId,
      commitLiveSegment,
      destroyAdapter,
      finalizeCapture,
      localBinaryReady,
      localMedia.ok,
      localModelReady,
      nearRealtime,
      setPhase,
      state.voicePrivacyAckV2,
    ],
  )

  const startLocalSegmentsRef = useRef(startLocalSegments)
  startLocalSegmentsRef.current = startLocalSegments

  // Unmount / ContextPanelHost 收起: always end server session if still capturing
  // (destroy() is silent and would otherwise leave status=recording — dual-review nit).
  useEffect(() => {
    return () => {
      const id = meetingIdRef.current
      const stillLive = phaseRef.current !== "idle" && !finalizedRef.current
      if (stillLive && id) {
        finalizedRef.current = true
        sendViaRuntime({ type: "meeting.end", v: 1, id })
      }
      destroyAdapter()
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    }
  }, [destroyAdapter, dispatch])

  const onMsg = useCallback(
    (msg: any) => {
      if (msg.type === "meeting.created" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || "")
        setStatus(msg.meeting.status || "draft")
        setBusy(false)
      }
      if (msg.type === "meeting.started" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || titleRef.current)
        setStatus(msg.meeting.status || "recording")
        if (phaseRef.current === "starting") {
          startLocalSegmentsRef.current(msg.meeting.id)
        }
      }
      if (msg.type === "meeting.ended" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        let st = msg.meeting.status || "ready"
        if (msg.audio_deleted === true) st = `${st} · 音频已按默认策略删除`
        setStatus(st)
      }
      if (msg.type === "meeting.updated" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setStatus(msg.meeting.status)
        // Only push server transcript when explicit cut/import ops or textarea not dirty.
        // During live capture, local appends own the textarea — a stale
        // meeting.updated (append N-1 arriving after local N) used to flicker
        // or drop the newest line.
        const live =
          phaseRef.current === "recording" ||
          phaseRef.current === "processing" ||
          phaseRef.current === "starting" ||
          phaseRef.current === "stopping"
        const forceSync = msg.cut === true
        if (
          Array.isArray(msg.meeting.transcript) &&
          msg.meeting.transcript.length > 0 &&
          (forceSync || (!transcriptDirtyRef.current && !live))
        ) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          if (formatted) {
            setTranscript(formatted)
            transcriptRef.current = formatted
            if (forceSync) transcriptDirtyRef.current = false
          }
        }
        if (msg.meeting.minutes?.raw_md) setMinutesMd(msg.meeting.minutes.raw_md)
        setBusy(false)
      }
      if (msg.type === "meeting.imported" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || titleRef.current)
        setStatus(msg.meeting.status || "ready")
        if (Array.isArray(msg.meeting.transcript)) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          setTranscript(formatted)
          transcriptRef.current = formatted
          transcriptDirtyRef.current = false
        }
        linePcmRef.current = []
        setBusy(false)
        setImportStatus("已导入转写文件")
      }
      if (msg.type === "meeting.diarized" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setStatus(msg.meeting.status || "ready")
        if (Array.isArray(msg.meeting.transcript)) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          setTranscript(formatted)
          transcriptRef.current = formatted
          transcriptDirtyRef.current = false
        }
        setBusy(false)
        const method = msg.diarize?.method || msg.meeting.diarize?.method
        const kRaw = msg.diarize?.k ?? msg.meeting.diarize?.k
        const k = typeof kRaw === "number" && Number.isFinite(kRaw) ? Math.floor(kRaw) : null
        setImportStatus(formatMeetingDiarizeStatus(method, k))
        if (k != null && k >= 2 && k <= 6) setDiarizeK(k)
      }
      if (msg.type === "meeting.minutes_result") {
        if (msg.minutes?.raw_md) setMinutesMd(msg.minutes.raw_md)
        if (msg.meeting?.id) {
          setMeetingId(msg.meeting.id)
          setStatus(msg.meeting.status || "done")
        }
        setBusy(false)
        setPendingGenerate(false)
        setError(null)
      }
      if (msg.type === "meeting.error") {
        setError(msg.message || msg.code || "error")
        setBusy(false)
        setPendingGenerate(false)
        if (
          msg.code === "need_privacy_ack" ||
          msg.code === "already_recording" ||
          phaseRef.current === "starting"
        ) {
          setPhase("idle")
          destroyAdapter()
          dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
        }
      }
    },
    [destroyAdapter, dispatch, setPhase],
  )

  useMeetingMessages(onMsg)

  const ensureAck = () => {
    if (ack) return true
    setError("请先确认会议隐私说明（生成纪要会将转写文本发给已配置的 LLM）")
    return false
  }

  const acceptAck = () => {
    setAck(true)
    try {
      chrome.storage.local.set({ meeting_privacy_ack_v1: true })
    } catch {
      /* */
    }
    setError(null)
  }

  const createMeeting = () => {
    setBusy(true)
    setError(null)
    sendViaRuntime({
      type: "meeting.create",
      v: 1,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
    })
  }

  const startLiveCapture = () => {
    if (!ensureAck()) return
    if (!companionConnected) {
      setError("Companion 未连接")
      return
    }
    if (state.dictationCaptureActive) {
      setError("听写进行中，请先结束听写再开始会议录音（全局同时仅一路本机 STT）")
      return
    }
    if (capturing) return
    if (!localMedia.ok) {
      setError("当前环境无法访问麦克风")
      return
    }
    if (!state.voicePrivacyAckV2) {
      setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
      return
    }
    if (!localModelReady || !localBinaryReady) {
      setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型。")
      try {
        chrome.runtime.sendMessage({ type: "voice.model.get_state" })
      } catch {
        /* */
      }
      return
    }

    setError(null)
    setMinutesMd("")
    setPhase("starting")
    setSoftCapHint(false)
    wantGenerateRef.current = false
    finalizedRef.current = false

    sendViaRuntime({
      type: "meeting.start",
      v: 1,
      id: meetingId || undefined,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
      privacy_ack_v1: true,
      audio_retained: false,
    })
  }

  const stopLiveCapture = (andGenerate: boolean) => {
    if (phaseRef.current === "idle" || phaseRef.current === "stopping") return
    setPhase("stopping")
    wantGenerateRef.current = andGenerate
    const a = adapterRef.current
    if (!a) {
      finalizeCapture({ generate: andGenerate, id: meetingId })
      return
    }
    try {
      a.stop()
    } catch {
      finalizeCapture({ generate: andGenerate, id: meetingId })
    }
  }

  const ensureMeetingIdThen = (then: (id: string) => void) => {
    if (meetingId) {
      then(meetingId)
      return
    }
    // Create then wait for meeting.created — fire create and use one-shot listener
    const listener = (msg: any) => {
      if (msg?.type === "meeting.created" && msg.meeting?.id) {
        chrome.runtime.onMessage.removeListener(listener)
        setMeetingId(msg.meeting.id)
        then(msg.meeting.id)
      }
      return false
    }
    chrome.runtime.onMessage.addListener(listener)
    sendViaRuntime({
      type: "meeting.create",
      v: 1,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
    })
    // Fallback timeout remove
    setTimeout(() => {
      try {
        chrome.runtime.onMessage.removeListener(listener)
      } catch {
        /* */
      }
    }, 8000)
  }

  const applySilenceCut = () => {
    if (!ensureAck()) return
    if (!meetingId && !transcript.trim()) {
      setError("没有可分段的转写")
      return
    }
    setBusy(true)
    setError(null)
    ensureMeetingIdThen((id) => {
      // Single WS: server applies text then silence-cut (no client setTimeout race)
      sendViaRuntime({
        type: "meeting.apply_silence_cut",
        v: 1,
        id,
        text: transcriptRef.current.trim() || undefined,
      })
      setImportStatus("已应用智能分段（静音/段落切分；说话人仍可手动标）")
    })
  }

  const bulkLabelSpeaker = () => {
    if (!ensureAck()) return
    const sp = defaultSpeaker.trim().slice(0, 32)
    if (!sp) {
      setError("请先填写默认说话人标签（如「我」）")
      return
    }
    if (!meetingId && !transcript.trim()) {
      setError("没有可标注的转写")
      return
    }
    setBusy(true)
    ensureMeetingIdThen((id) => {
      sendViaRuntime({
        type: "meeting.bulk_speaker",
        v: 1,
        id,
        speaker: sp,
        text: transcriptRef.current.trim() || undefined,
      })
      setImportStatus(`已将全部行标为「${sp}」（手动，非自动分离）`)
    })
  }

  const onImportTextFile = async (file: File | null) => {
    if (!file) return
    if (!ensureAck()) return
    setError(null)
    setBusy(true)
    setImportStatus(`读取 ${file.name}…`)
    try {
      const text = await file.text()
      if (!text.trim()) {
        setError("文件为空")
        setBusy(false)
        setImportStatus(null)
        return
      }
      const truncated = text.length > 80_000
      sendViaRuntime({
        type: "meeting.import_text",
        v: 1,
        id: meetingId || undefined,
        title: title || file.name.replace(/\.[^.]+$/, ""),
        thread_id: state.activeThreadId || undefined,
        privacy_ack_v1: true,
        text: text.slice(0, 80_000),
      })
      if (truncated) {
        setImportStatus("已截断至 80000 字后导入（文件过长）")
      }
    } catch {
      setError("读取文本文件失败")
      setBusy(false)
      setImportStatus(null)
    }
  }

  const onImportAudioFile = async (file: File | null) => {
    if (!file) return
    if (!ensureAck()) return
    if (!companionConnected) {
      setError("Companion 未连接")
      return
    }
    if (state.dictationCaptureActive || capturing) {
      setError("听写或会议录音进行中，请先结束后再导入音频")
      return
    }
    if (!state.voicePrivacyAckV2) {
      setError("导入音频需先确认「本机语音隐私说明」（见下方卡片，或设置 → 输入与语音 → 启用本机转写）")
      return
    }
    if (!localModelReady || !localBinaryReady) {
      setError("本机转写模型或二进制未就绪")
      return
    }

    setError(null)
    setBusy(true)
    importAbortRef.current = false
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: true })
    setImportStatus("解码音频…")

    const decoded = await fileToWavSegments(file)
    if (decoded.ok === false) {
      setError(decoded.message)
      setBusy(false)
      setImportStatus(null)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      return
    }

    // Ensure meeting exists
    let id = meetingId
    if (!id) {
      id = await new Promise<string | null>((resolve) => {
        const listener = (msg: any) => {
          if (msg?.type === "meeting.created" && msg.meeting?.id) {
            chrome.runtime.onMessage.removeListener(listener)
            resolve(msg.meeting.id as string)
          }
          return false
        }
        chrome.runtime.onMessage.addListener(listener)
        sendViaRuntime({
          type: "meeting.create",
          v: 1,
          title: title || file.name.replace(/\.[^.]+$/, ""),
          thread_id: state.activeThreadId || undefined,
        })
        setTimeout(() => {
          try {
            chrome.runtime.onMessage.removeListener(listener)
          } catch {
            /* */
          }
          resolve(null)
        }, 8000)
      })
      if (id) setMeetingId(id)
    }
    if (!id) {
      setError("无法创建会议会话")
      setBusy(false)
      setImportStatus(null)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      return
    }

    const total = decoded.segments.length
    let failedAt: number | null = null
    let done = 0
    const pcms: Uint8Array[] = []
    const texts: string[] = []
    setImportStatus(`本机转写 0/${total} 段…`)
    for (let i = 0; i < total; i++) {
      if (importAbortRef.current) break
      const seg = decoded.segments[i]!
      setImportStatus(`本机转写 ${i + 1}/${total} 段…`)
      const sid = `mtg-imp-${id}-${i}-${Date.now().toString(36)}`
      const r = await transcribeWavViaStt({
        wav: seg.wav,
        sessionId: sid,
        modelId: activeModelId,
        send: sendViaRuntime,
        onMessage: subscribeVoiceStt,
      })
      if (r.ok === false) {
        failedAt = i + 1
        setError(`音频第 ${i + 1} 段转写失败: ${r.code}`)
        break
      }
      if (r.text.trim()) {
        // One physical line per segment so PCM stays aligned (dual-review nit)
        const oneLine = r.text.trim().replace(/\s*\n+\s*/g, " ")
        texts.push(oneLine)
        pcms.push(wavToRawPcm(seg.wav))
        // local preview (speaker optional)
        appendLocalAndRemote(oneLine, null)
      }
      done = i + 1
    }
    linePcmRef.current = pcms

    // Single set_transcript so line count == features (avoid append race before diarize)
    if (texts.length > 0 && id) {
      const sp = defaultSpeakerRef.current.trim().slice(0, 32)
      const body = texts.join("\n")
      sendViaRuntime({
        type: "meeting.set_transcript",
        v: 1,
        id,
        text: body,
        source: "stt",
        silence_cut: false,
      })
      // Restore default-speaker when not auto-diarizing (Mtg2 contract)
      if (sp && !autoDiarizeAfterImport) {
        setTimeout(() => {
          sendViaRuntime({
            type: "meeting.bulk_speaker",
            v: 1,
            id,
            speaker: sp,
          })
        }, 100)
      }
    }

    setBusy(false)
    if (importAbortRef.current) {
      setImportStatus(`导入已中止（已完成 ${done}/${total} 段）`)
    } else if (failedAt != null) {
      setImportStatus(`导入部分失败（成功 ${done}/${total} 段，失败于第 ${failedAt} 段）`)
    } else {
      setImportStatus(`音频导入完成 ${done}/${total} 段`)
      if (autoDiarizeAfterImport && pcms.length >= 2 && id) {
        // embedding 引擎；模型未就绪 → 显式引导下载（#260 硬约束，不静默落回）
        if (!diarizeModelReady) {
          setError(mapMeetingDiarizeError("embedding_model_required"))
        } else {
          setBusy(true)
          await runUploadDiarize(id, pcms, "embedding")
        }
      }
    }
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
  }

  /**
   * #260 PCM 上传自动标说话人：embedding = companion ONNX 说话人嵌入聚类；
   * audio_cluster = 旧版 3 维声学特征显式回退（区分度低 · 无需模型）。
   * 成功态由 meeting.diarized 运行时处理器收尾（busy/importStatus）。
   */
  const runUploadDiarize = async (
    id: string,
    pcmSegments: Uint8Array[],
    mode: "embedding" | "audio_cluster",
  ): Promise<boolean> => {
    if (mode === "embedding" && !diarizeModelReady) {
      setError(mapMeetingDiarizeError("embedding_model_required"))
      setBusy(false)
      return false
    }
    setBusy(true)
    setError(null)
    const label = mode === "embedding" ? "说话人嵌入" : "旧版 3 维特征"
    setImportStatus(`${label} 0/${pcmSegments.length} 段…`)
    const r = await diarizeViaEmbeddingUpload({
      meetingId: id,
      pcmSegments,
      k: diarizeK,
      mode,
      send: sendViaRuntime,
      onMessage: subscribeMeetingRuntime,
      onProgress: (p) => setImportStatus(`${label} ${p.done}/${p.total} 段…`),
    })
    if (r.ok === false) {
      setError(mapMeetingDiarizeError(r.code, r.message))
      setBusy(false)
      setImportStatus(null)
      return false
    }
    return true
  }

  const runAutoDiarize = (mode: "embedding" | "audio_cluster" | "text_gap") => {
    if (!ensureAck()) return
    if (!meetingId && !transcript.trim()) {
      setError("请先创建会议或导入/录制转写")
      return
    }
    if (!transcript.trim()) {
      setError("转写为空，无法标说话人")
      return
    }
    if (mode === "embedding" || mode === "audio_cluster") {
      const pcms = linePcmRef.current
      if (!pcms.length) {
        setError("暂无音频段：请先「上传音频转写」以启用说话人分离（纯粘贴请用弱标）")
        return
      }
      // embedding 需模型；旧版 3 维是用户显式选择，不是模型缺失的静默落回
      if (mode === "embedding" && !diarizeModelReady) {
        setError(mapMeetingDiarizeError("embedding_model_required"))
        return
      }
      setBusy(true)
      setError(null)
      ensureMeetingIdThen((id) => {
        void runUploadDiarize(id, pcms, mode)
      })
      return
    }
    setBusy(true)
    setError(null)
    ensureMeetingIdThen((id) => {
      sendViaRuntime({
        type: "meeting.auto_diarize",
        v: 1,
        id,
        privacy_ack_v1: true,
        mode: "text_gap",
        k: diarizeK,
        text: transcriptRef.current.trim() || undefined,
      })
    })
  }

  const generate = () => {
    if (!ensureAck()) return
    if (capturing) {
      setError("请先结束录音再生成纪要，或使用「结束并生成纪要」")
      return
    }
    if (!transcript.trim() && !meetingId) {
      setError("请先粘贴转写文本或完成录音")
      return
    }
    setBusy(true)
    setError(null)
    if (meetingId && transcript.trim()) {
      sendViaRuntime({
        type: "meeting.set_transcript",
        v: 1,
        id: meetingId,
        text: transcript,
        source: "user_edit",
        silence_cut: true,
      })
    }
    sendMinutesJob(meetingId)
  }

  const copyMinutes = async () => {
    if (!minutesMd) return
    try {
      await navigator.clipboard.writeText(minutesMd)
      setStatus("已复制纪要")
    } catch {
      setError("复制失败")
    }
  }

  const localReadyLabel = !companionConnected
    ? "Companion 未连接"
    : !localModelReady || !localBinaryReady
      ? "本机 STT 未就绪"
      : "本机 STT 就绪"

  return (
    <div
      data-testid="meeting-panel"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 10,
        padding: 12,
        height: "100%",
        overflow: "auto",
        background: tokens.bgElevated,
        color: tokens.text,
        fontSize: 13,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <strong style={{ flex: 1, fontSize: 15 }}>会议记录</strong>
        <span style={{ fontSize: 11, color: tokens.textSecondary }}>
          实验可标发言人N · 非身份识别
        </span>
        <button
          type="button"
          onClick={() => {
            // Sync end before unmount so meeting.end is not raced by destroy()
            if (phaseRef.current !== "idle") {
              wantGenerateRef.current = false
              finalizeCapture({ generate: false, id: meetingIdRef.current })
            }
            props.onClose()
          }}
          title="结束录制并收起面板"
          aria-label="结束录制并收起面板"
          style={{
            border: `1px solid ${tokens.border}`,
            background: "transparent",
            borderRadius: 6,
            padding: "2px 8px",
            cursor: "pointer",
            color: tokens.textSecondary,
            fontSize: 12,
          }}
        >
          结束并收起
        </button>
      </div>

      <div style={{ fontSize: 11, color: tokens.textSecondary, lineHeight: 1.45 }}>
        粘贴 / 上传转写，或显式「开始录制」本机分段转写（最长约{" "}
        {Math.round(MEETING_LIVE_HARD_CAP_MS / 60_000)} 分钟；约 2 小时软提示）。
        {nearRealtime
          ? " 默认近实时出字（渐进假设，约 8 秒定稿；large 模型仅终稿）。"
          : " 当前为分段终稿模式（可在设置开启实时出字）。"}
        应用场景不会自动开麦。录音与听写互斥。说话人：手动标或实验性自动「发言人N」（非真名识别）；系统混音未支持。
        段与段之间自动空行分段；可开「录制 AI 纠错」用上文消歧同音字（需已配置 LLM）。
      </div>

      {/* Path B: meeting live STT / audio import requires voice_privacy_ack_v2.
          Previously only reachable via Settings → 启用本机转写 (easy to miss). */}
      {!state.voicePrivacyAckV2 && (
        <div
          data-testid="meeting-voice-privacy-v2"
          style={{
            border: `1px solid ${tokens.border}`,
            borderRadius: 8,
            padding: 10,
            fontSize: 11,
            lineHeight: 1.45,
            color: tokens.textSecondary,
          }}
        >
          <div style={{ marginBottom: 6, color: tokens.text, fontWeight: 500 }}>
            本机语音隐私说明
          </div>
          <p style={{ margin: "0 0 6px", fontSize: 10 }}>
            会议本机录音 / 上传音频转写前须确认。也可在：侧栏 ⋯ → 设置 → 输入与语音 →
            「启用本机转写」。
          </p>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {VOICE_PRIVACY_ACK_V2_CLAUSES.map((c) => (
              <li key={c.slice(0, 24)}>{c}</li>
            ))}
          </ul>
          <button
            type="button"
            data-testid="meeting-voice-privacy-v2-accept"
            onClick={() => {
              dispatch({ type: "SET_VOICE_PRIVACY_ACK_V2", ack: true })
              setError(null)
              // Companion refuses voice.stt.* unless sttEngine=local — flip if model ready.
              if (localModelReady && localBinaryReady) {
                // Companion validate requires source:"settings" for set_engine (settings dual fence).
                sendViaRuntime({
                  type: "voice.model.set_engine",
                  engine: "local",
                  privacy_ack_v2: true,
                  source: "settings",
                })
              }
            }}
            style={{ ...btnStyle(true), marginTop: 8, padding: "4px 10px", fontSize: 12 }}
          >
            同意本机语音隐私说明
            {localModelReady && localBinaryReady ? "并启用本机转写" : ""}
          </button>
          {!localModelReady || !localBinaryReady ? (
            <div style={{ marginTop: 6, fontSize: 10, color: tokens.warning }}>
              模型或本机组件未就绪时：侧栏 ⋯ → 设置 → 输入与语音 → 下载组件/模型 → 启用本机转写。
            </div>
          ) : null}
        </div>
      )}

      {!ack && (
        <div
          style={{
            border: `1px solid ${tokens.border}`,
            borderRadius: 8,
            padding: 10,
            fontSize: 11,
            lineHeight: 1.45,
            color: tokens.textSecondary,
          }}
        >
          <div style={{ marginBottom: 6, color: tokens.text, fontWeight: 500 }}>
            会议隐私说明
          </div>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            <li>会创建本地会话产物（转写 ± 可选音频）。</li>
            <li>默认结束录制后删除会议目录下音频（当前 UI 不提供保留选项）。</li>
            <li>生成纪要将把转写文本发给你已配置的 LLM。</li>
            <li>长会 STT 仅本机；不会自动开始录音。</li>
            <li>多方录音法律合规由你负责。</li>
          </ul>
          <button
            type="button"
            onClick={acceptAck}
            style={{ ...btnStyle(true), marginTop: 8, padding: "4px 10px", fontSize: 12 }}
          >
            我已了解
          </button>
        </div>
      )}

      <label style={{ fontSize: 12 }}>
        标题
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="可选"
          disabled={capturing}
          style={{
            display: "block",
            width: "100%",
            marginTop: 4,
            padding: "6px 8px",
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            boxSizing: "border-box",
          }}
        />
      </label>

      <div
        data-testid="meeting-capture-bar"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 8,
          alignItems: "center",
          padding: "8px 10px",
          borderRadius: 8,
          border: `1px solid ${capturing ? tokens.accent : tokens.border}`,
          background: tokens.bg,
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 500 }}>
          {capturing ? (
            <>
              <span style={{ color: "#c44" }}>●</span> 录制中 {formatElapsed(elapsedMs)}
              {capturePhase === "processing" ? " · 分段识别中…" : ""}
              {capturePhase === "starting" ? " · 启动中…" : ""}
              {capturePhase === "stopping" ? " · 结束中…" : ""}
              {refinePending > 0 ? ` · AI 纠错中(${refinePending})` : ""}
            </>
          ) : (
            "未录制"
          )}
        </span>
        <span style={{ fontSize: 11, color: tokens.textSecondary }}>{localReadyLabel}</span>
        {softCapHint && capturing && (
          <span style={{ fontSize: 11, color: "#b8860b" }}>
            已超过 {Math.round(MEETING_LIVE_SOFT_CAP_MS / 60_000)} 分钟软提示（硬上限{" "}
            {Math.round(MEETING_LIVE_HARD_CAP_MS / 60_000)} 分钟）
          </span>
        )}
        {state.dictationCaptureActive && !capturing && (
          <span style={{ fontSize: 11, color: "#c44" }}>听写占用中</span>
        )}
      </div>

      <div
        data-testid="meeting-live-options"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 12,
          fontSize: 11,
          color: tokens.textSecondary,
          alignItems: "center",
        }}
      >
        <label
          style={{ display: "flex", gap: 4, alignItems: "center", cursor: "pointer" }}
          title="段末将转写发给已配置 LLM 做 correct_only 纠错（同听写 ASR 纠错开关）；会参考上文消歧同音字"
        >
          <input
            type="checkbox"
            data-testid="meeting-asr-refine"
            checked={state.asrRefinerEnabled === true}
            disabled={capturing}
            onChange={(e) =>
              dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: e.target.checked })
            }
          />
          录制 AI 纠错（参考上文）
        </label>
        <label
          style={{ display: "flex", gap: 4, alignItems: "center", cursor: "pointer" }}
          title="结束录制后自动按静音/段落规则切分转写"
        >
          <input
            type="checkbox"
            data-testid="meeting-auto-segment-stop"
            checked={autoSegmentOnStop}
            onChange={(e) => setAutoSegmentOnStop(e.target.checked)}
          />
          结束时智能分段
        </label>
        {state.asrRefinerEnabled === true && (
          <span style={{ fontSize: 10, color: tokens.warning }}>
            纠错走 Companion LLM；失败时保留原文
          </span>
        )}
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button type="button" disabled={busy || capturing} onClick={createMeeting} style={btnStyle(false)}>
          新建会议会话
        </button>
        {!capturing ? (
          <button
            type="button"
            data-testid="meeting-start-capture"
            disabled={busy || !ack || !state.voicePrivacyAckV2}
            onClick={startLiveCapture}
            style={btnStyle(true)}
            title={
              !ack || !state.voicePrivacyAckV2
                ? "请先确认本机语音隐私与会议隐私说明"
                : undefined
            }
          >
            开始录制
          </button>
        ) : (
          <>
            <button
              type="button"
              data-testid="meeting-stop-capture"
              onClick={() => stopLiveCapture(false)}
              style={btnStyle(false)}
            >
              结束录制
            </button>
            <button
              type="button"
              data-testid="meeting-stop-and-generate"
              onClick={() => stopLiveCapture(true)}
              style={btnStyle(true)}
            >
              结束并生成纪要
            </button>
          </>
        )}
        {meetingId && (
          <span style={{ fontSize: 11, color: tokens.textSecondary, alignSelf: "center" }}>
            id: {meetingId.slice(0, 12)}… · {status}
          </span>
        )}
      </div>

      {/* Mtg2: speaker + import */}
      <div
        data-testid="meeting-mtg2-tools"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 8,
          padding: 10,
          borderRadius: 8,
          border: `1px solid ${tokens.border}`,
          background: tokens.bg,
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 500 }}>说话人 / 导入（Mtg2+3）</div>
        <label style={{ fontSize: 11, color: tokens.textSecondary }}>
          默认说话人标签（录制/导入 STT 追加时使用；可整表批量）
          <input
            data-testid="meeting-default-speaker"
            value={defaultSpeaker}
            onChange={(e) => setDefaultSpeaker(e.target.value)}
            placeholder='如「我」或「张三」'
            disabled={capturing}
            style={{
              display: "block",
              width: "100%",
              marginTop: 4,
              padding: "6px 8px",
              borderRadius: 6,
              border: `1px solid ${tokens.border}`,
              background: tokens.bgElevated,
              color: tokens.text,
              boxSizing: "border-box",
              fontSize: 12,
            }}
          />
        </label>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
          <label style={{ fontSize: 11, color: tokens.textSecondary }}>
            聚类 K
            <select
              data-testid="meeting-diarize-k"
              value={diarizeK}
              disabled={busy || capturing}
              onChange={(e) => setDiarizeK(Math.min(6, Math.max(0, Number(e.target.value) || 0)))}
              style={{ marginLeft: 4, fontSize: 12 }}
            >
              <option value={0}>自动</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
              <option value={6}>6</option>
            </select>
          </label>
          <span style={{ fontSize: 10, color: tokens.textSecondary }}>
            「自动」按说话人嵌入聚类估计人数（本机 · 实验 · 只标发言人N，非身份识别）
          </span>
          <label style={{ fontSize: 11, color: tokens.textSecondary, display: "flex", gap: 4, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={autoDiarizeAfterImport}
              disabled={busy || capturing}
              onChange={(e) => setAutoDiarizeAfterImport(e.target.checked)}
            />
            音频导入后自动标（实验）
          </label>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          <button
            type="button"
            data-testid="meeting-silence-cut"
            disabled={busy || capturing || !ack}
            onClick={applySilenceCut}
            style={btnStyle(false)}
            title="按空行/句号/长度软切分段（非说话人识别）"
          >
            智能分段
          </button>
          <button
            type="button"
            data-testid="meeting-bulk-speaker"
            disabled={busy || capturing || !ack}
            onClick={bulkLabelSpeaker}
            style={btnStyle(false)}
          >
            全部标为默认
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-audio"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("embedding")}
            style={btnStyle(true)}
            title="上传音频段 → 本机 ONNX 说话人嵌入 + 聚类；只标匿名发言人N，非身份识别（需先在 设置 → 输入与语音 → 听写方式 下载说话人分离模型）"
          >
            自动标说话人
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-legacy"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("audio_cluster")}
            style={btnStyle(false)}
            title="旧版回退：上传音频段 → 本机 3 维声学特征 + 聚类（区分度低 · 实验性 · 无需下载模型）；只标匿名发言人N，非身份识别"
          >
            旧版 3 维（区分度低）
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-text"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("text_gap")}
            style={btnStyle(false)}
            title="弱：按行交替发言人N，非声学"
          >
            弱标（交替）
          </button>
          <button
            type="button"
            data-testid="meeting-import-text"
            disabled={busy || capturing || !ack}
            onClick={() => textFileRef.current?.click()}
            style={btnStyle(false)}
          >
            上传转写文件
          </button>
          <button
            type="button"
            data-testid="meeting-import-audio"
            disabled={busy || capturing || !ack}
            onClick={() => audioFileRef.current?.click()}
            style={btnStyle(false)}
          >
            上传音频转写
          </button>
          {busy && importStatus?.includes("本机转写") && (
            <button
              type="button"
              data-testid="meeting-import-abort"
              onClick={() => {
                importAbortRef.current = true
                setImportStatus("正在中止…")
              }}
              style={btnStyle(false)}
            >
              中止导入
            </button>
          )}
        </div>
        <input
          ref={textFileRef}
          type="file"
          accept=".txt,.md,text/plain,text/markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0] || null
            e.target.value = ""
            void onImportTextFile(f)
          }}
        />
        <input
          ref={audioFileRef}
          type="file"
          accept="audio/*,.wav,.mp3,.m4a,.ogg,.webm"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0] || null
            e.target.value = ""
            void onImportAudioFile(f)
          }}
        />
        {importStatus && (
          <div style={{ fontSize: 11, color: tokens.textSecondary }} data-testid="meeting-import-status">
            {importStatus}
          </div>
        )}
        <div style={{ fontSize: 10, color: tokens.textSecondary, lineHeight: 1.4 }}>
          「自动标说话人」= 本机段特征 k-means → 匿名「发言人N」，
          <strong>不是</strong>身份识别，也非 Otter 级 SLA。默认覆盖已有标签（可再手改）。
          弱标仅按行交替。系统混音见 parking 调研。
        </div>
      </div>

      <label style={{ fontSize: 12, flex: 1, display: "flex", flexDirection: "column" }}>
        转写 / 口述文字（可编辑 · 支持「说话人: 正文」）
        <textarea
          value={transcript}
          onChange={(e) => {
            transcriptDirtyRef.current = true
            setTranscript(e.target.value)
          }}
          placeholder="粘贴会议转写，或开始录制/上传后自动填入…&#10;张三: 第一段&#10;&#10;李四: 第二段"
          rows={8}
          style={{
            marginTop: 4,
            width: "100%",
            flex: 1,
            minHeight: 120,
            padding: 8,
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            resize: "vertical",
            boxSizing: "border-box",
            fontFamily: "inherit",
            fontSize: 12,
            lineHeight: 1.45,
          }}
        />
        {capturing ? (
          <div
            data-testid="meeting-interim"
            style={{
              marginTop: 6,
              padding: "8px 10px",
              borderRadius: 8,
              background: tokens.accentSoft,
              border: `1px solid rgba(79, 70, 229, 0.16)`,
              fontSize: 13,
              color: tokens.accentText,
              lineHeight: 1.45,
              maxHeight: 96,
              overflow: "auto",
              whiteSpace: "pre-wrap",
            }}
          >
            {meetingLiveInterimHint({
              phase: capturePhase,
              interimText,
              nearRealtime,
              refinePending,
            })}
          </div>
        ) : null}
      </label>

      <details style={{ fontSize: 12 }}>
        <summary style={{ cursor: "pointer", color: tokens.textSecondary }}>
          纪要模板（可选）
        </summary>
        <p style={{ fontSize: 10, color: tokens.textSecondary, margin: "6px 0" }}>
          模板只约束输出结构；不会改变「不得臆造」规则。生成时把转写文本发给已配置 LLM。
        </p>
        <textarea
          value={templateMd}
          onChange={(e) => {
            const v = e.target.value
            setTemplateMd(v)
            templateMdRef.current = v
          }}
          placeholder={"### TL;DR\n\n### 决议\n\n### 待办\n\n### 风险 / 开放问题"}
          rows={5}
          style={{
            marginTop: 4,
            width: "100%",
            minHeight: 80,
            padding: 8,
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            resize: "vertical",
            boxSizing: "border-box",
            fontFamily: "inherit",
            fontSize: 12,
            lineHeight: 1.45,
          }}
        />
        <button
          type="button"
          onClick={() => {
            setTemplateMd("")
            templateMdRef.current = ""
            saveMeetingTemplate("")
          }}
          style={{
            marginTop: 6,
            fontSize: 11,
            padding: "4px 8px",
            borderRadius: 4,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.textSecondary,
            cursor: "pointer",
          }}
        >
          恢复默认
        </button>
      </details>

      <button type="button" disabled={busy || !ack || capturing} onClick={generate} style={btnStyle(true)}>
        {busy || pendingGenerate ? "生成中…" : "生成会议纪要"}
      </button>

      {error && (
        <div style={{ color: "#c44", fontSize: 12 }} role="alert">
          {error}
        </div>
      )}

      {minutesMd && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <strong style={{ flex: 1, fontSize: 12 }}>纪要</strong>
            <button type="button" onClick={copyMinutes} style={linkBtn}>
              复制
            </button>
            <button type="button" onClick={() => props.onSendToDraft(minutesMd)} style={linkBtn}>
              发送到对话草稿
            </button>
          </div>
          <pre
            style={{
              margin: 0,
              padding: 10,
              borderRadius: 8,
              border: `1px solid ${tokens.border}`,
              background: tokens.bg,
              fontSize: 11,
              lineHeight: 1.45,
              whiteSpace: "pre-wrap",
              maxHeight: 280,
              overflow: "auto",
            }}
          >
            {minutesMd}
          </pre>
        </div>
      )}
    </div>
  )
}

function btnStyle(primary: boolean): CSSProperties {
  return {
    border: primary ? "none" : `1px solid ${tokens.border}`,
    background: primary ? tokens.accent : "transparent",
    color: primary ? "#fff" : tokens.text,
    borderRadius: 8,
    padding: "8px 12px",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 500,
  }
}

const linkBtn: CSSProperties = {
  border: "none",
  background: "transparent",
  color: tokens.accent,
  cursor: "pointer",
  fontSize: 11,
  textDecoration: "underline",
  padding: 0,
}

FULL FILE chrome-extension/src/sidepanel/components/ThreadList.tsx
// Thread list — Timeline IA: today/yesterday + month→day, multi-select, tags view (P1).
// Wave A: untagged batch extract, tldr row, portal menu, tag cloud fold, N/M progress.

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { createPortal } from "react-dom"
import { useAgentStore } from "../store/agentStore"
import { tokens } from "../ui/tokens"
import { ThreadMetadataEditor } from "./ThreadMetadataEditor"
import { aiThreadGroup, threadTags } from "../utils/thread-management"
import { IconHistory } from "../ui/icons"
import { popupMenuStyles } from "../ui/popupMenuStyles"
import type { Thread } from "../types"
import {
  batchNeedsForceExtract,
  buildTagIndex,
  collapseTagKeys,
  digestQuotaDayKey,
  acpOutcomeChip,
  countAliases,
  displayThreadEvidence,
  displayThreadTitle,
  EXTRACT_DIGEST_MAX,
  threadAccessibleName,
  filterThreadsByQuery,
  formatThreadIdBadge,
  formatThreadListTime,
  groupThreadsByCalendar,
  isMonthGroupOpen,
  isPinnedGroupOpen,
  LS_DIGEST_QUOTA,
  LS_THREAD_LIST_EXPAND,
  LS_THREAD_LIST_EXPAND_MONTHS_LEGACY,
  parseDigestQuota,
  parseThreadListExpand,
  remainingDigestQuota,
  roleBadge,
  selectLazyDigestCandidates,
  selectUntaggedForExtract,
  selectionState,
  showDigestStaleBadge,
  TAG_CLOUD_MAX_VISIBLE,
  threadIdsInDay,
  threadIdsInMonth,
  toggleGroupSelection,
  selectAllIds,
  allSelectableSelected,
  type MonthGroup,
  type DayGroup,
  type ThreadListExpandState,
} from "../utils/thread-timeline"
import {
  digestLintStats,
  findRelatedThreads,
} from "../utils/thread-related"
import type { ThreadGraphSlim } from "../../background/thread-graph"

export function createBlankThread(dispatch: (action: { type: "ADD_THREAD"; thread: Thread }) => void) {
  const id = generateShortId()
  const now = new Date().toISOString()
  const thread = {
    id,
    alias: "",
    created_at: now,
    updated_at: now,
    // Inherit live companion config — do not stamp DeepSeek / empty trust.
    config_override: {} as Thread["config_override"],
    tool_whitelist: null as string[] | null,
    pinned_tabs: [] as number[],
    active_skill_ids: [] as string[],
  }
  dispatch({ type: "ADD_THREAD", thread: thread as Thread })
  chrome.runtime.sendMessage({ type: "thread.create", alias: "", id })
  return id
}

function generateShortId(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  let id = ""
  for (let i = 0; i < 6; i++) {
    id += chars[Math.floor(Math.random() * chars.length)]
  }
  return id
}

function loadExpandState(): ThreadListExpandState {
  try {
    const raw = localStorage.getItem(LS_THREAD_LIST_EXPAND)
    if (raw) return parseThreadListExpand(raw)
    // One-shot migrate legacy months array
    const legacy = localStorage.getItem(LS_THREAD_LIST_EXPAND_MONTHS_LEGACY)
    if (legacy) {
      const migrated = parseThreadListExpand(legacy)
      saveExpandState(migrated)
      try {
        localStorage.removeItem(LS_THREAD_LIST_EXPAND_MONTHS_LEGACY)
      } catch {
        /* ignore */
      }
      return migrated
    }
  } catch {
    /* ignore */
  }
  return parseThreadListExpand(null)
}

function saveExpandState(state: ThreadListExpandState) {
  try {
    localStorage.setItem(LS_THREAD_LIST_EXPAND, JSON.stringify(state))
  } catch {
    /* ignore quota */
  }
}

type ListView = "time" | "tags" | "topics" | "ai"

export function ThreadList() {
  const { state, dispatch } = useAgentStore()
  const [open, setOpen] = useState(false)
  const [editingThread, setEditingThread] = useState<Thread | null>(null)
  const [metadataNotice, setMetadataNotice] = useState("")
  useEffect(() => { if (!open) { setEditingThread(null); setMetadataNotice(""); setPendingDelete(null) } }, [open])
  useEffect(() => {
    const show = () => { if (!state.pendingSecurityConfirmations.length) setOpen(true) }
    window.addEventListener("cmspark:open-thread-manager", show)
    return () => window.removeEventListener("cmspark:open-thread-manager", show)
  }, [state.pendingSecurityConfirmations.length])
  useEffect(() => { if (state.pendingSecurityConfirmations.length) setOpen(false) }, [state.pendingSecurityConfirmations.length])
  const [query, setQuery] = useState("")
  const [view, setView] = useState<ListView>("time")
  const [selectMode, setSelectMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(() => new Set())
  const [expandState, setExpandState] = useState<ThreadListExpandState>(loadExpandState)
  const [expandedDays, setExpandedDays] = useState<Set<string>>(() => new Set())
  const [menuOpen, setMenuOpen] = useState(false)
  const menuOpenRef = useRef(menuOpen)
  useEffect(() => { menuOpenRef.current = menuOpen }, [menuOpen])
  const [menuPos, setMenuPos] = useState<{ top: number; right: number } | null>(null)
  const menuBtnRef = useRef<HTMLButtonElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const historyMenuRef = useRef<HTMLDivElement>(null)
  const historyRef = useRef<HTMLDivElement>(null)
  const [panelBox, setPanelBox] = useState<{ top: number; maxHeight: number } | null>(null)
  const [activeTag, setActiveTag] = useState<string | null>(null)
  const [extractingIds, setExtractingIds] = useState<Set<string>>(() => new Set())
  /** A-7 batch progress: done/total while untagged or multi extract runs. */
  const [extractProgress, setExtractProgress] = useState<{
    done: number
    total: number
  } | null>(null)
  /** Fingerprint/extracted_at snapshot at batch start — progress via UPSERT (S5). */
  const extractBatchRef = useRef<{
    /** Monotonic id so a late completed event cannot corrupt a newer batch. */
    batchId: number
    remaining: Set<string>
    total: number
    startMark: Map<string, string>
    /** Charge daily lazy quota only after successful ok[] (Wave B nit). */
    countTowardQuota: boolean
  } | null>(null)
  const extractBatchSeqRef = useRef(0)
  /** Clear N/M bar after complete; cancelled when a new batch starts (Claude N3). */
  const extractProgressClearTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [tagCloudExpanded, setTagCloudExpanded] = useState(false)
  const [trashView, setTrashView] = useState(false)
  const [cleanupOpen, setCleanupOpen] = useState(false)
  const [cleanupSuggestions, setCleanupSuggestions] = useState<
    Array<{
      thread_id: string
      reason: string
      detail: string
      confidence: number
      precheck?: boolean
    }>
  >([])
  const [cleanupSelected, setCleanupSelected] = useState<Set<string>>(() => new Set())
  /** 0 = 全部（含近期） */
  const [cleanupDays, setCleanupDays] = useState(0)
  /** In-panel confirm: Side Panel often swallows window.confirm (delete looks dead). */
  const [pendingDelete, setPendingDelete] = useState<{
    ids: string[]
    hard: boolean
    source: "row" | "batch" | "cleanup"
  } | null>(null)
  useEffect(() => {
    if (!pendingDelete) return
    historyRef.current?.querySelector("[role='alertdialog']")?.scrollIntoView({ block: "nearest" })
  }, [pendingDelete])
  /** Wave C: seed for related list; graph focus */
  const [relatedSeedId, setRelatedSeedId] = useState<string | null>(null)
  /** Companion thread.related override (local mirror first; WS may refine). */
  const [relatedFromServer, setRelatedFromServer] = useState<
    Array<{ thread_id: string; score: number; shared_tags?: string[] }> | null
  >(null)
  /** Brief feedback after click-to-copy thread id badge. */
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const copyIdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => {
    return () => {
      if (copyIdTimerRef.current) clearTimeout(copyIdTimerRef.current)
    }
  }, [])

  const { threads, activeThreadId, threadBusyById, config } = state
  /** Graph tab → open session (TG-3): keep graph open, switch active thread here. */
  useEffect(() => {
    const onMsg = (msg: { type?: string; thread_id?: string }) => {
      if (msg?.type !== "thread_graph.thread_selected" || !msg.thread_id) return
      // P1 H-UI-2: same thread → no-op (do not wipe messages)
      if (msg.thread_id === activeThreadId) return
      const thr = threads.find((t) => t.id === msg.thread_id)
      if (thr?.trashed_at) return
      dispatch({ type: "SET_ACTIVE_THREAD", threadId: msg.thread_id })
    }
    chrome.runtime.onMessage.addListener(onMsg)
    return () => chrome.runtime.onMessage.removeListener(onMsg)
  }, [dispatch, threads, activeThreadId])
  /** One-shot lazy extract per panel open when settings enabled (B-2). */
  const lazyDigestRanRef = useRef(false)

  const now = useMemo(() => new Date(), [open, threads.length])

  useEffect(() => {
    const onSug = (e: Event) => {
      const detail = (e as CustomEvent).detail
      const list = Array.isArray(detail?.suggestions) ? detail.suggestions : []
      setCleanupSuggestions(list)
      setCleanupSelected(
        new Set(
          list
            .filter((s: { precheck?: boolean }) => s.precheck === true)
            .map((s: { thread_id: string }) => s.thread_id),
        ),
      )
      setCleanupOpen(true)
    }
    window.addEventListener("cmspark:cleanup_suggestions", onSug as EventListener)
    return () =>
      window.removeEventListener("cmspark:cleanup_suggestions", onSug as EventListener)
  }, [])

  /** Position ⋯ menu for body portal (A-4 / GAP-14); clamp to viewport bottom. */
  useEffect(() => {
    if (!menuOpen) {
      setMenuPos(null)
      return
    }
    const MENU_EST_H = 280 // ~7 items
    const update = () => {
      const el = menuBtnRef.current
      if (!el) return
      const r = el.getBoundingClientRect()
      let top = r.bottom + 4
      if (top + MENU_EST_H > window.innerHeight - 8) {
        // Flip above the button when near bottom
        top = Math.max(8, r.top - MENU_EST_H - 4)
      }
      setMenuPos({
        top,
        right: Math.max(8, window.innerWidth - r.right),
      })
    }
    update()
    window.addEventListener("resize", update)
    window.addEventListener("scroll", update, true)
    return () => {
      window.removeEventListener("resize", update)
      window.removeEventListener("scroll", update, true)
    }
  }, [menuOpen])

  const scheduleProgressClear = useCallback(() => {
    if (extractProgressClearTimerRef.current) {
      clearTimeout(extractProgressClearTimerRef.current)
      extractProgressClearTimerRef.current = null
    }
    extractProgressClearTimerRef.current = setTimeout(() => {
      extractProgressClearTimerRef.current = null
      setExtractProgress(null)
    }, 1600)
  }, [])

  /** A-7 / S5: advance progress when thread digests change (digest_updated → UPSERT). */
  useEffect(() => {
    const batch = extractBatchRef.current
    if (!batch || batch.remaining.size === 0) return
    let changed = false
    for (const id of [...batch.remaining]) {
      const t = threads.find((x) => x.id === id) as Thread | undefined
      if (!t) {
        batch.remaining.delete(id)
        changed = true
        continue
      }
      const mark =
        (t.digest?.extracted_at || "") +
        "|" +
        (t.digest?.content_fingerprint || "") +
        "|" +
        (t.digest?.tags || []).join(",")
      const start = batch.startMark.get(id) || ""
      // Only mark done when digest fingerprint actually changed (not mere hasTags).
      if (mark !== start && (t.digest?.extracted_at || t.digest?.tags)) {
        batch.remaining.delete(id)
        changed = true
      }
    }
    if (!changed) return
    setExtractingIds(new Set(batch.remaining))
    const done = batch.total - batch.remaining.size
    setExtractProgress({ done, total: batch.total })
    if (batch.remaining.size === 0) {
      extractBatchRef.current = null
      scheduleProgressClear()
    }
  }, [threads, scheduleProgressClear])

  /** Clear remaining spinners when companion reports batch complete (ok + failed). */
  useEffect(() => {
    const onDone = (e: Event) => {
      const detail = (e as CustomEvent).detail as {
        ok?: string[]
        failed?: Array<{ id?: string } | string>
        batch_id?: string
      } | null
      const batch = extractBatchRef.current
      if (!batch) return
      // Ignore completions that belong to a superseded batch (no shared remaining mutation).
      if (
        detail?.batch_id != null &&
        detail.batch_id !== "" &&
        detail.batch_id !== String(batch.batchId)
      ) {
        return
      }
      // If another batch already replaced us, drop this late event.
      if (extractBatchRef.current !== batch) return

      const doneIds = new Set<string>()
      for (const id of detail?.ok || []) if (typeof id === "string") doneIds.add(id)
      for (const f of detail?.failed || []) {
        if (typeof f === "string") doneIds.add(f)
        else if (f && typeof f.id === "string") doneIds.add(f.id)
      }
      // Charge daily quota only for successful ok[] (Wave B nit — not at send time).
      if (batch.countTowardQuota && Array.isArray(detail?.ok) && detail!.ok!.length > 0) {
        const charge = detail!.ok!.filter((id) => typeof id === "string").length
        if (charge > 0) {
          try {
            const day = digestQuotaDayKey(new Date())
            const prev = parseDigestQuota(localStorage.getItem(LS_DIGEST_QUOTA), new Date())
            const count = (prev.day === day ? prev.count : 0) + charge
            localStorage.setItem(LS_DIGEST_QUOTA, JSON.stringify({ day, count }))
          } catch {
            /* ignore quota */
          }
        }
        batch.countTowardQuota = false // once per batch completion
      }
      if (doneIds.size === 0) {
        // Completed without lists — clear whole tracked batch
        batch.remaining.clear()
      } else {
        for (const id of doneIds) batch.remaining.delete(id)
      }
      if (extractBatchRef.current !== batch) return
      setExtractingIds(new Set(batch.remaining))
      setExtractProgress({
        done: batch.total - batch.remaining.size,
        total: batch.total,
      })
      if (batch.remaining.size === 0) {
        if (extractBatchRef.current === batch) extractBatchRef.current = null
        scheduleProgressClear()
      }
    }
    window.addEventListener("cmspark:extract_digest_completed", onDone as EventListener)
    return () =>
      window.removeEventListener(
        "cmspark:extract_digest_completed",
        onDone as EventListener,
      )
  }, [scheduleProgressClear])

  const filtered = useMemo(() => {
    const base = (threads as Thread[]).filter((t) =>
      trashView ? !!t.trashed_at : !t.trashed_at,
    )
    return filterThreadsByQuery(base, query)
  }, [threads, query, trashView])

  const aliasDupCount = useMemo(() => countAliases(filtered as Thread[]), [filtered])

  const timeline = useMemo(
    () => groupThreadsByCalendar(filtered as Thread[], now),
    [filtered, now],
  )

  const tagIndex = useMemo(() => buildTagIndex(filtered as Thread[]), [filtered])

  const tagKeys = useMemo(() => {
    return [...tagIndex.keys()]
      .filter((k) => k !== "__untagged__")
      .sort((a, b) => {
        const ca = tagIndex.get(a)?.length || 0
        const cb = tagIndex.get(b)?.length || 0
        return cb - ca || a.localeCompare(b)
      })
  }, [tagIndex])

  const tagCloudCollapsed = useMemo(
    () => collapseTagKeys(tagKeys, tagCloudExpanded, TAG_CLOUD_MAX_VISIBLE),
    [tagKeys, tagCloudExpanded],
  )

  /** A-1/A-2: untagged batch targets (≤20, skip busy+worker, force empty-tags). Trash: no extract. */
  const untaggedExtract = useMemo(() => {
    if (trashView) return { ids: [] as string[], force: false }
    return selectUntaggedForExtract(filtered as Thread[], {
      max: EXTRACT_DIGEST_MAX,
      busyIds: threadBusyById,
      excludeWorkers: true,
    })
  }, [filtered, threadBusyById, trashView])

  /** Wave C-2: related hits — local instant, optional companion refine. */
  const relatedHitsLocal = useMemo(() => {
    if (!relatedSeedId) return []
    return findRelatedThreads(relatedSeedId, filtered as Thread[], 3)
  }, [relatedSeedId, filtered])

  const relatedHits = useMemo(() => {
    if (!relatedSeedId) return []
    if (relatedFromServer && relatedFromServer.length > 0) {
      return relatedFromServer.slice(0, 3).map((h) => ({
        thread_id: h.thread_id,
        score: h.score,
        signals: { co_tag: 0, tf: 0, time: 0 },
        shared_tags: h.shared_tags || [],
      }))
    }
    return relatedHitsLocal
  }, [relatedSeedId, relatedFromServer, relatedHitsLocal])

  // Request companion related when seed changes (background bridge + local fallback).
  useEffect(() => {
    if (!relatedSeedId) {
      setRelatedFromServer(null)
      return
    }
    setRelatedFromServer(null)
    chrome.runtime.sendMessage({
      type: "thread.related",
      thread_id: relatedSeedId,
      limit: 3,
    })
    const onRel = (e: Event) => {
      const d = (e as CustomEvent).detail as {
        thread_id?: string
        related?: Array<{ thread_id: string; score: number; shared_tags?: string[] }>
      }
      if (d?.thread_id !== relatedSeedId) return
      if (Array.isArray(d.related)) setRelatedFromServer(d.related)
    }
    window.addEventListener("cmspark:thread_related", onRel as EventListener)
    return () => window.removeEventListener("cmspark:thread_related", onRel as EventListener)
  }, [relatedSeedId])

  /** Open Obsidian-style full-page graph (TG-1/TG-4 — replaces side-panel edge list). */
  const openThreadGraph = useCallback(() => {
    const slim: ThreadGraphSlim[] = (threads as Thread[]).map((t) => ({
      id: t.id,
      alias: t.alias,
      updated_at: t.updated_at,
      created_at: t.created_at,
      last_message_at: t.last_message_at ?? null,
      agent_role: t.agent_role,
      trashed_at: t.trashed_at ?? null,
      user_tags: t.user_tags,
      digest: t.digest
        ? {
            tldr: t.digest?.tldr || "",
            tags: t.digest.tags,
            bullets: t.digest?.bullets || [],
            stale: t.digest?.stale,
          }
        : null,
    }))
    chrome.runtime.sendMessage(
      {
        type: "thread_graph.open",
        threads: slim,
        focus_id: relatedSeedId || activeThreadId || null,
      },
      () => {
        void chrome.runtime.lastError
      },
    )
    setMenuOpen(false)
    setOpen(false)
  }, [threads, relatedSeedId, activeThreadId])

  /** Wave C-4: lint stats for cleanup helper. */
  const lintStats = useMemo(
    () => digestLintStats(filtered as Thread[]),
    [filtered],
  )

  const selectableIds = useMemo(() => {
    const s = new Set<string>()
    for (const t of filtered) {
      if (!threadBusyById[t.id]) s.add(t.id)
    }
    return s
  }, [filtered, threadBusyById])

  const searchActive = query.trim().length > 0

  const toggleMonth = (monthKey: string) => {
    setExpandState((prev) => {
      const months = prev.months.includes(monthKey)
        ? prev.months.filter((k) => k !== monthKey)
        : [...prev.months, monthKey]
      const next = { ...prev, months }
      saveExpandState(next)
      return next
    })
  }

  const togglePinned = (key: "today" | "yesterday") => {
    setExpandState((prev) => {
      const next = { ...prev, [key]: !prev[key] }
      saveExpandState(next)
      return next
    })
  }

  const toggleDay = (dayKey: string) => {
    setExpandedDays((prev) => {
      const next = new Set(prev)
      if (next.has(dayKey)) next.delete(dayKey)
      else next.add(dayKey)
      return next
    })
  }

  const exitSelectMode = useCallback(() => {
    setSelectMode(false)
    setSelected(new Set())
  }, [])

  /** Copy thread id (without #) for search / support; show brief “已复制” only on success. */
  const copyThreadId = useCallback(async (threadId: string) => {
    const text = String(threadId || "").trim()
    if (!text) return
    let ok = false
    try {
      await navigator.clipboard.writeText(text)
      ok = true
    } catch {
      try {
        const ta = document.createElement("textarea")
        ta.value = text
        ta.style.position = "fixed"
        ta.style.left = "-9999px"
        document.body.appendChild(ta)
        ta.select()
        ok = document.execCommand("copy")
        document.body.removeChild(ta)
      } catch {
        ok = false
      }
    }
    if (!ok) return
    setCopiedId(threadId)
    if (copyIdTimerRef.current) clearTimeout(copyIdTimerRef.current)
    copyIdTimerRef.current = setTimeout(() => {
      setCopiedId((cur) => (cur === threadId ? null : cur))
      copyIdTimerRef.current = null
    }, 1200)
  }, [])

  const handleNewThread = () => {
    createBlankThread(dispatch)
    setOpen(false)
    exitSelectMode()
  }

  const handleCleanupEmpty = () => {
    const emptyN = threads.filter(
      (t) => t.message_count === 0 && t.id !== activeThreadId && !t.trashed_at,
    ).length
    if (threads.some((t) => typeof t.message_count === "number") && emptyN === 0) {
      alert("没有空白线程")
      setMenuOpen(false)
      return
    }
    const nLabel = emptyN > 0 ? `${emptyN} 个` : "所有"
    if (
      !confirm(
        `将永久删除 ${nLabel}没有任何消息的空白线程。此操作不可恢复，也不经过回收站。`,
      )
    ) {
      return
    }
    chrome.runtime.sendMessage({
      type: "thread.cleanup_empty",
      except_thread_id: activeThreadId,
    })
    setMenuOpen(false)
    setOpen(false)
  }

  const handleGenerateTitle = () => {
    const targetThreadId = activeThreadId || threads[0]?.id
    if (!targetThreadId) {
      alert("暂无线程可生成标题")
      return
    }
    chrome.runtime.sendMessage({ type: "thread.generate_title", thread_id: targetThreadId })
    setMenuOpen(false)
  }

  const handleBatchAutoTitle = (ids?: string[]) => {
    const payload: Record<string, unknown> = {
      type: "thread.batch_auto_title",
      only_empty: true,
    }
    if (ids && ids.length > 0) payload.thread_ids = ids
    chrome.runtime.sendMessage(payload)
    setMenuOpen(false)
  }

  const beginExtractBatch = useCallback(
    (ids: string[], force: boolean, opts?: { countTowardQuota?: boolean }) => {
      const capped = ids.slice(0, EXTRACT_DIGEST_MAX)
      if (capped.length === 0) return
      // Serialize: refuse starting a second batch while one is in flight (A dual-review nit).
      if (extractBatchRef.current && extractBatchRef.current.remaining.size > 0) {
        // In-flight batch already shows N/M progress bar; ignore overlapping click.
        return
      }
      if (extractProgressClearTimerRef.current) {
        clearTimeout(extractProgressClearTimerRef.current)
        extractProgressClearTimerRef.current = null
      }
      const startMark = new Map<string, string>()
      for (const id of capped) {
        const t = threads.find((x) => x.id === id) as Thread | undefined
        const mark =
          (t?.digest?.extracted_at || "") +
          "|" +
          (t?.digest?.content_fingerprint || "") +
          "|" +
          (t?.digest?.tags || []).join(",")
        startMark.set(id, mark)
      }
      const batchId = ++extractBatchSeqRef.current
      extractBatchRef.current = {
        batchId,
        remaining: new Set(capped),
        total: capped.length,
        startMark,
        // Quota charged on extract_digest.completed ok[] only (not at send).
        countTowardQuota: opts?.countTowardQuota === true,
      }
      setExtractingIds(new Set(capped))
      setExtractProgress({ done: 0, total: capped.length })
      chrome.runtime.sendMessage({
        type: "thread.extract_digest",
        thread_ids: capped,
        force: force === true,
        batch_id: String(batchId),
      })
      // No fixed 60s full clear (S5/GAP-15) — progress from digest UPSERT / completed.
    },
    [threads],
  )

  // Wave B-2: when list opens and settings enable lazy digest, fill coverage once.
  useEffect(() => {
    if (!open) {
      lazyDigestRanRef.current = false
      return
    }
    if (lazyDigestRanRef.current || trashView) return
    if (config?.thread_digest_enabled !== true) return
    if (extractBatchRef.current) return
    const maxPerDay = config.thread_digest_max_per_day ?? 20
    const idleH = config.thread_digest_on_idle_hours ?? 24
    let quota = { day: digestQuotaDayKey(now), count: 0 }
    try {
      quota = parseDigestQuota(localStorage.getItem(LS_DIGEST_QUOTA), now)
    } catch {
      /* ignore */
    }
    const remain = remainingDigestQuota(quota, maxPerDay)
    if (remain <= 0) return
    const live = (threads as Thread[]).filter((t) => !t.trashed_at)
    const sel = selectLazyDigestCandidates(live, {
      now,
      onIdleHours: idleH,
      max: Math.min(EXTRACT_DIGEST_MAX, remain),
      busyIds: threadBusyById,
      excludeWorkers: true,
    })
    if (sel.ids.length === 0) return
    lazyDigestRanRef.current = true
    beginExtractBatch(sel.ids, sel.force, { countTowardQuota: true })
  }, [
    open,
    trashView,
    config?.thread_digest_enabled,
    config?.thread_digest_max_per_day,
    config?.thread_digest_on_idle_hours,
    threads,
    threadBusyById,
    now,
    beginExtractBatch,
  ])

  const handleExtractDigest = (ids: string[]) => {
    if (ids.length === 0) return
    const capped = ids.slice(0, EXTRACT_DIGEST_MAX)
    const force = batchNeedsForceExtract(filtered as Thread[], capped)
    beginExtractBatch(capped, force)
  }

  /** A-1 menu / A-2 CTA: extract untagged (uses selection.force — S1). */
  const handleExtractUntagged = () => {
    if (untaggedExtract.ids.length === 0) return
    beginExtractBatch(untaggedExtract.ids, untaggedExtract.force)
    setMenuOpen(false)
  }

  const handleSelect = (threadId: string) => {
    if (selectMode) {
      if (threadBusyById[threadId]) return
      setSelected((prev) => {
        const next = new Set(prev)
        if (next.has(threadId)) next.delete(threadId)
        else next.add(threadId)
        return next
      })
      return
    }
    // Dual-review residual: do not activate soft-deleted threads into main chat
    if (trashView) return
    const thr = threads.find((t) => t.id === threadId)
    if (thr?.trashed_at) return
    dispatch({ type: "SET_ACTIVE_THREAD", threadId })
    chrome.runtime.sendMessage({ type: "thread.select", threadId })
    setOpen(false)
  }

  const handleDeleteOne = (threadId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (threadBusyById[threadId]) {
      alert("该线程正在运行，无法删除")
      return
    }
    setPendingDelete({ ids: [threadId], hard: trashView, source: "row" })
  }

  const handleBatchDelete = () => {
    let ids = [...selected].filter((id) => selectableIds.has(id))
    if (ids.length === 0) {
      ids = [...selectableIds]
      if (ids.length === 0) return
      setSelected(new Set(ids))
      setSelectMode(true)
    }
    setPendingDelete({ ids, hard: trashView, source: "batch" })
  }

  const executePendingDelete = () => {
    if (!pendingDelete || pendingDelete.ids.length === 0) return
    const { ids, hard, source } = pendingDelete
    const mode = hard ? "hard" : "trash"
    if (ids.length === 1) {
      dispatch({ type: "REMOVE_THREAD", threadId: ids[0] })
      chrome.runtime.sendMessage({ type: "thread.delete", thread_id: ids[0], mode }, () => {
        void chrome.runtime.lastError
      })
    } else {
      dispatch({ type: "REMOVE_THREADS", threadIds: ids })
      chrome.runtime.sendMessage({ type: "thread.batch_delete", thread_ids: ids, mode }, () => {
        void chrome.runtime.lastError
      })
    }
    setPendingDelete(null)
    if (source === "batch") exitSelectMode()
    if (source === "cleanup") {
      setCleanupOpen(false)
      setCleanupSuggestions([])
      setCleanupSelected(new Set())
    }
  }

  const handleSelectAllVisible = () => {
    if (cleanupOpen && cleanupSuggestions.length > 0) {
      setCleanupSelected(
        new Set(cleanupSuggestions.map((s) => s.thread_id).filter(Boolean).slice(0, 50)),
      )
      return
    }
    const ids = selectAllIds(selectableIds)
    setSelectMode(true)
    setSelected(ids)
    const months = timeline.months.map((m) => m.monthKey)
    const days = new Set<string>()
    for (const m of timeline.months) {
      for (const d of m.days) days.add(d.dayKey)
    }
    const nextExpand = { months, today: true, yesterday: true }
    setExpandState(nextExpand)
    saveExpandState(nextExpand)
    setExpandedDays(days)
  }

  const handleClearVisibleSelection = () => {
    if (cleanupOpen && cleanupSuggestions.length > 0) {
      setCleanupSelected(new Set())
      return
    }
    setSelected(new Set())
  }

  const handleRestore = (ids: string[]) => {
    if (ids.length === 0) return
    chrome.runtime.sendMessage({ type: "thread.restore", thread_ids: ids })
    dispatch({ type: "REMOVE_THREADS", threadIds: ids }) // drop from trash view until list refresh
    chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
    exitSelectMode()
  }

  const openTrashView = () => {
    setTrashView(true)
    setView("time")
    setMenuOpen(false)
    chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
  }

  const closeTrashView = () => {
    setTrashView(false)
    chrome.runtime.sendMessage({ type: "thread.list" })
  }

  const runCleanupScan = () => {
    const payload: Record<string, unknown> = {
      type: "thread.suggest_cleanup",
      include_workers: false,
      except_thread_id: activeThreadId || undefined,
    }
    if (cleanupDays > 0) {
      const to = new Date()
      const from = new Date(to.getTime() - cleanupDays * 86400_000)
      payload.to = from.toISOString()
    }
    chrome.runtime.sendMessage(payload)
    setMenuOpen(false)
  }

  const applyCleanupTrash = () => {
    let ids = [...cleanupSelected].slice(0, 50)
    if (ids.length === 0) {
      ids = cleanupSuggestions.map((s) => s.thread_id).filter(Boolean).slice(0, 50)
      if (ids.length === 0) return
      setCleanupSelected(new Set(ids))
    }
    setPendingDelete({ ids, hard: false, source: "cleanup" })
  }

  /** B-4: extract digests for cleanup-selected threads only (no delete). */
  const applyCleanupExtractOnly = () => {
    const ids = [...cleanupSelected].slice(0, EXTRACT_DIGEST_MAX)
    if (ids.length === 0) return
    const force = batchNeedsForceExtract(filtered as Thread[], ids)
    beginExtractBatch(ids, force)
  }

  const panelMaxHeight = selectMode || cleanupOpen || view === "tags" || view === "topics" || view === "ai" ? 480 : 360

  useEffect(() => {
    if (!open) {
      setPanelBox(null)
      return
    }
    const place = () => {
      const r = triggerRef.current?.getBoundingClientRect()
      const top = Math.round((r?.bottom ?? 48) + 6)
      setPanelBox({
        top,
        maxHeight: Math.max(0, Math.min(window.innerHeight - top - 12, (document.querySelector<HTMLElement>(".cm-composer-dock")?.getBoundingClientRect().top ?? window.innerHeight) - top - 8)),
      })
    }
    place()
    window.addEventListener("resize", place)
    const observer = new ResizeObserver(place)
    const dock = document.querySelector(".cm-composer-dock")
    const rail = document.querySelector(".cm-status-rail")
    if (dock) observer.observe(dock)
    if (rail) observer.observe(rail)
    return () => { window.removeEventListener("resize", place); observer.disconnect() }
  }, [open, selectMode, view])

  // Outside actions remain directly usable (not intercepted by a transparent backdrop).
  useEffect(() => {
    if (!open) return
    const outside = (event: MouseEvent) => {
      const target = event.target as Node
      if (!historyRef.current?.contains(target) && !triggerRef.current?.contains(target) && !historyMenuRef.current?.contains(target)) {
        setOpen(false); setMenuOpen(false); exitSelectMode()
      }
    }
    document.addEventListener("mousedown", outside)
    return () => document.removeEventListener("mousedown", outside)
  }, [open, exitSelectMode])

  // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
  // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
  useEffect(() => {
    if (!open || !panelBox) return
    historyRef.current?.querySelector<HTMLInputElement>('input[type="search"]')?.focus()
    const key = (event: KeyboardEvent) => {
      if (event.key !== "Escape" || event.defaultPrevented) return
      if (!historyRef.current?.contains(event.target as Node) && event.target !== triggerRef.current && !historyMenuRef.current?.contains(event.target as Node)) return
      event.preventDefault()
      event.stopPropagation()
      if (menuOpenRef.current) { setMenuOpen(false); menuBtnRef.current?.focus(); return }
      setOpen(false); triggerRef.current?.focus()
    }
    document.addEventListener("keydown", key)
    return () => document.removeEventListener("keydown", key)
  }, [open, !!panelBox])

  const closeMetadataEditor = (threadId = editingThread?.id) => {
    setEditingThread(null)
    requestAnimationFrame(() => {
      const row = threadId ? historyRef.current?.querySelector(`[data-thread-id="${CSS.escape(threadId)}"]`) : null
      const target = row?.querySelector<HTMLElement>('button[title="编辑标签与分组"]') || historyRef.current?.querySelector<HTMLElement>('input[type="search"]')
      target?.focus()
    })
  }

  const renderThreadRow = (t: Thread) => {
    const busy = !!threadBusyById[t.id]
    const isActive = t.id === activeThreadId
    const badge = roleBadge(t.agent_role)
    const title = displayThreadTitle(t)
    const accessibleName = threadAccessibleName(t)
    const idBadge = formatThreadIdBadge(t.id)
    const rel = formatThreadListTime(t, now, aliasDupCount)
    const tags = threadTags(t)
    const extracting = extractingIds.has(t.id)
    const evidence = displayThreadEvidence(t)
    const chip = acpOutcomeChip(t)
    const justCopied = copiedId === t.id

    return (
      <div
        key={t.id}
        className={selectMode ? "cm-thread-row cm-thread-selecting" : "cm-thread-row"}
        data-thread-id={t.id}
        style={{
          ...styles.threadItem,
          background: isActive ? tokens.accentSoft : "transparent",
          opacity: selectMode && busy ? 0.45 : 1,
        }}
        aria-label={accessibleName}
      >
        {selectMode && (
          <input
            type="checkbox"
            checked={selected.has(t.id)}
            disabled={busy}
            onChange={() => handleSelect(t.id)}
            onClick={(e) => e.stopPropagation()}
            title={busy ? "运行中，不可选" : undefined}
            style={styles.checkbox}
            aria-label={`选择 ${accessibleName}`}
          />
        )}
        <div className="cm-thread-row-content" style={{ flex: 1, minWidth: 0 }}>
          <div style={styles.threadAliasRow}>
            <button type="button" className="cm-thread-open" style={{ ...styles.threadAlias, border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "pointer", padding: "6px 0", minHeight: 32 }} disabled={trashView} aria-label={`${selectMode ? "选择" : trashView ? "已删除" : "打开"} ${accessibleName}`} onClick={e => { e.stopPropagation(); handleSelect(t.id) }}>{title}</button>
            {chip ? <span style={styles.badge}>{chip}</span> : null}
            {idBadge ? (
              <button
                type="button"
                style={{
                  ...styles.threadIdBadge,
                  color: justCopied ? tokens.accentText : tokens.textMuted,
                }}
                title={`复制编号 ${idBadge}（可在搜索框粘贴定位）`}
                aria-label={`复制会话编号 ${idBadge}`}
                onClick={(e) => {
                  e.stopPropagation()
                  void copyThreadId(t.id)
                }}
              >
                {justCopied ? "已复制" : idBadge}
              </button>
            ) : null}
            {badge && <span style={styles.badge}>{badge}</span>}
            {extracting && <span style={styles.badgeMuted}>抽取中</span>}
            {showDigestStaleBadge(t, view, now) && (
              <span style={styles.badgeMuted} title="要点可能过期">
                过期
              </span>
            )}
          </div>
          {evidence && (
            <div style={styles.tldr} title={evidence}>
              {evidence}
            </div>
          )}
          {tags.length > 0 && (
            <div style={styles.tagRow}>
              {tags.slice(0, 4).map((tag) => (
                <button
                  key={tag}
                  type="button"
                  style={styles.tagPill}
                  onClick={(e) => {
                    e.stopPropagation()
                    setView("tags")
                    setActiveTag(tag)
                  }}
                >
                  #{tag} <span className="cm-thread-tag-origin">{(t.user_tags || []).some(value => value.toLowerCase() === tag) ? "人工" : "AI"}</span>
                </button>
              ))}
            </div>
          )}
          {rel && <div style={styles.relTime}>{rel}</div>}
          {t.topic_folder ? (
            <div style={styles.relTime} title="话题夹">
              分组 · {t.topic_folder}
            </div>
          ) : null}
        </div>
        {!selectMode && (
          <>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                setRelatedSeedId((prev) => (prev === t.id ? null : t.id))
              }}
              title="列表内相关"
            >
              🔗
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                handleExtractDigest([t.id])
              }}
              title="提取要点 / 标签"
            >
              🏷
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                setOpen(false)
                chrome.runtime.sendMessage({ type: "thread.distill_preview", thread_id: t.id })
              }}
              title="提炼为知识（需确认）"
            >
              知识
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                setEditingThread(t)
                setMetadataNotice("")
              }}
              title="编辑标签与分组"
            >
              分类
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                dispatch({ type: "SET_SUMMARIZING_THREAD", threadId: t.id })
                chrome.runtime.sendMessage({
                  type: "thread.export_obsidian",
                  thread_id: t.id,
                  scope: "summary",
                  // Wave D/E: honor Settings exportIncludeReasoning (P0-2)
                  include_reasoning: state.exportIncludeReasoning === true,
                })
              }}
              disabled={state.summarizingThreadId === t.id}
              title="导出此线程摘要为 Markdown"
            >
              {state.summarizingThreadId === t.id ? "⏳" : "🧠"}
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => handleDeleteOne(t.id, e)}
              title="删除线程"
              aria-label={`删除 ${accessibleName}`}
            >
              🗑️
            </button>
          </>
        )}
      </div>
    )
  }

  const renderGroupCheckbox = (ids: string[], label: string) => {
    if (!selectMode) return null
    const eligible = ids.filter((id) => selectableIds.has(id))
    const st = selectionState(eligible, selected)
    return (
      <input
        type="checkbox"
        checked={st === "all" && eligible.length > 0}
        ref={(el) => {
          if (el) el.indeterminate = st === "some"
        }}
        disabled={eligible.length === 0}
        onChange={() => {
          setSelected((prev) => toggleGroupSelection(ids, prev, selectableIds))
        }}
        onClick={(e) => e.stopPropagation()}
        aria-label={`选择 ${label}`}
        style={styles.checkbox}
      />
    )
  }

  const renderMonth = (month: MonthGroup) => {
    const openMonth = isMonthGroupOpen(month.monthKey, expandState, {
      searchActive,
      hasMatches: searchActive && month.count > 0,
    })
    const ids = threadIdsInMonth(month)
    return (
      <div key={month.monthKey}>
        <div style={styles.groupHeader}>
          {renderGroupCheckbox(ids, month.label)}
          <button type="button" className="cm-history-group" aria-expanded={openMonth} onClick={() => toggleMonth(month.monthKey)}><span aria-hidden="true" style={styles.groupChevron}>{openMonth ? "▼" : "▶"}</span> {month.label} · {month.count}</button>
        </div>
        {openMonth && month.days.map((day) => renderDay(day))}
      </div>
    )
  }

  const renderDay = (day: DayGroup) => {
    // Search: force-open days that still have matches (parity with month groups).
    const openDay =
      expandedDays.has(day.dayKey) || (searchActive && day.threads.length > 0)
    const ids = threadIdsInDay(day)
    return (
      <div key={day.dayKey}>
        <div
          style={{ ...styles.groupHeader, paddingLeft: 20 }}
        >
          {renderGroupCheckbox(ids, day.label)}
          <button type="button" className="cm-history-group" aria-expanded={openDay} onClick={() => toggleDay(day.dayKey)}><span aria-hidden="true" style={styles.groupChevron}>{openDay ? "▼" : "▶"}</span> {day.label} · {day.threads.length}</button>
        </div>
        {openDay && day.threads.map((t) => renderThreadRow(t as Thread))}
      </div>
    )
  }

  const renderTimeline = () => {
    const todayOpen = isPinnedGroupOpen("today", expandState, {
      searchActive,
      hasMatches: searchActive && timeline.today.length > 0,
    })
    const yesterdayOpen = isPinnedGroupOpen("yesterday", expandState, {
      searchActive,
      hasMatches: searchActive && timeline.yesterday.length > 0,
    })
    return (
      <>
        {timeline.today.length > 0 && (
          <div>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(
                timeline.today.map((t) => t.id),
                "今天",
              )}
              <button type="button" className="cm-history-group" aria-expanded={todayOpen} onClick={() => togglePinned("today")}><span aria-hidden="true" style={styles.groupChevron}>{todayOpen ? "▼" : "▶"}</span> 今天 · {timeline.today.length}</button>
            </div>
            {todayOpen && timeline.today.map((t) => renderThreadRow(t as Thread))}
          </div>
        )}

        {timeline.yesterday.length > 0 && (
          <div>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(
                timeline.yesterday.map((t) => t.id),
                "昨天",
              )}
              <button type="button" className="cm-history-group" aria-expanded={yesterdayOpen} onClick={() => togglePinned("yesterday")}><span aria-hidden="true" style={styles.groupChevron}>{yesterdayOpen ? "▼" : "▶"}</span> 昨天 · {timeline.yesterday.length}</button>
            </div>
            {yesterdayOpen && timeline.yesterday.map((t) => renderThreadRow(t as Thread))}
          </div>
        )}

        {timeline.months.map(renderMonth)}

        {filtered.length === 0 && (
          <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
            {threads.length === 0 ? "暂无线程，可从导航创建新对话" : "无匹配线程"}
          </div>
        )}
      </>
    )
  }

  const renderTagsView = () => {
    const untagged = tagIndex.get("__untagged__") || []
    const listForTag =
      activeTag === null
        ? null
        : activeTag === "__untagged__"
          ? untagged
          : tagIndex.get(activeTag) || []
    const extractDisabled = untaggedExtract.ids.length === 0
    const extractLabel = `为未标注提取要点（最多${EXTRACT_DIGEST_MAX}）`
    // Primary CTA only when extractable targets exist (no dead disabled empty-library CTA).
    const showPrimaryCta = untaggedExtract.ids.length > 0

    return (
      <div>
        {/* A-5: count-fold only; 更多/收起 OUTSIDE pills so they are never clipped (Pi blocking). */}
        <div style={styles.tagCloudSection}>
          <div style={styles.tagCloud}>
            {tagKeys.length === 0 && untagged.length === 0 && (
              <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 8 }}>
                暂无标签。使用下方按钮为会话提取要点与标签。
              </div>
            )}
            {tagCloudCollapsed.visible.map((tag) => {
              const n = tagIndex.get(tag)?.length || 0
              const active = activeTag === tag
              return (
                <button
                  key={tag}
                  type="button"
                  style={active ? styles.tagPillActive : styles.tagPill}
                  onClick={() => setActiveTag(active ? null : tag)}
                >
                  #{tag} {n}
                </button>
              )
            })}
            {untagged.length > 0 && (
              <button
                type="button"
                style={
                  activeTag === "__untagged__" ? styles.tagPillActive : styles.tagPill
                }
                onClick={() =>
                  setActiveTag(activeTag === "__untagged__" ? null : "__untagged__")
                }
              >
                #未标注 {untagged.length}
              </button>
            )}
          </div>
          {tagCloudCollapsed.hiddenCount > 0 && !tagCloudExpanded && (
            <div style={styles.tagCloudFoldRow}>
              <button
                type="button"
                style={styles.tagPill}
                onClick={() => setTagCloudExpanded(true)}
                title={`还有 ${tagCloudCollapsed.hiddenCount} 个标签`}
              >
                更多 · {tagCloudCollapsed.hiddenCount}
              </button>
            </div>
          )}
          {tagCloudExpanded && tagKeys.length > TAG_CLOUD_MAX_VISIBLE && (
            <div style={styles.tagCloudFoldRow}>
              <button
                type="button"
                style={styles.tagPill}
                onClick={() => setTagCloudExpanded(false)}
              >
                收起
              </button>
            </div>
          )}
        </div>

        {showPrimaryCta && untaggedExtract.ids.length > 0 && (
          <div style={styles.untaggedCtaRow}>
            <button
              type="button"
              style={{
                ...styles.primaryCta,
                opacity: extractDisabled ? 0.45 : 1,
                cursor: extractDisabled ? "not-allowed" : "pointer",
              }}
              disabled={extractDisabled}
              onClick={handleExtractUntagged}
              title={
                extractDisabled
                  ? "没有可提取的未标注会话（已跳过运行中与 worker）"
                  : `将提取最多 ${untaggedExtract.ids.length} 个未标注会话`
              }
            >
              🏷 {extractLabel}
            </button>
            {!extractDisabled && (
              <span style={styles.ctaHint}>
                本批 {untaggedExtract.ids.length} 个
                {untagged.length > untaggedExtract.ids.length
                  ? `（共 ${untagged.length} 未标注）`
                  : ""}
              </span>
            )}
          </div>
        )}

        {listForTag && (
          <div>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(listForTag.map((t) => t.id), activeTag === "__untagged__" ? "未标注" : `#${activeTag}`)}
              <span style={styles.groupLabel}>
                {activeTag === "__untagged__" ? "未标注" : `#${activeTag}`} ·{" "}
                {listForTag.length}
              </span>
            </div>
            {listForTag.map((t) => renderThreadRow(t as Thread))}
          </div>
        )}
        {!listForTag && tagKeys.length > 0 && (
          <div style={{ color: tokens.textMuted, fontSize: 12, padding: 10 }}>
            选择上方标签查看会话
          </div>
        )}
      </div>
    )
  }

  const renderTopicsView = (ai = false) => {
    const groups = new Map<string, Thread[]>()
    for (const t of filtered as Thread[]) {
      const key = ai ? aiThreadGroup(t) || "待 AI 整理" : t.topic_folder || "未分组"
      const arr = groups.get(key) || []
      arr.push(t)
      groups.set(key, arr)
    }
    const keys = [...groups.keys()].sort((a, b) => {
      const ungrouped = ai ? "待 AI 整理" : "未分组"
      if (a === ungrouped) return 1
      if (b === ungrouped) return -1
      return a.localeCompare(b, "zh")
    })
    return (
      <>
        {keys.map((key) => (
          <div key={key}>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(groups.get(key)!.map((t) => t.id), key)}
              <span style={styles.groupLabel}>
                {key} · {groups.get(key)!.length}
              </span>
            </div>
            {groups.get(key)!.map((t) => renderThreadRow(t))}
          </div>
        ))}
        {keys.length === 1 && keys[0] === "未分组" && filtered.length > 0 && (
          <div style={{ color: tokens.textMuted, fontSize: 11, padding: "8px 12px" }}>
            点对话右侧「分类」编辑标签、选择或新建分组
          </div>
        )}
        {filtered.length === 0 && (
          <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
            无匹配线程
          </div>
        )}
      </>
    )
  }

  return (
    <div style={{ position: "relative" }}>
      <button
        ref={triggerRef}
        type="button"
        className="cm-thread-manager-trigger"
        style={{
          ...styles.hamburger,
          ...(open ? { color: tokens.text } : null),
        }}
        disabled={state.pendingSecurityConfirmations.length > 0}
        onClick={() => setOpen(!open)}
        title="对话管理：历史、标签、分组与图谱"
        aria-label="对话管理（历史对话）"
        aria-expanded={open}
      >
        <IconHistory size={17} /><span>对话管理</span>
      </button>

      {open && !state.pendingSecurityConfirmations.length &&
        panelBox &&
        typeof document !== "undefined" &&
        createPortal(
        <>
          <div
            ref={historyRef} className="cm-history-panel" role="dialog" aria-label="历史对话列表" aria-modal="false"
            style={{
              ...styles.panel,
              position: "fixed",
              top: panelBox.top,
              left: 8,
              right: 8,
              width: "auto",
              maxHeight: Math.min(panelMaxHeight, panelBox.maxHeight),
              zIndex: 10050,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>对话管理</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
            <div className="cm-thread-management-header" style={styles.panelHeader}>
              <div className="cm-thread-management-views" style={styles.viewToggle}>
                <button
                  type="button"
                  style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("time")}
                >
                  时间
                </button>
                <button
                  type="button"
                  style={view === "tags" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("tags")}
                >
                  标签
                </button>
                <button
                  type="button"
                  style={view === "topics" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("topics")}
                >
                  手动分组
                </button>
                <button type="button" style={view === "ai" ? styles.viewBtnActive : styles.viewBtn} onClick={() => setView("ai")}>AI 分组</button>
              </div>
              <div style={{ display: "flex", gap: 6, flexShrink: 0, alignItems: "center" }}>
                <button
                  type="button"
                  style={selectMode ? styles.selectBtnActive : styles.selectBtn}
                  onClick={() => {
                    if (selectMode) exitSelectMode()
                    else {
                      setSelectMode(true)
                      setSelected(new Set())
                    }
                  }}
                  title="多选"
                >
                  {selectMode ? "取消选择" : "选择"}
                </button>
                <button
                  type="button"
                  style={styles.selectBtn}
                  disabled={selectableIds.size === 0}
                  onClick={() =>
                    allSelectableSelected(selected, selectableIds)
                      ? handleClearVisibleSelection()
                      : handleSelectAllVisible()
                  }
                  title="全选当前列表中可删除的会话"
                >
                  {allSelectableSelected(selected, selectableIds) ? "取消全选" : "全选"}
                </button>
                <button style={styles.newBtn} onClick={handleNewThread} title="新建线程">
                  + 新建
                </button>
                <div style={{ position: "relative" }}>
                  <button
                    ref={menuBtnRef}
                    type="button"
                    style={styles.menuBtn}
                    onClick={() => setMenuOpen((v) => !v)}
                    title="更多"
                    aria-haspopup="menu"
                    aria-expanded={menuOpen}
                  >
                    ⋯
                  </button>
                  {menuOpen &&
                    menuPos &&
                    typeof document !== "undefined" &&
                    createPortal(
                      <div
                        style={{
                          ...styles.menuPortal,
                          top: menuPos.top,
                          right: menuPos.right,
                          maxHeight: Math.max(0, panelBox.top + panelBox.maxHeight - menuPos.top),
                          overflowY: "auto",
                        }}
                        ref={historyMenuRef} role="menu"
                      >
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={handleGenerateTitle}
                        >
                          ✨ AI 生成标题
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() => handleBatchAutoTitle()}
                        >
                          📝 未命名→首条起名
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={handleCleanupEmpty}
                        >
                          🧹 清理空白
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() => {
                            setCleanupOpen(true)
                            setMenuOpen(false)
                            runCleanupScan()
                          }}
                        >
                          🗂 整理助手
                        </button>
                        <button
                          type="button"
                          style={{
                            ...styles.menuItem,
                            opacity: untaggedExtract.ids.length === 0 ? 0.45 : 1,
                            cursor:
                              untaggedExtract.ids.length === 0
                                ? "not-allowed"
                                : "pointer",
                          }}
                          disabled={untaggedExtract.ids.length === 0}
                          onClick={handleExtractUntagged}
                          title={
                            untaggedExtract.ids.length === 0
                              ? "没有可提取的未标注会话"
                              : `为最多 ${untaggedExtract.ids.length} 个未标注会话提取要点`
                          }
                        >
                          🏷 为未标注提取要点
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={openThreadGraph}
                          title="在新标签页打开会话关系图"
                        >
                          会话关系图
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() =>
                            trashView ? closeTrashView() : openTrashView()
                          }
                        >
                          {trashView ? "← 返回列表" : "🗑 回收站"}
                        </button>
                      </div>,
                      document.body,
                    )}
                </div>
              </div>
            </div>

            <div className="cm-thread-management-actions" aria-label="对话整理工具">
              <button type="button" onClick={handleExtractUntagged} disabled={untaggedExtract.ids.length === 0 || !!extractProgress}>AI 提取标签</button>
              <button type="button" onClick={() => { setCleanupOpen(true); runCleanupScan() }}>整理助手</button>
              <button type="button" onClick={openThreadGraph}>关系图谱</button>
              <button type="button" onClick={() => trashView ? closeTrashView() : openTrashView()}>{trashView ? "返回对话" : "回收站"}</button>
              <button
                type="button"
                onClick={() =>
                  (cleanupOpen && cleanupSuggestions.length > 0
                    ? cleanupSelected.size === cleanupSuggestions.length
                    : allSelectableSelected(selected, selectableIds))
                    ? handleClearVisibleSelection()
                    : handleSelectAllVisible()
                }
                disabled={cleanupOpen && cleanupSuggestions.length > 0 ? cleanupSuggestions.length === 0 : selectableIds.size === 0}
                title={cleanupOpen ? "全选整理助手扫描结果" : "全选当前列表中可删除的会话"}
              >
                {(cleanupOpen && cleanupSuggestions.length > 0
                  ? cleanupSelected.size === cleanupSuggestions.length && cleanupSuggestions.length > 0
                  : allSelectableSelected(selected, selectableIds))
                  ? "取消全选"
                  : "全选"}
              </button>
            </div>
            {cleanupOpen && (
              <div className="cm-thread-cleanup" style={styles.cleanupPanel}>
                <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 8 }}>整理助手（规则）</div>
                <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 11, color: tokens.textSecondary }}>扫描</span>
                  <select
                    value={cleanupDays}
                    onChange={(e) => setCleanupDays(Number(e.target.value))}
                    style={{ fontSize: 11, padding: "2px 4px" }}
                  >
                    <option value={0}>全部（含近期）</option>
                    <option value={30}>30 天前以前</option>
                    <option value={90}>90 天前以前</option>
                  </select>
                  <button type="button" style={styles.selectBtn} onClick={runCleanupScan}>
                    扫描
                  </button>
                  <button
                    type="button"
                    style={styles.selectBtn}
                    onClick={() => {
                      setCleanupOpen(false)
                      setCleanupSuggestions([])
                    }}
                  >
                    关闭
                  </button>
                </div>
                <div
                  style={{
                    fontSize: 10,
                    color: tokens.textMuted,
                    marginBottom: 6,
                  }}
                >
                  索引健康：未标注 {lintStats.untagged} · 过期 {lintStats.stale} · 孤立{" "}
                  {lintStats.isolated}
                </div>
                {cleanupSuggestions.length === 0 ? (
                  <div style={{ fontSize: 11, color: tokens.textMuted }}>
                    空会话 / 无用户消息 / 极短孤消息 / 过久且少 / 同名薄会话（不含簇主）
                  </div>
                ) : (
                  <>
                    <div style={{ maxHeight: 160, overflowY: "auto" }}>
                      {cleanupSuggestions.map((s) => {
                        const thr = threads.find((t) => t.id === s.thread_id)
                        const title = thr
                          ? displayThreadTitle(thr as Thread)
                          : s.thread_id
                        return (
                          <label
                            key={`${s.thread_id}-${s.reason}`}
                            style={{
                              display: "flex",
                              gap: 6,
                              alignItems: "flex-start",
                              fontSize: 11,
                              padding: "4px 0",
                              borderBottom: `1px solid ${tokens.border}`,
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={cleanupSelected.has(s.thread_id)}
                              onChange={() => {
                                setCleanupSelected((prev) => {
                                  const next = new Set(prev)
                                  if (next.has(s.thread_id)) next.delete(s.thread_id)
                                  else next.add(s.thread_id)
                                  return next
                                })
                              }}
                            />
                            <span>
                              <strong>{title}</strong>
                              <span style={{ color: tokens.textMuted }}>
                                {" "}
                                · {s.reason} · {s.detail}
                              </span>
                            </span>
                          </label>
                        )
                      })}
                    </div>
                    <div
                      style={{
                        display: "flex",
                        gap: 6,
                        marginTop: 8,
                        flexWrap: "wrap",
                      }}
                    >
                      <button
                        type="button"
                        style={styles.selectBtn}
                        disabled={cleanupSelected.size === 0}
                        onClick={applyCleanupExtractOnly}
                        title="仅提取要点/标签，不删除"
                      >
                        仅提取要点（{Math.min(cleanupSelected.size, EXTRACT_DIGEST_MAX)}）
                      </button>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        onClick={() => {
                          const ids = cleanupSuggestions.map((s) => s.thread_id).slice(0, 50)
                          setCleanupSelected(new Set(ids))
                        }}
                      >
                        全选
                      </button>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        onClick={() => setCleanupSelected(new Set())}
                      >
                        全不选
                      </button>
                      <button
                        type="button"
                        style={styles.dangerBtn}
                        disabled={cleanupSelected.size === 0}
                        onClick={applyCleanupTrash}
                      >
                        移入回收站（{cleanupSelected.size}）
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
            {pendingDelete && (
              <div
                role="alertdialog"
                aria-label="确认删除会话"
                style={styles.pendingDelete}
              >
                <p style={{ margin: 0, fontSize: 12, lineHeight: 1.5 }}>
                  {pendingDelete.hard
                    ? `永久删除 ${pendingDelete.ids.length} 个会话？不可恢复。`
                    : `将 ${pendingDelete.ids.length} 个会话移入回收站？可在回收站恢复（约 30 天后自动清理）。`}
                  {pendingDelete.source === "cleanup" &&
                  cleanupSuggestions.some(
                    (s) => pendingDelete.ids.includes(s.thread_id) && s.reason === "acp_husk",
                  )
                    ? " 含编程接力记录，请再核对。"
                    : ""}
                </p>
                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                  <button type="button" style={styles.dangerBtn} onClick={executePendingDelete}>
                    {pendingDelete.hard ? "永久删除" : "移入回收站"}
                  </button>
                  <button type="button" style={styles.selectBtn} onClick={() => setPendingDelete(null)}>
                    取消
                  </button>
                </div>
              </div>
            )}
            {view === "ai" && <p className="cm-thread-management-help">按 AI 提取的首个主题标签自动分组；重新提取可能调整 AI 分组，不改变手动分组。点击“AI 提取标签”为最多20个未标注对话提取标签。</p>}
            {view === "tags" && <p className="cm-thread-management-help">汇总人工与 AI 标签；点对话右侧“分类”管理人工标签。</p>}
            {metadataNotice && <p className="cm-thread-management-help" role="status">{metadataNotice}</p>}
            {editingThread && <ThreadMetadataEditor key={editingThread.id} thread={editingThread} folders={[...new Set(threads.map(t => t.topic_folder).filter((name): name is string => !!name))]} onClose={() => closeMetadataEditor()} onSaved={thread => { dispatch({ type: "UPSERT_THREAD", thread }); closeMetadataEditor(thread.id); setMetadataNotice("分类已保存") }} />}
            {extractProgress && extractProgress.total > 0 && (
              <div style={styles.progressBar} role="status" aria-live="polite">
                提取要点 {extractProgress.done}/{extractProgress.total}
                {extractProgress.done >= extractProgress.total ? " · 完成" : "…"}
              </div>
            )}

            {relatedSeedId && (
              <div style={styles.relatedPanel}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 4,
                  }}
                >
                  <span style={{ fontSize: 11, fontWeight: 600, color: tokens.textSecondary }}>
                    相关 · {displayThreadTitle(
                      (threads.find((x) => x.id === relatedSeedId) as Thread) || {
                        id: relatedSeedId,
                      },
                    )}
                  </span>
                  <button
                    type="button"
                    style={styles.selectBtn}
                    onClick={() => setRelatedSeedId(null)}
                  >
                    关闭
                  </button>
                </div>
                {relatedHits.length === 0 ? (
                  <div style={{ fontSize: 11, color: tokens.textSecondary }}>
                    暂无相关会话（需更多标签/要点）
                  </div>
                ) : (
                  relatedHits.map((h) => {
                    const thr = threads.find((x) => x.id === h.thread_id) as Thread | undefined
                    const title = thr ? displayThreadTitle(thr) : h.thread_id
                    return (
                      <button
                        key={h.thread_id}
                        type="button"
                        style={styles.relatedItem}
                        onClick={() => handleSelect(h.thread_id)}
                        title={
                          h.shared_tags.length
                            ? `共标签: ${h.shared_tags.join(", ")}`
                            : `score ${h.score.toFixed(2)}`
                        }
                      >
                        {title}
                        {h.shared_tags.length > 0 && (
                          <span style={{ color: tokens.textMuted, marginLeft: 4 }}>
                            #{h.shared_tags.slice(0, 2).join(" #")}
                          </span>
                        )}
                      </button>
                    )
                  })
                )}
              </div>
            )}

            {trashView && (
              <div
                style={{
                  padding: "6px 10px",
                  background: tokens.warningSoft,
                  color: tokens.warning,
                  fontSize: 11,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <span>回收站 · {filtered.length}（约 30 天后自动清理）</span>
                <button type="button" style={styles.selectBtn} onClick={closeTrashView}>
                  返回
                </button>
              </div>
            )}

            <div style={styles.searchRow}>
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="搜索标题 / 编号 / 消息 / 要点 / 标签…"
                style={styles.searchInput}
                aria-label="搜索线程"
              />
            </div>

            <div className="cm-thread-management-list" style={styles.list}>
              {view === "time" ? renderTimeline() : view === "tags" ? renderTagsView()  : renderTopicsView(view === "ai")}
            </div>

            {selectMode && (
              <div style={styles.bottomBar}>
                <span style={{ fontSize: 12, color: tokens.textSecondary }}>
                  已选 {selected.size}
                </span>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
                  <button
                    type="button"
                    style={styles.selectBtn}
                    disabled={selectableIds.size === 0}
                    onClick={() =>
                      allSelectableSelected(selected, selectableIds)
                        ? handleClearVisibleSelection()
                        : handleSelectAllVisible()
                    }
                  >
                    {allSelectableSelected(selected, selectableIds) ? "取消全选" : "全选"}
                  </button>
                  {trashView ? (
                    <button
                      type="button"
                      style={styles.selectBtn}
                      disabled={selected.size === 0}
                      onClick={() => handleRestore([...selected])}
                    >
                      恢复
                    </button>
                  ) : (
                    <>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        disabled={selected.size === 0}
                        onClick={() => {
                          handleBatchAutoTitle([...selected])
                          exitSelectMode()
                        }}
                        title="用首条消息为选中未命名会话起名"
                      >
                        起名
                      </button>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        disabled={selected.size === 0}
                        onClick={() => {
                          handleExtractDigest([...selected])
                          exitSelectMode()
                        }}
                      >
                        提取要点
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    style={styles.dangerBtn}
                    disabled={selected.size === 0}
                    onClick={handleBatchDelete}
                  >
                    {trashView ? "永久删除" : "回收站"}
                  </button>
                  <button type="button" style={styles.selectBtn} onClick={exitSelectMode}>
                    取消
                  </button>
                </div>
              </div>
            )}
          </div>

        </>,
        document.body,
      )}
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  hamburger: {
    width: 32,
    height: 32,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    background: "transparent",
    border: "none",
    borderRadius: tokens.radiusMd,
    cursor: "pointer",
    padding: 0,
    color: tokens.text,
    flexShrink: 0,
    fontFamily: tokens.font,
  },
  panel: {
    position: "fixed",
    left: 8,
    right: 8,
    width: "auto",
    maxHeight: 360,
    background: tokens.bgElevated,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: tokens.radiusMd,
    boxShadow: tokens.shadowMd,
    zIndex: 10050,
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
  },
  panelHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 10px",
    borderBottom: `1px solid ${tokens.border}`,
    gap: 6,
  },
  viewToggle: {
    display: "flex",
    gap: 2,
    background: tokens.bgMuted,
    borderRadius: 6,
    padding: 2,
  },
  viewBtn: {
    border: "none",
    background: "transparent",
    fontSize: 11,
    padding: "3px 8px",
    borderRadius: 4,
    cursor: "pointer",
    color: tokens.textSecondary,
    fontFamily: tokens.font,
  },
  viewBtnActive: {
    border: "none",
    background: tokens.bgElevated,
    fontSize: 11,
    padding: "3px 8px",
    borderRadius: 4,
    cursor: "pointer",
    color: tokens.accentText,
    fontWeight: 600,
    fontFamily: tokens.font,
    boxShadow: tokens.shadowSm,
  },
  searchRow: {
    padding: "6px 10px",
    borderBottom: `1px solid ${tokens.border}`,
  },
  searchInput: {
    width: "100%",
    boxSizing: "border-box",
    border: `1px solid ${tokens.border}`,
    borderRadius: 6,
    padding: "6px 8px",
    fontSize: 12,
    fontFamily: tokens.font,
    outline: "none",
  },
  newBtn: {
    background: tokens.accent,
    color: tokens.userBubbleText,
    border: "none",
    borderRadius: 4,
    padding: "3px 10px",
    fontSize: 11,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  selectBtn: {
    background: tokens.bgElevated,
    color: tokens.textSecondary,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: 4,
    padding: "3px 8px",
    fontSize: 11,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  selectBtnActive: {
    background: tokens.accentSoft,
    color: tokens.accentText,
    border: `1px solid ${tokens.accent}`,
    borderRadius: 4,
    padding: "3px 8px",
    fontSize: 11,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  // Phase 2b: same density as StatusRail ⋯ (popupMenuStyles)
  menuBtn: popupMenuStyles.menuTrigger,
  /** A-4 portal menu — fixed to body, above panel(51) / backdrop(50). */
  menuPortal: {
    ...popupMenuStyles.menu,
    position: "fixed" as const,
    zIndex: 10060,
  },
  menuItem: popupMenuStyles.menuItem,
  progressBar: {
    padding: "5px 10px",
    fontSize: 11,
    color: tokens.accentText,
    background: tokens.accentSoft,
    borderBottom: `1px solid ${tokens.border}`,
    fontFamily: tokens.font,
  },
  relatedPanel: {
    padding: "6px 10px",
    borderBottom: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
  },
  relatedItem: {
    display: "block",
    width: "100%",
    textAlign: "left" as const,
    background: "none",
    border: "none",
    padding: "4px 0",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: tokens.font,
    color: tokens.accentText,
  },
  tagCloudSection: {
    borderBottom: `1px solid ${tokens.border}`,
  },
  tagCloudFoldRow: {
    display: "flex",
    flexWrap: "wrap" as const,
    gap: 6,
    padding: "0 10px 8px",
  },
  untaggedCtaRow: {
    display: "flex",
    flexDirection: "column" as const,
    gap: 4,
    padding: "8px 10px",
    borderBottom: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
  },
  primaryCta: {
    background: tokens.accent,
    color: tokens.userBubbleText,
    border: "none",
    borderRadius: tokens.radiusSm,
    padding: "7px 10px",
    fontSize: 12,
    fontWeight: 600,
    cursor: "pointer",
    fontFamily: tokens.font,
    textAlign: "center" as const,
  },
  ctaHint: {
    fontSize: 10,
    color: tokens.textMuted,
    fontFamily: tokens.font,
  },
  tldr: {
    fontSize: 11,
    color: tokens.textSecondary,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap" as const,
    marginTop: 2,
    lineHeight: 1.35,
    fontFamily: tokens.font,
  },
  list: {
    overflowY: "auto",
    flex: 1,
  },
  groupHeader: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    padding: "6px 10px",
    background: tokens.bgMuted,
    borderBottom: `1px solid ${tokens.border}`,
    cursor: "pointer",
    userSelect: "none",
  },
  groupChevron: {
    fontSize: 9,
    color: tokens.textMuted,
    width: 12,
    flexShrink: 0,
  },
  groupLabel: {
    fontSize: 12,
    fontWeight: 600,
    color: tokens.textSecondary,
  },
  threadItem: {
    padding: "8px 12px",
    borderBottom: `1px solid ${tokens.border}`,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: 8,
    userSelect: "text",
    WebkitUserSelect: "text",
  },
  checkbox: {
    flexShrink: 0,
    width: 14,
    height: 14,
    cursor: "pointer",
  },
  iconBtn: {
    background: "none",
    border: "none",
    fontSize: 12,
    cursor: "pointer",
    padding: "2px 4px",
    opacity: 0.5,
    flexShrink: 0,
  },
  threadAliasRow: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    minWidth: 0,
  },
  threadAlias: {
    fontSize: 13,
    fontWeight: 500,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  /** Always-visible short id; click copies bare id for search. */
  threadIdBadge: {
    flexShrink: 0,
    border: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    padding: "1px 5px",
    margin: 0,
    fontSize: 10,
    fontWeight: 600,
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
    color: tokens.textSecondary,
    cursor: "pointer",
    lineHeight: 1.2,
    maxWidth: 88,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap" as const,
    borderRadius: tokens.radiusPill,
  },
  badge: {
    fontSize: 9,
    fontWeight: 600,
    color: tokens.accentText,
    background: tokens.accentSoft,
    borderRadius: 3,
    padding: "1px 4px",
    flexShrink: 0,
    textTransform: "uppercase" as const,
  },
  badgeMuted: {
    fontSize: 9,
    fontWeight: 500,
    color: tokens.textMuted,
    background: tokens.bgMuted,
    borderRadius: 3,
    padding: "1px 4px",
    flexShrink: 0,
  },
  tagRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: 4,
    marginTop: 3,
  },
  tagCloud: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
    padding: "8px 10px",
    // border lives on tagCloudSection so fold row stays outside any clip
  },
  tagPill: {
    border: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    borderRadius: 999,
    padding: "2px 8px",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: tokens.font,
  },
  tagPillActive: {
    border: `1px solid ${tokens.accent}`,
    background: tokens.accentSoft,
    color: tokens.accentText,
    borderRadius: 999,
    padding: "2px 8px",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: tokens.font,
    fontWeight: 600,
  },
  preview: {
    fontSize: 11,
    color: tokens.textMuted,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    marginTop: 2,
  },
  relTime: {
    fontSize: 10,
    color: tokens.textMuted,
    marginTop: 2,
  },
  pendingDelete: {
    display: "flex",
    flexWrap: "wrap",
    gap: 8,
    alignItems: "center",
    justifyContent: "space-between",
    padding: "10px 12px",
    background: tokens.warningSoft,
    borderBottom: `1px solid ${tokens.border}`,
    color: tokens.text,
    position: "sticky",
    top: 0,
    zIndex: 6,
    flexShrink: 0,
  },
  bottomBar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 10px",
    borderTop: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    gap: 8,
  },
  dangerBtn: {
    background: tokens.danger,
    color: tokens.userBubbleText,
    border: "none",
    borderRadius: 4,
    padding: "4px 10px",
    fontSize: 11,
    cursor: "pointer",
  },
  cleanupPanel: {
    borderBottom: `1px solid ${tokens.border}`,
    padding: "10px 12px",
    background: tokens.bgMuted,
    maxHeight: "min(42%, 280px)",
    overflowY: "auto",
    flexShrink: 0,
  },
}

FULL FILE chrome-extension/src/sidepanel/ui/workspace-styles.ts
import { tokens } from "./tokens"

/** Scoped shell styles; colors remain owned by tokens.ts. */
export const workspaceCSS = `
.cm-workspace{display:flex;height:100dvh;min-height:0;width:100%;overflow:hidden;background:${tokens.bg};font-family:${tokens.font};color:${tokens.text}}
.cm-workspace-main{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;position:relative}
.cm-navigation{width:220px;height:100%;box-sizing:border-box;flex-shrink:0;display:flex;flex-direction:column;padding:20px 12px 12px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};gap:6px;overflow-y:auto}
[aria-label="工作区导航"] .cm-navigation{width:100%}
.cm-nav-brand{display:flex;align-items:center;gap:10px;padding:0 8px 20px;font-size:15px;letter-spacing:-.03em}
.cm-nav-brand .cm-icon-button{margin-left:auto}
.cm-nav-new,.cm-nav-item,.cm-nav-thread{font:inherit;border:0;border-radius:${tokens.radiusMd}px;cursor:pointer;display:flex;align-items:center;gap:10px;text-align:left;min-height:36px;width:100%;padding:8px 10px;color:${tokens.text};background:transparent;font-size:13px;flex-shrink:0}
.cm-nav-new{background:${tokens.bgElevated};border:1px solid ${tokens.border};margin-bottom:10px;font-weight:500}
.cm-nav-item:hover,.cm-nav-thread:hover,.cm-icon-button:hover{background:${tokens.bgHover}}
.cm-nav-tools{flex:none;border-top:1px solid ${tokens.border};margin-top:8px}.cm-nav-tools summary{cursor:pointer;min-height:36px;padding:10px 4px;font-size:12px}.cm-nav-tools summary:focus-visible{outline:2px solid currentColor;outline-offset:2px}
.cm-nav-resources{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-bottom:16px}
.cm-nav-resources .cm-nav-item{font-size:12px;gap:6px;padding:8px 6px;min-width:0}
.cm-nav-resources .cm-nav-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cm-nav-section{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:${tokens.textSecondary};padding:0 8px}
.cm-nav-search{box-sizing:border-box;width:100%;border:1px solid ${tokens.border};border-radius:${tokens.radiusMd}px;padding:9px 10px;font:inherit;font-size:12px;background:${tokens.bgElevated};color:${tokens.text}}
.cm-nav-threads{flex:1;min-height:80px;overflow-y:auto;margin-top:4px}
.cm-nav-thread{min-height:38px;color:${tokens.textSecondary}}
.cm-nav-thread>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.cm-nav-item[aria-current="true"],.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
.cm-nav-running{color:${tokens.success};font-size:20px}
.cm-nav-empty{font-size:12px;color:${tokens.textSecondary};padding:8px}
.cm-nav-settings{margin-top:12px;border-top:1px solid ${tokens.border};border-radius:0;padding-top:14px}
.cm-icon-button{display:inline-flex;align-items:center;justify-content:center;min-width:32px;min-height:32px;border:0;background:transparent;color:${tokens.textSecondary};border-radius:${tokens.radiusMd}px;cursor:pointer;font-size:18px}
.cm-task-title{font-size:13px;font-weight:500;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-left:8px}
.cm-chat-content,.cm-composer-dock{width:100%;max-width:780px;margin-left:auto;margin-right:auto;box-sizing:border-box}
.cm-composer-dock{padding:12px 20px 18px!important}
.cm-composer-actions{display:flex;align-items:center;gap:8px;min-width:0}
.cm-composer-capsule:focus-within{border-color:${tokens.accent}!important;box-shadow:${tokens.shadowFocus}!important}
.cm-workspace button:focus-visible,.cm-workspace [role="button"]:focus-visible,.cm-workspace input:focus-visible,.cm-workspace textarea:focus-visible,[role="dialog"] button:focus-visible,[role="dialog"] input:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
.cm-workspace button:disabled{cursor:not-allowed}
.cm-settings-panel{width:min(780px,100vw - 32px)!important;max-height:88dvh!important;border-radius:${tokens.radiusSheet}px!important;box-shadow:${tokens.shadowLg}}
.cm-settings-header{padding:20px 24px!important}
.cm-settings-body{padding:8px 24px 24px!important}
.cm-context-panel{max-height:min(36dvh,360px)!important;margin:0 16px;border:1px solid ${tokens.border};border-radius:${tokens.radiusLg}px;box-shadow:${tokens.shadowSm}}
.cm-history-group{flex:1;border:0;background:transparent;color:inherit;font:inherit;text-align:left;min-height:32px;cursor:pointer;padding:4px 0}
.cm-navigation-toggle{gap:4px;flex-shrink:0}
.cm-history-panel{max-width:720px;margin:0 auto}
.cm-history-panel button:focus-visible,.cm-history-panel [role="button"]:focus-visible{outline:2px solid ${tokens.accent};outline-offset:-2px}
@media(min-width:760px){.cm-navigation-toggle{display:none!important}.cm-status-rail{padding:12px 24px!important;border-bottom:1px solid ${tokens.border}!important}.cm-chat-scroll{padding:28px 32px!important}.cm-composer-dock{padding-bottom:24px!important}}
@media(max-width:759px){.cm-workspace{flex-direction:column}.cm-navigation-disclosure{flex-shrink:0;max-height:28dvh;overflow:auto;border-bottom:1px solid ${tokens.border}}.cm-navigation-disclosure .cm-navigation{height:auto;width:100%}.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-panel{align-self:flex-end;width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-body{padding:8px 16px 16px!important}}
@media(max-height:560px){.cm-context-panel{max-height:28dvh!important}.cm-composer-dock{padding-top:4px!important;padding-bottom:6px!important}.cm-navigation{padding-top:10px}.cm-nav-brand{padding-bottom:8px}.cm-nav-resources{margin-bottom:4px}.cm-nav-new{margin-bottom:2px}}
@media(prefers-reduced-motion:reduce){.cm-workspace *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}

.cm-settings-panel{width:min(980px,100vw - 32px)!important;height:88dvh;max-height:88dvh!important}
.cm-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap;border:0}
.cm-settings-content{display:flex;flex-direction:column;flex:1;min-height:0}
.cm-settings-save-scope{font-size:11px;color:${tokens.textSecondary};line-height:1.5}
.cm-settings-panel button{min-height:36px}
.cm-settings-page-heading h3:focus-visible,.cm-settings-panel select:focus-visible,.cm-settings-panel summary:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
.cm-settings-layout{display:flex;flex:1;min-height:0;overflow:hidden}
.cm-settings-nav{box-sizing:border-box;width:172px;flex-shrink:0;padding:16px 10px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};overflow-y:auto}
.cm-settings-nav button{display:block;width:100%;min-height:40px;padding:10px 12px;margin:2px 0;border:0;border-radius:8px;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:13px;text-align:left;cursor:pointer}
.cm-settings-nav button[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:600}
.cm-settings-nav button:hover{background:${tokens.bgHover}}
.cm-settings-layout .cm-settings-body{flex:1;min-width:0;padding:20px 28px 28px!important;overflow:auto}
.cm-settings-page-heading{padding:0 0 20px;margin-bottom:16px;border-bottom:1px solid ${tokens.border}}
.cm-settings-page-title{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.cm-settings-page-heading h3{font-size:20px;font-weight:600;letter-spacing:-.03em;margin:0 0 8px}
.cm-settings-page-heading p{font-size:12px;line-height:1.7;color:${tokens.textSecondary};margin:8px 0 0}
.cm-settings-status{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 8px}
.cm-settings-status:not(:has(button)){padding:0}
.cm-settings-status button{background:${tokens.warningSoft};color:${tokens.text};border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;min-height:36px;font:inherit;font-size:12px;cursor:pointer}
.cm-settings-assistant{margin-bottom:20px;font-size:12px;color:${tokens.textSecondary}}
.cm-settings-assistant summary{cursor:pointer;min-height:36px}
.cm-settings-mobile-category{display:none}
.cm-settings-footer{flex-wrap:wrap;padding:12px 24px!important;gap:8px!important}
.cm-settings-footer button{min-height:36px}
.cm-settings-footer .cm-settings-save{background:${tokens.actionPrimary}!important}
.cm-settings-body input,.cm-settings-body select,.cm-settings-body textarea{max-width:100%;box-sizing:border-box}
@media(max-width:759px){.cm-settings-panel{height:94dvh;max-height:94dvh!important;width:100%!important}.cm-settings-layout{flex-direction:column}.cm-settings-nav{display:none}.cm-settings-mobile-category{display:flex;align-items:center;gap:12px;padding:10px 16px;background:${tokens.bgMuted};border-bottom:1px solid ${tokens.border};font-size:12px;color:${tokens.textSecondary}}.cm-settings-mobile-category select{flex:1;min-width:0;min-height:36px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;background:${tokens.bg};color:${tokens.text};font:inherit}.cm-settings-layout .cm-settings-body{padding:16px!important}.cm-settings-status{padding:0 16px 8px}.cm-settings-page-heading h3{font-size:18px}.cm-settings-footer{padding:10px 16px!important}}
.cm-settings-body input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),.cm-settings-body select{min-height:36px}

.cm-header-new{display:none;font-size:24px}
.cm-nav-manage{border:0;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:12px;padding:6px;cursor:pointer}
.cm-thread-manager-trigger{width:auto!important;gap:5px;padding:0 5px;font-size:12px;white-space:nowrap}
.cm-history-panel{display:flex!important;flex-direction:column;overflow:hidden!important;overscroll-behavior:contain}
.cm-thread-management-header{flex-wrap:wrap;flex-shrink:0}
.cm-thread-management-views{flex-wrap:wrap}
.cm-thread-management-list{flex:1;min-height:0;overflow-y:auto!important;max-height:none!important}
.cm-thread-management-actions{display:flex;gap:6px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
.cm-thread-cleanup{flex-shrink:0}
.cm-thread-management-actions button,.cm-thread-editor button{font:inherit;font-size:12px;min-height:32px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 9px;background:${tokens.bgMuted};color:${tokens.text};cursor:pointer}
.cm-thread-management-actions button:disabled,.cm-thread-editor button:disabled{opacity:.5;cursor:not-allowed}
.cm-thread-management-help{font-size:12px;line-height:1.6;color:${tokens.textSecondary};padding:0 12px}
.cm-thread-editor{padding:16px;display:flex;flex-direction:column;gap:10px;border-bottom:1px solid ${tokens.border};background:${tokens.bgMuted}}
.cm-thread-editor label{display:flex;flex-direction:column;gap:6px;font-size:12px}.cm-thread-editor input{box-sizing:border-box;width:100%;min-width:0;border:1px solid ${tokens.border};border-radius:8px;padding:8px;font:inherit;background:${tokens.bg}}
.cm-thread-editor p{font-size:12px;line-height:1.5;margin:0;color:${tokens.textSecondary};overflow-wrap:anywhere}.cm-thread-editor [role="alert"]{color:${tokens.danger}}.cm-thread-editor-actions{display:flex;justify-content:flex-end;gap:8px}
@media(max-width:759px){.cm-header-new{display:inline-flex;flex-shrink:0}.cm-status-rail{flex-wrap:wrap}.cm-thread-manager-trigger{min-height:32px}.cm-thread-management-header{align-items:flex-start!important}}
@media(max-width:520px){.cm-thread-row{flex-wrap:wrap}.cm-thread-row:not(.cm-thread-selecting) .cm-thread-row-content{flex-basis:100%!important}.cm-rail-brand{display:none}}
.cm-thread-tag-origin{font-size:10px;opacity:.8}
`

FULL FILE chrome-extension/src/sidepanel/utils/thread-timeline.ts
import { threadTags } from "./thread-management"
// Thread History IA — calendar grouping + filter helpers (pure).
// Spec: docs/superpowers/specs/2026-08-06-thread-history-ia-product-design.md

export type AcpListMeta = {
  outcome?: "ok" | "partial" | "fail" | "cancelled"
  agent_id?: string
  goal_preview?: string
}

export type TimelineThread = {
  id: string
  user_tags?: string[]
  alias?: string
  created_at?: string
  updated_at?: string
  /** Last persisted transcript row. Human-facing recency; never `updated_at`. */
  last_message_at?: string | null
  /** First user message preview (optional, from companion list enrichment). */
  first_user_preview?: string | null
  agent_role?: "normal" | "orchestrator" | "worker" | string
  message_count?: number
  user_message_count?: number
  /** First-party ACP list meta from companion — never parsed from handback body. */
  acp_list?: AcpListMeta | null
  digest?: {
    tldr?: string
    tags?: string[]
    bullets?: string[]
    extracted_at?: string
    content_fingerprint?: string
    stale?: boolean
  } | null
}

export type DayGroup = {
  /** Local calendar day key YYYY-MM-DD */
  dayKey: string
  /** Display label e.g. 07-28 */
  label: string
  threads: TimelineThread[]
}

export type MonthGroup = {
  /** Local calendar month key YYYY-MM */
  monthKey: string
  /** Display label e.g. 2026-07 */
  label: string
  days: DayGroup[]
  /** Flat count of threads in this month */
  count: number
}

export type TimelineModel = {
  today: TimelineThread[]
  /** Local calendar yesterday (default collapsed — 2026-08-06 adversary lock) */
  yesterday: TimelineThread[]
  months: MonthGroup[]
}

/** Unified fold memory (History IA + settings-thread-compact). */
export const LS_THREAD_LIST_EXPAND = "cmspark.threadList.expand"
/** Legacy key — migrated once into LS_THREAD_LIST_EXPAND. */
export const LS_THREAD_LIST_EXPAND_MONTHS_LEGACY = "cmspark.threadList.expandMonths"

export type ThreadListExpandState = {
  months: string[]
  /** Default true when missing */
  today: boolean
  /** Default false when missing (yesterday collapsed) */
  yesterday: boolean
}

export const DEFAULT_THREAD_LIST_EXPAND: ThreadListExpandState = {
  months: [],
  today: true,
  yesterday: false,
}

export function parseThreadListExpand(raw: string | null): ThreadListExpandState {
  if (!raw) return { ...DEFAULT_THREAD_LIST_EXPAND, months: [] }
  try {
    const parsed = JSON.parse(raw)
    // Legacy: bare string[] of month keys
    if (Array.isArray(parsed)) {
      return {
        months: parsed.filter((x): x is string => typeof x === "string"),
        today: DEFAULT_THREAD_LIST_EXPAND.today,
        yesterday: DEFAULT_THREAD_LIST_EXPAND.yesterday,
      }
    }
    if (parsed && typeof parsed === "object") {
      const months = Array.isArray(parsed.months)
        ? parsed.months.filter((x: unknown): x is string => typeof x === "string")
        : []
      return {
        months,
        today: typeof parsed.today === "boolean" ? parsed.today : DEFAULT_THREAD_LIST_EXPAND.today,
        yesterday:
          typeof parsed.yesterday === "boolean"
            ? parsed.yesterday
            : DEFAULT_THREAD_LIST_EXPAND.yesterday,
      }
    }
  } catch {
    /* ignore */
  }
  return { ...DEFAULT_THREAD_LIST_EXPAND, months: [] }
}

/** Effective open state: search force-open wins when group has matches. */
export function isPinnedGroupOpen(
  key: "today" | "yesterday",
  state: ThreadListExpandState,
  opts: { searchActive: boolean; hasMatches: boolean },
): boolean {
  if (opts.searchActive && opts.hasMatches) return true
  return key === "today" ? state.today : state.yesterday
}

export function isMonthGroupOpen(
  monthKey: string,
  state: ThreadListExpandState,
  opts: { searchActive: boolean; hasMatches: boolean },
): boolean {
  if (opts.searchActive && opts.hasMatches) return true
  return state.months.includes(monthKey)
}

/** Local YYYY-MM-DD for a Date (uses local timezone, not UTC). */
export function localDayKey(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${y}-${m}-${day}`
}

/** Local YYYY-MM for a Date. */
export function localMonthKey(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, "0")
  return `${y}-${m}`
}

/** Yesterday's local calendar day key. */
export function localYesterdayKey(now: Date = new Date()): string {
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)
  return localDayKey(d)
}

function parseTs(iso: string | undefined, fallbackMs: number): Date {
  if (!iso) return new Date(fallbackMs)
  const t = Date.parse(iso)
  if (Number.isNaN(t)) return new Date(fallbackMs)
  return new Date(t)
}

/**
 * Human-facing recency: last transcript row, else created_at. Never `updated_at`
 * (digest / run_progress / budget must not impersonate "recent").
 */
export function threadRecency(t: {
  last_message_at?: string | null
  created_at?: string
}): string {
  const last = typeof t.last_message_at === "string" ? t.last_message_at.trim() : ""
  if (last) return last
  return typeof t.created_at === "string" ? t.created_at : ""
}

/**
 * Screen-reader name: (preview || alias) AND short id — never one without the other
 * when both exist. Duplicate `cruise-wl` rows stay distinguishable.
 */
export function threadAccessibleName(t: TimelineThread): string {
  const preview = (t.first_user_preview || "").trim()
  const alias = (t.alias || "").trim()
  const left = preview || alias
  const shortId = String(t.id || "").trim().replace(/^#/, "")
  if (left && shortId) return `${left} · #${shortId}`
  if (left) return left
  if (shortId) return `#${shortId}`
  return displayThreadTitle(t)
}

/**
 * Group threads for the default Timeline view.
 * - "今天": local calendar day of `now`, by last_message_at || created_at desc
 * - "昨天": previous local calendar day (P0.5)
 * - History: month → day (threadRecency), months newest-first, days newest-first
 */
export function groupThreadsByCalendar(
  threads: TimelineThread[],
  now: Date = new Date(),
): TimelineModel {
  const todayKey = localDayKey(now)
  const yesterdayKey = localYesterdayKey(now)
  const nowMs = now.getTime()

  const sorted = [...threads].sort((a, b) => {
    const ta = parseTs(threadRecency(a), 0).getTime()
    const tb = parseTs(threadRecency(b), 0).getTime()
    return tb - ta
  })

  const today: TimelineThread[] = []
  const yesterday: TimelineThread[] = []
  const monthMap = new Map<string, Map<string, TimelineThread[]>>()

  for (const t of sorted) {
    const d = parseTs(threadRecency(t), nowMs)
    const dayKey = localDayKey(d)
    if (dayKey === todayKey) {
      today.push(t)
      continue
    }
    if (dayKey === yesterdayKey) {
      yesterday.push(t)
      continue
    }
    const monthKey = localMonthKey(d)
    let days = monthMap.get(monthKey)
    if (!days) {
      days = new Map()
      monthMap.set(monthKey, days)
    }
    const list = days.get(dayKey) || []
    list.push(t)
    days.set(dayKey, list)
  }

  const months: MonthGroup[] = [...monthMap.entries()]
    .sort((a, b) => (a[0] < b[0] ? 1 : a[0] > b[0] ? -1 : 0))
    .map(([monthKey, daysMap]) => {
      const days: DayGroup[] = [...daysMap.entries()]
        .sort((a, b) => (a[0] < b[0] ? 1 : a[0] > b[0] ? -1 : 0))
        .map(([dayKey, dayThreads]) => ({
          dayKey,
          label: dayKey.slice(5), // MM-DD
          threads: dayThreads,
        }))
      const count = days.reduce((n, d) => n + d.threads.length, 0)
      return { monthKey, label: monthKey, days, count }
    })

  return { today, yesterday, months }
}

/** Collect all thread ids under a month (for group-header multi-select). */
export function threadIdsInMonth(month: MonthGroup): string[] {
  return month.days.flatMap((d) => d.threads.map((t) => t.id))
}

export function threadIdsInDay(day: DayGroup): string[] {
  return day.threads.map((t) => t.id)
}

/**
 * P0 local search: alias + id + first_user_preview + tags + digest tldr/bullets.
 * Empty query returns all. Leading `#` on id queries is stripped for convenience.
 */
export function filterThreadsByQuery(
  threads: TimelineThread[],
  query: string,
): TimelineThread[] {
  const raw = query.trim().toLowerCase()
  if (!raw) return threads
  const q = raw.startsWith("#") ? raw.slice(1) : raw
  if (!q) return threads
  return threads.filter((t) => {
    const alias = (t.alias || "").toLowerCase()
    const id = (t.id || "").toLowerCase()
    const preview = (t.first_user_preview || "").toLowerCase()
    const tags = threadTags(t).join(" ").toLowerCase()
    const tldr = (t.digest?.tldr || "").toLowerCase()
    const bullets = (t.digest?.bullets || []).join(" ").toLowerCase()
    const goal = (t.acp_list?.goal_preview || "").toLowerCase()
    return (
      alias.includes(q) ||
      id.includes(q) ||
      preview.includes(q) ||
      tags.includes(q) ||
      tldr.includes(q) ||
      bullets.includes(q) ||
      goal.includes(q)
    )
  })
}

/** List / copy badge: always `#id` (empty id → empty string). */
export function formatThreadIdBadge(id: string | null | undefined): string {
  const s = String(id ?? "").trim()
  if (!s) return ""
  return s.startsWith("#") ? s : `#${s}`
}

/** Relative Chinese time for list rows. */
export function formatRelativeTime(iso: string | undefined, now: Date = new Date()): string {
  if (!iso) return ""
  const t = Date.parse(iso)
  if (Number.isNaN(t)) return ""
  const diff = Math.max(0, now.getTime() - t)
  const sec = Math.floor(diff / 1000)
  if (sec < 60) return "刚刚"
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min}分钟前`
  const hr = Math.floor(min / 60)
  if (hr < 24) return `${hr}小时前`
  const day = Math.floor(hr / 24)
  if (day < 30) return `${day}天前`
  const month = Math.floor(day / 30)
  if (month < 12) return `${month}个月前`
  return `${Math.floor(month / 12)}年前`
}

export function displayThreadTitle(t: TimelineThread): string {
  const alias = (t.alias || "").trim()
  const id = String(t.id || "").trim()
  if (alias && alias !== id && alias !== `#${id}`) return alias
  // Missing enrichment (old companion) → keep 「未命名」, do not guess.
  if (t.message_count === 0) return "空会话"
  if (t.acp_list) return "编程接力"
  if (typeof t.user_message_count === "number" && t.user_message_count === 0 && (t.message_count ?? 0) > 0) {
    return "无用户消息"
  }
  const preview = (t.first_user_preview || "").trim()
  if (preview) {
    const fromUser = aliasFromFirstUserText(preview, 24)
    if (fromUser) return fromUser
  }
  return "未命名"
}

export function acpOutcomeChip(t: TimelineThread): "完成" | "部分" | "失败" | null {
  const o = t.acp_list?.outcome
  if (o === "ok") return "完成"
  if (o === "partial") return "部分"
  if (o === "fail" || o === "cancelled") return "失败"
  return null
}

/** One evidence line: tldr > unused preview > goal / first-party ACP template. */
export function displayThreadEvidence(t: TimelineThread): string | null {
  const tldr = displayDigestTldr(t)
  if (tldr) return tldr
  const preview = (t.first_user_preview || "").trim()
  const title = displayThreadTitle(t)
  if (preview && preview !== title && !title.startsWith(preview.slice(0, 8))) {
    return preview
  }
  const goal = (t.acp_list?.goal_preview || "").replace(/\s+/g, " ").trim()
  if (goal) return goal.length > 40 ? goal.slice(0, 40).trimEnd() + "…" : goal
  if (t.acp_list) {
    const chip = acpOutcomeChip(t)
    const agent = (t.acp_list.agent_id || "").trim()
    if (agent && chip) return `编程接力 · ${agent} · ${chip}`
    if (chip) return `编程接力 · ${chip}`
  }
  return preview && preview !== title ? preview : null
}

export function formatClockTime(iso: string | undefined, now: Date = new Date()): string {
  if (!iso) return ""
  const t = Date.parse(iso)
  if (Number.isNaN(t)) return ""
  const d = new Date(t)
  const hh = String(d.getHours()).padStart(2, "0")
  const mm = String(d.getMinutes()).padStart(2, "0")
  if (localDayKey(d) === localDayKey(now)) return `今天 ${hh}:${mm}`
  const mo = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  return `${mo}-${day} ${hh}:${mm}`
}

export function formatThreadListTime(
  t: TimelineThread,
  now: Date,
  aliasDupCount: Map<string, number>,
): string {
  const alias = (t.alias || "").trim()
  const iso = threadRecency(t)
  if (alias && (aliasDupCount.get(alias) || 0) >= 2) {
    return formatClockTime(iso, now)
  }
  return formatRelativeTime(iso, now)
}

export function countAliases(threads: TimelineThread[]): Map<string, number> {
  const m = new Map<string, number>()
  for (const t of threads) {
    const a = (t.alias || "").trim()
    if (!a) continue
    m.set(a, (m.get(a) || 0) + 1)
  }
  return m
}

/**
 * Rule-based title from first user message (P0.5 — no LLM).
 * Collapse whitespace, strip leading markdown noise, cap length.
 */
export function aliasFromFirstUserText(text: string, maxLen = 40): string {
  let s = String(text || "")
    .replace(/\s+/g, " ")
    .trim()
  // strip common chat prefixes
  s = s.replace(/^(请|帮我|麻烦|请问)[，,\s]*/u, "")
  if (!s) return ""
  if (s.length > maxLen) {
    // prefer break at punctuation/space near end
    const cut = s.slice(0, maxLen)
    const m = cut.match(/^(.+?)[\s，。、；;,.!?…]+[^\s，。、；;,.!?…]*$/)
    s = (m?.[1] || cut).trim()
    if (s.length < 8) s = cut.trim()
    if (!s.endsWith("…") && text.trim().length > s.length) s += "…"
  }
  return s.slice(0, maxLen + 1)
}

export function roleBadge(role: string | undefined): string | null {
  if (role === "worker") return "worker"
  if (role === "orchestrator") return "orch"
  return null
}

/** Checkbox tri-state for group headers. */
export type CheckState = "none" | "some" | "all"

export function selectionState(ids: string[], selected: Set<string>): CheckState {
  if (ids.length === 0) return "none"
  let n = 0
  for (const id of ids) if (selected.has(id)) n++
  if (n === 0) return "none"
  if (n === ids.length) return "all"
  return "some"
}

export function toggleGroupSelection(
  ids: string[],
  selected: Set<string>,
  /** When true, only these ids may be selected (e.g. non-busy). */
  selectable?: Set<string> | null,
): Set<string> {
  const eligible = selectable
    ? ids.filter((id) => selectable.has(id))
    : ids
  const next = new Set(selected)
  const state = selectionState(eligible, selected)
  if (state === "all") {
    for (const id of eligible) next.delete(id)
  } else {
    for (const id of eligible) next.add(id)
  }
  return next
}

/** Select-all / clear-all for the currently visible selectable set. */
export function toggleSelectAll(
  selected: Set<string>,
  selectableIds: Iterable<string>,
): Set<string> {
  return toggleGroupSelection([...selectableIds], selected)
}

/** Idempotent 全选 — never toggle. Safe under Strict Mode double-updaters. */
export function selectAllIds(selectableIds: Iterable<string>): Set<string> {
  return new Set(selectableIds)
}

export function allSelectableSelected(
  selected: Set<string>,
  selectableIds: Iterable<string>,
): boolean {
  const ids = [...selectableIds]
  return ids.length > 0 && selectionState(ids, selected) === "all"
}

/** Build tag → threadIds index for Tags view (P1). */
export function buildTagIndex(
  threads: TimelineThread[],
): Map<string, TimelineThread[]> {
  const map = new Map<string, TimelineThread[]>()
  for (const t of threads) {
    const tags = threadTags(t)
    if (!tags || tags.length === 0) {
      const list = map.get("__untagged__") || []
      list.push(t)
      map.set("__untagged__", list)
      continue
    }
    for (const tag of tags) {
      const k = tag.toLowerCase()
      const list = map.get(k) || []
      list.push(t)
      map.set(k, list)
    }
  }
  return map
}

// ─── Wave A: untagged batch extract helpers (GAP-11..15 / S1–S5) ───────────

/** Max threads per extract_digest request (companion hard cap). */
export const EXTRACT_DIGEST_MAX = 20

/** Tag cloud: show this many pills before 「更多」 fold (A-5). Count-fold only — no height clip. */
export const TAG_CLOUD_MAX_VISIBLE = 16

/**
 * Untagged for batch extract (S1/GAP-11):
 * `!digest || tags.length === 0`. Non-empty non-stale tags are out of batch.
 * (Stale-with-tags is not "untagged" — leave for per-row / multi-select.)
 */
export function isUntaggedForExtract(t: TimelineThread): boolean {
  if (!t.digest) return true
  const tags = t.digest.tags
  return !tags || tags.length === 0
}

/**
 * Empty-tags digests must re-extract with force:true (S1).
 * No-digest threads extract without force (handler has nothing to skip).
 */
export function shouldForceDigestExtract(t: TimelineThread): boolean {
  if (!t.digest) return false
  const tags = t.digest.tags
  return !tags || tags.length === 0
}

export type SelectUntaggedForExtractOpts = {
  /** Cap (default EXTRACT_DIGEST_MAX = 20). */
  max?: number
  /** Busy thread ids — skipped (S3/GAP-13). */
  busyIds?: Set<string> | Record<string, boolean | undefined>
  /**
   * Default true: exclude agent_role === "worker" (S2/GAP-12).
   * Orchestrator and normal are included.
   */
  excludeWorkers?: boolean
}

export type UntaggedExtractSelection = {
  ids: string[]
  /**
   * True when batch needs force:true.
   * Untagged batches always force when non-empty so empty-tags digests re-run (S1);
   * no-digest-only batches also send force:true (harmless on companion).
   */
  force: boolean
}

function isBusyId(
  id: string,
  busyIds?: Set<string> | Record<string, boolean | undefined>,
): boolean {
  if (!busyIds) return false
  if (busyIds instanceof Set) return busyIds.has(id)
  return !!busyIds[id]
}

/**
 * Select up to `max` untagged threads for 「为未标注提取要点」.
 * Skips busy + worker (default); force:true for any non-empty selection (S1).
 * Empty result → UI disables CTA/menu (S3); caller must not send empty batch.
 */
export function selectUntaggedForExtract(
  threads: TimelineThread[],
  opts: SelectUntaggedForExtractOpts = {},
): UntaggedExtractSelection {
  const max = opts.max ?? EXTRACT_DIGEST_MAX
  const excludeWorkers = opts.excludeWorkers !== false
  const ids: string[] = []

  for (const t of threads) {
    if (ids.length >= max) break
    if (!t?.id) continue
    if (excludeWorkers && t.agent_role === "worker") continue
    if (isBusyId(t.id, opts.busyIds)) continue
    if (!isUntaggedForExtract(t)) continue
    ids.push(t.id)
  }

  return { ids, force: ids.length > 0 }
}

/**
 * Whether a multi-select / per-row extract batch should send force:true.
 * True if any target has an empty-tags digest (S1 empty-tags path).
 */
export function batchNeedsForceExtract(
  threads: TimelineThread[],
  ids: string[],
): boolean {
  if (ids.length === 0) return false
  const byId = new Map(threads.map((t) => [t.id, t]))
  for (const id of ids) {
    const t = byId.get(id)
    if (t && shouldForceDigestExtract(t)) return true
  }
  return false
}

/** Collapse tag keys for cloud UI (A-5). */
export function collapseTagKeys(
  keys: string[],
  expanded: boolean,
  maxVisible: number = TAG_CLOUD_MAX_VISIBLE,
): { visible: string[]; hiddenCount: number } {
  if (expanded || keys.length <= maxVisible) {
    return { visible: keys, hiddenCount: 0 }
  }
  return {
    visible: keys.slice(0, maxVisible),
    hiddenCount: keys.length - maxVisible,
  }
}

/** One-line tldr for list rows (A-3); empty → null. */
export function displayDigestTldr(
  t: TimelineThread,
  maxLen = 120,
): string | null {
  const raw = (t.digest?.tldr || "").replace(/\s+/g, " ").trim()
  if (!raw) return null
  if (raw.length <= maxLen) return raw
  return raw.slice(0, maxLen).trimEnd() + "…"
}

// ─── Wave B: lazy digest quota + idle candidates ───────────────────────────

export const LS_DIGEST_QUOTA = "cmspark.threadDigest.quota"

export type DigestQuotaState = { day: string; count: number }

/** Local calendar day key for quota (YYYY-MM-DD). */
export function digestQuotaDayKey(now: Date = new Date()): string {
  return localDayKey(now)
}

export function parseDigestQuota(raw: string | null, now: Date = new Date()): DigestQuotaState {
  const day = digestQuotaDayKey(now)
  if (!raw) return { day, count: 0 }
  try {
    const o = JSON.parse(raw)
    if (o && typeof o === "object" && o.day === day && typeof o.count === "number") {
      return { day, count: Math.max(0, Math.floor(o.count)) }
    }
  } catch {
    /* ignore */
  }
  return { day, count: 0 }
}

export function remainingDigestQuota(
  state: DigestQuotaState,
  maxPerDay: number,
): number {
  const cap = Math.max(0, Math.floor(maxPerDay))
  return Math.max(0, cap - state.count)
}

/**
 * Candidates for lazy extract (Wave B-2): untagged (or empty tags) OR digest.stale,
 * idle for on_idle_hours, skip busy/worker. Cap by max.
 */
export function selectLazyDigestCandidates(
  threads: TimelineThread[],
  opts: {
    now?: Date
    onIdleHours?: number
    max?: number
    busyIds?: Set<string> | Record<string, boolean | undefined>
    excludeWorkers?: boolean
  } = {},
): UntaggedExtractSelection {
  const now = opts.now || new Date()
  const idleMs = Math.max(0, (opts.onIdleHours ?? 24) * 3600_000)
  const max = opts.max ?? EXTRACT_DIGEST_MAX
  const excludeWorkers = opts.excludeWorkers !== false
  const ids: string[] = []

  for (const t of threads) {
    if (ids.length >= max) break
    if (!t?.id) continue
    if (excludeWorkers && t.agent_role === "worker") continue
    if (isBusyId(t.id, opts.busyIds)) continue
    const updated = t.updated_at || t.created_at
    if (updated) {
      const ts = new Date(updated).getTime()
      if (Number.isFinite(ts) && now.getTime() - ts < idleMs) continue
    }
    const untagged = isUntaggedForExtract(t)
    const stale = !!t.digest?.stale
    if (!untagged && !stale) continue
    ids.push(t.id)
  }
  // Non-empty lazy batch always force:true (empty-tags / stale re-extract).
  return { ids, force: ids.length > 0 }
}

/** Show digest stale badge: tags/topics always; time view only non-today (B-3). */
export function showDigestStaleBadge(
  t: TimelineThread,
  view: "time" | "tags" | "topics" | "ai",
  now: Date = new Date(),
): boolean {
  if (!t.digest?.stale) return false
  if (view === "tags" || view === "topics") return true
  const updated = t.updated_at || t.created_at
  if (!updated) return true
  try {
    return localDayKey(new Date(updated)) !== localDayKey(now)
  } catch {
    return true
  }
}

FULL FILE chrome-extension/src/sidepanel/voice/meeting-diarize-copy.ts
/** Side Panel / tests: echo auto-selected K after meeting.diarized. */

export function formatMeetingDiarizeStatus(
  method: string | undefined | null,
  k?: number | null,
): string {
  const kPart =
    typeof k === "number" && Number.isFinite(k) && k >= 1 ? ` · K=${Math.floor(k)}` : ""
  if (method === "embedding") {
    return `已自动标匿名发言人（说话人嵌入 · 本机 · 非身份识别）${kPart}`
  }
  if (method === "text_gap") {
    return `已弱标说话人（按行交替 · 非声学）${kPart}`
  }
  return `已自动标匿名发言人（实验 · 非身份识别）${kPart}`
}

/**
 * #260 硬约束：模型未就绪必须显式引导下载，绝不静默落回旧引擎。
 * 标签只说「发言人N」——禁止任何「识别出是谁」的暗示。
 */
export function mapMeetingDiarizeError(code: string, message?: string): string {
  if (code === "embedding_model_required") {
    return "说话人分离模型未就绪：请到 设置 → 输入与语音 → 听写方式 下载「说话人分离模型」后重试（不会静默落回旧引擎）"
  }
  if (code === "diarize_runtime_unavailable") {
    return "本机推理组件不可用（onnxruntime 缺失）：请更新 Companion 后重试"
  }
  if (code === "timeout") {
    return "说话人分离超时，请重试"
  }
  if (code === "no_segments") {
    return "无音频段，无法做说话人聚类"
  }
  if (message) {
    return `说话人分离失败（${code}）：${message}`
  }
  return `说话人分离失败：${code}`
}

FULL FILE chrome-extension/tests/meeting-diarize-copy.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import {
  formatMeetingDiarizeStatus,
  mapMeetingDiarizeError,
} from "../src/sidepanel/voice/meeting-diarize-copy"

test("formatMeetingDiarizeStatus echoes K for auto audio cluster", () => {
  assert.match(formatMeetingDiarizeStatus("audio_cluster", 3), /已自动标/)
  assert.match(formatMeetingDiarizeStatus("audio_cluster", 3), /K=3/)
  assert.equal(/K=/.test(formatMeetingDiarizeStatus("audio_cluster", null)), false)
})

test("formatMeetingDiarizeStatus text_gap keeps weak-label copy and optional K", () => {
  assert.match(formatMeetingDiarizeStatus("text_gap", 2), /弱标/)
  assert.match(formatMeetingDiarizeStatus("text_gap", 2), /K=2/)
})

test("formatMeetingDiarizeStatus embedding: 说话人嵌入 · 本机 · 非身份识别 (#260)", () => {
  assert.match(formatMeetingDiarizeStatus("embedding", 3), /已自动标匿名发言人/)
  assert.match(formatMeetingDiarizeStatus("embedding", 3), /说话人嵌入 · 本机 · 非身份识别/)
  assert.match(formatMeetingDiarizeStatus("embedding", 3), /K=3/)
  assert.equal(/K=/.test(formatMeetingDiarizeStatus("embedding", null)), false)
  // 文案禁「声纹」（暗示身份识别）；用「说话人嵌入/聚类」（匿名）
  assert.equal(/声纹/.test(formatMeetingDiarizeStatus("embedding", 3)), false)
})

test("mapMeetingDiarizeError: model-missing guidance, no silent fallback (#260)", () => {
  const guidance = mapMeetingDiarizeError("embedding_model_required")
  assert.match(guidance, /设置 → 输入与语音 → 听写方式/)
  assert.match(guidance, /下载/)
  assert.match(guidance, /不会静默落回/)
  assert.equal(/识别出是谁|声纹身份|声纹/.test(guidance), false, "禁止身份识别暗示")
  assert.match(mapMeetingDiarizeError("no_segments"), /无音频段/)
})

test("mapMeetingDiarizeError: machine code + message composition", () => {
  assert.match(mapMeetingDiarizeError("seq_gap", "段序号断档"), /seq_gap/)
  assert.match(mapMeetingDiarizeError("seq_gap", "段序号断档"), /段序号断档/)
  assert.match(mapMeetingDiarizeError("timeout"), /超时/)
  assert.match(mapMeetingDiarizeError("pcm_mismatch"), /pcm_mismatch/)
})

FULL FILE chrome-extension/tests/thread-timeline.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import {
  groupThreadsByCalendar,
  filterThreadsByQuery,
  formatRelativeTime,
  formatThreadIdBadge,
  localDayKey,
  localMonthKey,
  localYesterdayKey,
  selectionState,
  toggleGroupSelection,
  toggleSelectAll,
  selectAllIds,
  allSelectableSelected,
  displayThreadTitle,
  threadAccessibleName,
  threadRecency,
  displayThreadEvidence,
  acpOutcomeChip,
  formatClockTime,
  formatThreadListTime,
  countAliases,
  threadIdsInMonth,
  aliasFromFirstUserText,
  buildTagIndex,
  parseThreadListExpand,
  DEFAULT_THREAD_LIST_EXPAND,
  isPinnedGroupOpen,
  isMonthGroupOpen,
  isUntaggedForExtract,
  shouldForceDigestExtract,
  selectUntaggedForExtract,
  batchNeedsForceExtract,
  collapseTagKeys,
  displayDigestTldr,
  EXTRACT_DIGEST_MAX,
  TAG_CLOUD_MAX_VISIBLE,
  parseDigestQuota,
  remainingDigestQuota,
  selectLazyDigestCandidates,
  showDigestStaleBadge,
  digestQuotaDayKey,
} from "../src/sidepanel/utils/thread-timeline"

/** Build ISO in local timezone for year/month/day/hour. */
function localIso(y: number, m: number, d: number, h = 12, min = 0): string {
  return new Date(y, m - 1, d, h, min, 0, 0).toISOString()
}

test("localDayKey / localMonthKey use local calendar", () => {
  const d = new Date(2026, 7, 6, 15, 30, 0) // Aug 6 2026 local
  assert.equal(localDayKey(d), "2026-08-06")
  assert.equal(localMonthKey(d), "2026-08")
})

test("localYesterdayKey is previous calendar day", () => {
  const now = new Date(2026, 7, 6, 12, 0, 0)
  assert.equal(localYesterdayKey(now), "2026-08-05")
  // month boundary
  const sep1 = new Date(2026, 8, 1, 10, 0, 0)
  assert.equal(localYesterdayKey(sep1), "2026-08-31")
})

test("groupThreadsByCalendar: today + yesterday + history month→day", () => {
  const now = new Date(2026, 7, 6, 18, 0, 0) // 2026-08-06
  const threads = [
    { id: "t1", alias: "today-a", last_message_at: localIso(2026, 8, 6, 10) },
    { id: "t2", alias: "today-b", last_message_at: localIso(2026, 8, 6, 16) },
    { id: "y1", alias: "yest", last_message_at: localIso(2026, 8, 5, 20) },
    { id: "t3", alias: "july-28", last_message_at: localIso(2026, 7, 28, 9) },
    { id: "t4", alias: "july-15", last_message_at: localIso(2026, 7, 15, 9) },
    { id: "t5", alias: "june", last_message_at: localIso(2026, 6, 1, 9) },
  ]
  const model = groupThreadsByCalendar(threads, now)
  assert.equal(model.today.length, 2)
  assert.equal(model.today[0].id, "t2")
  assert.equal(model.yesterday.length, 1)
  assert.equal(model.yesterday[0].id, "y1")
  // yesterday must NOT appear inside months
  for (const m of model.months) {
    for (const d of m.days) {
      assert.ok(!d.threads.some((t) => t.id === "y1"))
    }
  }
  assert.equal(model.months.length, 2)
  assert.equal(model.months[0].monthKey, "2026-07")
  assert.equal(model.months[0].count, 2)
  assert.deepEqual(threadIdsInMonth(model.months[0]).sort(), ["t3", "t4"])
})

test("groupThreadsByCalendar: cross-midnight boundary (local)", () => {
  const now = new Date(2026, 7, 6, 0, 30, 0)
  const threads = [
    { id: "after", last_message_at: localIso(2026, 8, 6, 0, 10) },
    { id: "before", last_message_at: localIso(2026, 8, 5, 23, 50) },
  ]
  const model = groupThreadsByCalendar(threads, now)
  assert.deepEqual(model.today.map((t) => t.id), ["after"])
  assert.deepEqual(model.yesterday.map((t) => t.id), ["before"])
  assert.equal(model.months.length, 0)
})

test("groupThreadsByCalendar: ignores updated_at (digest must not impersonate recency)", () => {
  const now = new Date(2026, 7, 6, 12, 0, 0)
  const threads = [
    {
      id: "old-created-digest-today",
      created_at: localIso(2026, 1, 1),
      updated_at: localIso(2026, 8, 6, 8),
    },
  ]
  const model = groupThreadsByCalendar(threads, now)
  assert.equal(model.today.length, 0)
  assert.equal(model.yesterday.length, 0)
  assert.ok(model.months.some((m) => m.monthKey === "2026-01"))
})

test("groupThreadsByCalendar: last_message_at wins over created_at", () => {
  const now = new Date(2026, 7, 6, 12, 0, 0)
  const threads = [
    {
      id: "old-created-messaged-today",
      created_at: localIso(2026, 1, 1),
      updated_at: localIso(2026, 8, 6, 8),
      last_message_at: localIso(2026, 8, 6, 8),
    },
  ]
  const model = groupThreadsByCalendar(threads, now)
  assert.equal(model.today.length, 1)
  assert.equal(model.yesterday.length, 0)
  assert.equal(model.months.length, 0)
})

test("I-digest: old last_message_at + new digest updated_at stays in original calendar group", () => {
  const now = new Date(2026, 8, 1, 15, 0, 0) // 2026-09-01
  const threads = [
    {
      id: "w2k8z9",
      alias: "cruise-wl",
      created_at: localIso(2026, 8, 31, 14),
      last_message_at: localIso(2026, 8, 31, 14),
      updated_at: localIso(2026, 9, 1, 14),
      digest: { tldr: "立项风险", extracted_at: localIso(2026, 9, 1, 14) },
    },
  ]
  const model = groupThreadsByCalendar(threads, now)
  assert.equal(model.today.length, 0)
  assert.equal(model.yesterday.length, 1)
  assert.equal(model.yesterday[0].id, "w2k8z9")
})

test("threadRecency: last_message_at || created_at, never updated_at", () => {
  assert.equal(
    threadRecency({ last_message_at: "2026-08-31T00:00:00.000Z", created_at: "2026-01-01T00:00:00.000Z" }),
    "2026-08-31T00:00:00.000Z",
  )
  assert.equal(
    threadRecency({ created_at: "2026-01-01T00:00:00.000Z" }),
    "2026-01-01T00:00:00.000Z",
  )
  assert.equal(threadRecency({ last_message_at: "  ", created_at: "c" }), "c")
  assert.equal(threadRecency({}), "")
})

test("formatThreadListTime uses threadRecency not updated_at", () => {
  const now = new Date(2026, 7, 6, 15, 0, 0)
  const t = {
    id: "x",
    alias: "solo",
    created_at: localIso(2026, 8, 1),
    updated_at: localIso(2026, 8, 6, 14),
    last_message_at: localIso(2026, 8, 5, 10),
  }
  // last_message_at is ~29h ago → 1天前; updated_at would have been 1小时前
  assert.match(formatThreadListTime(t, now, new Map()), /1天前/)
})

test("T-alias-1: accessible name is (preview || alias) AND #shortId", () => {
  assert.equal(
    threadAccessibleName({
      id: "w2k8z9",
      alias: "cruise-wl",
      first_user_preview: "立项风险分析",
    }),
    "立项风险分析 · #w2k8z9",
  )
  assert.equal(
    threadAccessibleName({ id: "abc123", alias: "cruise-wl" }),
    "cruise-wl · #abc123",
  )
  const both = threadAccessibleName({
    id: "w2k8z9",
    alias: "cruise-wl",
    first_user_preview: "立项风险分析",
  })
  assert.ok(both.includes("立项风险分析"))
  assert.ok(both.includes("#w2k8z9"))
  assert.ok(both.includes(" · #"))
})

test("parseThreadListExpand: defaults + legacy months array + object", () => {
  assert.deepEqual(parseThreadListExpand(null), {
    months: [],
    today: true,
    yesterday: false,
  })
  assert.deepEqual(parseThreadListExpand(JSON.stringify(["2026-07", "2026-06"])), {
    months: ["2026-07", "2026-06"],
    today: true,
    yesterday: false,
  })
  assert.deepEqual(
    parseThreadListExpand(
      JSON.stringify({ months: ["2026-07"], today: false, yesterday: true }),
    ),
    { months: ["2026-07"], today: false, yesterday: true },
  )
  assert.equal(DEFAULT_THREAD_LIST_EXPAND.today, true)
  assert.equal(DEFAULT_THREAD_LIST_EXPAND.yesterday, false)
})

test("isPinnedGroupOpen / isMonthGroupOpen: search force-expand", () => {
  const state = { months: [] as string[], today: false, yesterday: false }
  assert.equal(isPinnedGroupOpen("today", state, { searchActive: false, hasMatches: true }), false)
  assert.equal(isPinnedGroupOpen("today", state, { searchActive: true, hasMatches: true }), true)
  assert.equal(isPinnedGroupOpen("yesterday", state, { searchActive: true, hasMatches: false }), false)
  assert.equal(
    isMonthGroupOpen("2026-07", { ...state, months: ["2026-07"] }, {
      searchActive: false,
      hasMatches: false,
    }),
    true,
  )
  assert.equal(
    isMonthGroupOpen("2026-06", state, { searchActive: true, hasMatches: true }),
    true,
  )
})

test("filterThreadsByQuery: alias, id, first_user_preview, tags", () => {
  const threads = [
    { id: "abc123", alias: "竞品调研", first_user_preview: "对比三家定价", digest: { tags: ["竞品", "定价"] } },
    { id: "xyz789", alias: "", first_user_preview: "hello world" },
  ]
  assert.equal(filterThreadsByQuery(threads, "竞品").length, 1)
  assert.equal(filterThreadsByQuery(threads, "xyz").length, 1)
  assert.equal(filterThreadsByQuery(threads, "定价").length, 1)
  assert.equal(filterThreadsByQuery(threads, "nope").length, 0)
  assert.equal(filterThreadsByQuery(threads, "  ").length, 2)
})

test("filterThreadsByQuery: digest tldr and bullets", () => {
  const threads = [
    {
      id: "a1",
      alias: "会话甲",
      digest: {
        tldr: "敲定了 Q3 预算上限",
        bullets: ["采用分阶段上线", "保留本地 Whisper"],
        tags: ["预算"],
      },
    },
    {
      id: "b2",
      alias: "会话乙",
      first_user_preview: "无关内容",
      digest: { tldr: "修 UI 间距", bullets: ["ThreadList"] },
    },
  ]
  assert.equal(filterThreadsByQuery(threads, "预算上限").length, 1)
  assert.equal(filterThreadsByQuery(threads, "Whisper").length, 1)
  assert.equal(filterThreadsByQuery(threads, "分阶段").length, 1)
  assert.equal(filterThreadsByQuery(threads, "ThreadList").length, 1)
  assert.equal(filterThreadsByQuery(threads, "不存在的词").length, 0)
  // id still works with leading #
  assert.equal(filterThreadsByQuery(threads, "#a1").length, 1)
  assert.equal(filterThreadsByQuery(threads, "a1").length, 1)
})

test("formatThreadIdBadge: always #id for list display", () => {
  assert.equal(formatThreadIdBadge("abc123"), "#abc123")
  assert.equal(formatThreadIdBadge("#xyz"), "#xyz")
  assert.equal(formatThreadIdBadge("  def  "), "#def")
  assert.equal(formatThreadIdBadge(""), "")
  assert.equal(formatThreadIdBadge(null), "")
  assert.equal(formatThreadIdBadge(undefined), "")
})

test("formatRelativeTime buckets", () => {
  const now = new Date("2026-08-06T12:00:00.000Z")
  assert.equal(formatRelativeTime(new Date(now.getTime() - 30_000).toISOString(), now), "刚刚")
  assert.equal(formatRelativeTime(new Date(now.getTime() - 5 * 60_000).toISOString(), now), "5分钟前")
  assert.equal(formatRelativeTime(new Date(now.getTime() - 3 * 3600_000).toISOString(), now), "3小时前")
  assert.equal(formatRelativeTime(new Date(now.getTime() - 2 * 86400_000).toISOString(), now), "2天前")
})

test("selectionState + toggleGroupSelection", () => {
  const ids = ["a", "b", "c"]
  assert.equal(selectionState(ids, new Set()), "none")
  assert.equal(selectionState(ids, new Set(["a"])), "some")
  assert.equal(selectionState(ids, new Set(["a", "b", "c"])), "all")

  let sel = toggleGroupSelection(ids, new Set())
  assert.deepEqual([...sel].sort(), ["a", "b", "c"])
  sel = toggleGroupSelection(ids, sel)
  assert.equal(sel.size, 0)

  sel = toggleGroupSelection(ids, new Set(), new Set(["a", "b"]))
  assert.deepEqual([...sel].sort(), ["a", "b"])
})

test("toggleSelectAll kept for group toggling; toolbar 全选 uses selectAllIds", () => {
  const selectable = ["a", "b", "c"]
  assert.equal(allSelectableSelected(new Set(), selectable), false)
  let sel = toggleSelectAll(new Set(), selectable)
  assert.deepEqual([...sel].sort(), ["a", "b", "c"])
  assert.equal(allSelectableSelected(sel, selectable), true)
  sel = toggleSelectAll(sel, selectable)
  assert.equal(sel.size, 0)
  sel = toggleSelectAll(new Set(["z"]), ["a", "b"])
  assert.deepEqual([...sel].sort(), ["a", "b", "z"])
})

test("selectAllIds is idempotent (double click / Strict updater still all-on)", () => {
  const selectable = ["a", "b", "c"]
  const once = selectAllIds(selectable)
  const twice = selectAllIds(once)
  assert.deepEqual([...selectAllIds(selectable)].sort(), ["a", "b", "c"])
  assert.deepEqual([...selectAllIds(twice)].sort(), ["a", "b", "c"])
  assert.equal(allSelectableSelected(new Set(), []), false)
})

test("displayThreadTitle fallback", () => {
  // Id lives in list badge (formatThreadIdBadge), not inlined into title
  assert.equal(displayThreadTitle({ id: "abcdefgh", alias: "  " }), "未命名")
  assert.equal(displayThreadTitle({ id: "x", alias: "Hello" }), "Hello")
})

test("displayThreadTitle hygiene ladder (P-B1)", () => {
  assert.equal(displayThreadTitle({ id: "2b8ckp", alias: "", message_count: 0 }), "空会话")
  assert.equal(
    displayThreadTitle({
      id: "rny77t",
      alias: "",
      message_count: 2,
      user_message_count: 0,
      acp_list: { outcome: "fail", agent_id: "pi" },
    }),
    "编程接力",
  )
  assert.equal(
    displayThreadTitle({
      id: "4j6l6f",
      alias: "p1-wl",
      message_count: 1,
      user_message_count: 0,
      acp_list: { outcome: "fail", agent_id: "pi" },
    }),
    "p1-wl",
  )
  assert.equal(
    displayThreadTitle({
      id: "x",
      alias: "",
      message_count: 2,
      user_message_count: 0,
    }),
    "无用户消息",
  )
  assert.ok(!/未命名\s*·/.test(displayThreadTitle({ id: "rny77t", alias: "" })))
})

test("acpOutcomeChip + evidence never inlines handback body", () => {
  const t = {
    id: "rny77t",
    alias: "",
    message_count: 2,
    user_message_count: 0,
    acp_list: { outcome: "fail" as const, agent_id: "pi" },
  }
  assert.equal(acpOutcomeChip(t), "失败")
  const ev = displayThreadEvidence(t)
  assert.equal(ev, "编程接力 · pi · 失败")
  assert.ok(!String(ev).includes("No API key"))
})

test("duplicate alias uses clock time", () => {
  const now = new Date(2026, 7, 17, 15, 0, 0)
  const threads = [
    { id: "a", alias: "p1-wl", last_message_at: new Date(2026, 7, 17, 14, 32).toISOString() },
    { id: "b", alias: "p1-wl", last_message_at: new Date(2026, 7, 17, 11, 8).toISOString() },
  ]
  const counts = countAliases(threads)
  assert.equal(counts.get("p1-wl"), 2)
  assert.match(formatThreadListTime(threads[0], now, counts), /今天 14:32/)
  assert.match(formatClockTime(threads[1].last_message_at, now), /今天 11:08/)
})

test("aliasFromFirstUserText strips prefixes and truncates", () => {
  assert.equal(aliasFromFirstUserText("帮我 对比三家 SaaS 定价"), "对比三家 SaaS 定价")
  const long = "请" + "这是一段很长的用户消息用来测试截断效果".repeat(5)
  const a = aliasFromFirstUserText(long, 40)
  assert.ok(a.length <= 42)
  assert.ok(a.length >= 8)
  assert.equal(aliasFromFirstUserText("   "), "")
})

test("buildTagIndex groups by tag and untagged", () => {
  const threads = [
    { id: "1", digest: { tags: ["Alpha", "beta"] } },
    { id: "2", digest: { tags: ["beta"] } },
    { id: "3", alias: "no tags" },
  ]
  const idx = buildTagIndex(threads)
  assert.equal(idx.get("alpha")?.length, 1)
  assert.equal(idx.get("beta")?.length, 2)
  assert.equal(idx.get("__untagged__")?.length, 1)
})

// ─── Wave A: untagged extract helpers (GAP-11..15 / S1–S5 / S10) ───────────

test("isUntaggedForExtract: !digest OR empty tags", () => {
  assert.equal(isUntaggedForExtract({ id: "a" }), true)
  assert.equal(isUntaggedForExtract({ id: "b", digest: null }), true)
  assert.equal(isUntaggedForExtract({ id: "c", digest: {} }), true)
  assert.equal(isUntaggedForExtract({ id: "d", digest: { tags: [] } }), true)
  assert.equal(isUntaggedForExtract({ id: "e", digest: { tags: ["x"] } }), false)
  // Stale-with-tags is NOT untagged
  assert.equal(
    isUntaggedForExtract({ id: "f", digest: { tags: ["x"], stale: true } }),
    false,
  )
})

test("shouldForceDigestExtract: only empty-tags digests need force", () => {
  assert.equal(shouldForceDigestExtract({ id: "a" }), false)
  assert.equal(shouldForceDigestExtract({ id: "b", digest: null }), false)
  assert.equal(shouldForceDigestExtract({ id: "c", digest: { tags: [] } }), true)
  assert.equal(shouldForceDigestExtract({ id: "d", digest: {} }), true)
  assert.equal(shouldForceDigestExtract({ id: "e", digest: { tags: ["ok"] } }), false)
})

test("selectUntaggedForExtract: skips busy + worker; cap 20; force true", () => {
  const threads = [
    { id: "w1", agent_role: "worker" as const },
    { id: "o1", agent_role: "orchestrator" as const },
    { id: "n1", agent_role: "normal" as const },
    { id: "busy1" },
    { id: "tagged", digest: { tags: ["alpha"] } },
    { id: "emptyTags", digest: { tags: [] as string[] } },
    { id: "n2" },
  ]
  const sel = selectUntaggedForExtract(threads, {
    busyIds: { busy1: true },
    max: EXTRACT_DIGEST_MAX,
  })
  // worker + busy + tagged out; orch/normal/emptyTags/n2 in
  assert.deepEqual(sel.ids.sort(), ["emptyTags", "n1", "n2", "o1"].sort())
  assert.equal(sel.force, true)
  assert.ok(!sel.ids.includes("w1"))
  assert.ok(!sel.ids.includes("busy1"))
  assert.ok(!sel.ids.includes("tagged"))
})

test("selectUntaggedForExtract: empty batch when nothing eligible", () => {
  const threads = [
    { id: "w1", agent_role: "worker" as const },
    { id: "t1", digest: { tags: ["x"] } },
    { id: "b1" },
  ]
  const sel = selectUntaggedForExtract(threads, { busyIds: new Set(["b1"]) })
  assert.deepEqual(sel.ids, [])
  assert.equal(sel.force, false)
})

test("selectUntaggedForExtract: respects max cap", () => {
  const threads = Array.from({ length: 30 }, (_, i) => ({ id: `t${i}` }))
  const sel = selectUntaggedForExtract(threads, { max: 20 })
  assert.equal(sel.ids.length, 20)
  assert.equal(sel.force, true)
})

test("selectUntaggedForExtract: can include workers when excludeWorkers=false", () => {
  const threads = [
    { id: "w1", agent_role: "worker" as const },
    { id: "n1" },
  ]
  const sel = selectUntaggedForExtract(threads, { excludeWorkers: false })
  assert.deepEqual(sel.ids.sort(), ["n1", "w1"].sort())
})

test("batchNeedsForceExtract: true when any empty-tags digest in selection", () => {
  const threads = [
    { id: "a", digest: { tags: ["x"] } },
    { id: "b", digest: { tags: [] as string[] } },
    { id: "c" },
  ]
  assert.equal(batchNeedsForceExtract(threads, ["a"]), false)
  assert.equal(batchNeedsForceExtract(threads, ["a", "b"]), true)
  assert.equal(batchNeedsForceExtract(threads, ["c"]), false) // no digest → no force needed
  assert.equal(batchNeedsForceExtract(threads, []), false)
})

test("collapseTagKeys: folds past maxVisible", () => {
  const keys = Array.from({ length: 20 }, (_, i) => `t${i}`)
  const folded = collapseTagKeys(keys, false, TAG_CLOUD_MAX_VISIBLE)
  assert.equal(folded.visible.length, TAG_CLOUD_MAX_VISIBLE)
  assert.equal(folded.hiddenCount, 20 - TAG_CLOUD_MAX_VISIBLE)
  const open = collapseTagKeys(keys, true, TAG_CLOUD_MAX_VISIBLE)
  assert.equal(open.visible.length, 20)
  assert.equal(open.hiddenCount, 0)
})

test("displayDigestTldr: one-line ellipsis", () => {
  assert.equal(displayDigestTldr({ id: "x" }), null)
  assert.equal(displayDigestTldr({ id: "x", digest: { tldr: "  short  " } }), "short")
  const long = "字".repeat(150)
  const out = displayDigestTldr({ id: "x", digest: { tldr: long } }, 120)
  assert.ok(out)
  assert.ok(out!.endsWith("…"))
  assert.ok(out!.length <= 121)
})

// ─── Wave B: lazy digest + stale badge ─────────────────────────────────────

test("parseDigestQuota resets on new day", () => {
  const now = new Date(2026, 7, 11, 12, 0, 0)
  const day = digestQuotaDayKey(now)
  assert.equal(parseDigestQuota(JSON.stringify({ day, count: 5 }), now).count, 5)
  assert.equal(
    parseDigestQuota(JSON.stringify({ day: "2000-01-01", count: 99 }), now).count,
    0,
  )
  assert.equal(remainingDigestQuota({ day, count: 5 }, 20), 15)
  assert.equal(remainingDigestQuota({ day, count: 20 }, 20), 0)
})

test("selectLazyDigestCandidates: idle untagged/stale, skip fresh+worker", () => {
  const now = new Date(2026, 7, 11, 12, 0, 0)
  const old = new Date(2026, 7, 9, 12, 0, 0).toISOString()
  const fresh = new Date(2026, 7, 11, 11, 0, 0).toISOString()
  const threads = [
    { id: "fresh", updated_at: fresh },
    { id: "old", updated_at: old },
    { id: "stale", updated_at: old, digest: { tags: ["x"], stale: true } },
    { id: "worker", agent_role: "worker" as const, updated_at: old },
    { id: "tagged", updated_at: old, digest: { tags: ["ok"] } },
  ]
  const sel = selectLazyDigestCandidates(threads, {
    now,
    onIdleHours: 24,
    max: 20,
  })
  assert.ok(sel.ids.includes("old"))
  assert.ok(sel.ids.includes("stale"))
  assert.ok(!sel.ids.includes("fresh"))
  assert.ok(!sel.ids.includes("worker"))
  assert.ok(!sel.ids.includes("tagged"))
  assert.equal(sel.force, true)
})

test("showDigestStaleBadge: time view only non-today", () => {
  const now = new Date(2026, 7, 11, 12, 0, 0)
  const today = new Date(2026, 7, 11, 10, 0, 0).toISOString()
  const yday = new Date(2026, 7, 10, 10, 0, 0).toISOString()
  assert.equal(
    showDigestStaleBadge({ id: "a", digest: { stale: true }, updated_at: today }, "time", now),
    false,
  )
  assert.equal(
    showDigestStaleBadge({ id: "b", digest: { stale: true }, updated_at: yday }, "time", now),
    true,
  )
  assert.equal(
    showDigestStaleBadge({ id: "c", digest: { stale: true }, updated_at: today }, "tags", now),
    true,
  )
  assert.equal(
    showDigestStaleBadge({ id: "e", digest: { stale: true }, updated_at: today }, "topics", now),
    true,
  )
  assert.equal(showDigestStaleBadge({ id: "d", digest: { tags: ["x"] } }, "tags", now), false)
})

FULL FILE companion/src/acp/jsonrpc-stdio.ts
// Minimal NDJSON JSON-RPC 2.0 over child process stdio (ACP Client half).
// Spec: https://agentclientprotocol.com — initialize / session/* / notifications.

import type { ChildProcessWithoutNullStreams } from "child_process"
import { EventEmitter } from "events"
import { killAcpChild } from "./win-spawn"

export type JsonRpcId = string | number

export type JsonRpcMessage = {
  jsonrpc: "2.0"
  id?: JsonRpcId | null
  method?: string
  params?: unknown
  result?: unknown
  error?: { code: number; message: string; data?: unknown }
}

type Pending = {
  resolve: (v: unknown) => void
  reject: (e: Error) => void
  timer: ReturnType<typeof setTimeout>
}

export class JsonRpcStdioClient extends EventEmitter {
  private nextId = 1
  private pending = new Map<string, Pending>()
  private buf = ""
  private closed = false

  constructor(private readonly child: ChildProcessWithoutNullStreams) {
    super()
    child.stdout.setEncoding("utf8")
    child.stdout.on("data", (chunk: string) => this.onData(chunk))
    child.stderr.setEncoding("utf8")
    child.stderr.on("data", (chunk: string) => {
      this.emit("stderr", chunk)
    })
    child.on("close", () => this.shutdown(new Error("process closed")))
    child.on("error", (err) => this.shutdown(err instanceof Error ? err : new Error(String(err))))
  }

  private onData(chunk: string): void {
    this.buf += chunk
    let idx: number
    while ((idx = this.buf.indexOf("\n")) >= 0) {
      const line = this.buf.slice(0, idx).trim()
      this.buf = this.buf.slice(idx + 1)
      if (!line) continue
      let msg: JsonRpcMessage
      try {
        msg = JSON.parse(line) as JsonRpcMessage
      } catch {
        // Non-JSON line — treat as log/agent text for CLI hybrids
        this.emit("raw_line", line)
        continue
      }
      this.dispatch(msg)
    }
  }

  private dispatch(msg: JsonRpcMessage): void {
    if (msg.id != null && (msg.result !== undefined || msg.error !== undefined)) {
      const key = String(msg.id)
      const p = this.pending.get(key)
      if (!p) return
      this.pending.delete(key)
      clearTimeout(p.timer)
      if (msg.error) {
        p.reject(new Error(msg.error.message || `jsonrpc error ${msg.error.code}`))
      } else {
        p.resolve(msg.result)
      }
      return
    }
    if (msg.method) {
      // Request from agent (permission) or notification
      if (msg.id != null && msg.id !== undefined) {
        this.emit("request", msg)
      } else {
        this.emit("notification", msg.method, msg.params)
      }
    }
  }

  request(method: string, params?: unknown, timeoutMs = 60_000): Promise<unknown> {
    if (this.closed) return Promise.reject(new Error("jsonrpc client closed"))
    const id = this.nextId++
    const payload: JsonRpcMessage = {
      jsonrpc: "2.0",
      id,
      method,
      params: params ?? {},
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(String(id))
        reject(new Error(`jsonrpc timeout: ${method}`))
      }, timeoutMs)
      this.pending.set(String(id), { resolve, reject, timer })
      this.write(payload)
    })
  }

  notify(method: string, params?: unknown): void {
    this.write({ jsonrpc: "2.0", method, params: params ?? {} })
  }

  respond(id: JsonRpcId, result: unknown): void {
    this.write({ jsonrpc: "2.0", id, result })
  }

  respondError(id: JsonRpcId, code: number, message: string): void {
    this.write({ jsonrpc: "2.0", id, error: { code, message } })
  }

  private write(msg: JsonRpcMessage): void {
    if (this.closed) return
    try {
      this.child.stdin.write(JSON.stringify(msg) + "\n")
    } catch (e) {
      this.emit("error", e)
    }
  }

  shutdown(err?: Error): void {
    if (this.closed) return
    this.closed = true
    for (const [k, p] of this.pending) {
      clearTimeout(p.timer)
      p.reject(err || new Error("client shutdown"))
      this.pending.delete(k)
    }
    this.emit("close", err)
  }

  kill(): void {
    try {
      killAcpChild(this.child, "SIGTERM")
    } catch {
      /* */
    }
    setTimeout(() => {
      try {
        killAcpChild(this.child, "SIGKILL")
      } catch {
        /* */
      }
    }, 1500)
    this.shutdown(new Error("killed"))
  }
}

/** Try ACP initialize handshake; returns false if peer is not JSON-RPC ACP. */
export async function tryAcpInitialize(
  client: JsonRpcStdioClient,
  timeoutMs = 4000,
): Promise<{ ok: true; result: unknown } | { ok: false; error: string }> {
  try {
    const result = await client.request(
      "initialize",
      {
        protocolVersion: 1,
        clientInfo: { name: "cmspark", version: "0.6.7" },
        capabilities: {
          fs: { readTextFile: false, writeTextFile: false },
          terminal: false,
        },
      },
      timeoutMs,
    )
    return { ok: true, result }
  } catch (e: any) {
    return { ok: false, error: e?.message || String(e) }
  }
}

FULL FILE companion/src/cli-version.ts
import * as fs from "fs"
import * as path from "path"

/** Fallback must stay lock-step with companion/package.json (test-package-gates). */
export const CLI_VERSION_FALLBACK = "0.6.7"

export function resolveCliVersion(): string {
  const candidates = [
    path.join(__dirname, "..", "package.json"),
    path.join(__dirname, "..", "..", "package.json"),
  ]
  for (const pkgPath of candidates) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8")) as { version?: unknown }
      if (typeof pkg.version === "string" && pkg.version.trim()) return pkg.version.trim()
    } catch {
      /* try next layout (dist/ vs .test-dist/src/) */
    }
  }
  return CLI_VERSION_FALLBACK
}

FULL FILE companion/src/index.ts
#!/usr/bin/env node
// cmspark-agent CLI entry point

import { startServer } from "./server"
import { installFatalHandlers } from "./crash-handlers"
import { initDataDir, getLockFilePath, getPidFilePath, getConfig } from "./config"
import { getSwiftTrayPath, getTrayBuildScript, getTrayCwd } from "./paths"
import {
  acquireLock,
  releaseLock,
  isProcessRunning,
  isDaemonRunning,
  readPidFile,
  writePidFile,
  cleanupPidFile,
  daemonize,
} from "./daemon"
import { startMenuBarAgent } from "./menu-bar-agent"
import { runInteractiveSettings, runNonInteractiveSettings, runNonInteractiveSettingsCli } from "./settings-cli"
import { getPlatform } from "./platform"
import { applyHardenedProcessPath } from "./process-path"
import { resolveCliVersion } from "./cli-version"
import * as fs from "fs"
import * as path from "path"
import * as child_process from "child_process"

// Earliest possible PATH fix for tray/daemon/settings entrypoints (before any spawn).
// Packaged .app has shipped with PATH=…/cmspark-agent.js → bare tools fail ENOTDIR.
applyHardenedProcessPath()

function printUsage(): void {
  console.log(`cmspark-agent v${resolveCliVersion()}

Usage:
  cmspark-agent --version                  打印版本并退出
  cmspark-agent start                      启动 Companion 服务器（前台）
  cmspark-agent stop                       停止 Companion 服务器（同 daemon stop）
  cmspark-agent status                     查看服务器状态（同 daemon status）

  cmspark-agent daemon start [--daemonize]  启动守护进程
  cmspark-agent daemon stop                停止守护进程
  cmspark-agent daemon status              查看守护进程状态
  cmspark-agent daemon logs                查看守护进程日志

  cmspark-agent settings                   打开 Web 设置面板（浏览器）
  cmspark-agent settings --set key=value   非交互式修改配置

  cmspark-agent settings-ui                打开 Web 设置面板
  cmspark-agent settings-cli               打开终端交互式设置（旧版）

  cmspark-agent tray                       启动系统托盘（推荐）
  cmspark-agent tray status                查看托盘后端信息
  cmspark-agent tray rebuild               重新编译 Swift 托盘（macOS）

  cmspark-agent menu-bar                   启动菜单栏（已弃用，请使用 tray）

  cmspark-agent mcp-outbound               启动 Outbound MCP stdio 服务（非 default-on；编程 Agent 对接）

  cmspark-agent outbound-grant issue --caller-id <id> [--label <name>] [--profile outbound_l1_default|outbound_l1_interact|outbound_context_v1] [--context-config file.json] [--allow-page-export] [--ttl-ms N]
                                           签发租手钥匙（一次性 token；不是扩展配对码）
  cmspark-agent outbound-grant revoke --grant-id <id>
                                           撤销租手钥匙
  cmspark-agent outbound-grant list        列出已签发的租手钥匙（不含 token）`)
}

// ---------------------------------------------------------------------------
// Tray sub-commands
// ---------------------------------------------------------------------------

/** #406 — the WS port the companion actually binds (config.port, default 23401). */
function wsPortForDisplay(): number {
  try {
    const p = Number(getConfig().port)
    if (Number.isFinite(p) && p > 0 && p <= 65535) return Math.trunc(p)
  } catch {
    /* config.json corrupt/unreadable — fall back */
  }
  return 23401
}

async function handleTrayStatus(): Promise<void> {
  const { detectTrayBackend } = await import("./tray/tray-adapter")
  const backend = detectTrayBackend()
  const platform = getPlatform()

  console.log("CMspark 托盘状态:")
  console.log(`  平台: ${platform} (${process.arch})`)
  console.log(`  托盘后端: ${backend}`)

  const pid = readPidFile(getPidFilePath())
  console.log(`  Companion: ${pid && isProcessRunning(pid) ? "运行中" : "已停止"}`)
  console.log(`  WebSocket: ws://127.0.0.1:${wsPortForDisplay()}`)

  if (platform === "darwin" && process.arch === "arm64") {
    const swiftBin = getSwiftTrayPath()
    console.log(`  Swift 托盘: ${fs.existsSync(swiftBin) ? "可用" : "未编译"}`)
  }

  process.exit(0)
}

async function handleTrayRebuild(): Promise<void> {
  if (process.platform !== "darwin") {
    console.error("[cmspark-agent] Swift 托盘仅支持 macOS")
    process.exit(1)
  }

  const buildScript = getTrayBuildScript()
  if (!fs.existsSync(buildScript)) {
    console.error(`[cmspark-agent] 编译脚本不存在: ${buildScript}`)
    process.exit(1)
  }

  console.log("[cmspark-agent] 重新编译 Swift 托盘...")
  try {
    child_process.execSync(`bash "${buildScript}"`, {
      cwd: getTrayCwd(),
      stdio: "inherit",
    })
    console.log("[cmspark-agent] Swift 托盘编译成功")
    process.exit(0)
  } catch {
    console.error("[cmspark-agent] Swift 托盘编译失败")
    process.exit(1)
  }
}

// ---------------------------------------------------------------------------
// Daemon commands
// ---------------------------------------------------------------------------

async function handleDaemonStart(): Promise<void> {
  const lockPath = getLockFilePath()
  const pidPath = getPidFilePath()

  // Use isDaemonRunning (not isProcessRunning): a stale daemon.pid can point at
  // a PID the OS has recycled to an unrelated process (e.g. RuntimeBroker.exe on
  // Windows). The bare PID-existence check would then falsely report "already
  // running" and refuse to start the real server.
  const existingPid = readPidFile(pidPath)
  if (existingPid && isDaemonRunning(existingPid)) {
    console.log(`[cmspark-agent] Daemon already running (pid: ${existingPid})`)
    process.exit(0)
  }

  const lockAcquired = await acquireLock(lockPath)
  if (!lockAcquired) {
    const pidFromLock = readPidFile(pidPath)
    if (pidFromLock && !isProcessRunning(pidFromLock)) {
      console.log(`[cmspark-agent] Cleaning up stale lock from dead process (pid: ${pidFromLock})`)
      cleanupPidFile(pidPath)
      releaseLock(lockPath)
      const retry = await acquireLock(lockPath)
      if (!retry) {
        console.error("[cmspark-agent] Failed to acquire lock after cleanup")
        process.exit(1)
      }
    } else {
      console.error("[cmspark-agent] Another instance is already running")
      process.exit(1)
    }
  }

  const shouldDaemonize = process.argv.includes("--daemonize")

  if (shouldDaemonize) {
    console.log("[cmspark-agent] Daemonizing...")
    // In SEA mode process.argv[0] === process.argv[1] === exe path, so
    // slice(1) would include the exe path as the first "arg", causing the
    // spawned grandchild to see the exe path as the command ("Unknown command").
    // getSelfSpawnArgs() handles both SEA and non-SEA correctly.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { getSelfSpawnArgs } = require("./paths") as typeof import("./paths")
    const { execPath, args } = getSelfSpawnArgs(["daemon", "start"])
    const grandchild = child_process.spawn(execPath, args, {
      detached: true,
      stdio: "ignore",
      windowsHide: true,
    })
    grandchild.unref()
    process.exit(0)
  }

  writePidFile(pidPath, process.pid)

  // P1 OPS-02: do NOT release UDS lock across init — race window allowed a
  // second daemon to acquire. startServer re-acquires if needed; keep hold
  // through initDataDir (best-effort). release only if startServer will
  // replace ownership via its own acquire path after we pass the same lock.
  // startServer's acquireLock is idempotent when we still hold the socket.
  await initDataDir()
  // Hand off: startServer acquires; if it fails we still release in finally paths.
  // Keep lock until startServer begins — only release if startServer fails to start.
  try {
    await startServer({ onShutdown: () => cleanupPidFile(pidPath) })
  } catch (e) {
    releaseLock(lockPath)
    throw e
  }
}

async function handleDaemonStop(): Promise<void> {
  const lockPath = getLockFilePath()
  const pidPath = getPidFilePath()
  const pid = readPidFile(pidPath)

  if (!pid) {
    console.log("[cmspark-agent] No PID file found — daemon not running")
    releaseLock(lockPath)
    process.exit(0)
  }

  if (!isProcessRunning(pid)) {
    console.log(`[cmspark-agent] Process ${pid} is not running — cleaning up stale state`)
    cleanupPidFile(pidPath)
    releaseLock(lockPath)
    process.exit(0)
  }

  console.log(`[cmspark-agent] Sending SIGTERM to process ${pid}...`)
  try {
    process.kill(pid, "SIGTERM")
  } catch (err: any) {
    console.error("[cmspark-agent] Failed to send signal:", err.message)
    process.exit(1)
  }

  const start = Date.now()
  const timeout = 10000
  while (Date.now() - start < timeout) {
    if (!isProcessRunning(pid)) {
      console.log("[cmspark-agent] Daemon stopped successfully")
      cleanupPidFile(pidPath)
      releaseLock(lockPath)
      process.exit(0)
    }
    await new Promise((r) => setTimeout(r, 200))
  }

  // SIGTERM didn't work within 10s — escalate to SIGKILL
  console.log(`[cmspark-agent] SIGTERM timed out, sending SIGKILL to process ${pid}...`)
  try {
    process.kill(pid, "SIGKILL")
  } catch (err: any) {
    console.error("[cmspark-agent] Failed to send SIGKILL:", err.message)
    process.exit(1)
  }

  // Wait up to 5 more seconds for SIGKILL to take effect
  const killStart = Date.now()
  while (Date.now() - killStart < 5000) {
    if (!isProcessRunning(pid)) {
      console.log("[cmspark-agent] Daemon killed successfully")
      cleanupPidFile(pidPath)
      releaseLock(lockPath)
      process.exit(0)
    }
    await new Promise((r) => setTimeout(r, 200))
  }

  console.error("[cmspark-agent] Daemon refused to die even after SIGKILL")
  process.exit(1)
}

async function handleDaemonStatus(): Promise<void> {
  const lockPath = getLockFilePath()
  const pidPath = getPidFilePath()
  const lockExists = fs.existsSync(lockPath)
  const pid = readPidFile(pidPath)
  const running = pid ? isProcessRunning(pid) : false

  console.log("Daemon status:")
  console.log(`  Lock file: ${lockExists ? "present" : "not present"} (${lockPath})`)
  console.log(`  PID file:  ${pid ? pid : "not present"} (${pidPath})`)
  console.log(`  Process:   ${running ? "running" : pid ? "dead (stale)" : "not running"}`)

  if (running) {
    console.log(`  WebSocket: ws://127.0.0.1:${wsPortForDisplay()}`)
  }

  process.exit(running ? 0 : 1)
}

async function handleDaemonLogs(): Promise<void> {
  const logDir = path.join(require("os").homedir(), ".cmspark-agent", "logs")
  const files = fs.readdirSync(logDir)
    .filter((f: string) => f.startsWith("companion-") && f.endsWith(".log"))
    .sort()

  if (files.length === 0) {
    console.log("[cmspark-agent] No log files found")
    process.exit(0)
  }

  const latest = path.join(logDir, files[files.length - 1])
  console.log(`[cmspark-agent] Latest log: ${latest}\n`)

  try {
    const content = fs.readFileSync(latest, "utf-8")
    const lines = content.split("\n").filter((l) => l.trim())
    const tail = lines.slice(-50)
    for (const line of tail) {
      try {
        const entry = JSON.parse(line)
        console.log(`[${entry.ts}] ${entry.level.toUpperCase().padEnd(5)} ${entry.event}`)
        if (entry.data && Object.keys(entry.data).length > 0) {
          console.log("  ", JSON.stringify(entry.data))
        }
      } catch {
        console.log(line)
      }
    }
  } catch (err: any) {
    console.error("[cmspark-agent] Failed to read logs:", err.message)
    process.exit(1)
  }

  process.exit(0)
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  const command = process.argv[2]
  const subCommand = process.argv[3]
  const subSubCommand = process.argv[4]

  switch (command) {
    case "start":
      await initDataDir()
      await startServer()
      break

    case "stop":
      await handleDaemonStop()
      break

    case "status":
      await handleDaemonStatus()
      break

    case "daemon": {
      switch (subCommand) {
        case "start":
          await handleDaemonStart()
          break
        case "stop":
          await handleDaemonStop()
          break
        case "status":
          await handleDaemonStatus()
          break
        case "logs":
          await handleDaemonLogs()
          break
        default:
          console.log("Usage: cmspark-agent daemon {start|stop|status|logs}")
          process.exit(1)
      }
      break
    }

    case "tray": {
      switch (subCommand) {
        case "status":
          await handleTrayStatus()
          break
        case "rebuild":
          await handleTrayRebuild()
          break
        default:
          await startMenuBarAgent()
      }
      break
    }

    case "mcp-outbound": {
      // ADR-022 Phase 0c: explicit opt-in stdio MCP (never auto-started by start/daemon)
      await initDataDir()
      const { runOutboundMcpStdioServer } = await import("./outbound-mcp/stdio-server")
      await runOutboundMcpStdioServer()
      break
    }

    case "outbound-grant": {
      await initDataDir()
      const { handleOutboundGrantCli } = await import("./outbound-mcp/grant-cli")
      const code = await handleOutboundGrantCli(process.argv.slice(3))
      process.exit(code)
    }

    case "settings": {
      const cliArgs = process.argv.slice(3)
      // P0-2B: read-only WS pairing secret (first-run / re-pair display). The
      // secret is generated, not user-set, so it has no place in --set.
      if (cliArgs.includes("--ws-secret")) {
        const { getSharedSecretForDisplay } = await import("./ws-auth")
        process.stdout.write(getSharedSecretForDisplay() + "\n")
        process.exit(0)
      }
      const setFlags = cliArgs.filter((a) => a.startsWith("--set="))
      const hasSetStdin = cliArgs.includes("--set-stdin")
      if (setFlags.length > 0 || hasSetStdin) {
        await runNonInteractiveSettingsCli(cliArgs)
        process.exit(0)
      }
      // Interactive mode -> Web settings page
      try {
        const { startSettingsServer } = await import("./settings-web")
        const { port, token } = await startSettingsServer()
        const url = `http://127.0.0.1:${port}/settings?token=${token}`
        const platform = getPlatform()
        if (platform === "darwin") {
          child_process.execSync(`open "${url}"`, { stdio: "ignore" })
        } else if (platform === "linux") {
          child_process.execSync(`xdg-open "${url}"`, { stdio: "ignore" })
        } else if (platform === "win32") {
          try {
            child_process.spawn("explorer", [url], { detached: true, stdio: "ignore" }).unref()
          } catch {
            child_process.execSync(`cmd /c start "" "${url}"`, { stdio: "ignore" })
          }
        }
        console.log(`Settings page opened: ${url}`)
        console.log("Press Ctrl+C to stop the server")
        await new Promise(() => {})
      } catch (err: any) {
        console.error(`Failed to open web settings: ${err.message}`)
        console.log("Falling back to CLI settings...")
        await runInteractiveSettings()
        process.exit(0)
      }
      break
    }

    case "settings-ui":
    case "settings-web": {
      const { startSettingsServer } = await import("./settings-web")
      const port = await startSettingsServer()
      const url = `http://127.0.0.1:${port}/settings`
      const platform = getPlatform()
      if (platform === "darwin") {
        child_process.execSync(`open "${url}"`, { stdio: "ignore" })
      } else if (platform === "linux") {
        child_process.execSync(`xdg-open "${url}"`, { stdio: "ignore" })
      } else if (platform === "win32") {
        try {
          child_process.spawn("explorer", [url], { detached: true, stdio: "ignore" }).unref()
        } catch {
          child_process.execSync(`cmd /c start "" "${url}"`, { stdio: "ignore" })
        }
      }
      console.log(`Settings page: ${url}`)
      console.log("Press Ctrl+C to stop the server")
      await new Promise(() => {})
      break
    }

    case "settings-cli": {
      await runInteractiveSettings()
      process.exit(0)
    }

    case "menu-bar":
      console.warn("[cmspark-agent] 'menu-bar' 已弃用，请使用 'tray' 命令")
      await startMenuBarAgent()
      break

    case "--help":
    case "-h":
      printUsage()
      process.exit(0)

    case "--version":
    case "-V":
    case "version":
      console.log(`cmspark-agent v${resolveCliVersion()}`)
      process.exit(0)

    case undefined:
      // In SEA (packaged exe): double-click → start tray directly
      // In dev mode: show CLI usage
      try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const sea = require("node:sea") as { isSea?: () => boolean } | null
        if (sea?.isSea?.()) {
          await startMenuBarAgent()
          break
        }
      } catch { /* not in SEA mode */ }
      printUsage()
      process.exit(0)

    default:
      console.error(`Unknown command: ${command}`)
      printUsage()
      process.exit(1)
  }
}

// Install process-global fatal handlers (crash log + exit(1)) before main() so
// a rejection/exception during startup is also caught. See crash-handlers.ts.
installFatalHandlers()

main().catch((e) => {
  console.error("Fatal error:", e)
  process.exit(1)
})

Large file companion/src/llm/adapter.ts: changed hunks included above; full file omitted. Do not infer unseen behavior.

FULL FILE companion/src/meeting/diarize-embed.ts
/**
 * #260 — speaker-embedding runtime for diarize (ONNX, local-only inference).
 * Pipeline per segment: fbank (80-dim log-mel, pure TS) → utterance CMN →
 * onnxruntime-node → 192-dim embedding. Audio never leaves this machine.
 *
 * Model readiness gates first: absent/incomplete model → embedding_model_required
 * (UI guides to settings download; never silently falls back to the legacy
 * 3-feature engine). Native runtime missing → diarize_runtime_unavailable.
 */

import { diarizeModelDestDir, probeDiarizeModel, DIARIZE_MODEL_ID } from "../voice/diarize-model"
import { getDiarizeModelFiles, type DiarizeManifest } from "../voice/diarize-manifest"
import { cmnOverTime, computeFbank, FBANK_NUM_BINS } from "./fbank"

export const DIARIZE_EMBEDDING_DIM = 192

export type EmbedProgress = { done: number; total: number }

export type EmbedSegmentsResult =
  | { ok: true; embeddings: number[][] }
  | { ok: false; code: "embedding_model_required" | "diarize_runtime_unavailable"; message: string }

/** Structural slice of onnxruntime-node used here (test seam friendly). */
export type OrtSessionLike = {
  inputNames: readonly string[]
  outputNames: readonly string[]
  run: (feeds: Record<string, unknown>) => Promise<Record<string, { data: ArrayLike<number> }>>
}

export type OrtLike = {
  Tensor: new (type: "float32", data: Float32Array, dims: readonly number[]) => unknown
  InferenceSession: { create: (modelPath: string) => Promise<OrtSessionLike> }
}

// --- lazy native runtime load ---------------------------------------------------

let ortCached: OrtLike | null | undefined

/** Plain require first (dev/dist node_modules), then executable-dir resolver (packaged single-file, systray2 precedent). */
export function loadOrtRuntime(): OrtLike | null {
  if (ortCached !== undefined) return ortCached
  ortCached = null
  try {
    ortCached = require("onnxruntime-node") as OrtLike
    return ortCached
  } catch {
    /* fall through */
  }
  try {
    const { createRequire } = require("node:module") as typeof import("node:module")
    const req = createRequire(process.execPath)
    ortCached = req("onnxruntime-node") as OrtLike
  } catch {
    ortCached = null
  }
  return ortCached
}

/** Test seam: drop cached ort module handle. */
export function __resetOrtCacheForTests(): void {
  ortCached = undefined
  sessionCache.clear()
}

// --- session cache ---------------------------------------------------------------

const sessionCache = new Map<string, Promise<OrtSessionLike>>()

async function getSession(modelPath: string, ort: OrtLike): Promise<OrtSessionLike> {
  const existing = sessionCache.get(modelPath)
  if (existing) return existing
  const p = ort.InferenceSession.create(modelPath)
  sessionCache.set(modelPath, p)
  try {
    return await p
  } catch (e) {
    sessionCache.delete(modelPath)
    throw e
  }
}

// --- embed ------------------------------------------------------------------------

export async function embedSegmentsForDiarize(
  pcm: Float32Array[],
  opts: {
    onProgress?: (p: EmbedProgress) => void
    /** Test seam: inject a fake onnxruntime. */
    ort?: OrtLike
    modelRootDir?: string
    manifest?: DiarizeManifest
  } = {},
): Promise<EmbedSegmentsResult> {
  const probe = probeDiarizeModel(opts.modelRootDir, opts.manifest)
  if (probe.status !== "ready") {
    return {
      ok: false,
      code: "embedding_model_required",
      message: `说话人模型未就绪（${probe.status}${probe.error ? ` · ${probe.error}` : ""}）：请到 设置 → 输入与语音 → 听写方式 下载「说话人分离模型」后重试`,
    }
  }

  const ort = opts.ort ?? loadOrtRuntime()
  if (!ort) {
    return {
      ok: false,
      code: "diarize_runtime_unavailable",
      message: "本机缺少 onnxruntime 原生运行时（onnxruntime-node），无法进行本地说话人嵌入推理",
    }
  }

  let files
  try {
    files = getDiarizeModelFiles(DIARIZE_MODEL_ID, opts.manifest)
  } catch {
    return {
      ok: false,
      code: "embedding_model_required",
      message: "说话人模型清单缺失（diarize-models.manifest.json）",
    }
  }
  const modelPath = `${diarizeModelDestDir(DIARIZE_MODEL_ID, opts.modelRootDir)}/${files[0]!.name}`

  let session: OrtSessionLike
  try {
    session = await getSession(modelPath, ort)
  } catch (e) {
    return {
      ok: false,
      code: "diarize_runtime_unavailable",
      message: `说话人模型加载失败：${e instanceof Error ? e.message : String(e)}`,
    }
  }

  const inputName = session.inputNames[0]
  const outputName = session.outputNames[0]
  if (!inputName || !outputName) {
    return {
      ok: false,
      code: "diarize_runtime_unavailable",
      message: "说话人模型输入/输出名缺失（非常规 ONNX 导出）",
    }
  }

  const embeddings: number[][] = []
  for (let i = 0; i < pcm.length; i++) {
    const seg = pcm[i] ?? new Float32Array(0)
    if (seg.length === 0) {
      embeddings.push(new Array<number>(DIARIZE_EMBEDDING_DIM).fill(0))
      opts.onProgress?.({ done: i + 1, total: pcm.length })
      continue
    }
    const rows = cmnOverTime(computeFbank(seg))
    const frames = rows.length
    const flat = new Float32Array(frames * FBANK_NUM_BINS)
    for (let f = 0; f < frames; f++) {
      flat.set(rows[f]!, f * FBANK_NUM_BINS)
    }
    let out: Record<string, { data: ArrayLike<number> }>
    try {
      out = await session.run({
        [inputName]: new ort.Tensor("float32", flat, [1, frames, FBANK_NUM_BINS]),
      })
    } catch (e) {
      return {
        ok: false,
        code: "diarize_runtime_unavailable",
        message: `说话人嵌入推理失败（段 ${i}）：${e instanceof Error ? e.message : String(e)}`,
      }
    }
    const raw = out[outputName]?.data
    if (!raw || raw.length !== DIARIZE_EMBEDDING_DIM) {
      return {
        ok: false,
        code: "diarize_runtime_unavailable",
        message: `说话人模型输出维度异常（期望 ${DIARIZE_EMBEDDING_DIM}，得到 ${raw ? raw.length : 0}）`,
      }
    }
    embeddings.push(Array.from(raw))
    opts.onProgress?.({ done: i + 1, total: pcm.length })
  }
  return { ok: true, embeddings }
}

FULL FILE companion/src/outbound-mcp/stdio-server.ts
/**
 * stdio MCP server for outbound L1 tools (ADR-022 Phase 0c).
 *
 * Not default-on: only runs when user invokes `cmspark-agent mcp-outbound`.
 * Dispatches to Companion loopback HTTP (Bearer ws_secret) when companion is up.
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js"
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js"
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js"
import {
  OUTBOUND_DISCLOSURE_ZH,
  outboundMcpWireName,
  canonicalOutboundMcpName,
  outboundToolsForProfiles,
} from "./profile"
import { invokeOutboundTool, setOutboundDispatcher } from "./bridge"
import { OUTBOUND_L1_DEFAULT_PROFILE, OUTBOUND_CONTEXT_PROFILE } from "./outbound-grants"
import {
  createHttpOutboundDispatcher,
  fetchCompanionOutboundProfile,
  type HttpClientOptions,
} from "./http-client"
import { getOrCreateSharedSecret } from "../ws-auth"
import { getConfig } from "../config"

const CALLER_ENV = "CMSPARK_OUTBOUND_CALLER_ID"
const PORT_ENV = "CMSPARK_OUTBOUND_PORT"
/** L4+ grant token (cmg_…). Required when outbound_mcp.require_grant=true. */
export const GRANT_ENV = "CMSPARK_OUTBOUND_GRANT"

const META_ACCEPT = "cmspark__accept_data_disclosure"
const META_PROFILE = "cmspark__list_outbound_profile"

/**
 * #410 — stdio tools/list per-key profile trimming. The stdio child only has
 * its env token; the grant profile lives in the companion. wire* fetches it
 * via the authenticated /outbound-mcp/v1/profile endpoint and caches it here.
 * null = not resolved yet (fallback: default profile + caller-level gate).
 *
 * #419 — lazy re-pull: when the first fetch failed because companion was not
 * up yet, tools/list / CallTool re-attempt after PROFILE_RETRY_MS (throttled,
 * bounded retries); on success the advertised set + local gate upgrade to the
 * key's real profile. Failure keeps the documented default-set degradation
 * (never widens).
 */
let resolvedProfiles: string[] | null = null
/** Loopback HTTP opts captured at wire time — used for lazy re-pull. */
let wireHttpOpts: HttpClientOptions | null = null
/** Last profile fetch attempt timestamp (ms epoch). */
let profileLastAttemptMs = 0
/** Remaining lazy retries after the initial wire attempt. */
let profileRetriesLeft = 5
const PROFILE_RETRY_MS = 30_000

type OutboundProfileFetcher = (
  opts: HttpClientOptions,
) => ReturnType<typeof fetchCompanionOutboundProfile>
let profileFetcher: OutboundProfileFetcher = fetchCompanionOutboundProfile

function callerId(): string {
  return (process.env[CALLER_ENV] || "stdio-default").trim() || "stdio-default"
}

function toolDescription(name: string): string {
  const base: Record<string, string> = {
    cmspark__list_tabs: "List open Chrome tabs (CMspark outbound L1)",
    cmspark__navigate: "Navigate a tab to a URL (may require domain confirm)",
    cmspark__get_page_text: "Read page text — data-exfil; requires prior disclosure accept",
    cmspark__click: "Click element (L1 interactive)",
    cmspark__type: "Type into focused/target element (L1)",
    cmspark__screenshot: "Screenshot — data-exfil; requires prior disclosure accept",
    cmspark__wait_for: "Wait for selector/condition",
    cmspark__downloads_find: "Find files in Downloads sandbox (read-only)",
    cmspark__site_context: "Read sanitized target, explicitly granted site knowledge and this grant/session's failure counts. Requires independent context export permission and an allowed exact origin. No chat history or evidence export.",
    // #410 interact profile (granted via --profile outbound_l1_interact)
    cmspark__scroll: "Scroll a page/tab (interact profile)",
    cmspark__get_element_info: "Inspect element metadata before acting (interact)",
    cmspark__press_key: "Press a keyboard key (interact)",
    cmspark__select_option: "Select an option in a dropdown (interact)",
    cmspark__hover: "Hover an element (interact)",
    cmspark__dblclick: "Double-click an element (interact)",
    cmspark__fill_form: "Fill a form (interact)",
    cmspark__drag_and_drop: "Drag & drop an element (interact)",
    cmspark__create_tab: "Open a new tab to a URL (URL gate, interact)",
    cmspark__get_page_html: "Read raw page DOM — data-exfil; requires prior disclosure accept (interact)",
    cmspark__analyze_image: "Send page pixels to vision model — data-exfil; requires prior disclosure accept (interact)",
    [META_ACCEPT]:
      "Caller acknowledge is not operator consent (ACK_NOT_OPERATOR). Page export requires grant --allow-page-export and Confirm Center HITL.",
    [META_PROFILE]: "List default outbound L1 tool names (curated profile)",
  }
  return base[name] || `CMspark outbound tool ${name}`
}

function openArgsSchema(): {
  type: "object"
  properties: Record<string, unknown>
  additionalProperties: boolean
} {
  return {
    type: "object",
    properties: {},
    additionalProperties: true,
  }
}

/**
 * Resolve HTTP bearer for mcp-outbound → companion loopback.
 * L4+ dual-review: when require_grant, never fall back to ws_secret.
 */
export function resolveOutboundHttpBearer(): {
  token: string
  mode: "grant" | "ws_secret"
} {
  const requireGrant = getConfig().outbound_mcp?.require_grant === true
  const grant = (process.env[GRANT_ENV] || "").trim()
  if (requireGrant) {
    if (!grant) {
      throw new Error(
        `GRANT_REQUIRED: set ${GRANT_ENV} (cmg_…) when outbound_mcp.require_grant=true — Extension ws_secret is not accepted`,
      )
    }
    return { token: grant, mode: "grant" }
  }
  if (grant) {
    return { token: grant, mode: "grant" }
  }
  return { token: getOrCreateSharedSecret(), mode: "ws_secret" }
}

/** Resolve companion loopback + secret/grant; wire HTTP dispatcher. */
export async function wireDefaultOutboundHttpDispatcher(): Promise<{
  port: number
  token_present: boolean
  auth_mode: "grant" | "ws_secret"
  profile: string
}> {
  const config = getConfig()
  const port =
    Number(process.env[PORT_ENV]) ||
    Number(config.port) ||
    23401
  const { token, mode } = resolveOutboundHttpBearer()
  const httpOpts: HttpClientOptions = {
    port,
    token,
    timeout_ms: 30_000,
  }
  setOutboundDispatcher(
    createHttpOutboundDispatcher({
      port,
      token,
      timeout_ms: 120_000,
      contextSession: () => outboundActiveProfiles().includes(OUTBOUND_CONTEXT_PROFILE),
    }),
  )
  wireHttpOpts = httpOpts
  // First attempt is awaited before the first tools/list so an interact key
  // never sees a default-only ad when companion is already up. On failure the
  // lazy retry (retryOutboundProfileIfStale) takes over — see module comment.
  profileLastAttemptMs = Date.now()
  await tryFetchOutboundProfile()
  return {
    port,
    token_present: Boolean(token),
    auth_mode: mode,
    profile: resolvedProfiles?.[0] ?? OUTBOUND_L1_DEFAULT_PROFILE,
  }
}

/** One HTTP fetch; sets resolvedProfiles on success. Returns success. */
async function tryFetchOutboundProfile(): Promise<boolean> {
  if (!wireHttpOpts) return false
  profileLastAttemptMs = Date.now()
  try {
    const p = await profileFetcher(wireHttpOpts)
    if (p.ok) {
      resolvedProfiles = [p.profile]
      profileRetriesLeft = 5
      console.error(
        `[cmspark-outbound] grant profile: ${p.profile} (${p.tools.length} canonical tools)`,
      )
      return true
    }
    console.error(
      `[cmspark-outbound] profile fetch rejected (${p.error || "unknown"}) — advertising default outbound L1 set`,
    )
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    console.error(
      `[cmspark-outbound] profile fetch failed (${msg}) — advertising default outbound L1 set`,
    )
  }
  return false
}

/**
 * #419 — lazy re-pull when still degraded (companion came up after the stdio
 * child). Throttled to one attempt per PROFILE_RETRY_MS, bounded retries.
 * Returns true when a profile is known (resolved now or earlier).
 */
export async function retryOutboundProfileIfStale(): Promise<boolean> {
  if (resolvedProfiles !== null) return true
  if (!wireHttpOpts || profileRetriesLeft <= 0) return false
  if (Date.now() - profileLastAttemptMs < PROFILE_RETRY_MS) return false
  profileRetriesLeft--
  return tryFetchOutboundProfile()
}

// --- test seams (never used in production; keep module state hermetic) ---

export function _setOutboundProfileFetcherForTests(
  fn: OutboundProfileFetcher | null,
): void {
  profileFetcher = fn ?? fetchCompanionOutboundProfile
}

export function _resetOutboundProfileRuntimeForTests(): void {
  resolvedProfiles = null
  wireHttpOpts = null
  profileLastAttemptMs = 0
  profileRetriesLeft = 5
  profileFetcher = fetchCompanionOutboundProfile
}

/** Force the next lazy re-pull to ignore the 30s cooldown (test only). */
export function _forceProfileStaleForTests(): void {
  profileLastAttemptMs = 0
}

/** Profiles currently advertising ([] = default). Visible for tests. */
export function outboundActiveProfiles(): readonly string[] {
  return resolvedProfiles ?? [OUTBOUND_L1_DEFAULT_PROFILE]
}

/** Canonical tool set granted by the resolved profile (default when unset). */
export function outboundActiveCanonicalTools(): string[] {
  return outboundToolsForProfiles(outboundActiveProfiles())
}

/** Build MCP server instance (testable without connecting transport). */
export function createOutboundMcpServer(
  profiles?: readonly string[],
): Server {
  // Explicit profiles (tests) win; else the profile resolved from the env
  // token at wire time; else default (byte-identical to pre-#410 behavior).
  if (profiles) resolvedProfiles = [...profiles]
  const server = new Server(
    { name: "cmspark-outbound", version: "0.6.7" },
    { capabilities: { tools: {} } },
  )

  // Wire names are the suffix only (`list_tabs`). Clients that qualify as
  // `server__tool` (Grok) then expose `cmspark__list_tabs`. Advertising the
  // canonical `cmspark__*` name here makes Grok emit two `__` delimiters and
  // drop every tool (session tool_count=0; `grok mcp doctor` still counts 10).
  // #419: tool set + ad are recomputed per request so a lazy profile re-pull
  // (companion came up late) upgrades tools/list without restarting the child.
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    await retryOutboundProfileIfStale()
    const grantedCanonical = outboundToolsForProfiles(outboundActiveProfiles())
    const allToolNames = [META_ACCEPT, META_PROFILE, ...grantedCanonical]
    return {
      tools: allToolNames.map((canonical) => ({
        name: outboundMcpWireName(canonical),
        description: toolDescription(canonical),
        inputSchema: canonical === "cmspark__site_context" ? {
          type: "object" as const, properties: { tabId: { type: "integer", minimum: 1 }, query: { type: "string", maxLength: 2048 } },
          required: ["tabId"], additionalProperties: false,
        } : openArgsSchema(),
      })),
    }
  })

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    // #419: lazy re-pull before the local gate so an interact key that could
    // not fetch its profile at boot (companion was down) upgrades once the
    // companion is reachable again (throttled, bounded — see module doc).
    await retryOutboundProfileIfStale()
    const name = canonicalOutboundMcpName(request.params.name)
    const args = (request.params.arguments || {}) as Record<string, unknown>
    const cid = callerId()

    if (name === META_ACCEPT) {
      if (args.acknowledge !== true) {
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify({
                ok: false,
                error_code: "ACK_REQUIRED",
                disclosure_text_zh: OUTBOUND_DISCLOSURE_ZH,
              }),
            },
          ],
          isError: true,
        }
      }
      // Caller ack is not operator HITL (Task 10 Confirm Center). Do not arm execute.
      return {
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({
              ok: false,
              error_code: "ACK_NOT_OPERATOR",
              error: "caller acknowledge is not operator consent",
              caller_id: cid,
              disclosure_text_zh: OUTBOUND_DISCLOSURE_ZH,
            }),
          },
        ],
        isError: true,
      }
    }

    if (name === META_PROFILE) {
      return {
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({ tools: outboundActiveCanonicalTools() }),
          },
        ],
      }
    }

    const granted = outboundActiveCanonicalTools()
    if (!(granted as readonly string[]).includes(name)) {
      const isDefaultOnly =
        resolvedProfiles == null ||
        (resolvedProfiles.length === 1 &&
          resolvedProfiles[0] === OUTBOUND_L1_DEFAULT_PROFILE)
      return {
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({
              ok: false,
              error_code: "PROFILE_FORBIDDEN",
              error: isDefaultOnly
                ? `tool "${name}" is not on the default outbound L1 profile`
                : `tool "${name}" is not granted on the outbound profile ${resolvedProfiles?.join("/")}`,
            }),
          },
        ],
        isError: true,
      }
    }

    const domain = typeof args.domain === "string" ? args.domain : undefined
    const toolArgs =
      args.args && typeof args.args === "object" && !Array.isArray(args.args)
        ? (args.args as Record<string, unknown>)
        : Object.fromEntries(Object.entries(args).filter(([k]) => k !== "domain"))

    const result = await invokeOutboundTool(
      {
        caller_id: cid,
        tool: name,
        args: toolArgs,
        domain,
      },
      undefined,
      // Local gate mirrors the advertised set (explicit profiles → per-key;
      // null fallback → caller-level live-grant union, i.e. pre-#410 behavior).
      resolvedProfiles ?? undefined,
    )

    return {
      content: [{ type: "text" as const, text: JSON.stringify(result) }],
      isError: !result.ok,
    }
  })

  return server
}

/** Connect stdio transport and run until stdin closes. */
export async function runOutboundMcpStdioServer(): Promise<void> {
  const wire = await wireDefaultOutboundHttpDispatcher()
  // Log to stderr only — stdout is MCP JSON-RPC
  console.error(
    `[cmspark-outbound] stdio MCP up; companion HTTP 127.0.0.1:${wire.port} (auth=${wire.auth_mode}, profile=${wire.profile})`,
  )
  const server = createOutboundMcpServer()
  const transport = new StdioServerTransport()
  await server.connect(transport)
  await new Promise<void>((resolve) => {
    process.stdin.on("end", () => resolve())
    process.stdin.on("close", () => resolve())
  })
}

FULL FILE companion/src/security/tool-persistence-redact.ts
/**
 * Redact sensitive tool params/results before durable thread JSON persistence.
 *
 * Thread JSON redaction (audit SEC-C / item 3; scope revised by #255): cookies,
 * exec-tier tools (shell, host_*, osascript, workspace_*), MCP secrets, and
 * sensitive keys (incl. passwd / Authorization) must not land in
 * ~/.cmspark-agent/threads/*.json. Read-tier tools (get_page_text /
 * get_page_html / evaluate) persist a gate-checked prefix so a reloaded thread
 * keeps the page context the model read (#255: full collapse caused reload
 * amnesia). ALL rules live in the shared module security/redact-rules.ts —
 * history/store.ts consumes the same one (golden fixtures + lock-step tests
 * pin parity). In-flight LLM tool rows stay unredacted; only
 * createToolResultMessage → addMessage (tool-role) and
 * persistAssistantDraft → addMessage (assistant tool_calls.arguments)
 * go through here.
 */
import {
  EXEC_FOLD_TOOLS,
  MCP_SENSITIVE_RESULT_RE,
  MCP_TOOL_PREFIX,
  READ_RELEASE_TOOLS,
  SENSITIVE_COOKIE_TOOLS,
  readReleaseBlocked,
  redactCodeishParams,
  redactSensitiveKeysDeep,
  releaseReadData,
  shortHash,
} from "./redact-rules"

function redactCookieData(data: unknown): unknown {
  if (Array.isArray(data)) {
    return data.map((cookie) => redactOneCookie(cookie))
  }
  if (data && typeof data === "object") {
    return redactOneCookie(data)
  }
  // Mirror history/store redactCookieSummary: blank non-object/array rather than
  // passthrough (future tool shapes must not leak raw cookie strings).
  return null
}

function redactOneCookie(cookie: unknown): unknown {
  if (!cookie || typeof cookie !== "object") return cookie
  const c = cookie as Record<string, unknown>
  const { name, domain, path: cookiePath, hostOnly, secure, httpOnly, value, ...rest } = c
  const valueStr = typeof value === "string" ? value : ""
  const restRedacted = redactSensitiveKeysDeep(
    Object.fromEntries(Object.entries(rest).filter(([k]) => k !== "value")),
  ) as Record<string, unknown>
  return {
    name,
    domain,
    path: cookiePath,
    hostOnly,
    secure,
    httpOnly,
    ...restRedacted,
    ...(valueStr
      ? { value_hash: shortHash(valueStr), value_length: valueStr.length }
      : {}),
  }
}

function redactComputerParams(params: Record<string, unknown>): Record<string, unknown> {
  const redacted: Record<string, unknown> = { ...params }
  if (typeof redacted.task === "string") {
    redacted.task = `<redacted:hash=${shortHash(redacted.task)},len=${redacted.task.length}>`
  }
  if (typeof redacted.security_token === "string") {
    redacted.security_token = `<redacted:hash=${shortHash(redacted.security_token)},len=${redacted.security_token.length}>`
  }
  if (Array.isArray(redacted.actions)) {
    redacted.actions = redacted.actions.map((a: any) => {
      if (!a || typeof a !== "object") return a
      const copy = { ...a }
      if (typeof copy.text === "string") {
        copy.text = `<redacted:hash=${shortHash(copy.text)},len=${copy.text.length}>`
      }
      return copy
    })
  }
  return redacted
}

function collapseResult(result: unknown): { success?: boolean; redacted: true; len: number; sha256: string } {
  const raw = typeof result === "string" ? result : JSON.stringify(result ?? null)
  return {
    success: typeof result === "object" && result && "success" in (result as any)
      ? Boolean((result as any).success)
      : undefined,
    redacted: true,
    len: raw.length,
    sha256: shortHash(raw),
  }
}

/**
 * Data-less error rows ({success:false, error, error_code?} — the shape of the
 * INTERRUPTED heal fillers from tool-batch-heal) carry no sensitive payload.
 * Sensitive branches below would rebuild the row without error_code (codeish) or
 * collapse away error entirely (collapseResult), destroying the INTERRUPTED
 * marker the heal/rebuild flow keys on. Reconstructs a fresh object (no extra
 * keys), else null.
 */
function plainErrorResult(
  result: unknown,
): { success: false; error: string; error_code?: string } | null {
  if (!result || typeof result !== "object") return null
  const r = result as Record<string, unknown>
  if (r.success !== false || typeof r.error !== "string") return null
  if (r.data !== undefined) return null
  // Reconstruct — never return the original object (extra keys like
  // stdout / env / stack would otherwise persist next to INTERRUPTED).
  const out: { success: false; error: string; error_code?: string } = {
    success: false,
    error: r.error,
  }
  if (typeof r.error_code === "string") out.error_code = r.error_code
  return out
}

/**
 * Returns params + result safe for durable thread JSON (and content string).
 * Non-sensitive tools pass through (params deep-key scan only for MCP).
 */
export function redactToolPayloadForPersistence(
  toolName: string,
  params: unknown,
  result: unknown,
): { params: unknown; result: unknown } {
  const name = typeof toolName === "string" ? toolName : ""
  let safeParams = params
  let safeResult = result

  if (name === "thread_recall") {
    const p = params && typeof params === "object" ? (params as Record<string, unknown>) : {}
    const q = typeof p.query === "string" ? p.query : ""
    safeParams = {
      query_len: q.length,
      ...(typeof p.max_hits === "number" ? { max_hits: p.max_hits } : {}),
      query: `<redacted:len=${q.length}:sha256=${shortHash(q)}>`,
    }
    safeResult = plainErrorResult(result) ?? collapseResult(result)
    return { params: safeParams, result: safeResult }
  }

  if (SENSITIVE_COOKIE_TOOLS.has(name)) {
    if (params && typeof params === "object") {
      const original = params as Record<string, unknown>
      const p = redactSensitiveKeysDeep({ ...original }) as Record<string, unknown>
      if (typeof original.value === "string") {
        p.value = `<redacted:hash=${shortHash(original.value)}>`
      }
      safeParams = p
    }
    // ToolExecutionResult shape: { success, data?, error? }
    if (result && typeof result === "object") {
      const r = result as Record<string, unknown>
      safeResult = {
        ...r,
        data: r.data !== undefined ? redactCookieData(r.data) : undefined,
      }
    } else {
      safeResult = collapseResult(result)
    }
    return { params: safeParams, result: safeResult }
  }

  if (name === "host_computer") {
    if (params && typeof params === "object") {
      safeParams = redactComputerParams(params as Record<string, unknown>)
    }
    safeResult = plainErrorResult(result) ?? collapseResult(result)
    return { params: safeParams, result: safeResult }
  }

  // #255 read tier: gate-checked prefix release (完整 / 截断), fail-closed
  // collapse on any gate hit (折叠).
  if (READ_RELEASE_TOOLS.has(name)) {
    // Params are ALWAYS folded (evaluate code / security_token); page read
    // tools carry only selector/tabId — deep-key scan suffices.
    if (name === "evaluate" && params && typeof params === "object") {
      safeParams = redactCodeishParams(params as Record<string, unknown>)
    } else if (params !== undefined) {
      safeParams = redactSensitiveKeysDeep(params)
    }
    if (result && typeof result === "object") {
      const plainError = plainErrorResult(result)
      if (plainError) {
        // INTERRUPTED-style row: no data payload — keep error_code + error verbatim.
        safeResult = plainError
      } else {
        const r = result as Record<string, unknown>
        const dataStr = r.data !== undefined ? JSON.stringify(r.data) : ""
        safeResult = {
          success: r.success,
          // Keep the passthrough shape: error/data keys only when present
          // (reloaded read-tier rows must deep-equal their generic-branch
          // ancestors for linkage/UI tests).
          ...(r.error !== undefined
            ? {
                error: typeof r.error === "string" && r.error.length > 200
                  ? r.error.slice(0, 200) + "…"
                  : r.error,
              }
            : {}),
          ...(r.data !== undefined
            ? {
                data: readReleaseBlocked(name, params, dataStr)
                  ? { redacted: true, len: dataStr.length, sha256: shortHash(dataStr) }
                  : releaseReadData(r.data),
              }
            : {}),
        }
      }
    }
    return { params: safeParams, result: safeResult }
  }

  if (EXEC_FOLD_TOOLS.has(name)) {
    if (params && typeof params === "object") {
      safeParams = redactCodeishParams(params as Record<string, unknown>)
    }
    // Keep success/error structure; collapse large data
    if (result && typeof result === "object") {
      const plainError = plainErrorResult(result)
      if (plainError) {
        // INTERRUPTED-style row: no data payload — keep error_code + error verbatim.
        safeResult = plainError
      } else {
        const r = result as Record<string, unknown>
        const dataStr = r.data !== undefined ? JSON.stringify(r.data) : ""
        safeResult = {
          success: r.success,
          error: typeof r.error === "string" && r.error.length > 200
            ? r.error.slice(0, 200) + "…"
            : r.error,
          // Always collapse payload for shell/host_*/workspace_* — a 200-char
          // cookie/source snippet is still a secret on disk.
          data:
            r.data !== undefined
              ? { redacted: true, len: dataStr.length, sha256: shortHash(dataStr) }
              : undefined,
        }
      }
    }
    return { params: safeParams, result: safeResult }
  }

  if (name.startsWith(MCP_TOOL_PREFIX)) {
    if (params !== undefined) {
      safeParams = redactSensitiveKeysDeep(params)
    }
    if (MCP_SENSITIVE_RESULT_RE.test(name)) {
      safeResult = plainErrorResult(result) ?? collapseResult(result)
    } else {
      safeResult = redactSensitiveKeysDeep(result)
    }
    return { params: safeParams, result: safeResult }
  }

  // Generic: deep-key scan only
  if (params !== undefined) {
    safeParams = redactSensitiveKeysDeep(params)
  }
  if (result !== undefined) {
    safeResult = redactSensitiveKeysDeep(result)
  }
  return { params: safeParams, result: safeResult }
}

/** OpenAI-shaped assistant tool_call as stored on the persisted assistant row. */
export type AssistantToolCallForPersist = {
  id: string
  type: "function"
  function: { name: string; arguments: string }
}

/**
 * Redact assistant tool_calls.arguments before durable thread JSON persist.
 * Clones; does not mutate in-flight LLM rows. Invalid JSON is replaced with a
 * stub — never stored raw (truncated streams can carry partial secrets).
 */
export function redactAssistantToolCallsForPersistence(
  toolCalls: readonly AssistantToolCallForPersist[] | null | undefined,
): AssistantToolCallForPersist[] {
  if (!Array.isArray(toolCalls) || toolCalls.length === 0) return []
  return toolCalls.map((tc) => redactOneAssistantToolCall(tc))
}

function redactOneAssistantToolCall(
  tc: AssistantToolCallForPersist,
): AssistantToolCallForPersist {
  const name = typeof tc?.function?.name === "string" ? tc.function.name : ""
  const rawArgs = typeof tc?.function?.arguments === "string" ? tc.function.arguments : ""
  let argumentsOut: string
  try {
    const params = JSON.parse(rawArgs)
    const { params: safeParams } = redactToolPayloadForPersistence(name, params, null)
    argumentsOut = JSON.stringify(safeParams === undefined ? {} : safeParams)
  } catch {
    argumentsOut = JSON.stringify({ _redacted: "invalid_json", len: rawArgs.length })
  }
  return {
    id: tc.id,
    type: tc.type ?? "function",
    function: {
      name,
      arguments: argumentsOut,
    },
  }
}

Large file companion/src/summoner-web.ts: changed hunks included above; full file omitted. Do not infer unseen behavior.

FULL FILE companion/tests/assistant-tool-args-redact.test.ts
/**
 * L4: assistant tool_calls.arguments must be redacted before threads/*.json persist.
 * persistAssistantDraft is the disk gate; in-flight LLM rows stay raw.
 */
import test, { after, before } from "node:test"
import assert from "node:assert/strict"
import * as fs from "node:fs"
import * as os from "node:os"
import * as path from "node:path"
import { redactAssistantToolCallsForPersistence } from "../src/security/tool-persistence-redact"

const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "cmspark-assistant-args-redact-"))
process.env.HOME = tempHome
process.env.CMSPARK_DATA_DIR = path.join(tempHome, ".cmspark-agent")

const ROOT = path.resolve(__dirname, "..", "..")
function srcFile(...parts: string[]): string {
  const candidates = [
    path.join(ROOT, "src", ...parts),
    path.join(__dirname, "..", "src", ...parts),
  ]
  for (const p of candidates) {
    if (fs.existsSync(p)) return p
  }
  return candidates[candidates.length - 1]
}

function call(
  name: string,
  args: string,
  id = "call_1",
): { id: string; type: "function"; function: { name: string; arguments: string } } {
  return { id, type: "function", function: { name, arguments: args } }
}

function persistedArgs(toolCalls: ReturnType<typeof redactAssistantToolCallsForPersistence>): string {
  return JSON.stringify(toolCalls)
}

let ThreadManager: typeof import("../src/threads/thread-manager").ThreadManager
let initDataDir: typeof import("../src/config").initDataDir

before(async () => {
  const config = await import("../src/config")
  initDataDir = config.initDataDir
  await initDataDir()
  ThreadManager = (await import("../src/threads/thread-manager")).ThreadManager
})

after(() => {
  try { fs.rmSync(tempHome, { recursive: true, force: true }) } catch { /* best-effort */ }
})

test("set_cookie value is folded in persisted assistant arguments", () => {
  const secret = "COOKIE_SECRET_VALUE_DO_NOT_PERSIST"
  const original = call("set_cookie", JSON.stringify({
    name: "sid",
    domain: "example.com",
    value: secret,
  }))
  const out = redactAssistantToolCallsForPersistence([original])
  const args = JSON.parse(out[0].function.arguments)
  assert.equal(out[0].id, "call_1")
  assert.equal(out[0].type, "function")
  assert.equal(out[0].function.name, "set_cookie")
  assert.equal(args.name, "sid")
  assert.equal(args.domain, "example.com")
  assert.ok(String(args.value).startsWith("<redacted:"))
  assert.ok(!persistedArgs(out).includes(secret))
  assert.equal(original.function.arguments.includes(secret), true, "in-flight row stays raw")
})

test("shell_exec command is folded in persisted assistant arguments", () => {
  const command = "cat /etc/passwd && echo SHELL_SECRET_PAYLOAD"
  const original = call("shell_exec", JSON.stringify({ command, cwd: "/tmp" }))
  const out = redactAssistantToolCallsForPersistence([original])
  const args = JSON.parse(out[0].function.arguments)
  assert.ok(String(args.command).startsWith("<redacted:"))
  assert.equal(args.cwd, "/tmp")
  assert.ok(!persistedArgs(out).includes(command))
  assert.ok(!persistedArgs(out).includes("SHELL_SECRET_PAYLOAD"))
  assert.equal(original.function.arguments.includes(command), true)
})

test("host_computer task is folded in persisted assistant arguments", () => {
  const task = "type the password hunter2 into the login form"
  const original = call("host_computer", JSON.stringify({ task, actions: [{ type: "type", text: "hunter2" }] }))
  const out = redactAssistantToolCallsForPersistence([original])
  const args = JSON.parse(out[0].function.arguments)
  assert.ok(String(args.task).startsWith("<redacted:"))
  assert.ok(!persistedArgs(out).includes(task))
  assert.ok(!persistedArgs(out).includes("hunter2"))
  assert.equal(original.function.arguments.includes("hunter2"), true)
})

test("evaluate code is folded in persisted assistant arguments", () => {
  const code = "return document.cookie"
  const original = call("evaluate", JSON.stringify({ code, tabId: 7 }))
  const out = redactAssistantToolCallsForPersistence([original])
  const args = JSON.parse(out[0].function.arguments)
  assert.ok(String(args.code).startsWith("<redacted:"))
  assert.equal(args.tabId, 7)
  assert.ok(!persistedArgs(out).includes(code))
})

test("list_tabs keeps non-secret args", () => {
  const original = call("list_tabs", JSON.stringify({ currentWindow: true, tabId: 42 }))
  const out = redactAssistantToolCallsForPersistence([original])
  const args = JSON.parse(out[0].function.arguments)
  assert.equal(args.currentWindow, true)
  assert.equal(args.tabId, 42)
  assert.equal(out[0].function.name, "list_tabs")
})

test("invalid JSON arguments are replaced with a stub, not the raw string", () => {
  const raw = '{"value":"PARTIAL_SECRET_STILL_LEAK"'
  const original = call("set_cookie", raw)
  const out = redactAssistantToolCallsForPersistence([original])
  const args = JSON.parse(out[0].function.arguments)
  assert.equal(args._redacted, "invalid_json")
  assert.equal(args.len, raw.length)
  assert.ok(!persistedArgs(out).includes("PARTIAL_SECRET_STILL_LEAK"))
  assert.equal(original.function.arguments, raw)
})

test("empty tool_calls list stays empty", () => {
  assert.deepEqual(redactAssistantToolCallsForPersistence([]), [])
  assert.deepEqual(redactAssistantToolCallsForPersistence(undefined), [])
})

test("persistAssistantDraft redacts tool_calls before addMessage", () => {
  const src = fs.readFileSync(srcFile("llm", "adapter.ts"), "utf8")
  assert.match(src, /redactAssistantToolCallsForPersistence/)
  const start = src.indexOf("function persistAssistantDraft")
  assert.ok(start >= 0, "persistAssistantDraft missing")
  const loopMark = src.indexOf("// Tool calling loop", start)
  const body = src.slice(start, loopMark > start ? loopMark : start + 1200)
  assert.match(body, /redactAssistantToolCallsForPersistence/)
  assert.match(body, /addMessage/)
  assert.ok(
    body.indexOf("redactAssistantToolCallsForPersistence") < body.indexOf("addMessage"),
    "helper must run before addMessage",
  )
  assert.ok(
    /tool_calls:\s*redactAssistantToolCallsForPersistence\(/.test(body)
      || /const\s+\w+\s*=\s*redactAssistantToolCallsForPersistence\(/.test(body),
    "addMessage payload must use helper output, not raw assistantMsg",
  )
})

test("set_cookie value does not appear in persisted thread JSON", () => {
  const secret = "COOKIE_SECRET_VALUE_DO_NOT_PERSIST"
  const tm = new ThreadManager()
  const th = tm.create("assistant-args-redact")
  tm.addMessage(th.id, {
    thread_id: th.id,
    role: "assistant",
    content: "",
    tool_calls: redactAssistantToolCallsForPersistence([
      call("set_cookie", JSON.stringify({ name: "sid", value: secret, domain: "example.com" })),
    ]),
  })
  const diskPath = path.join(process.env.CMSPARK_DATA_DIR!, "threads", `${th.id}.json`)
  const disk = fs.readFileSync(diskPath, "utf8")
  assert.ok(!disk.includes(secret), "cookie value must not persist in threads/*.json")
  const stored = JSON.parse(disk)
  const args = JSON.parse(stored.messages[0].tool_calls[0].function.arguments)
  assert.equal(args.name, "sid")
  assert.ok(String(args.value).startsWith("<redacted:"))
})

FULL FILE companion/tests/cli-version.test.ts
import assert from "node:assert/strict"
import { spawnSync } from "node:child_process"
import * as fs from "node:fs"
import * as path from "node:path"
import { describe, it } from "node:test"
import { CLI_VERSION_FALLBACK, resolveCliVersion } from "../src/cli-version"

function companionRoot(): string {
  const candidates = [
    path.join(__dirname, ".."),
    path.join(__dirname, "..", ".."),
  ]
  for (const dir of candidates) {
    const pkgPath = path.join(dir, "package.json")
    if (fs.existsSync(pkgPath)) {
      try {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8")) as { name?: string }
        if (pkg.name === "cmspark-agent") return dir
      } catch {
        /* next */
      }
    }
  }
  return path.join(__dirname, "..")
}

const ROOT = companionRoot()
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8")) as { version: string }

describe("cli version", () => {
  it("resolveCliVersion matches package.json", () => {
    assert.equal(pkg.version, "0.6.7")
    assert.equal(resolveCliVersion(), pkg.version)
    assert.equal(CLI_VERSION_FALLBACK, pkg.version)
  })

  it("--version prints one line and exits 0", () => {
    const cli = path.join(__dirname, "..", "src", "index.js")
    assert.equal(fs.existsSync(cli), true, cli)
    const r = spawnSync(process.execPath, [cli, "--version"], {
      encoding: "utf8",
      env: { ...process.env, CMSPARK_DATA_DIR: path.join(ROOT, ".test-dist", "cli-version") },
    })
    assert.equal(r.status, 0, r.stderr)
    assert.match(r.stdout, /^cmspark-agent v0\.6\.7\r?\n$/)
    assert.doesNotMatch(r.stdout, /Unknown command/)
  })
})

FULL FILE companion/tests/version-lockstep.test.ts
// Version lockstep: companion/package.json is the version SoT.
// CLI usage/--version resolve at runtime (cli-version.ts); ACP/MCP serverInfo
// and CLI_VERSION_FALLBACK stay as literals — this test guards bump misses.

import { test } from "node:test"
import assert from "node:assert/strict"
import * as fs from "fs"
import * as path from "path"

const ROOT = path.join(__dirname, "..", "..")
const VERSION: string = JSON.parse(
  fs.readFileSync(path.join(ROOT, "package.json"), "utf8"),
).version

function src(rel: string): string {
  return fs.readFileSync(path.join(ROOT, "src", rel), "utf8")
}

test("version lockstep: embedded literals match package.json", () => {
  assert.ok(VERSION, "package.json must carry a version")
  const v = VERSION.replace(/\./g, "\\.")
  // CLI banner is runtime-resolved; hardcoded `cmspark-agent vX.Y.Z` in
  // index.ts would fight --version honesty. Fallback + ACP/MCP stay literals.
  assert.match(src("index.ts"), /cmspark-agent v\$\{resolveCliVersion\(\)\}/)
  assert.match(src("cli-version.ts"), new RegExp(`CLI_VERSION_FALLBACK = "${v}"`))
  assert.match(src(path.join("acp", "jsonrpc-stdio.ts")), new RegExp(`version: "${v}"`))
  assert.match(src(path.join("outbound-mcp", "stdio-server.ts")), new RegExp(`version: "${v}"`))
})

test("version lockstep: chrome-extension package.json matches companion", () => {
  const ext = JSON.parse(
    fs.readFileSync(path.join(ROOT, "..", "chrome-extension", "package.json"), "utf8"),
  )
  assert.equal(ext.version, VERSION)
})

test("version lockstep: AGENTS.md header and footer match package.json", () => {
  const agents = fs.readFileSync(path.join(ROOT, "..", "AGENTS.md"), "utf8")
  const v = VERSION.replace(/\./g, "\\.")
  assert.match(agents, new RegExp(`> \\*\\*Version\\*\\*: ${v} `), "AGENTS.md header version line")
  assert.match(agents, new RegExp(`\\*CMspark Agent v${v}\\*`), "AGENTS.md footer")
})

FULL FILE chrome-extension/src/sidepanel/utils/thread-management.ts
type TaggedThread = { user_tags?: string[]; digest?: { tags?: string[] } | null }

export function threadTags(thread: TaggedThread): string[] {
  return [...new Set([...(thread.user_tags || []), ...(thread.digest?.tags || [])]
    .filter(tag => typeof tag === "string" && tag.trim()).map(tag => tag.trim().toLowerCase()))]
}

/** A derived AI view; never writes or overrides a user's manual folder. */
export function aiThreadGroup(thread: TaggedThread): string | null {
  return thread.digest?.tags?.find(tag => typeof tag === "string" && tag.trim())?.trim().toLowerCase() || null
}

/** Wait for the server's persisted response, not the service worker transport ACK. */
export function saveThreadMetadata(threadId: string, updates: { user_tags: string[]; topic_folder: string | null }, signal: AbortSignal): Promise<any> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(new Error("已取消等待")); return }
    const id = `thread-metadata-${crypto.randomUUID()}`
    let timer: ReturnType<typeof setTimeout>
    let settled = false
    const finish = (error?: Error, thread?: any) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      chrome.runtime.onMessage.removeListener(receive)
      signal.removeEventListener("abort", cancel)
      if (error) reject(error)
      else resolve(thread)
    }
    const cancel = () => finish(new Error("已取消等待；已发送的保存可能仍会完成"))
    const receive = (message: any) => {
      if (message?.id !== id) return
      if (message.type === "thread.updated" && message.thread?.id === threadId) {
        const actualTags = threadTags({ user_tags: message.thread.user_tags }).sort()
        const wantedTags = threadTags({ user_tags: updates.user_tags }).sort()
        if (JSON.stringify(actualTags) !== JSON.stringify(wantedTags) || (message.thread.topic_folder || null) !== updates.topic_folder) {
          finish(new Error("服务端未确认所提交的分类，请确认 Companion 已更新后重试"))
        } else finish(undefined, message.thread)
      }
      else if (message.type === "error") finish(new Error(message.error || "保存失败"))
    }
    chrome.runtime.onMessage.addListener(receive)
    signal.addEventListener("abort", cancel, { once: true })
    timer = setTimeout(() => finish(new Error("尚未收到保存确认，请检查连接后重试")), 15_000)
    chrome.runtime.sendMessage({ type: "thread.update", id, thread_id: threadId, updates, require_connected: true }).then(response => {
      if (response?.ok === false) finish(new Error(response.error || "连接不可用"))
    }).catch(error => finish(new Error(error?.message || "发送失败")))
  })
}

Your independent lens: skeptical user/deployment/cross-platform perspective, discoverability, failure states, capability claims, packaging/version/compatibility. Review now.