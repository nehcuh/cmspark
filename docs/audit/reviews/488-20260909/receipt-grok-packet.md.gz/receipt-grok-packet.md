Independent re-review for CMspark #488 after confirmed meeting persistence weakness was fixed. Review actual source, machine evidence and outcome/trajectory/component contracts; reject concrete remaining issues, distinguish verified findings from hypotheses. Existing meeting protocol already supports id=request-id plus meeting_id=owner; no backend production endpoint or permission added. New explicit Save Transcript UI uses existing set_transcript, no LLM or auto retries. Conservative T3 review of existing persistence boundary; no Surface/L2/Autonomy/Trust/Channel privilege expansion. Thread mutation product logic is unchanged from initial review and remains in scope for any unresolved claimed blocker.

DoD: close waits for each actual capture/import write's correlated response, not matching old text; correlated readback/end; same/old tail or wrong ID cannot pass; failed save preserves text and explicit Save Transcript can recover; stop then close and all navigation paths work; optional-host fallback works; successful unmount unregisters close guard; 320px row actions receive pointer; failed close retains panel. No real microphone or Windows machine is claimed. Final VERDICT: APPROVE / APPROVE_WITH_NITS / REJECT. No preface/tools.

Verified claims for independent confirmation:
- Arrow effect useEffect(() => register(...), deps) returns unregister; it was not a leaked cleanup. New UI reopens Settings after actual unmount.
- Actual companion endMeetingRecording returns session even already ended, handler returns ended every time. Current tests include stop then close.
- Whole-window/component unmount abort prevents state update to disposed UI; closing history popover does not unmount ThreadList, submitted mutation still finishes. Reopen loads thread.list. No visible stale success is asserted on destroyed app.
- Existing media max-width520 sets cm-thread-row flex-wrap; new tests hit-test and trial-click every real row action at320/390/760/1440.
- Old brand token contrast tests remain; only former mascot geometry assertions changed for authorized brand alignment.
- Dead surfaceChip styles removed; capabilityLevel prop retained solely for source compatibility. History copy corrected and separately reviewed.

CURRENT DIFF selected receipt/UI files vs947532a8
 .../scripts/render-meeting-close-fixture.cjs       |  37 ++
 chrome-extension/scripts/test-meeting-close-ui.py  | 190 ++++++++++
 .../scripts/test-thread-mutations-ui.py            | 158 ++++++++
 .../src/sidepanel/components/ComposeDrawer.tsx     |  39 +-
 .../src/sidepanel/components/ContextPanelHost.tsx  |  96 +++--
 .../src/sidepanel/components/MeetingPanel.tsx      | 239 ++++++++++--
 .../src/sidepanel/voice/meeting-close.ts           |  90 +++++
 .../tests/fixtures/meeting-responses.ts            | 417 +++++++++++++++++++++
 chrome-extension/tests/meeting-close.test.ts       |  91 +++++
 companion/tests/meeting-close-contract-488.test.ts |  48 +++
 10 files changed, 1313 insertions(+), 92 deletions(-)

FULL CURRENT FILE chrome-extension/scripts/render-meeting-close-fixture.cjs
// Actual MeetingPanel + ContextPanelHost + local STT adapter. Only PCM input and
// transport are synthetic; no live Companion, microphone, or user data.
const fs = require('fs'), path = require('path');
const root = process.cwd(), out = process.argv[2];
if (!out) throw new Error('output directory required');
fs.mkdirSync(out, { recursive: true });
const source = `
import React,{useEffect,useState} from 'react';import{createRoot}from'react-dom/client';
import{AgentStoreProvider,initialState,useAgentStore}from'./src/sidepanel/store/agentStore';
import{ContextPanelHostProvider,ContextPanelHost,useContextPanelHost}from'./src/sidepanel/components/ContextPanelHost';
import{MeetingPanel}from'./src/sidepanel/components/MeetingPanel';
import{meetingResponses as recorded}from'./tests/fixtures/meeting-responses';
const listeners=new Set();window.sent=[];window.persisted=[];window.deferStart=false;window.failRead=false;window.deferEnd=false;window.failWrite=false;
window.recorded=recorded;window.owner=recorded.created.response.meeting.id;
window.emit=m=>{for(const fn of [...listeners])fn(m)};
window.snapshot=()=>({...structuredClone(recorded.read.response.meeting),transcript:window.persisted.map(text=>({...recorded.appended.response.meeting.transcript[0],text}))});
window.reply=(key,m)=>window.emit({...structuredClone(recorded[key].response),id:m.id,meeting:window.snapshot()});
window.replyEnd=()=>window.reply('ended',window.sent.findLast(m=>m.type==='meeting.end'));
const event={addListener(){},removeListener(){}};
window.chrome={runtime:{id:'fixture',onMessage:{addListener:f=>listeners.add(f),removeListener:f=>listeners.delete(f)},sendMessage:(m,cb)=>{
window.sent.push(m);queueMicrotask(()=>{cb?.({ok:true});
if(m.type==='meeting.start'&&!window.deferStart)window.reply('started',m);
if(m.type==='meeting.create')window.reply('created',m);
if(m.type==='meeting.append_transcript'||m.type==='meeting.set_transcript'){
if(window.failWrite){window.emit({...recorded.denied.response,id:m.id});window.reply('appended',{id:'stale-write'});}
else{if(m.type==='meeting.append_transcript')window.persisted.push(m.text);else window.persisted=m.text.split(/\\n+/).map(t=>t.trim()).filter(Boolean);window.reply(m.type==='meeting.append_transcript'?'appended':'replaced',m)}}
if(m.type==='meeting.get'){if(window.failRead)window.emit({...recorded.denied.response,id:m.id,message:'尚未确认保存'});else window.reply('read',m)}
if(m.type==='meeting.end'&&!window.deferEnd)window.reply('ended',m);
});return Promise.resolve({ok:true})}},storage:{local:{get:(k,cb)=>{const r={meeting_privacy_ack_v1:true};cb?.(r);return Promise.resolve(r)},set:(v,cb)=>{cb?.();return Promise.resolve()}},onChanged:event},tabs:{query:(q,cb)=>{cb?.([]);return Promise.resolve([])}}};
function Harness(){const h=useContextPanelHost();const{state,dispatch}=useAgentStore();window.dispatchUI=dispatch;window.activePanel=h.activePanel;
useEffect(()=>h.openPanelForce('meeting'),[]);return <><button onClick={()=>h.openPanelForce('skills')}>切换技能</button><button onClick={()=>h.openPanelForce('knowledge')}>切换知识</button><button onClick={()=>dispatch({type:'SET_SETTINGS_OPEN',open:true})}>打开设置</button><span data-testid='settings-state'>{state.settingsOpen?'设置已打开':'设置未打开'}</span><ContextPanelHost/></>}
function Standalone(){const[open,setOpen]=useState(true);window.activePanel=open?'meeting':null;return open?<MeetingPanel onClose={()=>{window.sent.push({type:'fixture.closed'});setOpen(false)}} onSendToDraft={()=>{}}/>:<span>独立面板已关闭</span>}
createRoot(document.getElementById('root')).render(<AgentStoreProvider initialState={{...initialState,connectionState:'connected',activeThreadId:'thread-fixture',voicePrivacyAckV2:true,voiceRealtimeStreaming:true,voiceModel:{localModelId:'medium',binary:{status:'ready'},models:{medium:{status:'ready'}}}}}>{location.search.includes('standalone')?<Standalone/>:<ContextPanelHostProvider capabilityLevel='chat'><Harness/></ContextPanelHostProvider>}</AgentStoreProvider>);
`;
const capture = `export async function startPcmStreamCapture(opts){window.capture=opts;window.captureStops=0;window.captureAborts=0;return{backend:'scriptprocessor',stop:async()=>{window.captureStops++},abort:()=>{window.captureAborts++}}}`;
const audioImport = `export * from ${JSON.stringify(path.join(root,'src/sidepanel/voice/meeting-audio-import.ts'))};import{wrapPcmS16leAsWav}from ${JSON.stringify(path.join(root,'src/sidepanel/voice/pcm-encode.ts'))};export async function fileToWavSegments(){if(window.deferDecode)await new Promise(r=>window.finishDecode=r);const wav=wrapPcmS16leAsWav(new Uint8Array(32000),16000,1);return{ok:true,segments:[{wav},{wav}],durationSec:2}}`;
require(path.join(root,'node_modules/esbuild')).build({stdin:{contents:source,resolveDir:root,loader:'tsx'},bundle:true,outfile:path.join(out,'app.js'),jsx:'automatic',plugins:[{name:'synthetic-pcm',setup(b){b.onResolve({filter:/\/pcm-stream-capture$/},()=>({path:'pcm-fixture',namespace:'fixture'}));b.onResolve({filter:/\/meeting-audio-import$/},()=>({path:'import-fixture',namespace:'fixture'}));b.onLoad({filter:/.*/,namespace:'fixture'},args=>({contents:args.path==='import-fixture'?audioImport:capture,loader:'ts',resolveDir:root}));}}]}).then(()=>fs.writeFileSync(path.join(out,'index.html'),'<html lang="zh-CN"><meta charset="utf-8"><body><div id="root"></div><script src="app.js"></script></body></html>')).catch(e=>{console.error(e);process.exitCode=1});

FULL CURRENT FILE chrome-extension/scripts/test-meeting-close-ui.py
"""Production Host/Meeting/adapter, synthetic PCM + transport. No real audio."""
from pathlib import Path
import subprocess
import tempfile
from playwright.sync_api import sync_playwright

project = Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='cmspark-meeting-close-') as directory:
    subprocess.run(['node', 'scripts/render-meeting-close-fixture.cjs', directory], cwd=project, check=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        def open_fixture(standalone=False):
            page.goto((Path(directory)/'index.html').as_uri() + ('?standalone' if standalone else ''))
            page.get_by_test_id('meeting-start-capture').wait_for()
            page.wait_for_function('!document.querySelector("[data-testid=meeting-start-capture]").disabled')
        def start():
            page.get_by_test_id('meeting-start-capture').click()
            page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.start")')
            page.evaluate('window.capture.onPcmChunk(new Uint8Array(32000))')
        def final(text='最后一段合成转写'):
            page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
            assert page.get_by_test_id('meeting-panel').is_visible()
            assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
            page.evaluate("text=>window.emit({type:'voice.stt.result',sessionId:window.sent.find(m=>m.type==='voice.stt.end').sessionId,text})", text)
        for action in ['host', 'inner', 'skills', 'escape', 'settings', 'latest', 'owner']:
            open_fixture(); start()
            if action == 'host': page.get_by_role('button',name='结束并收起',exact=True).click()
            elif action == 'inner': page.get_by_role('button',name='结束录制并收起面板',exact=True).click()
            elif action == 'skills': page.get_by_role('button',name='切换技能',exact=True).click()
            elif action == 'settings': page.get_by_role('button',name='打开设置',exact=True).click()
            elif action == 'latest':
                page.get_by_role('button',name='切换技能',exact=True).click()
                page.get_by_role('button',name='切换知识',exact=True).click()
            elif action == 'owner':
                page.get_by_role('button',name='结束并收起',exact=True).click()
                page.evaluate("window.emit({type:'meeting.created',meeting:{id:'other-meeting'}})")
            else:
                page.get_by_role('button',name='结束并收起',exact=True).focus()
                page.keyboard.press('Escape')
            final()
            page.wait_for_function('window.activePanel!=="meeting"')
            assert page.evaluate('window.persisted') == ['最后一段合成转写']
            assert page.evaluate('window.captureStops') == 1
            assert page.evaluate('window.captureAborts') == 0
            types = page.evaluate('window.sent.map(m=>m.type)')
            assert types.index('meeting.append_transcript') < types.index('meeting.get') < types.index('meeting.end')
            assert page.evaluate("window.sent.filter(m=>['meeting.append_transcript','meeting.get','meeting.end'].includes(m.type)).every(m=>m.meeting_id===window.owner&&m.id!==window.owner)")
            if action == 'settings': assert page.get_by_test_id('settings-state').inner_text() == '设置已打开'
            if action == 'latest': assert page.evaluate('window.activePanel') == 'knowledge'
        # A successful forwarding ACK / incorrect persisted snapshot must not close.
        open_fixture(); start(); page.evaluate('window.failRead=true')
        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
        page.get_by_role('alert').filter(has_text='尚未确认保存').wait_for()
        assert page.evaluate('window.activePanel') == 'meeting'
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        page.evaluate('window.failRead=false')
        page.get_by_role('button',name='收起面板',exact=True).click()
        page.wait_for_function('window.activePanel===null')
        # Review finding 2: failure retains the meeting and a repeated Settings
        # action retries successfully; it must not force-close or silently lose text.
        open_fixture(); start(); page.evaluate('window.failRead=true')
        settings_button = page.get_by_role('button',name='打开设置',exact=True)
        settings_button.click(); final()
        page.get_by_role('alert').filter(has_text='尚未确认保存').wait_for()
        assert page.evaluate('window.activePanel') == 'meeting'
        assert page.get_by_test_id('settings-state').inner_text() == '设置未打开'
        assert settings_button.is_enabled()
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        assert page.evaluate('window.persisted') == ['最后一段合成转写']
        page.evaluate('window.failRead=false')
        settings_button.click()
        page.wait_for_function('window.activePanel===null')
        assert page.get_by_test_id('settings-state').inner_text() == '设置已打开'
        assert page.evaluate('window.sent.filter(m=>m.type==="meeting.get").length') == 2
        print('PASS settings readback failure: visible error + meeting retained; repeated Settings action completes after recovery')
        # Review finding 3: no Host and no registerBeforeClose prop. The inner
        # button still uses the production fallback guard and delays onClose.
        open_fixture(standalone=True); start(); page.evaluate('window.deferEnd=true')
        page.get_by_role('button',name='结束录制并收起面板',exact=True).click(); final()
        page.wait_for_function('window.sent.some(m=>m.type==="meeting.end")')
        assert page.get_by_test_id('meeting-panel').is_visible()
        assert not page.evaluate('window.sent.some(m=>m.type==="fixture.closed")')
        page.evaluate("window.replyEnd()")
        page.wait_for_function('window.activePanel===null')
        assert page.evaluate('window.persisted') == ['最后一段合成转写']
        types = page.evaluate('window.sent.map(m=>m.type)')
        assert types.index('meeting.append_transcript') < types.index('meeting.get') < types.index('meeting.end') < types.index('fixture.closed')
        assert types.count('fixture.closed') == 1
        print('PASS standalone MeetingPanel without registerBeforeClose: final → persisted readback → end ACK → exactly one onClose')
        # Final dispatch is not end confirmation: keep the owner mounted until ACK.
        open_fixture(); start(); page.evaluate('window.deferEnd=true')
        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
        page.wait_for_function('window.sent.some(m=>m.type==="meeting.end")')
        assert page.evaluate('window.activePanel') == 'meeting'
        page.evaluate("window.emit({type:'meeting.ended',meeting:{id:'other'}})")
        assert page.evaluate('window.activePanel') == 'meeting'
        page.evaluate("window.replyEnd()")
        page.wait_for_function('window.activePanel===null')
        # Closing before meeting.started must not acquire a mic when start arrives.
        open_fixture(); page.evaluate('window.deferStart=true')
        page.get_by_test_id('meeting-start-capture').click()
        page.get_by_role('button',name='结束并收起',exact=True).click()
        page.wait_for_timeout(20)
        page.evaluate("window.emit({type:'meeting.started',meeting:window.snapshot()})")
        page.wait_for_function('window.activePanel===null')
        assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start")')
        # Import stop keeps the current final, saves it, and skips remaining segments.
        open_fixture()
        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
        page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
        page.get_by_role('button',name='结束并收起',exact=True).click()
        final()
        page.wait_for_function('window.activePanel===null')
        assert page.evaluate('window.persisted') == ['最后一段合成转写']
        assert page.evaluate('window.sent.filter(m=>m.type==="voice.stt.start").length') == 1
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        # Closing while decoding cancels before creating a meeting or STT session.
        open_fixture(); page.evaluate('window.deferDecode=true')
        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
        page.wait_for_function('!!window.finishDecode')
        page.get_by_role('button',name='结束并收起',exact=True).click()
        page.wait_for_timeout(20); page.evaluate('window.finishDecode()')
        page.wait_for_function('window.activePanel===null')
        assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start"||m.type==="meeting.create")')
        # Old equal/suffix text and stale server pushes must not consume a failed
        # new write or replace the local final. Explicit save is a recoverable path.
        for text in ['好', '你好']:
            open_fixture(); start()
            page.evaluate("window.persisted=['你好'];window.failWrite=true")
            page.get_by_role('button',name='结束并收起',exact=True).click(); final(text)
            page.get_by_role('alert').filter(has_text='保存转写').wait_for()
            textarea = page.locator('textarea').first
            assert textarea.input_value() == text
            page.evaluate("window.reply('appended',{id:'stale-after-idle'});window.emit(window.recorded.oldRead.response)")
            assert textarea.input_value() == text
            assert page.evaluate('window.activePanel') == 'meeting'
            assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
            # A denied full replacement must not erase the original write failure.
            page.get_by_role('button',name='保存转写',exact=True).click()
            page.get_by_role('alert').filter(has_text='草稿仍保留').wait_for()
            assert textarea.input_value() == text
            page.evaluate('window.failWrite=false')
            page.get_by_role('button',name='保存转写',exact=True).click()
            page.get_by_test_id('meeting-save-status').filter(has_text='已保存转写').wait_for()
            assert page.evaluate('window.persisted') == [text]
            page.get_by_role('button',name='收起面板',exact=True).click()
            page.wait_for_function('window.activePanel===null')
            assert not page.evaluate('window.sent.some(m=>m.type==="meeting.generate_minutes")')
        print('PASS stale suffix/equal write receipts rejected; textarea retains unconfirmed final after idle and stale pushes; denied save retains draft; explicit successful save recovers close without LLM')
        # An unregistered guard cannot create another read/end on later settings.
        requests = page.evaluate('window.sent.filter(m=>m.type==="meeting.get"||m.type==="meeting.end").length')
        page.get_by_role('button',name='打开设置',exact=True).click()
        assert page.get_by_test_id('settings-state').inner_text() == '设置已打开'
        assert page.evaluate('window.sent.filter(m=>m.type==="meeting.get"||m.type==="meeting.end").length') == requests
        print('PASS guard effect unregisters on unmount; subsequent settings does not run stale meeting guard')
        # Normal Stop precedes Close: actual store contract independently verifies
        # endMeetingRecording remains idempotent and returns both receipts.
        open_fixture(); start()
        page.get_by_test_id('meeting-stop-capture').click(); final()
        page.wait_for_function('window.sent.some(m=>m.type==="meeting.end")')
        page.get_by_role('button',name='收起面板',exact=True).click()
        page.wait_for_function('window.activePanel===null')
        print('PASS normal stop followed by close completes with final text intact')
        # Failed import replacement also preserves its local final for recovery.
        open_fixture(); page.evaluate('window.failWrite=true')
        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
        page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
        page.get_by_role('alert').filter(has_text='保存转写').wait_for()
        assert page.locator('textarea').first.input_value() == '最后一段合成转写'
        page.evaluate('window.failWrite=false')
        page.get_by_role('button',name='保存转写',exact=True).click()
        page.get_by_test_id('meeting-save-status').filter(has_text='已保存转写').wait_for()
        page.get_by_role('button',name='收起面板',exact=True).click()
        page.wait_for_function('window.activePanel===null')
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        print('PASS failed import set_transcript preserves textarea and explicit save enables retry')
        # Accelerate only the production 20s stop deadline; transport/final absent.
        page.add_init_script("const timeout=window.setTimeout.bind(window);window.setTimeout=(f,ms,...args)=>timeout(f,ms===20000?40:ms,...args)")
        open_fixture(); start()
        page.get_by_role('button',name='结束并收起',exact=True).click()
        page.get_by_role('alert').filter(has_text='未完整处理').wait_for()
        assert page.evaluate('window.activePanel') == 'meeting'
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        assert not errors, errors
        browser.close()
print('PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation')

FULL CURRENT FILE chrome-extension/scripts/test-thread-mutations-ui.py
"""#488 actual App + recorded server payload shapes, isolated synthetic transport.
No live Chrome profile, conversation, microphone, or configuration is accessed.
"""
from pathlib import Path
import subprocess, tempfile
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-488-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
 with sync_playwright() as p:
  browser=p.chromium.launch(channel='chrome',headless=True)
  errors=[]
  def setup(count=60,trash=False,width=390,height=740):
   page=browser.new_page(viewport={'width':width,'height':height});page.set_default_timeout(7000)
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
   page.evaluate('''({count,trash})=>{
    const threads=Array.from({length:count},(_,i)=>({...window.demoThreads[0],id:'t'+i,alias:'对话 '+i,message_count:4,user_tags:[i<2?'支付':'架构'],trashed_at:trash?'2026-09-09T00:00:00Z':null}));
    window.fixtureServerThreads=structuredClone(threads);
    window.dispatchUI({type:'SET_THREADS',threads});window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'t0'});
   }''',{'count':count,'trash':trash})
   page.get_by_role('button',name='对话管理（历史对话）',exact=True).click()
   manager=page.get_by_role('dialog',name='历史对话列表',exact=True);manager.wait_for()
   if trash:
    manager.get_by_role('button',name='回收站',exact=True).click()
    manager.get_by_text(f'回收站 · {count}',exact=False).wait_for()
   return page,manager
  def select_all(manager):manager.get_by_role('button',name='全选',exact=True).click()
  def confirm_delete(manager,hard=False):
   manager.locator('.cm-thread-selection-bar').get_by_role('button',name='永久删除' if hard else '移入回收站',exact=True).click()
   dialog=manager.get_by_role('alertdialog',name='确认删除会话');dialog.wait_for()
   assert dialog.get_by_role('button',name='取消',exact=True).evaluate('(el)=>el===document.activeElement')
   dialog.get_by_role('button',name='永久删除' if hard else '移入回收站',exact=True).click()

  # A visible tag filter is the complete selection boundary.
  page,m=setup();m.get_by_role('button',name='标签',exact=True).click();m.get_by_role('button',name='#支付 2',exact=True).click()
  select_all(m);m.get_by_text('已选 2',exact=True).wait_for()
  page.evaluate('window.mutationReply="defer"');confirm_delete(m)
  assert page.evaluate('window.mutationRequests[0].thread_ids')==['t0','t1']
  assert page.evaluate('window.fixtureState.threads.length')==60
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.fixtureState.threads.length===58');page.close()

  # Single-row deletion also goes through the correlated batch protocol.
  page,m=setup(3);page.evaluate('window.mutationReply="defer"')
  m.locator('[data-thread-id="t1"]').get_by_role('button',name='删除 对话 1',exact=False).click()
  m.get_by_role('alertdialog').get_by_role('button',name='移入回收站',exact=True).click()
  assert page.evaluate('window.mutationRequests.map(m=>({type:m.type,ids:m.thread_ids}))')==[{'type':'thread.batch_delete','ids':['t1']}]
  assert page.evaluate('window.fixtureState.threads.length')==3
  assert not page.evaluate('window.sent.some(m=>m.type==="thread.delete")')
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.fixtureState.threads.length===2');page.close()

  # More than 50 items are sent serially; a transport ACK never removes rows.
  page,m=setup();page.evaluate('window.mutationReply="defer"');select_all(m);confirm_delete(m)
  assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids.length)')==[50]
  assert page.evaluate('window.fixtureState.threads.length')==60
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.mutationRequests.length===2')
  assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids.length)')==[50,10]
  page.evaluate('window.finishThreadMutation(window.mutationRequests[1])')
  page.wait_for_function('window.fixtureState.threads.length===0');page.close()

  # Busy/filter changes only shrink a selection; no deletion of another row.
  for change in ['busy','filter']:
   page,m=setup(3);m.get_by_role('button',name='选择',exact=True).click()
   m.locator('[data-thread-id="t0"] input[type="checkbox"]').check()
   if change=='busy':page.evaluate('window.dispatchUI({type:"SET_THREAD_BUSY",threadId:"t0",busy:true})')
   else:m.get_by_role('searchbox').fill('对话 1')
   m.get_by_text('已选 0',exact=True).wait_for()
   assert m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).is_disabled()
   assert page.evaluate('window.mutationRequests.length')==0;page.close()

  # Confirmation re-checks busy state even after the target preview was opened.
  page,m=setup(2);select_all(m)
  m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).click()
  page.evaluate('window.dispatchUI({type:"SET_THREAD_BUSY",threadId:"t0",busy:true})')
  m.get_by_role('alertdialog').get_by_role('button',name='移入回收站',exact=True).click()
  m.get_by_role('status').filter(has_text='状态已变化').wait_for()
  assert page.evaluate('window.mutationRequests.length')==0;page.close()

  # Offline and partial failures retain failed records with an actionable result.
  page,m=setup(3);page.evaluate('window.mutationReply="offline"');select_all(m);confirm_delete(m)
  m.get_by_role('status').filter(has_text='未发送').wait_for()
  assert page.evaluate('window.fixtureState.threads.length')==3;page.close()
  page,m=setup(3);page.evaluate('window.mutationFailedIds=["t1"]');select_all(m);confirm_delete(m)
  page.wait_for_function('window.fixtureState.threads.length===1')
  assert page.evaluate('window.fixtureState.threads[0].id')=='t1'
  m.get_by_role('status').filter(has_text='已移入回收站 2').wait_for();page.close()

  # Restore waits for persistence, then refreshes including remaining trash rows.
  page,m=setup(3,trash=True);page.evaluate('window.mutationReply="defer";window.mutationFailedIds=["t1"]');select_all(m)
  m.locator('.cm-thread-selection-bar').get_by_role('button',name='恢复',exact=True).click()
  assert page.evaluate('window.fixtureState.threads.filter(t=>t.trashed_at).length')==3
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.fixtureState.threads.filter(t=>t.trashed_at).length===1')
  assert page.evaluate('window.fixtureState.threads.find(t=>t.trashed_at).id')=='t1'
  assert page.evaluate('window.sent.filter(m=>m.type==="thread.list").at(-1).include_trashed') is True
  page.close()

  # Empty cleanup uses an in-app preview, probes safely, and rechecks server content.
  for legacy in [False,True]:
   page,m=setup(3)
   page.evaluate('''legacy=>{window.legacyEmptyProbe=legacy;
    const threads=window.fixtureState.threads.map(t=>({...t,message_count:0}));
    window.dispatchUI({type:'SET_THREADS',threads});
    window.fixtureServerThreads=threads.map(t=>({...t,message_count:t.id==='t1'?1:0}));
   }''',legacy)
   m.get_by_title('更多',exact=True).click()
   page.get_by_role('menu').get_by_role('button',name='🧹 清理空白',exact=True).click()
   m.get_by_role('alertdialog').get_by_role('button',name='永久删除',exact=True).click()
   if legacy:
    m.get_by_role('status').filter(has_text='请更新 Companion').wait_for()
    assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids)')==[[]]
    assert page.evaluate('window.fixtureState.threads.length')==3
   else:
    page.wait_for_function('window.fixtureState.threads.length===2')
    assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids)')==[[],['t1','t2']]
    assert page.evaluate('window.fixtureState.threads.map(t=>t.id)')==['t0','t1']
   page.close()

  # Cleanup's checkboxes and bulk-list selection are visibly separate scopes.
  page,m=setup(4)
  page.evaluate('window.dispatchEvent(new CustomEvent("cmspark:cleanup_suggestions",{detail:{suggestions:[{thread_id:"t1",reason:"thin",detail:"test",precheck:true},{thread_id:"t2",reason:"thin",detail:"test"}]}}))')
  cleanup=m.get_by_role('region',name='整理建议');cleanup.wait_for()
  select_all(m)
  assert cleanup.locator('input:checked').count()==1
  cleanup.get_by_role('button',name='全选建议',exact=True).click()
  assert cleanup.locator('input:checked').count()==2
  m.get_by_role('button',name='取消全选',exact=True).click()
  assert cleanup.locator('input:checked').count()==2
  cleanup.get_by_role('button',name='清空建议选择',exact=True).click()
  assert cleanup.get_by_role('button',name='移入回收站（0）',exact=True).is_disabled();page.close()

  # Short windows retain scrollable rows, all management tools and outside stop.
  for width,height in [(320,480),(390,740),(760,740),(1440,900)]:
   page,m=setup(6,width=width,height=height)
   for view in ['时间','标签','手动分组','AI 分组']:
    m.get_by_role('button',name=view,exact=True).click()
    assert m.locator('.cm-thread-management-list').bounding_box()['height']>=100
    assert m.evaluate('(el)=>el.scrollWidth<=el.clientWidth')
   m.get_by_role('button',name='时间',exact=True).click();select_all(m)
   m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).scroll_into_view_if_needed()
   assert m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
   m.get_by_role('button',name='取消选择',exact=True).click()
   row=m.locator('[data-thread-id="t0"]')
   for title in ['列表内相关','提取要点 / 标签','提炼为知识（需确认）','编辑标签与分组','导出此线程摘要为 Markdown','删除线程']:
    button=row.get_by_title(title,exact=True);button.scroll_into_view_if_needed();button.click(trial=True)
    assert button.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
   page.screenshot(path=str(shots/f'row-actions-{width}.png'))
   for label in ['AI 提取标签','整理助手','关系图谱','回收站']:
    button=m.get_by_role('button',name=label,exact=True);button.scroll_into_view_if_needed();assert button.is_visible()
   m.evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(shots/f'manager-{width}.png'));page.close()
  assert not errors,errors
  browser.close()
print('PASS: actual App selection boundaries, busy/filter race, 60-item batching, ACK vs persisted result, offline/partial failure, restore, independent cleanup scope and responsive management capabilities.')

FULL CURRENT FILE chrome-extension/src/sidepanel/components/ComposeDrawer.tsx
// 装配 drawer — full Composition section UI (UIUX v2 PR6 / §4.5).
// Opens Host panels; Board / Fleet / multi-worker are Autonomy — never listed.
// Shell via BottomSheet (focus trap + Escape from ui/Modal); landfill
// one-surface rule enforced by parent.
// G4: MD3-ish sheet (radiusSheet + soft scrim) + settings-list groups.

import {
  useRef,
  useState,
  type CSSProperties,
  type ComponentType,
  type RefObject,
} from "react"
import {
  COMPOSE_GROUP_LABELS,
  COMPOSE_SECTIONS,
  composeSectionGroups,
  composeSectionsInGroup,
  type ComposeSection,
  type ComposeSectionGroup,
  type ComposeSectionId,
} from "../composer/meta-slash"
import type { ContextPanelId } from "./ContextPanelHost"
import type { CapabilityLevel } from "../types"
import { tokens } from "../ui/tokens"
import { BottomSheet } from "./ui/BottomSheet"
import {
  IconApps,
  IconChevronRight,
  IconClose,
  IconHistory,
  IconKnowledge,
  IconMcp,
  IconPacks,
  IconSkills,
  type IconProps,
} from "../ui/icons"

const FIRST_SECTION_ID: ComposeSectionId = COMPOSE_SECTIONS[0]?.id ?? "skills"

const SECTION_SCOPE: Record<ComposeSectionId, string> = {
  skills: "管理全局技能；按需用于对话",
  knowledge: "管理知识库；选择本次对话使用的知识",
  packs: "管理场景与专家；选择本对话工作区",
  mcp: "管理全局 MCP 连接",
  apps: "管理全局应用连接",
  history: "查看当前对话的操作记录",
}

const SECTION_ICONS: Record<ComposeSection["id"], ComponentType<IconProps>> = {
  skills: IconSkills,
  knowledge: IconKnowledge,
  packs: IconPacks,
  mcp: IconMcp,
  apps: IconApps,
  history: IconHistory,
}

export type ComposeDrawerProps = {
  open: boolean
  onClose: () => void
  /** Open Host panel and close drawer. */
  onOpenSection: (panelId: ContextPanelId) => void
  /** Accepted for caller compatibility; resource configuration is not Surface-scoped. */
  capabilityLevel?: CapabilityLevel
}

export function ComposeDrawer({
  open,
  onClose,
  onOpenSection,
}: ComposeDrawerProps) {
  const firstBtnRef = useRef<HTMLButtonElement>(null)
  const groups = composeSectionGroups()

  const handleSection = (section: ComposeSection) => {
    // Defense: never open Autonomy surfaces from 装配
    if (section.panelId === "board") return
    onOpenSection(section.panelId)
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      ariaLabel="装配"
      initialFocusRef={firstBtnRef as RefObject<HTMLElement>}
    >
      <div data-testid="compose-drawer">
        <div style={styles.header}>
          <div style={{ minWidth: 0 }}>
            <div style={styles.title}>装配</div>
            <div style={styles.subtitle}>
              管理资源与连接，按需用于对话
            </div>
          </div>
          <button
            type="button"
            style={styles.closeBtn}
            onClick={onClose}
            aria-label="关闭装配"
            data-testid="compose-drawer-close"
          >
            <IconClose size={14} />
          </button>
        </div>

        {groups.map((group) => (
          <SectionGroup
            key={group}
            group={group}
            firstSectionId={FIRST_SECTION_ID}
            firstBtnRef={firstBtnRef}
            onOpen={handleSection}
          />
        ))}

        <p style={styles.footNote} data-testid="compose-autonomy-note">
          任务板可从“资料与工具”或 /board 打开
        </p>
      </div>
    </BottomSheet>
  )
}

function SectionGroup({
  group,
  firstSectionId,
  firstBtnRef,
  onOpen,
}: {
  group: ComposeSectionGroup
  firstSectionId: ComposeSectionId
  firstBtnRef: RefObject<HTMLButtonElement>
  onOpen: (section: ComposeSection) => void
}) {
  const sections = composeSectionsInGroup(group)
  if (sections.length === 0) return null

  return (
    <section style={styles.group} aria-labelledby={`compose-group-${group}`}>
      <h3 id={`compose-group-${group}`} style={styles.groupLabel}>
        {COMPOSE_GROUP_LABELS[group]}
      </h3>
      <ul style={styles.list} role="list">
        {sections.map((section, index) => {
          const Icon = SECTION_ICONS[section.id]
          return (
            <li
              key={section.id}
              style={{
                ...styles.listItem,
                borderTop: index > 0 ? `1px solid ${tokens.border}` : undefined,
              }}
            >
              <SectionRowButton
                section={section}
                Icon={Icon}
                attachLine={SECTION_SCOPE[section.id]}
                buttonRef={section.id === firstSectionId ? firstBtnRef : undefined}
                onOpen={onOpen}
              />
            </li>
          )
        })}
      </ul>
    </section>
  )
}

/** Settings-list row with hover (inline styles cannot use :hover). */
function SectionRowButton({
  section,
  Icon,
  attachLine,
  buttonRef,
  onOpen,
}: {
  section: ComposeSection
  Icon: ComponentType<IconProps>
  attachLine: string
  buttonRef?: RefObject<HTMLButtonElement>
  onOpen: (section: ComposeSection) => void
}) {
  const [hovered, setHovered] = useState(false)
  return (
    <button
      ref={buttonRef}
      type="button"
      style={{
        ...styles.sectionBtn,
        background: hovered ? tokens.bgHover : "transparent",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocus={() => setHovered(true)}
      onBlur={() => setHovered(false)}
      onClick={() => onOpen(section)}
      data-testid={`compose-section-${section.id}`}
    >
      <span style={styles.iconWrap} aria-hidden>
        <Icon size={16} />
      </span>
      <span style={styles.sectionBody}>
        <span style={styles.sectionTitleRow}>
          <span style={styles.sectionTitleZh}>{section.titleZh}</span>
          <span style={styles.sectionLabelEn}>{section.label}</span>
        </span>
        <span style={styles.sectionHint}>{section.hint}</span>
        <span style={styles.attachLine}>{attachLine}</span>
      </span>
      <IconChevronRight size={14} style={{ color: tokens.textMuted, flexShrink: 0 }} />
    </button>
  )
}

// Re-export for tests that import section list from drawer path (if any).
export { COMPOSE_SECTIONS }

const styles: Record<string, CSSProperties> = {
  header: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 8,
    padding: "0 16px 10px",
  },
  title: {
    fontSize: 16,
    fontWeight: 650,
    color: tokens.text,
    letterSpacing: "-0.02em",
  },
  subtitle: {
    fontSize: 11,
    color: tokens.textSecondary,
    marginTop: 3,
    lineHeight: 1.4,
  },
  closeBtn: {
    width: 30,
    height: 30,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusMd,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 0,
  },
  group: {
    margin: 0,
    padding: "0 0 10px",
  },
  groupLabel: {
    margin: "4px 16px 6px",
    fontSize: 10,
    fontWeight: 650,
    color: tokens.textMuted,
    textTransform: "uppercase" as const,
    letterSpacing: "0.06em",
  },
  /** G4: one elevated settings card per group (not a grid of caged buttons) */
  list: {
    listStyle: "none",
    margin: "0 12px",
    padding: 4,
    background: tokens.bg,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusLg,
    boxShadow: tokens.shadowSm,
    overflow: "hidden",
  },
  listItem: {
    margin: 0,
  },
  sectionBtn: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    width: "100%",
    textAlign: "left",
    border: "none",
    borderRadius: tokens.radiusMd,
    background: "transparent",
    padding: "10px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    transition: `background ${tokens.transitionFast} ease`,
  },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: tokens.radiusMd,
    background: tokens.accentSoft,
    color: tokens.accentText,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  sectionBody: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    gap: 2,
  },
  sectionTitleRow: {
    display: "flex",
    alignItems: "baseline",
    gap: 6,
  },
  sectionTitleZh: {
    fontSize: 13,
    fontWeight: 600,
    color: tokens.text,
  },
  sectionLabelEn: {
    fontSize: 10,
    fontWeight: 500,
    color: tokens.textMuted,
  },
  sectionHint: {
    fontSize: 11,
    color: tokens.textSecondary,
    lineHeight: 1.35,
  },
  attachLine: {
    fontSize: 10,
    color: tokens.accentText,
    marginTop: 1,
    lineHeight: 1.3,
  },
  footNote: {
    margin: "4px 16px 0",
    fontSize: 10,
    color: tokens.textMuted,
    lineHeight: 1.4,
  },
}

FULL CURRENT FILE chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
// ContextPanelHost — single owner of context panel state, loaders, mounts,
// and cmspark:open-context-panel (UIUX v2 §4.7 M1). Host is SoT for panels.
// #321 PR-1: legacy permanent BottomBar tab strip deleted (was PR5-gated off).

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
} from "react"
import { useAgentStore } from "../store/agentStore"
import {
  contextBarTabsForLevel,
  contextBarOverflowTabsForLevel,
} from "../mode/mode-controller"
import type { CapabilityLevel } from "../types"
import { KnowledgeSubPanel } from "./KnowledgeSubPanel"
import { McpPanel } from "./McpPanel"
import { AppsPanel } from "./AppsPanel"
import { PacksPanel } from "./PacksPanel"
import { BoardPanel } from "./BoardPanel"
import { MeetingPanel } from "./MeetingPanel"
import { tokens } from "../ui/tokens"
import {
  IconTabs,
  IconHistory,
  IconSkills,
  IconKnowledge,
  IconMcp,
  IconApps,
  IconPacks,
  IconMic,
  IconList,
} from "../ui/icons"

// ── Registry ───────────────────────────────────────────────────────────────

export type ContextPanelId =
  | "tabs"
  | "history"
  | "skills"
  | "knowledge"
  | "packs"
  | "board"
  | "mcp"
  | "apps"
  | "meeting"

export type ContextPanelTabDef = {
  id: ContextPanelId
  label: string
  Icon: ComponentType<{ size?: number }>
}

/** Canonical panel registry (labels + icons). Strip and Host share this. */
// #321 PR-5: packs/meeting/board each get their own icon (were all IconSkills
// collisions); icons come from the existing ui/icons set — nothing new drawn.
export const CONTEXT_PANEL_TABS: ContextPanelTabDef[] = [
  { id: "tabs", label: "浏览器标签页", Icon: IconTabs },
  { id: "history", label: "历史", Icon: IconHistory },
  { id: "skills", label: "技能", Icon: IconSkills },
  { id: "knowledge", label: "知识", Icon: IconKnowledge },
  { id: "packs", label: "场景与专家", Icon: IconPacks },
  { id: "meeting", label: "会议", Icon: IconMic },
  { id: "board", label: "任务板", Icon: IconList },
  { id: "mcp", label: "MCP", Icon: IconMcp },
  { id: "apps", label: "应用", Icon: IconApps },
]

const KNOWN_IDS = new Set(CONTEXT_PANEL_TABS.map((t) => t.id))

export function isContextPanelId(id: string): id is ContextPanelId {
  return KNOWN_IDS.has(id as ContextPanelId)
}

export function contextPanelLabel(id: ContextPanelId): string {
  return CONTEXT_PANEL_TABS.find((t) => t.id === id)?.label ?? id
}

// ── Loaders ────────────────────────────────────────────────────────────────

export function loadPanelData(
  id: ContextPanelId,
  activeThreadId: string | null,
  dispatch: ReturnType<typeof useAgentStore>["dispatch"],
) {
  if (id === "tabs") {
    chrome.tabs.query({}, (tabs) => {
      dispatch({ type: "SET_TAB_LIST", tabs })
    })
  }
  if (id === "history") {
    chrome.runtime.sendMessage({ type: "history.query", limit: 50, thread_id: activeThreadId })
  }
  if (id === "skills") {
    // Force rescan when opening Skills — picks up Finder drops / external edits
    // even if mtime fingerprint was edge-case stale; cheap after ensureFresh path.
    chrome.runtime.sendMessage({ type: "skill.refresh" })
  }
  if (id === "knowledge") {
    chrome.runtime.sendMessage({ type: "knowledge.list" })
  }
  if (id === "packs") {
    chrome.runtime.sendMessage({ type: "pack.list" })
    chrome.runtime.sendMessage({ type: "modules.list" })
  }
  if (id === "mcp") {
    chrome.runtime.sendMessage({ type: "mcp.list" })
  }
  if (id === "apps") {
    chrome.runtime.sendMessage({ type: "apps.list" })
  }
}

// ── Host API context ───────────────────────────────────────────────────────

export type ContextPanelHostApi = {
  activePanel: ContextPanelId | null
  /** Toggle: same id closes; different id opens + loads. */
  openPanel: (id: ContextPanelId) => void
  /** Force-open (no toggle) — used by slash / custom events. */
  openPanelForce: (id: ContextPanelId) => void
  closePanel: () => void
  /** A recording panel can finish its last segment before navigation unmounts it. */
  registerBeforeClose: (guard: () => Promise<boolean>) => () => void
}

const ContextPanelHostContext = createContext<ContextPanelHostApi | null>(null)

export function useContextPanelHost(): ContextPanelHostApi {
  const ctx = useContext(ContextPanelHostContext)
  if (!ctx) {
    throw new Error("useContextPanelHost must be used within ContextPanelHostProvider")
  }
  return ctx
}

/** Soft read for optional chrome that may render outside provider in tests. */
export function useContextPanelHostOptional(): ContextPanelHostApi | null {
  return useContext(ContextPanelHostContext)
}

// ── Provider ───────────────────────────────────────────────────────────────

export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const activePanelRef = useRef(activePanel)
  activePanelRef.current = activePanel
  const beforeCloseRef = useRef<(() => Promise<boolean>) | null>(null)
  const transitionRef = useRef<Promise<boolean> | null>(null)
  const targetRef = useRef<ContextPanelId | null>(null)
  const transitionVersion = useRef(0)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId
  const activeThreadRef = useRef(activeThreadId)
  activeThreadRef.current = activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const registerBeforeClose = useCallback((guard: () => Promise<boolean>) => {
    beforeCloseRef.current = guard
    return () => { if (beforeCloseRef.current === guard) beforeCloseRef.current = null }
  }, [])

  const requestPanelChange = useCallback((id: ContextPanelId | null): Promise<boolean> => {
    targetRef.current = id
    transitionVersion.current += 1
    if (transitionRef.current) return transitionRef.current
    if (activePanelRef.current === id) {
      if (id) loadPanelData(id, activeThreadRef.current, dispatch)
      return Promise.resolve(true)
    }
    const apply = () => {
      const target = targetRef.current
      activePanelRef.current = target
      setActivePanel(target)
      if (target) loadPanelData(target, activeThreadRef.current, dispatch)
    }
    const guard = beforeCloseRef.current
    if (!guard) { apply(); return Promise.resolve(true) }
    const pending = Promise.resolve().then(guard).then(allowed => {
      if (allowed) apply()
      return allowed
    }, () => false).finally(() => { transitionRef.current = null })
    transitionRef.current = pending
    return pending
  }, [dispatch])

  const closePanel = useCallback(() => { void requestPanelChange(null) }, [requestPanelChange])

  useEffect(() => {
    if (!state.settingsOpen) return
    if (!beforeCloseRef.current) { closePanel(); return }
    // Keep the finishing/error state visible; open settings after a successful close.
    dispatch({ type: "SET_SETTINGS_OPEN", open: false })
    const pending = requestPanelChange(null)
    const version = transitionVersion.current
    void pending.then(allowed => {
      if (allowed && version === transitionVersion.current) dispatch({ type: "SET_SETTINGS_OPEN", open: true })
    })
  }, [state.settingsOpen, closePanel, dispatch, requestPanelChange])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      void requestPanelChange(id)
    },
    [requestPanelChange],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      void requestPanelChange(activePanelRef.current === id ? null : id)
    },
    [requestPanelChange],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      closePanel()
    }
  }, [activePanel, allowedIds, overflowIds, closePanel])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      openPanelForce(raw)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      openPanelForce("knowledge")
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      openPanelForce("knowledge")
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [openPanelForce])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      closePanel()
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel, closePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose }),
    [activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel, registerBeforeClose } = useContextPanelHost()
  const meetingCaptureActive = useAgentStore().state.meetingCaptureActive
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)
  const closeEndsMeeting = activePanel === "meeting" && meetingCaptureActive

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        {closeEndsMeeting ? (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="结束并收起"
            aria-label="结束并收起"
            onClick={closePanel}
          >
            结束并收起
          </button>
        ) : (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="收起面板 (Esc)"
            aria-label="收起面板"
            onClick={closePanel}
          >
            收起
          </button>
        )}
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          registerBeforeClose={registerBeforeClose}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}

// ── Built-in panel bodies (moved from BottomBar) ───────────────────────────

function TabsPanel() {
  const { state, dispatch } = useAgentStore()

  const handleTogglePin = (tabId: number) => {
    const pinnedTabIds = state.pinnedTabIds.includes(tabId)
      ? state.pinnedTabIds.filter((id) => id !== tabId)
      : [...state.pinnedTabIds, tabId]

    dispatch({ type: "SET_PINNED_TABS", tabIds: pinnedTabIds })

    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { pinned_tabs: pinnedTabIds },
      })
    }
  }

  return (
    <div style={styles.panelContent}>
      {state.tabList.length === 0 && (
        <div style={styles.emptyText}>暂无标签页数据</div>
      )}
      {state.tabList.map((tab) => (
        <label key={tab.id} style={styles.tabRow}>
          <input
            type="checkbox"
            checked={state.pinnedTabIds.includes(tab.id!)}
            onChange={() => handleTogglePin(tab.id!)}
            style={{ marginRight: 8 }}
          />
          <span style={styles.tabTitle}>{tab.title || tab.url}</span>
          <span style={styles.tabUrl}>{tab.id}</span>
        </label>
      ))}
    </div>
  )
}

function HistoryPanel() {
  const { state } = useAgentStore()
  const operations = state.operations || []
  const groups = groupBy(operations, "thread_id")

  return (
    <div style={styles.panelContent}>
      {state.operations.length === 0 && (
        <div style={styles.emptyText}>暂无操作历史</div>
      )}
      {Object.entries(groups).map(([threadId, ops]) => (
        <div key={threadId} style={{ marginBottom: 8 }}>
          <div style={styles.groupHeader}>#{threadId}</div>
          {ops.map((op) => (
            <div key={op.id} style={styles.historyRow}>
              <span style={{ color: op.success ? tokens.success : tokens.danger }}>
                {op.success ? "✓" : "✗"}
              </span>
              <span style={{ flex: 1, marginLeft: 6, fontFamily: "monospace", fontSize: 11 }}>
                {op.tool_name}
              </span>
              <span style={{ color: tokens.textMuted, fontSize: 11 }}>
                {op.created_at?.slice(11, 19)}
              </span>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

function SkillsPanel() {
  const { state, dispatch } = useAgentStore()
  const [importUrl, setImportUrl] = useState("")
  const [showUrlImport, setShowUrlImport] = useState(false)
  const [showPathImport, setShowPathImport] = useState(false)
  const [pathInput, setPathInput] = useState("")
  const [menuOpen, setMenuOpen] = useState<string | null>(null)
  const [currentHostname, setCurrentHostname] = useState<string>("")
  const menuRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const zipInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url
      if (url) {
        try {
          setCurrentHostname(new URL(url).hostname)
        } catch {
          setCurrentHostname("")
        }
      }
    })
  }, [state.tabList])

  const handleModeChange = (mode: "auto" | "all" | "manual") => {
    dispatch({ type: "SET_SKILL_SELECTION_MODE", mode })
    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { skill_selection_mode: mode },
      })
    }
  }

  useEffect(() => {
    if (!menuOpen) return
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(null)
      }
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [menuOpen])

  const handleFolderFiles = async (files: FileList | File[]) => {
    const fileArr = Array.from(files)
    if (fileArr.length === 0) return

    const hasSkillMd = fileArr.some(
      (f) => f.name === "SKILL.md" || f.webkitRelativePath.endsWith("/SKILL.md"),
    )
    if (!hasSkillMd) {
      alert("文件夹中未找到 SKILL.md 文件")
      return
    }

    const payload: { path: string; content: string }[] = []
    for (const file of fileArr) {
      const content = await file.text()
      const filePath = file.webkitRelativePath || file.name
      const parts = filePath.split("/")
      const relPath = parts.length > 1 ? parts.slice(1).join("/") : parts[0]
      payload.push({ path: relPath, content })
    }

    chrome.runtime.sendMessage({ type: "skill.import-files", files: payload })
  }

  const handlePathImport = () => {
    if (pathInput.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import-path", dir_path: pathInput.trim() })
      setPathInput("")
      setShowPathImport(false)
    }
  }

  const handleExport = (skillName: string) => {
    chrome.runtime.sendMessage({ type: "skill.export", skill_name: skillName })
    setMenuOpen(null)
  }

  const handleDelete = (skillName: string) => {
    if (confirm(`确定删除技能 "${skillName}"？`)) {
      chrome.runtime.sendMessage({ type: "skill.delete", skill_name: skillName })
    }
    setMenuOpen(null)
  }

  const handleImportFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const content = reader.result as string
      chrome.runtime.sendMessage({ type: "skill.import", content })
    }
    reader.readAsText(file)
  }

  const handleImportZip = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = reader.result as string
      const base64 = dataUrl.split(",")[1]
      if (base64) {
        chrome.runtime.sendMessage({ type: "skill.import-folder", zip_data: base64 })
      }
    }
    reader.readAsDataURL(file)
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()

    const items = e.dataTransfer.items
    if (items && items.length > 0) {
      const entry = items[0].webkitGetAsEntry()
      if (entry && entry.isDirectory) {
        const files = await readDirectoryEntry(entry as FileSystemDirectoryEntry)
        if (files.length > 0) {
          handleFolderFiles(files)
        }
        return
      }
    }

    const file = e.dataTransfer.files[0]
    if (!file) return
    if (file.name.endsWith(".zip")) {
      handleImportZip(file)
    } else if (file.name.endsWith(".md") || file.name.endsWith(".markdown")) {
      handleImportFile(file)
    }
  }

  const handleUrlImport = () => {
    if (importUrl.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import", url: importUrl.trim() })
      setImportUrl("")
      setShowUrlImport(false)
    }
  }

  const skillList = Array.isArray(state.skills) ? state.skills : []
  const groupedSkills = groupSkillsBySite(skillList, currentHostname)

  const modeLabels: Record<string, string> = { auto: "自动", all: "全选", manual: "按需" }
  const skillMode = state.skillSelectionMode || "auto"
  const skillManual = skillMode === "manual"
  const skillModeHint =
    skillMode === "auto"
      ? "自动：按站点/消息匹配技能，列表勾选不生效（未勾选 ≠ 不会调用）。"
      : skillMode === "all"
        ? "全选：全部技能参与索引，无需单独勾选。"
        : "按需：仅勾选的技能会参与本对话。"

  return (
    <div style={styles.panelContent}>
      <div style={styles.modeSwitcher}>
        {(["auto", "all", "manual"] as const).map((mode) => (
          <button
            key={mode}
            style={{
              ...styles.modeBtn,
              background: skillMode === mode ? tokens.accent : tokens.bgElevated,
              color: skillMode === mode ? "#fff" : tokens.textSecondary,
              borderColor: skillMode === mode ? tokens.accent : tokens.border,
            }}
            onClick={() => handleModeChange(mode)}
            title={
              mode === "auto"
                ? "自动匹配当前站点和消息"
                : mode === "all"
                  ? "注入所有技能索引"
                  : "仅使用勾选技能"
            }
          >
            {modeLabels[mode]}
          </button>
        ))}
      </div>
      <div
        style={{
          fontSize: 10,
          color: tokens.textMuted,
          lineHeight: 1.4,
          marginBottom: 8,
        }}
      >
        {skillModeHint}
      </div>

      <div
        style={{
          fontSize: 10,
          color: tokens.textSecondary,
          lineHeight: 1.4,
          marginBottom: 8,
          padding: "6px 8px",
          background: tokens.accentSoft,
          borderRadius: tokens.radiusSm,
          border: `1px solid ${tokens.border}`,
        }}
      >
        <strong style={{ color: tokens.accentText }}>安装技能（推荐）</strong>
        <div style={{ marginTop: 3 }}>
          GitHub 仓库：下载 ZIP → <strong>导入 ZIP</strong>；或解压后用{" "}
          <strong>导入文件夹</strong>。单文件 skill 用「导入」.md。
        </div>
        <div style={{ marginTop: 3, color: tokens.textMuted }}>
          勿用「场景」里的「应用安全审查」装技能 — 那会限制本对话工具。
        </div>
      </div>

      <div style={styles.skillToolbar}>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => chrome.runtime.sendMessage({ type: "skill.refresh" })}
          title="重新扫描技能目录（含 ~/.cmspark-agent/skills 外部变更）"
        >
          ↻ 刷新
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => fileInputRef.current?.click()}
          title="从文件导入 .md"
        >
          📁 导入
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => zipInputRef.current?.click()}
          title="从 ZIP 导入文件夹技能"
        >
          📦 导入 ZIP
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowPathImport(!showPathImport)}
          title="从文件夹导入"
        >
          📂 导入文件夹
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowUrlImport(!showUrlImport)}
          title="从 URL 导入"
        >
          🔗 URL
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".md,.markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportFile(file)
          }}
        />
        <input
          ref={zipInputRef}
          type="file"
          accept=".zip"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportZip(file)
          }}
        />
      </div>

      {showUrlImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="url"
            placeholder="https://...skill.md"
            value={importUrl}
            onChange={(e) => setImportUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleUrlImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handleUrlImport}>
            安装
          </button>
        </div>
      )}

      {showPathImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="text"
            placeholder="~/.claude/skills/datayes-api-search 或绝对路径"
            value={pathInput}
            onChange={(e) => setPathInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handlePathImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handlePathImport}>
            导入
          </button>
        </div>
      )}

      <div
        style={styles.dropZone}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        {skillList.length === 0 && (
          <div style={styles.emptyText}>暂无技能，拖拽 .md 文件或点击导入</div>
        )}
      </div>

      {groupedSkills.map(([groupName, skills]) => (
        <div key={groupName}>
          <div style={styles.groupHeader}>{groupName}</div>
          {skills.map((skill) => {
            const active = state.activeSkillIds.includes(skill.name)
            return (
              <div
                key={skill.name}
                style={{
                  ...styles.skillRow,
                  background: skillManual && active ? tokens.bgActive : "transparent",
                }}
              >
                {skillManual ? (
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={() => {
                      const activeSkillIds = active
                        ? state.activeSkillIds.filter((id) => id !== skill.name)
                        : [...state.activeSkillIds, skill.name]
                      dispatch({ type: "TOGGLE_SKILL", skillId: skill.name })
                      if (state.activeThreadId) {
                        chrome.runtime.sendMessage({
                          type: "thread.update",
                          threadId: state.activeThreadId,
                          updates: { active_skill_ids: activeSkillIds },
                        })
                      }
                    }}
                    style={{ marginRight: 8, flexShrink: 0 }}
                    title="勾选后参与本对话"
                  />
                ) : (
                  <span
                    style={{
                      width: 16,
                      textAlign: "center",
                      color: tokens.textMuted,
                      fontSize: 11,
                      flexShrink: 0,
                      marginRight: 4,
                    }}
                    title={
                      skillMode === "all"
                        ? "全选模式：全部参与索引"
                        : "自动模式：由匹配决定，与勾选无关"
                    }
                    aria-hidden
                  >
                    {skillMode === "all" ? "◎" : "◇"}
                  </span>
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 500,
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    {skill.name}
                    {skill.site && <span style={styles.siteBadge}>{skill.site}</span>}
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      color: tokens.textSecondary,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {skill.description}
                  </div>
                </div>
                {skill.builtin && <span style={styles.badge}>内置</span>}
                {!skill.builtin && (
                  <div
                    style={{ position: "relative" }}
                    ref={menuOpen === skill.name ? menuRef : undefined}
                  >
                    <button
                      style={styles.menuBtn}
                      onClick={() => setMenuOpen(menuOpen === skill.name ? null : skill.name)}
                      title="更多操作"
                    >
                      ···
                    </button>
                    {menuOpen === skill.name && (
                      <div style={styles.menuDropdown}>
                        <button style={styles.menuItem} onClick={() => handleExport(skill.name)}>
                          📤 导出
                        </button>
                        <button
                          style={{ ...styles.menuItem, color: tokens.danger }}
                          onClick={() => handleDelete(skill.name)}
                        >
                          删除
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}

// ── Helpers ────────────────────────────────────────────────────────────────

async function readDirectoryEntry(dirEntry: FileSystemDirectoryEntry): Promise<File[]> {
  const files: File[] = []
  const folderName = dirEntry.name

  async function readDir(entry: FileSystemDirectoryEntry, prefix: string): Promise<void> {
    const reader = entry.createReader()
    const readBatch = (): Promise<FileSystemEntry[]> => {
      return new Promise((resolve) => {
        reader.readEntries((entries) => resolve(entries))
      })
    }

    let batch = await readBatch()
    while (batch.length > 0) {
      for (const e of batch) {
        if (e.isFile) {
          const file = await new Promise<File>((resolve) => {
            ;(e as FileSystemFileEntry).file(resolve)
          })
          ;(file as File & { webkitRelativePath: string }).webkitRelativePath = prefix + e.name
          files.push(file)
        } else if (e.isDirectory) {
          await readDir(e as FileSystemDirectoryEntry, prefix + e.name + "/")
        }
      }
      batch = await readBatch()
    }
  }

  await readDir(dirEntry, folderName + "/")
  return files
}

function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> {
  return arr.reduce(
    (acc, item) => {
      const k = String(item[key] ?? "unknown")
      if (!acc[k]) acc[k] = []
      acc[k].push(item)
      return acc
    },
    {} as Record<string, T[]>,
  )
}

type SkillListItem = {
  name: string
  description?: string
  site?: string
  builtin?: boolean
}

function groupSkillsBySite(
  skills: SkillListItem[],
  currentHostname: string,
): [string, SkillListItem[]][] {
  const list = Array.isArray(skills) ? skills : []
  const globalSkills = list.filter((s) => !s.site)
  const siteGroups = new Map<string, SkillListItem[]>()
  for (const skill of list.filter((s) => s.site)) {
    const key = skill.site!
    if (!siteGroups.has(key)) siteGroups.set(key, [])
    siteGroups.get(key)!.push(skill)
  }
  const result: [string, SkillListItem[]][] = []
  if (globalSkills.length > 0) {
    result.push(["全局", globalSkills])
  }
  const sortedSites = Array.from(siteGroups.entries()).sort((a, b) => {
    const aMatch = currentHostname && matchesSite(a[0], currentHostname) ? -1 : 0
    const bMatch = currentHostname && matchesSite(b[0], currentHostname) ? -1 : 0
    if (aMatch !== bMatch) return aMatch - bMatch
    return a[0].localeCompare(b[0])
  })
  for (const [site, siteSkills] of sortedSites) {
    result.push([site, siteSkills])
  }
  return result
}

function matchesSite(pattern: string, hostname: string): boolean {
  if (pattern.startsWith("*.")) {
    const suffix = pattern.slice(2)
    return hostname === suffix || hostname.endsWith("." + suffix)
  }
  return hostname === pattern
}

// ── Styles (panel body only) ───────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  panel: {
    borderTop: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    // Apps「添加应用」needs room for search + policy + short list
    maxHeight: 320,
    overflowY: "auto",
    flexShrink: 0,
  },
  panelHeader: {
    position: "sticky",
    top: 0,
    zIndex: 2,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    padding: "6px 12px",
    background: tokens.bgElevated,
    borderBottom: `1px solid ${tokens.border}`,
  },
  panelTitle: {
    fontSize: 15,
    fontWeight: 600,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  panelCloseBtn: {
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusPill,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    fontSize: 11,
    fontWeight: 500,
    padding: "3px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
  },
  panelContent: {
    padding: "10px 12px",
  },
  emptyText: {
    color: tokens.textSecondary,
    fontSize: 12,
    textAlign: "center",
    padding: 12,
  },
  tabRow: {
    display: "flex",
    alignItems: "center",
    padding: "3px 0",
    cursor: "pointer",
    fontSize: 12,
  },
  tabTitle: {
    flex: 1,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  tabUrl: {
    color: tokens.textMuted,
    fontSize: 10,
    fontFamily: tokens.fontMono,
  },
  groupHeader: {
    fontSize: 11,
    fontWeight: 600,
    fontFamily: tokens.fontMono,
    color: tokens.accent,
    marginBottom: 2,
  },
  historyRow: {
    display: "flex",
    alignItems: "center",
    padding: "2px 0",
  },
  skillRow: {
    display: "flex",
    alignItems: "center",
    padding: "6px 0",
    borderBottom: `1px solid ${tokens.bgMuted}`,
  },
  badge: {
    fontSize: 10,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    padding: "1px 6px",
    borderRadius: tokens.radiusSm,
  },
  skillToolbar: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
    marginBottom: 8,
  },
  skillToolbarBtn: {
    whiteSpace: "nowrap",
    minHeight: 32,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    background: tokens.bgElevated,
    padding: "3px 10px",
    fontSize: 11,
    cursor: "pointer",
  },
  urlImportRow: {
    display: "flex",
    gap: 4,
    marginBottom: 8,
  },
  urlImportInput: {
    flex: 1,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    padding: "4px 8px",
    fontSize: 11,
    fontFamily: tokens.fontMono,
    outline: "none",
  },
  dropZone: {
    minHeight: 24,
  },
  menuBtn: {
    background: "none",
    border: "none",
    fontSize: 14,
    cursor: "pointer",
    padding: "0 4px",
    color: tokens.textMuted,
  },
  menuDropdown: {
    position: "absolute",
    right: 0,
    top: "100%",
    background: tokens.bgElevated,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: tokens.radiusMenu,
    boxShadow: tokens.shadowLg,
    zIndex: 10,
    overflow: "hidden",
    padding: 4,
    minWidth: 120,
  },
  menuItem: {
    display: "block",
    width: "100%",
    border: "none",
    background: "transparent",
    borderRadius: tokens.radiusMd,
    padding: "8px 12px",
    fontSize: 12,
    cursor: "pointer",
    textAlign: "left" as const,
    whiteSpace: "nowrap" as const,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  modeSwitcher: {
    display: "flex",
    gap: 0,
    marginBottom: 8,
    borderRadius: tokens.radiusSm,
    overflow: "hidden",
    border: `1px solid ${tokens.border}`,
  },
  modeBtn: {
    flex: 1,
    border: "none",
    borderRight: `1px solid ${tokens.border}`,
    padding: "4px 0",
    fontSize: 11,
    cursor: "pointer",
    background: tokens.bgElevated,
  },
  siteBadge: {
    fontSize: 9,
    background: tokens.accentSoft,
    color: tokens.accentText,
    padding: "0px 4px",
    borderRadius: tokens.radiusSm,
    fontWeight: 400,
  },
}

FULL CURRENT FILE chrome-extension/src/sidepanel/components/MeetingPanel.tsx
/**
 * Meeting workbench — Mtg0–Mtg3.
 * SoT: meeting-minutes-design + Mtg3 diarize design.
 * Mtg3: experimental anonymous 发言人N via local feature k-means (NOT identity).
 * Does NOT auto-start mic on pack apply. System audio mix still parking-lot.
 */

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react"
import { useAgentStore } from "../store/agentStore"
import { tokens } from "../ui/tokens"
import { createLocalSttAdapter } from "../voice/local-stt-adapter"
import {
  detectLocalMediaCapture,
  LOCAL_STT_NEAR_REALTIME_SEGMENT_MS,
} from "../voice/local-stt-detect"
import {
  fileToWavSegments,
  transcribeWavViaStt,
} from "../voice/meeting-audio-import"
import {
  loadMeetingTemplate,
  saveMeetingTemplate,
} from "../voice/meeting-template-storage"
import {
  formatMeetingElapsed,
  meetingLiveInterimHint,
  meetingMinutesSendPlan,
  MEETING_DISCONNECT_FINALIZE_MS,
  MEETING_LIVE_HARD_CAP_MS,
  MEETING_LIVE_SOFT_CAP_MS,
  MEETING_MINUTES_WATCHDOG_MS,
  MEETING_NEAR_REALTIME_DEFAULT,
  MEETING_STOP_FAILSAFE_MS,
} from "../voice/meeting-caps"
import { VOICE_DEFAULT_LANG } from "../voice/detect"
import { formatMeetingDiarizeStatus, mapMeetingDiarizeError } from "../voice/meeting-diarize-copy"
import { diarizeViaEmbeddingUpload, wavToRawPcm } from "../voice/meeting-diarize-upload"
import { mapLocalSttError } from "../voice/error-map"
import {
  createSerialRefineQueue,
  formatMeetingSoftSegmentError,
  isMeetingSoftSegmentBanner,
  requestMeetingSegmentRefine,
} from "../voice/meeting-live-refine"
import { VOICE_PRIVACY_ACK_V2_CLAUSES } from "../voice/privacy-copy"
import type { SpeechAdapter } from "../voice/web-speech-adapter"
import { confirmMeetingClose, createMeetingPersistence } from "../voice/meeting-close"

/** Format companion transcript lines for textarea (Speaker: text). */
function formatLinesFromMeeting(transcript: any[]): string {
  if (!Array.isArray(transcript)) return ""
  return transcript
    .map((l) => {
      const t = typeof l?.text === "string" ? l.text : ""
      const sp = typeof l?.speaker === "string" ? l.speaker.trim() : ""
      return sp ? `${sp}: ${t}` : t
    })
    .filter(Boolean)
    .join("\n\n")
}

type CapturePhase = "idle" | "starting" | "recording" | "processing" | "stopping"

function useMeetingMessages(onMsg: (m: any) => void) {
  useEffect(() => {
    const listener = (msg: any) => {
      if (msg && typeof msg.type === "string" && msg.type.startsWith("meeting.")) {
        onMsg(msg)
      }
      return false
    }
    chrome.runtime.onMessage.addListener(listener)
    return () => chrome.runtime.onMessage.removeListener(listener)
  }, [onMsg])
}

function sendViaRuntime(msg: Record<string, unknown>): void {
  try {
    chrome.runtime.sendMessage(msg)
  } catch {
    /* SW missing */
  }
}

function subscribeVoiceStt(handler: (msg: any) => void): () => void {
  if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
    return () => {}
  }
  const listener = (msg: any) => {
    if (msg && typeof msg.type === "string" && msg.type.startsWith("voice.stt.")) {
      handler(msg)
    }
    return false
  }
  chrome.runtime.onMessage.addListener(listener)
  return () => {
    try {
      chrome.runtime.onMessage.removeListener(listener)
    } catch {
      /* */
    }
  }
}

/** #260: imperative one-shot subscribe for meeting.* (upload client state machine). */
function subscribeMeetingRuntime(handler: (msg: any) => void): () => void {
  if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
    return () => {}
  }
  const listener = (msg: any) => {
    if (msg && typeof msg.type === "string" && (msg.type.startsWith("meeting.") || msg.type === "error")) {
      handler(msg)
    }
    return false
  }
  chrome.runtime.onMessage.addListener(listener)
  return () => {
    try {
      chrome.runtime.onMessage.removeListener(listener)
    } catch {
      /* */
    }
  }
}

const formatElapsed = formatMeetingElapsed

export function MeetingPanel(props: {
  onClose: () => void
  onSendToDraft: (text: string) => void
  registerBeforeClose?: (guard: () => Promise<boolean>) => () => void
}) {
  const { state, dispatch } = useAgentStore()
  const [title, setTitle] = useState("")
  const [transcript, setTranscript] = useState("")
  const [minutesMd, setMinutesMd] = useState("")
  const [meetingId, setMeetingId] = useState<string | null>(null)
  const [status, setStatus] = useState<string>("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [closing, setClosing] = useState(false)
  const savingTranscriptRef = useRef(false)
  const saveFinishedRef = useRef<Promise<boolean> | null>(null)
  const persistenceRef = useRef(createMeetingPersistence({
    subscribe: subscribeMeetingRuntime,
    send: (message, callback) => chrome.runtime.sendMessage(message, callback),
  }))
  const [ack, setAck] = useState(false)
  const [capturePhase, setCapturePhase] = useState<CapturePhase>("idle")
  const [elapsedMs, setElapsedMs] = useState(0)
  const [softCapHint, setSoftCapHint] = useState(false)
  /** P1: progressive hypothesis text (not yet committed to transcript). */
  const [interimText, setInterimText] = useState("")
  const [pendingGenerate, setPendingGenerate] = useState(false)
  /** Mtg2: optional default speaker for STT append / bulk label (manual only). */
  const [defaultSpeaker, setDefaultSpeaker] = useState("")
  const [importStatus, setImportStatus] = useState<string | null>(null)
  const textFileRef = useRef<HTMLInputElement | null>(null)
  const audioFileRef = useRef<HTMLInputElement | null>(null)
  const defaultSpeakerRef = useRef("")
  const importAbortRef = useRef(false)
  const importDoneRef = useRef<Promise<boolean> | null>(null)
  /** Skip server→textarea sync while user is typing (dual-review dirty-guard). */
  const transcriptDirtyRef = useRef(false)
  /** #260: per-line raw s16le PCM from last audio import (aligned with append order). */
  const linePcmRef = useRef<Uint8Array[]>([])
  const [diarizeK, setDiarizeK] = useState(0)
  const [autoDiarizeAfterImport, setAutoDiarizeAfterImport] = useState(false)
  /** Optional markdown template for minutes structure (chrome.storage). */
  const [templateMd, setTemplateMd] = useState("")
  const templateMdRef = useRef("")
  /** After stop: re-run silence-cut / soft paragraph split on full transcript. */
  const [autoSegmentOnStop, setAutoSegmentOnStop] = useState(true)
  const autoSegmentOnStopRef = useRef(true)
  /** Live segment AI refine in flight (opt-in via asrRefinerEnabled). */
  const [refinePending, setRefinePending] = useState(0)

  const adapterRef = useRef<SpeechAdapter | null>(null)
  const captureStartRef = useRef<number | null>(null)
  const meetingIdRef = useRef<string | null>(null)
  const phaseRef = useRef<CapturePhase>("idle")
  const wantGenerateRef = useRef(false)
  const transcriptRef = useRef("")
  /** Prevent double meeting.end / finalize. */
  const finalizedRef = useRef(false)
  const finalizingRef = useRef(false)
  const closePendingRef = useRef<Promise<boolean> | null>(null)
  const captureFinishedRef = useRef<((ok: boolean) => void) | null>(null)
  const closeFailureRef = useRef(false)
  const needsClosePersistenceRef = useRef(false)
  const closeMeetingIdRef = useRef<string | null>(null)
  const closeNeedsEndRef = useRef(true)
  const liveTextRef = useRef<string[]>([])
  const cancelStartingRef = useRef(false)
  const requestCloseRef = useRef<() => Promise<boolean>>(async () => true)
  const titleRef = useRef(title)
  const refineGenRef = useRef(0)
  const refineQueueRef = useRef(createSerialRefineQueue())
  const asrRefinerEnabledRef = useRef(false)
  const companionConnectedRef = useRef(false)
  /** Companion died after 「结束并生成纪要」: retry when WS is back. */
  const retryGenerateOnReconnectRef = useRef(false)

  meetingIdRef.current = meetingId
  transcriptRef.current = transcript
  titleRef.current = title
  phaseRef.current = capturePhase
  defaultSpeakerRef.current = defaultSpeaker
  templateMdRef.current = templateMd
  autoSegmentOnStopRef.current = autoSegmentOnStop
  asrRefinerEnabledRef.current = state.asrRefinerEnabled === true

  const companionConnected = state.connectionState === "connected"
  companionConnectedRef.current = companionConnected
  const activeModelId = state.voiceModel?.localModelId || "medium"
  const localModelReady = state.voiceModel?.models?.[activeModelId]?.status === "ready"
  const localBinaryReady = state.voiceModel?.binary?.status === "ready"
  /** #260: speaker-embedding diarize model (未就绪必须显式引导下载，不静默落回). */
  const diarizeModelReady = state.voiceModel?.diarizeModel?.status === "ready"
  /** P1: near-rt defaults on; honor global voiceRealtimeStreaming toggle. */
  const nearRealtime =
    MEETING_NEAR_REALTIME_DEFAULT &&
    state.voiceRealtimeStreaming !== false &&
    activeModelId !== "large-v3-turbo"
  const localMedia = detectLocalMediaCapture(
    typeof globalThis !== "undefined" ? (globalThis as any) : {},
  )
  const capturing =
    capturePhase === "recording" ||
    capturePhase === "processing" ||
    capturePhase === "starting" ||
    capturePhase === "stopping"

  const setPhase = useCallback((p: CapturePhase) => {
    phaseRef.current = p
    setCapturePhase(p)
  }, [])

  useEffect(() => {
    try {
      chrome.storage.local.get("meeting_privacy_ack_v1", (r) => {
        if (r.meeting_privacy_ack_v1 === true) setAck(true)
      })
    } catch {
      /* */
    }
  }, [])

  const templateLoadedRef = useRef(false)
  useEffect(() => {
    let cancelled = false
    void loadMeetingTemplate().then((t) => {
      if (cancelled) return
      setTemplateMd(t)
      templateMdRef.current = t
      templateLoadedRef.current = true
    })
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    if (!templateLoadedRef.current) return
    const t = setTimeout(() => {
      saveMeetingTemplate(templateMd)
    }, 300)
    return () => clearTimeout(t)
  }, [templateMd])

  useEffect(() => {
    if (!companionConnected) return
    try {
      chrome.runtime.sendMessage({ type: "voice.model.get_state" })
    } catch {
      /* */
    }
  }, [companionConnected])

  useEffect(() => {
    if (!capturing) return
    const id = setInterval(() => {
      if (captureStartRef.current != null) {
        const ms = Date.now() - captureStartRef.current
        setElapsedMs(ms)
        if (ms >= MEETING_LIVE_SOFT_CAP_MS) setSoftCapHint(true)
      }
    }, 250)
    return () => clearInterval(id)
  }, [capturing])

  useEffect(() => {
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: capturing })
    return () => {
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    }
  }, [capturing, dispatch])

  /** Tear down adapter without onEnd (destroy is silent; abort would re-enter finalize). */
  const destroyAdapter = useCallback(() => {
    const a = adapterRef.current
    adapterRef.current = null
    if (!a) return
    try {
      a.destroy()
    } catch {
      /* */
    }
  }, [])

  const appendLocalAndRemote = useCallback(
    (
      chunk: string,
      id: string | null,
      source: "stt" | "asr_refiner" = "stt",
    ) => {
      const t = chunk.trim()
      if (!t) return
      transcriptDirtyRef.current = true
      liveTextRef.current.push(t)
      const sp = defaultSpeakerRef.current.trim().slice(0, 32)
      const display = sp ? `${sp}: ${t}` : t
      setTranscript((prev) => {
        // Live STT: blank-line between segments = smart paragraph boundary
        const next = prev ? `${prev}\n\n${display}` : display
        transcriptRef.current = next
        return next
      })
      if (id) {
        void persistenceRef.current.write(id, "meeting.append_transcript", {
          text: t,
          source,
          speaker: sp || undefined,
        })
      }
    },
    [],
  )

  /**
   * Commit a live STT final: optional ADR-024 refine with prior transcript context,
   * then append (paragraph-separated). Serial queue preserves order.
   * Pin meeting id at enqueue so late refine never appends to a newer meeting (Pi nit).
   */
  const commitLiveSegment = useCallback(
    (finalChunk: string, meetingIdForAppend: string) => {
      const raw = finalChunk.trim()
      if (!raw) return
      const pinnedId = meetingIdForAppend
      const wantRefine = asrRefinerEnabledRef.current
      if (!wantRefine) {
        appendLocalAndRemote(raw, pinnedId, "stt")
        return
      }
      refineGenRef.current += 1
      const gen = refineGenRef.current
      const sid = `mtg-refine-${pinnedId}-${gen}`
      const prior = transcriptRef.current
      setRefinePending((n) => n + 1)
      void refineQueueRef.current
        .enqueue(async () => {
          const { text, refined } = await requestMeetingSegmentRefine({
            sessionId: sid,
            refineGen: gen,
            text: raw,
            priorTranscript: prior,
          })
          // Always pin to the meeting that owned this segment (not meetingIdRef after await)
          appendLocalAndRemote(
            text || raw,
            pinnedId,
            refined ? "asr_refiner" : "stt",
          )
        })
        .finally(() => {
          setRefinePending((n) => Math.max(0, n - 1))
        })
    },
    [appendLocalAndRemote],
  )

  /**
   * Fire minutes job or defer until Companion is back.
   * Product adversary B1: dropped WS send used to leave 「生成中…」 forever.
   */
  const sendMinutesJob = useCallback((id: string | null) => {
    if (meetingMinutesSendPlan(companionConnectedRef.current) === "defer-reconnect") {
      retryGenerateOnReconnectRef.current = true
      setBusy(false)
      setPendingGenerate(false)
      setError(
        (prev) =>
          prev ||
          "Companion 未连接；转写已保留，重连后将自动生成纪要（也可手动点「生成会议纪要」）",
      )
      return
    }
    retryGenerateOnReconnectRef.current = false
    setBusy(true)
    setPendingGenerate(true)
    sendViaRuntime({
      type: "meeting.generate_minutes",
      v: 1,
      id: id || undefined,
      text: transcriptRef.current.trim() || undefined,
      template_md: templateMdRef.current.trim() || undefined,
    })
  }, [])

  /**
   * End server session + tear down adapter. Idempotent via finalizedRef.
   * Drains in-flight AI refine before end / silence-cut / minutes (dual-review nit #2).
   */
  const finalizeCapture = useCallback(
    (opts: { generate: boolean; id: string | null }) => {
      if (finalizedRef.current) return
      finalizedRef.current = true
      finalizingRef.current = true
      captureStartRef.current = null
      setPhase("idle")
      setSoftCapHint(false)
      destroyAdapter()
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })

      const id = opts.id || meetingIdRef.current
      const wantGenerate = opts.generate
      const wantSegment = autoSegmentOnStopRef.current

      void (async () => {
        // Wait for segment refine queue (cap ~22s) so minutes see refined text
        try {
          const drained = await refineQueueRef.current.drain()
          if (!drained && closePendingRef.current) {
            closeFailureRef.current = true
            setError("最后一段仍在纠错，请等待转写完成后重试收起")
          }
          if (!drained && wantGenerate) {
            setError((prev) =>
              prev ||
              "部分 AI 纠错未在时限内完成；纪要将基于当前转写（可稍后重新生成）",
            )
          }
        } catch {
          /* best-effort */
        }

        if (id && !closePendingRef.current) {
          sendViaRuntime({ type: "meeting.end", v: 1, id })
        }
        // Smart segment after refine drain so silence-cut sees full refined blob
        if (wantSegment && id && transcriptRef.current.trim() && !closePendingRef.current) {
          sendViaRuntime({
            type: "meeting.apply_silence_cut",
            v: 1,
            id,
            text: transcriptRef.current,
          })
        }
        if (wantGenerate) {
          // Brief beat for silence-cut server apply before minutes job
          await new Promise((r) => setTimeout(r, 150))
          sendMinutesJob(id)
        }
      })().finally(() => {
        finalizingRef.current = false
        captureFinishedRef.current?.(!closeFailureRef.current)
        captureFinishedRef.current = null
      })
    },
    [destroyAdapter, dispatch, sendMinutesJob, setPhase],
  )

  // Companion restart mid-window used to leave phase=stopping forever
  // (adapter awaited a voice.stt.end ACK that never arrived). Force-finalize.
  useEffect(() => {
    if (capturePhase !== "stopping") return
    const t = setTimeout(() => {
      if (phaseRef.current !== "stopping" || finalizedRef.current) return
      closeFailureRef.current = true
      setError((prev) => prev || "结束超时：已停止录制。可基于已有转写生成纪要")
      const gen = wantGenerateRef.current
      wantGenerateRef.current = false
      finalizeCapture({ generate: gen, id: meetingIdRef.current })
    }, MEETING_STOP_FAILSAFE_MS)
    return () => clearTimeout(t)
  }, [capturePhase, finalizeCapture])

  // Debounced disconnect: WS auth blips (~1s) must not kill capture; a real
  // Companion death (SIGTERM ~18s this incident) must not leave 「正在听」.
  useEffect(() => {
    if (companionConnected) return
    if (phaseRef.current === "idle") return
    const t = setTimeout(() => {
      if (finalizedRef.current) return
      if (phaseRef.current === "idle") return
      closeFailureRef.current = true
      setError((prev) => prev || "Companion 断开，已停止录制。可基于已有转写生成纪要")
      const gen = wantGenerateRef.current
      wantGenerateRef.current = false
      finalizeCapture({ generate: gen, id: meetingIdRef.current })
    }, MEETING_DISCONNECT_FINALIZE_MS)
    return () => clearTimeout(t)
  }, [companionConnected, finalizeCapture])

  useEffect(() => {
    if (!companionConnected) return
    if (!retryGenerateOnReconnectRef.current) return
    if (phaseRef.current !== "idle") return
    retryGenerateOnReconnectRef.current = false
    sendMinutesJob(meetingIdRef.current)
  }, [companionConnected, sendMinutesJob])

  useEffect(() => {
    if (!pendingGenerate) return
    const t = setTimeout(() => {
      setPendingGenerate(false)
      setBusy(false)
      retryGenerateOnReconnectRef.current = false
      setError((prev) => prev || "纪要生成超时。转写已保留，可再点「生成会议纪要」")
    }, MEETING_MINUTES_WATCHDOG_MS)
    return () => clearTimeout(t)
  }, [pendingGenerate])

  const startLocalSegments = useCallback(
    (id: string) => {
      closeMeetingIdRef.current = id
      destroyAdapter()
      finalizedRef.current = false

      if (!localMedia.ok) {
        setError("当前环境无法访问麦克风（getUserMedia）")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }
      if (!state.voicePrivacyAckV2) {
        setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }
      if (!localModelReady || !localBinaryReady) {
        setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型后再开始会议录音。")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }

      const adapter = createLocalSttAdapter(
        {
          onStart: () => {
            captureStartRef.current = Date.now()
            setPhase("recording")
            setElapsedMs(0)
            setError(null)
            setInterimText("")
          },
          onResult: ({ interim, finalChunk }) => {
            if (finalChunk?.trim()) {
              setInterimText("")
              commitLiveSegment(finalChunk, id)
              return
            }
            // Progressive hypothesis only (M2); do not append until window final.
            // Empty interim is a soft/empty window — keep last visible text.
            if (typeof interim === "string" && interim.trim()) {
              setInterimText(interim)
            }
          },
          onError: (code) => {
            if (code === "aborted") return
            const mapped = mapLocalSttError(code)
            if (mapped.severity === "silent") return
            if (closePendingRef.current) closeFailureRef.current = true
            // Soft = adapter continues; honest copy (segment+audio irreversibly lost).
            const soft = isMeetingSoftSegmentBanner(code)
            const msg = mapped.message || `转写错误: ${code}`
            setError(soft ? formatMeetingSoftSegmentError(msg) : msg)
          },
          onEnd: () => {
            setInterimText("")
            const gen = wantGenerateRef.current
            wantGenerateRef.current = false
            if (phaseRef.current === "idle" && finalizedRef.current) return
            finalizeCapture({ generate: gen, id })
          },
          onSegmentContinue: () => {
            if (phaseRef.current !== "stopping") setPhase("recording")
          },
          onCaptureStopped: () => {
            if (phaseRef.current !== "stopping") setPhase("processing")
          },
        },
        {
          send: sendViaRuntime,
          onMessage: subscribeVoiceStt,
          modelId: activeModelId,
          // The panel owns the visible stop deadline. Do not let the adapter's
          // shorter quiet-empty timeout turn an unfinished final into success.
          stopGraceMs: MEETING_STOP_FAILSAFE_MS + 1_000,
        },
      )
      adapterRef.current = adapter
      const sid = `mtg-${id}-${Date.now().toString(36)}`
      // STT slot is force-aborted on companion by meeting.start — do not send
      // voice.stt.abort with a fake sessionId (e.g. "mtg-preempt") from the client.
      // P1 near-rt: streamPartial + ~8s windows; P2 hard cap independent of dictation 15/30m.
      adapter.start({
        lang: VOICE_DEFAULT_LANG,
        sessionId: sid,
        modelId: activeModelId,
        mode: "continuous",
        hardCapMs: MEETING_LIVE_HARD_CAP_MS,
        segmentMs: nearRealtime ? LOCAL_STT_NEAR_REALTIME_SEGMENT_MS : undefined,
        streamPartial: nearRealtime,
      })
    },
    [
      activeModelId,
      commitLiveSegment,
      destroyAdapter,
      finalizeCapture,
      localBinaryReady,
      localMedia.ok,
      localModelReady,
      nearRealtime,
      setPhase,
      state.voicePrivacyAckV2,
    ],
  )

  const startLocalSegmentsRef = useRef(startLocalSegments)
  startLocalSegmentsRef.current = startLocalSegments

  // Unmount / ContextPanelHost 收起: always end server session if still capturing
  // (destroy() is silent and would otherwise leave status=recording — dual-review nit).
  useEffect(() => {
    return () => {
      const id = meetingIdRef.current
      importAbortRef.current = true
      captureFinishedRef.current?.(false)
      captureFinishedRef.current = null
      const stillLive = phaseRef.current !== "idle" && !finalizedRef.current
      if (stillLive && id) {
        finalizedRef.current = true
        sendViaRuntime({ type: "meeting.end", v: 1, id })
      }
      destroyAdapter()
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    }
  }, [destroyAdapter, dispatch])

  const onMsg = useCallback(
    (msg: any) => {
      // Correlated persistence operations own their errors and busy lifecycle.
      // An append failure is recoverable text, not a failed PCM finalization.
      if (typeof msg.id === "string" && msg.id.startsWith("meeting-rpc-") &&
          (msg.type === "meeting.updated" || msg.type === "meeting.error")) return
      if (msg.type === "meeting.created" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || "")
        setStatus(msg.meeting.status || "draft")
        if (!savingTranscriptRef.current) setBusy(false)
      }
      if (msg.type === "meeting.started" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        meetingIdRef.current = msg.meeting.id
        setTitle(msg.meeting.title || titleRef.current)
        setStatus(msg.meeting.status || "recording")
        if (cancelStartingRef.current) {
          cancelStartingRef.current = false
          closeMeetingIdRef.current = msg.meeting.id
          finalizedRef.current = false
          finalizeCapture({ generate: false, id: msg.meeting.id })
        } else if (phaseRef.current === "starting") {
          startLocalSegmentsRef.current(msg.meeting.id)
        }
      }
      if (msg.type === "meeting.ended" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        let st = msg.meeting.status || "ready"
        if (msg.audio_deleted === true) st = `${st} · 音频已按默认策略删除`
        setStatus(st)
      }
      if (msg.type === "meeting.updated" && msg.meeting) {
        if (msg.meeting.id !== meetingIdRef.current) return
        setMeetingId(msg.meeting.id)
        setStatus(msg.meeting.status)
        // Only push server transcript when explicit cut/import ops or textarea not dirty.
        // During live capture, local appends own the textarea — a stale
        // meeting.updated (append N-1 arriving after local N) used to flicker
        // or drop the newest line.
        const live =
          phaseRef.current === "recording" ||
          phaseRef.current === "processing" ||
          phaseRef.current === "starting" ||
          phaseRef.current === "stopping"
        const forceSync = msg.cut === true && !persistenceRef.current.hasUnconfirmedWrites(msg.meeting.id)
        if (
          Array.isArray(msg.meeting.transcript) &&
          msg.meeting.transcript.length > 0 &&
          (forceSync || (!transcriptDirtyRef.current && !live))
        ) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          if (formatted) {
            setTranscript(formatted)
            transcriptRef.current = formatted
            if (forceSync) transcriptDirtyRef.current = false
          }
        }
        if (msg.meeting.minutes?.raw_md) setMinutesMd(msg.meeting.minutes.raw_md)
        if (!savingTranscriptRef.current) setBusy(false)
      }
      if (msg.type === "meeting.imported" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || titleRef.current)
        setStatus(msg.meeting.status || "ready")
        if (Array.isArray(msg.meeting.transcript)) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          setTranscript(formatted)
          transcriptRef.current = formatted
          transcriptDirtyRef.current = false
        }
        linePcmRef.current = []
        setBusy(false)
        setImportStatus("已导入转写文件")
      }
      if (msg.type === "meeting.diarized" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setStatus(msg.meeting.status || "ready")
        if (Array.isArray(msg.meeting.transcript)) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          setTranscript(formatted)
          transcriptRef.current = formatted
          transcriptDirtyRef.current = false
        }
        setBusy(false)
        const method = msg.diarize?.method || msg.meeting.diarize?.method
        const kRaw = msg.diarize?.k ?? msg.meeting.diarize?.k
        const k = typeof kRaw === "number" && Number.isFinite(kRaw) ? Math.floor(kRaw) : null
        setImportStatus(formatMeetingDiarizeStatus(method, k))
        if (k != null && k >= 2 && k <= 6) setDiarizeK(k)
      }
      if (msg.type === "meeting.minutes_result") {
        if (msg.minutes?.raw_md) setMinutesMd(msg.minutes.raw_md)
        if (msg.meeting?.id) {
          setMeetingId(msg.meeting.id)
          setStatus(msg.meeting.status || "done")
        }
        setBusy(false)
        setPendingGenerate(false)
        setError(null)
      }
      if (msg.type === "meeting.error") {
        if (closePendingRef.current) closeFailureRef.current = true
        setError(msg.message || msg.code || "error")
        setBusy(false)
        setPendingGenerate(false)
        if (
          msg.code === "need_privacy_ack" ||
          msg.code === "already_recording" ||
          phaseRef.current === "starting"
        ) {
          setPhase("idle")
          destroyAdapter()
          dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
          captureFinishedRef.current?.(false)
          captureFinishedRef.current = null
        }
      }
    },
    [destroyAdapter, dispatch, setPhase, finalizeCapture],
  )

  useMeetingMessages(onMsg)

  const ensureAck = () => {
    if (ack) return true
    setError("请先确认会议隐私说明（生成纪要会将转写文本发给已配置的 LLM）")
    return false
  }

  const acceptAck = () => {
    setAck(true)
    try {
      chrome.storage.local.set({ meeting_privacy_ack_v1: true })
    } catch {
      /* */
    }
    setError(null)
  }

  const createMeeting = () => {
    setBusy(true)
    setError(null)
    sendViaRuntime({
      type: "meeting.create",
      v: 1,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
    })
  }

  const startLiveCapture = () => {
    if (!ensureAck()) return
    if (!companionConnected) {
      setError("Companion 未连接")
      return
    }
    if (state.dictationCaptureActive) {
      setError("听写进行中，请先结束听写再开始会议录音（全局同时仅一路本机 STT）")
      return
    }
    if (capturing) return
    if (!localMedia.ok) {
      setError("当前环境无法访问麦克风")
      return
    }
    if (!state.voicePrivacyAckV2) {
      setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
      return
    }
    if (!localModelReady || !localBinaryReady) {
      setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型。")
      try {
        chrome.runtime.sendMessage({ type: "voice.model.get_state" })
      } catch {
        /* */
      }
      return
    }

    setError(null)
    setMinutesMd("")
    setPhase("starting")
    setSoftCapHint(false)
    wantGenerateRef.current = false
    finalizedRef.current = false
    closeFailureRef.current = false
    needsClosePersistenceRef.current = true
    closeMeetingIdRef.current = meetingId
    closeNeedsEndRef.current = true
    liveTextRef.current = []
    cancelStartingRef.current = false

    sendViaRuntime({
      type: "meeting.start",
      v: 1,
      id: meetingId || undefined,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
      privacy_ack_v1: true,
      audio_retained: false,
    })
  }

  const stopLiveCapture = (andGenerate: boolean) => {
    if (phaseRef.current === "idle" || phaseRef.current === "stopping") return
    setPhase("stopping")
    wantGenerateRef.current = andGenerate
    const a = adapterRef.current
    if (!a) {
      finalizeCapture({ generate: andGenerate, id: meetingId })
      return
    }
    try {
      a.stop()
    } catch {
      finalizeCapture({ generate: andGenerate, id: meetingId })
    }
  }

  requestCloseRef.current = () => {
    if (closePendingRef.current) return closePendingRef.current
    const pending = Promise.resolve().then(async () => {
      setClosing(true)
      closeFailureRef.current = false
      try {
        if (saveFinishedRef.current && !await saveFinishedRef.current) {
          throw new Error("转写保存未确认，草稿仍保留。请重试保存后再收起")
        }
        if (importDoneRef.current) {
          importAbortRef.current = true
          setImportStatus("正在中止导入并保存当前段…")
          const done = importDoneRef.current
          const finished = await new Promise<boolean>(resolve => {
            const timer = setTimeout(() => resolve(false), MEETING_STOP_FAILSAFE_MS)
            void done.then(ok => { clearTimeout(timer); resolve(ok) })
          })
          if (!finished) throw new Error("导入尚未完整结束，已保留面板。请等待当前段完成后重试收起")
        }
        if (phaseRef.current !== "idle" || finalizingRef.current) {
          const finished = new Promise<boolean>(resolve => { captureFinishedRef.current = resolve })
          if (phaseRef.current === "starting" && !adapterRef.current) {
            // Wait for meeting.started, then end without opening the microphone.
            cancelStartingRef.current = true
            setPhase("stopping")
          } else {
            stopLiveCapture(false)
          }
          if (!await finished) throw new Error("最后一段未完整处理，已保留面板和现有转写。请检查提示后重试收起")
        }
        if (needsClosePersistenceRef.current) {
          if (!await refineQueueRef.current.drain()) throw new Error("转写仍在纠错，请稍后重试收起")
          const id = closeMeetingIdRef.current
          if (!id) throw new Error("会议尚未创建完成，请稍后重试收起")
          await confirmMeetingClose({
            id,
            endRecording: closeNeedsEndRef.current,
            persistence: persistenceRef.current,
          })
          needsClosePersistenceRef.current = false
        }
        return true
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "保存失败，已保留面板，请重试")
        return false
      } finally {
        setClosing(false)
        closePendingRef.current = null
      }
    })
    closePendingRef.current = pending
    return pending
  }

  useEffect(() => props.registerBeforeClose?.(() => requestCloseRef.current()), [props.registerBeforeClose])

  const ensureMeetingIdThen = (then: (id: string) => void, onFailure?: () => void) => {
    if (meetingId) {
      then(meetingId)
      return
    }
    // Create then wait for meeting.created — fire create and use one-shot listener
    const timer = setTimeout(() => {
      chrome.runtime.onMessage.removeListener(listener)
      onFailure?.()
    }, 8000)
    const listener = (msg: any) => {
      if (msg?.type === "meeting.created" && msg.meeting?.id) {
        chrome.runtime.onMessage.removeListener(listener)
        clearTimeout(timer)
        setMeetingId(msg.meeting.id)
        then(msg.meeting.id)
      }
      return false
    }
    chrome.runtime.onMessage.addListener(listener)
    sendViaRuntime({
      type: "meeting.create",
      v: 1,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
    })
  }

  const applySilenceCut = () => {
    if (!ensureAck()) return
    if (!meetingId && !transcript.trim()) {
      setError("没有可分段的转写")
      return
    }
    setBusy(true)
    setError(null)
    ensureMeetingIdThen((id) => {
      // Single WS: server applies text then silence-cut (no client setTimeout race)
      sendViaRuntime({
        type: "meeting.apply_silence_cut",
        v: 1,
        id,
        text: transcriptRef.current.trim() || undefined,
      })
      setImportStatus("已应用智能分段（静音/段落切分；说话人仍可手动标）")
    })
  }

  const bulkLabelSpeaker = () => {
    if (!ensureAck()) return
    const sp = defaultSpeaker.trim().slice(0, 32)
    if (!sp) {
      setError("请先填写默认说话人标签（如「我」）")
      return
    }
    if (!meetingId && !transcript.trim()) {
      setError("没有可标注的转写")
      return
    }
    setBusy(true)
    ensureMeetingIdThen((id) => {
      sendViaRuntime({
        type: "meeting.bulk_speaker",
        v: 1,
        id,
        speaker: sp,
        text: transcriptRef.current.trim() || undefined,
      })
      setImportStatus(`已将全部行标为「${sp}」（手动，非自动分离）`)
    })
  }

  const onImportTextFile = async (file: File | null) => {
    if (!file) return
    if (!ensureAck()) return
    setError(null)
    setBusy(true)
    setImportStatus(`读取 ${file.name}…`)
    try {
      const text = await file.text()
      if (!text.trim()) {
        setError("文件为空")
        setBusy(false)
        setImportStatus(null)
        return
      }
      const truncated = text.length > 80_000
      sendViaRuntime({
        type: "meeting.import_text",
        v: 1,
        id: meetingId || undefined,
        title: title || file.name.replace(/\.[^.]+$/, ""),
        thread_id: state.activeThreadId || undefined,
        privacy_ack_v1: true,
        text: text.slice(0, 80_000),
      })
      if (truncated) {
        setImportStatus("已截断至 80000 字后导入（文件过长）")
      }
    } catch {
      setError("读取文本文件失败")
      setBusy(false)
      setImportStatus(null)
    }
  }

  const onImportAudioFile = async (file: File | null) => {
    if (!file) return
    if (!ensureAck()) return
    if (!companionConnected) {
      setError("Companion 未连接")
      return
    }
    if (state.dictationCaptureActive || capturing) {
      setError("听写或会议录音进行中，请先结束后再导入音频")
      return
    }
    if (!state.voicePrivacyAckV2) {
      setError("导入音频需先确认「本机语音隐私说明」（见下方卡片，或设置 → 输入与语音 → 启用本机转写）")
      return
    }
    if (!localModelReady || !localBinaryReady) {
      setError("本机转写模型或二进制未就绪")
      return
    }

    setError(null)
    setBusy(true)
    importAbortRef.current = false
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: true })
    setImportStatus("解码音频…")
    let resolveImport!: (ok: boolean) => void
    let importSucceeded = true
    importDoneRef.current = new Promise<boolean>(resolve => { resolveImport = resolve })

    try {
    const decoded = await fileToWavSegments(file)
    if (importAbortRef.current) return
    if (decoded.ok === false) {
      importSucceeded = false
      setError(decoded.message)
      setBusy(false)
      setImportStatus(null)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      return
    }

    // Ensure meeting exists
    let id = meetingId
    if (!id) {
      id = await new Promise<string | null>((resolve) => {
        const listener = (msg: any) => {
          if (msg?.type === "meeting.created" && msg.meeting?.id) {
            chrome.runtime.onMessage.removeListener(listener)
            resolve(msg.meeting.id as string)
          }
          return false
        }
        chrome.runtime.onMessage.addListener(listener)
        sendViaRuntime({
          type: "meeting.create",
          v: 1,
          title: title || file.name.replace(/\.[^.]+$/, ""),
          thread_id: state.activeThreadId || undefined,
        })
        setTimeout(() => {
          try {
            chrome.runtime.onMessage.removeListener(listener)
          } catch {
            /* */
          }
          resolve(null)
        }, 8000)
      })
      if (id) setMeetingId(id)
    }
    if (!id) {
      importSucceeded = false
      setError("无法创建会议会话")
      setBusy(false)
      setImportStatus(null)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      return
    }
    closeMeetingIdRef.current = id
    closeNeedsEndRef.current = false
    needsClosePersistenceRef.current = true
    liveTextRef.current = []

    const total = decoded.segments.length
    let failedAt: number | null = null
    let done = 0
    const pcms: Uint8Array[] = []
    const texts: string[] = []
    setImportStatus(`本机转写 0/${total} 段…`)
    for (let i = 0; i < total; i++) {
      if (importAbortRef.current) break
      const seg = decoded.segments[i]!
      setImportStatus(`本机转写 ${i + 1}/${total} 段…`)
      const sid = `mtg-imp-${id}-${i}-${Date.now().toString(36)}`
      const r = await transcribeWavViaStt({
        wav: seg.wav,
        sessionId: sid,
        modelId: activeModelId,
        send: sendViaRuntime,
        onMessage: subscribeVoiceStt,
      })
      if (r.ok === false) {
        importSucceeded = false
        failedAt = i + 1
        setError(`音频第 ${i + 1} 段转写失败: ${r.code}`)
        break
      }
      if (r.text.trim()) {
        // One physical line per segment so PCM stays aligned (dual-review nit)
        const oneLine = r.text.trim().replace(/\s*\n+\s*/g, " ")
        texts.push(oneLine)
        pcms.push(wavToRawPcm(seg.wav))
        // local preview (speaker optional)
        appendLocalAndRemote(oneLine, null)
      }
      done = i + 1
    }
    linePcmRef.current = pcms

    // Single set_transcript so line count == features (avoid append race before diarize)
    if (texts.length > 0 && id) {
      const sp = defaultSpeakerRef.current.trim().slice(0, 32)
      const body = texts.join("\n")
      void persistenceRef.current.write(id, "meeting.set_transcript", {
        text: body,
        source: "stt",
        silence_cut: false,
      })
      // Restore default-speaker when not auto-diarizing (Mtg2 contract)
      if (sp && !autoDiarizeAfterImport) {
        setTimeout(() => {
          sendViaRuntime({
            type: "meeting.bulk_speaker",
            v: 1,
            id,
            speaker: sp,
          })
        }, 100)
      }
    }

    setBusy(false)
    if (importAbortRef.current) {
      setImportStatus(`导入已中止（已完成 ${done}/${total} 段）`)
    } else if (failedAt != null) {
      setImportStatus(`导入部分失败（成功 ${done}/${total} 段，失败于第 ${failedAt} 段）`)
    } else {
      setImportStatus(`音频导入完成 ${done}/${total} 段`)
      if (autoDiarizeAfterImport && pcms.length >= 2 && id) {
        // embedding 引擎；模型未就绪 → 显式引导下载（#260 硬约束，不静默落回）
        if (!diarizeModelReady) {
          setError(mapMeetingDiarizeError("embedding_model_required"))
        } else {
          setBusy(true)
          await runUploadDiarize(id, pcms, "embedding")
        }
      }
    }
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    } catch {
      importSucceeded = false
      setError("音频导入失败，已保留面板和现有转写")
    } finally {
      setBusy(false)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      importDoneRef.current = null
      resolveImport(importSucceeded)
    }
  }

  /**
   * #260 PCM 上传自动标说话人：embedding = companion ONNX 说话人嵌入聚类；
   * audio_cluster = 旧版 3 维声学特征显式回退（区分度低 · 无需模型）。
   * 成功态由 meeting.diarized 运行时处理器收尾（busy/importStatus）。
   */
  const runUploadDiarize = async (
    id: string,
    pcmSegments: Uint8Array[],
    mode: "embedding" | "audio_cluster",
  ): Promise<boolean> => {
    if (mode === "embedding" && !diarizeModelReady) {
      setError(mapMeetingDiarizeError("embedding_model_required"))
      setBusy(false)
      return false
    }
    setBusy(true)
    setError(null)
    const label = mode === "embedding" ? "说话人嵌入" : "旧版 3 维特征"
    setImportStatus(`${label} 0/${pcmSegments.length} 段…`)
    const r = await diarizeViaEmbeddingUpload({
      meetingId: id,
      pcmSegments,
      k: diarizeK,
      mode,
      send: sendViaRuntime,
      onMessage: subscribeMeetingRuntime,
      onProgress: (p) => setImportStatus(`${label} ${p.done}/${p.total} 段…`),
    })
    if (r.ok === false) {
      setError(mapMeetingDiarizeError(r.code, r.message))
      setBusy(false)
      setImportStatus(null)
      return false
    }
    return true
  }

  const runAutoDiarize = (mode: "embedding" | "audio_cluster" | "text_gap") => {
    if (!ensureAck()) return
    if (!meetingId && !transcript.trim()) {
      setError("请先创建会议或导入/录制转写")
      return
    }
    if (!transcript.trim()) {
      setError("转写为空，无法标说话人")
      return
    }
    if (mode === "embedding" || mode === "audio_cluster") {
      const pcms = linePcmRef.current
      if (!pcms.length) {
        setError("暂无音频段：请先「上传音频转写」以启用说话人分离（纯粘贴请用弱标）")
        return
      }
      // embedding 需模型；旧版 3 维是用户显式选择，不是模型缺失的静默落回
      if (mode === "embedding" && !diarizeModelReady) {
        setError(mapMeetingDiarizeError("embedding_model_required"))
        return
      }
      setBusy(true)
      setError(null)
      ensureMeetingIdThen((id) => {
        void runUploadDiarize(id, pcms, mode)
      })
      return
    }
    setBusy(true)
    setError(null)
    ensureMeetingIdThen((id) => {
      sendViaRuntime({
        type: "meeting.auto_diarize",
        v: 1,
        id,
        privacy_ack_v1: true,
        mode: "text_gap",
        k: diarizeK,
        text: transcriptRef.current.trim() || undefined,
      })
    })
  }

  const generate = () => {
    if (!ensureAck()) return
    if (capturing) {
      setError("请先结束录音再生成纪要，或使用「结束并生成纪要」")
      return
    }
    if (!transcript.trim() && !meetingId) {
      setError("请先粘贴转写文本或完成录音")
      return
    }
    setBusy(true)
    setError(null)
    if (meetingId && transcript.trim()) {
      void persistenceRef.current.write(meetingId, "meeting.set_transcript", {
        text: transcript,
        source: "user_edit",
        silence_cut: true,
      })
    }
    sendMinutesJob(meetingId)
  }

  const saveTranscript = () => {
    if (busy || capturing || closing || savingTranscriptRef.current || !companionConnected || !transcript.trim()) return
    if (!ensureAck()) return
    const text = transcriptRef.current
    savingTranscriptRef.current = true
    let finishSave!: (ok: boolean) => void
    saveFinishedRef.current = new Promise<boolean>(resolve => { finishSave = resolve })
    setBusy(true)
    setError(null)
    setStatus("正在保存转写…")
    ensureMeetingIdThen(id => {
      if (closeMeetingIdRef.current !== id) closeNeedsEndRef.current = false
      closeMeetingIdRef.current = id
      needsClosePersistenceRef.current = true
      void persistenceRef.current.write(id, "meeting.set_transcript", { text, source: "user_edit", silence_cut: false }).then(ok => {
        savingTranscriptRef.current = false
        saveFinishedRef.current = null
        finishSave(ok)
        setBusy(false)
        if (ok) {
          const unchanged = transcriptRef.current === text
          if (unchanged) transcriptDirtyRef.current = false
          setStatus(unchanged ? "已保存转写" : "已保存；当前编辑仍需保存")
        } else setError("转写保存未确认，草稿仍保留。请检查连接后重试保存")
      })
    }, () => {
      savingTranscriptRef.current = false
      saveFinishedRef.current = null
      finishSave(false)
      setBusy(false)
      setError("创建会议超时，草稿仍保留。请重试保存")
    })
  }

  const copyMinutes = async () => {
    if (!minutesMd) return
    try {
      await navigator.clipboard.writeText(minutesMd)
      setStatus("已复制纪要")
    } catch {
      setError("复制失败")
    }
  }

  const localReadyLabel = !companionConnected
    ? "Companion 未连接"
    : !localModelReady || !localBinaryReady
      ? "本机 STT 未就绪"
      : "本机 STT 就绪"

  return (
    <div
      data-testid="meeting-panel"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 10,
        padding: 12,
        height: "100%",
        overflow: "auto",
        background: tokens.bgElevated,
        color: tokens.text,
        fontSize: 13,
      }}
    >
      <fieldset disabled={closing} style={{ display: "contents" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <strong style={{ flex: 1, fontSize: 15 }}>会议记录</strong>
        <span style={{ fontSize: 11, color: tokens.textSecondary }}>
          实验可标发言人N · 非身份识别
        </span>
        <button
          type="button"
          onClick={() => {
            if (props.registerBeforeClose) props.onClose()
            else void requestCloseRef.current().then(allowed => { if (allowed) props.onClose() })
          }}
          title="结束录制并收起面板"
          aria-label="结束录制并收起面板"
          style={{
            border: `1px solid ${tokens.border}`,
            background: "transparent",
            borderRadius: 6,
            padding: "2px 8px",
            cursor: "pointer",
            color: tokens.textSecondary,
            fontSize: 12,
          }}
        >
          结束并收起
        </button>
      </div>
      {closing && <div role="status" aria-live="polite">正在保存最后一段转写，完成后收起…</div>}

      <div style={{ fontSize: 11, color: tokens.textSecondary, lineHeight: 1.45 }}>
        粘贴 / 上传转写，或显式「开始录制」本机分段转写（最长约{" "}
        {Math.round(MEETING_LIVE_HARD_CAP_MS / 60_000)} 分钟；约 2 小时软提示）。
        {nearRealtime
          ? " 默认近实时出字（渐进假设，约 8 秒定稿；large 模型仅终稿）。"
          : " 当前为分段终稿模式（可在设置开启实时出字）。"}
        应用场景不会自动开麦。录音与听写互斥。说话人：手动标或实验性自动「发言人N」（非真名识别）；系统混音未支持。
        段与段之间自动空行分段；可开「录制 AI 纠错」用上文消歧同音字（需已配置 LLM）。
      </div>

      {/* Path B: meeting live STT / audio import requires voice_privacy_ack_v2.
          Previously only reachable via Settings → 启用本机转写 (easy to miss). */}
      {!state.voicePrivacyAckV2 && (
        <div
          data-testid="meeting-voice-privacy-v2"
          style={{
            border: `1px solid ${tokens.border}`,
            borderRadius: 8,
            padding: 10,
            fontSize: 11,
            lineHeight: 1.45,
            color: tokens.textSecondary,
          }}
        >
          <div style={{ marginBottom: 6, color: tokens.text, fontWeight: 500 }}>
            本机语音隐私说明
          </div>
          <p style={{ margin: "0 0 6px", fontSize: 10 }}>
            会议本机录音 / 上传音频转写前须确认。也可在：侧栏 ⋯ → 设置 → 输入与语音 →
            「启用本机转写」。
          </p>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {VOICE_PRIVACY_ACK_V2_CLAUSES.map((c) => (
              <li key={c.slice(0, 24)}>{c}</li>
            ))}
          </ul>
          <button
            type="button"
            data-testid="meeting-voice-privacy-v2-accept"
            onClick={() => {
              dispatch({ type: "SET_VOICE_PRIVACY_ACK_V2", ack: true })
              setError(null)
              // Companion refuses voice.stt.* unless sttEngine=local — flip if model ready.
              if (localModelReady && localBinaryReady) {
                // Companion validate requires source:"settings" for set_engine (settings dual fence).
                sendViaRuntime({
                  type: "voice.model.set_engine",
                  engine: "local",
                  privacy_ack_v2: true,
                  source: "settings",
                })
              }
            }}
            style={{ ...btnStyle(true), marginTop: 8, padding: "4px 10px", fontSize: 12 }}
          >
            同意本机语音隐私说明
            {localModelReady && localBinaryReady ? "并启用本机转写" : ""}
          </button>
          {!localModelReady || !localBinaryReady ? (
            <div style={{ marginTop: 6, fontSize: 10, color: tokens.warning }}>
              模型或本机组件未就绪时：侧栏 ⋯ → 设置 → 输入与语音 → 下载组件/模型 → 启用本机转写。
            </div>
          ) : null}
        </div>
      )}

      {!ack && (
        <div
          style={{
            border: `1px solid ${tokens.border}`,
            borderRadius: 8,
            padding: 10,
            fontSize: 11,
            lineHeight: 1.45,
            color: tokens.textSecondary,
          }}
        >
          <div style={{ marginBottom: 6, color: tokens.text, fontWeight: 500 }}>
            会议隐私说明
          </div>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            <li>会创建本地会话产物（转写 ± 可选音频）。</li>
            <li>默认结束录制后删除会议目录下音频（当前 UI 不提供保留选项）。</li>
            <li>生成纪要将把转写文本发给你已配置的 LLM。</li>
            <li>长会 STT 仅本机；不会自动开始录音。</li>
            <li>多方录音法律合规由你负责。</li>
          </ul>
          <button
            type="button"
            onClick={acceptAck}
            style={{ ...btnStyle(true), marginTop: 8, padding: "4px 10px", fontSize: 12 }}
          >
            我已了解
          </button>
        </div>
      )}

      <label style={{ fontSize: 12 }}>
        标题
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="可选"
          disabled={capturing}
          style={{
            display: "block",
            width: "100%",
            marginTop: 4,
            padding: "6px 8px",
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            boxSizing: "border-box",
          }}
        />
      </label>

      <div
        data-testid="meeting-capture-bar"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 8,
          alignItems: "center",
          padding: "8px 10px",
          borderRadius: 8,
          border: `1px solid ${capturing ? tokens.accent : tokens.border}`,
          background: tokens.bg,
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 500 }}>
          {capturing ? (
            <>
              <span style={{ color: "#c44" }}>●</span> 录制中 {formatElapsed(elapsedMs)}
              {capturePhase === "processing" ? " · 分段识别中…" : ""}
              {capturePhase === "starting" ? " · 启动中…" : ""}
              {capturePhase === "stopping" ? " · 结束中…" : ""}
              {refinePending > 0 ? ` · AI 纠错中(${refinePending})` : ""}
            </>
          ) : (
            "未录制"
          )}
        </span>
        <span style={{ fontSize: 11, color: tokens.textSecondary }}>{localReadyLabel}</span>
        {softCapHint && capturing && (
          <span style={{ fontSize: 11, color: "#b8860b" }}>
            已超过 {Math.round(MEETING_LIVE_SOFT_CAP_MS / 60_000)} 分钟软提示（硬上限{" "}
            {Math.round(MEETING_LIVE_HARD_CAP_MS / 60_000)} 分钟）
          </span>
        )}
        {state.dictationCaptureActive && !capturing && (
          <span style={{ fontSize: 11, color: "#c44" }}>听写占用中</span>
        )}
      </div>

      <div
        data-testid="meeting-live-options"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 12,
          fontSize: 11,
          color: tokens.textSecondary,
          alignItems: "center",
        }}
      >
        <label
          style={{ display: "flex", gap: 4, alignItems: "center", cursor: "pointer" }}
          title="段末将转写发给已配置 LLM 做 correct_only 纠错（同听写 ASR 纠错开关）；会参考上文消歧同音字"
        >
          <input
            type="checkbox"
            data-testid="meeting-asr-refine"
            checked={state.asrRefinerEnabled === true}
            disabled={capturing}
            onChange={(e) =>
              dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: e.target.checked })
            }
          />
          录制 AI 纠错（参考上文）
        </label>
        <label
          style={{ display: "flex", gap: 4, alignItems: "center", cursor: "pointer" }}
          title="结束录制后自动按静音/段落规则切分转写"
        >
          <input
            type="checkbox"
            data-testid="meeting-auto-segment-stop"
            checked={autoSegmentOnStop}
            onChange={(e) => setAutoSegmentOnStop(e.target.checked)}
          />
          结束时智能分段
        </label>
        {state.asrRefinerEnabled === true && (
          <span style={{ fontSize: 10, color: tokens.warning }}>
            纠错走 Companion LLM；失败时保留原文
          </span>
        )}
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button type="button" disabled={busy || capturing} onClick={createMeeting} style={btnStyle(false)}>
          新建会议会话
        </button>
        {!capturing ? (
          <button
            type="button"
            data-testid="meeting-start-capture"
            disabled={busy || !ack || !state.voicePrivacyAckV2}
            onClick={startLiveCapture}
            style={btnStyle(true)}
            title={
              !ack || !state.voicePrivacyAckV2
                ? "请先确认本机语音隐私与会议隐私说明"
                : undefined
            }
          >
            开始录制
          </button>
        ) : (
          <>
            <button
              type="button"
              data-testid="meeting-stop-capture"
              onClick={() => stopLiveCapture(false)}
              style={btnStyle(false)}
            >
              结束录制
            </button>
            <button
              type="button"
              data-testid="meeting-stop-and-generate"
              onClick={() => stopLiveCapture(true)}
              style={btnStyle(true)}
            >
              结束并生成纪要
            </button>
          </>
        )}
        {meetingId && (
          <span style={{ fontSize: 11, color: tokens.textSecondary, alignSelf: "center" }}>
            id: {meetingId.slice(0, 12)}… · {status}
          </span>
        )}
      </div>

      {/* Mtg2: speaker + import */}
      <div
        data-testid="meeting-mtg2-tools"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 8,
          padding: 10,
          borderRadius: 8,
          border: `1px solid ${tokens.border}`,
          background: tokens.bg,
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 500 }}>说话人 / 导入（Mtg2+3）</div>
        <label style={{ fontSize: 11, color: tokens.textSecondary }}>
          默认说话人标签（录制/导入 STT 追加时使用；可整表批量）
          <input
            data-testid="meeting-default-speaker"
            value={defaultSpeaker}
            onChange={(e) => setDefaultSpeaker(e.target.value)}
            placeholder='如「我」或「张三」'
            disabled={capturing}
            style={{
              display: "block",
              width: "100%",
              marginTop: 4,
              padding: "6px 8px",
              borderRadius: 6,
              border: `1px solid ${tokens.border}`,
              background: tokens.bgElevated,
              color: tokens.text,
              boxSizing: "border-box",
              fontSize: 12,
            }}
          />
        </label>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
          <label style={{ fontSize: 11, color: tokens.textSecondary }}>
            聚类 K
            <select
              data-testid="meeting-diarize-k"
              value={diarizeK}
              disabled={busy || capturing}
              onChange={(e) => setDiarizeK(Math.min(6, Math.max(0, Number(e.target.value) || 0)))}
              style={{ marginLeft: 4, fontSize: 12 }}
            >
              <option value={0}>自动</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
              <option value={6}>6</option>
            </select>
          </label>
          <span style={{ fontSize: 10, color: tokens.textSecondary }}>
            「自动」按说话人嵌入聚类估计人数（本机 · 实验 · 只标发言人N，非身份识别）
          </span>
          <label style={{ fontSize: 11, color: tokens.textSecondary, display: "flex", gap: 4, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={autoDiarizeAfterImport}
              disabled={busy || capturing}
              onChange={(e) => setAutoDiarizeAfterImport(e.target.checked)}
            />
            音频导入后自动标（实验）
          </label>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          <button
            type="button"
            data-testid="meeting-silence-cut"
            disabled={busy || capturing || !ack}
            onClick={applySilenceCut}
            style={btnStyle(false)}
            title="按空行/句号/长度软切分段（非说话人识别）"
          >
            智能分段
          </button>
          <button
            type="button"
            data-testid="meeting-bulk-speaker"
            disabled={busy || capturing || !ack}
            onClick={bulkLabelSpeaker}
            style={btnStyle(false)}
          >
            全部标为默认
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-audio"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("embedding")}
            style={btnStyle(true)}
            title="上传音频段 → 本机 ONNX 说话人嵌入 + 聚类；只标匿名发言人N，非身份识别（需先在 设置 → 输入与语音 → 听写方式 下载说话人分离模型）"
          >
            自动标说话人
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-legacy"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("audio_cluster")}
            style={btnStyle(false)}
            title="旧版回退：上传音频段 → 本机 3 维声学特征 + 聚类（区分度低 · 实验性 · 无需下载模型）；只标匿名发言人N，非身份识别"
          >
            旧版 3 维（区分度低）
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-text"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("text_gap")}
            style={btnStyle(false)}
            title="弱：按行交替发言人N，非声学"
          >
            弱标（交替）
          </button>
          <button
            type="button"
            data-testid="meeting-import-text"
            disabled={busy || capturing || !ack}
            onClick={() => textFileRef.current?.click()}
            style={btnStyle(false)}
          >
            上传转写文件
          </button>
          <button
            type="button"
            data-testid="meeting-import-audio"
            disabled={busy || capturing || !ack}
            onClick={() => audioFileRef.current?.click()}
            style={btnStyle(false)}
          >
            上传音频转写
          </button>
          {busy && importStatus?.includes("本机转写") && (
            <button
              type="button"
              data-testid="meeting-import-abort"
              onClick={() => {
                importAbortRef.current = true
                setImportStatus("正在中止…")
              }}
              style={btnStyle(false)}
            >
              中止导入
            </button>
          )}
        </div>
        <input
          ref={textFileRef}
          type="file"
          accept=".txt,.md,text/plain,text/markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0] || null
            e.target.value = ""
            void onImportTextFile(f)
          }}
        />
        <input
          ref={audioFileRef}
          type="file"
          accept="audio/*,.wav,.mp3,.m4a,.ogg,.webm"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0] || null
            e.target.value = ""
            void onImportAudioFile(f)
          }}
        />
        {importStatus && (
          <div style={{ fontSize: 11, color: tokens.textSecondary }} data-testid="meeting-import-status">
            {importStatus}
          </div>
        )}
        <div style={{ fontSize: 10, color: tokens.textSecondary, lineHeight: 1.4 }}>
          「自动标说话人」= 本机段特征 k-means → 匿名「发言人N」，
          <strong>不是</strong>身份识别，也非 Otter 级 SLA。默认覆盖已有标签（可再手改）。
          弱标仅按行交替。系统混音见 parking 调研。
        </div>
      </div>

      <label style={{ fontSize: 12, flex: 1, display: "flex", flexDirection: "column" }}>
        转写 / 口述文字（可编辑 · 支持「说话人: 正文」）
        <textarea
          value={transcript}
          onChange={(e) => {
            transcriptDirtyRef.current = true
            setTranscript(e.target.value)
          }}
          placeholder="粘贴会议转写，或开始录制/上传后自动填入…&#10;张三: 第一段&#10;&#10;李四: 第二段"
          rows={8}
          style={{
            marginTop: 4,
            width: "100%",
            flex: 1,
            minHeight: 120,
            padding: 8,
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            resize: "vertical",
            boxSizing: "border-box",
            fontFamily: "inherit",
            fontSize: 12,
            lineHeight: 1.45,
          }}
        />
        {capturing ? (
          <div
            data-testid="meeting-interim"
            style={{
              marginTop: 6,
              padding: "8px 10px",
              borderRadius: 8,
              background: tokens.accentSoft,
              border: `1px solid rgba(79, 70, 229, 0.16)`,
              fontSize: 13,
              color: tokens.accentText,
              lineHeight: 1.45,
              maxHeight: 96,
              overflow: "auto",
              whiteSpace: "pre-wrap",
            }}
          >
            {meetingLiveInterimHint({
              phase: capturePhase,
              interimText,
              nearRealtime,
              refinePending,
            })}
          </div>
        ) : null}
      </label>

      <details style={{ fontSize: 12 }}>
        <summary style={{ cursor: "pointer", color: tokens.textSecondary }}>
          纪要模板（可选）
        </summary>
        <p style={{ fontSize: 10, color: tokens.textSecondary, margin: "6px 0" }}>
          模板只约束输出结构；不会改变「不得臆造」规则。生成时把转写文本发给已配置 LLM。
        </p>
        <textarea
          value={templateMd}
          onChange={(e) => {
            const v = e.target.value
            setTemplateMd(v)
            templateMdRef.current = v
          }}
          placeholder={"### TL;DR\n\n### 决议\n\n### 待办\n\n### 风险 / 开放问题"}
          rows={5}
          style={{
            marginTop: 4,
            width: "100%",
            minHeight: 80,
            padding: 8,
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            resize: "vertical",
            boxSizing: "border-box",
            fontFamily: "inherit",
            fontSize: 12,
            lineHeight: 1.45,
          }}
        />
        <button
          type="button"
          onClick={() => {
            setTemplateMd("")
            templateMdRef.current = ""
            saveMeetingTemplate("")
          }}
          style={{
            marginTop: 6,
            fontSize: 11,
            padding: "4px 8px",
            borderRadius: 4,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.textSecondary,
            cursor: "pointer",
          }}
        >
          恢复默认
        </button>
      </details>

      <button type="button" disabled={busy || !ack || capturing || closing || !companionConnected || !transcript.trim()} onClick={saveTranscript} style={btnStyle(false)}>
        保存转写
      </button>
      <div role="status" aria-live="polite" data-testid="meeting-save-status">{status.startsWith("已保存") || status.startsWith("正在保存") ? status : ""}</div>
      <button type="button" disabled={busy || !ack || capturing} onClick={generate} style={btnStyle(true)}>
        {busy || pendingGenerate ? "生成中…" : "生成会议纪要"}
      </button>

      {error && (
        <div style={{ color: "#c44", fontSize: 12 }} role="alert">
          {error}
        </div>
      )}

      {minutesMd && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <strong style={{ flex: 1, fontSize: 12 }}>纪要</strong>
            <button type="button" onClick={copyMinutes} style={linkBtn}>
              复制
            </button>
            <button type="button" onClick={() => props.onSendToDraft(minutesMd)} style={linkBtn}>
              发送到对话草稿
            </button>
          </div>
          <pre
            style={{
              margin: 0,
              padding: 10,
              borderRadius: 8,
              border: `1px solid ${tokens.border}`,
              background: tokens.bg,
              fontSize: 11,
              lineHeight: 1.45,
              whiteSpace: "pre-wrap",
              maxHeight: 280,
              overflow: "auto",
            }}
          >
            {minutesMd}
          </pre>
        </div>
      )}
      </fieldset>
    </div>
  )
}

function btnStyle(primary: boolean): CSSProperties {
  return {
    border: primary ? "none" : `1px solid ${tokens.border}`,
    background: primary ? tokens.accent : "transparent",
    color: primary ? "#fff" : tokens.text,
    borderRadius: 8,
    padding: "8px 12px",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 500,
  }
}

const linkBtn: CSSProperties = {
  border: "none",
  background: "transparent",
  color: tokens.accent,
  cursor: "pointer",
  fontSize: 11,
  textDecoration: "underline",
  padding: 0,
}

FULL CURRENT FILE chrome-extension/src/sidepanel/voice/meeting-close.ts
type MeetingTransport = {
  send: (message: Record<string, unknown>, callback: (reply: any) => void) => void
  subscribe: (listener: (message: any) => void) => () => void
  timeoutMs?: number
}

/** Existing WS contract: id correlates the request; meeting_id owns the data. */
export function createMeetingPersistence({ send, subscribe, timeoutMs = 10_000 }: MeetingTransport) {
  let sequence = 0
  const replacements = new Map<string, number>()
  const writes: { meetingId: string; sequence: number; done: Promise<boolean>; confirmed: boolean; error?: Error }[] = []

  const request = (meetingId: string, type: string, responseType: string, fields: Record<string, unknown> = {}) => new Promise<any>((resolve, reject) => {
    const requestId = `meeting-rpc-${crypto.randomUUID()}`
    let settled = false
    let unsubscribe = () => {}
    const finish = (error?: Error, value?: any) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      unsubscribe()
      error ? reject(error) : resolve(value)
    }
    const timer = setTimeout(() => finish(new Error("保存确认超时，请保持面板并重试")), timeoutMs)
    unsubscribe = subscribe(message => {
      if (message.id !== requestId) return
      if (message.type === "meeting.error" || message.type === "error") {
        finish(new Error(message.message || message.error || "会议保存失败"))
      } else if (message.type === responseType) {
        if (message.meeting?.id !== meetingId || !Array.isArray(message.meeting.transcript)) {
          finish(new Error("会议保存回执与当前会议不匹配"))
        } else finish(undefined, message.meeting)
      }
    })
    try {
      send({ ...fields, type, v: 1, id: requestId, meeting_id: meetingId }, reply => {
        if (reply?.ok === false) finish(new Error(reply.error || "Companion 未连接，请重连后重试"))
      })
    } catch {
      finish(new Error("无法连接 Companion，请重连后重试"))
    }
  })

  return {
    request,
    write(meetingId: string, type: "meeting.append_transcript" | "meeting.set_transcript", fields: Record<string, unknown>): Promise<boolean> {
      const number = ++sequence
      const record = { meetingId, sequence: number, done: Promise.resolve(false), confirmed: false, error: undefined as Error | undefined }
      record.done = request(meetingId, type, "meeting.updated", fields).then(meeting => {
        // Require the exact appended line as well as its unique request receipt.
        if (type === "meeting.append_transcript" && meeting.transcript.at(-1)?.text !== String(fields.text || "").trim()) {
          throw new Error("转写写入回执不包含本次内容")
        }
        if (type === "meeting.set_transcript") replacements.set(meetingId, Math.max(number, replacements.get(meetingId) || 0))
        record.confirmed = true
        return true
      }).catch(cause => {
        record.error = cause instanceof Error ? cause : new Error("转写保存失败")
        return false
      })
      writes.push(record)
      return record.done
    },
    hasUnconfirmedWrites(meetingId: string): boolean {
      const replacedThrough = replacements.get(meetingId) || 0
      return writes.some(write => write.meetingId === meetingId && write.sequence > replacedThrough && !write.confirmed)
    },
    async waitForWrites(meetingId: string): Promise<void> {
      const owned = writes.filter(write => write.meetingId === meetingId)
      await Promise.all(owned.map(write => write.done))
      const replacedThrough = replacements.get(meetingId) || 0
      const failed = owned.find(write => write.sequence > replacedThrough && write.error)
      if (failed) throw new Error(`${failed.error!.message}。转写仍保留，请点击“保存转写”后重试收起`)
    },
  }
}

export type MeetingPersistence = ReturnType<typeof createMeetingPersistence>

/** Actual write receipts establish durability; a correlated read/end completes close. */
export async function confirmMeetingClose(options: {
  id: string
  persistence: MeetingPersistence
  endRecording?: boolean
}): Promise<void> {
  const { id, persistence } = options
  await persistence.waitForWrites(id)
  await persistence.request(id, "meeting.get", "meeting.get_result")
  if (options.endRecording !== false) await persistence.request(id, "meeting.end", "meeting.ended")
}

FULL CURRENT FILE chrome-extension/tests/fixtures/meeting-responses.ts
// Captured by companion/tests/meeting-close-contract-488.test.ts through handleMessage + actual WS envelope.
export const meetingResponses = {
  "created": {
    "request": {
      "title": "Synthetic receipt fixture",
      "thread_id": "thread-fixture",
      "type": "meeting.create",
      "v": 1,
      "id": "meeting-contract-1"
    },
    "response": {
      "type": "meeting.created",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "draft",
        "privacy": {
          "stt_engine": "none",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "transcript": [],
        "minutes": null,
        "error": null
      },
      "id": "meeting-contract-1"
    }
  },
  "started": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "privacy_ack_v1": true,
      "type": "meeting.start",
      "v": 1,
      "id": "meeting-contract-2"
    },
    "response": {
      "type": "meeting.started",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [],
        "minutes": null
      },
      "id": "meeting-contract-2"
    }
  },
  "appended": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "text": "你好",
      "source": "stt",
      "type": "meeting.append_transcript",
      "v": 1,
      "id": "meeting-contract-3"
    },
    "response": {
      "type": "meeting.updated",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "stt"
          }
        ],
        "minutes": null
      },
      "id": "meeting-contract-3"
    }
  },
  "oldRead": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "type": "meeting.get",
      "v": 1,
      "id": "meeting-contract-4"
    },
    "response": {
      "type": "meeting.get_result",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "stt"
          }
        ],
        "minutes": null
      },
      "id": "meeting-contract-4"
    }
  },
  "suffix": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "text": "好",
      "source": "stt",
      "type": "meeting.append_transcript",
      "v": 1,
      "id": "meeting-contract-5"
    },
    "response": {
      "type": "meeting.updated",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "stt"
          },
          {
            "text": "好",
            "source": "stt"
          }
        ],
        "minutes": null
      },
      "id": "meeting-contract-5"
    }
  },
  "repeated": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "text": "好",
      "source": "stt",
      "type": "meeting.append_transcript",
      "v": 1,
      "id": "meeting-contract-6"
    },
    "response": {
      "type": "meeting.updated",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "stt"
          },
          {
            "text": "好",
            "source": "stt"
          },
          {
            "text": "好",
            "source": "stt"
          }
        ],
        "minutes": null
      },
      "id": "meeting-contract-6"
    }
  },
  "replaced": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "text": "你好\n好\n好",
      "source": "user_edit",
      "silence_cut": false,
      "type": "meeting.set_transcript",
      "v": 1,
      "id": "meeting-contract-7"
    },
    "response": {
      "type": "meeting.updated",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          }
        ],
        "minutes": null
      },
      "id": "meeting-contract-7"
    }
  },
  "read": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "type": "meeting.get",
      "v": 1,
      "id": "meeting-contract-8"
    },
    "response": {
      "type": "meeting.get_result",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": null,
        "status": "recording",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          }
        ],
        "minutes": null
      },
      "id": "meeting-contract-8"
    }
  },
  "ended": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "type": "meeting.end",
      "v": 1,
      "id": "meeting-contract-9"
    },
    "response": {
      "type": "meeting.ended",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": "2026-09-09T02:34:05.843Z",
        "status": "ready",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          }
        ],
        "minutes": null
      },
      "audio_deleted": true,
      "id": "meeting-contract-9"
    }
  },
  "endedAgain": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "type": "meeting.end",
      "v": 1,
      "id": "meeting-contract-10"
    },
    "response": {
      "type": "meeting.ended",
      "v": 1,
      "meeting": {
        "id": "mtg_632eb33814176c9e",
        "thread_id": "thread-fixture",
        "title": "Synthetic receipt fixture",
        "started_at": "2026-09-09T02:34:05.839Z",
        "ended_at": "2026-09-09T02:34:05.844Z",
        "status": "ready",
        "privacy": {
          "stt_engine": "local",
          "audio_retained": false,
          "retain_until": null
        },
        "diarize": null,
        "error": null,
        "transcript": [
          {
            "text": "你好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          },
          {
            "text": "好",
            "source": "user_edit"
          }
        ],
        "minutes": null
      },
      "audio_deleted": true,
      "id": "meeting-contract-10"
    }
  },
  "denied": {
    "request": {
      "meeting_id": "mtg_632eb33814176c9e",
      "text": "拒绝",
      "silence_cut": false,
      "type": "meeting.set_transcript",
      "v": 1,
      "id": "meeting-contract-11"
    },
    "response": {
      "type": "meeting.error",
      "v": 1,
      "code": "origin_denied",
      "message": "chrome-extension origin required",
      "id": "meeting-contract-11"
    }
  }
} as const

FULL CURRENT FILE chrome-extension/tests/meeting-close.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import { confirmMeetingClose, createMeetingPersistence } from "../src/sidepanel/voice/meeting-close"
import { meetingResponses as captured } from "./fixtures/meeting-responses"

async function rejects(promise: Promise<unknown>, pattern: RegExp) {
  const cause = await promise.then(() => null, error => error)
  assert.ok(cause instanceof Error && pattern.test(cause.message))
}

const owner = captured.created.response.meeting.id
function harness(timeoutMs = 2000) {
  const listeners = new Set<(message: any) => void>(), sent: any[] = []
  const persistence = createMeetingPersistence({ timeoutMs,
    subscribe: listener => { listeners.add(listener); return () => { listeners.delete(listener) } },
    send: (message, callback) => { sent.push(message); callback({ ok: true }) },
  })
  const emit = (response: any) => { for (const listener of [...listeners]) listener(response) }
  const receipt = (key: keyof typeof captured, request = sent.at(-1), overrides: any = {}) =>
    emit({ ...structuredClone(captured[key].response), id: request.id, ...overrides })
  return { persistence, sent, receipt, emit, listeners }
}
const tick = () => new Promise(resolve => setTimeout(resolve, 0))

test("unique write receipt, correlated get and end required; forwarding ACK cannot close", async () => {
  const h = harness()
  const write = h.persistence.write(owner, "meeting.append_transcript", { text: "好", source: "stt" })
  const request = h.sent[0]
  assert.equal(request.meeting_id, owner)
  assert.ok(request.id !== owner)
  const closing = confirmMeetingClose({ id: owner, persistence: h.persistence })
  h.receipt("suffix", request, { id: "stale-request" })
  await tick(); assert.equal(h.sent.length, 1)
  h.receipt("suffix", request); assert.equal(await write, true)
  await tick(); assert.equal(h.sent.at(-1).type, "meeting.get")
  h.receipt("read")
  await tick(); assert.equal(h.sent.at(-1).type, "meeting.end")
  h.receipt("ended"); await closing
  assert.equal(h.listeners.size, 0)
})

for (const text of ["好", "你好"]) test(`old suffix/equal text (${text}) cannot prove a new write; explicit replacement recovers`, async () => {
  const h = harness(5)
  const write = h.persistence.write(owner, "meeting.append_transcript", { text, source: "stt" })
  h.emit(captured.appended.response)
  h.emit(captured.oldRead.response)
  assert.equal(await write, false)
  assert.equal(h.persistence.hasUnconfirmedWrites(owner), true)
  await rejects(confirmMeetingClose({ id: owner, persistence: h.persistence }), /保存转写/)
  assert.equal(h.sent.length, 1)
  const failedSave = h.persistence.write(owner, "meeting.set_transcript", { text: "你好\n好\n好", silence_cut: false })
  h.receipt("denied"); assert.equal(await failedSave, false)
  await rejects(h.persistence.waitForWrites(owner), /保存转写/)
  const save = h.persistence.write(owner, "meeting.set_transcript", { text: "你好\n好\n好", silence_cut: false })
  h.receipt("replaced"); assert.equal(await save, true)
  await h.persistence.waitForWrites(owner)
  assert.equal(h.persistence.hasUnconfirmedWrites(owner), false)
})

test("replacement cannot clear another owner's failure; wrong-owner write receipt rejects", async () => {
  const h = harness()
  const failed = h.persistence.write("mtg_other-owner", "meeting.append_transcript", { text: "好" })
  h.receipt("suffix"); assert.equal(await failed, false)
  const saved = h.persistence.write(owner, "meeting.set_transcript", { text: "你好\n好\n好", silence_cut: false })
  h.receipt("replaced"); assert.equal(await saved, true)
  await rejects(h.persistence.waitForWrites("mtg_other-owner"), /不匹配/)
})

test("read and end waits bounded and listeners removed", async () => {
  const read = harness(5)
  await rejects(confirmMeetingClose({ id: owner, persistence: read.persistence }), /超时/)
  assert.equal(read.listeners.size, 0)
  const end = harness(5)
  const closing = confirmMeetingClose({ id: owner, persistence: end.persistence })
  await tick(); end.receipt("read")
  await rejects(closing, /超时/)
  assert.equal(end.listeners.size, 0)
  assert.deepEqual(end.sent.map(request => request.type), ["meeting.get", "meeting.end"])
})

test("authorization error retains failure; unknown response metadata tolerated; imports skip end", async () => {
  const h = harness()
  const write = h.persistence.write(owner, "meeting.append_transcript", { text: "好" })
  h.receipt("denied"); assert.equal(await write, false)
  await rejects(h.persistence.waitForWrites(owner), /chrome-extension origin required/)
  const save = h.persistence.write(owner, "meeting.set_transcript", { text: "你好\n好\n好", silence_cut: false })
  h.receipt("replaced", undefined, { future_metadata: { harmless: true } }); assert.equal(await save, true)
  const closing = confirmMeetingClose({ id: owner, persistence: h.persistence, endRecording: false })
  await tick(); h.receipt("read"); await closing
  assert.equal(h.sent.some(request => request.type === "meeting.end"), false)
})

FULL CURRENT FILE companion/tests/meeting-close-contract-488.test.ts
// Capture real route/store responses in an isolated data directory, never user data.
import "./meeting-test-data-dir"
import test from "node:test"
import assert from "node:assert/strict"
import * as fs from "node:fs"
import * as path from "node:path"
import { handleMessage } from "../src/message-router"

test("meeting existing request-id/owner contract persists writes and repeated end returns a receipt", async () => {
  const services = { threadManager: {}, skillEngine: {}, historyStore: {} } as any
  const session = { origin: "chrome-extension://abcdefghijklmnopqrstuvwxyz" } as any
  let sequence = 0
  const route = async (type: string, fields: Record<string, unknown> = {}, context = session) => {
    const request = { ...fields, type, v: 1, id: `meeting-contract-${++sequence}` }
    const response = await handleMessage(request, services, context)
    // Exact production WS envelope, pinned below to prevent an invented contract.
    return { request, response: JSON.parse(JSON.stringify({ ...response, id: request.id })) }
  }
  const lifecycle = fs.readFileSync(path.resolve("src/ws/lifecycle.ts"), "utf8")
  assert.ok(lifecycle.includes("ws.send(JSON.stringify({ ...response, id: msg?.id }))"))
  const created = await route("meeting.create", { title: "Synthetic receipt fixture", thread_id: "thread-fixture" })
  const owner = created.response.meeting.id
  const started = await route("meeting.start", { meeting_id: owner, privacy_ack_v1: true })
  const appended = await route("meeting.append_transcript", { meeting_id: owner, text: "你好", source: "stt" })
  const oldRead = await route("meeting.get", { meeting_id: owner })
  const suffix = await route("meeting.append_transcript", { meeting_id: owner, text: "好", source: "stt" })
  const repeated = await route("meeting.append_transcript", { meeting_id: owner, text: "好", source: "stt" })
  const replaced = await route("meeting.set_transcript", { meeting_id: owner, text: "你好\n好\n好", source: "user_edit", silence_cut: false })
  const read = await route("meeting.get", { meeting_id: owner })
  const ended = await route("meeting.end", { meeting_id: owner })
  const endedAgain = await route("meeting.end", { meeting_id: owner })
  const denied = await route("meeting.set_transcript", { meeting_id: owner, text: "拒绝", silence_cut: false }, { origin: "https://untrusted.invalid" })
  assert.equal(denied.response.code, "origin_denied")
  assert.deepEqual(read.response.meeting.transcript.map((line: any) => line.text), ["你好", "好", "好"])
  assert.equal(ended.response.type, "meeting.ended")
  assert.equal(endedAgain.response.type, "meeting.ended")
  for (const result of [started, appended, oldRead, suffix, repeated, replaced, read, ended, endedAgain]) {
    assert.equal(result.response.meeting.id, owner)
    assert.equal(result.response.id, result.request.id)
    assert.notEqual(result.response.id, owner)
  }
  assert.equal("revision" in read.response.meeting, false)
  assert.equal("id" in read.response.meeting.transcript[0], false)
  const fixtures = { created, started, appended, oldRead, suffix, repeated, replaced, read, ended, endedAgain, denied }
  if (process.env.CMSPARK_MEETING_FIXTURE_OUT) {
    fs.writeFileSync(process.env.CMSPARK_MEETING_FIXTURE_OUT, `// Captured by companion/tests/meeting-close-contract-488.test.ts through handleMessage + actual WS envelope.\nexport const meetingResponses = ${JSON.stringify(fixtures, null, 2)} as const\n`)
  }
})

BACKEND CONTRACT companion/src/meeting/meeting-handlers.ts
/**
 * meeting.* WS handlers (SoT meeting-minutes).
 * create/start/end: chrome-extension OR summoner + cmspark-tray://local.
 * generate_minutes / append_transcript: chrome-extension OR overlay (summoner + tray).
 * auto_diarize / import_text remain extension-only.
 */

import { getConfig } from "../config"
import { logger } from "../logger"
import { isChromeExtensionOrigin, isVoiceSttOriginAllowed } from "../voice/stt-handlers"
import type { LlmExtractConfig } from "../llm/llm-extract"
import { generateMeetingMinutes } from "./meeting-minutes"
import {
  appendTranscript,
  createMeeting,
  endMeetingRecording,
  loadMeeting,
  listMeetings,
  deleteMeeting,
  replaceTranscript,
  setDiarizeResult,
  setMeetingStatus,
  setMinutes,
  setTranscript,
  isSafeMeetingId,
  startMeetingRecording,
  transcriptToText,
  type TranscriptLine,
  type TranscriptSource,
} from "./meeting-store"
import {
  applySilenceCut,
  applySpeakersByIndex,
  bulkSetSpeaker,
  silenceCutText,
} from "./silence-cut"
import {
  applyDiarizeToLines,
  clampDiarizeK,
  diarizeByAudioFeatures,
  diarizeByTextGap,
  extractSegmentFeatures,
} from "./auto-diarize"
import { diarizeByEmbeddings } from "./diarize-cluster"
import { embedSegmentsForDiarize } from "./diarize-embed"
import {
  appendPcmChunk,
  consumeFinalizedPcm,
  createPcmSession,
  finalizePcmSession,
} from "./diarize-pcm-store"

export interface MeetingHandlerContext {
  origin?: string
  peerId?: string
  send?: (data: any) => void
  /** Handshake surface. create/start/end allow summoner + tray origin. */
  surface?: string
}

export interface MeetingHandlerDeps {
  isExtensionOrigin?: (origin: string | undefined) => boolean
  getLlmConfig?: () => LlmExtractConfig | null
  generate?: typeof generateMeetingMinutes
  /** Best-effort: drop stale STT max-1 slot (e.g. prior dictation still inferring). */
  clearSttSessions?: () => void
  /** #260 test seam: override speaker-embedding runtime. */
  embedSegments?: typeof embedSegmentsForDiarize
}

function llmConfigFromCompanion(): LlmExtractConfig | null {
  try {
    const cfg = getConfig()
    const llm = cfg?.llm
    if (!llm?.base_url || !llm?.api_key || !llm?.model_name) return null
    return {
      base_url: llm.base_url,
      api_key: llm.api_key,
      model_name: llm.model_name,
      temperature: typeof llm.temperature === "number" ? llm.temperature : 0.3,
      protocol: llm.protocol,
      auth_style: llm.auth_style,
      client_header_profile: llm.client_header_profile,
      claude_code_compat_version: llm.claude_code_compat_version,
      extra_headers: llm.extra_headers,
      anthropic_version: llm.anthropic_version,
      context_window: llm.context_window,
    }
  } catch {
    return null
  }
}

function err(code: string, message: string, extra?: Record<string, unknown>) {
  return { type: "meeting.error", v: 1, code, message, ...extra }
}

const OVERLAY_MEETING_TYPES = new Set([
  "meeting.create",
  "meeting.start",
  "meeting.end",
  "meeting.append_transcript",
  "meeting.generate_minutes",
  "meeting.list",
  "meeting.get",
  // #244 NEVER: auto_diarize / import_text remain extension-only (#246 had
  // auto_diarize here; this ticket peels it back. Overlay UI has no entry.)
])

/**
 * Overlay tray RPC stamps `id: "tray-N"` for correlation. That is not a meeting
 * id (`mtg_…`). Prefer `meeting_id`; ignore tray request ids and unsafe paths.
 */
export function resolveMeetingId(msg: any): string {
  const candidates = [msg?.meeting_id, msg?.id]
  for (const raw of candidates) {
    if (typeof raw !== "string" || !raw) continue
    if (/^tray-\d+$/.test(raw)) continue
    if (!isSafeMeetingId(raw)) continue
    return raw
  }
  return ""
}

export async function handleMeetingMessage(
  msg: any,
  ctx: MeetingHandlerContext = {},
  deps: MeetingHandlerDeps = {},
): Promise<any> {
  const type = msg?.type
  const originOk = deps.isExtensionOrigin
    ? deps.isExtensionOrigin(ctx.origin)
    : typeof type === "string" && OVERLAY_MEETING_TYPES.has(type)
      ? isVoiceSttOriginAllowed(ctx.origin, ctx.surface)
      : isChromeExtensionOrigin(ctx.origin)
  if (!originOk) {
    logger.warn("meeting.refused", {
      type: typeof type === "string" ? type : undefined,
      origin: ctx.origin ? "present" : "missing",
      surface: ctx.surface,
    })
    return err("origin_denied", "chrome-extension origin required")
  }

  if (type === "meeting.create") {
    const session = createMeeting({
      title: typeof msg.title === "string" ? msg.title : undefined,
      thread_id: typeof msg.thread_id === "string" ? msg.thread_id : null,
    })
    return { type: "meeting.created", v: 1, meeting: session }
  }

  /**
   * Mtg1 live capture start.
   * Requires privacy_ack_v1 === true (meeting_privacy_ack_v1; voice v3 cannot substitute).
   * Does not open mic on server — extension owns gUM + voice.stt.* segments.
   */
  if (type === "meeting.start") {
    if (msg.privacy_ack_v1 !== true) {
      return err("need_privacy_ack", "meeting_privacy_ack_v1 required before start")
    }
    let id = resolveMeetingId(msg)
    if (!id) {
      const session = createMeeting({
        title: typeof msg.title === "string" ? msg.title : undefined,
        thread_id: typeof msg.thread_id === "string" ? msg.thread_id : null,
      })
      id = session.id
    } else {
      const existing = loadMeeting(id)
      if (!existing) return err("not_found", "meeting not found", { id })
      if (existing.status === "recording") {
        return err("already_recording", "meeting already recording", { id })
      }
    }
    const started = startMeetingRecording(id, {
      audio_retained: msg.audio_retained === true,
      retain_days: typeof msg.retain_days === "number" ? msg.retain_days : undefined,
    })
    if (!started) return err("not_found", "meeting not found", { id })
    // Free STT max-1 slot so extension voice.stt.* for this meeting is not blocked
    // by a prior dictation/meeting segment still inferring (resource_conflict).
    try {
      deps.clearSttSessions?.()
    } catch {
      /* best-effort */
    }
    logger.info("meeting.start.ok", {
      id: started.id,
      audio_retained: started.privacy.audio_retained,
    })
    return { type: "meeting.started", v: 1, meeting: started }
  }

  /** End live capture; default delete meetings/<id>/audio when not retained. */
  if (type === "meeting.end") {
    const id = resolveMeetingId(msg)
    if (!id) return err("invalid_id", "meeting.end requires id")
    const result = endMeetingRecording(id)
    if (!result) return err("not_found", "meeting not found", { id })
    logger.info("meeting.end.ok", {
      id,
      audioDeleted: result.audioDeleted,
      retained: result.session.privacy.audio_retained,
    })
    return {
      type: "meeting.ended",
      v: 1,
      meeting: result.session,
      audio_deleted: result.audioDeleted,
    }
  }

  if (type === "meeting.list") {
    return { type: "meeting.list_result", v: 1, meetings: listMeetings() }
  }

  if (type === "meeting.delete") {
    const id = resolveMeetingId(msg)
    if (!id) return err("invalid_id", "meeting.delete requires id")
    const ok = deleteMeeting(id)
    if (!ok) return err("not_found", "meeting not found", { id })
    return { type: "meeting.deleted", v: 1, id }
  }

  if (type === "meeting.get") {
    const id = resolveMeetingId(msg)
    const m = loadMeeting(id)
    if (!m) return err("not_found", "meeting not found", { id })
    return { type: "meeting.get_result", v: 1, meeting: m }
  }

  if (type === "meeting.set_transcript") {
    const id = resolveMeetingId(msg)
    const text = typeof msg.text === "string" ? msg.text : ""
    const source: TranscriptSource =
      msg.source === "stt" || msg.source === "paste" || msg.source === "user_edit"
        ? msg.source
        : "paste"
    if (!text.trim()) return err("empty_transcript", "empty transcript", { id })
    // Mtg2: default silence-cut + speaker prefix parse; opt-out with silence_cut:false
    const lines: TranscriptLine[] =
      msg.silence_cut === false
        ? text
            .split(/\n+/)
            .map((t: string) => t.trim())
            .filter(Boolean)
            .map((t: string) => ({ text: t, source }))
        : silenceCutText(text, source)
    const m = setTranscript(id, lines)
    if (!m) return err("not_found", "meeting not found", { id })
    return { type: "meeting.updated", v: 1, meeting: m }
  }

  if (type === "meeting.append_transcript") {
    const id = resolveMeetingId(msg)
    const text = typeof msg.text === "string" ? msg.text : ""
    if (!text.trim()) return err("empty_transcript", "empty text", { id })
    const line: TranscriptLine = {
      text: text.trim(),
      source:
        msg.source === "stt"
          ? "stt"
          : msg.source === "asr_refiner"
            ? "asr_refiner"
            : "user_edit",
      speaker: typeof msg.speaker === "string" ? msg.speaker.slice(0, 32) : undefined,
    }
    const m = appendTranscript(id, line)
    if (!m) return err("not_found", "meeting not found", { id })
    return { type: "meeting.updated", v: 1, meeting: m }
  }

  /**
   * Mtg2: re-apply silence-cut heuristic on stored transcript (manual labeling prep).
   * Optional msg.text: replace transcript from text first (avoids client race after set_transcript).
   * Does NOT invent speakers.
   */
  if (type === "meeting.apply_silence_cut") {
    const id = resolveMeetingId(msg)
    let m = loadMeeting(id)
    if (!m) return err("not_found", "meeting not found", { id })
    if (typeof msg.text === "string" && msg.text.trim()) {
      m = setTranscript(id, silenceCutText(msg.text, "user_edit")) || m
    }
    const next = applySilenceCut(m.transcript)
    const updated = replaceTranscript(id, next)
    if (!updated) return err("not_found", "meeting not found", { id })
    return { type: "meeting.updated", v: 1, meeting: updated, cut: true }
  }

  /**
   * Mtg2: manual speaker labels by line index.
   * assignments: [{ index, speaker }] speaker null/"" clears.
   */
  if (type === "meeting.set_speakers") {
    const id = resolveMeetingId(msg)
    const m = loadMeeting(id)
    if (!m) return err("not_found", "meeting not found", { id })
    const raw = Array.isArray(msg.assignments) ? msg.assignments : []
    if (raw.length === 0) return err("invalid_assignments", "assignments required", { id })
    if (raw.length > 500) return err("invalid_assignments", "too many assignments", { id })
    const assignments: Array<{ index: number; speaker: string | null }> = []
    for (const a of raw) {
      if (typeof a?.index !== "number" || !Number.isInteger(a.index) || a.index < 0) {
        return err("invalid_assignments", "each assignment needs non-negative integer index", { id })
      }
      assignments.push({
        index: a.index,
        speaker: a?.speaker == null || a.speaker === "" ? null : String(a.speaker).slice(0, 32),
      })
    }
    const next = applySpeakersByIndex(m.transcript, assignments)
    const updated = replaceTranscript(id, next)
    if (!updated) return err("not_found", "meeting not found", { id })
    return { type: "meeting.updated", v: 1, meeting: updated }
  }

  /**
   * Mtg2: set one speaker on all lines (e.g. 「我」) or clear with speaker:null.
   * Optional msg.text: set transcript (silence-cut) first — single round-trip, no client race.
   */
  if (type === "meeting.bulk_speaker") {
    const id = resolveMeetingId(msg)
    let m = loadMeeting(id)
    if (!m) return err("not_found", "meeting not found", { id })
    if (typeof msg.text === "string" && msg.text.trim()) {
      m = setTranscript(id, silenceCutText(msg.text, "user_edit")) || m
    }
    const speaker =
      msg.speaker == null || msg.speaker === ""
        ? null
        : String(msg.speaker).slice(0, 32)
    const next = bulkSetSpeaker(m.transcript, speaker)
    const updated = replaceTranscript(id, next)
    if (!updated) return err("not_found", "meeting not found", { id })
    return { type: "meeting.updated", v: 1, meeting: updated, cut: true }
  }

  /**
   * #260 PCM upload pipeline for embedding diarize. Extension-only (not in
   * OVERLAY_MEETING_TYPES). Audio stays in memory, consumed once by
   * meeting.auto_diarize mode:"embedding"; TTL + caps fail closed.
   */
  if (type === "meeting.diarize.upload_start") {
    if (msg.privacy_ack_v1 !== true) {
      return err("need_privacy_ack", "meeting_privacy_ack_v1 required for pcm upload")
    }
    const r = createPcmSession({
      segments: msg.segments,
      sampleRate: msg.sample_rate,
      format: msg.format,
    })
    if (!r.ok) return err(r.code, r.message)
    return { type: "meeting.diarize.upload_started", v: 1, session_id: r.value }
  }

  if (type === "meeting.diarize.upload_chunk") {
    const r = appendPcmChunk(msg.session_id, msg.index, msg.seq, msg.data)
    if (!r.ok) return err(r.code, r.message, { session_id: msg.session_id })
    return {
      type: "meeting.diarize.chunk_ok",
      v: 1,
      session_id: msg.session_id,
      index: msg.index,
      seq: msg.seq,
    }
  }

  if (type === "meeting.diarize.upload_end") {
    const r = finalizePcmSession(msg.session_id, msg.total_seqs)
    if (!r.ok) return err(r.code, r.message, { session_id: msg.session_id })
    return {
      type: "meeting.diarize.upload_ended",
      v: 1,
      session_id: msg.session_id,
      segments: r.value.segments,
    }
  }

  /**
   * Mtg3: auto-tag speakers (anonymous 发言人N).
   * mode=audio_cluster: 旧版 3 维特征 k-means（区分度低·experimental）。接受
   * features[][] 或（#260 round-2 起）pcm_session —— 服务端提特征。
   * mode=text_gap is weak alternating labels (explicit; not acoustic).
   * mode=#260 embedding: PCM uploaded via meeting.diarize.upload_*; local ONNX
   * speaker embeddings + cosine agglomerative clustering (round-2 held-out
   * gate FAILED 2026-09-05 → stays experimental).
   */
  if (type === "meeting.auto_diarize") {
    if (msg.privacy_ack_v1 !== true) {
      return err("need_privacy_ack", "meeting_privacy_ack_v1 required for auto_diarize")
    }
    const id = resolveMeetingId(msg)
    let m = loadMeeting(id)
    if (!m) return err("not_found", "meeting not found", { id })
    // Optional text: silence-cut set before diarize (text_gap path)
    if (typeof msg.text === "string" && msg.text.trim()) {
      m = setTranscript(id, silenceCutText(msg.text, "user_edit")) || m
    }
    if (!m.transcript.length) {
      return err("empty_transcript", "empty transcript", { id })
    }
    const mode =
      msg.mode === "text_gap"
        ? "text_gap"
        : msg.mode === "embedding"
          ? "embedding"
          : "audio_cluster"
    const k = clampDiarizeK(msg.k)
    let result
    if (mode === "text_gap") {
      result = diarizeByTextGap(m.transcript, k)
    } else if (mode === "embedding") {
      const sessionId = typeof msg.pcm_session === "string" ? msg.pcm_session : ""
      if (!sessionId) {
        return err("pcm_session_required", "embedding requires pcm_session from upload_end", { id })
      }
      const pcm = consumeFinalizedPcm(sessionId)
      if (!pcm) {
        return err(
          "pcm_session_not_found",
          "pcm session not found or not finalized (upload_end first)",
          { id },
        )
      }
      if (pcm.length !== m.transcript.length) {
        return err(
          "pcm_mismatch",
          `pcm segments ${pcm.length} != transcript ${m.transcript.length}`,
          { id },
        )
      }
      const embed = deps.embedSegments ?? embedSegmentsForDiarize
      const embedResult = await embed(pcm, {
        onProgress: (p) => {
          ctx.send?.({ type: "meeting.diarize.progress", v: 1, id, done: p.done, total: p.total })
        },
      })
      if (!embedResult.ok) {
        return err(embedResult.code, embedResult.message, { id })
      }
      result = diarizeByEmbeddings(m.transcript, embedResult.embeddings, k)
    } else {
      // #260 round-2 MAJOR-1: audio_cluster 也接受 pcm_session —— 服务端从上传
      // PCM 提 3 维特征（旧引擎显式回退；extension 新 UI 不再本地提特征）。
      const features = Array.isArray(msg.features) ? msg.features : null
      let feats = features && features.length > 0 ? features : null
      if (!feats) {
        const sessionId = typeof msg.pcm_session === "string" ? msg.pcm_session : ""
        if (!sessionId) {
          return err(
            "features_required",
            "audio_cluster requires features or pcm_session aligned with transcript lines",
            { id },
          )
        }
        const pcm = consumeFinalizedPcm(sessionId)
        if (!pcm) {
          return err(
            "pcm_session_not_found",
            "pcm session not found or not finalized (upload_end first)",
            { id },
          )
        }
        if (pcm.length !== m.transcript.length) {
          return err(
            "pcm_mismatch",
            `pcm segments ${pcm.length} != transcript ${m.transcript.length}`,
            { id },
          )
        }
        feats = pcm.map((s) => Array.from(extractSegmentFeatures(s, 16000)))
      }
      if (feats.length !== m.transcript.length) {
        return err(
          "features_mismatch",
          `features length ${feats.length} != transcript ${m.transcript.length}`,
          { id },
        )
      }
      result = diarizeByAudioFeatures(m.transcript, feats, k)
    }
    const lines = applyDiarizeToLines(m.transcript, result, {
      // Default: full auto overwrite. preserve_manual keeps hand labels (Mtg2).
      preserveManual: msg.preserve_manual === true,
    })
    const updated = setDiarizeResult(id, lines, {
      method: result.method,
      k: result.k,
      at: new Date().toISOString(),
      experimental: result.experimental,
    })
    if (!updated) return err("not_found", "meeting not found", { id })
    logger.info("meeting.auto_diarize.ok", {
      id,
      method: result.method,
      k: result.k,
      lines: lines.length,
    })
    return {
      type: "meeting.diarized",
      v: 1,
      meeting: updated,
      diarize: updated.diarize,
      cut: true,
    }
  }

  /**
   * Mtg2: import plain text / markdown transcript file content (already read by extension).
   * Same as set_transcript with silence_cut; creates meeting if no id.
   */
  if (type === "meeting.import_text") {
    if (msg.privacy_ack_v1 !== true) {
      return err("need_privacy_ack", "meeting_privacy_ack_v1 required for import")
    }
    const text = typeof msg.text === "string" ? msg.text : ""
    if (!text.trim()) return err("empty_transcript", "empty import text")
    if (text.length > 200_000) return err("too_large", "import text too long (max 200000)")
    let id = resolveMeetingId(msg)
    if (!id) {
      const session = createMeeting({
        title: typeof msg.title === "string" ? msg.title : undefined,
        thread_id: typeof msg.thread_id === "string" ? msg.thread_id : null,
      })
      id = session.id
    }
    const lines = silenceCutText(text, "paste")
    const m = setTranscript(id, lines)
    if (!m) return err("not_found", "meeting not found", { id })
    return { type: "meeting.imported", v: 1, meeting: m, kind: "text" }
  }

  if (type === "meeting.generate_minutes") {
    const id = resolveMeetingId(msg)
    // Optional one-shot: text without persisted meeting
    const inlineText = typeof msg.text === "string" ? msg.text : ""
    let transcriptText = inlineText.trim()
    let meetingId = id

    if (id) {
      const m = loadMeeting(id)
      if (!m) return err("not_found", "meeting not found", { id })
      transcriptText = transcriptToText(m.transcript) || inlineText.trim()
      setMeetingStatus(id, "generating")
    }

    if (!transcriptText) {
      if (id) setMeetingStatus(id, "error", "empty transcript")
      return err("empty_transcript", "empty transcript", { id })
    }

    const getLlm = deps.getLlmConfig ?? llmConfigFromCompanion
    const llm = getLlm()
    if (!llm) {
      if (id) setMeetingStatus(id, "error", "llm not configured")
      return err("llm_not_configured", "Companion LLM not configured")
    }

    const generate = deps.generate ?? generateMeetingMinutes
    const templateMd = typeof msg.template_md === "string" ? msg.template_md : undefined
    const result = await generate({ transcriptText, config: llm, templateMd })
    if (!result.ok) {
      if (id) setMeetingStatus(id, "error", result.message)
      return err(result.code, result.message, { id })
    }

    if (meetingId) {
      const updated = setMinutes(meetingId, result.minutes)
      return {
        type: "meeting.minutes_result",
        v: 1,
        meeting: updated,
        minutes: result.minutes,
      }
    }

    // Ephemeral generate (no id) — Mtg0 paste-only
    return {
      type: "meeting.minutes_result",
      v: 1,
      meeting: null,
      minutes: result.minutes,
    }
  }

  if (type === "meeting.set_status") {
    const id = resolveMeetingId(msg)
    const status = msg.status
    if (
      status !== "draft" &&
      status !== "recording" &&
      status !== "ready" &&
      status !== "generating" &&
      status !== "done" &&
      status !== "error"
    ) {
      return err("invalid_status", "invalid status")
    }
    const m = setMeetingStatus(id, status)
    if (!m) return err("not_found", "meeting not found", { id })
    return { type: "meeting.updated", v: 1, meeting: m }
  }

  return err("unknown_type", `unknown type ${String(type)}`)
}

BACKEND CONTRACT companion/src/meeting/meeting-store.ts
/**
 * MeetingSession disk store — ~/.cmspark-agent/meetings/<id>/
 * SoT: 2026-08-07-meeting-minutes-design.md
 */

import * as fs from "fs"
import * as path from "path"
import * as crypto from "crypto"
import { DATA_DIR } from "../config"
import { logger } from "../logger"

export type TranscriptSource = "stt" | "user_edit" | "paste" | "asr_refiner"

export type TranscriptLine = {
  t0?: number
  t1?: number
  speaker?: string
  text: string
  source: TranscriptSource
}

export type MeetingMinutes = {
  tldr?: string
  decisions?: string[]
  actions?: string[]
  risks?: string[]
  raw_md: string
  generated_at: string
}

export type MeetingStatus =
  | "draft"
  | "recording"
  | "ready"
  | "generating"
  | "done"
  | "error"

export type MeetingDiarizeMeta = {
  method: "audio_cluster" | "text_gap" | "embedding"
  k: number
  at: string
  /** legacy methods stay true; embedding false since diarize-eval gate PASS (#260) */
  experimental: boolean
}

export type MeetingMeta = {
  id: string
  thread_id?: string | null
  title: string
  started_at: string
  ended_at?: string | null
  status: MeetingStatus
  privacy: {
    stt_engine: "local" | "none"
    audio_retained: boolean
    retain_until?: string | null
  }
  /** Mtg3: last auto-diarize run (anonymous labels only). */
  diarize?: MeetingDiarizeMeta | null
  error?: string | null
}

export type MeetingSession = MeetingMeta & {
  transcript: TranscriptLine[]
  minutes?: MeetingMinutes | null
}

function meetingsRoot(dataDir = DATA_DIR): string {
  return path.join(dataDir, "meetings")
}

function meetingDir(id: string, dataDir = DATA_DIR): string {
  return path.join(meetingsRoot(dataDir), id)
}

/** Ensure id is a safe single path segment. */
export function isSafeMeetingId(id: string): boolean {
  return typeof id === "string" && /^[a-zA-Z0-9][a-zA-Z0-9_-]{7,63}$/.test(id)
}

export function ensureMeetingsRoot(dataDir = DATA_DIR): string {
  const root = meetingsRoot(dataDir)
  fs.mkdirSync(root, { recursive: true, mode: 0o700 })
  try {
    fs.chmodSync(root, 0o700)
  } catch {
    /* windows */
  }
  return root
}

function resolveContained(id: string, dataDir = DATA_DIR): string | null {
  if (!isSafeMeetingId(id)) return null
  const root = path.resolve(ensureMeetingsRoot(dataDir))
  const dir = path.resolve(meetingDir(id, dataDir))
  if (dir !== root && !dir.startsWith(root + path.sep)) return null
  return dir
}

function writeJsonAtomic(filePath: string, data: unknown): void {
  const dir = path.dirname(filePath)
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 })
  const tmp = `${filePath}.${process.pid}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), { encoding: "utf8", mode: 0o600 })
  fs.renameSync(tmp, filePath)
  try {
    fs.chmodSync(filePath, 0o600)
  } catch {
    /* */
  }
}

function readJson<T>(filePath: string): T | null {
  try {
    if (!fs.existsSync(filePath)) return null
    return JSON.parse(fs.readFileSync(filePath, "utf8")) as T
  } catch {
    return null
  }
}

/** Hard cap on retained meeting sessions (P2 disk bound). */
export const MAX_MEETINGS = 100

/**
 * Delete an entire meeting directory (meta + transcript + minutes + audio).
 * Returns false if id invalid or dir missing.
 */
export function deleteMeeting(id: string, dataDir = DATA_DIR): boolean {
  const dir = resolveContained(id, dataDir)
  if (!dir || !fs.existsSync(dir)) return false
  try {
    fs.rmSync(dir, { recursive: true, force: true })
    logger.info("meeting.deleted", { id })
    return true
  } catch (e: any) {
    logger.warn("meeting.delete_failed", { id, error: e?.message || String(e) })
    return false
  }
}

/**
 * If meeting count exceeds MAX_MEETINGS, delete oldest non-recording sessions first.
 * Never deletes status=recording (active capture).
 */
export function enforceMeetingCap(dataDir = DATA_DIR): { deleted: string[] } {
  const all = listMeetings(dataDir)
  if (all.length < MAX_MEETINGS) return { deleted: [] }
  const over = all.length - MAX_MEETINGS + 1 // make room for one more create
  // listMeetings sorts newest first — drop from the end (oldest)
  const candidates = [...all]
    .reverse()
    .filter((m) => m.status !== "recording")
  const deleted: string[] = []
  for (const m of candidates) {
    if (deleted.length >= over) break
    if (deleteMeeting(m.id, dataDir)) deleted.push(m.id)
  }
  if (deleted.length) {
    logger.info("meeting.cap_enforced", { deleted: deleted.length, max: MAX_MEETINGS })
  }
  return { deleted }
}

/**
 * P1 CORR-09: boot reconcile — stuck `recording` from a dead process never
 * ends and blocks meeting cap forever. Demote stale recordings to `ready`
 * when process restarts (no live STT session can survive process death).
 */
export function reconcileStaleRecordings(dataDir = DATA_DIR): { demoted: string[] } {
  const demoted: string[] = []
  for (const m of listMeetings(dataDir)) {
    if (m.status !== "recording") continue
    try {
      const full = loadMeeting(m.id, dataDir)
      if (!full || full.status !== "recording") continue
      full.status = "ready"
      full.ended_at = full.ended_at || new Date().toISOString()
      saveMeeting(full, dataDir)
      demoted.push(m.id)
      logger.info("meeting.recording_reconciled", { id: m.id })
    } catch (e: any) {
      logger.warn("meeting.recording_reconcile_failed", {
        id: m.id,
        error: e?.message || String(e),
      })
    }
  }
  return { demoted }
}

export function createMeeting(opts: {
  title?: string
  thread_id?: string | null
  dataDir?: string
}): MeetingSession {
  const dataDir = opts.dataDir ?? DATA_DIR
  enforceMeetingCap(dataDir)
  const id = `mtg_${crypto.randomBytes(8).toString("hex")}`
  const now = new Date().toISOString()
  const session: MeetingSession = {
    id,
    thread_id: opts.thread_id ?? null,
    title: (opts.title && opts.title.trim()) || `会议 ${now.slice(0, 16).replace("T", " ")}`,
    started_at: now,
    ended_at: null,
    status: "draft",
    privacy: {
      stt_engine: "none",
      audio_retained: false,
      retain_until: null,
    },
    diarize: null,
    transcript: [],
    minutes: null,
    error: null,
  }
  saveMeeting(session, dataDir)
  return session
}

export function saveMeeting(session: MeetingSession, dataDir = DATA_DIR): void {
  const dir = resolveContained(session.id, dataDir)
  if (!dir) throw new Error("invalid meeting id")
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 })
  const meta: MeetingMeta = {
    id: session.id,
    thread_id: session.thread_id,
    title: session.title,
    started_at: session.started_at,
    ended_at: session.ended_at,
    status: session.status,
    privacy: session.privacy,
    diarize: session.diarize ?? null,
    error: session.error ?? null,
  }
  writeJsonAtomic(path.join(dir, "meta.json"), meta)
  writeJsonAtomic(path.join(dir, "transcript.json"), session.transcript)
  if (session.minutes) {
    writeJsonAtomic(path.join(dir, "minutes.json"), session.minutes)
    const mdPath = path.join(dir, "minutes.md")
    fs.writeFileSync(mdPath, session.minutes.raw_md || "", { encoding: "utf8", mode: 0o600 })
  }
}

export function loadMeeting(id: string, dataDir = DATA_DIR): MeetingSession | null {
  const dir = resolveContained(id, dataDir)
  if (!dir || !fs.existsSync(path.join(dir, "meta.json"))) return null
  const meta = readJson<MeetingMeta>(path.join(dir, "meta.json"))
  if (!meta) return null
  const transcript =
    readJson<TranscriptLine[]>(path.join(dir, "transcript.json")) ||
    readJson<TranscriptLine[]>(path.join(dir, "transcript.jsonl")) ||
    []
  const minutes = readJson<MeetingMinutes>(path.join(dir, "minutes.json"))
  return {
    ...meta,
    transcript: Array.isArray(transcript) ? transcript : [],
    minutes: minutes || null,
  }
}

export function listMeetings(dataDir = DATA_DIR): MeetingMeta[] {
  const root = ensureMeetingsRoot(dataDir)
  const out: MeetingMeta[] = []
  for (const name of fs.readdirSync(root)) {
    const meta = readJson<MeetingMeta>(path.join(root, name, "meta.json"))
    if (meta?.id) out.push(meta)
  }
  out.sort((a, b) => (a.started_at < b.started_at ? 1 : -1))
  return out
}

export function setTranscript(
  id: string,
  lines: TranscriptLine[],
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.transcript = lines
  if (s.status === "draft" || s.status === "error") s.status = "ready"
  saveMeeting(s, dataDir)
  return s
}

export function appendTranscript(
  id: string,
  line: TranscriptLine,
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.transcript = [...s.transcript, line]
  if (s.status === "draft") s.status = "recording"
  saveMeeting(s, dataDir)
  return s
}

/** Replace full transcript line list (Mtg2 speaker edits / silence-cut). */
export function replaceTranscript(
  id: string,
  lines: TranscriptLine[],
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.transcript = Array.isArray(lines) ? lines : []
  if (s.transcript.length > 0 && (s.status === "draft" || s.status === "error")) {
    s.status = "ready"
  }
  saveMeeting(s, dataDir)
  return s
}

/** Persist diarize meta + optional new transcript lines. */
export function setDiarizeResult(
  id: string,
  lines: TranscriptLine[],
  diarize: MeetingDiarizeMeta,
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.transcript = lines
  s.diarize = diarize
  if (s.status === "draft" || s.status === "error") s.status = "ready"
  saveMeeting(s, dataDir)
  return s
}

export function setMinutes(
  id: string,
  minutes: MeetingMinutes,
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.minutes = minutes
  s.status = "done"
  s.ended_at = s.ended_at || new Date().toISOString()
  s.error = null
  saveMeeting(s, dataDir)
  return s
}

export function setMeetingStatus(
  id: string,
  status: MeetingStatus,
  error?: string | null,
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.status = status
  if (error !== undefined) s.error = error
  if (status === "done" || status === "ready") {
    s.ended_at = s.ended_at || new Date().toISOString()
  }
  saveMeeting(s, dataDir)
  return s
}

/**
 * Mark meeting as live capture (Mtg1).
 * Sets status=recording, stt_engine=local, optional audio retain.
 */
export function startMeetingRecording(
  id: string,
  opts: { audio_retained?: boolean; retain_days?: number } = {},
  dataDir = DATA_DIR,
): MeetingSession | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  if (s.status === "recording") return s
  s.status = "recording"
  s.error = null
  s.ended_at = null
  s.privacy = {
    ...s.privacy,
    stt_engine: "local",
    audio_retained: opts.audio_retained === true,
    retain_until: null,
  }
  if (s.privacy.audio_retained) {
    const days = Math.min(7, Math.max(1, Math.floor(opts.retain_days ?? 7)))
    const until = new Date(Date.now() + days * 24 * 60 * 60 * 1000)
    s.privacy.retain_until = until.toISOString()
  }
  // Ensure audio/ exists only when retain requested (optional durable bucket).
  if (s.privacy.audio_retained) {
    const dir = resolveContained(id, dataDir)
    if (dir) {
      try {
        fs.mkdirSync(path.join(dir, "audio"), { recursive: true, mode: 0o700 })
      } catch {
        /* */
      }
    }
  }
  saveMeeting(s, dataDir)
  return s
}

/**
 * End live capture: status=ready, default delete audio/ when not retained.
 */
export function endMeetingRecording(
  id: string,
  dataDir = DATA_DIR,
): { session: MeetingSession; audioDeleted: boolean } | null {
  const s = loadMeeting(id, dataDir)
  if (!s) return null
  s.status = "ready"
  s.ended_at = new Date().toISOString()
  s.error = null
  saveMeeting(s, dataDir)
  let audioDeleted = false
  if (!s.privacy.audio_retained) {
    audioDeleted = deleteMeetingAudio(id, dataDir)
  }
  const again = loadMeeting(id, dataDir)
  return { session: again || s, audioDeleted }
}

/**
 * Best-effort delete audio/ after end (default policy).
 * Returns true when policy is satisfied: dir removed **or already absent**.
 * Does not distinguish "bytes deleted" vs "never existed" — callers should not
 * treat true as proof of residual content removal.
 */
export function deleteMeetingAudio(id: string, dataDir = DATA_DIR): boolean {
  const dir = resolveContained(id, dataDir)
  if (!dir) return false
  const audio = path.join(dir, "audio")
  try {
    if (fs.existsSync(audio)) {
      fs.rmSync(audio, { recursive: true, force: true })
      return true
    }
    return true
  } catch (e) {
    logger.warn("meeting.audio_delete_failed", {
      id,
      err: e instanceof Error ? e.message : String(e),
    })
    return false
  }
}

/** Test / diagnostics: path to meeting audio dir (contained). */
export function meetingAudioDir(id: string, dataDir = DATA_DIR): string | null {
  const dir = resolveContained(id, dataDir)
  if (!dir) return null
  return path.join(dir, "audio")
}

/**
 * P1 Meeting: purge audio/ when retain_until is past wall clock.
 * Clears audio_retained + retain_until after successful delete.
 * Returns count of meetings whose audio was GC'd.
 */
export function gcExpiredMeetingAudio(
  dataDir = DATA_DIR,
  now: Date = new Date(),
): { purged: number; scanned: number } {
  const metas = listMeetings(dataDir)
  let purged = 0
  let scanned = 0
  const nowMs = now.getTime()
  for (const m of metas) {
    if (!m.privacy?.audio_retained) continue
    const until = m.privacy.retain_until
    if (!until || typeof until !== "string") continue
    scanned++
    const t = Date.parse(until)
    if (!Number.isFinite(t) || t > nowMs) continue
    const ok = deleteMeetingAudio(m.id, dataDir)
    if (!ok) continue
    const full = loadMeeting(m.id, dataDir)
    if (full) {
      full.privacy = {
        ...full.privacy,
        audio_retained: false,
        retain_until: null,
      }
      saveMeeting(full, dataDir)
    }
    purged++
    logger.info("meeting.audio_gc", { id: m.id, retain_until: until })
  }
  return { purged, scanned }
}

export function transcriptToText(lines: TranscriptLine[]): string {
  return lines
    .map((l) => {
      const sp = l.speaker ? `${l.speaker}: ` : ""
      return `${sp}${l.text}`
    })
    .join("\n")
    .trim()
}

SOURCE EXCERPT companion/src/ws/lifecycle.ts
1425:                 requireRt().securityConfirmations.request(
1426:                   (data) => {
1427:                     if (ws.readyState === WebSocket.OPEN) {
1428:                       ws.send(JSON.stringify(data))
1429:                     }
1430:                   },
1431:                   details,
1432:                   { originWs: ws },
1433:                 ),
1434:               broadcast: (data: any) => {
1435:                 const message = JSON.stringify(data)
1436:                 for (const client of clients) {
1437:                   try {
1438:                     // Y-e: mirror broadcastToClients (X3) — never fan out to
1439:                     // unauthenticated connections inside the handshake window.
1440:                     if (client.readyState === WebSocket.OPEN && wsAuth.get(client)?.authenticated === true) {
1441:                       client.send(message)
1442:                     }
1443:                   } catch { /* ignore disconnected */ }
1444:                 }
1445:               },
1446:               // WP4: 每连接面板标识(computer.evidence.open P6 频率上限计数)。
1447:               panelId,
1448:               // Path B M1: origin class for voice.stt.* (chrome-extension vs tray).
1449:               origin: peerOrigin,
1450:               surface: wsAuth.get(ws)?.surface,
1451:               originWs: ws,
1452:             },
1453:           )
1454:         } catch (handlerErr: any) {
1455:           // Keep Companion alive on STT/tool handler throws (was process-killing via unhandledRejection).
1456:           logger.error("ws.handleMessage.threw", {
1457:             type: typeof msg?.type === "string" ? msg.type : undefined,
1458:             error: handlerErr?.message || String(handlerErr),
1459:           })
1460:           response = {
1461:             type: "error",
1462:             error: handlerErr?.message || "handler failed",
1463:             family: typeof msg?.type === "string" ? String(msg.type).split(".")[0] : "ws",
1464:           }
1465:         }
1466: 
1467:         if (response && ws.readyState === WebSocket.OPEN) {
1468:           // Echo the request id so clients can match this response to a pending
1469:           // request. Without it, request-type responses (e.g. skill.list) are
1470:           // indistinguishable from server pushes and may be re-issued by clients
1471:           // that dispatch by type.
1472:           ws.send(JSON.stringify({ ...response, id: msg?.id }))
1473:         }
1474:       } catch (e: any) {
1475:         logger.error("ws.message_error", { error: e.message || String(e) })
1476:         if (ws.readyState === WebSocket.OPEN) {
1477:           ws.send(JSON.stringify({ type: "error", id: msg?.id, error: e.message }))
1478:         }
1479:       }
1480:     })
1481: 
1482:     ws.on("close", () => {
1483:       clearInterval(pingInterval)
1484:       clients.delete(ws)
1485:       // P0-2B: clear the per-connection auth timer + state.
1486:       const closedAuth = wsAuth.get(ws)
1487:       if (closedAuth) {
1488:         clearTimeout(closedAuth.timer)
1489:         wsAuth.delete(ws)
1490:       }
SOURCE EXCERPT chrome-extension/src/sidepanel/components/ThreadList.tsx
760:     setOpen(false)
761:   }
762: 
763:   const handleDeleteOne = (threadId: string, e: React.MouseEvent) => {
764:     e.stopPropagation()
765:     if (mutationRef.current) return
766:     if (threadBusyById[threadId]) {
767:       alert("该线程正在运行，无法删除")
768:       return
769:     }
770:     setPendingDelete({ ids: [threadId], hard: trashView, source: "row" })
771:   }
772: 
773:   const handleBatchDelete = () => {
774:     if (mutationRef.current) return
775:     const ids = [...selected].filter((id) => selectableIds.has(id))
776:     if (ids.length === 0) return
777:     setPendingDelete({ ids, hard: trashView, source: "batch" })
778:   }
779: 
780:   const runMutation = async (ids: string[], mode: "trash" | "hard" | "restore" | "empty", source: "row" | "batch" | "cleanup" | "empty") => {
781:     if (!ids.length || mutationRef.current) return
782:     const controller = new AbortController()
783:     mutationRef.current = controller
784:     setMutating(true)
785:     setMutationNotice(`正在${mode === "restore" ? "恢复" : "处理"} ${ids.length} 个对话，请等待服务端确认…`)
786:     setPendingDelete(null)
787:     try {
788:       const result = await mutateThreads(ids, mode, controller.signal)
789:       if (controller.signal.aborted) return
790:       if (mode !== "restore" && result.ok.length) dispatch({ type: "REMOVE_THREADS", threadIds: result.ok })
791:       if (mode === "restore") chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
792:       const failedIds = new Set(result.failed.map(item => item.id))
793:       const uncertain = result.failed.some(item => item.reason.startsWith("unknown"))
794:       const failures = result.failed.slice(0, 3).map(item => {
795:         const title = displayThreadTitle(threads.find(t => t.id === item.id) || { id: item.id })
796:         const reason = item.reason === "thread_busy" ? "运行中"
797:           : item.reason === "not_empty" ? "已有内容，已跳过"
798:           : item.reason === "not_sent_unsupported" ? "未发送，请更新 Companion 后重试"
799:           : item.reason.startsWith("not_sent") ? "未发送"
800:           : item.reason.startsWith("unknown") ? "结果未确认" : item.reason
801:         return `${title}：${reason}`
802:       }).join("；")
803:       setMutationNotice(`${mode === "restore" ? "已恢复" : mode === "hard" || mode === "empty" ? "已永久删除" : "已移入回收站"} ${result.ok.length} 个对话。${result.failed.length ? `另有 ${result.failed.length} 个未完成确认。${failures}${uncertain ? "；部分操作可能已完成，请刷新列表核对后重试。" : ""}` : ""}`)
804:       if (source === "batch") {
805:         setSelected(failedIds)
806:         setSelectMode(failedIds.size > 0)
807:       }
808:       if (source === "cleanup") {
809:         setCleanupSuggestions(previous => previous.filter(s => !result.ok.includes(s.thread_id)))
810:         setCleanupSelected(failedIds)
811:       }
812:     } catch (error) {
813:       if (!controller.signal.aborted) setMutationNotice(`未收到完整结果，部分操作可能已完成；请刷新列表核对。${error instanceof Error ? error.message : ""}`)
814:     } finally {
815:       if (mutationRef.current === controller) mutationRef.current = null
816:       if (!controller.signal.aborted) setMutating(false)
817:     }
818:   }
819: 
820:   const executePendingDelete = () => {
821:     if (!pendingDelete || mutationRef.current) return
822:     const { hard, source } = pendingDelete
823:     const ids = pendingDelete.ids.filter(id => {
824:       const thread = threads.find(t => t.id === id)
825:       return thread && !threadBusyById[id] && (source === "empty" ? !thread.trashed_at && thread.message_count === 0 && id !== activeThreadId : !!thread.trashed_at === hard)
826:     })
827:     if (ids.length !== pendingDelete.ids.length) {
828:       setPendingDelete(null)
829:       setMutationNotice("部分对话状态已变化，请重新核对选择后操作。")
830:       return
831:     }
832:     void runMutation(ids, source === "empty" ? "empty" : hard ? "hard" : "trash", source)
833:   }
834: 
835:   const handleSelectAllVisible = () => {
836:     const ids = selectAllIds(selectableIds)
837:     setSelectMode(true)
838:     setSelected(ids)
839:     const months = timeline.months.map((m) => m.monthKey)
840:     const days = new Set<string>()
841:     for (const m of timeline.months) {
842:       for (const d of m.days) days.add(d.dayKey)
843:     }
844:     const nextExpand = { months, today: true, yesterday: true }
845:     setExpandState(nextExpand)
846:     saveExpandState(nextExpand)
847:     setExpandedDays(days)
848:   }
849: 
850:   const handleClearVisibleSelection = () => {
851:     setSelected(new Set())
852:   }
853: 
854:   const handleRestore = (ids: string[]) => {
855:     const targets = ids.filter(id => selectableIds.has(id) && threads.some(t => t.id === id && t.trashed_at))
SOURCE EXCERPT chrome-extension/src/sidepanel/ui/workspace-styles.ts
70: .cm-settings-footer{flex-wrap:wrap;padding:12px 24px!important;gap:8px!important}
71: .cm-settings-footer button{min-height:36px}
72: .cm-settings-footer .cm-settings-save{background:${tokens.actionPrimary}!important}
73: .cm-settings-body input,.cm-settings-body select,.cm-settings-body textarea{max-width:100%;box-sizing:border-box}
74: @media(max-width:759px){.cm-settings-panel{height:94dvh;max-height:94dvh!important;width:100%!important}.cm-settings-layout{flex-direction:column}.cm-settings-nav{display:none}.cm-settings-mobile-category{display:flex;align-items:center;gap:12px;padding:10px 16px;background:${tokens.bgMuted};border-bottom:1px solid ${tokens.border};font-size:12px;color:${tokens.textSecondary}}.cm-settings-mobile-category select{flex:1;min-width:0;min-height:36px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;background:${tokens.bg};color:${tokens.text};font:inherit}.cm-settings-layout .cm-settings-body{padding:16px!important}.cm-settings-status{padding:0 16px 8px}.cm-settings-page-heading h3{font-size:18px}.cm-settings-footer{padding:10px 16px!important}}
75: .cm-settings-body input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),.cm-settings-body select{min-height:36px}
76: 
77: .cm-header-new{display:none;font-size:24px}
78: .cm-nav-manage{border:0;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:12px;padding:6px;cursor:pointer}
79: .cm-thread-manager-trigger{width:auto!important;gap:5px;padding:0 5px;font-size:12px;white-space:nowrap}
80: .cm-history-panel{display:block!important;overflow-y:auto!important;overscroll-behavior:contain}
81: .cm-thread-management-header{flex-wrap:wrap;flex-shrink:0}
82: .cm-thread-management-views{flex-wrap:wrap}
83: .cm-thread-management-list{min-height:120px;overflow:visible!important;max-height:none!important}
84: .cm-thread-management-actions{display:flex;gap:6px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
85: .cm-thread-cleanup{flex-shrink:0}
86: .cm-thread-selection-bar{position:sticky;bottom:0;z-index:2;background:${tokens.bgElevated};box-shadow:0 -2px 8px rgba(0,0,0,.04);flex-wrap:wrap;gap:8px}
87: .cm-history-panel button{min-height:32px}
88: .cm-thread-management-views button[aria-pressed="true"]{background:${tokens.navSelected};color:${tokens.text};font-weight:600}
89: .cm-thread-mutation-notice{padding:10px 12px;font-size:12px;line-height:1.6;background:${tokens.bgMuted};color:${tokens.textSecondary};overflow-wrap:anywhere}
90: .cm-thread-mutation-notice button{display:block;font:inherit;padding:4px 8px;margin-top:6px;background:${tokens.bg};border:1px solid ${tokens.border};border-radius:6px;cursor:pointer}
91: .cm-delete-preview{padding-left:18px;margin:8px 0;font-size:12px;line-height:1.7;overflow-wrap:anywhere}.cm-delete-preview span{color:${tokens.textMuted}}
92: .cm-thread-management-actions button,.cm-thread-editor button{font:inherit;font-size:12px;min-height:32px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 9px;background:${tokens.bgMuted};color:${tokens.text};cursor:pointer}
93: .cm-thread-management-actions button:disabled,.cm-thread-editor button:disabled{opacity:.5;cursor:not-allowed}
94: @media(max-height:600px){.cm-thread-management-title{padding:4px 10px!important}.cm-thread-management-header{padding:4px 10px!important}.cm-thread-management-actions{padding:4px 10px;gap:4px}.cm-thread-management-actions button{padding:4px 6px;white-space:nowrap}}
95: .cm-thread-management-help{font-size:12px;line-height:1.6;color:${tokens.textSecondary};padding:0 12px}
96: .cm-thread-editor{padding:16px;display:flex;flex-direction:column;gap:10px;border-bottom:1px solid ${tokens.border};background:${tokens.bgMuted}}
97: .cm-thread-editor label{display:flex;flex-direction:column;gap:6px;font-size:12px}.cm-thread-editor input{box-sizing:border-box;width:100%;min-width:0;border:1px solid ${tokens.border};border-radius:8px;padding:8px;font:inherit;background:${tokens.bg}}
98: .cm-thread-editor p{font-size:12px;line-height:1.5;margin:0;color:${tokens.textSecondary};overflow-wrap:anywhere}.cm-thread-editor [role="alert"]{color:${tokens.danger}}.cm-thread-editor-actions{display:flex;justify-content:flex-end;gap:8px}
99: @media(max-width:759px){.cm-header-new{display:inline-flex;flex-shrink:0}.cm-status-rail{flex-wrap:wrap}.cm-thread-manager-trigger{min-height:32px}.cm-thread-management-header{align-items:flex-start!important}}
100: @media(max-width:520px){.cm-thread-row{flex-wrap:wrap}.cm-thread-row:not(.cm-thread-selecting) .cm-thread-row-content{flex-basis:100%!important}.cm-rail-brand{display:none}}
101: .cm-thread-tag-origin{font-size:10px;opacity:.8}
102: `
103: 
SOURCE EXCERPT chrome-extension/src/sidepanel/hooks/useWebSocket.ts
45: export function clearHydrateRetry(threadId: string): void {
46:   hydrateRetryIds.delete(threadId)
47: }
48: 
49: function generateShortId(): string {
50:   const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
51:   let id = ""
52:   for (let i = 0; i < 6; i++) id += chars[Math.floor(Math.random() * chars.length)]
53:   return id
54: }
55: 
56: export function requestInitialSidePanelData(
57:   sendMessage: (message: object) => void,
58:   initializedRef: { current: boolean },
59: ): boolean {
60:   if (initializedRef.current) return false
61:   initializedRef.current = true
62:   sendMessage({ type: "thread.list" })
63:   sendMessage({ type: "skill.list" })
64:   sendMessage({ type: "knowledge.list" })
65:   sendMessage({ type: "config.get" })
66:   sendMessage({ type: "mcp.list" })
67:   // ADR-019: redacted secrets snapshot (auth required; no plaintext).
68:   sendMessage({ type: "user_env.list" })
69:   // ADR-021: hydrate unattended grant for StatusRail chip
70:   sendMessage({ type: "security.unattended.status" })
71:   return true
72: }
73: 
74: /** Module-level timer so multiple status messages replace (not stack) TTL clears. */
75: let unattendedExpireTimer: ReturnType<typeof setTimeout> | null = null
76: 
77: /**
78:  * Schedule local UI clear when process grant hard TTL elapses (Correctness F7).
79:  * Companion is still SoT — we re-fetch status at expiry; do not invent armed:true.
80:  */
SOURCE EXCERPT chrome-extension/src/sidepanel/hooks/useWebSocket.ts
2430:           }
2431:         }
2432:       })
2433:     }
2434: 
2435:     pollStatus()
2436:     const interval = setInterval(pollStatus, 3000)
2437: 
2438:     // Refresh thread list when sidepanel becomes visible again
2439:     const handleVisibilityChange = () => {
2440:       if (document.visibilityState === "visible") {
2441:         chrome.runtime.sendMessage({ type: "thread.list" })
2442:       }
2443:     }
2444:     document.addEventListener("visibilitychange", handleVisibilityChange)
2445: 
2446:     // Long-lived port connection to keep the service worker alive while sidepanel is open
2447:     const port = chrome.runtime.connect({ name: "cmspark-sidepanel" })
2448: 
2449:     return () => {
2450:       clearInterval(interval)
2451:       chrome.runtime.onMessage.removeListener(messageListener)
2452:       document.removeEventListener("visibilitychange", handleVisibilityChange)
2453:       port.disconnect()
2454:     }
MACHINE extension-tests.log
  type: 'test'
  ...
# Subtest: shouldRefuseWsFrame allows an 8MB JSON payload
ok 1326 - shouldRefuseWsFrame allows an 8MB JSON payload
  ---
  duration_ms: 0.044208
  type: 'test'
  ...
# Subtest: isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
ok 1327 - isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
  ---
  duration_ms: 0.04975
  type: 'test'
  ...
1..1327
# tests 1327
# suites 0
# pass 1327
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 9358.448542

MACHINE extension-build.log
  icon.png (782 bytes)
  icon_16x16.png (209 bytes)
  icon_16x16@2x.png (333 bytes)
  icon_32x32.png (333 bytes)
  icon_32x32@2x.png (531 bytes)
  icon_128x128.png (1235 bytes)
  icon_128x128@2x.png (2619 bytes)
  icon_256x256.png (2619 bytes)
  icon_256x256@2x.png (5904 bytes)
  icon_512x512.png (5904 bytes)
  icon_512x512@2x.png (15004 bytes)

Connection icon generation complete!

> cmspark-browser-agent@0.6.7 build
> tsc --noEmit && plasmo build

🟣 Plasmo v0.90.5
🔴 The Browser Extension Framework
🔵 INFO   | Prepare to bundle the extension...
🔵 INFO   | Building for target: chrome-mv3
🔵 INFO   | Loaded environment variables from: []
🟢 DONE   | Finished in 8553ms!

MACHINE mutations-ui-final.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpyao119no
PASS: actual App selection boundaries, busy/filter race, 60-item batching, ACK vs persisted result, offline/partial failure, restore, independent cleanup scope and responsive management capabilities.

MACHINE meeting-ui.log
PASS settings readback failure: visible error + meeting retained; repeated Settings action completes after recovery
PASS standalone MeetingPanel without registerBeforeClose: final → persisted readback → end ACK → exactly one onClose
PASS stale suffix/equal write receipts rejected; textarea retains unconfirmed final after idle and stale pushes; denied save retains draft; explicit successful save recovers close without LLM
PASS guard effect unregisters on unmount; subsequent settings does not run stale meeting guard
PASS normal stop followed by close completes with final text intact
PASS failed import set_transcript preserves textarea and explicit save enables retry
PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation

MACHINE meeting-receipt-unit.log
  type: 'test'
  ...
# Subtest: \#482 ordinary local dictation previews during recording, then commits one final on stop
ok 9 - \#482 ordinary local dictation previews during recording, then commits one final on stop
  ---
  duration_ms: 21.227291
  type: 'test'
  ...
# Subtest: \#482 cancel ordinary streaming dictation discards a late final
ok 10 - \#482 cancel ordinary streaming dictation discards a late final
  ---
  duration_ms: 3.438833
  type: 'test'
  ...
1..10
# tests 10
# suites 0
# pass 10
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 126.103167

MACHINE meeting-review-rebuttal-ui.log
PASS settings readback failure: visible error + meeting retained; repeated Settings action completes after recovery
PASS standalone MeetingPanel without registerBeforeClose: final → persisted readback → end ACK → exactly one onClose
PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation

MACHINE meeting-real-contract.log
TAP version 13
# [cmspark-agent] computer.modelVariant=hybrid 已弃用（TinyClick）——迁移为 Qwen3-VL "2b"
# Subtest: meeting existing request-id/owner contract persists writes and repeated end returns a receipt
ok 1 - meeting existing request-id/owner contract persists writes and repeated end returns a receipt
  ---
  duration_ms: 8.505875
  type: 'test'
  ...
1..1
# tests 1
# suites 0
# pass 1
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 176.217625

YOUR OWN EARLIER REPORT (not another judge)
# Independent review: CMspark #488 vs `947532a8`

Capability claim holds: existing `thread.batch_delete` + `only_empty` / empty-target probe; no new agent/tool privilege; confirmations stay user-gated; no offline destructive queue. Machine PASS is not treated as correctness.

## What actually landed

Selection is now the current search/tag/trash view and no longer expands an empty selection. Mutations wait on correlated companion payloads, not transport ACKs, in serial 50s. Empty cleanup probes `thread_ids: []` then hard-deletes with a server `getMessages()` recheck. Meeting close *intends* to drain capture → readback → `meeting.end`. Those contracts are the right ones. Several of them are not actually closed.

---

## P1 — leaked `beforeClose` guard (control-flow / component contract)

`registerBeforeClose` returns an unregister function:

```179:182:chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
  const registerBeforeClose = useCallback((guard: () => Promise<boolean>) => {
    beforeCloseRef.current = guard
    return () => { if (beforeCloseRef.current === guard) beforeCloseRef.current = null }
  }, [])
```

MeetingPanel never uses it:

```javascript
useEffect(() => props.registerBeforeClose?.(() => requestCloseRef.current()), [props.registerBeforeClose])
```

After a successful close, Host unmounts `MeetingPanel` and **leaves `beforeCloseRef` set for the rest of the session**.

Repro:
1. Open 会议, start or don’t start capture, 结束并收起 until `activePanel === null`.
2. Open 设置.

Host still sees a guard:

```javascript
if (!beforeCloseRef.current) { closePanel(); return }
dispatch({ type: "SET_SETTINGS_OPEN", open: false })
const pending = requestPanelChange(null)
```

Settings is forced shut, the **unmounted** panel’s `requestClose` runs (`setClosing(true)` on a dead instance), then settings may reopen. Every later panel change also goes through that stale async guard. If `needsClosePersistenceRef` is still true (see P1 below), settings/skills/knowledge are blocked on `meeting.get` / `meeting.end` for a meeting that is already gone.

UI tests never open settings after the meeting panel has unmounted. They only toggle settings *while* meeting is still mounted.

---

## P1 — stop-then-close waits for a second `meeting.end`

`startLiveCapture` sets `needsClosePersistenceRef = true` and `closeNeedsEndRef = true`. Those flags are cleared **only** after `confirmMeetingClose` succeeds.

Normal 「结束录制」 / 「结束并生成纪要」 calls `finalizeCapture` with `closePendingRef == null`, which **already sends `meeting.end`**. Closing afterwards still does:

```javascript
await confirmMeetingClose({
  id,
  expectedText: liveTextRef.current.join("\n"),
  endRecording: closeNeedsEndRef.current, // still true
  ...
})
```

Repro (not in `test-meeting-close-ui.py`):
1. 开始录制 → inject a final STT chunk so capture is live.
2. Click 「结束录制」 (not 收起). Wait until phase is idle / `meeting.end` has been sent.
3. Click 「结束并收起」 or switch to 技能.

Client sends `meeting.end` again and blocks up to 10s on `meeting.ended`. If companion treats the session as already ended (error, no second `ended`, or `meeting.ended` for a different id), close fails, panel is retained, retry hits the same flags. Navigation is stuck without a reload.

The synthetic close tests only close **while recording**. They never stop, then navigate.

Same hole: `onSendToDraft` → `closePanel()` after a finished recording.

---

## P1 — import close confirms a fire-and-forget `set_transcript`

Audio import appends locally with `appendLocalAndRemote(oneLine, null)` (no `meeting.append_transcript`), then:

```javascript
sendViaRuntime({ type: "meeting.set_transcript", v: 1, id, text: body, ... })
// ...
resolveImport(importSucceeded) // does not wait for persist
```

`requestClose` then `meeting.get` + `endsWith(liveText)`. On a real companion that is not the fixture’s synchronous `set_transcript`, first close fails “尚未确认保存” (acceptable) **or** succeeds on a stale snapshot that does not include the last imported segment (not acceptable). Abort-during-decode also `return`s from `try` with `importSucceeded` still `true`; that path is accidentally rescued only because `needsClosePersistenceRef` is still false.

Fixture applies `set_transcript` inline. That is not a persistence proof.

---

## P2 — last STT vs `meeting.get` is send-order, not durability

Live close orders `append_transcript` then `get` then `end` on the **outbound** queue. `confirmMeetingClose` accepts any `meeting.get_result` with the same id; it does not wait for the append’s `meeting.updated`. Compact `endsWith` can also pass if the expected tail is a suffix of an older line (`"好"` vs `"你好"`).

Timeout failsafe: `finalizeCapture` early-returns when `finalizedRef` is already true and will **not** resolve a newly installed `captureFinishedRef`. The 20s stopping timer usually shares the first finalize; a second close overlapping that window can hang until the import/capture timeout, then retain. Retry can then `meeting.end` without the late STT (textarea still has it locally).

---

## P2 — narrow list: capabilities are wider, not quieter

Row actions 相关 / AI 标签 / 知识 / 分类 / 导出 / 删除 are now nowrap text (`iconBtn.whiteSpace: "nowrap"`). Global `.cm-history-panel button { min-height: 32px }` applies to those too. `threadItem` is a non-wrapping flex row.

Playwright only asserts the **dialog** `scrollWidth <= clientWidth` and a list `height >= 100`. It never clicks a row action at 320×480. Clipped 删除/知识 on Mac side panel width is the likely outcome; that violates “all old capabilities remain reachable” without removing them.

Whole-panel scroll + `min-height: 120px` on the list is the right layout fix; sticky selection bar is fine. Header 全选 vs 整理建议 全选建议 is correctly split.

---

## P2 — mutation abort vs durable result

`runMutation` does `if (controller.signal.aborted) return` **after** `mutateThreads` resolves, skipping `REMOVE_THREADS` and the notice. Sidepanel unmount aborts. Server may already have deleted; UI keeps rows and says nothing. Unknown path is honest only when the notice actually renders.

`executePendingDelete` rechecks `message_count === 0` for empty cleanup. That is the UI preview, not `getMessages()`. Server recheck is the real gate; this is fail-closed if `message_count` is missing, fail-open if the list count is stale-zero and the server check were ever skipped. Companion path does not skip it.

---

## NIT

- `ComposeDrawer` still accepts `capabilityLevel` and keeps unused `surfaceChip` styles; copy itself is the requested global vs 本对话 split.
- Empty-probe `unknown_disconnected` is labeled `not_sent`, not `not_sent_unsupported` — fine.
- `requestPanelChange` coalesces on the first in-flight promise; latest `targetRef` is applied only if that first guard returns true. Failed close drops a queued 技能/知识 open.
- `CompanionMark` swap is in-scope branding; tests were rewritten to match, so they no longer protect the old #323 calf contrast story.

---

## What is actually solid (short)

`parseResult` refuses ACK-only, wrong mode, duplicate/unrequested/omitted ids, and count/`deleted_ids` mismatch. Background refuses delete/restore unless `wsClient` is connected and returns `ok: sent` with the same `id`. Companion probe cannot carry targets; `only_empty` requires `mode=hard` and rechecks trash/busy/messages. ThreadList no longer expands empty selection; busy/filter only shrinks; cleanup selection is a separate set. Those match DoD and the recorded payload fixture.

They do **not** cover: meeting unmount guard lifetime, stop-then-navigate, import persist-before-get, or row-level reachability at 320px. `PASS meeting-close-ui` / `PASS thread-mutations-ui` therefore do not prove the claimed close/navigation or Mac quiet-UI contracts.

---

VERDICT: REJECT

Re-adjudicate your prior findings against the current source. Do not infer unseen code.