Independently review CMspark #488 fixes against main 947532a8. This is a fresh final review, no other judge conclusions included. User requested pull Windows changes, independently review and repair for Mac; intuitive quiet UI without removing capabilities. Review actual outcomes, control flow/concurrency and component contracts. Do not assume machine PASS proves correctness. Be adversarial and cite concrete file/line + reproducible defects. Do not reward long text. Final line VERDICT: APPROVE / APPROVE_WITH_NITS / REJECT. Return complete review now, no tools or preface.

Capability declaration: T3 conservative tier for existing deletion persistence boundary. Existing batch_delete gains only_empty hard-delete condition plus empty-target read-only compatibility probe. Existing Surface, L2 classes, Compose execution capabilities, Autonomy, Trust, Channel unchanged. No new agent/tool privilege, no auto execution, no default outbound expansion. Existing UI user confirmation remains. Meeting close now drains final capture/import, reads persisted transcript and confirms ended before navigation. Larger native workbench/projects are not claimed.
DoD: tag/search/trash scoped selection; empty selection cannot expand; 50-item serial batches only persisted correlated complete replies count; preserve partial/unknown results and failed rows; no offline destructive queue; empty cleanup never deletes content changed since UI preview and fails safely on old companion; narrow/short viewport list scrolls and all old capabilities remain reachable; meeting close/navigation preserves final segment, failures/timeouts retain panel, late start replies never open mic; global resource scope copy accurate. Synthetic UI tests do NOT prove real microphone accuracy or real Windows behavior.

DIFF (including new files; audit reports excluded for independence)
diff --git a/CHANGELOG.md b/CHANGELOG.md
index 5ad8a3be..1e09dbc4 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -4,6 +4,9 @@
 
 ## [Unreleased]
 
+- Windows 对话管理复审修复（#488）：全选遵循当前筛选，整理建议与列表选择分开；删除和恢复按 50 条分批并等待真实回执，保留失败项，清理空白改为应用内确认并在服务端复核内容。短窗口可滚动访问列表和操作，保留标签、人工/AI 分组、整理及图谱入口。
+- 会议关闭（#488）：收起、切换面板和打开设置先等待最后一段转写保存及结束确认；失败保留面板并支持重试。工作区统一连接图标，资源抽屉区分全局配置与对话使用范围。
+
 ## [0.6.7] — 2026-09-08
 
 S107 六路对抗 + Claude/Kimi dual AWN 关门：活文档与代码锁步，不把 0.7.0 企业双场景验收算进本切点（#230 仍冻，#228 禁扩默认 outbound）。
diff --git a/DESIGN.md b/DESIGN.md
index 449c502b..62df0b90 100644
--- a/DESIGN.md
+++ b/DESIGN.md
@@ -1,7 +1,7 @@
 # Design
 
 ## Source of truth
-Active · 2026-09-08 · GitHub [#481](https://github.com/nehcuh/cmspark/issues/481).
+Active · 2026-09-09 · GitHub [#481](https://github.com/nehcuh/cmspark/issues/481), [#488](https://github.com/nehcuh/cmspark/issues/488).
 This is the current UI/UX contract for the extension workspace, summoner, settings,
 code panel, terminal, confirmation cockpit, meetings, graphs and tray. It consolidates
 #469 / #471 / #473 / #474 / #476 / #477 instead of appending competing layout rules.
@@ -59,6 +59,14 @@ ThreadList owns extension history, time/tags/manual/AI views, trash and bulk act
 Recent navigation projects the same store. Summoner uses persisted `user_tags` and
 `topic_folder`, not a second grouping store. AI grouping derives from extracted tags
 and never rewrites manual grouping. Keep AI extraction, cleanup and graph entries.
+Full selection uses the current search/tag/trash view and excludes busy threads.
+Cleanup suggestions own a separate selection. An empty selection never expands
+into a delete-all action. Confirmations show actual targets; only server-confirmed
+results update the list. Partial failures stay visible and unknown outcomes require
+refresh before retry. Empty cleanup requires server-side content revalidation.
+The entire history panel scrolls on short screens; its list cannot collapse to zero.
+Meeting close and navigation wait for final transcript persistence and end receipt;
+failures retain the panel with a retry action.
 Existing resource panels use ContextPanelHost above the composer; summoner resource
 attachments retain their current surface until native management lands. Label
 “used in this conversation” separately from global configuration. Read-only lists
diff --git a/chrome-extension/scripts/render-meeting-close-fixture.cjs b/chrome-extension/scripts/render-meeting-close-fixture.cjs
new file mode 100644
index 00000000..74825938
--- /dev/null
+++ b/chrome-extension/scripts/render-meeting-close-fixture.cjs
@@ -0,0 +1,30 @@
+// Actual MeetingPanel + ContextPanelHost + local STT adapter. Only PCM input and
+// transport are synthetic; no live Companion, microphone, or user data.
+const fs = require('fs'), path = require('path');
+const root = process.cwd(), out = process.argv[2];
+if (!out) throw new Error('output directory required');
+fs.mkdirSync(out, { recursive: true });
+const source = `
+import React,{useEffect} from 'react';import{createRoot}from'react-dom/client';
+import{AgentStoreProvider,initialState,useAgentStore}from'./src/sidepanel/store/agentStore';
+import{ContextPanelHostProvider,ContextPanelHost,useContextPanelHost}from'./src/sidepanel/components/ContextPanelHost';
+const listeners=new Set();window.sent=[];window.persisted=[];window.deferStart=false;window.failRead=false;window.deferEnd=false;
+window.emit=m=>{for(const fn of [...listeners])fn(m)};
+window.snapshot=()=>({id:'meeting-fixture',status:'ready',transcript:window.persisted.map(text=>({text,source:'stt'}))});
+const event={addListener(){},removeListener(){}};
+window.chrome={runtime:{id:'fixture',onMessage:{addListener:f=>listeners.add(f),removeListener:f=>listeners.delete(f)},sendMessage:(m,cb)=>{
+window.sent.push(m);queueMicrotask(()=>{cb?.({ok:true});
+if(m.type==='meeting.start'&&!window.deferStart)window.emit({type:'meeting.started',meeting:window.snapshot()});
+if(m.type==='meeting.create')window.emit({type:'meeting.created',meeting:window.snapshot()});
+if(m.type==='meeting.append_transcript'){window.persisted.push(m.text);window.emit({type:'meeting.updated',meeting:window.snapshot()})}
+if(m.type==='meeting.set_transcript'){window.persisted=m.text.split('\\n');window.emit({type:'meeting.updated',meeting:window.snapshot()})}
+if(m.type==='meeting.get')window.emit({type:'meeting.get_result',meeting:window.failRead?{...window.snapshot(),transcript:[]}:window.snapshot()});
+if(m.type==='meeting.end'&&!window.deferEnd)window.emit({type:'meeting.ended',meeting:window.snapshot()});
+});return Promise.resolve({ok:true})}},storage:{local:{get:(k,cb)=>{const r={meeting_privacy_ack_v1:true};cb?.(r);return Promise.resolve(r)},set:(v,cb)=>{cb?.();return Promise.resolve()}},onChanged:event},tabs:{query:(q,cb)=>{cb?.([]);return Promise.resolve([])}}};
+function Harness(){const h=useContextPanelHost();const{state,dispatch}=useAgentStore();window.dispatchUI=dispatch;window.activePanel=h.activePanel;
+useEffect(()=>h.openPanelForce('meeting'),[]);return <><button onClick={()=>h.openPanelForce('skills')}>切换技能</button><button onClick={()=>h.openPanelForce('knowledge')}>切换知识</button><button onClick={()=>dispatch({type:'SET_SETTINGS_OPEN',open:true})}>打开设置</button><span data-testid='settings-state'>{state.settingsOpen?'设置已打开':'设置未打开'}</span><ContextPanelHost/></>}
+createRoot(document.getElementById('root')).render(<AgentStoreProvider initialState={{...initialState,connectionState:'connected',activeThreadId:'thread-fixture',voicePrivacyAckV2:true,voiceRealtimeStreaming:true,voiceModel:{localModelId:'medium',binary:{status:'ready'},models:{medium:{status:'ready'}}}}}><ContextPanelHostProvider capabilityLevel='chat'><Harness/></ContextPanelHostProvider></AgentStoreProvider>);
+`;
+const capture = `export async function startPcmStreamCapture(opts){window.capture=opts;window.captureStops=0;window.captureAborts=0;return{backend:'scriptprocessor',stop:async()=>{window.captureStops++},abort:()=>{window.captureAborts++}}}`;
+const audioImport = `export * from ${JSON.stringify(path.join(root,'src/sidepanel/voice/meeting-audio-import.ts'))};import{wrapPcmS16leAsWav}from ${JSON.stringify(path.join(root,'src/sidepanel/voice/pcm-encode.ts'))};export async function fileToWavSegments(){if(window.deferDecode)await new Promise(r=>window.finishDecode=r);const wav=wrapPcmS16leAsWav(new Uint8Array(32000),16000,1);return{ok:true,segments:[{wav},{wav}],durationSec:2}}`;
+require(path.join(root,'node_modules/esbuild')).build({stdin:{contents:source,resolveDir:root,loader:'tsx'},bundle:true,outfile:path.join(out,'app.js'),jsx:'automatic',plugins:[{name:'synthetic-pcm',setup(b){b.onResolve({filter:/\/pcm-stream-capture$/},()=>({path:'pcm-fixture',namespace:'fixture'}));b.onResolve({filter:/\/meeting-audio-import$/},()=>({path:'import-fixture',namespace:'fixture'}));b.onLoad({filter:/.*/,namespace:'fixture'},args=>({contents:args.path==='import-fixture'?audioImport:capture,loader:'ts',resolveDir:root}));}}]}).then(()=>fs.writeFileSync(path.join(out,'index.html'),'<html lang="zh-CN"><meta charset="utf-8"><body><div id="root"></div><script src="app.js"></script></body></html>')).catch(e=>{console.error(e);process.exitCode=1});
diff --git a/chrome-extension/scripts/render-workspace-fixture.cjs b/chrome-extension/scripts/render-workspace-fixture.cjs
index a3267846..75f89fb1 100644
--- a/chrome-extension/scripts/render-workspace-fixture.cjs
+++ b/chrome-extension/scripts/render-workspace-fixture.cjs
@@ -5,11 +5,25 @@ const store=path.join(root,'src/sidepanel/store/agentStore.tsx');
 const hook=`import {useEffect} from 'react';import {useAgentStore} from ${JSON.stringify(store)};
 export const shouldApplyStreamEvent=()=>true;
 export function useWebSocket(){const {state,dispatch}=useAgentStore();window.fixtureState=state;useEffect(()=>{window.dispatchUI=dispatch;const threads=window.demoThreads;dispatch({type:'SET_CONNECTION',state:'connected'});dispatch({type:'SET_THREADS',threads});dispatch({type:'SET_ACTIVE_THREAD',threadId:threads[0].id});dispatch({type:'SET_MESSAGES',messages:[]});},[]);return {connectionState:state.connectionState};}`;
-const source=`import {CockpitRoot} from ${JSON.stringify(path.join(root,'src/cockpit/CockpitApp.tsx'))};import React from 'react';import{createRoot}from'react-dom/client';import{App}from${JSON.stringify(path.join(root,'src/sidepanel/App.tsx'))};
+const source=`import {recordedThreadMutationResponses} from ${JSON.stringify(path.join(root,'tests/fixtures/thread-mutation-responses.ts'))};import {CockpitRoot} from ${JSON.stringify(path.join(root,'src/cockpit/CockpitApp.tsx'))};import React from 'react';import{createRoot}from'react-dom/client';import{App}from${JSON.stringify(path.join(root,'src/sidepanel/App.tsx'))};
 const event={addListener(){},removeListener(){}};window.sent=[];window.runtimeListeners=new Set();window.emitRuntime=message=>{for(const fn of window.runtimeListeners)fn(message)};const runtimeEvent={addListener:fn=>window.runtimeListeners.add(fn),removeListener:fn=>window.runtimeListeners.delete(fn)};
 window.demoThreads=['发布 v2.8 · 变更材料','支付服务 · 需求与测试追溯','本周运行状态巡检','整理架构评审记录'].map((alias,i)=>({id:'demo-'+i,alias,created_at:new Date().toISOString(),updated_at:new Date().toISOString(),config_override:{},tool_whitelist:null,pinned_tabs:[],active_skill_ids:[],agent_role:'normal'}));
 const tabs=[{id:1,title:'支付服务 · 版本 v2.8 — DevOps',url:'https://devops.example.test/releases/2.8',active:true}];
 const respond=(value,cb)=>{if(typeof cb==='function')queueMicrotask(()=>cb(value));return Promise.resolve(value)};
-window.chrome={runtime:{id:'preview',getURL:p=>p,onMessage:runtimeEvent,onConnect:event,sendMessage:(m,cb)=>{window.sent.push(m);let value={ok:true};if(m.type==='thread.update' && m.id && window.metadataReply!=='ack-only')setTimeout(()=>window.emitRuntime(window.metadataReply==='error'?{type:'error',id:m.id,error:'Fixture persistence failed'}:{type:'thread.updated',id:m.id,thread:{...window.fixtureState.threads.find(t=>t.id===m.thread_id),...m.updates}}),25);if(m.type==='thread.create')value={thread:{...window.demoThreads[0],id:'created-'+Date.now(),alias:''}};if(m.type==='thread.select')setTimeout(()=>window.dispatchUI({type:'SET_MESSAGES',messages:[]}),0);return respond(value,cb)},connect:()=>({onMessage:event,onDisconnect:event,postMessage(){},disconnect(){}})},storage:{local:{get:(keys,cb)=>respond({},cb),set:(v,cb)=>respond({},cb)},onChanged:event},tabs:{query:(q,cb)=>respond(tabs,cb),onActivated:event,onUpdated:event},windows:{getCurrent:(o,cb)=>respond({id:1},cb)},commands:{onCommand:event}};
+window.mutationRequests=[];
+window.finishThreadMutation=(m)=>{
+ if(m.probe){window.emitRuntime(window.legacyEmptyProbe?{type:'error',id:m.id,error:'thread.batch_delete requires non-empty thread_ids'}:{...recordedThreadMutationResponses.capabilities,id:m.id});return;}
+ const mode=m.type==='thread.restore'?'restore':m.mode;
+ const ids=m.thread_ids, server=window.fixtureServerThreads || window.fixtureState.threads;
+ const failed=ids.filter(id=>(window.mutationFailedIds||[]).includes(id) || (m.only_empty && server.find(t=>t.id===id)?.message_count>0)).map(id=>({id,reason:m.only_empty?'not_empty':'thread_busy'}));
+ const ok=ids.filter(id=>!failed.some(f=>f.id===id));
+ window.fixtureServerThreads=server.flatMap(t=>!ok.includes(t.id)?[t]:mode==='hard'?[]:[{...t,trashed_at:mode==='restore'?null:new Date().toISOString()}]);
+ // Result fields come from the real companion router capture used by contract tests.
+ const result={...recordedThreadMutationResponses[mode],id:m.id,failed};
+ if(mode==='restore'){result.restored=ok;result.restored_count=ok.length;}
+ else {result.ok=ok;result.deleted_ids=ok;result.deleted_count=ok.length;}
+ window.emitRuntime(result);
+};
+window.chrome={runtime:{id:'preview',getURL:p=>p,onMessage:runtimeEvent,onConnect:event,sendMessage:(m,cb)=>{window.sent.push(m);let value={ok:true,id:m.id};if(m.type==='thread.update' && m.id && window.metadataReply!=='ack-only')setTimeout(()=>window.emitRuntime(window.metadataReply==='error'?{type:'error',id:m.id,error:'Fixture persistence failed'}:{type:'thread.updated',id:m.id,thread:{...window.fixtureState.threads.find(t=>t.id===m.thread_id),...m.updates}}),25);if(m.type==='thread.create')value={thread:{...window.demoThreads[0],id:'created-'+Date.now(),alias:''}};if(m.type==='thread.select')setTimeout(()=>window.dispatchUI({type:'SET_MESSAGES',messages:[]}),0);if(m.type==='thread.batch_delete'||m.type==='thread.restore'){window.mutationRequests.push(m);if(window.mutationReply==='offline')value={ok:false,id:m.id};else if(window.mutationReply!=='defer')setTimeout(()=>window.finishThreadMutation(m),25);}if(m.type==='thread.list' && window.fixtureServerThreads)setTimeout(()=>window.dispatchUI({type:'SET_THREADS',threads:window.fixtureServerThreads.filter(t=>m.include_trashed||!t.trashed_at)}),25);return respond(value,cb)},connect:()=>({onMessage:event,onDisconnect:event,postMessage(){},disconnect(){}})},storage:{local:{get:(keys,cb)=>respond({},cb),set:(v,cb)=>respond({},cb)},onChanged:event},tabs:{query:(q,cb)=>respond(tabs,cb),onActivated:event,onUpdated:event},windows:{getCurrent:(o,cb)=>respond({id:1},cb)},commands:{onCommand:event}};
 createRoot(document.getElementById('root')).render(location.search.includes('cockpit') ? <CockpitRoot/> : <App/>);`;
 require(path.join(root,'node_modules/esbuild')).build({stdin:{contents:source,resolveDir:root,loader:'tsx'},bundle:true,outfile:path.join(out,'app.js'),jsx:'automatic',loader:{'.css':'css','.woff2':'dataurl','.woff':'dataurl','.ttf':'dataurl'},plugins:[{name:'synthetic-transport',setup(b){b.onResolve({filter:/hooks\/useWebSocket$/},()=>({path:'fixture-hook',namespace:'fixture'}));b.onLoad({filter:/.*/,namespace:'fixture'},()=>({contents:hook,loader:'tsx',resolveDir:root}));}}]}).then(()=>{fs.writeFileSync(path.join(out,'index.html'),'<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="app.css"><body style="margin:0"><div id="root"></div><script src="app.js"></script></body></html>');console.log(out)}).catch(e=>{console.error(e);process.exit(1)});
diff --git a/chrome-extension/scripts/test-meeting-close-ui.py b/chrome-extension/scripts/test-meeting-close-ui.py
new file mode 100644
index 00000000..5b4b5e45
--- /dev/null
+++ b/chrome-extension/scripts/test-meeting-close-ui.py
@@ -0,0 +1,106 @@
+"""Production Host/Meeting/adapter, synthetic PCM + transport. No real audio."""
+from pathlib import Path
+import subprocess
+import tempfile
+from playwright.sync_api import sync_playwright
+
+project = Path(__file__).resolve().parent.parent
+with tempfile.TemporaryDirectory(prefix='cmspark-meeting-close-') as directory:
+    subprocess.run(['node', 'scripts/render-meeting-close-fixture.cjs', directory], cwd=project, check=True)
+    with sync_playwright() as p:
+        browser = p.chromium.launch(channel='chrome', headless=True)
+        page = browser.new_page()
+        errors = []
+        page.on('pageerror', lambda error: errors.append(str(error)))
+        def open_fixture():
+            page.goto((Path(directory)/'index.html').as_uri())
+            page.get_by_test_id('meeting-start-capture').wait_for()
+            page.wait_for_function('!document.querySelector("[data-testid=meeting-start-capture]").disabled')
+        def start():
+            page.get_by_test_id('meeting-start-capture').click()
+            page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.start")')
+            page.evaluate('window.capture.onPcmChunk(new Uint8Array(32000))')
+        def final():
+            page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
+            assert page.get_by_test_id('meeting-panel').is_visible()
+            assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
+            page.evaluate("window.emit({type:'voice.stt.result',sessionId:window.sent.find(m=>m.type==='voice.stt.end').sessionId,text:'最后一段合成转写'})")
+        for action in ['host', 'inner', 'skills', 'escape', 'settings', 'latest', 'owner']:
+            open_fixture(); start()
+            if action == 'host': page.get_by_role('button',name='结束并收起',exact=True).click()
+            elif action == 'inner': page.get_by_role('button',name='结束录制并收起面板',exact=True).click()
+            elif action == 'skills': page.get_by_role('button',name='切换技能',exact=True).click()
+            elif action == 'settings': page.get_by_role('button',name='打开设置',exact=True).click()
+            elif action == 'latest':
+                page.get_by_role('button',name='切换技能',exact=True).click()
+                page.get_by_role('button',name='切换知识',exact=True).click()
+            elif action == 'owner':
+                page.get_by_role('button',name='结束并收起',exact=True).click()
+                page.evaluate("window.emit({type:'meeting.created',meeting:{id:'other-meeting'}})")
+            else:
+                page.get_by_role('button',name='结束并收起',exact=True).focus()
+                page.keyboard.press('Escape')
+            final()
+            page.wait_for_function('window.activePanel!=="meeting"')
+            assert page.evaluate('window.persisted') == ['最后一段合成转写']
+            assert page.evaluate('window.captureStops') == 1
+            assert page.evaluate('window.captureAborts') == 0
+            types = page.evaluate('window.sent.map(m=>m.type)')
+            assert types.index('meeting.append_transcript') < types.index('meeting.get') < types.index('meeting.end')
+            assert page.evaluate("window.sent.filter(m=>['meeting.append_transcript','meeting.get','meeting.end'].includes(m.type)).every(m=>m.id==='meeting-fixture')")
+            if action == 'settings': assert page.get_by_test_id('settings-state').inner_text() == '设置已打开'
+            if action == 'latest': assert page.evaluate('window.activePanel') == 'knowledge'
+        # A successful forwarding ACK / incorrect persisted snapshot must not close.
+        open_fixture(); start(); page.evaluate('window.failRead=true')
+        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
+        page.get_by_role('alert').filter(has_text='尚未确认保存').wait_for()
+        assert page.evaluate('window.activePanel') == 'meeting'
+        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
+        page.evaluate('window.failRead=false')
+        page.get_by_role('button',name='收起面板',exact=True).click()
+        page.wait_for_function('window.activePanel===null')
+        # Final dispatch is not end confirmation: keep the owner mounted until ACK.
+        open_fixture(); start(); page.evaluate('window.deferEnd=true')
+        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
+        page.wait_for_function('window.sent.some(m=>m.type==="meeting.end")')
+        assert page.evaluate('window.activePanel') == 'meeting'
+        page.evaluate("window.emit({type:'meeting.ended',meeting:{id:'other'}})")
+        assert page.evaluate('window.activePanel') == 'meeting'
+        page.evaluate("window.emit({type:'meeting.ended',meeting:window.snapshot()})")
+        page.wait_for_function('window.activePanel===null')
+        # Closing before meeting.started must not acquire a mic when start arrives.
+        open_fixture(); page.evaluate('window.deferStart=true')
+        page.get_by_test_id('meeting-start-capture').click()
+        page.get_by_role('button',name='结束并收起',exact=True).click()
+        page.wait_for_timeout(20)
+        page.evaluate("window.emit({type:'meeting.started',meeting:window.snapshot()})")
+        page.wait_for_function('window.activePanel===null')
+        assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start")')
+        # Import stop keeps the current final, saves it, and skips remaining segments.
+        open_fixture()
+        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
+        page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
+        page.get_by_role('button',name='结束并收起',exact=True).click()
+        final()
+        page.wait_for_function('window.activePanel===null')
+        assert page.evaluate('window.persisted') == ['最后一段合成转写']
+        assert page.evaluate('window.sent.filter(m=>m.type==="voice.stt.start").length') == 1
+        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
+        # Closing while decoding cancels before creating a meeting or STT session.
+        open_fixture(); page.evaluate('window.deferDecode=true')
+        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
+        page.wait_for_function('!!window.finishDecode')
+        page.get_by_role('button',name='结束并收起',exact=True).click()
+        page.wait_for_timeout(20); page.evaluate('window.finishDecode()')
+        page.wait_for_function('window.activePanel===null')
+        assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start"||m.type==="meeting.create")')
+        # Accelerate only the production 20s stop deadline; transport/final absent.
+        page.add_init_script("const timeout=window.setTimeout.bind(window);window.setTimeout=(f,ms,...args)=>timeout(f,ms===20000?40:ms,...args)")
+        open_fixture(); start()
+        page.get_by_role('button',name='结束并收起',exact=True).click()
+        page.get_by_role('alert').filter(has_text='未完整处理').wait_for()
+        assert page.evaluate('window.activePanel') == 'meeting'
+        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
+        assert not errors, errors
+        browser.close()
+print('PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation')
diff --git a/chrome-extension/scripts/test-thread-mutations-ui.py b/chrome-extension/scripts/test-thread-mutations-ui.py
new file mode 100644
index 00000000..43cfee84
--- /dev/null
+++ b/chrome-extension/scripts/test-thread-mutations-ui.py
@@ -0,0 +1,143 @@
+"""#488 actual App + recorded server payload shapes, isolated synthetic transport.
+No live Chrome profile, conversation, microphone, or configuration is accessed.
+"""
+from pathlib import Path
+import subprocess, tempfile
+from playwright.sync_api import sync_playwright
+
+root=Path(__file__).resolve().parent.parent
+shots=Path('/private/tmp/cmspark-488-shots');shots.mkdir(exist_ok=True)
+with tempfile.TemporaryDirectory() as out:
+ subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
+ with sync_playwright() as p:
+  browser=p.chromium.launch(channel='chrome',headless=True)
+  errors=[]
+  def setup(count=60,trash=False,width=390,height=740):
+   page=browser.new_page(viewport={'width':width,'height':height});page.set_default_timeout(7000)
+   page.on('pageerror',lambda e:errors.append(str(e)))
+   page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
+   page.evaluate('''({count,trash})=>{
+    const threads=Array.from({length:count},(_,i)=>({...window.demoThreads[0],id:'t'+i,alias:'对话 '+i,message_count:4,user_tags:[i<2?'支付':'架构'],trashed_at:trash?'2026-09-09T00:00:00Z':null}));
+    window.fixtureServerThreads=structuredClone(threads);
+    window.dispatchUI({type:'SET_THREADS',threads});window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'t0'});
+   }''',{'count':count,'trash':trash})
+   page.get_by_role('button',name='对话管理（历史对话）',exact=True).click()
+   manager=page.get_by_role('dialog',name='历史对话列表',exact=True);manager.wait_for()
+   if trash:
+    manager.get_by_role('button',name='回收站',exact=True).click()
+    manager.get_by_text(f'回收站 · {count}',exact=False).wait_for()
+   return page,manager
+  def select_all(manager):manager.get_by_role('button',name='全选',exact=True).click()
+  def confirm_delete(manager,hard=False):
+   manager.locator('.cm-thread-selection-bar').get_by_role('button',name='永久删除' if hard else '移入回收站',exact=True).click()
+   dialog=manager.get_by_role('alertdialog',name='确认删除会话');dialog.wait_for()
+   assert dialog.get_by_role('button',name='取消',exact=True).evaluate('(el)=>el===document.activeElement')
+   dialog.get_by_role('button',name='永久删除' if hard else '移入回收站',exact=True).click()
+
+  # A visible tag filter is the complete selection boundary.
+  page,m=setup();m.get_by_role('button',name='标签',exact=True).click();m.get_by_role('button',name='#支付 2',exact=True).click()
+  select_all(m);m.get_by_text('已选 2',exact=True).wait_for()
+  page.evaluate('window.mutationReply="defer"');confirm_delete(m)
+  assert page.evaluate('window.mutationRequests[0].thread_ids')==['t0','t1']
+  assert page.evaluate('window.fixtureState.threads.length')==60
+  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
+  page.wait_for_function('window.fixtureState.threads.length===58');page.close()
+
+  # More than 50 items are sent serially; a transport ACK never removes rows.
+  page,m=setup();page.evaluate('window.mutationReply="defer"');select_all(m);confirm_delete(m)
+  assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids.length)')==[50]
+  assert page.evaluate('window.fixtureState.threads.length')==60
+  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
+  page.wait_for_function('window.mutationRequests.length===2')
+  assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids.length)')==[50,10]
+  page.evaluate('window.finishThreadMutation(window.mutationRequests[1])')
+  page.wait_for_function('window.fixtureState.threads.length===0');page.close()
+
+  # Busy/filter changes only shrink a selection; no deletion of another row.
+  for change in ['busy','filter']:
+   page,m=setup(3);m.get_by_role('button',name='选择',exact=True).click()
+   m.locator('[data-thread-id="t0"] input[type="checkbox"]').check()
+   if change=='busy':page.evaluate('window.dispatchUI({type:"SET_THREAD_BUSY",threadId:"t0",busy:true})')
+   else:m.get_by_role('searchbox').fill('对话 1')
+   m.get_by_text('已选 0',exact=True).wait_for()
+   assert m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).is_disabled()
+   assert page.evaluate('window.mutationRequests.length')==0;page.close()
+
+  # Confirmation re-checks busy state even after the target preview was opened.
+  page,m=setup(2);select_all(m)
+  m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).click()
+  page.evaluate('window.dispatchUI({type:"SET_THREAD_BUSY",threadId:"t0",busy:true})')
+  m.get_by_role('alertdialog').get_by_role('button',name='移入回收站',exact=True).click()
+  m.get_by_role('status').filter(has_text='状态已变化').wait_for()
+  assert page.evaluate('window.mutationRequests.length')==0;page.close()
+
+  # Offline and partial failures retain failed records with an actionable result.
+  page,m=setup(3);page.evaluate('window.mutationReply="offline"');select_all(m);confirm_delete(m)
+  m.get_by_role('status').filter(has_text='未发送').wait_for()
+  assert page.evaluate('window.fixtureState.threads.length')==3;page.close()
+  page,m=setup(3);page.evaluate('window.mutationFailedIds=["t1"]');select_all(m);confirm_delete(m)
+  page.wait_for_function('window.fixtureState.threads.length===1')
+  assert page.evaluate('window.fixtureState.threads[0].id')=='t1'
+  m.get_by_role('status').filter(has_text='已移入回收站 2').wait_for();page.close()
+
+  # Restore waits for persistence, then refreshes including remaining trash rows.
+  page,m=setup(3,trash=True);page.evaluate('window.mutationReply="defer";window.mutationFailedIds=["t1"]');select_all(m)
+  m.locator('.cm-thread-selection-bar').get_by_role('button',name='恢复',exact=True).click()
+  assert page.evaluate('window.fixtureState.threads.filter(t=>t.trashed_at).length')==3
+  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
+  page.wait_for_function('window.fixtureState.threads.filter(t=>t.trashed_at).length===1')
+  assert page.evaluate('window.fixtureState.threads.find(t=>t.trashed_at).id')=='t1'
+  assert page.evaluate('window.sent.filter(m=>m.type==="thread.list").at(-1).include_trashed') is True
+  page.close()
+
+  # Empty cleanup uses an in-app preview, probes safely, and rechecks server content.
+  for legacy in [False,True]:
+   page,m=setup(3)
+   page.evaluate('''legacy=>{window.legacyEmptyProbe=legacy;
+    const threads=window.fixtureState.threads.map(t=>({...t,message_count:0}));
+    window.dispatchUI({type:'SET_THREADS',threads});
+    window.fixtureServerThreads=threads.map(t=>({...t,message_count:t.id==='t1'?1:0}));
+   }''',legacy)
+   m.get_by_title('更多',exact=True).click()
+   page.get_by_role('menu').get_by_role('button',name='🧹 清理空白',exact=True).click()
+   m.get_by_role('alertdialog').get_by_role('button',name='永久删除',exact=True).click()
+   if legacy:
+    m.get_by_role('status').filter(has_text='请更新 Companion').wait_for()
+    assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids)')==[[]]
+    assert page.evaluate('window.fixtureState.threads.length')==3
+   else:
+    page.wait_for_function('window.fixtureState.threads.length===2')
+    assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids)')==[[],['t1','t2']]
+    assert page.evaluate('window.fixtureState.threads.map(t=>t.id)')==['t0','t1']
+   page.close()
+
+  # Cleanup's checkboxes and bulk-list selection are visibly separate scopes.
+  page,m=setup(4)
+  page.evaluate('window.dispatchEvent(new CustomEvent("cmspark:cleanup_suggestions",{detail:{suggestions:[{thread_id:"t1",reason:"thin",detail:"test",precheck:true},{thread_id:"t2",reason:"thin",detail:"test"}]}}))')
+  cleanup=m.get_by_role('region',name='整理建议');cleanup.wait_for()
+  select_all(m)
+  assert cleanup.locator('input:checked').count()==1
+  cleanup.get_by_role('button',name='全选建议',exact=True).click()
+  assert cleanup.locator('input:checked').count()==2
+  m.get_by_role('button',name='取消全选',exact=True).click()
+  assert cleanup.locator('input:checked').count()==2
+  cleanup.get_by_role('button',name='清空建议选择',exact=True).click()
+  assert cleanup.get_by_role('button',name='移入回收站（0）',exact=True).is_disabled();page.close()
+
+  # Short windows retain scrollable rows, all management tools and outside stop.
+  for width,height in [(320,480),(390,740),(760,740),(1440,900)]:
+   page,m=setup(6,width=width,height=height)
+   for view in ['时间','标签','手动分组','AI 分组']:
+    m.get_by_role('button',name=view,exact=True).click()
+    assert m.locator('.cm-thread-management-list').bounding_box()['height']>=100
+    assert m.evaluate('(el)=>el.scrollWidth<=el.clientWidth')
+   m.get_by_role('button',name='时间',exact=True).click();select_all(m)
+   m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).scroll_into_view_if_needed()
+   assert m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
+   m.get_by_role('button',name='取消选择',exact=True).click()
+   for label in ['AI 提取标签','整理助手','关系图谱','回收站']:
+    button=m.get_by_role('button',name=label,exact=True);button.scroll_into_view_if_needed();assert button.is_visible()
+   m.evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(shots/f'manager-{width}.png'));page.close()
+  assert not errors,errors
+  browser.close()
+print('PASS: actual App selection boundaries, busy/filter race, 60-item batching, ACK vs persisted result, offline/partial failure, restore, independent cleanup scope and responsive management capabilities.')
diff --git a/chrome-extension/src/background/index.ts b/chrome-extension/src/background/index.ts
index 584714f2..a58b96ad 100644
--- a/chrome-extension/src/background/index.ts
+++ b/chrome-extension/src/background/index.ts
@@ -336,6 +336,8 @@ function init() {
 
 function handleStateChange(state: "connected" | "connecting" | "disconnected") {
   updateBadge(state)
+  // Mutation waiters must stop on connection loss; never retry destructive work.
+  chrome.runtime.sendMessage({ type: "thread.mutation.connection", state }).catch(() => {})
 
   if (state === "disconnected") {
     scheduleDisconnectNotification()
@@ -1004,35 +1006,53 @@ function handleRuntimeMessage(message: any, sendResponse: (r?: any) => void): bo
         sendResponse({ ok: true })
         return true
 
-      case "thread.delete":
+      case "thread.delete": {
+        if (wsClient.getState() !== "connected") {
+          sendResponse({ id: message.id, ok: false, error: "Companion 未连接，未发送操作" })
+          return false
+        }
         // Align with companion: omit/unknown → hard; only explicit "trash" soft-deletes.
-        wsClient.send({
+        const sent = wsClient.send({
           type: "thread.delete",
+          id: message.id,
           thread_id: message.thread_id || message.threadId,
           mode: message.mode === "trash" ? "trash" : "hard",
         })
-        sendResponse({ ok: true })
+        sendResponse({ id: message.id, ok: sent })
         return true
+      }
 
       case "thread.batch_delete": {
+        if (wsClient.getState() !== "connected") {
+          sendResponse({ id: message.id, ok: false, error: "Companion 未连接，未发送操作" })
+          return false
+        }
         const ids = Array.isArray(message.thread_ids) ? message.thread_ids : []
         // Multi-select product default is recycle bin; permanent only with mode hard.
-        wsClient.send({
+        const sent = wsClient.send({
           type: "thread.batch_delete",
+          id: message.id,
           thread_ids: ids,
           mode: message.mode === "hard" ? "hard" : "trash",
+          ...(message.only_empty === true ? { only_empty: true } : {}),
+          ...(message.probe !== undefined ? { probe: message.probe } : {}),
         })
-        sendResponse({ ok: true })
+        sendResponse({ id: message.id, ok: sent })
         return true
       }
 
       case "thread.restore": {
-        wsClient.send({
+        if (wsClient.getState() !== "connected") {
+          sendResponse({ id: message.id, ok: false, error: "Companion 未连接，未发送操作" })
+          return false
+        }
+        const sent = wsClient.send({
           type: "thread.restore",
+          id: message.id,
           thread_id: message.thread_id,
           thread_ids: message.thread_ids,
         })
-        sendResponse({ ok: true })
+        sendResponse({ id: message.id, ok: sent })
         return true
       }
 
diff --git a/chrome-extension/src/sidepanel/components/ComposeDrawer.tsx b/chrome-extension/src/sidepanel/components/ComposeDrawer.tsx
index c79d0438..cb62a1ce 100644
--- a/chrome-extension/src/sidepanel/components/ComposeDrawer.tsx
+++ b/chrome-extension/src/sidepanel/components/ComposeDrawer.tsx
@@ -14,10 +14,8 @@ import {
 import {
   COMPOSE_GROUP_LABELS,
   COMPOSE_SECTIONS,
-  composeAttachLine,
   composeSectionGroups,
   composeSectionsInGroup,
-  surfaceLxLabel,
   type ComposeSection,
   type ComposeSectionGroup,
   type ComposeSectionId,
@@ -40,6 +38,15 @@ import {
 
 const FIRST_SECTION_ID: ComposeSectionId = COMPOSE_SECTIONS[0]?.id ?? "skills"
 
+const SECTION_SCOPE: Record<ComposeSectionId, string> = {
+  skills: "管理全局技能；按需用于对话",
+  knowledge: "管理知识库；选择本次对话使用的知识",
+  packs: "管理场景与专家；选择本对话工作区",
+  mcp: "管理全局 MCP 连接",
+  apps: "管理全局应用连接",
+  history: "查看与管理全部对话",
+}
+
 const SECTION_ICONS: Record<ComposeSection["id"], ComponentType<IconProps>> = {
   skills: IconSkills,
   knowledge: IconKnowledge,
@@ -54,7 +61,7 @@ export type ComposeDrawerProps = {
   onClose: () => void
   /** Open Host panel and close drawer. */
   onOpenSection: (panelId: ContextPanelId) => void
-  /** Current Surface level for §4.5 “挂到 … Surface Lx” copy. */
+  /** Accepted for caller compatibility; resource configuration is not Surface-scoped. */
   capabilityLevel?: CapabilityLevel
 }
 
@@ -62,10 +69,8 @@ export function ComposeDrawer({
   open,
   onClose,
   onOpenSection,
-  capabilityLevel = "chat",
 }: ComposeDrawerProps) {
   const firstBtnRef = useRef<HTMLButtonElement>(null)
-  const attachLine = composeAttachLine(capabilityLevel)
   const groups = composeSectionGroups()
 
   const handleSection = (section: ComposeSection) => {
@@ -86,7 +91,7 @@ export function ComposeDrawer({
           <div style={{ minWidth: 0 }}>
             <div style={styles.title}>装配</div>
             <div style={styles.subtitle}>
-              组合能力 · {attachLine}
+              管理资源与连接，按需用于对话
             </div>
           </div>
           <button
@@ -100,10 +105,6 @@ export function ComposeDrawer({
           </button>
         </div>
 
-        <div style={styles.surfaceChip} aria-hidden>
-          Surface {surfaceLxLabel(capabilityLevel)}
-        </div>
-
         {groups.map((group) => (
           <SectionGroup
             key={group}
@@ -111,12 +112,11 @@ export function ComposeDrawer({
             firstSectionId={FIRST_SECTION_ID}
             firstBtnRef={firstBtnRef}
             onOpen={handleSection}
-            attachLine={attachLine}
           />
         ))}
 
         <p style={styles.footNote} data-testid="compose-autonomy-note">
-          任务板不在装配内 — 使用 /board
+          任务板可从“资料与工具”或 /board 打开
         </p>
       </div>
     </BottomSheet>
@@ -128,13 +128,11 @@ function SectionGroup({
   firstSectionId,
   firstBtnRef,
   onOpen,
-  attachLine,
 }: {
   group: ComposeSectionGroup
   firstSectionId: ComposeSectionId
   firstBtnRef: RefObject<HTMLButtonElement>
   onOpen: (section: ComposeSection) => void
-  attachLine: string
 }) {
   const sections = composeSectionsInGroup(group)
   if (sections.length === 0) return null
@@ -158,7 +156,7 @@ function SectionGroup({
               <SectionRowButton
                 section={section}
                 Icon={Icon}
-                attachLine={attachLine}
+                attachLine={SECTION_SCOPE[section.id]}
                 buttonRef={section.id === firstSectionId ? firstBtnRef : undefined}
                 onOpen={onOpen}
               />
diff --git a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
index e46a3a4b..f12e5ed6 100644
--- a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
+++ b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
@@ -126,6 +126,8 @@ export type ContextPanelHostApi = {
   /** Force-open (no toggle) — used by slash / custom events. */
   openPanelForce: (id: ContextPanelId) => void
   closePanel: () => void
+  /** A recording panel can finish its last segment before navigation unmounts it. */
+  registerBeforeClose: (guard: () => Promise<boolean>) => () => void
 }
 
 const ContextPanelHostContext = createContext<ContextPanelHostApi | null>(null)
@@ -153,9 +155,17 @@ export function ContextPanelHostProvider({
   children: ReactNode
 }) {
   const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
+  const activePanelRef = useRef(activePanel)
+  activePanelRef.current = activePanel
+  const beforeCloseRef = useRef<(() => Promise<boolean>) | null>(null)
+  const transitionRef = useRef<Promise<boolean> | null>(null)
+  const targetRef = useRef<ContextPanelId | null>(null)
+  const transitionVersion = useRef(0)
   const pendingKnowledgeFocus = useRef<string | null>(null)
   const { state, dispatch } = useAgentStore()
   const activeThreadId = state.activeThreadId
+  const activeThreadRef = useRef(activeThreadId)
+  activeThreadRef.current = activeThreadId
 
   const allowedIds = useMemo(
     () => new Set(contextBarTabsForLevel(capabilityLevel)),
@@ -166,63 +176,89 @@ export function ContextPanelHostProvider({
     [capabilityLevel],
   )
 
-  const closePanel = useCallback(() => {
-    setActivePanel(null)
+  const registerBeforeClose = useCallback((guard: () => Promise<boolean>) => {
+    beforeCloseRef.current = guard
+    return () => { if (beforeCloseRef.current === guard) beforeCloseRef.current = null }
   }, [])
 
+  const requestPanelChange = useCallback((id: ContextPanelId | null): Promise<boolean> => {
+    targetRef.current = id
+    transitionVersion.current += 1
+    if (transitionRef.current) return transitionRef.current
+    if (activePanelRef.current === id) {
+      if (id) loadPanelData(id, activeThreadRef.current, dispatch)
+      return Promise.resolve(true)
+    }
+    const apply = () => {
+      const target = targetRef.current
+      activePanelRef.current = target
+      setActivePanel(target)
+      if (target) loadPanelData(target, activeThreadRef.current, dispatch)
+    }
+    const guard = beforeCloseRef.current
+    if (!guard) { apply(); return Promise.resolve(true) }
+    const pending = Promise.resolve().then(guard).then(allowed => {
+      if (allowed) apply()
+      return allowed
+    }, () => false).finally(() => { transitionRef.current = null })
+    transitionRef.current = pending
+    return pending
+  }, [dispatch])
+
+  const closePanel = useCallback(() => { void requestPanelChange(null) }, [requestPanelChange])
+
   useEffect(() => {
-    if (state.settingsOpen) closePanel()
-  }, [state.settingsOpen, closePanel])
+    if (!state.settingsOpen) return
+    if (!beforeCloseRef.current) { closePanel(); return }
+    // Keep the finishing/error state visible; open settings after a successful close.
+    dispatch({ type: "SET_SETTINGS_OPEN", open: false })
+    const pending = requestPanelChange(null)
+    const version = transitionVersion.current
+    void pending.then(allowed => {
+      if (allowed && version === transitionVersion.current) dispatch({ type: "SET_SETTINGS_OPEN", open: true })
+    })
+  }, [state.settingsOpen, closePanel, dispatch, requestPanelChange])
 
   const openPanelForce = useCallback(
     (id: ContextPanelId) => {
-      setActivePanel(id)
-      loadPanelData(id, activeThreadId, dispatch)
+      void requestPanelChange(id)
     },
-    [activeThreadId, dispatch],
+    [requestPanelChange],
   )
 
   const openPanel = useCallback(
     (id: ContextPanelId) => {
-      if (activePanel === id) {
-        setActivePanel(null)
-        return
-      }
-      setActivePanel(id)
-      loadPanelData(id, activeThreadId, dispatch)
+      void requestPanelChange(activePanelRef.current === id ? null : id)
     },
-    [activePanel, activeThreadId, dispatch],
+    [requestPanelChange],
   )
 
   // Close open panel if it is no longer primary or overflow for this level
   useEffect(() => {
     if (activePanel == null) return
     if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
-      setActivePanel(null)
+      closePanel()
     }
-  }, [activePanel, allowedIds, overflowIds])
+  }, [activePanel, allowedIds, overflowIds, closePanel])
 
   // S1: slash meta commands (/packs /board /mcp) open panels via soft event
   useEffect(() => {
     const onOpen = (e: Event) => {
       const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
       if (!raw || !isContextPanelId(raw)) return
-      setActivePanel(raw)
-      loadPanelData(raw, activeThreadId, dispatch)
+      openPanelForce(raw)
     }
     window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
     const onKnowledge = (e: Event) => {
       const id = (e as CustomEvent<{ id?: string }>).detail?.id
       if (id) pendingKnowledgeFocus.current = id
-      setActivePanel("knowledge")
-      loadPanelData("knowledge", activeThreadId, dispatch)
+      openPanelForce("knowledge")
     }
     window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
     const onGraphDoc = (msg: { type?: string; id?: string }) => {
       if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
       pendingKnowledgeFocus.current = msg.id
-      setActivePanel("knowledge")
-      loadPanelData("knowledge", activeThreadId, dispatch)
+      openPanelForce("knowledge")
     }
     chrome.runtime.onMessage.addListener(onGraphDoc)
     return () => {
@@ -230,7 +266,7 @@ export function ContextPanelHostProvider({
       window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
       chrome.runtime.onMessage.removeListener(onGraphDoc)
     }
-  }, [activeThreadId, dispatch])
+  }, [openPanelForce])
 
   useEffect(() => {
     if (activePanel !== "knowledge") return
@@ -248,15 +284,15 @@ export function ContextPanelHostProvider({
       const tag = (e.target as HTMLElement | null)?.tagName
       if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
       e.preventDefault()
-      setActivePanel(null)
+      closePanel()
     }
     window.addEventListener("keydown", onKey)
     return () => window.removeEventListener("keydown", onKey)
-  }, [activePanel])
+  }, [activePanel, closePanel])
 
   const api = useMemo<ContextPanelHostApi>(
-    () => ({ activePanel, openPanel, openPanelForce, closePanel }),
-    [activePanel, openPanel, openPanelForce, closePanel],
+    () => ({ activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose }),
+    [activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose],
   )
 
   return (
@@ -273,7 +309,7 @@ export function ContextPanelHostProvider({
  * (Host is SoT for panels).
  */
 export function ContextPanelHost() {
-  const { activePanel, closePanel } = useContextPanelHost()
+  const { activePanel, closePanel, registerBeforeClose } = useContextPanelHost()
   const meetingCaptureActive = useAgentStore().state.meetingCaptureActive
   if (!activePanel) return null
 
@@ -314,6 +350,7 @@ export function ContextPanelHost() {
       {activePanel === "meeting" && (
         <MeetingPanel
           onClose={closePanel}
+          registerBeforeClose={registerBeforeClose}
           onSendToDraft={(text) => {
             window.dispatchEvent(
               new CustomEvent("cmspark:fill-composer", { detail: { text } }),
@@ -1018,10 +1055,13 @@ const styles: Record<string, React.CSSProperties> = {
   },
   skillToolbar: {
     display: "flex",
+    flexWrap: "wrap",
     gap: 6,
     marginBottom: 8,
   },
   skillToolbarBtn: {
+    whiteSpace: "nowrap",
+    minHeight: 32,
     border: `1px solid ${tokens.border}`,
     borderRadius: tokens.radiusSm,
     background: tokens.bgElevated,
diff --git a/chrome-extension/src/sidepanel/components/MeetingPanel.tsx b/chrome-extension/src/sidepanel/components/MeetingPanel.tsx
index 089dfeab..1cfe5eb9 100644
--- a/chrome-extension/src/sidepanel/components/MeetingPanel.tsx
+++ b/chrome-extension/src/sidepanel/components/MeetingPanel.tsx
@@ -44,6 +44,7 @@ import {
 } from "../voice/meeting-live-refine"
 import { VOICE_PRIVACY_ACK_V2_CLAUSES } from "../voice/privacy-copy"
 import type { SpeechAdapter } from "../voice/web-speech-adapter"
+import { confirmMeetingClose } from "../voice/meeting-close"
 
 /** Format companion transcript lines for textarea (Speaker: text). */
 function formatLinesFromMeeting(transcript: any[]): string {
@@ -127,6 +128,7 @@ const formatElapsed = formatMeetingElapsed
 export function MeetingPanel(props: {
   onClose: () => void
   onSendToDraft: (text: string) => void
+  registerBeforeClose?: (guard: () => Promise<boolean>) => () => void
 }) {
   const { state, dispatch } = useAgentStore()
   const [title, setTitle] = useState("")
@@ -136,6 +138,7 @@ export function MeetingPanel(props: {
   const [status, setStatus] = useState<string>("")
   const [busy, setBusy] = useState(false)
   const [error, setError] = useState<string | null>(null)
+  const [closing, setClosing] = useState(false)
   const [ack, setAck] = useState(false)
   const [capturePhase, setCapturePhase] = useState<CapturePhase>("idle")
   const [elapsedMs, setElapsedMs] = useState(0)
@@ -150,6 +153,7 @@ export function MeetingPanel(props: {
   const audioFileRef = useRef<HTMLInputElement | null>(null)
   const defaultSpeakerRef = useRef("")
   const importAbortRef = useRef(false)
+  const importDoneRef = useRef<Promise<boolean> | null>(null)
   /** Skip server→textarea sync while user is typing (dual-review dirty-guard). */
   const transcriptDirtyRef = useRef(false)
   /** #260: per-line raw s16le PCM from last audio import (aligned with append order). */
@@ -173,6 +177,16 @@ export function MeetingPanel(props: {
   const transcriptRef = useRef("")
   /** Prevent double meeting.end / finalize. */
   const finalizedRef = useRef(false)
+  const finalizingRef = useRef(false)
+  const closePendingRef = useRef<Promise<boolean> | null>(null)
+  const captureFinishedRef = useRef<((ok: boolean) => void) | null>(null)
+  const closeFailureRef = useRef(false)
+  const needsClosePersistenceRef = useRef(false)
+  const closeMeetingIdRef = useRef<string | null>(null)
+  const closeNeedsEndRef = useRef(true)
+  const liveTextRef = useRef<string[]>([])
+  const cancelStartingRef = useRef(false)
+  const requestCloseRef = useRef<() => Promise<boolean>>(async () => true)
   const titleRef = useRef(title)
   const refineGenRef = useRef(0)
   const refineQueueRef = useRef(createSerialRefineQueue())
@@ -296,6 +310,7 @@ export function MeetingPanel(props: {
     ) => {
       const t = chunk.trim()
       if (!t) return
+      liveTextRef.current.push(t)
       const sp = defaultSpeakerRef.current.trim().slice(0, 32)
       const display = sp ? `${sp}: ${t}` : t
       setTranscript((prev) => {
@@ -396,6 +411,7 @@ export function MeetingPanel(props: {
     (opts: { generate: boolean; id: string | null }) => {
       if (finalizedRef.current) return
       finalizedRef.current = true
+      finalizingRef.current = true
       captureStartRef.current = null
       setPhase("idle")
       setSoftCapHint(false)
@@ -410,6 +426,10 @@ export function MeetingPanel(props: {
         // Wait for segment refine queue (cap ~22s) so minutes see refined text
         try {
           const drained = await refineQueueRef.current.drain()
+          if (!drained && closePendingRef.current) {
+            closeFailureRef.current = true
+            setError("最后一段仍在纠错，请等待转写完成后重试收起")
+          }
           if (!drained && wantGenerate) {
             setError((prev) =>
               prev ||
@@ -420,11 +440,11 @@ export function MeetingPanel(props: {
           /* best-effort */
         }
 
-        if (id) {
+        if (id && !closePendingRef.current) {
           sendViaRuntime({ type: "meeting.end", v: 1, id })
         }
         // Smart segment after refine drain so silence-cut sees full refined blob
-        if (wantSegment && id && transcriptRef.current.trim()) {
+        if (wantSegment && id && transcriptRef.current.trim() && !closePendingRef.current) {
           sendViaRuntime({
             type: "meeting.apply_silence_cut",
             v: 1,
@@ -437,7 +457,11 @@ export function MeetingPanel(props: {
           await new Promise((r) => setTimeout(r, 150))
           sendMinutesJob(id)
         }
-      })()
+      })().finally(() => {
+        finalizingRef.current = false
+        captureFinishedRef.current?.(!closeFailureRef.current)
+        captureFinishedRef.current = null
+      })
     },
     [destroyAdapter, dispatch, sendMinutesJob, setPhase],
   )
@@ -448,6 +472,7 @@ export function MeetingPanel(props: {
     if (capturePhase !== "stopping") return
     const t = setTimeout(() => {
       if (phaseRef.current !== "stopping" || finalizedRef.current) return
+      closeFailureRef.current = true
       setError((prev) => prev || "结束超时：已停止录制。可基于已有转写生成纪要")
       const gen = wantGenerateRef.current
       wantGenerateRef.current = false
@@ -464,6 +489,7 @@ export function MeetingPanel(props: {
     const t = setTimeout(() => {
       if (finalizedRef.current) return
       if (phaseRef.current === "idle") return
+      closeFailureRef.current = true
       setError((prev) => prev || "Companion 断开，已停止录制。可基于已有转写生成纪要")
       const gen = wantGenerateRef.current
       wantGenerateRef.current = false
@@ -493,6 +519,7 @@ export function MeetingPanel(props: {
 
   const startLocalSegments = useCallback(
     (id: string) => {
+      closeMeetingIdRef.current = id
       destroyAdapter()
       finalizedRef.current = false
 
@@ -527,7 +554,7 @@ export function MeetingPanel(props: {
           onResult: ({ interim, finalChunk }) => {
             if (finalChunk?.trim()) {
               setInterimText("")
-              commitLiveSegment(finalChunk, meetingIdRef.current || id)
+              commitLiveSegment(finalChunk, id)
               return
             }
             // Progressive hypothesis only (M2); do not append until window final.
@@ -540,6 +567,7 @@ export function MeetingPanel(props: {
             if (code === "aborted") return
             const mapped = mapLocalSttError(code)
             if (mapped.severity === "silent") return
+            if (closePendingRef.current) closeFailureRef.current = true
             // Soft = adapter continues; honest copy (segment+audio irreversibly lost).
             const soft = isMeetingSoftSegmentBanner(code)
             const msg = mapped.message || `转写错误: ${code}`
@@ -550,7 +578,7 @@ export function MeetingPanel(props: {
             const gen = wantGenerateRef.current
             wantGenerateRef.current = false
             if (phaseRef.current === "idle" && finalizedRef.current) return
-            finalizeCapture({ generate: gen, id: meetingIdRef.current || id })
+            finalizeCapture({ generate: gen, id })
           },
           onSegmentContinue: () => {
             if (phaseRef.current !== "stopping") setPhase("recording")
@@ -563,6 +591,9 @@ export function MeetingPanel(props: {
           send: sendViaRuntime,
           onMessage: subscribeVoiceStt,
           modelId: activeModelId,
+          // The panel owns the visible stop deadline. Do not let the adapter's
+          // shorter quiet-empty timeout turn an unfinished final into success.
+          stopGraceMs: MEETING_STOP_FAILSAFE_MS + 1_000,
         },
       )
       adapterRef.current = adapter
@@ -602,6 +633,9 @@ export function MeetingPanel(props: {
   useEffect(() => {
     return () => {
       const id = meetingIdRef.current
+      importAbortRef.current = true
+      captureFinishedRef.current?.(false)
+      captureFinishedRef.current = null
       const stillLive = phaseRef.current !== "idle" && !finalizedRef.current
       if (stillLive && id) {
         finalizedRef.current = true
@@ -622,9 +656,15 @@ export function MeetingPanel(props: {
       }
       if (msg.type === "meeting.started" && msg.meeting) {
         setMeetingId(msg.meeting.id)
+        meetingIdRef.current = msg.meeting.id
         setTitle(msg.meeting.title || titleRef.current)
         setStatus(msg.meeting.status || "recording")
-        if (phaseRef.current === "starting") {
+        if (cancelStartingRef.current) {
+          cancelStartingRef.current = false
+          closeMeetingIdRef.current = msg.meeting.id
+          finalizedRef.current = false
+          finalizeCapture({ generate: false, id: msg.meeting.id })
+        } else if (phaseRef.current === "starting") {
           startLocalSegmentsRef.current(msg.meeting.id)
         }
       }
@@ -703,6 +743,7 @@ export function MeetingPanel(props: {
         setError(null)
       }
       if (msg.type === "meeting.error") {
+        if (closePendingRef.current) closeFailureRef.current = true
         setError(msg.message || msg.code || "error")
         setBusy(false)
         setPendingGenerate(false)
@@ -714,10 +755,12 @@ export function MeetingPanel(props: {
           setPhase("idle")
           destroyAdapter()
           dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
+          captureFinishedRef.current?.(false)
+          captureFinishedRef.current = null
         }
       }
     },
-    [destroyAdapter, dispatch, setPhase],
+    [destroyAdapter, dispatch, setPhase, finalizeCapture],
   )
 
   useMeetingMessages(onMsg)
@@ -784,6 +827,12 @@ export function MeetingPanel(props: {
     setSoftCapHint(false)
     wantGenerateRef.current = false
     finalizedRef.current = false
+    closeFailureRef.current = false
+    needsClosePersistenceRef.current = true
+    closeMeetingIdRef.current = meetingId
+    closeNeedsEndRef.current = true
+    liveTextRef.current = []
+    cancelStartingRef.current = false
 
     sendViaRuntime({
       type: "meeting.start",
@@ -812,6 +861,61 @@ export function MeetingPanel(props: {
     }
   }
 
+  requestCloseRef.current = () => {
+    if (closePendingRef.current) return closePendingRef.current
+    const pending = Promise.resolve().then(async () => {
+      setClosing(true)
+      closeFailureRef.current = false
+      try {
+        if (importDoneRef.current) {
+          importAbortRef.current = true
+          setImportStatus("正在中止导入并保存当前段…")
+          const done = importDoneRef.current
+          const finished = await new Promise<boolean>(resolve => {
+            const timer = setTimeout(() => resolve(false), MEETING_STOP_FAILSAFE_MS)
+            void done.then(ok => { clearTimeout(timer); resolve(ok) })
+          })
+          if (!finished) throw new Error("导入尚未完整结束，已保留面板。请等待当前段完成后重试收起")
+        }
+        if (phaseRef.current !== "idle" || finalizingRef.current) {
+          const finished = new Promise<boolean>(resolve => { captureFinishedRef.current = resolve })
+          if (phaseRef.current === "starting" && !adapterRef.current) {
+            // Wait for meeting.started, then end without opening the microphone.
+            cancelStartingRef.current = true
+            setPhase("stopping")
+          } else {
+            stopLiveCapture(false)
+          }
+          if (!await finished) throw new Error("最后一段未完整处理，已保留面板和现有转写。请检查提示后重试收起")
+        }
+        if (needsClosePersistenceRef.current) {
+          if (!await refineQueueRef.current.drain()) throw new Error("转写仍在纠错，请稍后重试收起")
+          const id = closeMeetingIdRef.current
+          if (!id) throw new Error("会议尚未创建完成，请稍后重试收起")
+          await confirmMeetingClose({
+            id,
+            expectedText: liveTextRef.current.join("\n"),
+            endRecording: closeNeedsEndRef.current,
+            subscribe: subscribeMeetingRuntime,
+            send: (message, callback) => chrome.runtime.sendMessage(message, callback),
+          })
+          needsClosePersistenceRef.current = false
+        }
+        return true
+      } catch (cause) {
+        setError(cause instanceof Error ? cause.message : "保存失败，已保留面板，请重试")
+        return false
+      } finally {
+        setClosing(false)
+        closePendingRef.current = null
+      }
+    })
+    closePendingRef.current = pending
+    return pending
+  }
+
+  useEffect(() => props.registerBeforeClose?.(() => requestCloseRef.current()), [props.registerBeforeClose])
+
   const ensureMeetingIdThen = (then: (id: string) => void) => {
     if (meetingId) {
       then(meetingId)
@@ -946,9 +1050,15 @@ export function MeetingPanel(props: {
     importAbortRef.current = false
     dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: true })
     setImportStatus("解码音频…")
+    let resolveImport!: (ok: boolean) => void
+    let importSucceeded = true
+    importDoneRef.current = new Promise<boolean>(resolve => { resolveImport = resolve })
 
+    try {
     const decoded = await fileToWavSegments(file)
+    if (importAbortRef.current) return
     if (decoded.ok === false) {
+      importSucceeded = false
       setError(decoded.message)
       setBusy(false)
       setImportStatus(null)
@@ -986,12 +1096,17 @@ export function MeetingPanel(props: {
       if (id) setMeetingId(id)
     }
     if (!id) {
+      importSucceeded = false
       setError("无法创建会议会话")
       setBusy(false)
       setImportStatus(null)
       dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
       return
     }
+    closeMeetingIdRef.current = id
+    closeNeedsEndRef.current = false
+    needsClosePersistenceRef.current = true
+    liveTextRef.current = []
 
     const total = decoded.segments.length
     let failedAt: number | null = null
@@ -1012,6 +1127,7 @@ export function MeetingPanel(props: {
         onMessage: subscribeVoiceStt,
       })
       if (r.ok === false) {
+        importSucceeded = false
         failedAt = i + 1
         setError(`音频第 ${i + 1} 段转写失败: ${r.code}`)
         break
@@ -1071,6 +1187,15 @@ export function MeetingPanel(props: {
       }
     }
     dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
+    } catch {
+      importSucceeded = false
+      setError("音频导入失败，已保留面板和现有转写")
+    } finally {
+      setBusy(false)
+      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
+      importDoneRef.current = null
+      resolveImport(importSucceeded)
+    }
   }
 
   /**
@@ -1209,6 +1334,7 @@ export function MeetingPanel(props: {
         fontSize: 13,
       }}
     >
+      <fieldset disabled={closing} style={{ display: "contents" }}>
       <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
         <strong style={{ flex: 1, fontSize: 15 }}>会议记录</strong>
         <span style={{ fontSize: 11, color: tokens.textSecondary }}>
@@ -1217,12 +1343,8 @@ export function MeetingPanel(props: {
         <button
           type="button"
           onClick={() => {
-            // Sync end before unmount so meeting.end is not raced by destroy()
-            if (phaseRef.current !== "idle") {
-              wantGenerateRef.current = false
-              finalizeCapture({ generate: false, id: meetingIdRef.current })
-            }
-            props.onClose()
+            if (props.registerBeforeClose) props.onClose()
+            else void requestCloseRef.current().then(allowed => { if (allowed) props.onClose() })
           }}
           title="结束录制并收起面板"
           aria-label="结束录制并收起面板"
@@ -1239,6 +1361,7 @@ export function MeetingPanel(props: {
           结束并收起
         </button>
       </div>
+      {closing && <div role="status" aria-live="polite">正在保存最后一段转写，完成后收起…</div>}
 
       <div style={{ fontSize: 11, color: tokens.textSecondary, lineHeight: 1.45 }}>
         粘贴 / 上传转写，或显式「开始录制」本机分段转写（最长约{" "}
@@ -1817,6 +1940,7 @@ export function MeetingPanel(props: {
           </pre>
         </div>
       )}
+      </fieldset>
     </div>
   )
 }
diff --git a/chrome-extension/src/sidepanel/components/ThreadList.tsx b/chrome-extension/src/sidepanel/components/ThreadList.tsx
index 8e047144..3bd4006a 100644
--- a/chrome-extension/src/sidepanel/components/ThreadList.tsx
+++ b/chrome-extension/src/sidepanel/components/ThreadList.tsx
@@ -7,6 +7,7 @@ import { useAgentStore } from "../store/agentStore"
 import { tokens } from "../ui/tokens"
 import { ThreadMetadataEditor } from "./ThreadMetadataEditor"
 import { aiThreadGroup, threadTags } from "../utils/thread-management"
+import { mutateThreads } from "../utils/thread-mutations"
 import { IconHistory } from "../ui/icons"
 import { popupMenuStyles } from "../ui/popupMenuStyles"
 import type { Thread } from "../types"
@@ -119,6 +120,10 @@ export function ThreadList() {
   const [open, setOpen] = useState(false)
   const [editingThread, setEditingThread] = useState<Thread | null>(null)
   const [metadataNotice, setMetadataNotice] = useState("")
+  const [mutationNotice, setMutationNotice] = useState("")
+  const [mutating, setMutating] = useState(false)
+  const mutationRef = useRef<AbortController | null>(null)
+  useEffect(() => () => mutationRef.current?.abort(), [])
   useEffect(() => { if (!open) { setEditingThread(null); setMetadataNotice(""); setPendingDelete(null) } }, [open])
   useEffect(() => {
     const show = () => { if (!state.pendingSecurityConfirmations.length) setOpen(true) }
@@ -180,11 +185,12 @@ export function ThreadList() {
   const [pendingDelete, setPendingDelete] = useState<{
     ids: string[]
     hard: boolean
-    source: "row" | "batch" | "cleanup"
+    source: "row" | "batch" | "cleanup" | "empty"
   } | null>(null)
   useEffect(() => {
     if (!pendingDelete) return
     historyRef.current?.querySelector("[role='alertdialog']")?.scrollIntoView({ block: "nearest" })
+    historyRef.current?.querySelector<HTMLButtonElement>("[data-delete-cancel]")?.focus()
   }, [pendingDelete])
   /** Wave C: seed for related list; graph focus */
   const [relatedSeedId, setRelatedSeedId] = useState<string | null>(null)
@@ -508,11 +514,29 @@ export function ThreadList() {
 
   const selectableIds = useMemo(() => {
     const s = new Set<string>()
-    for (const t of filtered) {
+    const visible = view === "tags" && activeTag !== null ? tagIndex.get(activeTag) || [] : filtered
+    for (const t of visible) {
       if (!threadBusyById[t.id]) s.add(t.id)
     }
     return s
-  }, [filtered, threadBusyById])
+  }, [filtered, threadBusyById, view, activeTag, tagIndex])
+  useEffect(() => {
+    setSelected(previous => {
+      const next = new Set([...previous].filter(id => selectableIds.has(id)))
+      return next.size === previous.size ? previous : next
+    })
+  }, [selectableIds])
+  useEffect(() => { setPendingDelete(null) }, [view, activeTag, query, trashView])
+
+  const cleanupSelectableIds = useMemo(() => new Set(cleanupSuggestions
+    .map(s => s.thread_id)
+    .filter(id => threads.some(t => t.id === id && !t.trashed_at) && !threadBusyById[id])), [cleanupSuggestions, threads, threadBusyById])
+  useEffect(() => {
+    setCleanupSelected(previous => {
+      const next = new Set([...previous].filter(id => cleanupSelectableIds.has(id)))
+      return next.size === previous.size ? previous : next
+    })
+  }, [cleanupSelectableIds])
 
   const searchActive = query.trim().length > 0
 
@@ -587,28 +611,11 @@ export function ThreadList() {
   }
 
   const handleCleanupEmpty = () => {
-    const emptyN = threads.filter(
-      (t) => t.message_count === 0 && t.id !== activeThreadId && !t.trashed_at,
-    ).length
-    if (threads.some((t) => typeof t.message_count === "number") && emptyN === 0) {
-      alert("没有空白线程")
-      setMenuOpen(false)
-      return
-    }
-    const nLabel = emptyN > 0 ? `${emptyN} 个` : "所有"
-    if (
-      !confirm(
-        `将永久删除 ${nLabel}没有任何消息的空白线程。此操作不可恢复，也不经过回收站。`,
-      )
-    ) {
-      return
-    }
-    chrome.runtime.sendMessage({
-      type: "thread.cleanup_empty",
-      except_thread_id: activeThreadId,
-    })
+    if (mutationRef.current) return
+    const ids = threads.filter(t => t.message_count === 0 && t.id !== activeThreadId && !t.trashed_at && !threadBusyById[t.id]).map(t => t.id)
     setMenuOpen(false)
-    setOpen(false)
+    if (!ids.length) { setMutationNotice("没有可清理的空白对话；可刷新列表后再次检查。"); return }
+    setPendingDelete({ ids, hard: true, source: "empty" })
   }
 
   const handleGenerateTitle = () => {
@@ -755,6 +762,7 @@ export function ThreadList() {
 
   const handleDeleteOne = (threadId: string, e: React.MouseEvent) => {
     e.stopPropagation()
+    if (mutationRef.current) return
     if (threadBusyById[threadId]) {
       alert("该线程正在运行，无法删除")
       return
@@ -763,47 +771,68 @@ export function ThreadList() {
   }
 
   const handleBatchDelete = () => {
-    let ids = [...selected].filter((id) => selectableIds.has(id))
-    if (ids.length === 0) {
-      ids = [...selectableIds]
-      if (ids.length === 0) return
-      setSelected(new Set(ids))
-      setSelectMode(true)
-    }
+    if (mutationRef.current) return
+    const ids = [...selected].filter((id) => selectableIds.has(id))
+    if (ids.length === 0) return
     setPendingDelete({ ids, hard: trashView, source: "batch" })
   }
 
-  const executePendingDelete = () => {
-    if (!pendingDelete || pendingDelete.ids.length === 0) return
-    const { ids, hard, source } = pendingDelete
-    const mode = hard ? "hard" : "trash"
-    if (ids.length === 1) {
-      dispatch({ type: "REMOVE_THREAD", threadId: ids[0] })
-      chrome.runtime.sendMessage({ type: "thread.delete", thread_id: ids[0], mode }, () => {
-        void chrome.runtime.lastError
-      })
-    } else {
-      dispatch({ type: "REMOVE_THREADS", threadIds: ids })
-      chrome.runtime.sendMessage({ type: "thread.batch_delete", thread_ids: ids, mode }, () => {
-        void chrome.runtime.lastError
-      })
-    }
+  const runMutation = async (ids: string[], mode: "trash" | "hard" | "restore" | "empty", source: "row" | "batch" | "cleanup" | "empty") => {
+    if (!ids.length || mutationRef.current) return
+    const controller = new AbortController()
+    mutationRef.current = controller
+    setMutating(true)
+    setMutationNotice(`正在${mode === "restore" ? "恢复" : "处理"} ${ids.length} 个对话，请等待服务端确认…`)
     setPendingDelete(null)
-    if (source === "batch") exitSelectMode()
-    if (source === "cleanup") {
-      setCleanupOpen(false)
-      setCleanupSuggestions([])
-      setCleanupSelected(new Set())
+    try {
+      const result = await mutateThreads(ids, mode, controller.signal)
+      if (controller.signal.aborted) return
+      if (mode !== "restore" && result.ok.length) dispatch({ type: "REMOVE_THREADS", threadIds: result.ok })
+      if (mode === "restore") chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
+      const failedIds = new Set(result.failed.map(item => item.id))
+      const uncertain = result.failed.some(item => item.reason.startsWith("unknown"))
+      const failures = result.failed.slice(0, 3).map(item => {
+        const title = displayThreadTitle(threads.find(t => t.id === item.id) || { id: item.id })
+        const reason = item.reason === "thread_busy" ? "运行中"
+          : item.reason === "not_empty" ? "已有内容，已跳过"
+          : item.reason === "not_sent_unsupported" ? "未发送，请更新 Companion 后重试"
+          : item.reason.startsWith("not_sent") ? "未发送"
+          : item.reason.startsWith("unknown") ? "结果未确认" : item.reason
+        return `${title}：${reason}`
+      }).join("；")
+      setMutationNotice(`${mode === "restore" ? "已恢复" : mode === "hard" || mode === "empty" ? "已永久删除" : "已移入回收站"} ${result.ok.length} 个对话。${result.failed.length ? `另有 ${result.failed.length} 个未完成确认。${failures}${uncertain ? "；部分操作可能已完成，请刷新列表核对后重试。" : ""}` : ""}`)
+      if (source === "batch") {
+        setSelected(failedIds)
+        setSelectMode(failedIds.size > 0)
+      }
+      if (source === "cleanup") {
+        setCleanupSuggestions(previous => previous.filter(s => !result.ok.includes(s.thread_id)))
+        setCleanupSelected(failedIds)
+      }
+    } catch (error) {
+      if (!controller.signal.aborted) setMutationNotice(`未收到完整结果，部分操作可能已完成；请刷新列表核对。${error instanceof Error ? error.message : ""}`)
+    } finally {
+      if (mutationRef.current === controller) mutationRef.current = null
+      if (!controller.signal.aborted) setMutating(false)
     }
   }
 
-  const handleSelectAllVisible = () => {
-    if (cleanupOpen && cleanupSuggestions.length > 0) {
-      setCleanupSelected(
-        new Set(cleanupSuggestions.map((s) => s.thread_id).filter(Boolean).slice(0, 50)),
-      )
+  const executePendingDelete = () => {
+    if (!pendingDelete || mutationRef.current) return
+    const { hard, source } = pendingDelete
+    const ids = pendingDelete.ids.filter(id => {
+      const thread = threads.find(t => t.id === id)
+      return thread && !threadBusyById[id] && (source === "empty" ? !thread.trashed_at && thread.message_count === 0 && id !== activeThreadId : !!thread.trashed_at === hard)
+    })
+    if (ids.length !== pendingDelete.ids.length) {
+      setPendingDelete(null)
+      setMutationNotice("部分对话状态已变化，请重新核对选择后操作。")
       return
     }
+    void runMutation(ids, source === "empty" ? "empty" : hard ? "hard" : "trash", source)
+  }
+
+  const handleSelectAllVisible = () => {
     const ids = selectAllIds(selectableIds)
     setSelectMode(true)
     setSelected(ids)
@@ -819,19 +848,12 @@ export function ThreadList() {
   }
 
   const handleClearVisibleSelection = () => {
-    if (cleanupOpen && cleanupSuggestions.length > 0) {
-      setCleanupSelected(new Set())
-      return
-    }
     setSelected(new Set())
   }
 
   const handleRestore = (ids: string[]) => {
-    if (ids.length === 0) return
-    chrome.runtime.sendMessage({ type: "thread.restore", thread_ids: ids })
-    dispatch({ type: "REMOVE_THREADS", threadIds: ids }) // drop from trash view until list refresh
-    chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
-    exitSelectMode()
+    const targets = ids.filter(id => selectableIds.has(id) && threads.some(t => t.id === id && t.trashed_at))
+    void runMutation(targets, "restore", "batch")
   }
 
   const openTrashView = () => {
@@ -862,12 +884,9 @@ export function ThreadList() {
   }
 
   const applyCleanupTrash = () => {
-    let ids = [...cleanupSelected].slice(0, 50)
-    if (ids.length === 0) {
-      ids = cleanupSuggestions.map((s) => s.thread_id).filter(Boolean).slice(0, 50)
-      if (ids.length === 0) return
-      setCleanupSelected(new Set(ids))
-    }
+    if (mutationRef.current) return
+    const ids = [...cleanupSelected].filter(id => cleanupSelectableIds.has(id))
+    if (!ids.length) return
     setPendingDelete({ ids, hard: false, source: "cleanup" })
   }
 
@@ -879,7 +898,7 @@ export function ThreadList() {
     beginExtractBatch(ids, force)
   }
 
-  const panelMaxHeight = selectMode || cleanupOpen || view === "tags" || view === "topics" || view === "ai" ? 480 : 360
+  const panelMaxHeight = 480
 
   useEffect(() => {
     if (!open) {
@@ -964,7 +983,7 @@ export function ThreadList() {
         data-thread-id={t.id}
         style={{
           ...styles.threadItem,
-          background: isActive ? tokens.accentSoft : "transparent",
+          background: isActive ? tokens.bgHover : "transparent",
           opacity: selectMode && busy ? 0.45 : 1,
         }}
         aria-label={accessibleName}
@@ -1051,7 +1070,7 @@ export function ThreadList() {
               }}
               title="列表内相关"
             >
-              🔗
+              相关
             </button>
             <button
               type="button"
@@ -1062,7 +1081,7 @@ export function ThreadList() {
               }}
               title="提取要点 / 标签"
             >
-              🏷
+              AI 标签
             </button>
             <button
               type="button"
@@ -1105,16 +1124,17 @@ export function ThreadList() {
               disabled={state.summarizingThreadId === t.id}
               title="导出此线程摘要为 Markdown"
             >
-              {state.summarizingThreadId === t.id ? "⏳" : "🧠"}
+              {state.summarizingThreadId === t.id ? "导出中" : "导出"}
             </button>
             <button
               type="button"
               style={styles.iconBtn}
               onClick={(e) => handleDeleteOne(t.id, e)}
+              disabled={mutating || busy}
               title="删除线程"
               aria-label={`删除 ${accessibleName}`}
             >
-              🗑️
+              删除
             </button>
           </>
         )}
@@ -1231,7 +1251,7 @@ export function ThreadList() {
     const untagged = tagIndex.get("__untagged__") || []
     const listForTag =
       activeTag === null
-        ? null
+        ? filtered
         : activeTag === "__untagged__"
           ? untagged
           : tagIndex.get(activeTag) || []
@@ -1336,9 +1356,9 @@ export function ThreadList() {
         {listForTag && (
           <div>
             <div style={styles.groupHeader}>
-              {renderGroupCheckbox(listForTag.map((t) => t.id), activeTag === "__untagged__" ? "未标注" : `#${activeTag}`)}
+              {renderGroupCheckbox(listForTag.map((t) => t.id), activeTag === null ? "全部对话" : activeTag === "__untagged__" ? "未标注" : `#${activeTag}`)}
               <span style={styles.groupLabel}>
-                {activeTag === "__untagged__" ? "未标注" : `#${activeTag}`} ·{" "}
+                {activeTag === null ? "全部对话" : activeTag === "__untagged__" ? "未标注" : `#${activeTag}`} ·{" "}
                 {listForTag.length}
               </span>
             </div>
@@ -1432,11 +1452,12 @@ export function ThreadList() {
               zIndex: 10050,
             }}
           >
-            <div style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>对话管理</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
+            <div className="cm-thread-management-title" style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>对话管理</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
             <div className="cm-thread-management-header" style={styles.panelHeader}>
               <div className="cm-thread-management-views" style={styles.viewToggle}>
                 <button
                   type="button"
+                  aria-pressed={view === "time"}
                   style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
                   onClick={() => setView("time")}
                 >
@@ -1444,6 +1465,7 @@ export function ThreadList() {
                 </button>
                 <button
                   type="button"
+                  aria-pressed={view === "tags"}
                   style={view === "tags" ? styles.viewBtnActive : styles.viewBtn}
                   onClick={() => setView("tags")}
                 >
@@ -1451,12 +1473,13 @@ export function ThreadList() {
                 </button>
                 <button
                   type="button"
+                  aria-pressed={view === "topics"}
                   style={view === "topics" ? styles.viewBtnActive : styles.viewBtn}
                   onClick={() => setView("topics")}
                 >
                   手动分组
                 </button>
-                <button type="button" style={view === "ai" ? styles.viewBtnActive : styles.viewBtn} onClick={() => setView("ai")}>AI 分组</button>
+                <button type="button" aria-pressed={view === "ai"} style={view === "ai" ? styles.viewBtnActive : styles.viewBtn} onClick={() => setView("ai")}>AI 分组</button>
               </div>
               <div style={{ display: "flex", gap: 6, flexShrink: 0, alignItems: "center" }}>
                 <button
@@ -1596,27 +1619,9 @@ export function ThreadList() {
               <button type="button" onClick={() => { setCleanupOpen(true); runCleanupScan() }}>整理助手</button>
               <button type="button" onClick={openThreadGraph}>关系图谱</button>
               <button type="button" onClick={() => trashView ? closeTrashView() : openTrashView()}>{trashView ? "返回对话" : "回收站"}</button>
-              <button
-                type="button"
-                onClick={() =>
-                  (cleanupOpen && cleanupSuggestions.length > 0
-                    ? cleanupSelected.size === cleanupSuggestions.length
-                    : allSelectableSelected(selected, selectableIds))
-                    ? handleClearVisibleSelection()
-                    : handleSelectAllVisible()
-                }
-                disabled={cleanupOpen && cleanupSuggestions.length > 0 ? cleanupSuggestions.length === 0 : selectableIds.size === 0}
-                title={cleanupOpen ? "全选整理助手扫描结果" : "全选当前列表中可删除的会话"}
-              >
-                {(cleanupOpen && cleanupSuggestions.length > 0
-                  ? cleanupSelected.size === cleanupSuggestions.length && cleanupSuggestions.length > 0
-                  : allSelectableSelected(selected, selectableIds))
-                  ? "取消全选"
-                  : "全选"}
-              </button>
             </div>
             {cleanupOpen && (
-              <div className="cm-thread-cleanup" style={styles.cleanupPanel}>
+                <div className="cm-thread-cleanup" style={styles.cleanupPanel} role="region" aria-label="整理建议">
                 <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 8 }}>整理助手（规则）</div>
                 <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 8, flexWrap: "wrap" }}>
                   <span style={{ fontSize: 11, color: tokens.textSecondary }}>扫描</span>
@@ -1680,6 +1685,7 @@ export function ThreadList() {
                             <input
                               type="checkbox"
                               checked={cleanupSelected.has(s.thread_id)}
+                              disabled={!cleanupSelectableIds.has(s.thread_id) || mutating}
                               onChange={() => {
                                 setCleanupSelected((prev) => {
                                   const next = new Set(prev)
@@ -1721,23 +1727,22 @@ export function ThreadList() {
                         type="button"
                         style={styles.selectBtn}
                         onClick={() => {
-                          const ids = cleanupSuggestions.map((s) => s.thread_id).slice(0, 50)
-                          setCleanupSelected(new Set(ids))
+                          setCleanupSelected(new Set(cleanupSelectableIds))
                         }}
                       >
-                        全选
+                        全选建议
                       </button>
                       <button
                         type="button"
                         style={styles.selectBtn}
                         onClick={() => setCleanupSelected(new Set())}
                       >
-                        全不选
+                        清空建议选择
                       </button>
                       <button
                         type="button"
                         style={styles.dangerBtn}
-                        disabled={cleanupSelected.size === 0}
+                        disabled={cleanupSelected.size === 0 || mutating}
                         onClick={applyCleanupTrash}
                       >
                         移入回收站（{cleanupSelected.size}）
@@ -1751,10 +1756,11 @@ export function ThreadList() {
               <div
                 role="alertdialog"
                 aria-label="确认删除会话"
+                aria-describedby="cm-delete-description"
                 style={styles.pendingDelete}
               >
-                <p style={{ margin: 0, fontSize: 12, lineHeight: 1.5 }}>
-                  {pendingDelete.hard
+                <div id="cm-delete-description"><p style={{ margin: 0, fontSize: 12, lineHeight: 1.5 }}>
+                  {pendingDelete.source === "empty" ? `永久清理 ${pendingDelete.ids.length} 个空白对话？不可恢复，服务端会再次检查是否仍为空白。` : pendingDelete.hard
                     ? `永久删除 ${pendingDelete.ids.length} 个会话？不可恢复。`
                     : `将 ${pendingDelete.ids.length} 个会话移入回收站？可在回收站恢复（约 30 天后自动清理）。`}
                   {pendingDelete.source === "cleanup" &&
@@ -1764,11 +1770,14 @@ export function ThreadList() {
                     ? " 含编程接力记录，请再核对。"
                     : ""}
                 </p>
+                <ul className="cm-delete-preview">{pendingDelete.ids.slice(0, 5).map(id => <li key={id}>{displayThreadTitle(threads.find(t => t.id === id) || { id })} <span>#{id}</span></li>)}</ul>
+                {pendingDelete.ids.length > 5 && <p className="cm-thread-management-help">另有 {pendingDelete.ids.length - 5} 个已选对话</p>}
+                </div>
                 <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
-                  <button type="button" style={styles.dangerBtn} onClick={executePendingDelete}>
+                  <button type="button" style={styles.dangerBtn} disabled={mutating} onClick={executePendingDelete}>
                     {pendingDelete.hard ? "永久删除" : "移入回收站"}
                   </button>
-                  <button type="button" style={styles.selectBtn} onClick={() => setPendingDelete(null)}>
+                  <button type="button" data-delete-cancel style={styles.selectBtn} onClick={() => setPendingDelete(null)}>
                     取消
                   </button>
                 </div>
@@ -1777,6 +1786,7 @@ export function ThreadList() {
             {view === "ai" && <p className="cm-thread-management-help">按 AI 提取的首个主题标签自动分组；重新提取可能调整 AI 分组，不改变手动分组。点击“AI 提取标签”为最多20个未标注对话提取标签。</p>}
             {view === "tags" && <p className="cm-thread-management-help">汇总人工与 AI 标签；点对话右侧“分类”管理人工标签。</p>}
             {metadataNotice && <p className="cm-thread-management-help" role="status">{metadataNotice}</p>}
+            {mutationNotice && <div className="cm-thread-mutation-notice" role="status" aria-live="polite"><span>{mutationNotice}</span>{!mutating && <button type="button" onClick={() => chrome.runtime.sendMessage({ type: "thread.list", include_trashed: trashView })}>刷新列表</button>}</div>}
             {editingThread && <ThreadMetadataEditor key={editingThread.id} thread={editingThread} folders={[...new Set(threads.map(t => t.topic_folder).filter((name): name is string => !!name))]} onClose={() => closeMetadataEditor()} onSaved={thread => { dispatch({ type: "UPSERT_THREAD", thread }); closeMetadataEditor(thread.id); setMetadataNotice("分类已保存") }} />}
             {extractProgress && extractProgress.total > 0 && (
               <div style={styles.progressBar} role="status" aria-live="polite">
@@ -1878,28 +1888,16 @@ export function ThreadList() {
             </div>
 
             {selectMode && (
-              <div style={styles.bottomBar}>
+              <div className="cm-thread-selection-bar" style={styles.bottomBar}>
                 <span style={{ fontSize: 12, color: tokens.textSecondary }}>
                   已选 {selected.size}
                 </span>
                 <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
-                  <button
-                    type="button"
-                    style={styles.selectBtn}
-                    disabled={selectableIds.size === 0}
-                    onClick={() =>
-                      allSelectableSelected(selected, selectableIds)
-                        ? handleClearVisibleSelection()
-                        : handleSelectAllVisible()
-                    }
-                  >
-                    {allSelectableSelected(selected, selectableIds) ? "取消全选" : "全选"}
-                  </button>
                   {trashView ? (
                     <button
                       type="button"
                       style={styles.selectBtn}
-                      disabled={selected.size === 0}
+                      disabled={selected.size === 0 || mutating}
                       onClick={() => handleRestore([...selected])}
                     >
                       恢复
@@ -1934,10 +1932,10 @@ export function ThreadList() {
                   <button
                     type="button"
                     style={styles.dangerBtn}
-                    disabled={selected.size === 0}
+                    disabled={selected.size === 0 || mutating}
                     onClick={handleBatchDelete}
                   >
-                    {trashView ? "永久删除" : "回收站"}
+                    {trashView ? "永久删除" : "移入回收站"}
                   </button>
                   <button type="button" style={styles.selectBtn} onClick={exitSelectMode}>
                     取消
@@ -2194,7 +2192,8 @@ const styles: Record<string, React.CSSProperties> = {
     fontSize: 12,
     cursor: "pointer",
     padding: "2px 4px",
-    opacity: 0.5,
+    color: tokens.textSecondary,
+    whiteSpace: "nowrap",
     flexShrink: 0,
   },
   threadAliasRow: {
@@ -2305,9 +2304,6 @@ const styles: Record<string, React.CSSProperties> = {
     background: tokens.warningSoft,
     borderBottom: `1px solid ${tokens.border}`,
     color: tokens.text,
-    position: "sticky",
-    top: 0,
-    zIndex: 6,
     flexShrink: 0,
   },
   bottomBar: {
diff --git a/chrome-extension/src/sidepanel/hooks/useWebSocket.ts b/chrome-extension/src/sidepanel/hooks/useWebSocket.ts
index 1b8bf2de..d8d535a0 100644
--- a/chrome-extension/src/sidepanel/hooks/useWebSocket.ts
+++ b/chrome-extension/src/sidepanel/hooks/useWebSocket.ts
@@ -11,6 +11,7 @@ import { rememberNativeVisionProbe } from "../components/vision-reuse-logic"
 import { normalizeInboundLogEvent } from "../log-event-normalize"
 import { humanizeSidepanelGateError } from "../utils/gate-error-copy"
 import { newTempUserMessageId } from "../../utils/temp-message-id"
+import { isManagedThreadMutationReply } from "../utils/thread-mutations"
 import { knowledgePreviewErrorText, sanitizeKnowledgeSuggestion } from "../utils/knowledge-preview"
 import {
   KNOWLEDGE_DUPLICATE_CONFIRM_PREFIX,
@@ -1086,7 +1087,8 @@ export function useWebSocket() {
           break
         }
         case "thread.restored": {
-          chrome.runtime.sendMessage({ type: "thread.list" })
+          // Managed mutations refresh their own view (including remaining trash).
+          if (!isManagedThreadMutationReply(msg)) chrome.runtime.sendMessage({ type: "thread.list" })
           break
         }
         case "thread.cleanup_suggestions": {
@@ -1106,6 +1108,7 @@ export function useWebSocket() {
           break
         }
         case "thread.batch_deleted": {
+          if (isManagedThreadMutationReply(msg)) break
           const okIds: string[] = Array.isArray(msg.ok)
             ? msg.ok
             : Array.isArray(msg.deleted_ids)
@@ -2274,6 +2277,8 @@ export function useWebSocket() {
           break
 
         case "error": {
+          // A management failure must not stop or append errors to unrelated chat.
+          if (isManagedThreadMutationReply(msg)) break
           const overlayCode = typeof msg.error_code === "string" ? msg.error_code : ""
           const errText = typeof msg.error === "string" ? msg.error : ""
           if (activeThreadRef.current) {
diff --git a/chrome-extension/src/sidepanel/ui/icons.tsx b/chrome-extension/src/sidepanel/ui/icons.tsx
index 373eb6f5..974f9fb9 100644
--- a/chrome-extension/src/sidepanel/ui/icons.tsx
+++ b/chrome-extension/src/sidepanel/ui/icons.tsx
@@ -204,52 +204,20 @@ export function IconList(p: IconProps) {
   )
 }
 
-/**
- * Empty-state imprint — red calf robot (brandRed terracotta). Filled stamp,
- * not an outline. Decorative only: aria-hidden, no cruise/armed state, no
- * danger-family red. Keep size configurable (#321 PR-4 92→48 compatible).
- */
+/** Shared connection-spark geometry from scripts/lib/brand-icon.mjs. Decorative, never process state. */
 export function CompanionMark({ size = 92 }: { size?: number }) {
   return (
     <svg
       width={size}
       height={size}
-      viewBox="0 0 92 92"
-      fill="none"
+      viewBox="0 0 24 24"
+      fill={tokens.textSecondary}
       aria-hidden
       style={{ display: "block", flexShrink: 0 }}
     >
-      {/* ground shadow */}
-      <ellipse cx="46" cy="85" rx="17" ry="3.5" fill="rgba(23, 23, 23, 0.10)" />
-      {/* ears — tucked behind the head at the upper sides */}
-      <circle cx="21" cy="44" r="11" fill={tokens.brandRed} />
-      <circle cx="71" cy="44" r="11" fill={tokens.brandRed} />
-      {/* horns — smooth arcs rising from the top of the head */}
-      <path
-        d="M37 36 C34 25 31 16 29 10"
-        stroke={tokens.brandRed}
-        strokeWidth="9"
-        strokeLinecap="round"
-        fill="none"
-      />
-      <path
-        d="M55 36 C58 25 61 16 63 10"
-        stroke={tokens.brandRed}
-        strokeWidth="9"
-        strokeLinecap="round"
-        fill="none"
-      />
-      {/* head */}
-      <circle cx="46" cy="56" r="23" fill={tokens.brandRed} />
-      {/* eyes — indigo pupils keep the robot character accent */}
-      <circle cx="36" cy="50" r="5" fill={tokens.bg} />
-      <circle cx="56" cy="50" r="5" fill={tokens.bg} />
-      <circle cx="36" cy="50" r="2.2" fill={tokens.accent} />
-      <circle cx="56" cy="50" r="2.2" fill={tokens.accent} />
-      {/* muzzle with nostrils — the calf face marker */}
-      <ellipse cx="46" cy="69" rx="9" ry="7" fill={tokens.bg} />
-      <circle cx="42" cy="69" r="1.7" fill={tokens.text} />
-      <circle cx="50" cy="69" r="1.7" fill={tokens.text} />
+      <path d="M5 5 12 12 5 19M12 12H20" fill="none" stroke={tokens.textSecondary} strokeWidth="2.3" strokeLinecap="round" />
+      <circle cx="5" cy="5" r="2.3" /><circle cx="5" cy="19" r="2.3" /><circle cx="20" cy="12" r="2.3" />
+      <path d="m12 7.5 4.5 4.5-4.5 4.5L7.5 12Z" />
     </svg>
   )
 }
diff --git a/chrome-extension/src/sidepanel/ui/workspace-styles.ts b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
index b863ab01..0aa24bcb 100644
--- a/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -77,14 +77,21 @@ export const workspaceCSS = `
 .cm-header-new{display:none;font-size:24px}
 .cm-nav-manage{border:0;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:12px;padding:6px;cursor:pointer}
 .cm-thread-manager-trigger{width:auto!important;gap:5px;padding:0 5px;font-size:12px;white-space:nowrap}
-.cm-history-panel{display:flex!important;flex-direction:column;overflow:hidden!important;overscroll-behavior:contain}
+.cm-history-panel{display:block!important;overflow-y:auto!important;overscroll-behavior:contain}
 .cm-thread-management-header{flex-wrap:wrap;flex-shrink:0}
 .cm-thread-management-views{flex-wrap:wrap}
-.cm-thread-management-list{flex:1;min-height:0;overflow-y:auto!important;max-height:none!important}
+.cm-thread-management-list{min-height:120px;overflow:visible!important;max-height:none!important}
 .cm-thread-management-actions{display:flex;gap:6px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
 .cm-thread-cleanup{flex-shrink:0}
+.cm-thread-selection-bar{position:sticky;bottom:0;z-index:2;background:${tokens.bgElevated};box-shadow:0 -2px 8px rgba(0,0,0,.04);flex-wrap:wrap;gap:8px}
+.cm-history-panel button{min-height:32px}
+.cm-thread-management-views button[aria-pressed="true"]{background:${tokens.navSelected};color:${tokens.text};font-weight:600}
+.cm-thread-mutation-notice{padding:10px 12px;font-size:12px;line-height:1.6;background:${tokens.bgMuted};color:${tokens.textSecondary};overflow-wrap:anywhere}
+.cm-thread-mutation-notice button{display:block;font:inherit;padding:4px 8px;margin-top:6px;background:${tokens.bg};border:1px solid ${tokens.border};border-radius:6px;cursor:pointer}
+.cm-delete-preview{padding-left:18px;margin:8px 0;font-size:12px;line-height:1.7;overflow-wrap:anywhere}.cm-delete-preview span{color:${tokens.textMuted}}
 .cm-thread-management-actions button,.cm-thread-editor button{font:inherit;font-size:12px;min-height:32px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 9px;background:${tokens.bgMuted};color:${tokens.text};cursor:pointer}
 .cm-thread-management-actions button:disabled,.cm-thread-editor button:disabled{opacity:.5;cursor:not-allowed}
+@media(max-height:600px){.cm-thread-management-title{padding:4px 10px!important}.cm-thread-management-header{padding:4px 10px!important}.cm-thread-management-actions{padding:4px 10px;gap:4px}.cm-thread-management-actions button{padding:4px 6px;white-space:nowrap}}
 .cm-thread-management-help{font-size:12px;line-height:1.6;color:${tokens.textSecondary};padding:0 12px}
 .cm-thread-editor{padding:16px;display:flex;flex-direction:column;gap:10px;border-bottom:1px solid ${tokens.border};background:${tokens.bgMuted}}
 .cm-thread-editor label{display:flex;flex-direction:column;gap:6px;font-size:12px}.cm-thread-editor input{box-sizing:border-box;width:100%;min-width:0;border:1px solid ${tokens.border};border-radius:8px;padding:8px;font:inherit;background:${tokens.bg}}
diff --git a/chrome-extension/src/sidepanel/utils/thread-mutations.ts b/chrome-extension/src/sidepanel/utils/thread-mutations.ts
new file mode 100644
index 00000000..fed63a0c
--- /dev/null
+++ b/chrome-extension/src/sidepanel/utils/thread-mutations.ts
@@ -0,0 +1,149 @@
+export type ThreadMutationMode = "trash" | "hard" | "restore" | "empty"
+export type ThreadMutationResult = { ok: string[]; failed: Array<{ id: string; reason: string }> }
+
+const REQUEST_PREFIX = "thread-mutation:"
+export function isManagedThreadMutationReply(message: { id?: unknown }): boolean {
+  return typeof message.id === "string" && message.id.startsWith(REQUEST_PREFIX)
+}
+
+type Runtime = Pick<typeof chrome.runtime, "onMessage" | "sendMessage" | "lastError">
+type BatchResult = ThreadMutationResult & { stop?: boolean; reason?: string }
+type RequestMode = ThreadMutationMode | "probe"
+
+/** Only a complete, correlated server result can confirm durable changes. */
+function parseResult(message: any, ids: string[], mode: RequestMode): ThreadMutationResult | null {
+  if (mode === "probe") {
+    return message.type === "thread.batch_delete.capabilities" && message.only_empty === true
+      ? { ok: [], failed: [] } : null
+  }
+  if (message.type !== (mode === "restore" ? "thread.restored" : "thread.batch_deleted")) return null
+  if (mode !== "restore" && message.mode !== (mode === "empty" ? "hard" : mode)) return null
+  const ok = mode === "restore" ? message.restored : message.ok
+  const failed = message.failed
+  if (!Array.isArray(ok) || !Array.isArray(failed)) return null
+  const expected = new Set(ids)
+  const seen = new Set<string>()
+  for (const id of ok) {
+    if (typeof id !== "string" || !expected.has(id) || seen.has(id)) return null
+    seen.add(id)
+  }
+  for (const item of failed) {
+    if (!item || typeof item.id !== "string" || !expected.has(item.id) || seen.has(item.id)
+      || typeof item.reason !== "string" || !item.reason) return null
+    seen.add(item.id)
+  }
+  if (seen.size !== expected.size) return null
+  const count = mode === "restore" ? message.restored_count : message.deleted_count
+  if (count !== ok.length) return null
+  if (mode !== "restore" && (!Array.isArray(message.deleted_ids)
+    || message.deleted_ids.length !== ok.length
+    || message.deleted_ids.some((id: unknown, i: number) => id !== ok[i]))) return null
+  return { ok: [...ok], failed: failed.map(({ id, reason }: { id: string; reason: string }) => ({ id, reason })) }
+}
+
+/** Injecting the runtime/timeout keeps transport races testable without a browser or daemon. */
+export function createThreadMutator(runtime: Runtime, timeoutMs = 30_000) {
+  function batch(ids: string[], mode: RequestMode, signal: AbortSignal): Promise<BatchResult> {
+    if (signal.aborted) return Promise.resolve({ ok: [], failed: ids.map(id => ({ id, reason: "not_sent" })), stop: true, reason: "not_sent" })
+    const requestId = REQUEST_PREFIX + crypto.randomUUID()
+    return new Promise(resolve => {
+      let settled = false
+      let attempted = false
+      let timer: ReturnType<typeof setTimeout> | undefined
+      const finish = (result: BatchResult) => {
+        if (settled) return
+        settled = true
+        if (timer) clearTimeout(timer)
+        runtime.onMessage.removeListener(onMessage)
+        signal.removeEventListener("abort", onAbort)
+        resolve(result)
+      }
+      const stop = (reason: string) => finish({ ok: [], failed: ids.map(id => ({ id, reason })), stop: true, reason })
+      const onAbort = () => stop(attempted ? "unknown_aborted" : "not_sent")
+      const onMessage = (message: any) => {
+        if (message?.type === "thread.mutation.connection" && message.state !== "connected") {
+          stop(attempted ? "unknown_disconnected" : "not_sent")
+          return
+        }
+        if (message?.id !== requestId) return
+        // A handler error can follow a partial mutation: do not say nothing changed.
+        if (message.type === "error") { stop("unknown_server_error"); return }
+        const result = parseResult(message, ids, mode)
+        if (result) finish(result)
+        else stop("unknown_invalid_response")
+      }
+      runtime.onMessage.addListener(onMessage)
+      signal.addEventListener("abort", onAbort, { once: true })
+      if (signal.aborted) { onAbort(); return }
+      timer = setTimeout(() => stop("unknown_timeout"), timeoutMs)
+      attempted = true
+      try {
+        runtime.sendMessage({
+          type: mode === "restore" ? "thread.restore" : "thread.batch_delete",
+          id: requestId,
+          thread_ids: ids,
+          ...(mode === "restore" || mode === "probe" ? {} : { mode: mode === "empty" ? "hard" : mode }),
+          ...(mode === "empty" ? { only_empty: true } : {}),
+          ...(mode === "probe" ? { probe: "only_empty" } : {}),
+          require_connected: true,
+        }, (ack: any) => {
+          const transportError = runtime.lastError
+          if (settled) return
+          if (transportError || ack?.id !== requestId || typeof ack?.ok !== "boolean") {
+            stop("unknown_transport")
+          } else if (!ack.ok) {
+            stop("not_sent")
+          }
+          // ok=true only acknowledges transport; keep waiting for the server.
+        })
+      } catch {
+        stop("unknown_transport")
+      }
+    })
+  }
+
+  return async (rawIds: string[], mode: ThreadMutationMode, signal: AbortSignal): Promise<ThreadMutationResult> => {
+    const ids = [...new Set(rawIds.filter(id => typeof id === "string" && id.length > 0))]
+    const result: ThreadMutationResult = { ok: [], failed: [] }
+    if (ids.length === 0) return result
+    // Also cover the microtask gap between a reply and the next batch/probe.
+    // A capability checked on one connection must not authorize another one.
+    let connectionLost = false
+    const onConnection = (message: any) => {
+      if (message?.type === "thread.mutation.connection" && message.state !== "connected") connectionLost = true
+    }
+    runtime.onMessage.addListener(onConnection)
+    try {
+      if (mode === "empty") {
+        // An old Companion rejects the empty target list before doing any work.
+        // Probe every invocation, never reuse capability across reconnections.
+        const probe = await batch([], "probe", signal)
+        if (probe.stop) {
+          const reason = ["unknown_server_error", "unknown_invalid_response", "unknown_timeout"].includes(probe.reason || "")
+            ? "not_sent_unsupported" : "not_sent"
+          return { ok: [], failed: ids.map(id => ({ id, reason })) }
+        }
+      }
+      for (let offset = 0; offset < ids.length; offset += 50) {
+        if (connectionLost) {
+          result.failed.push(...ids.slice(offset).map(id => ({ id, reason: "not_sent" })))
+          break
+        }
+        const next = await batch(ids.slice(offset, offset + 50), mode, signal)
+        result.ok.push(...next.ok)
+        result.failed.push(...next.failed)
+        if (next.stop) {
+          result.failed.push(...ids.slice(offset + 50).map(id => ({ id, reason: "not_sent" })))
+          break
+        }
+      }
+      return result
+    } finally {
+      runtime.onMessage.removeListener(onConnection)
+    }
+  }
+}
+
+export function mutateThreads(ids: string[], mode: ThreadMutationMode, signal: AbortSignal): Promise<ThreadMutationResult> {
+  return createThreadMutator(chrome.runtime)(ids, mode, signal)
+}
diff --git a/chrome-extension/src/sidepanel/voice/meeting-close.ts b/chrome-extension/src/sidepanel/voice/meeting-close.ts
new file mode 100644
index 00000000..76ccfe56
--- /dev/null
+++ b/chrome-extension/src/sidepanel/voice/meeting-close.ts
@@ -0,0 +1,41 @@
+/** Wait for persisted transcript and the server end event, not a transport ACK. */
+export async function confirmMeetingClose(options: {
+  id: string
+  expectedText: string
+  endRecording?: boolean
+  send: (message: Record<string, unknown>, callback: (reply: any) => void) => void
+  subscribe: (listener: (message: any) => void) => () => void
+  timeoutMs?: number
+}): Promise<void> {
+  const { id, send, subscribe, expectedText, timeoutMs = 10_000 } = options
+  const compact = (text: string) => text.replace(/\s+/gu, "")
+  const wait = (type: "meeting.get_result" | "meeting.ended", request: string) => new Promise<any>((resolve, reject) => {
+    let settled = false
+    let unsubscribe = () => {}
+    const finish = (error?: Error, value?: any) => {
+      if (settled) return
+      settled = true
+      clearTimeout(timer)
+      unsubscribe()
+      error ? reject(error) : resolve(value)
+    }
+    const timer = setTimeout(() => finish(new Error("保存确认超时，请保持面板并重试")), timeoutMs)
+    unsubscribe = subscribe(message => {
+      if (message.type === type && message.meeting?.id === id) finish(undefined, message.meeting)
+      if (message.type === "meeting.error" && message.id === id) finish(new Error(message.message || "会议保存失败"))
+    })
+    try {
+      send({ type: request, v: 1, id }, reply => {
+        if (reply?.ok === false) finish(new Error(reply.error || "Companion 未连接，请重连后重试"))
+      })
+    } catch {
+      finish(new Error("无法连接 Companion，请重连后重试"))
+    }
+  })
+  const persisted = await wait("meeting.get_result", "meeting.get")
+  const saved = (persisted.transcript || []).map((line: any) => String(line.text || "")).join("\n")
+  if (expectedText.trim() && !compact(saved).endsWith(compact(expectedText))) {
+    throw new Error("最后一段尚未确认保存。转写仍保留在面板，请保存转写后重试收起")
+  }
+  if (options.endRecording !== false) await wait("meeting.ended", "meeting.end")
+}
diff --git a/chrome-extension/tests/calf-mark-323.test.ts b/chrome-extension/tests/calf-mark-323.test.ts
index 3d78295c..ebc2d84b 100644
--- a/chrome-extension/tests/calf-mark-323.test.ts
+++ b/chrome-extension/tests/calf-mark-323.test.ts
@@ -6,8 +6,8 @@ import { tokens } from "../src/sidepanel/ui/tokens"
 
 const src = (rel: string) => readFileSync(join(process.cwd(), rel), "utf8")
 
-// GitHub: #323 — empty-state imprint is a red calf robot (brandRed token),
-// independent from the danger family. Pure T1 presentation.
+// #323 token contrast remains covered; #488 aligns the decorative mark with
+// the existing connection brand instead of the historical calf geometry.
 
 // --- small colour-science helpers (CIEDE2000 + Machado 2009 deutan), so the
 // "clearly distinguishable from danger" acceptance lives in code, not prose. ---
@@ -127,22 +127,20 @@ test("#323 mark keeps filled-stamp geometry, aria-hidden, no armed-state bits",
   assert.match(mark, /aria-hidden/)
   assert.ok(!/dangerouslySetInnerHTML/.test(mark))
   assert.ok(!/armed|cruise|tier|mode|level|L[012]/.test(mark), "mark carries no state")
-  // viewBox stays 92×92 and size stays a prop (fits #321 PR-4 92→48 rescale).
-  assert.match(mark, /viewBox="0 0 92 92"/)
+  assert.match(mark, /viewBox="0 0 24 24"/)
   assert.match(mark, /\{ size = \d+ \}/)
 })
 
-test("#323 mark draws calf features from tokens, no raw hex drift", () => {
+test("#488 decorative mark uses the connection brand without state or raw colors", () => {
   const icons = src("src/sidepanel/ui/icons.tsx")
   const mark = icons.slice(
     icons.indexOf("export function CompanionMark"),
     icons.indexOf("export function IconSend"),
   )
-  // Body + horns + ears use the brandRed token (not a literal or danger).
-  assert.ok((mark.match(/tokens\.brandRed/g) ?? []).length >= 4)
-  assert.ok(!/#dc2626/i.test(mark))
-  // Robot accent stays indigo; face marker is the calf muzzle.
-  assert.match(mark, /tokens\.accent/)
-  assert.match(mark, /ellipse cx="46"/)
-  assert.match(mark, /rx="9"/)
+  assert.match(mark, /tokens\.textSecondary/)
+  assert.doesNotMatch(mark, /#[0-9a-f]{3,8}\b|tokens\.danger|tokens\.brandRed/i)
+  const brand = src("../scripts/lib/brand-icon.mjs")
+  const diamond = 'm12 7.5 4.5 4.5-4.5 4.5L7.5 12Z'
+  assert.ok(mark.includes(diamond) && brand.includes(diamond), "shared connection geometry")
+  assert.equal((mark.match(/<circle /g) ?? []).length, 3)
 })
diff --git a/chrome-extension/tests/companion-canon-s12.test.ts b/chrome-extension/tests/companion-canon-s12.test.ts
index d6648d2e..f74ac48e 100644
--- a/chrome-extension/tests/companion-canon-s12.test.ts
+++ b/chrome-extension/tests/companion-canon-s12.test.ts
@@ -36,7 +36,8 @@ test("S1.3 settings lives in ⋯ only; pin is left thumbtack", () => {
 
 test("S1.4 ComposeDrawer has no ⋯编排 dead link", () => {
   const drawer = src("src/sidepanel/components/ComposeDrawer.tsx")
-  assert.match(drawer, /使用 \/board/)
+  assert.match(drawer, /\/board/)
+  assert.match(drawer, /资料与工具/)
   assert.ok(!/⋯「编排」/.test(drawer))
 })
 
@@ -49,7 +50,7 @@ test("S2.6 inviteRow color lives only in CSS so hover can win", () => {
   assert.ok(!/color:/.test(block), "inline color would beat :hover")
 })
 
-test("S2 chrome: legal contrast, send arrow, brandRed mark, no IconPlus", () => {
+test("S2 chrome: legal contrast, send arrow, decorative connection mark, no IconPlus", () => {
   const app = src("src/sidepanel/App.tsx")
   const legal = app.slice(app.indexOf("legal:"), app.indexOf("legal:") + 180)
   assert.match(legal, /fontSize:\s*11/)
@@ -59,9 +60,8 @@ test("S2 chrome: legal contrast, send arrow, brandRed mark, no IconPlus", () =>
   const send = icons.slice(icons.indexOf("export function IconSend"), icons.indexOf("export function IconStop"))
   assert.match(send, /M12 19V6/)
   const mark = icons.slice(icons.indexOf("export function CompanionMark"), icons.indexOf("export function IconSend"))
-  // #323: mark is the brandRed calf imprint — filled stamp, aria-hidden,
-  // and must never fall back to danger-family red.
-  assert.match(mark, /tokens\.brandRed/, "mark body is brandRed")
+  // #488: align with connection branding; no process-state color on static mark.
+  assert.match(mark, /tokens\.textSecondary/, "mark uses neutral semantic color")
   assert.match(mark, /aria-hidden/, "mark stays decorative")
   assert.ok(!/tokens\.danger/.test(mark), "mark must not reuse danger red")
   assert.ok(!/#171717/.test(mark), "ink silhouette removed by #323")
diff --git a/chrome-extension/tests/empty-face-321.test.ts b/chrome-extension/tests/empty-face-321.test.ts
index 4c35c719..00e57670 100644
--- a/chrome-extension/tests/empty-face-321.test.ts
+++ b/chrome-extension/tests/empty-face-321.test.ts
@@ -9,7 +9,7 @@ import { tokens } from "../src/sidepanel/ui/tokens"
 
 const src = (rel: string) => readFileSync(join(process.cwd(), rel), "utf8")
 
-test("#321 PR-4: CompanionMark empty imprint is 36px (#469 workspace), still red calf", () => {
+test("#488: CompanionMark empty imprint stays 36px with connection branding", () => {
   const emptyFn = src("src/sidepanel/components/ChatView.tsx").slice(
     src("src/sidepanel/components/ChatView.tsx").indexOf("function EmptyState"),
     src("src/sidepanel/components/ChatView.tsx").indexOf("const markdownCSS"),
@@ -20,9 +20,9 @@ test("#321 PR-4: CompanionMark empty imprint is 36px (#469 workspace), still red
     src("src/sidepanel/ui/icons.tsx").indexOf("export function CompanionMark"),
     src("src/sidepanel/ui/icons.tsx").indexOf("export function IconSend"),
   )
-  assert.match(mark, /tokens\.brandRed/)
+  assert.match(mark, /tokens\.textSecondary/)
   assert.doesNotMatch(mark, /#111|#000|black/i)
-  assert.match(mark, /viewBox="0 0 92 92"/)
+  assert.match(mark, /viewBox="0 0 24 24"/)
 })
 
 test("#321 PR-4: greeting stays 22px; three invites live in EmptyState (above the fold)", () => {
diff --git a/chrome-extension/tests/fixtures/thread-mutation-responses.ts b/chrome-extension/tests/fixtures/thread-mutation-responses.ts
new file mode 100644
index 00000000..a5d500ba
--- /dev/null
+++ b/chrome-extension/tests/fixtures/thread-mutation-responses.ts
@@ -0,0 +1,29 @@
+// Captured 2026-09-09 from companion/src/message-router.ts handleMessage using
+// a temporary real ThreadManager: fixture-a / fixture-b / fixture-missing.
+// Capture recipe: create A/B; batch_delete trash; restore; batch_delete hard.
+// Wire lifecycle adds {id: request.id} at companion/src/ws/lifecycle.ts.
+export const recordedThreadMutationResponses = {
+  capabilities: { type: "thread.batch_delete.capabilities", only_empty: true },
+  trash: {
+    type: "thread.batch_deleted",
+    ok: ["fixture-a", "fixture-b"],
+    failed: [{ id: "fixture-missing", reason: "not_found" }],
+    deleted_ids: ["fixture-a", "fixture-b"],
+    deleted_count: 2,
+    mode: "trash",
+  },
+  restore: {
+    type: "thread.restored",
+    restored: ["fixture-a", "fixture-b"],
+    failed: [{ id: "fixture-missing", reason: "not_found" }],
+    restored_count: 2,
+  },
+  hard: {
+    type: "thread.batch_deleted",
+    ok: ["fixture-a", "fixture-b"],
+    failed: [{ id: "fixture-missing", reason: "not_found" }],
+    deleted_ids: ["fixture-a", "fixture-b"],
+    deleted_count: 2,
+    mode: "hard",
+  },
+}
diff --git a/chrome-extension/tests/meeting-close.test.ts b/chrome-extension/tests/meeting-close.test.ts
new file mode 100644
index 00000000..e936e6f8
--- /dev/null
+++ b/chrome-extension/tests/meeting-close.test.ts
@@ -0,0 +1,77 @@
+import test from "node:test"
+import assert from "node:assert/strict"
+import { confirmMeetingClose } from "../src/sidepanel/voice/meeting-close"
+
+async function rejects(promise: Promise<unknown>, expected: RegExp) {
+  const error = await promise.then(() => null, cause => cause)
+  assert.ok(error instanceof Error && expected.test(error.message))
+}
+
+test("meeting close validates stored final text before ending; transport ACK is insufficient", async () => {
+  const sent: string[] = []
+  let receive: (m: any) => void = () => {}
+  const closing = confirmMeetingClose({ id: "a", expectedText: "末段", timeoutMs: 100,
+    subscribe: listener => { receive = listener; return () => { receive = () => {} } },
+    send: (message, callback) => { sent.push(message.type as string); callback({ ok: true }) },
+  })
+  assert.deepEqual(sent, ["meeting.get"])
+  receive({ type: "meeting.get_result", meeting: { id: "other", transcript: [{ text: "末段" }] } })
+  assert.deepEqual(sent, ["meeting.get"])
+  receive({ type: "meeting.get_result", meeting: { id: "a", transcript: [{ text: "前段" }, { text: "末段" }] } })
+  await new Promise(resolve => setTimeout(resolve, 0))
+  assert.deepEqual(sent, ["meeting.get", "meeting.end"])
+  receive({ type: "meeting.ended", meeting: { id: "a" } })
+  await closing
+})
+
+test("meeting close rejects missing final text without sending end", async () => {
+  const sent: string[] = []
+  let receive: (m: any) => void = () => {}
+  const closing = confirmMeetingClose({ id: "a", expectedText: "尚未落盘", timeoutMs: 100,
+    subscribe: listener => { receive = listener; return () => {} },
+    send: (message, callback) => { sent.push(message.type as string); callback({ ok: true }) },
+  })
+  receive({ type: "meeting.get_result", meeting: { id: "a", transcript: [{ text: "旧转写" }] } })
+  await rejects(closing, /尚未确认保存/)
+  assert.deepEqual(sent, ["meeting.get"])
+})
+
+test("meeting close has bounded waits and removes its listener", async () => {
+  let removed = 0
+  await rejects(confirmMeetingClose({ id: "a", expectedText: "", timeoutMs: 5,
+    subscribe: () => () => { removed++ }, send: (_message, callback) => callback({ ok: true }),
+  }), /超时/)
+  assert.equal(removed, 1)
+})
+
+test("meeting close surfaces transport failure rather than accepting dispatch", async () => {
+  await rejects(confirmMeetingClose({ id: "a", expectedText: "", timeoutMs: 100,
+    subscribe: () => () => {}, send: (_message, callback) => callback({ ok: false, error: "断线" }),
+  }), /断线/)
+})
+
+test("meeting close also bounds a missing end event after successful readback", async () => {
+  let receive: (m: any) => void = () => {}, removed = 0
+  const closing = confirmMeetingClose({ id: "a", expectedText: "", timeoutMs: 5,
+    subscribe: listener => { receive = listener; return () => { removed++ } },
+    send: (message, callback) => {
+      callback({ ok: true })
+      if (message.type === "meeting.get") queueMicrotask(() => receive({ type: "meeting.get_result", meeting: { id: "a", transcript: [] } }))
+    },
+  })
+  await rejects(closing, /超时/)
+  assert.equal(removed, 2)
+})
+
+test("closing an audio import confirms its text without ending a recording", async () => {
+  const sent: string[] = []
+  let receive: (m: any) => void = () => {}
+  await confirmMeetingClose({ id: "a", expectedText: "已导入一段", endRecording: false, timeoutMs: 100,
+    subscribe: listener => { receive = listener; return () => {} },
+    send: (message, callback) => {
+      sent.push(message.type as string); callback({ ok: true })
+      queueMicrotask(() => receive({ type: "meeting.get_result", meeting: { id: "a", transcript: [{ text: "已导入一段" }] } }))
+    },
+  })
+  assert.deepEqual(sent, ["meeting.get"])
+})
diff --git a/chrome-extension/tests/thread-mutations.test.ts b/chrome-extension/tests/thread-mutations.test.ts
new file mode 100644
index 00000000..2a1f6d8e
--- /dev/null
+++ b/chrome-extension/tests/thread-mutations.test.ts
@@ -0,0 +1,243 @@
+import test from "node:test"
+import assert from "node:assert/strict"
+import fs from "node:fs"
+import path from "node:path"
+import vm from "node:vm"
+import { createThreadMutator, isManagedThreadMutationReply } from "../src/sidepanel/utils/thread-mutations"
+import { recordedThreadMutationResponses as recorded } from "./fixtures/thread-mutation-responses"
+declare const __dirname: string
+
+function harness(timeout = 100) {
+  const listeners = new Set<(message: any) => void>()
+  const calls: Array<{ request: any; ack: (value: any) => void }> = []
+  const runtime = {
+    onMessage: { addListener: (fn: any) => listeners.add(fn), removeListener: (fn: any) => listeners.delete(fn) },
+    sendMessage: (request: any, ack: any) => { calls.push({ request, ack }) },
+    lastError: undefined as { message: string } | undefined,
+  }
+  const emit = (message: any) => { for (const fn of [...listeners]) fn(message) }
+  return { calls, listeners, runtime, emit, mutate: createThreadMutator(runtime as any, timeout) }
+}
+
+// Scale the recorded production shape to requested synthetic IDs, keeping real
+// field names and counters (restore intentionally has neither mode nor ok).
+function success(request: any) {
+  const restoring = request.type === "thread.restore"
+  const value: any = structuredClone(recorded[restoring ? "restore" : request.mode as "trash" | "hard"])
+  value.id = request.id
+  value.failed = []
+  if (restoring) { value.restored = request.thread_ids; value.restored_count = request.thread_ids.length }
+  else { value.ok = request.thread_ids; value.deleted_ids = request.thread_ids; value.deleted_count = request.thread_ids.length }
+  return value
+}
+const tick = () => new Promise(resolve => setTimeout(resolve, 0))
+
+for (const mode of ["trash", "hard", "restore"] as const) {
+  test(`${mode}: exact recorded durable response, ACK alone never commits`, async () => {
+    const h = harness()
+    let done = false
+    const pending = h.mutate(["fixture-a", "fixture-b", "fixture-missing"], mode, new AbortController().signal).then(r => { done = true; return r })
+    const { request, ack } = h.calls[0]
+    assert.equal(request.require_connected, true)
+    ack({ id: request.id, ok: true })
+    await tick()
+    assert.equal(done, false)
+    h.emit({ ...recorded[mode], id: "other-request" })
+    assert.equal(done, false)
+    h.emit({ ...recorded[mode], id: request.id })
+    const result = await pending
+    assert.deepEqual(result, { ok: ["fixture-a", "fixture-b"], failed: [{ id: "fixture-missing", reason: "not_found" }] })
+    assert.equal(h.listeners.size, 0)
+    if (mode === "restore") { assert.equal("mode" in recorded.restore, false); assert.equal("ok" in recorded.restore, false) }
+  })
+}
+
+test("51+ IDs use serial batches of 50, preserving partial failures and exact successes", async () => {
+  const h = harness()
+  const ids = Array.from({ length: 102 }, (_, i) => `t${i}`)
+  const pending = h.mutate(ids, "trash", new AbortController().signal)
+  assert.equal(h.calls.length, 1)
+  const first = success(h.calls[0].request)
+  first.ok = first.ok.slice(1); first.deleted_ids = first.ok; first.deleted_count--
+  first.failed = [{ id: "t0", reason: "thread_busy" }]
+  h.emit(first)
+  await tick()
+  assert.equal(h.calls.length, 2)
+  h.emit(success(h.calls[1].request))
+  await tick()
+  h.emit(success(h.calls[2].request))
+  const result = await pending
+  assert.deepEqual(h.calls.map(c => c.request.thread_ids.length), [50, 50, 2])
+  assert.equal(new Set(h.calls.map(c => c.request.id)).size, 3)
+  assert.deepEqual(result.ok, ids.slice(1))
+  assert.deepEqual(result.failed, [{ id: "t0", reason: "thread_busy" }])
+  assert.equal(h.listeners.size, 0)
+})
+
+test("empty cleanup uses bounded hard requests with only_empty and never expands targets", async () => {
+  const h = harness()
+  const ids = Array.from({ length: 51 }, (_, i) => `empty-${i}`)
+  const pending = h.mutate(ids, "empty", new AbortController().signal)
+  assert.deepEqual(h.calls[0].request.thread_ids, [])
+  assert.equal(h.calls[0].request.probe, "only_empty")
+  h.emit({ ...recorded.capabilities, id: h.calls[0].request.id })
+  await tick()
+  assert.equal(h.calls[1].request.mode, "hard")
+  assert.equal(h.calls[1].request.only_empty, true)
+  h.emit(success(h.calls[1].request))
+  await tick()
+  assert.equal(h.calls[2].request.only_empty, true)
+  h.emit(success(h.calls[2].request))
+  assert.deepEqual((await pending).ok, ids)
+  assert.deepEqual(h.calls.flatMap(c => c.request.thread_ids), ids)
+  assert.equal(h.listeners.size, 0)
+})
+
+for (const failure of ["old-server", "missing-id", "wrong-shape", "disconnect"] as const) {
+  test(`empty probe ${failure} never sends mutation targets`, async () => {
+    const h = harness(15)
+    const pending = h.mutate(["valuable"], "empty", new AbortController().signal)
+    const { request } = h.calls[0]
+    if (failure === "old-server") h.emit({ type: "error", id: request.id, error: "thread.batch_delete requires non-empty thread_ids" })
+    if (failure === "missing-id") h.emit(recorded.capabilities)
+    if (failure === "wrong-shape") h.emit({ ...recorded.capabilities, only_empty: false, id: request.id })
+    if (failure === "disconnect") h.emit({ type: "thread.mutation.connection", state: "disconnected" })
+    const result = await pending
+    assert.deepEqual(result.ok, [])
+    assert.equal(result.failed[0].reason, failure === "disconnect" ? "not_sent" : "not_sent_unsupported")
+    assert.equal(h.calls.length, 1)
+    assert.deepEqual(request.thread_ids, [])
+    assert.equal(h.listeners.size, 0)
+  })
+}
+
+test("connection loss immediately after probe invalidates capability before any deletion", async () => {
+  const h = harness()
+  const pending = h.mutate(["keep"], "empty", new AbortController().signal)
+  h.emit({ ...recorded.capabilities, id: h.calls[0].request.id })
+  h.emit({ type: "thread.mutation.connection", state: "disconnected" })
+  h.emit({ type: "thread.mutation.connection", state: "connected" })
+  assert.deepEqual(await pending, { ok: [], failed: [{ id: "keep", reason: "not_sent" }] })
+  assert.equal(h.calls.length, 1)
+  assert.equal(h.listeners.size, 0)
+})
+
+for (const defect of ["mode", "duplicate", "unrequested", "omitted", "wrong-type", "counter"] as const) {
+  test(`reject ${defect} result without claiming any successful mutation`, async () => {
+    const h = harness()
+    const pending = h.mutate(["a", "b"], "hard", new AbortController().signal)
+    const value = success(h.calls[0].request)
+    if (defect === "mode") value.mode = "trash"
+    if (defect === "duplicate") value.ok = ["a", "a"]
+    if (defect === "unrequested") value.ok = ["a", "other"]
+    if (defect === "omitted") value.ok = ["a"]
+    if (defect === "wrong-type") value.type = "thread.restored"
+    if (defect === "counter") value.deleted_count = 1
+    h.emit(value)
+    const result = await pending
+    assert.deepEqual(result.ok, [])
+    assert.ok(result.failed.every(f => f.reason === "unknown_invalid_response"))
+    assert.equal(h.listeners.size, 0)
+  })
+}
+
+test("wrong ACK id is uncertain; definite not-sent ACK stops remaining batches", async () => {
+  for (const wrongId of [true, false]) {
+    const h = harness()
+    const ids = Array.from({ length: 51 }, (_, i) => String(i))
+    const pending = h.mutate(ids, "hard", new AbortController().signal)
+    h.calls[0].ack({ id: wrongId ? "wrong" : h.calls[0].request.id, ok: false })
+    const result = await pending
+    assert.equal(result.failed[0].reason, wrongId ? "unknown_transport" : "not_sent")
+    assert.equal(result.failed[50].reason, "not_sent")
+    assert.equal(h.calls.length, 1)
+    assert.equal(h.listeners.size, 0)
+  }
+})
+
+test("timeout after a successful batch keeps successes, stops remainder, and ignores late response", async () => {
+  const h = harness(15)
+  const ids = Array.from({ length: 101 }, (_, i) => String(i))
+  const pending = h.mutate(ids, "hard", new AbortController().signal)
+  h.emit(success(h.calls[0].request))
+  const result = await pending
+  assert.deepEqual(result.ok, ids.slice(0, 50))
+  assert.equal(result.failed[0].reason, "unknown_timeout")
+  assert.equal(result.failed[50].reason, "not_sent")
+  assert.equal(h.calls.length, 2)
+  h.emit(success(h.calls[1].request))
+  assert.equal(result.ok.length, 50)
+  assert.equal(h.listeners.size, 0)
+})
+
+test("abort before send is not_sent; abort in flight is unknown and listeners are removed", async () => {
+  for (const before of [true, false]) {
+    const h = harness()
+    const controller = new AbortController()
+    if (before) controller.abort()
+    const pending = h.mutate(["a"], "trash", controller.signal)
+    if (!before) controller.abort()
+    const result = await pending
+    assert.equal(result.failed[0].reason, before ? "not_sent" : "unknown_aborted")
+    assert.equal(h.calls.length, before ? 0 : 1)
+    assert.equal(h.listeners.size, 0)
+  }
+})
+
+test("disconnect and runtime channel loss are uncertain, without retry", async () => {
+  for (const channelLoss of [false, true]) {
+    const h = harness()
+    const pending = h.mutate(["a"], "restore", new AbortController().signal)
+    if (channelLoss) {
+      h.runtime.lastError = { message: "channel closed" }
+      h.calls[0].ack(undefined)
+    } else h.emit({ type: "thread.mutation.connection", state: "disconnected" })
+    assert.equal((await pending).failed[0].reason, channelLoss ? "unknown_transport" : "unknown_disconnected")
+    assert.equal(h.calls.length, 1)
+    assert.equal(h.listeners.size, 0)
+  }
+})
+
+test("server response can beat runtime ACK; late ACK/duplicate do not overwrite committed result", async () => {
+  const h = harness()
+  const pending = h.mutate(["a", "a"], "trash", new AbortController().signal)
+  assert.deepEqual(h.calls[0].request.thread_ids, ["a"])
+  h.emit(success(h.calls[0].request))
+  h.calls[0].ack({ id: h.calls[0].request.id, ok: false })
+  h.emit(success(h.calls[0].request))
+  assert.deepEqual(await pending, { ok: ["a"], failed: [] })
+  assert.equal(h.listeners.size, 0)
+})
+
+test("managed restore identity is explicit; legacy restore keeps its normal refresh behavior", () => {
+  assert.equal(isManagedThreadMutationReply({ id: "thread-mutation:123" }), true)
+  assert.equal(isManagedThreadMutationReply({ id: "legacy" }), false)
+  assert.equal(isManagedThreadMutationReply({}), false)
+})
+
+test("actual background mutation branches reject disconnected/handshaking without buffering, retain correlation", () => {
+  const srcPath = [path.join(__dirname, "../src/background/index.ts"), path.join(__dirname, "../../src/background/index.ts")].find(p => fs.existsSync(p))!
+  const source = fs.readFileSync(srcPath, "utf8")
+  const start = source.indexOf('      case "thread.delete":')
+  const end = source.indexOf('      case "thread.suggest_cleanup":', start)
+  const code = `(function(){switch(message.type){${source.slice(start, end)}}})()`
+  for (const type of ["thread.delete", "thread.batch_delete", "thread.restore"]) {
+    for (const state of ["disconnected", "connecting", "connected"]) {
+      for (const sent of [true, false]) {
+        const calls: any[] = []; let ack: any
+        vm.runInNewContext(code, {
+          message: { type, id: "request", thread_ids: ["a"], thread_id: "a", require_connected: true, mode: "hard", only_empty: true },
+          wsClient: { getState: () => state, send: (message: any) => { calls.push(message); return sent } },
+          sendResponse: (value: any) => { ack = value },
+        })
+        assert.equal(calls.length, state === "connected" ? 1 : 0)
+        assert.equal(ack.id, "request")
+        assert.equal(ack.ok, state === "connected" && sent)
+        if (calls.length) {
+          assert.equal(calls[0].id, "request")
+          if (type === "thread.batch_delete") assert.equal(calls[0].only_empty, true)
+        }
+      }
+    }
+  }
+})
diff --git a/companion/src/message-router.ts b/companion/src/message-router.ts
index 6bef0cb3..97002302 100644
--- a/companion/src/message-router.ts
+++ b/companion/src/message-router.ts
@@ -2408,6 +2408,12 @@ export async function handleMessage(
      */
     case "thread.batch_delete": {
       const rawIds = rest.thread_ids
+      if (rest.probe !== undefined) {
+        if (rest.probe === "only_empty" && Array.isArray(rawIds) && rawIds.length === 0) {
+          return { type: "thread.batch_delete.capabilities", only_empty: true }
+        }
+        return { type: "error", error: "thread.batch_delete probe requires only_empty and empty thread_ids" }
+      }
       if (!Array.isArray(rawIds) || rawIds.length === 0) {
         return { type: "error", error: "thread.batch_delete requires non-empty thread_ids" }
       }
@@ -2415,6 +2421,9 @@ export async function handleMessage(
         return { type: "error", error: "thread.batch_delete max 50 threads per request" }
       }
       const mode = rest.mode === "hard" ? "hard" : "trash"
+      if (rest.only_empty !== undefined && (typeof rest.only_empty !== "boolean" || (rest.only_empty && mode !== "hard"))) {
+        return { type: "error", error: "only_empty requires a boolean and mode=hard" }
+      }
       const busy = new Set(listLlmActiveThreadIds())
       const ok: string[] = []
       const failed: Array<{ id: string; reason: string }> = []
@@ -2436,7 +2445,7 @@ export async function handleMessage(
             failed.push({ id: String(raw ?? ""), reason: "invalid_id" })
             continue
           }
-          if (busy.has(id)) {
+          if (busy.has(id) || (rest.only_empty === true && listLlmActiveThreadIds().includes(id))) {
             failed.push({ id, reason: "thread_busy" })
             continue
           }
@@ -2445,6 +2454,18 @@ export async function handleMessage(
             failed.push({ id, reason: "not_found" })
             continue
           }
+          if (rest.only_empty === true) {
+            if (thr.trashed_at) {
+              failed.push({ id, reason: "trashed" })
+              continue
+            }
+            // Recheck durable messages immediately before deletion, not the UI's
+            // earlier list count: a conversation may have changed during confirmation.
+            if (threadManager.getMessages(id).length !== 0) {
+              failed.push({ id, reason: "not_empty" })
+              continue
+            }
+          }
           try {
             releaseTrust?.(thr, "thread.batch_delete", threadManager)
           } catch {
diff --git a/companion/src/ws/validate.ts b/companion/src/ws/validate.ts
index cb83d7d3..ca108275 100644
--- a/companion/src/ws/validate.ts
+++ b/companion/src/ws/validate.ts
@@ -115,6 +115,11 @@ export function validateWsMessage(msg: any): WsValidationResult {
       return { valid: true }
     },
     "thread.batch_delete": (m) => {
+      if (m.probe !== undefined) {
+        return m.probe === "only_empty" && Array.isArray(m.thread_ids) && m.thread_ids.length === 0
+          ? { valid: true }
+          : { valid: false, error: "thread.batch_delete probe requires only_empty and empty thread_ids" }
+      }
       if (!Array.isArray(m.thread_ids) || m.thread_ids.length === 0) {
         return { valid: false, error: "thread.batch_delete requires non-empty thread_ids" }
       }
@@ -127,6 +132,9 @@ export function validateWsMessage(msg: any): WsValidationResult {
       if (m.mode !== undefined && m.mode !== "trash" && m.mode !== "hard") {
         return { valid: false, error: "thread.batch_delete mode must be trash|hard" }
       }
+      if (m.only_empty !== undefined && (typeof m.only_empty !== "boolean" || (m.only_empty && m.mode !== "hard"))) {
+        return { valid: false, error: "thread.batch_delete only_empty requires a boolean and mode=hard" }
+      }
       return { valid: true }
     },
     "thread.restore": (m) => {
diff --git a/companion/tests/thread-empty-mutation-488.test.ts b/companion/tests/thread-empty-mutation-488.test.ts
new file mode 100644
index 00000000..ffdec508
--- /dev/null
+++ b/companion/tests/thread-empty-mutation-488.test.ts
@@ -0,0 +1,83 @@
+import test, { before, after } from "node:test"
+import assert from "node:assert/strict"
+import fs from "node:fs"
+import os from "node:os"
+import path from "node:path"
+import { validateWsMessage } from "../src/ws/validate"
+
+const dir = fs.mkdtempSync(path.join(os.tmpdir(), "cmspark-488-empty-mutation-"))
+process.env.CMSPARK_DATA_DIR = dir
+let ThreadManager: typeof import("../src/threads/thread-manager").ThreadManager
+let handleMessage: typeof import("../src/message-router").handleMessage
+let setBusy: typeof import("../src/message-router").__testSetLlmActiveForTests
+before(async () => {
+  await (await import("../src/config")).initDataDir()
+  ThreadManager = (await import("../src/threads/thread-manager")).ThreadManager
+  const router = await import("../src/message-router")
+  handleMessage = router.handleMessage
+  setBusy = router.__testSetLlmActiveForTests
+})
+after(() => { fs.rmSync(dir, { recursive: true, force: true }) })
+
+test("empty cleanup rechecks durable content, trash and busy after confirmation", async () => {
+  const tm = new ThreadManager()
+  const ids = ["empty", "became-nonempty", "trashed", "busy", "missing"]
+  for (const id of ids.slice(0, -1)) tm.create(id, id)
+  // At confirmation time every candidate was empty. Then other work changes it.
+  tm.addMessage("became-nonempty", { thread_id: "became-nonempty", role: "user", content: "keep this conversation" })
+  tm.trash("trashed")
+  setBusy("busy", true)
+  const broadcasts: any[] = []
+  try {
+    const response = await handleMessage({ type: "thread.batch_delete", thread_ids: ids, mode: "hard", only_empty: true },
+      { threadManager: tm, skillEngine: {} as any, historyStore: {} as any },
+      { broadcast: (msg: any) => broadcasts.push(msg) } as any)
+    assert.deepEqual(response, {
+      type: "thread.batch_deleted", ok: ["empty"],
+      failed: [
+        { id: "became-nonempty", reason: "not_empty" },
+        { id: "trashed", reason: "trashed" },
+        { id: "busy", reason: "thread_busy" },
+        { id: "missing", reason: "not_found" },
+      ], deleted_ids: ["empty"], deleted_count: 1, mode: "hard",
+    })
+    assert.equal(tm.get("empty"), undefined)
+    assert.equal(tm.getMessages("became-nonempty")[0].content, "keep this conversation")
+    assert.ok(tm.get("trashed")?.trashed_at)
+    assert.ok(tm.get("busy"))
+    assert.deepEqual(broadcasts.map(b => b.thread_id), ["empty"])
+  } finally { setBusy("busy", false) }
+})
+
+test("only_empty malformed/soft modes fail closed; legacy hard deletion is unchanged", async () => {
+  const tm = new ThreadManager()
+  tm.create("legacy", "legacy")
+  tm.addMessage("legacy", { thread_id: "legacy", role: "user", content: "explicit regular hard delete remains available" })
+  const services = { threadManager: tm, skillEngine: {} as any, historyStore: {} as any }
+  for (const extra of [{ mode: "trash", only_empty: true }, { mode: "hard", only_empty: "true" }]) {
+    const message = { type: "thread.batch_delete", thread_ids: ["legacy"], ...extra }
+    assert.equal(validateWsMessage(message).valid, false)
+    assert.equal((await handleMessage(message, services))?.type, "error")
+    assert.ok(tm.get("legacy"))
+  }
+  const response = await handleMessage({ type: "thread.batch_delete", thread_ids: ["legacy"], mode: "hard" }, services)
+  assert.deepEqual(response.ok, ["legacy"])
+  assert.equal(tm.get("legacy"), undefined)
+})
+
+test("capability probe has empty targets and cannot mutate; malformed probes are rejected", async () => {
+  const tm = new ThreadManager()
+  tm.create("probe-keep", "probe-keep")
+  const services = { threadManager: tm, skillEngine: {} as any, historyStore: {} as any }
+  const probe = { type: "thread.batch_delete", thread_ids: [], probe: "only_empty" }
+  assert.equal(validateWsMessage(probe).valid, true)
+  assert.deepEqual(await handleMessage(probe, services), { type: "thread.batch_delete.capabilities", only_empty: true })
+  for (const malformed of [
+    { ...probe, thread_ids: ["probe-keep"], mode: "hard" },
+    { ...probe, probe: "unknown" },
+  ]) {
+    assert.equal(validateWsMessage(malformed).valid, false)
+    assert.equal((await handleMessage(malformed, services))?.type, "error")
+  }
+  assert.ok(tm.get("probe-keep"))
+})
diff --git a/docs/superpowers/plans/2026-09-09-windows-thread-ux-review.md b/docs/superpowers/plans/2026-09-09-windows-thread-ux-review.md
new file mode 100644
index 00000000..8daa5dd4
--- /dev/null
+++ b/docs/superpowers/plans/2026-09-09-windows-thread-ux-review.md
@@ -0,0 +1,38 @@
+# Windows 变更复审与 Mac 交互修复
+
+GitHub: #488 · 外部范围 4a63de56 → 947532a8（#487）
+
+## 证据与完成边界
+
+冻结外部 diff，Grok / 独立 Codex / DeepSeek 三路分别复审；主代理复现后定级。
+真实 App 合成传输已复现：标签筛选显示 2 个却全选 60 个；超过服务端 50 条上限的
+删除请求在回执之前移除了全部 UI 记录；320×480 时管理列表高度为 0。
+此前测试仅检查按钮可见与横向溢出，不能覆盖这些错误。
+
+## 本批修复
+
+1. 列表选择域等于搜索、回收站与标签筛选后的候选，排除运行中对话。选择为空不能
+   自动扩大为其他目标；变化只收窄。整理助手选择域独立。确认显示标题与编号。
+2. 删除/恢复使用唯一请求 ID 等待真实持久化回执，50 条一批串行；成功/失败分别
+   显示，未知结果明确可能已完成，不自动重试。离线不排队破坏性操作。
+   清理空白先用空目标只读探测，旧 Companion 不会收到实际删除目标；支持时服务端
+   在删除前重查内容、回收站及运行状态，避免确认期间变化导致误删。
+3. 管理器保持非模态与输入/停止可达；短屏改为可滚动整体，列表保有可用空间。
+   去重全选按钮与层级，不移除人工/AI分类、摘要、图谱、知识、命名或清理能力。
+4. 会议用户关闭流程必须先 stop 收取最后转写，再结束/收起；补证被外部复审发现的
+   既有末段丢失问题。失败保留可恢复状态，不以改按钮文案完成修复。
+5. 统一硬编码默认品牌为已有连接火花矢量图。既有品牌不是用户配置；不删个性化能力。
+   检查资源/设置完整入口；资源抽屉说明各项作用域，技能按钮窄屏换行但不挤碎文字。
+   更大的产品重构仍在 #481/#476。
+
+能力声明：本批按 T3 审查持久化删除边界，扩展既有 batch_delete 的 only_empty 条件与
+空目标只读能力探测；Surface、L2 类、Compose 执行能力、Autonomy、Trust 与 Channel
+均维持既有授权。没有新工具、默认外发、终端自动启动或权限豁免。
+
+## 验收
+
+生产函数协议测试 + 实际组件交互：标签全选、51/60 条分批、busy/filter变化、
+错/迟/缺回执、部分失败、恢复、取消、清理选择域、短屏滚动、确认/停止、完整入口。
+会议用合成捕获验证最后结果与关闭时序，不声称实机识别性能。
+冻结修复代码，Grok + DeepSeek 独立复审；所有阻断复现、修复、重审留痕。
+最终提交 CI 通过后合 main，Mac 打包/签名/替换/启动另有证明，提醒 Reload 插件。

FULL SOURCE chrome-extension/src/sidepanel/utils/thread-mutations.ts
export type ThreadMutationMode = "trash" | "hard" | "restore" | "empty"
export type ThreadMutationResult = { ok: string[]; failed: Array<{ id: string; reason: string }> }

const REQUEST_PREFIX = "thread-mutation:"
export function isManagedThreadMutationReply(message: { id?: unknown }): boolean {
  return typeof message.id === "string" && message.id.startsWith(REQUEST_PREFIX)
}

type Runtime = Pick<typeof chrome.runtime, "onMessage" | "sendMessage" | "lastError">
type BatchResult = ThreadMutationResult & { stop?: boolean; reason?: string }
type RequestMode = ThreadMutationMode | "probe"

/** Only a complete, correlated server result can confirm durable changes. */
function parseResult(message: any, ids: string[], mode: RequestMode): ThreadMutationResult | null {
  if (mode === "probe") {
    return message.type === "thread.batch_delete.capabilities" && message.only_empty === true
      ? { ok: [], failed: [] } : null
  }
  if (message.type !== (mode === "restore" ? "thread.restored" : "thread.batch_deleted")) return null
  if (mode !== "restore" && message.mode !== (mode === "empty" ? "hard" : mode)) return null
  const ok = mode === "restore" ? message.restored : message.ok
  const failed = message.failed
  if (!Array.isArray(ok) || !Array.isArray(failed)) return null
  const expected = new Set(ids)
  const seen = new Set<string>()
  for (const id of ok) {
    if (typeof id !== "string" || !expected.has(id) || seen.has(id)) return null
    seen.add(id)
  }
  for (const item of failed) {
    if (!item || typeof item.id !== "string" || !expected.has(item.id) || seen.has(item.id)
      || typeof item.reason !== "string" || !item.reason) return null
    seen.add(item.id)
  }
  if (seen.size !== expected.size) return null
  const count = mode === "restore" ? message.restored_count : message.deleted_count
  if (count !== ok.length) return null
  if (mode !== "restore" && (!Array.isArray(message.deleted_ids)
    || message.deleted_ids.length !== ok.length
    || message.deleted_ids.some((id: unknown, i: number) => id !== ok[i]))) return null
  return { ok: [...ok], failed: failed.map(({ id, reason }: { id: string; reason: string }) => ({ id, reason })) }
}

/** Injecting the runtime/timeout keeps transport races testable without a browser or daemon. */
export function createThreadMutator(runtime: Runtime, timeoutMs = 30_000) {
  function batch(ids: string[], mode: RequestMode, signal: AbortSignal): Promise<BatchResult> {
    if (signal.aborted) return Promise.resolve({ ok: [], failed: ids.map(id => ({ id, reason: "not_sent" })), stop: true, reason: "not_sent" })
    const requestId = REQUEST_PREFIX + crypto.randomUUID()
    return new Promise(resolve => {
      let settled = false
      let attempted = false
      let timer: ReturnType<typeof setTimeout> | undefined
      const finish = (result: BatchResult) => {
        if (settled) return
        settled = true
        if (timer) clearTimeout(timer)
        runtime.onMessage.removeListener(onMessage)
        signal.removeEventListener("abort", onAbort)
        resolve(result)
      }
      const stop = (reason: string) => finish({ ok: [], failed: ids.map(id => ({ id, reason })), stop: true, reason })
      const onAbort = () => stop(attempted ? "unknown_aborted" : "not_sent")
      const onMessage = (message: any) => {
        if (message?.type === "thread.mutation.connection" && message.state !== "connected") {
          stop(attempted ? "unknown_disconnected" : "not_sent")
          return
        }
        if (message?.id !== requestId) return
        // A handler error can follow a partial mutation: do not say nothing changed.
        if (message.type === "error") { stop("unknown_server_error"); return }
        const result = parseResult(message, ids, mode)
        if (result) finish(result)
        else stop("unknown_invalid_response")
      }
      runtime.onMessage.addListener(onMessage)
      signal.addEventListener("abort", onAbort, { once: true })
      if (signal.aborted) { onAbort(); return }
      timer = setTimeout(() => stop("unknown_timeout"), timeoutMs)
      attempted = true
      try {
        runtime.sendMessage({
          type: mode === "restore" ? "thread.restore" : "thread.batch_delete",
          id: requestId,
          thread_ids: ids,
          ...(mode === "restore" || mode === "probe" ? {} : { mode: mode === "empty" ? "hard" : mode }),
          ...(mode === "empty" ? { only_empty: true } : {}),
          ...(mode === "probe" ? { probe: "only_empty" } : {}),
          require_connected: true,
        }, (ack: any) => {
          const transportError = runtime.lastError
          if (settled) return
          if (transportError || ack?.id !== requestId || typeof ack?.ok !== "boolean") {
            stop("unknown_transport")
          } else if (!ack.ok) {
            stop("not_sent")
          }
          // ok=true only acknowledges transport; keep waiting for the server.
        })
      } catch {
        stop("unknown_transport")
      }
    })
  }

  return async (rawIds: string[], mode: ThreadMutationMode, signal: AbortSignal): Promise<ThreadMutationResult> => {
    const ids = [...new Set(rawIds.filter(id => typeof id === "string" && id.length > 0))]
    const result: ThreadMutationResult = { ok: [], failed: [] }
    if (ids.length === 0) return result
    // Also cover the microtask gap between a reply and the next batch/probe.
    // A capability checked on one connection must not authorize another one.
    let connectionLost = false
    const onConnection = (message: any) => {
      if (message?.type === "thread.mutation.connection" && message.state !== "connected") connectionLost = true
    }
    runtime.onMessage.addListener(onConnection)
    try {
      if (mode === "empty") {
        // An old Companion rejects the empty target list before doing any work.
        // Probe every invocation, never reuse capability across reconnections.
        const probe = await batch([], "probe", signal)
        if (probe.stop) {
          const reason = ["unknown_server_error", "unknown_invalid_response", "unknown_timeout"].includes(probe.reason || "")
            ? "not_sent_unsupported" : "not_sent"
          return { ok: [], failed: ids.map(id => ({ id, reason })) }
        }
      }
      for (let offset = 0; offset < ids.length; offset += 50) {
        if (connectionLost) {
          result.failed.push(...ids.slice(offset).map(id => ({ id, reason: "not_sent" })))
          break
        }
        const next = await batch(ids.slice(offset, offset + 50), mode, signal)
        result.ok.push(...next.ok)
        result.failed.push(...next.failed)
        if (next.stop) {
          result.failed.push(...ids.slice(offset + 50).map(id => ({ id, reason: "not_sent" })))
          break
        }
      }
      return result
    } finally {
      runtime.onMessage.removeListener(onConnection)
    }
  }
}

export function mutateThreads(ids: string[], mode: ThreadMutationMode, signal: AbortSignal): Promise<ThreadMutationResult> {
  return createThreadMutator(chrome.runtime)(ids, mode, signal)
}

FULL SOURCE chrome-extension/src/sidepanel/voice/meeting-close.ts
/** Wait for persisted transcript and the server end event, not a transport ACK. */
export async function confirmMeetingClose(options: {
  id: string
  expectedText: string
  endRecording?: boolean
  send: (message: Record<string, unknown>, callback: (reply: any) => void) => void
  subscribe: (listener: (message: any) => void) => () => void
  timeoutMs?: number
}): Promise<void> {
  const { id, send, subscribe, expectedText, timeoutMs = 10_000 } = options
  const compact = (text: string) => text.replace(/\s+/gu, "")
  const wait = (type: "meeting.get_result" | "meeting.ended", request: string) => new Promise<any>((resolve, reject) => {
    let settled = false
    let unsubscribe = () => {}
    const finish = (error?: Error, value?: any) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      unsubscribe()
      error ? reject(error) : resolve(value)
    }
    const timer = setTimeout(() => finish(new Error("保存确认超时，请保持面板并重试")), timeoutMs)
    unsubscribe = subscribe(message => {
      if (message.type === type && message.meeting?.id === id) finish(undefined, message.meeting)
      if (message.type === "meeting.error" && message.id === id) finish(new Error(message.message || "会议保存失败"))
    })
    try {
      send({ type: request, v: 1, id }, reply => {
        if (reply?.ok === false) finish(new Error(reply.error || "Companion 未连接，请重连后重试"))
      })
    } catch {
      finish(new Error("无法连接 Companion，请重连后重试"))
    }
  })
  const persisted = await wait("meeting.get_result", "meeting.get")
  const saved = (persisted.transcript || []).map((line: any) => String(line.text || "")).join("\n")
  if (expectedText.trim() && !compact(saved).endsWith(compact(expectedText))) {
    throw new Error("最后一段尚未确认保存。转写仍保留在面板，请保存转写后重试收起")
  }
  if (options.endRecording !== false) await wait("meeting.ended", "meeting.end")
}

FULL SOURCE chrome-extension/src/sidepanel/components/ThreadList.tsx
// Thread list — Timeline IA: today/yesterday + month→day, multi-select, tags view (P1).
// Wave A: untagged batch extract, tldr row, portal menu, tag cloud fold, N/M progress.

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { createPortal } from "react-dom"
import { useAgentStore } from "../store/agentStore"
import { tokens } from "../ui/tokens"
import { ThreadMetadataEditor } from "./ThreadMetadataEditor"
import { aiThreadGroup, threadTags } from "../utils/thread-management"
import { mutateThreads } from "../utils/thread-mutations"
import { IconHistory } from "../ui/icons"
import { popupMenuStyles } from "../ui/popupMenuStyles"
import type { Thread } from "../types"
import {
  batchNeedsForceExtract,
  buildTagIndex,
  collapseTagKeys,
  digestQuotaDayKey,
  acpOutcomeChip,
  countAliases,
  displayThreadEvidence,
  displayThreadTitle,
  EXTRACT_DIGEST_MAX,
  threadAccessibleName,
  filterThreadsByQuery,
  formatThreadIdBadge,
  formatThreadListTime,
  groupThreadsByCalendar,
  isMonthGroupOpen,
  isPinnedGroupOpen,
  LS_DIGEST_QUOTA,
  LS_THREAD_LIST_EXPAND,
  LS_THREAD_LIST_EXPAND_MONTHS_LEGACY,
  parseDigestQuota,
  parseThreadListExpand,
  remainingDigestQuota,
  roleBadge,
  selectLazyDigestCandidates,
  selectUntaggedForExtract,
  selectionState,
  showDigestStaleBadge,
  TAG_CLOUD_MAX_VISIBLE,
  threadIdsInDay,
  threadIdsInMonth,
  toggleGroupSelection,
  selectAllIds,
  allSelectableSelected,
  type MonthGroup,
  type DayGroup,
  type ThreadListExpandState,
} from "../utils/thread-timeline"
import {
  digestLintStats,
  findRelatedThreads,
} from "../utils/thread-related"
import type { ThreadGraphSlim } from "../../background/thread-graph"

export function createBlankThread(dispatch: (action: { type: "ADD_THREAD"; thread: Thread }) => void) {
  const id = generateShortId()
  const now = new Date().toISOString()
  const thread = {
    id,
    alias: "",
    created_at: now,
    updated_at: now,
    // Inherit live companion config — do not stamp DeepSeek / empty trust.
    config_override: {} as Thread["config_override"],
    tool_whitelist: null as string[] | null,
    pinned_tabs: [] as number[],
    active_skill_ids: [] as string[],
  }
  dispatch({ type: "ADD_THREAD", thread: thread as Thread })
  chrome.runtime.sendMessage({ type: "thread.create", alias: "", id })
  return id
}

function generateShortId(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
  let id = ""
  for (let i = 0; i < 6; i++) {
    id += chars[Math.floor(Math.random() * chars.length)]
  }
  return id
}

function loadExpandState(): ThreadListExpandState {
  try {
    const raw = localStorage.getItem(LS_THREAD_LIST_EXPAND)
    if (raw) return parseThreadListExpand(raw)
    // One-shot migrate legacy months array
    const legacy = localStorage.getItem(LS_THREAD_LIST_EXPAND_MONTHS_LEGACY)
    if (legacy) {
      const migrated = parseThreadListExpand(legacy)
      saveExpandState(migrated)
      try {
        localStorage.removeItem(LS_THREAD_LIST_EXPAND_MONTHS_LEGACY)
      } catch {
        /* ignore */
      }
      return migrated
    }
  } catch {
    /* ignore */
  }
  return parseThreadListExpand(null)
}

function saveExpandState(state: ThreadListExpandState) {
  try {
    localStorage.setItem(LS_THREAD_LIST_EXPAND, JSON.stringify(state))
  } catch {
    /* ignore quota */
  }
}

type ListView = "time" | "tags" | "topics" | "ai"

export function ThreadList() {
  const { state, dispatch } = useAgentStore()
  const [open, setOpen] = useState(false)
  const [editingThread, setEditingThread] = useState<Thread | null>(null)
  const [metadataNotice, setMetadataNotice] = useState("")
  const [mutationNotice, setMutationNotice] = useState("")
  const [mutating, setMutating] = useState(false)
  const mutationRef = useRef<AbortController | null>(null)
  useEffect(() => () => mutationRef.current?.abort(), [])
  useEffect(() => { if (!open) { setEditingThread(null); setMetadataNotice(""); setPendingDelete(null) } }, [open])
  useEffect(() => {
    const show = () => { if (!state.pendingSecurityConfirmations.length) setOpen(true) }
    window.addEventListener("cmspark:open-thread-manager", show)
    return () => window.removeEventListener("cmspark:open-thread-manager", show)
  }, [state.pendingSecurityConfirmations.length])
  useEffect(() => { if (state.pendingSecurityConfirmations.length) setOpen(false) }, [state.pendingSecurityConfirmations.length])
  const [query, setQuery] = useState("")
  const [view, setView] = useState<ListView>("time")
  const [selectMode, setSelectMode] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(() => new Set())
  const [expandState, setExpandState] = useState<ThreadListExpandState>(loadExpandState)
  const [expandedDays, setExpandedDays] = useState<Set<string>>(() => new Set())
  const [menuOpen, setMenuOpen] = useState(false)
  const menuOpenRef = useRef(menuOpen)
  useEffect(() => { menuOpenRef.current = menuOpen }, [menuOpen])
  const [menuPos, setMenuPos] = useState<{ top: number; right: number } | null>(null)
  const menuBtnRef = useRef<HTMLButtonElement | null>(null)
  const triggerRef = useRef<HTMLButtonElement | null>(null)
  const historyMenuRef = useRef<HTMLDivElement>(null)
  const historyRef = useRef<HTMLDivElement>(null)
  const [panelBox, setPanelBox] = useState<{ top: number; maxHeight: number } | null>(null)
  const [activeTag, setActiveTag] = useState<string | null>(null)
  const [extractingIds, setExtractingIds] = useState<Set<string>>(() => new Set())
  /** A-7 batch progress: done/total while untagged or multi extract runs. */
  const [extractProgress, setExtractProgress] = useState<{
    done: number
    total: number
  } | null>(null)
  /** Fingerprint/extracted_at snapshot at batch start — progress via UPSERT (S5). */
  const extractBatchRef = useRef<{
    /** Monotonic id so a late completed event cannot corrupt a newer batch. */
    batchId: number
    remaining: Set<string>
    total: number
    startMark: Map<string, string>
    /** Charge daily lazy quota only after successful ok[] (Wave B nit). */
    countTowardQuota: boolean
  } | null>(null)
  const extractBatchSeqRef = useRef(0)
  /** Clear N/M bar after complete; cancelled when a new batch starts (Claude N3). */
  const extractProgressClearTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [tagCloudExpanded, setTagCloudExpanded] = useState(false)
  const [trashView, setTrashView] = useState(false)
  const [cleanupOpen, setCleanupOpen] = useState(false)
  const [cleanupSuggestions, setCleanupSuggestions] = useState<
    Array<{
      thread_id: string
      reason: string
      detail: string
      confidence: number
      precheck?: boolean
    }>
  >([])
  const [cleanupSelected, setCleanupSelected] = useState<Set<string>>(() => new Set())
  /** 0 = 全部（含近期） */
  const [cleanupDays, setCleanupDays] = useState(0)
  /** In-panel confirm: Side Panel often swallows window.confirm (delete looks dead). */
  const [pendingDelete, setPendingDelete] = useState<{
    ids: string[]
    hard: boolean
    source: "row" | "batch" | "cleanup" | "empty"
  } | null>(null)
  useEffect(() => {
    if (!pendingDelete) return
    historyRef.current?.querySelector("[role='alertdialog']")?.scrollIntoView({ block: "nearest" })
    historyRef.current?.querySelector<HTMLButtonElement>("[data-delete-cancel]")?.focus()
  }, [pendingDelete])
  /** Wave C: seed for related list; graph focus */
  const [relatedSeedId, setRelatedSeedId] = useState<string | null>(null)
  /** Companion thread.related override (local mirror first; WS may refine). */
  const [relatedFromServer, setRelatedFromServer] = useState<
    Array<{ thread_id: string; score: number; shared_tags?: string[] }> | null
  >(null)
  /** Brief feedback after click-to-copy thread id badge. */
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const copyIdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  useEffect(() => {
    return () => {
      if (copyIdTimerRef.current) clearTimeout(copyIdTimerRef.current)
    }
  }, [])

  const { threads, activeThreadId, threadBusyById, config } = state
  /** Graph tab → open session (TG-3): keep graph open, switch active thread here. */
  useEffect(() => {
    const onMsg = (msg: { type?: string; thread_id?: string }) => {
      if (msg?.type !== "thread_graph.thread_selected" || !msg.thread_id) return
      // P1 H-UI-2: same thread → no-op (do not wipe messages)
      if (msg.thread_id === activeThreadId) return
      const thr = threads.find((t) => t.id === msg.thread_id)
      if (thr?.trashed_at) return
      dispatch({ type: "SET_ACTIVE_THREAD", threadId: msg.thread_id })
    }
    chrome.runtime.onMessage.addListener(onMsg)
    return () => chrome.runtime.onMessage.removeListener(onMsg)
  }, [dispatch, threads, activeThreadId])
  /** One-shot lazy extract per panel open when settings enabled (B-2). */
  const lazyDigestRanRef = useRef(false)

  const now = useMemo(() => new Date(), [open, threads.length])

  useEffect(() => {
    const onSug = (e: Event) => {
      const detail = (e as CustomEvent).detail
      const list = Array.isArray(detail?.suggestions) ? detail.suggestions : []
      setCleanupSuggestions(list)
      setCleanupSelected(
        new Set(
          list
            .filter((s: { precheck?: boolean }) => s.precheck === true)
            .map((s: { thread_id: string }) => s.thread_id),
        ),
      )
      setCleanupOpen(true)
    }
    window.addEventListener("cmspark:cleanup_suggestions", onSug as EventListener)
    return () =>
      window.removeEventListener("cmspark:cleanup_suggestions", onSug as EventListener)
  }, [])

  /** Position ⋯ menu for body portal (A-4 / GAP-14); clamp to viewport bottom. */
  useEffect(() => {
    if (!menuOpen) {
      setMenuPos(null)
      return
    }
    const MENU_EST_H = 280 // ~7 items
    const update = () => {
      const el = menuBtnRef.current
      if (!el) return
      const r = el.getBoundingClientRect()
      let top = r.bottom + 4
      if (top + MENU_EST_H > window.innerHeight - 8) {
        // Flip above the button when near bottom
        top = Math.max(8, r.top - MENU_EST_H - 4)
      }
      setMenuPos({
        top,
        right: Math.max(8, window.innerWidth - r.right),
      })
    }
    update()
    window.addEventListener("resize", update)
    window.addEventListener("scroll", update, true)
    return () => {
      window.removeEventListener("resize", update)
      window.removeEventListener("scroll", update, true)
    }
  }, [menuOpen])

  const scheduleProgressClear = useCallback(() => {
    if (extractProgressClearTimerRef.current) {
      clearTimeout(extractProgressClearTimerRef.current)
      extractProgressClearTimerRef.current = null
    }
    extractProgressClearTimerRef.current = setTimeout(() => {
      extractProgressClearTimerRef.current = null
      setExtractProgress(null)
    }, 1600)
  }, [])

  /** A-7 / S5: advance progress when thread digests change (digest_updated → UPSERT). */
  useEffect(() => {
    const batch = extractBatchRef.current
    if (!batch || batch.remaining.size === 0) return
    let changed = false
    for (const id of [...batch.remaining]) {
      const t = threads.find((x) => x.id === id) as Thread | undefined
      if (!t) {
        batch.remaining.delete(id)
        changed = true
        continue
      }
      const mark =
        (t.digest?.extracted_at || "") +
        "|" +
        (t.digest?.content_fingerprint || "") +
        "|" +
        (t.digest?.tags || []).join(",")
      const start = batch.startMark.get(id) || ""
      // Only mark done when digest fingerprint actually changed (not mere hasTags).
      if (mark !== start && (t.digest?.extracted_at || t.digest?.tags)) {
        batch.remaining.delete(id)
        changed = true
      }
    }
    if (!changed) return
    setExtractingIds(new Set(batch.remaining))
    const done = batch.total - batch.remaining.size
    setExtractProgress({ done, total: batch.total })
    if (batch.remaining.size === 0) {
      extractBatchRef.current = null
      scheduleProgressClear()
    }
  }, [threads, scheduleProgressClear])

  /** Clear remaining spinners when companion reports batch complete (ok + failed). */
  useEffect(() => {
    const onDone = (e: Event) => {
      const detail = (e as CustomEvent).detail as {
        ok?: string[]
        failed?: Array<{ id?: string } | string>
        batch_id?: string
      } | null
      const batch = extractBatchRef.current
      if (!batch) return
      // Ignore completions that belong to a superseded batch (no shared remaining mutation).
      if (
        detail?.batch_id != null &&
        detail.batch_id !== "" &&
        detail.batch_id !== String(batch.batchId)
      ) {
        return
      }
      // If another batch already replaced us, drop this late event.
      if (extractBatchRef.current !== batch) return

      const doneIds = new Set<string>()
      for (const id of detail?.ok || []) if (typeof id === "string") doneIds.add(id)
      for (const f of detail?.failed || []) {
        if (typeof f === "string") doneIds.add(f)
        else if (f && typeof f.id === "string") doneIds.add(f.id)
      }
      // Charge daily quota only for successful ok[] (Wave B nit — not at send time).
      if (batch.countTowardQuota && Array.isArray(detail?.ok) && detail!.ok!.length > 0) {
        const charge = detail!.ok!.filter((id) => typeof id === "string").length
        if (charge > 0) {
          try {
            const day = digestQuotaDayKey(new Date())
            const prev = parseDigestQuota(localStorage.getItem(LS_DIGEST_QUOTA), new Date())
            const count = (prev.day === day ? prev.count : 0) + charge
            localStorage.setItem(LS_DIGEST_QUOTA, JSON.stringify({ day, count }))
          } catch {
            /* ignore quota */
          }
        }
        batch.countTowardQuota = false // once per batch completion
      }
      if (doneIds.size === 0) {
        // Completed without lists — clear whole tracked batch
        batch.remaining.clear()
      } else {
        for (const id of doneIds) batch.remaining.delete(id)
      }
      if (extractBatchRef.current !== batch) return
      setExtractingIds(new Set(batch.remaining))
      setExtractProgress({
        done: batch.total - batch.remaining.size,
        total: batch.total,
      })
      if (batch.remaining.size === 0) {
        if (extractBatchRef.current === batch) extractBatchRef.current = null
        scheduleProgressClear()
      }
    }
    window.addEventListener("cmspark:extract_digest_completed", onDone as EventListener)
    return () =>
      window.removeEventListener(
        "cmspark:extract_digest_completed",
        onDone as EventListener,
      )
  }, [scheduleProgressClear])

  const filtered = useMemo(() => {
    const base = (threads as Thread[]).filter((t) =>
      trashView ? !!t.trashed_at : !t.trashed_at,
    )
    return filterThreadsByQuery(base, query)
  }, [threads, query, trashView])

  const aliasDupCount = useMemo(() => countAliases(filtered as Thread[]), [filtered])

  const timeline = useMemo(
    () => groupThreadsByCalendar(filtered as Thread[], now),
    [filtered, now],
  )

  const tagIndex = useMemo(() => buildTagIndex(filtered as Thread[]), [filtered])

  const tagKeys = useMemo(() => {
    return [...tagIndex.keys()]
      .filter((k) => k !== "__untagged__")
      .sort((a, b) => {
        const ca = tagIndex.get(a)?.length || 0
        const cb = tagIndex.get(b)?.length || 0
        return cb - ca || a.localeCompare(b)
      })
  }, [tagIndex])

  const tagCloudCollapsed = useMemo(
    () => collapseTagKeys(tagKeys, tagCloudExpanded, TAG_CLOUD_MAX_VISIBLE),
    [tagKeys, tagCloudExpanded],
  )

  /** A-1/A-2: untagged batch targets (≤20, skip busy+worker, force empty-tags). Trash: no extract. */
  const untaggedExtract = useMemo(() => {
    if (trashView) return { ids: [] as string[], force: false }
    return selectUntaggedForExtract(filtered as Thread[], {
      max: EXTRACT_DIGEST_MAX,
      busyIds: threadBusyById,
      excludeWorkers: true,
    })
  }, [filtered, threadBusyById, trashView])

  /** Wave C-2: related hits — local instant, optional companion refine. */
  const relatedHitsLocal = useMemo(() => {
    if (!relatedSeedId) return []
    return findRelatedThreads(relatedSeedId, filtered as Thread[], 3)
  }, [relatedSeedId, filtered])

  const relatedHits = useMemo(() => {
    if (!relatedSeedId) return []
    if (relatedFromServer && relatedFromServer.length > 0) {
      return relatedFromServer.slice(0, 3).map((h) => ({
        thread_id: h.thread_id,
        score: h.score,
        signals: { co_tag: 0, tf: 0, time: 0 },
        shared_tags: h.shared_tags || [],
      }))
    }
    return relatedHitsLocal
  }, [relatedSeedId, relatedFromServer, relatedHitsLocal])

  // Request companion related when seed changes (background bridge + local fallback).
  useEffect(() => {
    if (!relatedSeedId) {
      setRelatedFromServer(null)
      return
    }
    setRelatedFromServer(null)
    chrome.runtime.sendMessage({
      type: "thread.related",
      thread_id: relatedSeedId,
      limit: 3,
    })
    const onRel = (e: Event) => {
      const d = (e as CustomEvent).detail as {
        thread_id?: string
        related?: Array<{ thread_id: string; score: number; shared_tags?: string[] }>
      }
      if (d?.thread_id !== relatedSeedId) return
      if (Array.isArray(d.related)) setRelatedFromServer(d.related)
    }
    window.addEventListener("cmspark:thread_related", onRel as EventListener)
    return () => window.removeEventListener("cmspark:thread_related", onRel as EventListener)
  }, [relatedSeedId])

  /** Open Obsidian-style full-page graph (TG-1/TG-4 — replaces side-panel edge list). */
  const openThreadGraph = useCallback(() => {
    const slim: ThreadGraphSlim[] = (threads as Thread[]).map((t) => ({
      id: t.id,
      alias: t.alias,
      updated_at: t.updated_at,
      created_at: t.created_at,
      last_message_at: t.last_message_at ?? null,
      agent_role: t.agent_role,
      trashed_at: t.trashed_at ?? null,
      user_tags: t.user_tags,
      digest: t.digest
        ? {
            tldr: t.digest?.tldr || "",
            tags: t.digest.tags,
            bullets: t.digest?.bullets || [],
            stale: t.digest?.stale,
          }
        : null,
    }))
    chrome.runtime.sendMessage(
      {
        type: "thread_graph.open",
        threads: slim,
        focus_id: relatedSeedId || activeThreadId || null,
      },
      () => {
        void chrome.runtime.lastError
      },
    )
    setMenuOpen(false)
    setOpen(false)
  }, [threads, relatedSeedId, activeThreadId])

  /** Wave C-4: lint stats for cleanup helper. */
  const lintStats = useMemo(
    () => digestLintStats(filtered as Thread[]),
    [filtered],
  )

  const selectableIds = useMemo(() => {
    const s = new Set<string>()
    const visible = view === "tags" && activeTag !== null ? tagIndex.get(activeTag) || [] : filtered
    for (const t of visible) {
      if (!threadBusyById[t.id]) s.add(t.id)
    }
    return s
  }, [filtered, threadBusyById, view, activeTag, tagIndex])
  useEffect(() => {
    setSelected(previous => {
      const next = new Set([...previous].filter(id => selectableIds.has(id)))
      return next.size === previous.size ? previous : next
    })
  }, [selectableIds])
  useEffect(() => { setPendingDelete(null) }, [view, activeTag, query, trashView])

  const cleanupSelectableIds = useMemo(() => new Set(cleanupSuggestions
    .map(s => s.thread_id)
    .filter(id => threads.some(t => t.id === id && !t.trashed_at) && !threadBusyById[id])), [cleanupSuggestions, threads, threadBusyById])
  useEffect(() => {
    setCleanupSelected(previous => {
      const next = new Set([...previous].filter(id => cleanupSelectableIds.has(id)))
      return next.size === previous.size ? previous : next
    })
  }, [cleanupSelectableIds])

  const searchActive = query.trim().length > 0

  const toggleMonth = (monthKey: string) => {
    setExpandState((prev) => {
      const months = prev.months.includes(monthKey)
        ? prev.months.filter((k) => k !== monthKey)
        : [...prev.months, monthKey]
      const next = { ...prev, months }
      saveExpandState(next)
      return next
    })
  }

  const togglePinned = (key: "today" | "yesterday") => {
    setExpandState((prev) => {
      const next = { ...prev, [key]: !prev[key] }
      saveExpandState(next)
      return next
    })
  }

  const toggleDay = (dayKey: string) => {
    setExpandedDays((prev) => {
      const next = new Set(prev)
      if (next.has(dayKey)) next.delete(dayKey)
      else next.add(dayKey)
      return next
    })
  }

  const exitSelectMode = useCallback(() => {
    setSelectMode(false)
    setSelected(new Set())
  }, [])

  /** Copy thread id (without #) for search / support; show brief “已复制” only on success. */
  const copyThreadId = useCallback(async (threadId: string) => {
    const text = String(threadId || "").trim()
    if (!text) return
    let ok = false
    try {
      await navigator.clipboard.writeText(text)
      ok = true
    } catch {
      try {
        const ta = document.createElement("textarea")
        ta.value = text
        ta.style.position = "fixed"
        ta.style.left = "-9999px"
        document.body.appendChild(ta)
        ta.select()
        ok = document.execCommand("copy")
        document.body.removeChild(ta)
      } catch {
        ok = false
      }
    }
    if (!ok) return
    setCopiedId(threadId)
    if (copyIdTimerRef.current) clearTimeout(copyIdTimerRef.current)
    copyIdTimerRef.current = setTimeout(() => {
      setCopiedId((cur) => (cur === threadId ? null : cur))
      copyIdTimerRef.current = null
    }, 1200)
  }, [])

  const handleNewThread = () => {
    createBlankThread(dispatch)
    setOpen(false)
    exitSelectMode()
  }

  const handleCleanupEmpty = () => {
    if (mutationRef.current) return
    const ids = threads.filter(t => t.message_count === 0 && t.id !== activeThreadId && !t.trashed_at && !threadBusyById[t.id]).map(t => t.id)
    setMenuOpen(false)
    if (!ids.length) { setMutationNotice("没有可清理的空白对话；可刷新列表后再次检查。"); return }
    setPendingDelete({ ids, hard: true, source: "empty" })
  }

  const handleGenerateTitle = () => {
    const targetThreadId = activeThreadId || threads[0]?.id
    if (!targetThreadId) {
      alert("暂无线程可生成标题")
      return
    }
    chrome.runtime.sendMessage({ type: "thread.generate_title", thread_id: targetThreadId })
    setMenuOpen(false)
  }

  const handleBatchAutoTitle = (ids?: string[]) => {
    const payload: Record<string, unknown> = {
      type: "thread.batch_auto_title",
      only_empty: true,
    }
    if (ids && ids.length > 0) payload.thread_ids = ids
    chrome.runtime.sendMessage(payload)
    setMenuOpen(false)
  }

  const beginExtractBatch = useCallback(
    (ids: string[], force: boolean, opts?: { countTowardQuota?: boolean }) => {
      const capped = ids.slice(0, EXTRACT_DIGEST_MAX)
      if (capped.length === 0) return
      // Serialize: refuse starting a second batch while one is in flight (A dual-review nit).
      if (extractBatchRef.current && extractBatchRef.current.remaining.size > 0) {
        // In-flight batch already shows N/M progress bar; ignore overlapping click.
        return
      }
      if (extractProgressClearTimerRef.current) {
        clearTimeout(extractProgressClearTimerRef.current)
        extractProgressClearTimerRef.current = null
      }
      const startMark = new Map<string, string>()
      for (const id of capped) {
        const t = threads.find((x) => x.id === id) as Thread | undefined
        const mark =
          (t?.digest?.extracted_at || "") +
          "|" +
          (t?.digest?.content_fingerprint || "") +
          "|" +
          (t?.digest?.tags || []).join(",")
        startMark.set(id, mark)
      }
      const batchId = ++extractBatchSeqRef.current
      extractBatchRef.current = {
        batchId,
        remaining: new Set(capped),
        total: capped.length,
        startMark,
        // Quota charged on extract_digest.completed ok[] only (not at send).
        countTowardQuota: opts?.countTowardQuota === true,
      }
      setExtractingIds(new Set(capped))
      setExtractProgress({ done: 0, total: capped.length })
      chrome.runtime.sendMessage({
        type: "thread.extract_digest",
        thread_ids: capped,
        force: force === true,
        batch_id: String(batchId),
      })
      // No fixed 60s full clear (S5/GAP-15) — progress from digest UPSERT / completed.
    },
    [threads],
  )

  // Wave B-2: when list opens and settings enable lazy digest, fill coverage once.
  useEffect(() => {
    if (!open) {
      lazyDigestRanRef.current = false
      return
    }
    if (lazyDigestRanRef.current || trashView) return
    if (config?.thread_digest_enabled !== true) return
    if (extractBatchRef.current) return
    const maxPerDay = config.thread_digest_max_per_day ?? 20
    const idleH = config.thread_digest_on_idle_hours ?? 24
    let quota = { day: digestQuotaDayKey(now), count: 0 }
    try {
      quota = parseDigestQuota(localStorage.getItem(LS_DIGEST_QUOTA), now)
    } catch {
      /* ignore */
    }
    const remain = remainingDigestQuota(quota, maxPerDay)
    if (remain <= 0) return
    const live = (threads as Thread[]).filter((t) => !t.trashed_at)
    const sel = selectLazyDigestCandidates(live, {
      now,
      onIdleHours: idleH,
      max: Math.min(EXTRACT_DIGEST_MAX, remain),
      busyIds: threadBusyById,
      excludeWorkers: true,
    })
    if (sel.ids.length === 0) return
    lazyDigestRanRef.current = true
    beginExtractBatch(sel.ids, sel.force, { countTowardQuota: true })
  }, [
    open,
    trashView,
    config?.thread_digest_enabled,
    config?.thread_digest_max_per_day,
    config?.thread_digest_on_idle_hours,
    threads,
    threadBusyById,
    now,
    beginExtractBatch,
  ])

  const handleExtractDigest = (ids: string[]) => {
    if (ids.length === 0) return
    const capped = ids.slice(0, EXTRACT_DIGEST_MAX)
    const force = batchNeedsForceExtract(filtered as Thread[], capped)
    beginExtractBatch(capped, force)
  }

  /** A-1 menu / A-2 CTA: extract untagged (uses selection.force — S1). */
  const handleExtractUntagged = () => {
    if (untaggedExtract.ids.length === 0) return
    beginExtractBatch(untaggedExtract.ids, untaggedExtract.force)
    setMenuOpen(false)
  }

  const handleSelect = (threadId: string) => {
    if (selectMode) {
      if (threadBusyById[threadId]) return
      setSelected((prev) => {
        const next = new Set(prev)
        if (next.has(threadId)) next.delete(threadId)
        else next.add(threadId)
        return next
      })
      return
    }
    // Dual-review residual: do not activate soft-deleted threads into main chat
    if (trashView) return
    const thr = threads.find((t) => t.id === threadId)
    if (thr?.trashed_at) return
    dispatch({ type: "SET_ACTIVE_THREAD", threadId })
    chrome.runtime.sendMessage({ type: "thread.select", threadId })
    setOpen(false)
  }

  const handleDeleteOne = (threadId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (mutationRef.current) return
    if (threadBusyById[threadId]) {
      alert("该线程正在运行，无法删除")
      return
    }
    setPendingDelete({ ids: [threadId], hard: trashView, source: "row" })
  }

  const handleBatchDelete = () => {
    if (mutationRef.current) return
    const ids = [...selected].filter((id) => selectableIds.has(id))
    if (ids.length === 0) return
    setPendingDelete({ ids, hard: trashView, source: "batch" })
  }

  const runMutation = async (ids: string[], mode: "trash" | "hard" | "restore" | "empty", source: "row" | "batch" | "cleanup" | "empty") => {
    if (!ids.length || mutationRef.current) return
    const controller = new AbortController()
    mutationRef.current = controller
    setMutating(true)
    setMutationNotice(`正在${mode === "restore" ? "恢复" : "处理"} ${ids.length} 个对话，请等待服务端确认…`)
    setPendingDelete(null)
    try {
      const result = await mutateThreads(ids, mode, controller.signal)
      if (controller.signal.aborted) return
      if (mode !== "restore" && result.ok.length) dispatch({ type: "REMOVE_THREADS", threadIds: result.ok })
      if (mode === "restore") chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
      const failedIds = new Set(result.failed.map(item => item.id))
      const uncertain = result.failed.some(item => item.reason.startsWith("unknown"))
      const failures = result.failed.slice(0, 3).map(item => {
        const title = displayThreadTitle(threads.find(t => t.id === item.id) || { id: item.id })
        const reason = item.reason === "thread_busy" ? "运行中"
          : item.reason === "not_empty" ? "已有内容，已跳过"
          : item.reason === "not_sent_unsupported" ? "未发送，请更新 Companion 后重试"
          : item.reason.startsWith("not_sent") ? "未发送"
          : item.reason.startsWith("unknown") ? "结果未确认" : item.reason
        return `${title}：${reason}`
      }).join("；")
      setMutationNotice(`${mode === "restore" ? "已恢复" : mode === "hard" || mode === "empty" ? "已永久删除" : "已移入回收站"} ${result.ok.length} 个对话。${result.failed.length ? `另有 ${result.failed.length} 个未完成确认。${failures}${uncertain ? "；部分操作可能已完成，请刷新列表核对后重试。" : ""}` : ""}`)
      if (source === "batch") {
        setSelected(failedIds)
        setSelectMode(failedIds.size > 0)
      }
      if (source === "cleanup") {
        setCleanupSuggestions(previous => previous.filter(s => !result.ok.includes(s.thread_id)))
        setCleanupSelected(failedIds)
      }
    } catch (error) {
      if (!controller.signal.aborted) setMutationNotice(`未收到完整结果，部分操作可能已完成；请刷新列表核对。${error instanceof Error ? error.message : ""}`)
    } finally {
      if (mutationRef.current === controller) mutationRef.current = null
      if (!controller.signal.aborted) setMutating(false)
    }
  }

  const executePendingDelete = () => {
    if (!pendingDelete || mutationRef.current) return
    const { hard, source } = pendingDelete
    const ids = pendingDelete.ids.filter(id => {
      const thread = threads.find(t => t.id === id)
      return thread && !threadBusyById[id] && (source === "empty" ? !thread.trashed_at && thread.message_count === 0 && id !== activeThreadId : !!thread.trashed_at === hard)
    })
    if (ids.length !== pendingDelete.ids.length) {
      setPendingDelete(null)
      setMutationNotice("部分对话状态已变化，请重新核对选择后操作。")
      return
    }
    void runMutation(ids, source === "empty" ? "empty" : hard ? "hard" : "trash", source)
  }

  const handleSelectAllVisible = () => {
    const ids = selectAllIds(selectableIds)
    setSelectMode(true)
    setSelected(ids)
    const months = timeline.months.map((m) => m.monthKey)
    const days = new Set<string>()
    for (const m of timeline.months) {
      for (const d of m.days) days.add(d.dayKey)
    }
    const nextExpand = { months, today: true, yesterday: true }
    setExpandState(nextExpand)
    saveExpandState(nextExpand)
    setExpandedDays(days)
  }

  const handleClearVisibleSelection = () => {
    setSelected(new Set())
  }

  const handleRestore = (ids: string[]) => {
    const targets = ids.filter(id => selectableIds.has(id) && threads.some(t => t.id === id && t.trashed_at))
    void runMutation(targets, "restore", "batch")
  }

  const openTrashView = () => {
    setTrashView(true)
    setView("time")
    setMenuOpen(false)
    chrome.runtime.sendMessage({ type: "thread.list", include_trashed: true })
  }

  const closeTrashView = () => {
    setTrashView(false)
    chrome.runtime.sendMessage({ type: "thread.list" })
  }

  const runCleanupScan = () => {
    const payload: Record<string, unknown> = {
      type: "thread.suggest_cleanup",
      include_workers: false,
      except_thread_id: activeThreadId || undefined,
    }
    if (cleanupDays > 0) {
      const to = new Date()
      const from = new Date(to.getTime() - cleanupDays * 86400_000)
      payload.to = from.toISOString()
    }
    chrome.runtime.sendMessage(payload)
    setMenuOpen(false)
  }

  const applyCleanupTrash = () => {
    if (mutationRef.current) return
    const ids = [...cleanupSelected].filter(id => cleanupSelectableIds.has(id))
    if (!ids.length) return
    setPendingDelete({ ids, hard: false, source: "cleanup" })
  }

  /** B-4: extract digests for cleanup-selected threads only (no delete). */
  const applyCleanupExtractOnly = () => {
    const ids = [...cleanupSelected].slice(0, EXTRACT_DIGEST_MAX)
    if (ids.length === 0) return
    const force = batchNeedsForceExtract(filtered as Thread[], ids)
    beginExtractBatch(ids, force)
  }

  const panelMaxHeight = 480

  useEffect(() => {
    if (!open) {
      setPanelBox(null)
      return
    }
    const place = () => {
      const r = triggerRef.current?.getBoundingClientRect()
      const top = Math.round((r?.bottom ?? 48) + 6)
      setPanelBox({
        top,
        maxHeight: Math.max(0, Math.min(window.innerHeight - top - 12, (document.querySelector<HTMLElement>(".cm-composer-dock")?.getBoundingClientRect().top ?? window.innerHeight) - top - 8)),
      })
    }
    place()
    window.addEventListener("resize", place)
    const observer = new ResizeObserver(place)
    const dock = document.querySelector(".cm-composer-dock")
    const rail = document.querySelector(".cm-status-rail")
    if (dock) observer.observe(dock)
    if (rail) observer.observe(rail)
    return () => { window.removeEventListener("resize", place); observer.disconnect() }
  }, [open, selectMode, view])

  // Outside actions remain directly usable (not intercepted by a transparent backdrop).
  useEffect(() => {
    if (!open) return
    const outside = (event: MouseEvent) => {
      const target = event.target as Node
      if (!historyRef.current?.contains(target) && !triggerRef.current?.contains(target) && !historyMenuRef.current?.contains(target)) {
        setOpen(false); setMenuOpen(false); exitSelectMode()
      }
    }
    document.addEventListener("mousedown", outside)
    return () => document.removeEventListener("mousedown", outside)
  }, [open, exitSelectMode])

  // Nonmodal history popover: focus search, Escape dismisses and returns to trigger.
  // Its existing overflow menu uses a separate portal, so do not claim aria-modal.
  useEffect(() => {
    if (!open || !panelBox) return
    historyRef.current?.querySelector<HTMLInputElement>('input[type="search"]')?.focus()
    const key = (event: KeyboardEvent) => {
      if (event.key !== "Escape" || event.defaultPrevented) return
      if (!historyRef.current?.contains(event.target as Node) && event.target !== triggerRef.current && !historyMenuRef.current?.contains(event.target as Node)) return
      event.preventDefault()
      event.stopPropagation()
      if (menuOpenRef.current) { setMenuOpen(false); menuBtnRef.current?.focus(); return }
      setOpen(false); triggerRef.current?.focus()
    }
    document.addEventListener("keydown", key)
    return () => document.removeEventListener("keydown", key)
  }, [open, !!panelBox])

  const closeMetadataEditor = (threadId = editingThread?.id) => {
    setEditingThread(null)
    requestAnimationFrame(() => {
      const row = threadId ? historyRef.current?.querySelector(`[data-thread-id="${CSS.escape(threadId)}"]`) : null
      const target = row?.querySelector<HTMLElement>('button[title="编辑标签与分组"]') || historyRef.current?.querySelector<HTMLElement>('input[type="search"]')
      target?.focus()
    })
  }

  const renderThreadRow = (t: Thread) => {
    const busy = !!threadBusyById[t.id]
    const isActive = t.id === activeThreadId
    const badge = roleBadge(t.agent_role)
    const title = displayThreadTitle(t)
    const accessibleName = threadAccessibleName(t)
    const idBadge = formatThreadIdBadge(t.id)
    const rel = formatThreadListTime(t, now, aliasDupCount)
    const tags = threadTags(t)
    const extracting = extractingIds.has(t.id)
    const evidence = displayThreadEvidence(t)
    const chip = acpOutcomeChip(t)
    const justCopied = copiedId === t.id

    return (
      <div
        key={t.id}
        className={selectMode ? "cm-thread-row cm-thread-selecting" : "cm-thread-row"}
        data-thread-id={t.id}
        style={{
          ...styles.threadItem,
          background: isActive ? tokens.bgHover : "transparent",
          opacity: selectMode && busy ? 0.45 : 1,
        }}
        aria-label={accessibleName}
      >
        {selectMode && (
          <input
            type="checkbox"
            checked={selected.has(t.id)}
            disabled={busy}
            onChange={() => handleSelect(t.id)}
            onClick={(e) => e.stopPropagation()}
            title={busy ? "运行中，不可选" : undefined}
            style={styles.checkbox}
            aria-label={`选择 ${accessibleName}`}
          />
        )}
        <div className="cm-thread-row-content" style={{ flex: 1, minWidth: 0 }}>
          <div style={styles.threadAliasRow}>
            <button type="button" className="cm-thread-open" style={{ ...styles.threadAlias, border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "pointer", padding: "6px 0", minHeight: 32 }} disabled={trashView} aria-label={`${selectMode ? "选择" : trashView ? "已删除" : "打开"} ${accessibleName}`} onClick={e => { e.stopPropagation(); handleSelect(t.id) }}>{title}</button>
            {chip ? <span style={styles.badge}>{chip}</span> : null}
            {idBadge ? (
              <button
                type="button"
                style={{
                  ...styles.threadIdBadge,
                  color: justCopied ? tokens.accentText : tokens.textMuted,
                }}
                title={`复制编号 ${idBadge}（可在搜索框粘贴定位）`}
                aria-label={`复制会话编号 ${idBadge}`}
                onClick={(e) => {
                  e.stopPropagation()
                  void copyThreadId(t.id)
                }}
              >
                {justCopied ? "已复制" : idBadge}
              </button>
            ) : null}
            {badge && <span style={styles.badge}>{badge}</span>}
            {extracting && <span style={styles.badgeMuted}>抽取中</span>}
            {showDigestStaleBadge(t, view, now) && (
              <span style={styles.badgeMuted} title="要点可能过期">
                过期
              </span>
            )}
          </div>
          {evidence && (
            <div style={styles.tldr} title={evidence}>
              {evidence}
            </div>
          )}
          {tags.length > 0 && (
            <div style={styles.tagRow}>
              {tags.slice(0, 4).map((tag) => (
                <button
                  key={tag}
                  type="button"
                  style={styles.tagPill}
                  onClick={(e) => {
                    e.stopPropagation()
                    setView("tags")
                    setActiveTag(tag)
                  }}
                >
                  #{tag} <span className="cm-thread-tag-origin">{(t.user_tags || []).some(value => value.toLowerCase() === tag) ? "人工" : "AI"}</span>
                </button>
              ))}
            </div>
          )}
          {rel && <div style={styles.relTime}>{rel}</div>}
          {t.topic_folder ? (
            <div style={styles.relTime} title="话题夹">
              分组 · {t.topic_folder}
            </div>
          ) : null}
        </div>
        {!selectMode && (
          <>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                setRelatedSeedId((prev) => (prev === t.id ? null : t.id))
              }}
              title="列表内相关"
            >
              相关
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                handleExtractDigest([t.id])
              }}
              title="提取要点 / 标签"
            >
              AI 标签
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                setOpen(false)
                chrome.runtime.sendMessage({ type: "thread.distill_preview", thread_id: t.id })
              }}
              title="提炼为知识（需确认）"
            >
              知识
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                setEditingThread(t)
                setMetadataNotice("")
              }}
              title="编辑标签与分组"
            >
              分类
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => {
                e.stopPropagation()
                dispatch({ type: "SET_SUMMARIZING_THREAD", threadId: t.id })
                chrome.runtime.sendMessage({
                  type: "thread.export_obsidian",
                  thread_id: t.id,
                  scope: "summary",
                  // Wave D/E: honor Settings exportIncludeReasoning (P0-2)
                  include_reasoning: state.exportIncludeReasoning === true,
                })
              }}
              disabled={state.summarizingThreadId === t.id}
              title="导出此线程摘要为 Markdown"
            >
              {state.summarizingThreadId === t.id ? "导出中" : "导出"}
            </button>
            <button
              type="button"
              style={styles.iconBtn}
              onClick={(e) => handleDeleteOne(t.id, e)}
              disabled={mutating || busy}
              title="删除线程"
              aria-label={`删除 ${accessibleName}`}
            >
              删除
            </button>
          </>
        )}
      </div>
    )
  }

  const renderGroupCheckbox = (ids: string[], label: string) => {
    if (!selectMode) return null
    const eligible = ids.filter((id) => selectableIds.has(id))
    const st = selectionState(eligible, selected)
    return (
      <input
        type="checkbox"
        checked={st === "all" && eligible.length > 0}
        ref={(el) => {
          if (el) el.indeterminate = st === "some"
        }}
        disabled={eligible.length === 0}
        onChange={() => {
          setSelected((prev) => toggleGroupSelection(ids, prev, selectableIds))
        }}
        onClick={(e) => e.stopPropagation()}
        aria-label={`选择 ${label}`}
        style={styles.checkbox}
      />
    )
  }

  const renderMonth = (month: MonthGroup) => {
    const openMonth = isMonthGroupOpen(month.monthKey, expandState, {
      searchActive,
      hasMatches: searchActive && month.count > 0,
    })
    const ids = threadIdsInMonth(month)
    return (
      <div key={month.monthKey}>
        <div style={styles.groupHeader}>
          {renderGroupCheckbox(ids, month.label)}
          <button type="button" className="cm-history-group" aria-expanded={openMonth} onClick={() => toggleMonth(month.monthKey)}><span aria-hidden="true" style={styles.groupChevron}>{openMonth ? "▼" : "▶"}</span> {month.label} · {month.count}</button>
        </div>
        {openMonth && month.days.map((day) => renderDay(day))}
      </div>
    )
  }

  const renderDay = (day: DayGroup) => {
    // Search: force-open days that still have matches (parity with month groups).
    const openDay =
      expandedDays.has(day.dayKey) || (searchActive && day.threads.length > 0)
    const ids = threadIdsInDay(day)
    return (
      <div key={day.dayKey}>
        <div
          style={{ ...styles.groupHeader, paddingLeft: 20 }}
        >
          {renderGroupCheckbox(ids, day.label)}
          <button type="button" className="cm-history-group" aria-expanded={openDay} onClick={() => toggleDay(day.dayKey)}><span aria-hidden="true" style={styles.groupChevron}>{openDay ? "▼" : "▶"}</span> {day.label} · {day.threads.length}</button>
        </div>
        {openDay && day.threads.map((t) => renderThreadRow(t as Thread))}
      </div>
    )
  }

  const renderTimeline = () => {
    const todayOpen = isPinnedGroupOpen("today", expandState, {
      searchActive,
      hasMatches: searchActive && timeline.today.length > 0,
    })
    const yesterdayOpen = isPinnedGroupOpen("yesterday", expandState, {
      searchActive,
      hasMatches: searchActive && timeline.yesterday.length > 0,
    })
    return (
      <>
        {timeline.today.length > 0 && (
          <div>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(
                timeline.today.map((t) => t.id),
                "今天",
              )}
              <button type="button" className="cm-history-group" aria-expanded={todayOpen} onClick={() => togglePinned("today")}><span aria-hidden="true" style={styles.groupChevron}>{todayOpen ? "▼" : "▶"}</span> 今天 · {timeline.today.length}</button>
            </div>
            {todayOpen && timeline.today.map((t) => renderThreadRow(t as Thread))}
          </div>
        )}

        {timeline.yesterday.length > 0 && (
          <div>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(
                timeline.yesterday.map((t) => t.id),
                "昨天",
              )}
              <button type="button" className="cm-history-group" aria-expanded={yesterdayOpen} onClick={() => togglePinned("yesterday")}><span aria-hidden="true" style={styles.groupChevron}>{yesterdayOpen ? "▼" : "▶"}</span> 昨天 · {timeline.yesterday.length}</button>
            </div>
            {yesterdayOpen && timeline.yesterday.map((t) => renderThreadRow(t as Thread))}
          </div>
        )}

        {timeline.months.map(renderMonth)}

        {filtered.length === 0 && (
          <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
            {threads.length === 0 ? "暂无线程，可从导航创建新对话" : "无匹配线程"}
          </div>
        )}
      </>
    )
  }

  const renderTagsView = () => {
    const untagged = tagIndex.get("__untagged__") || []
    const listForTag =
      activeTag === null
        ? filtered
        : activeTag === "__untagged__"
          ? untagged
          : tagIndex.get(activeTag) || []
    const extractDisabled = untaggedExtract.ids.length === 0
    const extractLabel = `为未标注提取要点（最多${EXTRACT_DIGEST_MAX}）`
    // Primary CTA only when extractable targets exist (no dead disabled empty-library CTA).
    const showPrimaryCta = untaggedExtract.ids.length > 0

    return (
      <div>
        {/* A-5: count-fold only; 更多/收起 OUTSIDE pills so they are never clipped (Pi blocking). */}
        <div style={styles.tagCloudSection}>
          <div style={styles.tagCloud}>
            {tagKeys.length === 0 && untagged.length === 0 && (
              <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 8 }}>
                暂无标签。使用下方按钮为会话提取要点与标签。
              </div>
            )}
            {tagCloudCollapsed.visible.map((tag) => {
              const n = tagIndex.get(tag)?.length || 0
              const active = activeTag === tag
              return (
                <button
                  key={tag}
                  type="button"
                  style={active ? styles.tagPillActive : styles.tagPill}
                  onClick={() => setActiveTag(active ? null : tag)}
                >
                  #{tag} {n}
                </button>
              )
            })}
            {untagged.length > 0 && (
              <button
                type="button"
                style={
                  activeTag === "__untagged__" ? styles.tagPillActive : styles.tagPill
                }
                onClick={() =>
                  setActiveTag(activeTag === "__untagged__" ? null : "__untagged__")
                }
              >
                #未标注 {untagged.length}
              </button>
            )}
          </div>
          {tagCloudCollapsed.hiddenCount > 0 && !tagCloudExpanded && (
            <div style={styles.tagCloudFoldRow}>
              <button
                type="button"
                style={styles.tagPill}
                onClick={() => setTagCloudExpanded(true)}
                title={`还有 ${tagCloudCollapsed.hiddenCount} 个标签`}
              >
                更多 · {tagCloudCollapsed.hiddenCount}
              </button>
            </div>
          )}
          {tagCloudExpanded && tagKeys.length > TAG_CLOUD_MAX_VISIBLE && (
            <div style={styles.tagCloudFoldRow}>
              <button
                type="button"
                style={styles.tagPill}
                onClick={() => setTagCloudExpanded(false)}
              >
                收起
              </button>
            </div>
          )}
        </div>

        {showPrimaryCta && untaggedExtract.ids.length > 0 && (
          <div style={styles.untaggedCtaRow}>
            <button
              type="button"
              style={{
                ...styles.primaryCta,
                opacity: extractDisabled ? 0.45 : 1,
                cursor: extractDisabled ? "not-allowed" : "pointer",
              }}
              disabled={extractDisabled}
              onClick={handleExtractUntagged}
              title={
                extractDisabled
                  ? "没有可提取的未标注会话（已跳过运行中与 worker）"
                  : `将提取最多 ${untaggedExtract.ids.length} 个未标注会话`
              }
            >
              🏷 {extractLabel}
            </button>
            {!extractDisabled && (
              <span style={styles.ctaHint}>
                本批 {untaggedExtract.ids.length} 个
                {untagged.length > untaggedExtract.ids.length
                  ? `（共 ${untagged.length} 未标注）`
                  : ""}
              </span>
            )}
          </div>
        )}

        {listForTag && (
          <div>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(listForTag.map((t) => t.id), activeTag === null ? "全部对话" : activeTag === "__untagged__" ? "未标注" : `#${activeTag}`)}
              <span style={styles.groupLabel}>
                {activeTag === null ? "全部对话" : activeTag === "__untagged__" ? "未标注" : `#${activeTag}`} ·{" "}
                {listForTag.length}
              </span>
            </div>
            {listForTag.map((t) => renderThreadRow(t as Thread))}
          </div>
        )}
        {!listForTag && tagKeys.length > 0 && (
          <div style={{ color: tokens.textMuted, fontSize: 12, padding: 10 }}>
            选择上方标签查看会话
          </div>
        )}
      </div>
    )
  }

  const renderTopicsView = (ai = false) => {
    const groups = new Map<string, Thread[]>()
    for (const t of filtered as Thread[]) {
      const key = ai ? aiThreadGroup(t) || "待 AI 整理" : t.topic_folder || "未分组"
      const arr = groups.get(key) || []
      arr.push(t)
      groups.set(key, arr)
    }
    const keys = [...groups.keys()].sort((a, b) => {
      const ungrouped = ai ? "待 AI 整理" : "未分组"
      if (a === ungrouped) return 1
      if (b === ungrouped) return -1
      return a.localeCompare(b, "zh")
    })
    return (
      <>
        {keys.map((key) => (
          <div key={key}>
            <div style={styles.groupHeader}>
              {renderGroupCheckbox(groups.get(key)!.map((t) => t.id), key)}
              <span style={styles.groupLabel}>
                {key} · {groups.get(key)!.length}
              </span>
            </div>
            {groups.get(key)!.map((t) => renderThreadRow(t))}
          </div>
        ))}
        {keys.length === 1 && keys[0] === "未分组" && filtered.length > 0 && (
          <div style={{ color: tokens.textMuted, fontSize: 11, padding: "8px 12px" }}>
            点对话右侧「分类」编辑标签、选择或新建分组
          </div>
        )}
        {filtered.length === 0 && (
          <div style={{ color: tokens.textSecondary, fontSize: 12, padding: 12, textAlign: "center" }}>
            无匹配线程
          </div>
        )}
      </>
    )
  }

  return (
    <div style={{ position: "relative" }}>
      <button
        ref={triggerRef}
        type="button"
        className="cm-thread-manager-trigger"
        style={{
          ...styles.hamburger,
          ...(open ? { color: tokens.text } : null),
        }}
        disabled={state.pendingSecurityConfirmations.length > 0}
        onClick={() => setOpen(!open)}
        title="对话管理：历史、标签、分组与图谱"
        aria-label="对话管理（历史对话）"
        aria-expanded={open}
      >
        <IconHistory size={17} /><span>对话管理</span>
      </button>

      {open && !state.pendingSecurityConfirmations.length &&
        panelBox &&
        typeof document !== "undefined" &&
        createPortal(
        <>
          <div
            ref={historyRef} className="cm-history-panel" role="dialog" aria-label="历史对话列表" aria-modal="false"
            style={{
              ...styles.panel,
              position: "fixed",
              top: panelBox.top,
              left: 8,
              right: 8,
              width: "auto",
              maxHeight: Math.min(panelMaxHeight, panelBox.maxHeight),
              zIndex: 10050,
            }}
          >
            <div className="cm-thread-management-title" style={{ display: "flex", alignItems: "center", padding: "8px 12px", borderBottom: `1px solid ${tokens.border}` }}><strong style={{ flex: 1, fontSize: 14 }}>对话管理</strong><button type="button" className="cm-icon-button" aria-label="关闭历史对话" onClick={() => { setOpen(false); triggerRef.current?.focus() }}>×</button></div>
            <div className="cm-thread-management-header" style={styles.panelHeader}>
              <div className="cm-thread-management-views" style={styles.viewToggle}>
                <button
                  type="button"
                  aria-pressed={view === "time"}
                  style={view === "time" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("time")}
                >
                  时间
                </button>
                <button
                  type="button"
                  aria-pressed={view === "tags"}
                  style={view === "tags" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("tags")}
                >
                  标签
                </button>
                <button
                  type="button"
                  aria-pressed={view === "topics"}
                  style={view === "topics" ? styles.viewBtnActive : styles.viewBtn}
                  onClick={() => setView("topics")}
                >
                  手动分组
                </button>
                <button type="button" aria-pressed={view === "ai"} style={view === "ai" ? styles.viewBtnActive : styles.viewBtn} onClick={() => setView("ai")}>AI 分组</button>
              </div>
              <div style={{ display: "flex", gap: 6, flexShrink: 0, alignItems: "center" }}>
                <button
                  type="button"
                  style={selectMode ? styles.selectBtnActive : styles.selectBtn}
                  onClick={() => {
                    if (selectMode) exitSelectMode()
                    else {
                      setSelectMode(true)
                      setSelected(new Set())
                    }
                  }}
                  title="多选"
                >
                  {selectMode ? "取消选择" : "选择"}
                </button>
                <button
                  type="button"
                  style={styles.selectBtn}
                  disabled={selectableIds.size === 0}
                  onClick={() =>
                    allSelectableSelected(selected, selectableIds)
                      ? handleClearVisibleSelection()
                      : handleSelectAllVisible()
                  }
                  title="全选当前列表中可删除的会话"
                >
                  {allSelectableSelected(selected, selectableIds) ? "取消全选" : "全选"}
                </button>
                <button style={styles.newBtn} onClick={handleNewThread} title="新建线程">
                  + 新建
                </button>
                <div style={{ position: "relative" }}>
                  <button
                    ref={menuBtnRef}
                    type="button"
                    style={styles.menuBtn}
                    onClick={() => setMenuOpen((v) => !v)}
                    title="更多"
                    aria-haspopup="menu"
                    aria-expanded={menuOpen}
                  >
                    ⋯
                  </button>
                  {menuOpen &&
                    menuPos &&
                    typeof document !== "undefined" &&
                    createPortal(
                      <div
                        style={{
                          ...styles.menuPortal,
                          top: menuPos.top,
                          right: menuPos.right,
                          maxHeight: Math.max(0, panelBox.top + panelBox.maxHeight - menuPos.top),
                          overflowY: "auto",
                        }}
                        ref={historyMenuRef} role="menu"
                      >
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={handleGenerateTitle}
                        >
                          ✨ AI 生成标题
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() => handleBatchAutoTitle()}
                        >
                          📝 未命名→首条起名
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={handleCleanupEmpty}
                        >
                          🧹 清理空白
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() => {
                            setCleanupOpen(true)
                            setMenuOpen(false)
                            runCleanupScan()
                          }}
                        >
                          🗂 整理助手
                        </button>
                        <button
                          type="button"
                          style={{
                            ...styles.menuItem,
                            opacity: untaggedExtract.ids.length === 0 ? 0.45 : 1,
                            cursor:
                              untaggedExtract.ids.length === 0
                                ? "not-allowed"
                                : "pointer",
                          }}
                          disabled={untaggedExtract.ids.length === 0}
                          onClick={handleExtractUntagged}
                          title={
                            untaggedExtract.ids.length === 0
                              ? "没有可提取的未标注会话"
                              : `为最多 ${untaggedExtract.ids.length} 个未标注会话提取要点`
                          }
                        >
                          🏷 为未标注提取要点
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={openThreadGraph}
                          title="在新标签页打开会话关系图"
                        >
                          会话关系图
                        </button>
                        <button
                          type="button"
                          style={styles.menuItem}
                          onClick={() =>
                            trashView ? closeTrashView() : openTrashView()
                          }
                        >
                          {trashView ? "← 返回列表" : "🗑 回收站"}
                        </button>
                      </div>,
                      document.body,
                    )}
                </div>
              </div>
            </div>

            <div className="cm-thread-management-actions" aria-label="对话整理工具">
              <button type="button" onClick={handleExtractUntagged} disabled={untaggedExtract.ids.length === 0 || !!extractProgress}>AI 提取标签</button>
              <button type="button" onClick={() => { setCleanupOpen(true); runCleanupScan() }}>整理助手</button>
              <button type="button" onClick={openThreadGraph}>关系图谱</button>
              <button type="button" onClick={() => trashView ? closeTrashView() : openTrashView()}>{trashView ? "返回对话" : "回收站"}</button>
            </div>
            {cleanupOpen && (
                <div className="cm-thread-cleanup" style={styles.cleanupPanel} role="region" aria-label="整理建议">
                <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 8 }}>整理助手（规则）</div>
                <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 11, color: tokens.textSecondary }}>扫描</span>
                  <select
                    value={cleanupDays}
                    onChange={(e) => setCleanupDays(Number(e.target.value))}
                    style={{ fontSize: 11, padding: "2px 4px" }}
                  >
                    <option value={0}>全部（含近期）</option>
                    <option value={30}>30 天前以前</option>
                    <option value={90}>90 天前以前</option>
                  </select>
                  <button type="button" style={styles.selectBtn} onClick={runCleanupScan}>
                    扫描
                  </button>
                  <button
                    type="button"
                    style={styles.selectBtn}
                    onClick={() => {
                      setCleanupOpen(false)
                      setCleanupSuggestions([])
                    }}
                  >
                    关闭
                  </button>
                </div>
                <div
                  style={{
                    fontSize: 10,
                    color: tokens.textMuted,
                    marginBottom: 6,
                  }}
                >
                  索引健康：未标注 {lintStats.untagged} · 过期 {lintStats.stale} · 孤立{" "}
                  {lintStats.isolated}
                </div>
                {cleanupSuggestions.length === 0 ? (
                  <div style={{ fontSize: 11, color: tokens.textMuted }}>
                    空会话 / 无用户消息 / 极短孤消息 / 过久且少 / 同名薄会话（不含簇主）
                  </div>
                ) : (
                  <>
                    <div style={{ maxHeight: 160, overflowY: "auto" }}>
                      {cleanupSuggestions.map((s) => {
                        const thr = threads.find((t) => t.id === s.thread_id)
                        const title = thr
                          ? displayThreadTitle(thr as Thread)
                          : s.thread_id
                        return (
                          <label
                            key={`${s.thread_id}-${s.reason}`}
                            style={{
                              display: "flex",
                              gap: 6,
                              alignItems: "flex-start",
                              fontSize: 11,
                              padding: "4px 0",
                              borderBottom: `1px solid ${tokens.border}`,
                            }}
                          >
                            <input
                              type="checkbox"
                              checked={cleanupSelected.has(s.thread_id)}
                              disabled={!cleanupSelectableIds.has(s.thread_id) || mutating}
                              onChange={() => {
                                setCleanupSelected((prev) => {
                                  const next = new Set(prev)
                                  if (next.has(s.thread_id)) next.delete(s.thread_id)
                                  else next.add(s.thread_id)
                                  return next
                                })
                              }}
                            />
                            <span>
                              <strong>{title}</strong>
                              <span style={{ color: tokens.textMuted }}>
                                {" "}
                                · {s.reason} · {s.detail}
                              </span>
                            </span>
                          </label>
                        )
                      })}
                    </div>
                    <div
                      style={{
                        display: "flex",
                        gap: 6,
                        marginTop: 8,
                        flexWrap: "wrap",
                      }}
                    >
                      <button
                        type="button"
                        style={styles.selectBtn}
                        disabled={cleanupSelected.size === 0}
                        onClick={applyCleanupExtractOnly}
                        title="仅提取要点/标签，不删除"
                      >
                        仅提取要点（{Math.min(cleanupSelected.size, EXTRACT_DIGEST_MAX)}）
                      </button>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        onClick={() => {
                          setCleanupSelected(new Set(cleanupSelectableIds))
                        }}
                      >
                        全选建议
                      </button>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        onClick={() => setCleanupSelected(new Set())}
                      >
                        清空建议选择
                      </button>
                      <button
                        type="button"
                        style={styles.dangerBtn}
                        disabled={cleanupSelected.size === 0 || mutating}
                        onClick={applyCleanupTrash}
                      >
                        移入回收站（{cleanupSelected.size}）
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}
            {pendingDelete && (
              <div
                role="alertdialog"
                aria-label="确认删除会话"
                aria-describedby="cm-delete-description"
                style={styles.pendingDelete}
              >
                <div id="cm-delete-description"><p style={{ margin: 0, fontSize: 12, lineHeight: 1.5 }}>
                  {pendingDelete.source === "empty" ? `永久清理 ${pendingDelete.ids.length} 个空白对话？不可恢复，服务端会再次检查是否仍为空白。` : pendingDelete.hard
                    ? `永久删除 ${pendingDelete.ids.length} 个会话？不可恢复。`
                    : `将 ${pendingDelete.ids.length} 个会话移入回收站？可在回收站恢复（约 30 天后自动清理）。`}
                  {pendingDelete.source === "cleanup" &&
                  cleanupSuggestions.some(
                    (s) => pendingDelete.ids.includes(s.thread_id) && s.reason === "acp_husk",
                  )
                    ? " 含编程接力记录，请再核对。"
                    : ""}
                </p>
                <ul className="cm-delete-preview">{pendingDelete.ids.slice(0, 5).map(id => <li key={id}>{displayThreadTitle(threads.find(t => t.id === id) || { id })} <span>#{id}</span></li>)}</ul>
                {pendingDelete.ids.length > 5 && <p className="cm-thread-management-help">另有 {pendingDelete.ids.length - 5} 个已选对话</p>}
                </div>
                <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                  <button type="button" style={styles.dangerBtn} disabled={mutating} onClick={executePendingDelete}>
                    {pendingDelete.hard ? "永久删除" : "移入回收站"}
                  </button>
                  <button type="button" data-delete-cancel style={styles.selectBtn} onClick={() => setPendingDelete(null)}>
                    取消
                  </button>
                </div>
              </div>
            )}
            {view === "ai" && <p className="cm-thread-management-help">按 AI 提取的首个主题标签自动分组；重新提取可能调整 AI 分组，不改变手动分组。点击“AI 提取标签”为最多20个未标注对话提取标签。</p>}
            {view === "tags" && <p className="cm-thread-management-help">汇总人工与 AI 标签；点对话右侧“分类”管理人工标签。</p>}
            {metadataNotice && <p className="cm-thread-management-help" role="status">{metadataNotice}</p>}
            {mutationNotice && <div className="cm-thread-mutation-notice" role="status" aria-live="polite"><span>{mutationNotice}</span>{!mutating && <button type="button" onClick={() => chrome.runtime.sendMessage({ type: "thread.list", include_trashed: trashView })}>刷新列表</button>}</div>}
            {editingThread && <ThreadMetadataEditor key={editingThread.id} thread={editingThread} folders={[...new Set(threads.map(t => t.topic_folder).filter((name): name is string => !!name))]} onClose={() => closeMetadataEditor()} onSaved={thread => { dispatch({ type: "UPSERT_THREAD", thread }); closeMetadataEditor(thread.id); setMetadataNotice("分类已保存") }} />}
            {extractProgress && extractProgress.total > 0 && (
              <div style={styles.progressBar} role="status" aria-live="polite">
                提取要点 {extractProgress.done}/{extractProgress.total}
                {extractProgress.done >= extractProgress.total ? " · 完成" : "…"}
              </div>
            )}

            {relatedSeedId && (
              <div style={styles.relatedPanel}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 4,
                  }}
                >
                  <span style={{ fontSize: 11, fontWeight: 600, color: tokens.textSecondary }}>
                    相关 · {displayThreadTitle(
                      (threads.find((x) => x.id === relatedSeedId) as Thread) || {
                        id: relatedSeedId,
                      },
                    )}
                  </span>
                  <button
                    type="button"
                    style={styles.selectBtn}
                    onClick={() => setRelatedSeedId(null)}
                  >
                    关闭
                  </button>
                </div>
                {relatedHits.length === 0 ? (
                  <div style={{ fontSize: 11, color: tokens.textSecondary }}>
                    暂无相关会话（需更多标签/要点）
                  </div>
                ) : (
                  relatedHits.map((h) => {
                    const thr = threads.find((x) => x.id === h.thread_id) as Thread | undefined
                    const title = thr ? displayThreadTitle(thr) : h.thread_id
                    return (
                      <button
                        key={h.thread_id}
                        type="button"
                        style={styles.relatedItem}
                        onClick={() => handleSelect(h.thread_id)}
                        title={
                          h.shared_tags.length
                            ? `共标签: ${h.shared_tags.join(", ")}`
                            : `score ${h.score.toFixed(2)}`
                        }
                      >
                        {title}
                        {h.shared_tags.length > 0 && (
                          <span style={{ color: tokens.textMuted, marginLeft: 4 }}>
                            #{h.shared_tags.slice(0, 2).join(" #")}
                          </span>
                        )}
                      </button>
                    )
                  })
                )}
              </div>
            )}

            {trashView && (
              <div
                style={{
                  padding: "6px 10px",
                  background: tokens.warningSoft,
                  color: tokens.warning,
                  fontSize: 11,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <span>回收站 · {filtered.length}（约 30 天后自动清理）</span>
                <button type="button" style={styles.selectBtn} onClick={closeTrashView}>
                  返回
                </button>
              </div>
            )}

            <div style={styles.searchRow}>
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="搜索标题 / 编号 / 消息 / 要点 / 标签…"
                style={styles.searchInput}
                aria-label="搜索线程"
              />
            </div>

            <div className="cm-thread-management-list" style={styles.list}>
              {view === "time" ? renderTimeline() : view === "tags" ? renderTagsView()  : renderTopicsView(view === "ai")}
            </div>

            {selectMode && (
              <div className="cm-thread-selection-bar" style={styles.bottomBar}>
                <span style={{ fontSize: 12, color: tokens.textSecondary }}>
                  已选 {selected.size}
                </span>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "flex-end" }}>
                  {trashView ? (
                    <button
                      type="button"
                      style={styles.selectBtn}
                      disabled={selected.size === 0 || mutating}
                      onClick={() => handleRestore([...selected])}
                    >
                      恢复
                    </button>
                  ) : (
                    <>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        disabled={selected.size === 0}
                        onClick={() => {
                          handleBatchAutoTitle([...selected])
                          exitSelectMode()
                        }}
                        title="用首条消息为选中未命名会话起名"
                      >
                        起名
                      </button>
                      <button
                        type="button"
                        style={styles.selectBtn}
                        disabled={selected.size === 0}
                        onClick={() => {
                          handleExtractDigest([...selected])
                          exitSelectMode()
                        }}
                      >
                        提取要点
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    style={styles.dangerBtn}
                    disabled={selected.size === 0 || mutating}
                    onClick={handleBatchDelete}
                  >
                    {trashView ? "永久删除" : "移入回收站"}
                  </button>
                  <button type="button" style={styles.selectBtn} onClick={exitSelectMode}>
                    取消
                  </button>
                </div>
              </div>
            )}
          </div>

        </>,
        document.body,
      )}
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  hamburger: {
    width: 32,
    height: 32,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    background: "transparent",
    border: "none",
    borderRadius: tokens.radiusMd,
    cursor: "pointer",
    padding: 0,
    color: tokens.text,
    flexShrink: 0,
    fontFamily: tokens.font,
  },
  panel: {
    position: "fixed",
    left: 8,
    right: 8,
    width: "auto",
    maxHeight: 360,
    background: tokens.bgElevated,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: tokens.radiusMd,
    boxShadow: tokens.shadowMd,
    zIndex: 10050,
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
  },
  panelHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 10px",
    borderBottom: `1px solid ${tokens.border}`,
    gap: 6,
  },
  viewToggle: {
    display: "flex",
    gap: 2,
    background: tokens.bgMuted,
    borderRadius: 6,
    padding: 2,
  },
  viewBtn: {
    border: "none",
    background: "transparent",
    fontSize: 11,
    padding: "3px 8px",
    borderRadius: 4,
    cursor: "pointer",
    color: tokens.textSecondary,
    fontFamily: tokens.font,
  },
  viewBtnActive: {
    border: "none",
    background: tokens.bgElevated,
    fontSize: 11,
    padding: "3px 8px",
    borderRadius: 4,
    cursor: "pointer",
    color: tokens.accentText,
    fontWeight: 600,
    fontFamily: tokens.font,
    boxShadow: tokens.shadowSm,
  },
  searchRow: {
    padding: "6px 10px",
    borderBottom: `1px solid ${tokens.border}`,
  },
  searchInput: {
    width: "100%",
    boxSizing: "border-box",
    border: `1px solid ${tokens.border}`,
    borderRadius: 6,
    padding: "6px 8px",
    fontSize: 12,
    fontFamily: tokens.font,
    outline: "none",
  },
  newBtn: {
    background: tokens.accent,
    color: tokens.userBubbleText,
    border: "none",
    borderRadius: 4,
    padding: "3px 10px",
    fontSize: 11,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  selectBtn: {
    background: tokens.bgElevated,
    color: tokens.textSecondary,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: 4,
    padding: "3px 8px",
    fontSize: 11,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  selectBtnActive: {
    background: tokens.accentSoft,
    color: tokens.accentText,
    border: `1px solid ${tokens.accent}`,
    borderRadius: 4,
    padding: "3px 8px",
    fontSize: 11,
    cursor: "pointer",
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  // Phase 2b: same density as StatusRail ⋯ (popupMenuStyles)
  menuBtn: popupMenuStyles.menuTrigger,
  /** A-4 portal menu — fixed to body, above panel(51) / backdrop(50). */
  menuPortal: {
    ...popupMenuStyles.menu,
    position: "fixed" as const,
    zIndex: 10060,
  },
  menuItem: popupMenuStyles.menuItem,
  progressBar: {
    padding: "5px 10px",
    fontSize: 11,
    color: tokens.accentText,
    background: tokens.accentSoft,
    borderBottom: `1px solid ${tokens.border}`,
    fontFamily: tokens.font,
  },
  relatedPanel: {
    padding: "6px 10px",
    borderBottom: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
  },
  relatedItem: {
    display: "block",
    width: "100%",
    textAlign: "left" as const,
    background: "none",
    border: "none",
    padding: "4px 0",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: tokens.font,
    color: tokens.accentText,
  },
  tagCloudSection: {
    borderBottom: `1px solid ${tokens.border}`,
  },
  tagCloudFoldRow: {
    display: "flex",
    flexWrap: "wrap" as const,
    gap: 6,
    padding: "0 10px 8px",
  },
  untaggedCtaRow: {
    display: "flex",
    flexDirection: "column" as const,
    gap: 4,
    padding: "8px 10px",
    borderBottom: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
  },
  primaryCta: {
    background: tokens.accent,
    color: tokens.userBubbleText,
    border: "none",
    borderRadius: tokens.radiusSm,
    padding: "7px 10px",
    fontSize: 12,
    fontWeight: 600,
    cursor: "pointer",
    fontFamily: tokens.font,
    textAlign: "center" as const,
  },
  ctaHint: {
    fontSize: 10,
    color: tokens.textMuted,
    fontFamily: tokens.font,
  },
  tldr: {
    fontSize: 11,
    color: tokens.textSecondary,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap" as const,
    marginTop: 2,
    lineHeight: 1.35,
    fontFamily: tokens.font,
  },
  list: {
    overflowY: "auto",
    flex: 1,
  },
  groupHeader: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    padding: "6px 10px",
    background: tokens.bgMuted,
    borderBottom: `1px solid ${tokens.border}`,
    cursor: "pointer",
    userSelect: "none",
  },
  groupChevron: {
    fontSize: 9,
    color: tokens.textMuted,
    width: 12,
    flexShrink: 0,
  },
  groupLabel: {
    fontSize: 12,
    fontWeight: 600,
    color: tokens.textSecondary,
  },
  threadItem: {
    padding: "8px 12px",
    borderBottom: `1px solid ${tokens.border}`,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: 8,
    userSelect: "text",
    WebkitUserSelect: "text",
  },
  checkbox: {
    flexShrink: 0,
    width: 14,
    height: 14,
    cursor: "pointer",
  },
  iconBtn: {
    background: "none",
    border: "none",
    fontSize: 12,
    cursor: "pointer",
    padding: "2px 4px",
    color: tokens.textSecondary,
    whiteSpace: "nowrap",
    flexShrink: 0,
  },
  threadAliasRow: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    minWidth: 0,
  },
  threadAlias: {
    fontSize: 13,
    fontWeight: 500,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  /** Always-visible short id; click copies bare id for search. */
  threadIdBadge: {
    flexShrink: 0,
    border: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    padding: "1px 5px",
    margin: 0,
    fontSize: 10,
    fontWeight: 600,
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
    color: tokens.textSecondary,
    cursor: "pointer",
    lineHeight: 1.2,
    maxWidth: 88,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap" as const,
    borderRadius: tokens.radiusPill,
  },
  badge: {
    fontSize: 9,
    fontWeight: 600,
    color: tokens.accentText,
    background: tokens.accentSoft,
    borderRadius: 3,
    padding: "1px 4px",
    flexShrink: 0,
    textTransform: "uppercase" as const,
  },
  badgeMuted: {
    fontSize: 9,
    fontWeight: 500,
    color: tokens.textMuted,
    background: tokens.bgMuted,
    borderRadius: 3,
    padding: "1px 4px",
    flexShrink: 0,
  },
  tagRow: {
    display: "flex",
    flexWrap: "wrap",
    gap: 4,
    marginTop: 3,
  },
  tagCloud: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
    padding: "8px 10px",
    // border lives on tagCloudSection so fold row stays outside any clip
  },
  tagPill: {
    border: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    borderRadius: 999,
    padding: "2px 8px",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: tokens.font,
  },
  tagPillActive: {
    border: `1px solid ${tokens.accent}`,
    background: tokens.accentSoft,
    color: tokens.accentText,
    borderRadius: 999,
    padding: "2px 8px",
    fontSize: 11,
    cursor: "pointer",
    fontFamily: tokens.font,
    fontWeight: 600,
  },
  preview: {
    fontSize: 11,
    color: tokens.textMuted,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    marginTop: 2,
  },
  relTime: {
    fontSize: 10,
    color: tokens.textMuted,
    marginTop: 2,
  },
  pendingDelete: {
    display: "flex",
    flexWrap: "wrap",
    gap: 8,
    alignItems: "center",
    justifyContent: "space-between",
    padding: "10px 12px",
    background: tokens.warningSoft,
    borderBottom: `1px solid ${tokens.border}`,
    color: tokens.text,
    flexShrink: 0,
  },
  bottomBar: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "8px 10px",
    borderTop: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    gap: 8,
  },
  dangerBtn: {
    background: tokens.danger,
    color: tokens.userBubbleText,
    border: "none",
    borderRadius: 4,
    padding: "4px 10px",
    fontSize: 11,
    cursor: "pointer",
  },
  cleanupPanel: {
    borderBottom: `1px solid ${tokens.border}`,
    padding: "10px 12px",
    background: tokens.bgMuted,
    maxHeight: "min(42%, 280px)",
    overflowY: "auto",
    flexShrink: 0,
  },
}

FULL SOURCE chrome-extension/src/sidepanel/components/MeetingPanel.tsx
/**
 * Meeting workbench — Mtg0–Mtg3.
 * SoT: meeting-minutes-design + Mtg3 diarize design.
 * Mtg3: experimental anonymous 发言人N via local feature k-means (NOT identity).
 * Does NOT auto-start mic on pack apply. System audio mix still parking-lot.
 */

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react"
import { useAgentStore } from "../store/agentStore"
import { tokens } from "../ui/tokens"
import { createLocalSttAdapter } from "../voice/local-stt-adapter"
import {
  detectLocalMediaCapture,
  LOCAL_STT_NEAR_REALTIME_SEGMENT_MS,
} from "../voice/local-stt-detect"
import {
  fileToWavSegments,
  transcribeWavViaStt,
} from "../voice/meeting-audio-import"
import {
  loadMeetingTemplate,
  saveMeetingTemplate,
} from "../voice/meeting-template-storage"
import {
  formatMeetingElapsed,
  meetingLiveInterimHint,
  meetingMinutesSendPlan,
  MEETING_DISCONNECT_FINALIZE_MS,
  MEETING_LIVE_HARD_CAP_MS,
  MEETING_LIVE_SOFT_CAP_MS,
  MEETING_MINUTES_WATCHDOG_MS,
  MEETING_NEAR_REALTIME_DEFAULT,
  MEETING_STOP_FAILSAFE_MS,
} from "../voice/meeting-caps"
import { VOICE_DEFAULT_LANG } from "../voice/detect"
import { formatMeetingDiarizeStatus, mapMeetingDiarizeError } from "../voice/meeting-diarize-copy"
import { diarizeViaEmbeddingUpload, wavToRawPcm } from "../voice/meeting-diarize-upload"
import { mapLocalSttError } from "../voice/error-map"
import {
  createSerialRefineQueue,
  formatMeetingSoftSegmentError,
  isMeetingSoftSegmentBanner,
  requestMeetingSegmentRefine,
} from "../voice/meeting-live-refine"
import { VOICE_PRIVACY_ACK_V2_CLAUSES } from "../voice/privacy-copy"
import type { SpeechAdapter } from "../voice/web-speech-adapter"
import { confirmMeetingClose } from "../voice/meeting-close"

/** Format companion transcript lines for textarea (Speaker: text). */
function formatLinesFromMeeting(transcript: any[]): string {
  if (!Array.isArray(transcript)) return ""
  return transcript
    .map((l) => {
      const t = typeof l?.text === "string" ? l.text : ""
      const sp = typeof l?.speaker === "string" ? l.speaker.trim() : ""
      return sp ? `${sp}: ${t}` : t
    })
    .filter(Boolean)
    .join("\n\n")
}

type CapturePhase = "idle" | "starting" | "recording" | "processing" | "stopping"

function useMeetingMessages(onMsg: (m: any) => void) {
  useEffect(() => {
    const listener = (msg: any) => {
      if (msg && typeof msg.type === "string" && msg.type.startsWith("meeting.")) {
        onMsg(msg)
      }
      return false
    }
    chrome.runtime.onMessage.addListener(listener)
    return () => chrome.runtime.onMessage.removeListener(listener)
  }, [onMsg])
}

function sendViaRuntime(msg: Record<string, unknown>): void {
  try {
    chrome.runtime.sendMessage(msg)
  } catch {
    /* SW missing */
  }
}

function subscribeVoiceStt(handler: (msg: any) => void): () => void {
  if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
    return () => {}
  }
  const listener = (msg: any) => {
    if (msg && typeof msg.type === "string" && msg.type.startsWith("voice.stt.")) {
      handler(msg)
    }
    return false
  }
  chrome.runtime.onMessage.addListener(listener)
  return () => {
    try {
      chrome.runtime.onMessage.removeListener(listener)
    } catch {
      /* */
    }
  }
}

/** #260: imperative one-shot subscribe for meeting.* (upload client state machine). */
function subscribeMeetingRuntime(handler: (msg: any) => void): () => void {
  if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
    return () => {}
  }
  const listener = (msg: any) => {
    if (msg && typeof msg.type === "string" && msg.type.startsWith("meeting.")) {
      handler(msg)
    }
    return false
  }
  chrome.runtime.onMessage.addListener(listener)
  return () => {
    try {
      chrome.runtime.onMessage.removeListener(listener)
    } catch {
      /* */
    }
  }
}

const formatElapsed = formatMeetingElapsed

export function MeetingPanel(props: {
  onClose: () => void
  onSendToDraft: (text: string) => void
  registerBeforeClose?: (guard: () => Promise<boolean>) => () => void
}) {
  const { state, dispatch } = useAgentStore()
  const [title, setTitle] = useState("")
  const [transcript, setTranscript] = useState("")
  const [minutesMd, setMinutesMd] = useState("")
  const [meetingId, setMeetingId] = useState<string | null>(null)
  const [status, setStatus] = useState<string>("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [closing, setClosing] = useState(false)
  const [ack, setAck] = useState(false)
  const [capturePhase, setCapturePhase] = useState<CapturePhase>("idle")
  const [elapsedMs, setElapsedMs] = useState(0)
  const [softCapHint, setSoftCapHint] = useState(false)
  /** P1: progressive hypothesis text (not yet committed to transcript). */
  const [interimText, setInterimText] = useState("")
  const [pendingGenerate, setPendingGenerate] = useState(false)
  /** Mtg2: optional default speaker for STT append / bulk label (manual only). */
  const [defaultSpeaker, setDefaultSpeaker] = useState("")
  const [importStatus, setImportStatus] = useState<string | null>(null)
  const textFileRef = useRef<HTMLInputElement | null>(null)
  const audioFileRef = useRef<HTMLInputElement | null>(null)
  const defaultSpeakerRef = useRef("")
  const importAbortRef = useRef(false)
  const importDoneRef = useRef<Promise<boolean> | null>(null)
  /** Skip server→textarea sync while user is typing (dual-review dirty-guard). */
  const transcriptDirtyRef = useRef(false)
  /** #260: per-line raw s16le PCM from last audio import (aligned with append order). */
  const linePcmRef = useRef<Uint8Array[]>([])
  const [diarizeK, setDiarizeK] = useState(0)
  const [autoDiarizeAfterImport, setAutoDiarizeAfterImport] = useState(false)
  /** Optional markdown template for minutes structure (chrome.storage). */
  const [templateMd, setTemplateMd] = useState("")
  const templateMdRef = useRef("")
  /** After stop: re-run silence-cut / soft paragraph split on full transcript. */
  const [autoSegmentOnStop, setAutoSegmentOnStop] = useState(true)
  const autoSegmentOnStopRef = useRef(true)
  /** Live segment AI refine in flight (opt-in via asrRefinerEnabled). */
  const [refinePending, setRefinePending] = useState(0)

  const adapterRef = useRef<SpeechAdapter | null>(null)
  const captureStartRef = useRef<number | null>(null)
  const meetingIdRef = useRef<string | null>(null)
  const phaseRef = useRef<CapturePhase>("idle")
  const wantGenerateRef = useRef(false)
  const transcriptRef = useRef("")
  /** Prevent double meeting.end / finalize. */
  const finalizedRef = useRef(false)
  const finalizingRef = useRef(false)
  const closePendingRef = useRef<Promise<boolean> | null>(null)
  const captureFinishedRef = useRef<((ok: boolean) => void) | null>(null)
  const closeFailureRef = useRef(false)
  const needsClosePersistenceRef = useRef(false)
  const closeMeetingIdRef = useRef<string | null>(null)
  const closeNeedsEndRef = useRef(true)
  const liveTextRef = useRef<string[]>([])
  const cancelStartingRef = useRef(false)
  const requestCloseRef = useRef<() => Promise<boolean>>(async () => true)
  const titleRef = useRef(title)
  const refineGenRef = useRef(0)
  const refineQueueRef = useRef(createSerialRefineQueue())
  const asrRefinerEnabledRef = useRef(false)
  const companionConnectedRef = useRef(false)
  /** Companion died after 「结束并生成纪要」: retry when WS is back. */
  const retryGenerateOnReconnectRef = useRef(false)

  meetingIdRef.current = meetingId
  transcriptRef.current = transcript
  titleRef.current = title
  phaseRef.current = capturePhase
  defaultSpeakerRef.current = defaultSpeaker
  templateMdRef.current = templateMd
  autoSegmentOnStopRef.current = autoSegmentOnStop
  asrRefinerEnabledRef.current = state.asrRefinerEnabled === true

  const companionConnected = state.connectionState === "connected"
  companionConnectedRef.current = companionConnected
  const activeModelId = state.voiceModel?.localModelId || "medium"
  const localModelReady = state.voiceModel?.models?.[activeModelId]?.status === "ready"
  const localBinaryReady = state.voiceModel?.binary?.status === "ready"
  /** #260: speaker-embedding diarize model (未就绪必须显式引导下载，不静默落回). */
  const diarizeModelReady = state.voiceModel?.diarizeModel?.status === "ready"
  /** P1: near-rt defaults on; honor global voiceRealtimeStreaming toggle. */
  const nearRealtime =
    MEETING_NEAR_REALTIME_DEFAULT &&
    state.voiceRealtimeStreaming !== false &&
    activeModelId !== "large-v3-turbo"
  const localMedia = detectLocalMediaCapture(
    typeof globalThis !== "undefined" ? (globalThis as any) : {},
  )
  const capturing =
    capturePhase === "recording" ||
    capturePhase === "processing" ||
    capturePhase === "starting" ||
    capturePhase === "stopping"

  const setPhase = useCallback((p: CapturePhase) => {
    phaseRef.current = p
    setCapturePhase(p)
  }, [])

  useEffect(() => {
    try {
      chrome.storage.local.get("meeting_privacy_ack_v1", (r) => {
        if (r.meeting_privacy_ack_v1 === true) setAck(true)
      })
    } catch {
      /* */
    }
  }, [])

  const templateLoadedRef = useRef(false)
  useEffect(() => {
    let cancelled = false
    void loadMeetingTemplate().then((t) => {
      if (cancelled) return
      setTemplateMd(t)
      templateMdRef.current = t
      templateLoadedRef.current = true
    })
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    if (!templateLoadedRef.current) return
    const t = setTimeout(() => {
      saveMeetingTemplate(templateMd)
    }, 300)
    return () => clearTimeout(t)
  }, [templateMd])

  useEffect(() => {
    if (!companionConnected) return
    try {
      chrome.runtime.sendMessage({ type: "voice.model.get_state" })
    } catch {
      /* */
    }
  }, [companionConnected])

  useEffect(() => {
    if (!capturing) return
    const id = setInterval(() => {
      if (captureStartRef.current != null) {
        const ms = Date.now() - captureStartRef.current
        setElapsedMs(ms)
        if (ms >= MEETING_LIVE_SOFT_CAP_MS) setSoftCapHint(true)
      }
    }, 250)
    return () => clearInterval(id)
  }, [capturing])

  useEffect(() => {
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: capturing })
    return () => {
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    }
  }, [capturing, dispatch])

  /** Tear down adapter without onEnd (destroy is silent; abort would re-enter finalize). */
  const destroyAdapter = useCallback(() => {
    const a = adapterRef.current
    adapterRef.current = null
    if (!a) return
    try {
      a.destroy()
    } catch {
      /* */
    }
  }, [])

  const appendLocalAndRemote = useCallback(
    (
      chunk: string,
      id: string | null,
      source: "stt" | "asr_refiner" = "stt",
    ) => {
      const t = chunk.trim()
      if (!t) return
      liveTextRef.current.push(t)
      const sp = defaultSpeakerRef.current.trim().slice(0, 32)
      const display = sp ? `${sp}: ${t}` : t
      setTranscript((prev) => {
        // Live STT: blank-line between segments = smart paragraph boundary
        const next = prev ? `${prev}\n\n${display}` : display
        transcriptRef.current = next
        return next
      })
      if (id) {
        sendViaRuntime({
          type: "meeting.append_transcript",
          v: 1,
          id,
          text: t,
          source,
          speaker: sp || undefined,
        })
      }
    },
    [],
  )

  /**
   * Commit a live STT final: optional ADR-024 refine with prior transcript context,
   * then append (paragraph-separated). Serial queue preserves order.
   * Pin meeting id at enqueue so late refine never appends to a newer meeting (Pi nit).
   */
  const commitLiveSegment = useCallback(
    (finalChunk: string, meetingIdForAppend: string) => {
      const raw = finalChunk.trim()
      if (!raw) return
      const pinnedId = meetingIdForAppend
      const wantRefine = asrRefinerEnabledRef.current
      if (!wantRefine) {
        appendLocalAndRemote(raw, pinnedId, "stt")
        return
      }
      refineGenRef.current += 1
      const gen = refineGenRef.current
      const sid = `mtg-refine-${pinnedId}-${gen}`
      const prior = transcriptRef.current
      setRefinePending((n) => n + 1)
      void refineQueueRef.current
        .enqueue(async () => {
          const { text, refined } = await requestMeetingSegmentRefine({
            sessionId: sid,
            refineGen: gen,
            text: raw,
            priorTranscript: prior,
          })
          // Always pin to the meeting that owned this segment (not meetingIdRef after await)
          appendLocalAndRemote(
            text || raw,
            pinnedId,
            refined ? "asr_refiner" : "stt",
          )
        })
        .finally(() => {
          setRefinePending((n) => Math.max(0, n - 1))
        })
    },
    [appendLocalAndRemote],
  )

  /**
   * Fire minutes job or defer until Companion is back.
   * Product adversary B1: dropped WS send used to leave 「生成中…」 forever.
   */
  const sendMinutesJob = useCallback((id: string | null) => {
    if (meetingMinutesSendPlan(companionConnectedRef.current) === "defer-reconnect") {
      retryGenerateOnReconnectRef.current = true
      setBusy(false)
      setPendingGenerate(false)
      setError(
        (prev) =>
          prev ||
          "Companion 未连接；转写已保留，重连后将自动生成纪要（也可手动点「生成会议纪要」）",
      )
      return
    }
    retryGenerateOnReconnectRef.current = false
    setBusy(true)
    setPendingGenerate(true)
    sendViaRuntime({
      type: "meeting.generate_minutes",
      v: 1,
      id: id || undefined,
      text: transcriptRef.current.trim() || undefined,
      template_md: templateMdRef.current.trim() || undefined,
    })
  }, [])

  /**
   * End server session + tear down adapter. Idempotent via finalizedRef.
   * Drains in-flight AI refine before end / silence-cut / minutes (dual-review nit #2).
   */
  const finalizeCapture = useCallback(
    (opts: { generate: boolean; id: string | null }) => {
      if (finalizedRef.current) return
      finalizedRef.current = true
      finalizingRef.current = true
      captureStartRef.current = null
      setPhase("idle")
      setSoftCapHint(false)
      destroyAdapter()
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })

      const id = opts.id || meetingIdRef.current
      const wantGenerate = opts.generate
      const wantSegment = autoSegmentOnStopRef.current

      void (async () => {
        // Wait for segment refine queue (cap ~22s) so minutes see refined text
        try {
          const drained = await refineQueueRef.current.drain()
          if (!drained && closePendingRef.current) {
            closeFailureRef.current = true
            setError("最后一段仍在纠错，请等待转写完成后重试收起")
          }
          if (!drained && wantGenerate) {
            setError((prev) =>
              prev ||
              "部分 AI 纠错未在时限内完成；纪要将基于当前转写（可稍后重新生成）",
            )
          }
        } catch {
          /* best-effort */
        }

        if (id && !closePendingRef.current) {
          sendViaRuntime({ type: "meeting.end", v: 1, id })
        }
        // Smart segment after refine drain so silence-cut sees full refined blob
        if (wantSegment && id && transcriptRef.current.trim() && !closePendingRef.current) {
          sendViaRuntime({
            type: "meeting.apply_silence_cut",
            v: 1,
            id,
            text: transcriptRef.current,
          })
        }
        if (wantGenerate) {
          // Brief beat for silence-cut server apply before minutes job
          await new Promise((r) => setTimeout(r, 150))
          sendMinutesJob(id)
        }
      })().finally(() => {
        finalizingRef.current = false
        captureFinishedRef.current?.(!closeFailureRef.current)
        captureFinishedRef.current = null
      })
    },
    [destroyAdapter, dispatch, sendMinutesJob, setPhase],
  )

  // Companion restart mid-window used to leave phase=stopping forever
  // (adapter awaited a voice.stt.end ACK that never arrived). Force-finalize.
  useEffect(() => {
    if (capturePhase !== "stopping") return
    const t = setTimeout(() => {
      if (phaseRef.current !== "stopping" || finalizedRef.current) return
      closeFailureRef.current = true
      setError((prev) => prev || "结束超时：已停止录制。可基于已有转写生成纪要")
      const gen = wantGenerateRef.current
      wantGenerateRef.current = false
      finalizeCapture({ generate: gen, id: meetingIdRef.current })
    }, MEETING_STOP_FAILSAFE_MS)
    return () => clearTimeout(t)
  }, [capturePhase, finalizeCapture])

  // Debounced disconnect: WS auth blips (~1s) must not kill capture; a real
  // Companion death (SIGTERM ~18s this incident) must not leave 「正在听」.
  useEffect(() => {
    if (companionConnected) return
    if (phaseRef.current === "idle") return
    const t = setTimeout(() => {
      if (finalizedRef.current) return
      if (phaseRef.current === "idle") return
      closeFailureRef.current = true
      setError((prev) => prev || "Companion 断开，已停止录制。可基于已有转写生成纪要")
      const gen = wantGenerateRef.current
      wantGenerateRef.current = false
      finalizeCapture({ generate: gen, id: meetingIdRef.current })
    }, MEETING_DISCONNECT_FINALIZE_MS)
    return () => clearTimeout(t)
  }, [companionConnected, finalizeCapture])

  useEffect(() => {
    if (!companionConnected) return
    if (!retryGenerateOnReconnectRef.current) return
    if (phaseRef.current !== "idle") return
    retryGenerateOnReconnectRef.current = false
    sendMinutesJob(meetingIdRef.current)
  }, [companionConnected, sendMinutesJob])

  useEffect(() => {
    if (!pendingGenerate) return
    const t = setTimeout(() => {
      setPendingGenerate(false)
      setBusy(false)
      retryGenerateOnReconnectRef.current = false
      setError((prev) => prev || "纪要生成超时。转写已保留，可再点「生成会议纪要」")
    }, MEETING_MINUTES_WATCHDOG_MS)
    return () => clearTimeout(t)
  }, [pendingGenerate])

  const startLocalSegments = useCallback(
    (id: string) => {
      closeMeetingIdRef.current = id
      destroyAdapter()
      finalizedRef.current = false

      if (!localMedia.ok) {
        setError("当前环境无法访问麦克风（getUserMedia）")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }
      if (!state.voicePrivacyAckV2) {
        setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }
      if (!localModelReady || !localBinaryReady) {
        setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型后再开始会议录音。")
        setPhase("idle")
        sendViaRuntime({ type: "meeting.end", v: 1, id })
        return
      }

      const adapter = createLocalSttAdapter(
        {
          onStart: () => {
            captureStartRef.current = Date.now()
            setPhase("recording")
            setElapsedMs(0)
            setError(null)
            setInterimText("")
          },
          onResult: ({ interim, finalChunk }) => {
            if (finalChunk?.trim()) {
              setInterimText("")
              commitLiveSegment(finalChunk, id)
              return
            }
            // Progressive hypothesis only (M2); do not append until window final.
            // Empty interim is a soft/empty window — keep last visible text.
            if (typeof interim === "string" && interim.trim()) {
              setInterimText(interim)
            }
          },
          onError: (code) => {
            if (code === "aborted") return
            const mapped = mapLocalSttError(code)
            if (mapped.severity === "silent") return
            if (closePendingRef.current) closeFailureRef.current = true
            // Soft = adapter continues; honest copy (segment+audio irreversibly lost).
            const soft = isMeetingSoftSegmentBanner(code)
            const msg = mapped.message || `转写错误: ${code}`
            setError(soft ? formatMeetingSoftSegmentError(msg) : msg)
          },
          onEnd: () => {
            setInterimText("")
            const gen = wantGenerateRef.current
            wantGenerateRef.current = false
            if (phaseRef.current === "idle" && finalizedRef.current) return
            finalizeCapture({ generate: gen, id })
          },
          onSegmentContinue: () => {
            if (phaseRef.current !== "stopping") setPhase("recording")
          },
          onCaptureStopped: () => {
            if (phaseRef.current !== "stopping") setPhase("processing")
          },
        },
        {
          send: sendViaRuntime,
          onMessage: subscribeVoiceStt,
          modelId: activeModelId,
          // The panel owns the visible stop deadline. Do not let the adapter's
          // shorter quiet-empty timeout turn an unfinished final into success.
          stopGraceMs: MEETING_STOP_FAILSAFE_MS + 1_000,
        },
      )
      adapterRef.current = adapter
      const sid = `mtg-${id}-${Date.now().toString(36)}`
      // STT slot is force-aborted on companion by meeting.start — do not send
      // voice.stt.abort with a fake sessionId (e.g. "mtg-preempt") from the client.
      // P1 near-rt: streamPartial + ~8s windows; P2 hard cap independent of dictation 15/30m.
      adapter.start({
        lang: VOICE_DEFAULT_LANG,
        sessionId: sid,
        modelId: activeModelId,
        mode: "continuous",
        hardCapMs: MEETING_LIVE_HARD_CAP_MS,
        segmentMs: nearRealtime ? LOCAL_STT_NEAR_REALTIME_SEGMENT_MS : undefined,
        streamPartial: nearRealtime,
      })
    },
    [
      activeModelId,
      commitLiveSegment,
      destroyAdapter,
      finalizeCapture,
      localBinaryReady,
      localMedia.ok,
      localModelReady,
      nearRealtime,
      setPhase,
      state.voicePrivacyAckV2,
    ],
  )

  const startLocalSegmentsRef = useRef(startLocalSegments)
  startLocalSegmentsRef.current = startLocalSegments

  // Unmount / ContextPanelHost 收起: always end server session if still capturing
  // (destroy() is silent and would otherwise leave status=recording — dual-review nit).
  useEffect(() => {
    return () => {
      const id = meetingIdRef.current
      importAbortRef.current = true
      captureFinishedRef.current?.(false)
      captureFinishedRef.current = null
      const stillLive = phaseRef.current !== "idle" && !finalizedRef.current
      if (stillLive && id) {
        finalizedRef.current = true
        sendViaRuntime({ type: "meeting.end", v: 1, id })
      }
      destroyAdapter()
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    }
  }, [destroyAdapter, dispatch])

  const onMsg = useCallback(
    (msg: any) => {
      if (msg.type === "meeting.created" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || "")
        setStatus(msg.meeting.status || "draft")
        setBusy(false)
      }
      if (msg.type === "meeting.started" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        meetingIdRef.current = msg.meeting.id
        setTitle(msg.meeting.title || titleRef.current)
        setStatus(msg.meeting.status || "recording")
        if (cancelStartingRef.current) {
          cancelStartingRef.current = false
          closeMeetingIdRef.current = msg.meeting.id
          finalizedRef.current = false
          finalizeCapture({ generate: false, id: msg.meeting.id })
        } else if (phaseRef.current === "starting") {
          startLocalSegmentsRef.current(msg.meeting.id)
        }
      }
      if (msg.type === "meeting.ended" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        let st = msg.meeting.status || "ready"
        if (msg.audio_deleted === true) st = `${st} · 音频已按默认策略删除`
        setStatus(st)
      }
      if (msg.type === "meeting.updated" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setStatus(msg.meeting.status)
        // Only push server transcript when explicit cut/import ops or textarea not dirty.
        // During live capture, local appends own the textarea — a stale
        // meeting.updated (append N-1 arriving after local N) used to flicker
        // or drop the newest line.
        const live =
          phaseRef.current === "recording" ||
          phaseRef.current === "processing" ||
          phaseRef.current === "starting" ||
          phaseRef.current === "stopping"
        const forceSync = msg.cut === true
        if (
          Array.isArray(msg.meeting.transcript) &&
          msg.meeting.transcript.length > 0 &&
          (forceSync || (!transcriptDirtyRef.current && !live))
        ) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          if (formatted) {
            setTranscript(formatted)
            transcriptRef.current = formatted
            if (forceSync) transcriptDirtyRef.current = false
          }
        }
        if (msg.meeting.minutes?.raw_md) setMinutesMd(msg.meeting.minutes.raw_md)
        setBusy(false)
      }
      if (msg.type === "meeting.imported" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setTitle(msg.meeting.title || titleRef.current)
        setStatus(msg.meeting.status || "ready")
        if (Array.isArray(msg.meeting.transcript)) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          setTranscript(formatted)
          transcriptRef.current = formatted
          transcriptDirtyRef.current = false
        }
        linePcmRef.current = []
        setBusy(false)
        setImportStatus("已导入转写文件")
      }
      if (msg.type === "meeting.diarized" && msg.meeting) {
        setMeetingId(msg.meeting.id)
        setStatus(msg.meeting.status || "ready")
        if (Array.isArray(msg.meeting.transcript)) {
          const formatted = formatLinesFromMeeting(msg.meeting.transcript)
          setTranscript(formatted)
          transcriptRef.current = formatted
          transcriptDirtyRef.current = false
        }
        setBusy(false)
        const method = msg.diarize?.method || msg.meeting.diarize?.method
        const kRaw = msg.diarize?.k ?? msg.meeting.diarize?.k
        const k = typeof kRaw === "number" && Number.isFinite(kRaw) ? Math.floor(kRaw) : null
        setImportStatus(formatMeetingDiarizeStatus(method, k))
        if (k != null && k >= 2 && k <= 6) setDiarizeK(k)
      }
      if (msg.type === "meeting.minutes_result") {
        if (msg.minutes?.raw_md) setMinutesMd(msg.minutes.raw_md)
        if (msg.meeting?.id) {
          setMeetingId(msg.meeting.id)
          setStatus(msg.meeting.status || "done")
        }
        setBusy(false)
        setPendingGenerate(false)
        setError(null)
      }
      if (msg.type === "meeting.error") {
        if (closePendingRef.current) closeFailureRef.current = true
        setError(msg.message || msg.code || "error")
        setBusy(false)
        setPendingGenerate(false)
        if (
          msg.code === "need_privacy_ack" ||
          msg.code === "already_recording" ||
          phaseRef.current === "starting"
        ) {
          setPhase("idle")
          destroyAdapter()
          dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
          captureFinishedRef.current?.(false)
          captureFinishedRef.current = null
        }
      }
    },
    [destroyAdapter, dispatch, setPhase, finalizeCapture],
  )

  useMeetingMessages(onMsg)

  const ensureAck = () => {
    if (ack) return true
    setError("请先确认会议隐私说明（生成纪要会将转写文本发给已配置的 LLM）")
    return false
  }

  const acceptAck = () => {
    setAck(true)
    try {
      chrome.storage.local.set({ meeting_privacy_ack_v1: true })
    } catch {
      /* */
    }
    setError(null)
  }

  const createMeeting = () => {
    setBusy(true)
    setError(null)
    sendViaRuntime({
      type: "meeting.create",
      v: 1,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
    })
  }

  const startLiveCapture = () => {
    if (!ensureAck()) return
    if (!companionConnected) {
      setError("Companion 未连接")
      return
    }
    if (state.dictationCaptureActive) {
      setError("听写进行中，请先结束听写再开始会议录音（全局同时仅一路本机 STT）")
      return
    }
    if (capturing) return
    if (!localMedia.ok) {
      setError("当前环境无法访问麦克风")
      return
    }
    if (!state.voicePrivacyAckV2) {
      setError("请先确认下方「本机语音隐私说明」（或：设置 → 输入与语音 → 启用本机转写）")
      return
    }
    if (!localModelReady || !localBinaryReady) {
      setError("本机转写模型或二进制未就绪。请到设置 → 输入与语音 下载模型。")
      try {
        chrome.runtime.sendMessage({ type: "voice.model.get_state" })
      } catch {
        /* */
      }
      return
    }

    setError(null)
    setMinutesMd("")
    setPhase("starting")
    setSoftCapHint(false)
    wantGenerateRef.current = false
    finalizedRef.current = false
    closeFailureRef.current = false
    needsClosePersistenceRef.current = true
    closeMeetingIdRef.current = meetingId
    closeNeedsEndRef.current = true
    liveTextRef.current = []
    cancelStartingRef.current = false

    sendViaRuntime({
      type: "meeting.start",
      v: 1,
      id: meetingId || undefined,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
      privacy_ack_v1: true,
      audio_retained: false,
    })
  }

  const stopLiveCapture = (andGenerate: boolean) => {
    if (phaseRef.current === "idle" || phaseRef.current === "stopping") return
    setPhase("stopping")
    wantGenerateRef.current = andGenerate
    const a = adapterRef.current
    if (!a) {
      finalizeCapture({ generate: andGenerate, id: meetingId })
      return
    }
    try {
      a.stop()
    } catch {
      finalizeCapture({ generate: andGenerate, id: meetingId })
    }
  }

  requestCloseRef.current = () => {
    if (closePendingRef.current) return closePendingRef.current
    const pending = Promise.resolve().then(async () => {
      setClosing(true)
      closeFailureRef.current = false
      try {
        if (importDoneRef.current) {
          importAbortRef.current = true
          setImportStatus("正在中止导入并保存当前段…")
          const done = importDoneRef.current
          const finished = await new Promise<boolean>(resolve => {
            const timer = setTimeout(() => resolve(false), MEETING_STOP_FAILSAFE_MS)
            void done.then(ok => { clearTimeout(timer); resolve(ok) })
          })
          if (!finished) throw new Error("导入尚未完整结束，已保留面板。请等待当前段完成后重试收起")
        }
        if (phaseRef.current !== "idle" || finalizingRef.current) {
          const finished = new Promise<boolean>(resolve => { captureFinishedRef.current = resolve })
          if (phaseRef.current === "starting" && !adapterRef.current) {
            // Wait for meeting.started, then end without opening the microphone.
            cancelStartingRef.current = true
            setPhase("stopping")
          } else {
            stopLiveCapture(false)
          }
          if (!await finished) throw new Error("最后一段未完整处理，已保留面板和现有转写。请检查提示后重试收起")
        }
        if (needsClosePersistenceRef.current) {
          if (!await refineQueueRef.current.drain()) throw new Error("转写仍在纠错，请稍后重试收起")
          const id = closeMeetingIdRef.current
          if (!id) throw new Error("会议尚未创建完成，请稍后重试收起")
          await confirmMeetingClose({
            id,
            expectedText: liveTextRef.current.join("\n"),
            endRecording: closeNeedsEndRef.current,
            subscribe: subscribeMeetingRuntime,
            send: (message, callback) => chrome.runtime.sendMessage(message, callback),
          })
          needsClosePersistenceRef.current = false
        }
        return true
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "保存失败，已保留面板，请重试")
        return false
      } finally {
        setClosing(false)
        closePendingRef.current = null
      }
    })
    closePendingRef.current = pending
    return pending
  }

  useEffect(() => props.registerBeforeClose?.(() => requestCloseRef.current()), [props.registerBeforeClose])

  const ensureMeetingIdThen = (then: (id: string) => void) => {
    if (meetingId) {
      then(meetingId)
      return
    }
    // Create then wait for meeting.created — fire create and use one-shot listener
    const listener = (msg: any) => {
      if (msg?.type === "meeting.created" && msg.meeting?.id) {
        chrome.runtime.onMessage.removeListener(listener)
        setMeetingId(msg.meeting.id)
        then(msg.meeting.id)
      }
      return false
    }
    chrome.runtime.onMessage.addListener(listener)
    sendViaRuntime({
      type: "meeting.create",
      v: 1,
      title: title || undefined,
      thread_id: state.activeThreadId || undefined,
    })
    // Fallback timeout remove
    setTimeout(() => {
      try {
        chrome.runtime.onMessage.removeListener(listener)
      } catch {
        /* */
      }
    }, 8000)
  }

  const applySilenceCut = () => {
    if (!ensureAck()) return
    if (!meetingId && !transcript.trim()) {
      setError("没有可分段的转写")
      return
    }
    setBusy(true)
    setError(null)
    ensureMeetingIdThen((id) => {
      // Single WS: server applies text then silence-cut (no client setTimeout race)
      sendViaRuntime({
        type: "meeting.apply_silence_cut",
        v: 1,
        id,
        text: transcriptRef.current.trim() || undefined,
      })
      setImportStatus("已应用智能分段（静音/段落切分；说话人仍可手动标）")
    })
  }

  const bulkLabelSpeaker = () => {
    if (!ensureAck()) return
    const sp = defaultSpeaker.trim().slice(0, 32)
    if (!sp) {
      setError("请先填写默认说话人标签（如「我」）")
      return
    }
    if (!meetingId && !transcript.trim()) {
      setError("没有可标注的转写")
      return
    }
    setBusy(true)
    ensureMeetingIdThen((id) => {
      sendViaRuntime({
        type: "meeting.bulk_speaker",
        v: 1,
        id,
        speaker: sp,
        text: transcriptRef.current.trim() || undefined,
      })
      setImportStatus(`已将全部行标为「${sp}」（手动，非自动分离）`)
    })
  }

  const onImportTextFile = async (file: File | null) => {
    if (!file) return
    if (!ensureAck()) return
    setError(null)
    setBusy(true)
    setImportStatus(`读取 ${file.name}…`)
    try {
      const text = await file.text()
      if (!text.trim()) {
        setError("文件为空")
        setBusy(false)
        setImportStatus(null)
        return
      }
      const truncated = text.length > 80_000
      sendViaRuntime({
        type: "meeting.import_text",
        v: 1,
        id: meetingId || undefined,
        title: title || file.name.replace(/\.[^.]+$/, ""),
        thread_id: state.activeThreadId || undefined,
        privacy_ack_v1: true,
        text: text.slice(0, 80_000),
      })
      if (truncated) {
        setImportStatus("已截断至 80000 字后导入（文件过长）")
      }
    } catch {
      setError("读取文本文件失败")
      setBusy(false)
      setImportStatus(null)
    }
  }

  const onImportAudioFile = async (file: File | null) => {
    if (!file) return
    if (!ensureAck()) return
    if (!companionConnected) {
      setError("Companion 未连接")
      return
    }
    if (state.dictationCaptureActive || capturing) {
      setError("听写或会议录音进行中，请先结束后再导入音频")
      return
    }
    if (!state.voicePrivacyAckV2) {
      setError("导入音频需先确认「本机语音隐私说明」（见下方卡片，或设置 → 输入与语音 → 启用本机转写）")
      return
    }
    if (!localModelReady || !localBinaryReady) {
      setError("本机转写模型或二进制未就绪")
      return
    }

    setError(null)
    setBusy(true)
    importAbortRef.current = false
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: true })
    setImportStatus("解码音频…")
    let resolveImport!: (ok: boolean) => void
    let importSucceeded = true
    importDoneRef.current = new Promise<boolean>(resolve => { resolveImport = resolve })

    try {
    const decoded = await fileToWavSegments(file)
    if (importAbortRef.current) return
    if (decoded.ok === false) {
      importSucceeded = false
      setError(decoded.message)
      setBusy(false)
      setImportStatus(null)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      return
    }

    // Ensure meeting exists
    let id = meetingId
    if (!id) {
      id = await new Promise<string | null>((resolve) => {
        const listener = (msg: any) => {
          if (msg?.type === "meeting.created" && msg.meeting?.id) {
            chrome.runtime.onMessage.removeListener(listener)
            resolve(msg.meeting.id as string)
          }
          return false
        }
        chrome.runtime.onMessage.addListener(listener)
        sendViaRuntime({
          type: "meeting.create",
          v: 1,
          title: title || file.name.replace(/\.[^.]+$/, ""),
          thread_id: state.activeThreadId || undefined,
        })
        setTimeout(() => {
          try {
            chrome.runtime.onMessage.removeListener(listener)
          } catch {
            /* */
          }
          resolve(null)
        }, 8000)
      })
      if (id) setMeetingId(id)
    }
    if (!id) {
      importSucceeded = false
      setError("无法创建会议会话")
      setBusy(false)
      setImportStatus(null)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      return
    }
    closeMeetingIdRef.current = id
    closeNeedsEndRef.current = false
    needsClosePersistenceRef.current = true
    liveTextRef.current = []

    const total = decoded.segments.length
    let failedAt: number | null = null
    let done = 0
    const pcms: Uint8Array[] = []
    const texts: string[] = []
    setImportStatus(`本机转写 0/${total} 段…`)
    for (let i = 0; i < total; i++) {
      if (importAbortRef.current) break
      const seg = decoded.segments[i]!
      setImportStatus(`本机转写 ${i + 1}/${total} 段…`)
      const sid = `mtg-imp-${id}-${i}-${Date.now().toString(36)}`
      const r = await transcribeWavViaStt({
        wav: seg.wav,
        sessionId: sid,
        modelId: activeModelId,
        send: sendViaRuntime,
        onMessage: subscribeVoiceStt,
      })
      if (r.ok === false) {
        importSucceeded = false
        failedAt = i + 1
        setError(`音频第 ${i + 1} 段转写失败: ${r.code}`)
        break
      }
      if (r.text.trim()) {
        // One physical line per segment so PCM stays aligned (dual-review nit)
        const oneLine = r.text.trim().replace(/\s*\n+\s*/g, " ")
        texts.push(oneLine)
        pcms.push(wavToRawPcm(seg.wav))
        // local preview (speaker optional)
        appendLocalAndRemote(oneLine, null)
      }
      done = i + 1
    }
    linePcmRef.current = pcms

    // Single set_transcript so line count == features (avoid append race before diarize)
    if (texts.length > 0 && id) {
      const sp = defaultSpeakerRef.current.trim().slice(0, 32)
      const body = texts.join("\n")
      sendViaRuntime({
        type: "meeting.set_transcript",
        v: 1,
        id,
        text: body,
        source: "stt",
        silence_cut: false,
      })
      // Restore default-speaker when not auto-diarizing (Mtg2 contract)
      if (sp && !autoDiarizeAfterImport) {
        setTimeout(() => {
          sendViaRuntime({
            type: "meeting.bulk_speaker",
            v: 1,
            id,
            speaker: sp,
          })
        }, 100)
      }
    }

    setBusy(false)
    if (importAbortRef.current) {
      setImportStatus(`导入已中止（已完成 ${done}/${total} 段）`)
    } else if (failedAt != null) {
      setImportStatus(`导入部分失败（成功 ${done}/${total} 段，失败于第 ${failedAt} 段）`)
    } else {
      setImportStatus(`音频导入完成 ${done}/${total} 段`)
      if (autoDiarizeAfterImport && pcms.length >= 2 && id) {
        // embedding 引擎；模型未就绪 → 显式引导下载（#260 硬约束，不静默落回）
        if (!diarizeModelReady) {
          setError(mapMeetingDiarizeError("embedding_model_required"))
        } else {
          setBusy(true)
          await runUploadDiarize(id, pcms, "embedding")
        }
      }
    }
    dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
    } catch {
      importSucceeded = false
      setError("音频导入失败，已保留面板和现有转写")
    } finally {
      setBusy(false)
      dispatch({ type: "SET_MEETING_CAPTURE_ACTIVE", active: false })
      importDoneRef.current = null
      resolveImport(importSucceeded)
    }
  }

  /**
   * #260 PCM 上传自动标说话人：embedding = companion ONNX 说话人嵌入聚类；
   * audio_cluster = 旧版 3 维声学特征显式回退（区分度低 · 无需模型）。
   * 成功态由 meeting.diarized 运行时处理器收尾（busy/importStatus）。
   */
  const runUploadDiarize = async (
    id: string,
    pcmSegments: Uint8Array[],
    mode: "embedding" | "audio_cluster",
  ): Promise<boolean> => {
    if (mode === "embedding" && !diarizeModelReady) {
      setError(mapMeetingDiarizeError("embedding_model_required"))
      setBusy(false)
      return false
    }
    setBusy(true)
    setError(null)
    const label = mode === "embedding" ? "说话人嵌入" : "旧版 3 维特征"
    setImportStatus(`${label} 0/${pcmSegments.length} 段…`)
    const r = await diarizeViaEmbeddingUpload({
      meetingId: id,
      pcmSegments,
      k: diarizeK,
      mode,
      send: sendViaRuntime,
      onMessage: subscribeMeetingRuntime,
      onProgress: (p) => setImportStatus(`${label} ${p.done}/${p.total} 段…`),
    })
    if (r.ok === false) {
      setError(mapMeetingDiarizeError(r.code, r.message))
      setBusy(false)
      setImportStatus(null)
      return false
    }
    return true
  }

  const runAutoDiarize = (mode: "embedding" | "audio_cluster" | "text_gap") => {
    if (!ensureAck()) return
    if (!meetingId && !transcript.trim()) {
      setError("请先创建会议或导入/录制转写")
      return
    }
    if (!transcript.trim()) {
      setError("转写为空，无法标说话人")
      return
    }
    if (mode === "embedding" || mode === "audio_cluster") {
      const pcms = linePcmRef.current
      if (!pcms.length) {
        setError("暂无音频段：请先「上传音频转写」以启用说话人分离（纯粘贴请用弱标）")
        return
      }
      // embedding 需模型；旧版 3 维是用户显式选择，不是模型缺失的静默落回
      if (mode === "embedding" && !diarizeModelReady) {
        setError(mapMeetingDiarizeError("embedding_model_required"))
        return
      }
      setBusy(true)
      setError(null)
      ensureMeetingIdThen((id) => {
        void runUploadDiarize(id, pcms, mode)
      })
      return
    }
    setBusy(true)
    setError(null)
    ensureMeetingIdThen((id) => {
      sendViaRuntime({
        type: "meeting.auto_diarize",
        v: 1,
        id,
        privacy_ack_v1: true,
        mode: "text_gap",
        k: diarizeK,
        text: transcriptRef.current.trim() || undefined,
      })
    })
  }

  const generate = () => {
    if (!ensureAck()) return
    if (capturing) {
      setError("请先结束录音再生成纪要，或使用「结束并生成纪要」")
      return
    }
    if (!transcript.trim() && !meetingId) {
      setError("请先粘贴转写文本或完成录音")
      return
    }
    setBusy(true)
    setError(null)
    if (meetingId && transcript.trim()) {
      sendViaRuntime({
        type: "meeting.set_transcript",
        v: 1,
        id: meetingId,
        text: transcript,
        source: "user_edit",
        silence_cut: true,
      })
    }
    sendMinutesJob(meetingId)
  }

  const copyMinutes = async () => {
    if (!minutesMd) return
    try {
      await navigator.clipboard.writeText(minutesMd)
      setStatus("已复制纪要")
    } catch {
      setError("复制失败")
    }
  }

  const localReadyLabel = !companionConnected
    ? "Companion 未连接"
    : !localModelReady || !localBinaryReady
      ? "本机 STT 未就绪"
      : "本机 STT 就绪"

  return (
    <div
      data-testid="meeting-panel"
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 10,
        padding: 12,
        height: "100%",
        overflow: "auto",
        background: tokens.bgElevated,
        color: tokens.text,
        fontSize: 13,
      }}
    >
      <fieldset disabled={closing} style={{ display: "contents" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <strong style={{ flex: 1, fontSize: 15 }}>会议记录</strong>
        <span style={{ fontSize: 11, color: tokens.textSecondary }}>
          实验可标发言人N · 非身份识别
        </span>
        <button
          type="button"
          onClick={() => {
            if (props.registerBeforeClose) props.onClose()
            else void requestCloseRef.current().then(allowed => { if (allowed) props.onClose() })
          }}
          title="结束录制并收起面板"
          aria-label="结束录制并收起面板"
          style={{
            border: `1px solid ${tokens.border}`,
            background: "transparent",
            borderRadius: 6,
            padding: "2px 8px",
            cursor: "pointer",
            color: tokens.textSecondary,
            fontSize: 12,
          }}
        >
          结束并收起
        </button>
      </div>
      {closing && <div role="status" aria-live="polite">正在保存最后一段转写，完成后收起…</div>}

      <div style={{ fontSize: 11, color: tokens.textSecondary, lineHeight: 1.45 }}>
        粘贴 / 上传转写，或显式「开始录制」本机分段转写（最长约{" "}
        {Math.round(MEETING_LIVE_HARD_CAP_MS / 60_000)} 分钟；约 2 小时软提示）。
        {nearRealtime
          ? " 默认近实时出字（渐进假设，约 8 秒定稿；large 模型仅终稿）。"
          : " 当前为分段终稿模式（可在设置开启实时出字）。"}
        应用场景不会自动开麦。录音与听写互斥。说话人：手动标或实验性自动「发言人N」（非真名识别）；系统混音未支持。
        段与段之间自动空行分段；可开「录制 AI 纠错」用上文消歧同音字（需已配置 LLM）。
      </div>

      {/* Path B: meeting live STT / audio import requires voice_privacy_ack_v2.
          Previously only reachable via Settings → 启用本机转写 (easy to miss). */}
      {!state.voicePrivacyAckV2 && (
        <div
          data-testid="meeting-voice-privacy-v2"
          style={{
            border: `1px solid ${tokens.border}`,
            borderRadius: 8,
            padding: 10,
            fontSize: 11,
            lineHeight: 1.45,
            color: tokens.textSecondary,
          }}
        >
          <div style={{ marginBottom: 6, color: tokens.text, fontWeight: 500 }}>
            本机语音隐私说明
          </div>
          <p style={{ margin: "0 0 6px", fontSize: 10 }}>
            会议本机录音 / 上传音频转写前须确认。也可在：侧栏 ⋯ → 设置 → 输入与语音 →
            「启用本机转写」。
          </p>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {VOICE_PRIVACY_ACK_V2_CLAUSES.map((c) => (
              <li key={c.slice(0, 24)}>{c}</li>
            ))}
          </ul>
          <button
            type="button"
            data-testid="meeting-voice-privacy-v2-accept"
            onClick={() => {
              dispatch({ type: "SET_VOICE_PRIVACY_ACK_V2", ack: true })
              setError(null)
              // Companion refuses voice.stt.* unless sttEngine=local — flip if model ready.
              if (localModelReady && localBinaryReady) {
                // Companion validate requires source:"settings" for set_engine (settings dual fence).
                sendViaRuntime({
                  type: "voice.model.set_engine",
                  engine: "local",
                  privacy_ack_v2: true,
                  source: "settings",
                })
              }
            }}
            style={{ ...btnStyle(true), marginTop: 8, padding: "4px 10px", fontSize: 12 }}
          >
            同意本机语音隐私说明
            {localModelReady && localBinaryReady ? "并启用本机转写" : ""}
          </button>
          {!localModelReady || !localBinaryReady ? (
            <div style={{ marginTop: 6, fontSize: 10, color: tokens.warning }}>
              模型或本机组件未就绪时：侧栏 ⋯ → 设置 → 输入与语音 → 下载组件/模型 → 启用本机转写。
            </div>
          ) : null}
        </div>
      )}

      {!ack && (
        <div
          style={{
            border: `1px solid ${tokens.border}`,
            borderRadius: 8,
            padding: 10,
            fontSize: 11,
            lineHeight: 1.45,
            color: tokens.textSecondary,
          }}
        >
          <div style={{ marginBottom: 6, color: tokens.text, fontWeight: 500 }}>
            会议隐私说明
          </div>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            <li>会创建本地会话产物（转写 ± 可选音频）。</li>
            <li>默认结束录制后删除会议目录下音频（当前 UI 不提供保留选项）。</li>
            <li>生成纪要将把转写文本发给你已配置的 LLM。</li>
            <li>长会 STT 仅本机；不会自动开始录音。</li>
            <li>多方录音法律合规由你负责。</li>
          </ul>
          <button
            type="button"
            onClick={acceptAck}
            style={{ ...btnStyle(true), marginTop: 8, padding: "4px 10px", fontSize: 12 }}
          >
            我已了解
          </button>
        </div>
      )}

      <label style={{ fontSize: 12 }}>
        标题
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="可选"
          disabled={capturing}
          style={{
            display: "block",
            width: "100%",
            marginTop: 4,
            padding: "6px 8px",
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            boxSizing: "border-box",
          }}
        />
      </label>

      <div
        data-testid="meeting-capture-bar"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 8,
          alignItems: "center",
          padding: "8px 10px",
          borderRadius: 8,
          border: `1px solid ${capturing ? tokens.accent : tokens.border}`,
          background: tokens.bg,
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 500 }}>
          {capturing ? (
            <>
              <span style={{ color: "#c44" }}>●</span> 录制中 {formatElapsed(elapsedMs)}
              {capturePhase === "processing" ? " · 分段识别中…" : ""}
              {capturePhase === "starting" ? " · 启动中…" : ""}
              {capturePhase === "stopping" ? " · 结束中…" : ""}
              {refinePending > 0 ? ` · AI 纠错中(${refinePending})` : ""}
            </>
          ) : (
            "未录制"
          )}
        </span>
        <span style={{ fontSize: 11, color: tokens.textSecondary }}>{localReadyLabel}</span>
        {softCapHint && capturing && (
          <span style={{ fontSize: 11, color: "#b8860b" }}>
            已超过 {Math.round(MEETING_LIVE_SOFT_CAP_MS / 60_000)} 分钟软提示（硬上限{" "}
            {Math.round(MEETING_LIVE_HARD_CAP_MS / 60_000)} 分钟）
          </span>
        )}
        {state.dictationCaptureActive && !capturing && (
          <span style={{ fontSize: 11, color: "#c44" }}>听写占用中</span>
        )}
      </div>

      <div
        data-testid="meeting-live-options"
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: 12,
          fontSize: 11,
          color: tokens.textSecondary,
          alignItems: "center",
        }}
      >
        <label
          style={{ display: "flex", gap: 4, alignItems: "center", cursor: "pointer" }}
          title="段末将转写发给已配置 LLM 做 correct_only 纠错（同听写 ASR 纠错开关）；会参考上文消歧同音字"
        >
          <input
            type="checkbox"
            data-testid="meeting-asr-refine"
            checked={state.asrRefinerEnabled === true}
            disabled={capturing}
            onChange={(e) =>
              dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: e.target.checked })
            }
          />
          录制 AI 纠错（参考上文）
        </label>
        <label
          style={{ display: "flex", gap: 4, alignItems: "center", cursor: "pointer" }}
          title="结束录制后自动按静音/段落规则切分转写"
        >
          <input
            type="checkbox"
            data-testid="meeting-auto-segment-stop"
            checked={autoSegmentOnStop}
            onChange={(e) => setAutoSegmentOnStop(e.target.checked)}
          />
          结束时智能分段
        </label>
        {state.asrRefinerEnabled === true && (
          <span style={{ fontSize: 10, color: tokens.warning }}>
            纠错走 Companion LLM；失败时保留原文
          </span>
        )}
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button type="button" disabled={busy || capturing} onClick={createMeeting} style={btnStyle(false)}>
          新建会议会话
        </button>
        {!capturing ? (
          <button
            type="button"
            data-testid="meeting-start-capture"
            disabled={busy || !ack || !state.voicePrivacyAckV2}
            onClick={startLiveCapture}
            style={btnStyle(true)}
            title={
              !ack || !state.voicePrivacyAckV2
                ? "请先确认本机语音隐私与会议隐私说明"
                : undefined
            }
          >
            开始录制
          </button>
        ) : (
          <>
            <button
              type="button"
              data-testid="meeting-stop-capture"
              onClick={() => stopLiveCapture(false)}
              style={btnStyle(false)}
            >
              结束录制
            </button>
            <button
              type="button"
              data-testid="meeting-stop-and-generate"
              onClick={() => stopLiveCapture(true)}
              style={btnStyle(true)}
            >
              结束并生成纪要
            </button>
          </>
        )}
        {meetingId && (
          <span style={{ fontSize: 11, color: tokens.textSecondary, alignSelf: "center" }}>
            id: {meetingId.slice(0, 12)}… · {status}
          </span>
        )}
      </div>

      {/* Mtg2: speaker + import */}
      <div
        data-testid="meeting-mtg2-tools"
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 8,
          padding: 10,
          borderRadius: 8,
          border: `1px solid ${tokens.border}`,
          background: tokens.bg,
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 500 }}>说话人 / 导入（Mtg2+3）</div>
        <label style={{ fontSize: 11, color: tokens.textSecondary }}>
          默认说话人标签（录制/导入 STT 追加时使用；可整表批量）
          <input
            data-testid="meeting-default-speaker"
            value={defaultSpeaker}
            onChange={(e) => setDefaultSpeaker(e.target.value)}
            placeholder='如「我」或「张三」'
            disabled={capturing}
            style={{
              display: "block",
              width: "100%",
              marginTop: 4,
              padding: "6px 8px",
              borderRadius: 6,
              border: `1px solid ${tokens.border}`,
              background: tokens.bgElevated,
              color: tokens.text,
              boxSizing: "border-box",
              fontSize: 12,
            }}
          />
        </label>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
          <label style={{ fontSize: 11, color: tokens.textSecondary }}>
            聚类 K
            <select
              data-testid="meeting-diarize-k"
              value={diarizeK}
              disabled={busy || capturing}
              onChange={(e) => setDiarizeK(Math.min(6, Math.max(0, Number(e.target.value) || 0)))}
              style={{ marginLeft: 4, fontSize: 12 }}
            >
              <option value={0}>自动</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
              <option value={5}>5</option>
              <option value={6}>6</option>
            </select>
          </label>
          <span style={{ fontSize: 10, color: tokens.textSecondary }}>
            「自动」按说话人嵌入聚类估计人数（本机 · 实验 · 只标发言人N，非身份识别）
          </span>
          <label style={{ fontSize: 11, color: tokens.textSecondary, display: "flex", gap: 4, alignItems: "center" }}>
            <input
              type="checkbox"
              checked={autoDiarizeAfterImport}
              disabled={busy || capturing}
              onChange={(e) => setAutoDiarizeAfterImport(e.target.checked)}
            />
            音频导入后自动标（实验）
          </label>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          <button
            type="button"
            data-testid="meeting-silence-cut"
            disabled={busy || capturing || !ack}
            onClick={applySilenceCut}
            style={btnStyle(false)}
            title="按空行/句号/长度软切分段（非说话人识别）"
          >
            智能分段
          </button>
          <button
            type="button"
            data-testid="meeting-bulk-speaker"
            disabled={busy || capturing || !ack}
            onClick={bulkLabelSpeaker}
            style={btnStyle(false)}
          >
            全部标为默认
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-audio"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("embedding")}
            style={btnStyle(true)}
            title="上传音频段 → 本机 ONNX 说话人嵌入 + 聚类；只标匿名发言人N，非身份识别（需先在 设置 → 输入与语音 → 听写方式 下载说话人分离模型）"
          >
            自动标说话人
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-legacy"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("audio_cluster")}
            style={btnStyle(false)}
            title="旧版回退：上传音频段 → 本机 3 维声学特征 + 聚类（区分度低 · 实验性 · 无需下载模型）；只标匿名发言人N，非身份识别"
          >
            旧版 3 维（区分度低）
          </button>
          <button
            type="button"
            data-testid="meeting-auto-diarize-text"
            disabled={busy || capturing || !ack}
            onClick={() => runAutoDiarize("text_gap")}
            style={btnStyle(false)}
            title="弱：按行交替发言人N，非声学"
          >
            弱标（交替）
          </button>
          <button
            type="button"
            data-testid="meeting-import-text"
            disabled={busy || capturing || !ack}
            onClick={() => textFileRef.current?.click()}
            style={btnStyle(false)}
          >
            上传转写文件
          </button>
          <button
            type="button"
            data-testid="meeting-import-audio"
            disabled={busy || capturing || !ack}
            onClick={() => audioFileRef.current?.click()}
            style={btnStyle(false)}
          >
            上传音频转写
          </button>
          {busy && importStatus?.includes("本机转写") && (
            <button
              type="button"
              data-testid="meeting-import-abort"
              onClick={() => {
                importAbortRef.current = true
                setImportStatus("正在中止…")
              }}
              style={btnStyle(false)}
            >
              中止导入
            </button>
          )}
        </div>
        <input
          ref={textFileRef}
          type="file"
          accept=".txt,.md,text/plain,text/markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0] || null
            e.target.value = ""
            void onImportTextFile(f)
          }}
        />
        <input
          ref={audioFileRef}
          type="file"
          accept="audio/*,.wav,.mp3,.m4a,.ogg,.webm"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0] || null
            e.target.value = ""
            void onImportAudioFile(f)
          }}
        />
        {importStatus && (
          <div style={{ fontSize: 11, color: tokens.textSecondary }} data-testid="meeting-import-status">
            {importStatus}
          </div>
        )}
        <div style={{ fontSize: 10, color: tokens.textSecondary, lineHeight: 1.4 }}>
          「自动标说话人」= 本机段特征 k-means → 匿名「发言人N」，
          <strong>不是</strong>身份识别，也非 Otter 级 SLA。默认覆盖已有标签（可再手改）。
          弱标仅按行交替。系统混音见 parking 调研。
        </div>
      </div>

      <label style={{ fontSize: 12, flex: 1, display: "flex", flexDirection: "column" }}>
        转写 / 口述文字（可编辑 · 支持「说话人: 正文」）
        <textarea
          value={transcript}
          onChange={(e) => {
            transcriptDirtyRef.current = true
            setTranscript(e.target.value)
          }}
          placeholder="粘贴会议转写，或开始录制/上传后自动填入…&#10;张三: 第一段&#10;&#10;李四: 第二段"
          rows={8}
          style={{
            marginTop: 4,
            width: "100%",
            flex: 1,
            minHeight: 120,
            padding: 8,
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            resize: "vertical",
            boxSizing: "border-box",
            fontFamily: "inherit",
            fontSize: 12,
            lineHeight: 1.45,
          }}
        />
        {capturing ? (
          <div
            data-testid="meeting-interim"
            style={{
              marginTop: 6,
              padding: "8px 10px",
              borderRadius: 8,
              background: tokens.accentSoft,
              border: `1px solid rgba(79, 70, 229, 0.16)`,
              fontSize: 13,
              color: tokens.accentText,
              lineHeight: 1.45,
              maxHeight: 96,
              overflow: "auto",
              whiteSpace: "pre-wrap",
            }}
          >
            {meetingLiveInterimHint({
              phase: capturePhase,
              interimText,
              nearRealtime,
              refinePending,
            })}
          </div>
        ) : null}
      </label>

      <details style={{ fontSize: 12 }}>
        <summary style={{ cursor: "pointer", color: tokens.textSecondary }}>
          纪要模板（可选）
        </summary>
        <p style={{ fontSize: 10, color: tokens.textSecondary, margin: "6px 0" }}>
          模板只约束输出结构；不会改变「不得臆造」规则。生成时把转写文本发给已配置 LLM。
        </p>
        <textarea
          value={templateMd}
          onChange={(e) => {
            const v = e.target.value
            setTemplateMd(v)
            templateMdRef.current = v
          }}
          placeholder={"### TL;DR\n\n### 决议\n\n### 待办\n\n### 风险 / 开放问题"}
          rows={5}
          style={{
            marginTop: 4,
            width: "100%",
            minHeight: 80,
            padding: 8,
            borderRadius: 6,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.text,
            resize: "vertical",
            boxSizing: "border-box",
            fontFamily: "inherit",
            fontSize: 12,
            lineHeight: 1.45,
          }}
        />
        <button
          type="button"
          onClick={() => {
            setTemplateMd("")
            templateMdRef.current = ""
            saveMeetingTemplate("")
          }}
          style={{
            marginTop: 6,
            fontSize: 11,
            padding: "4px 8px",
            borderRadius: 4,
            border: `1px solid ${tokens.border}`,
            background: tokens.bg,
            color: tokens.textSecondary,
            cursor: "pointer",
          }}
        >
          恢复默认
        </button>
      </details>

      <button type="button" disabled={busy || !ack || capturing} onClick={generate} style={btnStyle(true)}>
        {busy || pendingGenerate ? "生成中…" : "生成会议纪要"}
      </button>

      {error && (
        <div style={{ color: "#c44", fontSize: 12 }} role="alert">
          {error}
        </div>
      )}

      {minutesMd && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <strong style={{ flex: 1, fontSize: 12 }}>纪要</strong>
            <button type="button" onClick={copyMinutes} style={linkBtn}>
              复制
            </button>
            <button type="button" onClick={() => props.onSendToDraft(minutesMd)} style={linkBtn}>
              发送到对话草稿
            </button>
          </div>
          <pre
            style={{
              margin: 0,
              padding: 10,
              borderRadius: 8,
              border: `1px solid ${tokens.border}`,
              background: tokens.bg,
              fontSize: 11,
              lineHeight: 1.45,
              whiteSpace: "pre-wrap",
              maxHeight: 280,
              overflow: "auto",
            }}
          >
            {minutesMd}
          </pre>
        </div>
      )}
      </fieldset>
    </div>
  )
}

function btnStyle(primary: boolean): CSSProperties {
  return {
    border: primary ? "none" : `1px solid ${tokens.border}`,
    background: primary ? tokens.accent : "transparent",
    color: primary ? "#fff" : tokens.text,
    borderRadius: 8,
    padding: "8px 12px",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 500,
  }
}

const linkBtn: CSSProperties = {
  border: "none",
  background: "transparent",
  color: tokens.accent,
  cursor: "pointer",
  fontSize: 11,
  textDecoration: "underline",
  padding: 0,
}

FULL SOURCE chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
// ContextPanelHost — single owner of context panel state, loaders, mounts,
// and cmspark:open-context-panel (UIUX v2 §4.7 M1). Host is SoT for panels.
// #321 PR-1: legacy permanent BottomBar tab strip deleted (was PR5-gated off).

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
} from "react"
import { useAgentStore } from "../store/agentStore"
import {
  contextBarTabsForLevel,
  contextBarOverflowTabsForLevel,
} from "../mode/mode-controller"
import type { CapabilityLevel } from "../types"
import { KnowledgeSubPanel } from "./KnowledgeSubPanel"
import { McpPanel } from "./McpPanel"
import { AppsPanel } from "./AppsPanel"
import { PacksPanel } from "./PacksPanel"
import { BoardPanel } from "./BoardPanel"
import { MeetingPanel } from "./MeetingPanel"
import { tokens } from "../ui/tokens"
import {
  IconTabs,
  IconHistory,
  IconSkills,
  IconKnowledge,
  IconMcp,
  IconApps,
  IconPacks,
  IconMic,
  IconList,
} from "../ui/icons"

// ── Registry ───────────────────────────────────────────────────────────────

export type ContextPanelId =
  | "tabs"
  | "history"
  | "skills"
  | "knowledge"
  | "packs"
  | "board"
  | "mcp"
  | "apps"
  | "meeting"

export type ContextPanelTabDef = {
  id: ContextPanelId
  label: string
  Icon: ComponentType<{ size?: number }>
}

/** Canonical panel registry (labels + icons). Strip and Host share this. */
// #321 PR-5: packs/meeting/board each get their own icon (were all IconSkills
// collisions); icons come from the existing ui/icons set — nothing new drawn.
export const CONTEXT_PANEL_TABS: ContextPanelTabDef[] = [
  { id: "tabs", label: "浏览器标签页", Icon: IconTabs },
  { id: "history", label: "历史", Icon: IconHistory },
  { id: "skills", label: "技能", Icon: IconSkills },
  { id: "knowledge", label: "知识", Icon: IconKnowledge },
  { id: "packs", label: "场景与专家", Icon: IconPacks },
  { id: "meeting", label: "会议", Icon: IconMic },
  { id: "board", label: "任务板", Icon: IconList },
  { id: "mcp", label: "MCP", Icon: IconMcp },
  { id: "apps", label: "应用", Icon: IconApps },
]

const KNOWN_IDS = new Set(CONTEXT_PANEL_TABS.map((t) => t.id))

export function isContextPanelId(id: string): id is ContextPanelId {
  return KNOWN_IDS.has(id as ContextPanelId)
}

export function contextPanelLabel(id: ContextPanelId): string {
  return CONTEXT_PANEL_TABS.find((t) => t.id === id)?.label ?? id
}

// ── Loaders ────────────────────────────────────────────────────────────────

export function loadPanelData(
  id: ContextPanelId,
  activeThreadId: string | null,
  dispatch: ReturnType<typeof useAgentStore>["dispatch"],
) {
  if (id === "tabs") {
    chrome.tabs.query({}, (tabs) => {
      dispatch({ type: "SET_TAB_LIST", tabs })
    })
  }
  if (id === "history") {
    chrome.runtime.sendMessage({ type: "history.query", limit: 50, thread_id: activeThreadId })
  }
  if (id === "skills") {
    // Force rescan when opening Skills — picks up Finder drops / external edits
    // even if mtime fingerprint was edge-case stale; cheap after ensureFresh path.
    chrome.runtime.sendMessage({ type: "skill.refresh" })
  }
  if (id === "knowledge") {
    chrome.runtime.sendMessage({ type: "knowledge.list" })
  }
  if (id === "packs") {
    chrome.runtime.sendMessage({ type: "pack.list" })
    chrome.runtime.sendMessage({ type: "modules.list" })
  }
  if (id === "mcp") {
    chrome.runtime.sendMessage({ type: "mcp.list" })
  }
  if (id === "apps") {
    chrome.runtime.sendMessage({ type: "apps.list" })
  }
}

// ── Host API context ───────────────────────────────────────────────────────

export type ContextPanelHostApi = {
  activePanel: ContextPanelId | null
  /** Toggle: same id closes; different id opens + loads. */
  openPanel: (id: ContextPanelId) => void
  /** Force-open (no toggle) — used by slash / custom events. */
  openPanelForce: (id: ContextPanelId) => void
  closePanel: () => void
  /** A recording panel can finish its last segment before navigation unmounts it. */
  registerBeforeClose: (guard: () => Promise<boolean>) => () => void
}

const ContextPanelHostContext = createContext<ContextPanelHostApi | null>(null)

export function useContextPanelHost(): ContextPanelHostApi {
  const ctx = useContext(ContextPanelHostContext)
  if (!ctx) {
    throw new Error("useContextPanelHost must be used within ContextPanelHostProvider")
  }
  return ctx
}

/** Soft read for optional chrome that may render outside provider in tests. */
export function useContextPanelHostOptional(): ContextPanelHostApi | null {
  return useContext(ContextPanelHostContext)
}

// ── Provider ───────────────────────────────────────────────────────────────

export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const activePanelRef = useRef(activePanel)
  activePanelRef.current = activePanel
  const beforeCloseRef = useRef<(() => Promise<boolean>) | null>(null)
  const transitionRef = useRef<Promise<boolean> | null>(null)
  const targetRef = useRef<ContextPanelId | null>(null)
  const transitionVersion = useRef(0)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId
  const activeThreadRef = useRef(activeThreadId)
  activeThreadRef.current = activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const registerBeforeClose = useCallback((guard: () => Promise<boolean>) => {
    beforeCloseRef.current = guard
    return () => { if (beforeCloseRef.current === guard) beforeCloseRef.current = null }
  }, [])

  const requestPanelChange = useCallback((id: ContextPanelId | null): Promise<boolean> => {
    targetRef.current = id
    transitionVersion.current += 1
    if (transitionRef.current) return transitionRef.current
    if (activePanelRef.current === id) {
      if (id) loadPanelData(id, activeThreadRef.current, dispatch)
      return Promise.resolve(true)
    }
    const apply = () => {
      const target = targetRef.current
      activePanelRef.current = target
      setActivePanel(target)
      if (target) loadPanelData(target, activeThreadRef.current, dispatch)
    }
    const guard = beforeCloseRef.current
    if (!guard) { apply(); return Promise.resolve(true) }
    const pending = Promise.resolve().then(guard).then(allowed => {
      if (allowed) apply()
      return allowed
    }, () => false).finally(() => { transitionRef.current = null })
    transitionRef.current = pending
    return pending
  }, [dispatch])

  const closePanel = useCallback(() => { void requestPanelChange(null) }, [requestPanelChange])

  useEffect(() => {
    if (!state.settingsOpen) return
    if (!beforeCloseRef.current) { closePanel(); return }
    // Keep the finishing/error state visible; open settings after a successful close.
    dispatch({ type: "SET_SETTINGS_OPEN", open: false })
    const pending = requestPanelChange(null)
    const version = transitionVersion.current
    void pending.then(allowed => {
      if (allowed && version === transitionVersion.current) dispatch({ type: "SET_SETTINGS_OPEN", open: true })
    })
  }, [state.settingsOpen, closePanel, dispatch, requestPanelChange])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      void requestPanelChange(id)
    },
    [requestPanelChange],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      void requestPanelChange(activePanelRef.current === id ? null : id)
    },
    [requestPanelChange],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      closePanel()
    }
  }, [activePanel, allowedIds, overflowIds, closePanel])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      openPanelForce(raw)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      openPanelForce("knowledge")
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      openPanelForce("knowledge")
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [openPanelForce])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      closePanel()
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel, closePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose }),
    [activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel, registerBeforeClose } = useContextPanelHost()
  const meetingCaptureActive = useAgentStore().state.meetingCaptureActive
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)
  const closeEndsMeeting = activePanel === "meeting" && meetingCaptureActive

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        {closeEndsMeeting ? (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="结束并收起"
            aria-label="结束并收起"
            onClick={closePanel}
          >
            结束并收起
          </button>
        ) : (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="收起面板 (Esc)"
            aria-label="收起面板"
            onClick={closePanel}
          >
            收起
          </button>
        )}
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          registerBeforeClose={registerBeforeClose}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}

// ── Built-in panel bodies (moved from BottomBar) ───────────────────────────

function TabsPanel() {
  const { state, dispatch } = useAgentStore()

  const handleTogglePin = (tabId: number) => {
    const pinnedTabIds = state.pinnedTabIds.includes(tabId)
      ? state.pinnedTabIds.filter((id) => id !== tabId)
      : [...state.pinnedTabIds, tabId]

    dispatch({ type: "SET_PINNED_TABS", tabIds: pinnedTabIds })

    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { pinned_tabs: pinnedTabIds },
      })
    }
  }

  return (
    <div style={styles.panelContent}>
      {state.tabList.length === 0 && (
        <div style={styles.emptyText}>暂无标签页数据</div>
      )}
      {state.tabList.map((tab) => (
        <label key={tab.id} style={styles.tabRow}>
          <input
            type="checkbox"
            checked={state.pinnedTabIds.includes(tab.id!)}
            onChange={() => handleTogglePin(tab.id!)}
            style={{ marginRight: 8 }}
          />
          <span style={styles.tabTitle}>{tab.title || tab.url}</span>
          <span style={styles.tabUrl}>{tab.id}</span>
        </label>
      ))}
    </div>
  )
}

function HistoryPanel() {
  const { state } = useAgentStore()
  const operations = state.operations || []
  const groups = groupBy(operations, "thread_id")

  return (
    <div style={styles.panelContent}>
      {state.operations.length === 0 && (
        <div style={styles.emptyText}>暂无操作历史</div>
      )}
      {Object.entries(groups).map(([threadId, ops]) => (
        <div key={threadId} style={{ marginBottom: 8 }}>
          <div style={styles.groupHeader}>#{threadId}</div>
          {ops.map((op) => (
            <div key={op.id} style={styles.historyRow}>
              <span style={{ color: op.success ? tokens.success : tokens.danger }}>
                {op.success ? "✓" : "✗"}
              </span>
              <span style={{ flex: 1, marginLeft: 6, fontFamily: "monospace", fontSize: 11 }}>
                {op.tool_name}
              </span>
              <span style={{ color: tokens.textMuted, fontSize: 11 }}>
                {op.created_at?.slice(11, 19)}
              </span>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

function SkillsPanel() {
  const { state, dispatch } = useAgentStore()
  const [importUrl, setImportUrl] = useState("")
  const [showUrlImport, setShowUrlImport] = useState(false)
  const [showPathImport, setShowPathImport] = useState(false)
  const [pathInput, setPathInput] = useState("")
  const [menuOpen, setMenuOpen] = useState<string | null>(null)
  const [currentHostname, setCurrentHostname] = useState<string>("")
  const menuRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const zipInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url
      if (url) {
        try {
          setCurrentHostname(new URL(url).hostname)
        } catch {
          setCurrentHostname("")
        }
      }
    })
  }, [state.tabList])

  const handleModeChange = (mode: "auto" | "all" | "manual") => {
    dispatch({ type: "SET_SKILL_SELECTION_MODE", mode })
    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { skill_selection_mode: mode },
      })
    }
  }

  useEffect(() => {
    if (!menuOpen) return
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(null)
      }
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [menuOpen])

  const handleFolderFiles = async (files: FileList | File[]) => {
    const fileArr = Array.from(files)
    if (fileArr.length === 0) return

    const hasSkillMd = fileArr.some(
      (f) => f.name === "SKILL.md" || f.webkitRelativePath.endsWith("/SKILL.md"),
    )
    if (!hasSkillMd) {
      alert("文件夹中未找到 SKILL.md 文件")
      return
    }

    const payload: { path: string; content: string }[] = []
    for (const file of fileArr) {
      const content = await file.text()
      const filePath = file.webkitRelativePath || file.name
      const parts = filePath.split("/")
      const relPath = parts.length > 1 ? parts.slice(1).join("/") : parts[0]
      payload.push({ path: relPath, content })
    }

    chrome.runtime.sendMessage({ type: "skill.import-files", files: payload })
  }

  const handlePathImport = () => {
    if (pathInput.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import-path", dir_path: pathInput.trim() })
      setPathInput("")
      setShowPathImport(false)
    }
  }

  const handleExport = (skillName: string) => {
    chrome.runtime.sendMessage({ type: "skill.export", skill_name: skillName })
    setMenuOpen(null)
  }

  const handleDelete = (skillName: string) => {
    if (confirm(`确定删除技能 "${skillName}"？`)) {
      chrome.runtime.sendMessage({ type: "skill.delete", skill_name: skillName })
    }
    setMenuOpen(null)
  }

  const handleImportFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const content = reader.result as string
      chrome.runtime.sendMessage({ type: "skill.import", content })
    }
    reader.readAsText(file)
  }

  const handleImportZip = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = reader.result as string
      const base64 = dataUrl.split(",")[1]
      if (base64) {
        chrome.runtime.sendMessage({ type: "skill.import-folder", zip_data: base64 })
      }
    }
    reader.readAsDataURL(file)
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()

    const items = e.dataTransfer.items
    if (items && items.length > 0) {
      const entry = items[0].webkitGetAsEntry()
      if (entry && entry.isDirectory) {
        const files = await readDirectoryEntry(entry as FileSystemDirectoryEntry)
        if (files.length > 0) {
          handleFolderFiles(files)
        }
        return
      }
    }

    const file = e.dataTransfer.files[0]
    if (!file) return
    if (file.name.endsWith(".zip")) {
      handleImportZip(file)
    } else if (file.name.endsWith(".md") || file.name.endsWith(".markdown")) {
      handleImportFile(file)
    }
  }

  const handleUrlImport = () => {
    if (importUrl.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import", url: importUrl.trim() })
      setImportUrl("")
      setShowUrlImport(false)
    }
  }

  const skillList = Array.isArray(state.skills) ? state.skills : []
  const groupedSkills = groupSkillsBySite(skillList, currentHostname)

  const modeLabels: Record<string, string> = { auto: "自动", all: "全选", manual: "按需" }
  const skillMode = state.skillSelectionMode || "auto"
  const skillManual = skillMode === "manual"
  const skillModeHint =
    skillMode === "auto"
      ? "自动：按站点/消息匹配技能，列表勾选不生效（未勾选 ≠ 不会调用）。"
      : skillMode === "all"
        ? "全选：全部技能参与索引，无需单独勾选。"
        : "按需：仅勾选的技能会参与本对话。"

  return (
    <div style={styles.panelContent}>
      <div style={styles.modeSwitcher}>
        {(["auto", "all", "manual"] as const).map((mode) => (
          <button
            key={mode}
            style={{
              ...styles.modeBtn,
              background: skillMode === mode ? tokens.accent : tokens.bgElevated,
              color: skillMode === mode ? "#fff" : tokens.textSecondary,
              borderColor: skillMode === mode ? tokens.accent : tokens.border,
            }}
            onClick={() => handleModeChange(mode)}
            title={
              mode === "auto"
                ? "自动匹配当前站点和消息"
                : mode === "all"
                  ? "注入所有技能索引"
                  : "仅使用勾选技能"
            }
          >
            {modeLabels[mode]}
          </button>
        ))}
      </div>
      <div
        style={{
          fontSize: 10,
          color: tokens.textMuted,
          lineHeight: 1.4,
          marginBottom: 8,
        }}
      >
        {skillModeHint}
      </div>

      <div
        style={{
          fontSize: 10,
          color: tokens.textSecondary,
          lineHeight: 1.4,
          marginBottom: 8,
          padding: "6px 8px",
          background: tokens.accentSoft,
          borderRadius: tokens.radiusSm,
          border: `1px solid ${tokens.border}`,
        }}
      >
        <strong style={{ color: tokens.accentText }}>安装技能（推荐）</strong>
        <div style={{ marginTop: 3 }}>
          GitHub 仓库：下载 ZIP → <strong>导入 ZIP</strong>；或解压后用{" "}
          <strong>导入文件夹</strong>。单文件 skill 用「导入」.md。
        </div>
        <div style={{ marginTop: 3, color: tokens.textMuted }}>
          勿用「场景」里的「应用安全审查」装技能 — 那会限制本对话工具。
        </div>
      </div>

      <div style={styles.skillToolbar}>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => chrome.runtime.sendMessage({ type: "skill.refresh" })}
          title="重新扫描技能目录（含 ~/.cmspark-agent/skills 外部变更）"
        >
          ↻ 刷新
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => fileInputRef.current?.click()}
          title="从文件导入 .md"
        >
          📁 导入
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => zipInputRef.current?.click()}
          title="从 ZIP 导入文件夹技能"
        >
          📦 导入 ZIP
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowPathImport(!showPathImport)}
          title="从文件夹导入"
        >
          📂 导入文件夹
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowUrlImport(!showUrlImport)}
          title="从 URL 导入"
        >
          🔗 URL
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".md,.markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportFile(file)
          }}
        />
        <input
          ref={zipInputRef}
          type="file"
          accept=".zip"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportZip(file)
          }}
        />
      </div>

      {showUrlImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="url"
            placeholder="https://...skill.md"
            value={importUrl}
            onChange={(e) => setImportUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleUrlImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handleUrlImport}>
            安装
          </button>
        </div>
      )}

      {showPathImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="text"
            placeholder="~/.claude/skills/datayes-api-search 或绝对路径"
            value={pathInput}
            onChange={(e) => setPathInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handlePathImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handlePathImport}>
            导入
          </button>
        </div>
      )}

      <div
        style={styles.dropZone}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        {skillList.length === 0 && (
          <div style={styles.emptyText}>暂无技能，拖拽 .md 文件或点击导入</div>
        )}
      </div>

      {groupedSkills.map(([groupName, skills]) => (
        <div key={groupName}>
          <div style={styles.groupHeader}>{groupName}</div>
          {skills.map((skill) => {
            const active = state.activeSkillIds.includes(skill.name)
            return (
              <div
                key={skill.name}
                style={{
                  ...styles.skillRow,
                  background: skillManual && active ? tokens.bgActive : "transparent",
                }}
              >
                {skillManual ? (
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={() => {
                      const activeSkillIds = active
                        ? state.activeSkillIds.filter((id) => id !== skill.name)
                        : [...state.activeSkillIds, skill.name]
                      dispatch({ type: "TOGGLE_SKILL", skillId: skill.name })
                      if (state.activeThreadId) {
                        chrome.runtime.sendMessage({
                          type: "thread.update",
                          threadId: state.activeThreadId,
                          updates: { active_skill_ids: activeSkillIds },
                        })
                      }
                    }}
                    style={{ marginRight: 8, flexShrink: 0 }}
                    title="勾选后参与本对话"
                  />
                ) : (
                  <span
                    style={{
                      width: 16,
                      textAlign: "center",
                      color: tokens.textMuted,
                      fontSize: 11,
                      flexShrink: 0,
                      marginRight: 4,
                    }}
                    title={
                      skillMode === "all"
                        ? "全选模式：全部参与索引"
                        : "自动模式：由匹配决定，与勾选无关"
                    }
                    aria-hidden
                  >
                    {skillMode === "all" ? "◎" : "◇"}
                  </span>
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 500,
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    {skill.name}
                    {skill.site && <span style={styles.siteBadge}>{skill.site}</span>}
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      color: tokens.textSecondary,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {skill.description}
                  </div>
                </div>
                {skill.builtin && <span style={styles.badge}>内置</span>}
                {!skill.builtin && (
                  <div
                    style={{ position: "relative" }}
                    ref={menuOpen === skill.name ? menuRef : undefined}
                  >
                    <button
                      style={styles.menuBtn}
                      onClick={() => setMenuOpen(menuOpen === skill.name ? null : skill.name)}
                      title="更多操作"
                    >
                      ···
                    </button>
                    {menuOpen === skill.name && (
                      <div style={styles.menuDropdown}>
                        <button style={styles.menuItem} onClick={() => handleExport(skill.name)}>
                          📤 导出
                        </button>
                        <button
                          style={{ ...styles.menuItem, color: tokens.danger }}
                          onClick={() => handleDelete(skill.name)}
                        >
                          删除
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}

// ── Helpers ────────────────────────────────────────────────────────────────

async function readDirectoryEntry(dirEntry: FileSystemDirectoryEntry): Promise<File[]> {
  const files: File[] = []
  const folderName = dirEntry.name

  async function readDir(entry: FileSystemDirectoryEntry, prefix: string): Promise<void> {
    const reader = entry.createReader()
    const readBatch = (): Promise<FileSystemEntry[]> => {
      return new Promise((resolve) => {
        reader.readEntries((entries) => resolve(entries))
      })
    }

    let batch = await readBatch()
    while (batch.length > 0) {
      for (const e of batch) {
        if (e.isFile) {
          const file = await new Promise<File>((resolve) => {
            ;(e as FileSystemFileEntry).file(resolve)
          })
          ;(file as File & { webkitRelativePath: string }).webkitRelativePath = prefix + e.name
          files.push(file)
        } else if (e.isDirectory) {
          await readDir(e as FileSystemDirectoryEntry, prefix + e.name + "/")
        }
      }
      batch = await readBatch()
    }
  }

  await readDir(dirEntry, folderName + "/")
  return files
}

function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> {
  return arr.reduce(
    (acc, item) => {
      const k = String(item[key] ?? "unknown")
      if (!acc[k]) acc[k] = []
      acc[k].push(item)
      return acc
    },
    {} as Record<string, T[]>,
  )
}

type SkillListItem = {
  name: string
  description?: string
  site?: string
  builtin?: boolean
}

function groupSkillsBySite(
  skills: SkillListItem[],
  currentHostname: string,
): [string, SkillListItem[]][] {
  const list = Array.isArray(skills) ? skills : []
  const globalSkills = list.filter((s) => !s.site)
  const siteGroups = new Map<string, SkillListItem[]>()
  for (const skill of list.filter((s) => s.site)) {
    const key = skill.site!
    if (!siteGroups.has(key)) siteGroups.set(key, [])
    siteGroups.get(key)!.push(skill)
  }
  const result: [string, SkillListItem[]][] = []
  if (globalSkills.length > 0) {
    result.push(["全局", globalSkills])
  }
  const sortedSites = Array.from(siteGroups.entries()).sort((a, b) => {
    const aMatch = currentHostname && matchesSite(a[0], currentHostname) ? -1 : 0
    const bMatch = currentHostname && matchesSite(b[0], currentHostname) ? -1 : 0
    if (aMatch !== bMatch) return aMatch - bMatch
    return a[0].localeCompare(b[0])
  })
  for (const [site, siteSkills] of sortedSites) {
    result.push([site, siteSkills])
  }
  return result
}

function matchesSite(pattern: string, hostname: string): boolean {
  if (pattern.startsWith("*.")) {
    const suffix = pattern.slice(2)
    return hostname === suffix || hostname.endsWith("." + suffix)
  }
  return hostname === pattern
}

// ── Styles (panel body only) ───────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  panel: {
    borderTop: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    // Apps「添加应用」needs room for search + policy + short list
    maxHeight: 320,
    overflowY: "auto",
    flexShrink: 0,
  },
  panelHeader: {
    position: "sticky",
    top: 0,
    zIndex: 2,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    padding: "6px 12px",
    background: tokens.bgElevated,
    borderBottom: `1px solid ${tokens.border}`,
  },
  panelTitle: {
    fontSize: 15,
    fontWeight: 600,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  panelCloseBtn: {
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusPill,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    fontSize: 11,
    fontWeight: 500,
    padding: "3px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
  },
  panelContent: {
    padding: "10px 12px",
  },
  emptyText: {
    color: tokens.textSecondary,
    fontSize: 12,
    textAlign: "center",
    padding: 12,
  },
  tabRow: {
    display: "flex",
    alignItems: "center",
    padding: "3px 0",
    cursor: "pointer",
    fontSize: 12,
  },
  tabTitle: {
    flex: 1,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  tabUrl: {
    color: tokens.textMuted,
    fontSize: 10,
    fontFamily: tokens.fontMono,
  },
  groupHeader: {
    fontSize: 11,
    fontWeight: 600,
    fontFamily: tokens.fontMono,
    color: tokens.accent,
    marginBottom: 2,
  },
  historyRow: {
    display: "flex",
    alignItems: "center",
    padding: "2px 0",
  },
  skillRow: {
    display: "flex",
    alignItems: "center",
    padding: "6px 0",
    borderBottom: `1px solid ${tokens.bgMuted}`,
  },
  badge: {
    fontSize: 10,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    padding: "1px 6px",
    borderRadius: tokens.radiusSm,
  },
  skillToolbar: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
    marginBottom: 8,
  },
  skillToolbarBtn: {
    whiteSpace: "nowrap",
    minHeight: 32,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    background: tokens.bgElevated,
    padding: "3px 10px",
    fontSize: 11,
    cursor: "pointer",
  },
  urlImportRow: {
    display: "flex",
    gap: 4,
    marginBottom: 8,
  },
  urlImportInput: {
    flex: 1,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    padding: "4px 8px",
    fontSize: 11,
    fontFamily: tokens.fontMono,
    outline: "none",
  },
  dropZone: {
    minHeight: 24,
  },
  menuBtn: {
    background: "none",
    border: "none",
    fontSize: 14,
    cursor: "pointer",
    padding: "0 4px",
    color: tokens.textMuted,
  },
  menuDropdown: {
    position: "absolute",
    right: 0,
    top: "100%",
    background: tokens.bgElevated,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: tokens.radiusMenu,
    boxShadow: tokens.shadowLg,
    zIndex: 10,
    overflow: "hidden",
    padding: 4,
    minWidth: 120,
  },
  menuItem: {
    display: "block",
    width: "100%",
    border: "none",
    background: "transparent",
    borderRadius: tokens.radiusMd,
    padding: "8px 12px",
    fontSize: 12,
    cursor: "pointer",
    textAlign: "left" as const,
    whiteSpace: "nowrap" as const,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  modeSwitcher: {
    display: "flex",
    gap: 0,
    marginBottom: 8,
    borderRadius: tokens.radiusSm,
    overflow: "hidden",
    border: `1px solid ${tokens.border}`,
  },
  modeBtn: {
    flex: 1,
    border: "none",
    borderRight: `1px solid ${tokens.border}`,
    padding: "4px 0",
    fontSize: 11,
    cursor: "pointer",
    background: tokens.bgElevated,
  },
  siteBadge: {
    fontSize: 9,
    background: tokens.accentSoft,
    color: tokens.accentText,
    padding: "0px 4px",
    borderRadius: tokens.radiusSm,
    fontWeight: 400,
  },
}

FULL SOURCE chrome-extension/src/sidepanel/components/ComposeDrawer.tsx
// 装配 drawer — full Composition section UI (UIUX v2 PR6 / §4.5).
// Opens Host panels; Board / Fleet / multi-worker are Autonomy — never listed.
// Shell via BottomSheet (focus trap + Escape from ui/Modal); landfill
// one-surface rule enforced by parent.
// G4: MD3-ish sheet (radiusSheet + soft scrim) + settings-list groups.

import {
  useRef,
  useState,
  type CSSProperties,
  type ComponentType,
  type RefObject,
} from "react"
import {
  COMPOSE_GROUP_LABELS,
  COMPOSE_SECTIONS,
  composeSectionGroups,
  composeSectionsInGroup,
  type ComposeSection,
  type ComposeSectionGroup,
  type ComposeSectionId,
} from "../composer/meta-slash"
import type { ContextPanelId } from "./ContextPanelHost"
import type { CapabilityLevel } from "../types"
import { tokens } from "../ui/tokens"
import { BottomSheet } from "./ui/BottomSheet"
import {
  IconApps,
  IconChevronRight,
  IconClose,
  IconHistory,
  IconKnowledge,
  IconMcp,
  IconPacks,
  IconSkills,
  type IconProps,
} from "../ui/icons"

const FIRST_SECTION_ID: ComposeSectionId = COMPOSE_SECTIONS[0]?.id ?? "skills"

const SECTION_SCOPE: Record<ComposeSectionId, string> = {
  skills: "管理全局技能；按需用于对话",
  knowledge: "管理知识库；选择本次对话使用的知识",
  packs: "管理场景与专家；选择本对话工作区",
  mcp: "管理全局 MCP 连接",
  apps: "管理全局应用连接",
  history: "查看与管理全部对话",
}

const SECTION_ICONS: Record<ComposeSection["id"], ComponentType<IconProps>> = {
  skills: IconSkills,
  knowledge: IconKnowledge,
  packs: IconPacks,
  mcp: IconMcp,
  apps: IconApps,
  history: IconHistory,
}

export type ComposeDrawerProps = {
  open: boolean
  onClose: () => void
  /** Open Host panel and close drawer. */
  onOpenSection: (panelId: ContextPanelId) => void
  /** Accepted for caller compatibility; resource configuration is not Surface-scoped. */
  capabilityLevel?: CapabilityLevel
}

export function ComposeDrawer({
  open,
  onClose,
  onOpenSection,
}: ComposeDrawerProps) {
  const firstBtnRef = useRef<HTMLButtonElement>(null)
  const groups = composeSectionGroups()

  const handleSection = (section: ComposeSection) => {
    // Defense: never open Autonomy surfaces from 装配
    if (section.panelId === "board") return
    onOpenSection(section.panelId)
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      ariaLabel="装配"
      initialFocusRef={firstBtnRef as RefObject<HTMLElement>}
    >
      <div data-testid="compose-drawer">
        <div style={styles.header}>
          <div style={{ minWidth: 0 }}>
            <div style={styles.title}>装配</div>
            <div style={styles.subtitle}>
              管理资源与连接，按需用于对话
            </div>
          </div>
          <button
            type="button"
            style={styles.closeBtn}
            onClick={onClose}
            aria-label="关闭装配"
            data-testid="compose-drawer-close"
          >
            <IconClose size={14} />
          </button>
        </div>

        {groups.map((group) => (
          <SectionGroup
            key={group}
            group={group}
            firstSectionId={FIRST_SECTION_ID}
            firstBtnRef={firstBtnRef}
            onOpen={handleSection}
          />
        ))}

        <p style={styles.footNote} data-testid="compose-autonomy-note">
          任务板可从“资料与工具”或 /board 打开
        </p>
      </div>
    </BottomSheet>
  )
}

function SectionGroup({
  group,
  firstSectionId,
  firstBtnRef,
  onOpen,
}: {
  group: ComposeSectionGroup
  firstSectionId: ComposeSectionId
  firstBtnRef: RefObject<HTMLButtonElement>
  onOpen: (section: ComposeSection) => void
}) {
  const sections = composeSectionsInGroup(group)
  if (sections.length === 0) return null

  return (
    <section style={styles.group} aria-labelledby={`compose-group-${group}`}>
      <h3 id={`compose-group-${group}`} style={styles.groupLabel}>
        {COMPOSE_GROUP_LABELS[group]}
      </h3>
      <ul style={styles.list} role="list">
        {sections.map((section, index) => {
          const Icon = SECTION_ICONS[section.id]
          return (
            <li
              key={section.id}
              style={{
                ...styles.listItem,
                borderTop: index > 0 ? `1px solid ${tokens.border}` : undefined,
              }}
            >
              <SectionRowButton
                section={section}
                Icon={Icon}
                attachLine={SECTION_SCOPE[section.id]}
                buttonRef={section.id === firstSectionId ? firstBtnRef : undefined}
                onOpen={onOpen}
              />
            </li>
          )
        })}
      </ul>
    </section>
  )
}

/** Settings-list row with hover (inline styles cannot use :hover). */
function SectionRowButton({
  section,
  Icon,
  attachLine,
  buttonRef,
  onOpen,
}: {
  section: ComposeSection
  Icon: ComponentType<IconProps>
  attachLine: string
  buttonRef?: RefObject<HTMLButtonElement>
  onOpen: (section: ComposeSection) => void
}) {
  const [hovered, setHovered] = useState(false)
  return (
    <button
      ref={buttonRef}
      type="button"
      style={{
        ...styles.sectionBtn,
        background: hovered ? tokens.bgHover : "transparent",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocus={() => setHovered(true)}
      onBlur={() => setHovered(false)}
      onClick={() => onOpen(section)}
      data-testid={`compose-section-${section.id}`}
    >
      <span style={styles.iconWrap} aria-hidden>
        <Icon size={16} />
      </span>
      <span style={styles.sectionBody}>
        <span style={styles.sectionTitleRow}>
          <span style={styles.sectionTitleZh}>{section.titleZh}</span>
          <span style={styles.sectionLabelEn}>{section.label}</span>
        </span>
        <span style={styles.sectionHint}>{section.hint}</span>
        <span style={styles.attachLine}>{attachLine}</span>
      </span>
      <IconChevronRight size={14} style={{ color: tokens.textMuted, flexShrink: 0 }} />
    </button>
  )
}

// Re-export for tests that import section list from drawer path (if any).
export { COMPOSE_SECTIONS }

const styles: Record<string, CSSProperties> = {
  header: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 8,
    padding: "0 16px 10px",
  },
  title: {
    fontSize: 16,
    fontWeight: 650,
    color: tokens.text,
    letterSpacing: "-0.02em",
  },
  subtitle: {
    fontSize: 11,
    color: tokens.textSecondary,
    marginTop: 3,
    lineHeight: 1.4,
  },
  closeBtn: {
    width: 30,
    height: 30,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusMd,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 0,
  },
  surfaceChip: {
    display: "inline-flex",
    margin: "0 16px 10px",
    padding: "3px 10px",
    borderRadius: tokens.radiusPill,
    background: tokens.accentSoft,
    color: tokens.accentText,
    fontSize: 10,
    fontWeight: 600,
    letterSpacing: "0.02em",
  },
  group: {
    margin: 0,
    padding: "0 0 10px",
  },
  groupLabel: {
    margin: "4px 16px 6px",
    fontSize: 10,
    fontWeight: 650,
    color: tokens.textMuted,
    textTransform: "uppercase" as const,
    letterSpacing: "0.06em",
  },
  /** G4: one elevated settings card per group (not a grid of caged buttons) */
  list: {
    listStyle: "none",
    margin: "0 12px",
    padding: 4,
    background: tokens.bg,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusLg,
    boxShadow: tokens.shadowSm,
    overflow: "hidden",
  },
  listItem: {
    margin: 0,
  },
  sectionBtn: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    width: "100%",
    textAlign: "left",
    border: "none",
    borderRadius: tokens.radiusMd,
    background: "transparent",
    padding: "10px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    transition: `background ${tokens.transitionFast} ease`,
  },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: tokens.radiusMd,
    background: tokens.accentSoft,
    color: tokens.accentText,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  sectionBody: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    gap: 2,
  },
  sectionTitleRow: {
    display: "flex",
    alignItems: "baseline",
    gap: 6,
  },
  sectionTitleZh: {
    fontSize: 13,
    fontWeight: 600,
    color: tokens.text,
  },
  sectionLabelEn: {
    fontSize: 10,
    fontWeight: 500,
    color: tokens.textMuted,
  },
  sectionHint: {
    fontSize: 11,
    color: tokens.textSecondary,
    lineHeight: 1.35,
  },
  attachLine: {
    fontSize: 10,
    color: tokens.accentText,
    marginTop: 1,
    lineHeight: 1.3,
  },
  footNote: {
    margin: "4px 16px 0",
    fontSize: 10,
    color: tokens.textMuted,
    lineHeight: 1.4,
  },
}

FULL SOURCE chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
/**
 * Path B — local STT adapter (gUM → WAV/PCM chunks → voice.stt.* WS).
 * classic: one shot ≤45s then onEnd.
 * continuous (D1c): serial segments ≤45s until hard cap or user stop.
 * continuous + streamPartial (M2): PCM stream + partial_request progressive hypothesis.
 */

import {
  LOCAL_STT_CHANNELS,
  LOCAL_STT_MAX_CHUNK_RAW_BYTES,
  LOCAL_STT_MAX_RECORD_MS,
  LOCAL_STT_NEAR_REALTIME_SEGMENT_MS,
  LOCAL_STT_SAMPLE_RATE,
} from "./local-stt-detect"
import { splitIntoChunks } from "./pcm-encode"
import {
  startCapture as defaultStartCapture,
  type CaptureHandle,
  type StartCaptureOpts,
} from "./audio-capture"
import {
  startPcmStreamCapture as defaultStartPcmStreamCapture,
  type PcmStreamCaptureOpts,
  type PcmStreamHandle,
} from "./pcm-stream-capture"
import {
  nextPartialPollMs,
  STREAM_PARTIAL_POLL_DEFAULT_MS,
} from "./stream-partial-poll"
import type {
  SpeechAdapter,
  SpeechAdapterHandlers,
  SpeechAdapterStartArg,
} from "./web-speech-adapter"
import {
  VOICE_CONTINUOUS_HARD_CAP_MS,
  VOICE_DEFAULT_LANG,
  type VoiceDictationMode,
} from "./detect"

export type LocalSttSend = (msg: Record<string, unknown>) => void

/** Subscribe to inbound companion messages; returns unsubscribe. */
export type LocalSttOnMessage = (handler: (msg: any) => void) => () => void

export type LocalSttAdapterDeps = {
  send: LocalSttSend
  onMessage: LocalSttOnMessage
  /**
   * Whisper model id. #259: optional for engineKind "system" (Windows SAPI
   * sessions carry no whisper model on the wire).
   */
  modelId?: string
  /** #259: "system" stamps voice.stt.start engine:"system" (per-session SAPI). */
  engineKind?: "local" | "system"
  startCapture?: (opts?: StartCaptureOpts) => Promise<CaptureHandle>
  startPcmStreamCapture?: (opts: PcmStreamCaptureOpts) => Promise<PcmStreamHandle>
  /**
   * Wall timeout waiting for voice.stt.result/error after end().
   * Companion infer cap is 90s; default a hair over that so a live infer can finish.
   */
  pendingTimeoutMs?: number
  /**
   * After user stop(), do not wait the full pendingTimeoutMs — Companion restart
   * mid-window used to leave meeting "正在听" forever because stop() while
   * waiting was a no-op until the missing ACK.
   */
  stopGraceMs?: number
}

/** Client wait for companion infer ACK (server STT_INFER_MAX_MS = 90s). */
export const LOCAL_STT_PENDING_TIMEOUT_MS = 95_000

/** After user stop, give the in-flight window this long then end anyway. */
export const LOCAL_STT_STOP_GRACE_MS = 12_000

/**
 * Soft-continue only for failures after end() when companion has dropBound.
 * NEVER soft-continue session_busy / resource_conflict / oom / binary_broken
 * without reclaiming the slot (adversary B F1/F2 + dual-review: binary_broken is sticky).
 */
export function isSoftSttSegmentError(code: string): boolean {
  const c = (code || "").toLowerCase()
  return (
    c === "infer_failed" ||
    c === "empty_result" ||
    c === "infer_timeout" ||
    c === "partial_skipped"
  )
}

/** Hard stop — do not keep mic open. */
export function isHardSttSegmentError(code: string): boolean {
  const c = (code || "").toLowerCase()
  return (
    c === "oom" ||
    c === "binary_broken" ||
    c === "model_missing" ||
    c === "binary_missing" ||
    c === "hash_fail" ||
    c === "engine_not_local" ||
    c === "need_privacy_ack" ||
    c === "origin_denied" ||
    c === "peer_mismatch"
  )
}

/** uint8 → base64 without Node Buffer (Side Panel / tests). */
export function uint8ToBase64(data: Uint8Array): string {
  const chunkSize = 0x8000
  let binary = ""
  for (let i = 0; i < data.length; i += chunkSize) {
    const slice = data.subarray(i, Math.min(i + chunkSize, data.length))
    binary += String.fromCharCode.apply(null, Array.from(slice) as number[])
  }
  if (typeof btoa === "function") {
    return btoa(binary)
  }
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  let out = ""
  for (let i = 0; i < data.length; i += 3) {
    const a = data[i]
    const b = i + 1 < data.length ? data[i + 1] : 0
    const c = i + 2 < data.length ? data[i + 2] : 0
    const triple = (a << 16) | (b << 8) | c
    out += alphabet[(triple >> 18) & 63]
    out += alphabet[(triple >> 12) & 63]
    out += i + 1 < data.length ? alphabet[(triple >> 6) & 63] : "="
    out += i + 2 < data.length ? alphabet[triple & 63] : "="
  }
  return out
}

type PendingWait = {
  sessionId: string
  resolve: (
    r: { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string },
  ) => void
}

export function createLocalSttAdapter(
  handlers: SpeechAdapterHandlers,
  deps: LocalSttAdapterDeps,
): SpeechAdapter {
  let dead = false
  let capture: CaptureHandle | null = null
  let sessionId: string | null = null
  let modelId = deps.modelId ?? ""
  let unsub: (() => void) | null = null
  let phase: "idle" | "recording" | "uploading" | "waiting" = "idle"
  let aborted = false
  let wantListening = false
  let mode: VoiceDictationMode = "classic"
  let parentSessionId = ""
  let lang = VOICE_DEFAULT_LANG
  let hardCapMs = VOICE_CONTINUOUS_HARD_CAP_MS
  /** Optional per-segment window override (tests); clamped to LOCAL_STT_MAX_RECORD_MS. */
  let segmentCapMs = LOCAL_STT_MAX_RECORD_MS
  let streamPartial = false
  let wallStart = 0
  let segmentIndex = 0
  let pending: PendingWait | null = null
  let pendingTimer: ReturnType<typeof setTimeout> | null = null
  let loopGen = 0
  /** Continuous: resolve when current segment should stop recording. */
  let segmentStopTrigger: (() => void) | null = null
  let segmentTimer: ReturnType<typeof setTimeout> | null = null
  let partialTimer: ReturnType<typeof setTimeout> | null = null
  let pcmStream: PcmStreamHandle | null = null
  let streamSeq = 0
  let streamStable = ""
  let streamPrevHypothesis = ""
  /** Adaptive partial poll (ms); paced by last hypothesis infer time. */
  let partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
  /**
   * N3: soft stop requested while awaiting gUM / before window wait is armed.
   * Checked after each await so we never run a full unintended window.
   */
  let pendingSoftStop = false
  /** Consecutive soft segment failures — hard stop after threshold (adversary B F2). */
  let softFailStreak = 0
  /** Classic: first stop() already started the stop→upload chain; repeat stops are ignored. */
  let stopChainInFlight = false
  const SOFT_FAIL_MAX = 3
  const beginCapture = deps.startCapture ?? defaultStartCapture
  const beginPcmStream = deps.startPcmStreamCapture ?? defaultStartPcmStreamCapture
  const pendingTimeoutMs = deps.pendingTimeoutMs ?? LOCAL_STT_PENDING_TIMEOUT_MS
  const stopGraceMs = deps.stopGraceMs ?? LOCAL_STT_STOP_GRACE_MS

  const clearSegmentTimer = () => {
    if (segmentTimer) {
      clearTimeout(segmentTimer)
      segmentTimer = null
    }
  }

  const clearPartialTimer = () => {
    if (partialTimer) {
      clearTimeout(partialTimer)
      partialTimer = null
    }
  }

  const clearPendingTimer = () => {
    if (pendingTimer) {
      clearTimeout(pendingTimer)
      pendingTimer = null
    }
  }

  const pendingWaitMs = () => {
    const budget = deps.pendingTimeoutMs ?? (modelId === "large-v3-turbo" ? 305_000 : pendingTimeoutMs)
    // Ending an ordinary recording is the normal route to its final, not cancellation.
    return mode === "classic" || wantListening ? budget : Math.min(stopGraceMs, budget)
  }

  const armPendingTimer = (sid: string) => {
    clearPendingTimer()
    const ms = pendingWaitMs()
    pendingTimer = setTimeout(() => {
      pendingTimer = null
      if (!pending || pending.sessionId !== sid) return
      // Still listening: surface infer_timeout (soft streak). After user stop:
      // empty_result so the loop can onEnd without a scary banner.
      finishPending({
        ok: false,
        code: mode === "classic" || wantListening ? "infer_timeout" : "empty_result",
      })
    }, ms)
  }

  const clearSub = () => {
    if (unsub) {
      try {
        unsub()
      } catch {
        /* */
      }
      unsub = null
    }
  }

  const reset = () => {
    // V1: invalidate every in-flight coroutine gen guard (classic stop chain,
    // continuous loops). Without this a coroutine sleeping in conflict backoff
    // survived reset() and woke as a zombie — uploading with no subscription,
    // pending never settled, phase stuck "waiting" → mic locked for good.
    loopGen += 1
    clearSegmentTimer()
    clearPartialTimer()
    clearPendingTimer()
    segmentStopTrigger = null
    if (pcmStream) {
      try {
        pcmStream.abort()
      } catch {
        /* */
      }
      pcmStream = null
    }
    clearSub()
    capture = null
    sessionId = null
    phase = "idle"
    aborted = false
    wantListening = false
    mode = "classic"
    streamPartial = false
    parentSessionId = ""
    segmentIndex = 0
    pending = null
    streamSeq = 0
    streamStable = ""
    streamPrevHypothesis = ""
    partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
    pendingSoftStop = false
    softFailStreak = 0
    stopChainInFlight = false
  }

  const finishPending = (
    r: { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string },
  ) => {
    clearPendingTimer()
    const p = pending
    pending = null
    p?.resolve(r)
  }

  const onWs = (msg: any) => {
    if (dead || !msg || typeof msg.type !== "string") return
    const sid = typeof msg.sessionId === "string" ? msg.sessionId : ""
    if (!sessionId || sid !== sessionId) return

    if (msg.type === "voice.stt.partial") {
      // M2 hypothesis text (status === "hypothesis"); ignore status-only partials
      // N4: drop late partials after window end / while waiting for final
      if (phase !== "recording") return
      if (msg.status === "hypothesis" && typeof msg.text === "string") {
        const hyp = msg.text.trim()
        if (!hyp) return
        // Pace next poll from companion infer wall time (medium models often >1.4s)
        if (typeof msg.ms === "number" && Number.isFinite(msg.ms) && msg.ms > 0) {
          partialPollMs = nextPartialPollMs(msg.ms)
        }
        // F3: interim-only within a window — never commit finalChunk mid-window.
        streamPrevHypothesis = hyp
        const display = hyp.startsWith(streamStable) ? hyp.slice(streamStable.length) : hyp
        handlers.onResult({
          interim: display,
          finalChunk: "",
        })
      }
      return
    }

    if (msg.type === "voice.stt.result") {
      const text = typeof msg.text === "string" ? msg.text : ""
      if (pending && pending.sessionId === sid) {
        finishPending({
          ok: true,
          text,
          ...(msg.postprocessed === true ? { postprocessed: true } : {}),
        })
        return
      }
      if (aborted) {
        handlers.onEnd()
        reset()
        return
      }
      if (text.trim()) {
        handlers.onResult({
          interim: "",
          finalChunk: text,
          ...(msg.postprocessed === true ? { postprocessed: true } : {}),
        })
      }
      handlers.onEnd()
      reset()
      return
    }

    if (msg.type === "voice.stt.error") {
      const code = typeof msg.code === "string" && msg.code ? msg.code : "unknown"
      if (pending && pending.sessionId === sid) {
        finishPending({
          ok: false,
          code: code === "aborted" || aborted ? "aborted" : code,
        })
        return
      }
      if (code === "aborted" || aborted) {
        handlers.onError("aborted")
        handlers.onEnd()
        reset()
        return
      }
      // No pending (e.g. start rejected mid-stream).
      // Hard errors always stop. Soft: only when streamPartial is false —
      // streaming loop already counts soft fails on end() (Pi nit: avoid double streak).
      if (isHardSttSegmentError(code) || code === "oom") {
        handlers.onError(code)
        handlers.onEnd()
        reset()
        return
      }
      if (
        mode === "continuous" &&
        wantListening &&
        isSoftSttSegmentError(code) &&
        !streamPartial
      ) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
        softFailStreak += 1
        handlers.onError(code)
        if (softFailStreak >= SOFT_FAIL_MAX) {
          handlers.onEnd()
          reset()
          return
        }
        handlers.onSegmentContinue?.()
        return
      }
      // Streaming with pending null on soft: notify UI but let loop own streak via end path
      if (mode === "continuous" && streamPartial && isSoftSttSegmentError(code)) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
        handlers.onError(code)
        return
      }
      handlers.onError(code)
      handlers.onEnd()
      reset()
    }
  }

  const ensureSub = () => {
    if (unsub) return
    unsub = deps.onMessage(onWs)
  }

  const uploadAndWait = (
    sid: string,
    wav: Uint8Array,
  ): Promise<{ ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string }> => {
    return new Promise((resolve) => {
      if (!sid || dead) {
        resolve({ ok: false, code: "aborted" })
        return
      }
      phase = "uploading"
      handlers.onCaptureStopped?.()

      if (wav.length === 0) {
        resolve({ ok: false, code: "empty_result" })
        return
      }

      pending = { sessionId: sid, resolve }
      sessionId = sid
      armPendingTimer(sid)

      const chunks = splitIntoChunks(wav, LOCAL_STT_MAX_CHUNK_RAW_BYTES)
      for (let seq = 0; seq < chunks.length; seq++) {
        if (dead || aborted || sessionId !== sid) {
          finishPending({ ok: false, code: "aborted" })
          return
        }
        deps.send({
          type: "voice.stt.chunk",
          v: 1,
          sessionId: sid,
          seq,
          data: uint8ToBase64(chunks[seq]!),
        })
      }

      if (dead || aborted || sessionId !== sid) {
        finishPending({ ok: false, code: "aborted" })
        return
      }
      phase = "waiting"
      deps.send({
        type: "voice.stt.end",
        v: 1,
        sessionId: sid,
        totalSeq: chunks.length,
      })
    })
  }

  const sendStart = (sid: string, maxMs: number) => {
    deps.send({
      type: "voice.stt.start",
      v: 1,
      sessionId: sid,
      ...(modelId ? { modelId } : {}),
      ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
      format: "wav",
      sampleRate: LOCAL_STT_SAMPLE_RATE,
      channels: LOCAL_STT_CHANNELS,
      lang: lang.startsWith("zh") ? "zh" : lang,
      maxMs,
      // P1: server-enforced privacy ack (chrome.storage alone is not enough)
      privacy_ack_v2: true,
    })
  }

  /**
   * Record one segment: wait segmentMs or user stop(), then return WAV.
   */
  const recordSegment = async (segmentMs: number): Promise<Uint8Array | null> => {
    const handle = await beginCapture({ maxMs: segmentMs, onLevel: handlers.onLevel })
    if (dead || aborted || !wantListening) {
      try {
        handle.abort()
      } catch {
        /* */
      }
      return null
    }
    capture = handle

    await new Promise<void>((resolve) => {
      let settled = false
      const done = () => {
        if (settled) return
        settled = true
        clearSegmentTimer()
        segmentStopTrigger = null
        resolve()
      }
      segmentStopTrigger = done
      segmentTimer = setTimeout(done, segmentMs)
    })

    capture = null
    if (dead || aborted) {
      try {
        handle.abort()
      } catch {
        /* */
      }
      return null
    }
    try {
      return await handle.stop()
    } catch (e: any) {
      if (e?.code === "aborted" || aborted) return null
      throw e
    }
  }

  const runClassic = async (sid: string) => {
    try {
      const handle = await beginCapture({ maxMs: LOCAL_STT_MAX_RECORD_MS, onLevel: handlers.onLevel })
      if (dead || aborted || sessionId !== sid) {
        handle.abort()
        return
      }
      capture = handle
      // C1 / D1c: do NOT voice.stt.start until upload. Companion arms 10s idle
      // on start with zero chunks during record → forceAbort (classic ≥10s).
      if (dead || aborted) {
        handle.abort()
        return
      }
      handlers.onStart()
    } catch (e: any) {
      if (dead || aborted) return
      const code =
        e?.code === "aborted"
          ? "aborted"
          : e?.name === "NotAllowedError" || e?.name === "PermissionDeniedError"
            ? "not-allowed"
            : "audio-capture"
      handlers.onError(code)
      handlers.onEnd()
      reset()
    }
  }

  /**
   * M2 streaming continuous: PCM chunks live + partial_request → interim hypothesis;
   * window end → single final commit (F3: no mid-window finalChunk).
   * Window length honors segmentCapMs (F1), default ~8s when realtime.
   */
  const runStreamingContinuous = async (gen: number) => {
    try {
      let reportedStart = false
      while (!dead && wantListening && gen === loopGen) {
        const remaining = hardCapMs - (Date.now() - wallStart)
        if (remaining < 200) break

        // F1: honor near-realtime segmentCapMs (not always 45s)
        const windowMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
        segmentIndex += 1
        const segSid = `${parentSessionId}-s${segmentIndex}`
        sessionId = segSid
        phase = "recording"
        streamSeq = 0
        streamStable = ""
        streamPrevHypothesis = ""
        partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
        let sessionStarted = false

        // N3: soft-stop may arrive while we await gUM — honor after resolve
        if (pendingSoftStop || !wantListening) {
          pendingSoftStop = false
          if (!dead) {
            handlers.onEnd()
            reset()
          }
          return
        }

        // F7: open mic first, then voice.stt.start (avoid idle abort during gUM)
        try {
          pcmStream = await beginPcmStream({
            maxMs: windowMs,
            onLevel: handlers.onLevel,
            onPcmChunk: (pcm) => {
              if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
              if (!sessionStarted || pcm.length === 0) return
              const chunks = splitIntoChunks(pcm, LOCAL_STT_MAX_CHUNK_RAW_BYTES)
              for (const c of chunks) {
                deps.send({
                  type: "voice.stt.chunk",
                  v: 1,
                  sessionId: segSid,
                  seq: streamSeq,
                  data: uint8ToBase64(c),
                })
                streamSeq += 1
              }
            },
          })
        } catch (e: any) {
          if (dead || gen !== loopGen) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
          return
        }

        // N3: soft stop during gUM — release mic, clean end (no full window)
        if (dead || gen !== loopGen) {
          try {
            pcmStream?.abort()
          } catch {
            /* */
          }
          pcmStream = null
          return
        }
        if (aborted || pendingSoftStop || !wantListening) {
          try {
            pcmStream?.abort()
          } catch {
            /* */
          }
          pcmStream = null
          pendingSoftStop = false
          if (aborted) {
            handlers.onError("aborted")
          }
          if (!dead) {
            handlers.onEnd()
            reset()
          }
          return
        }

        deps.send({
          type: "voice.stt.start",
          v: 1,
          sessionId: segSid,
          ...(modelId ? { modelId } : {}),
          ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
          format: "pcm_s16le",
          sampleRate: LOCAL_STT_SAMPLE_RATE,
          channels: LOCAL_STT_CHANNELS,
          lang: lang.startsWith("zh") ? "zh" : lang,
          maxMs: windowMs,
          // P1: same wire gate as classic WAV start — continuous/hold path must not omit
          privacy_ack_v2: true,
        })
        sessionStarted = true
        // Permission/capture acquisition is still "starting". Report listening
        // only once capture is ready; later windows use onSegmentContinue.
        if (!reportedStart) {
          reportedStart = true
          handlers.onStart()
        }

        // Adaptive partial poll: setTimeout chain paced by last hypothesis `ms`
        clearPartialTimer()
        const schedulePartialPoll = () => {
          clearPartialTimer()
          if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
          if (phase !== "recording") return
          partialTimer = setTimeout(() => {
            partialTimer = null
            if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
            if (phase !== "recording") return
            deps.send({
              type: "voice.stt.partial_request",
              v: 1,
              sessionId: segSid,
            })
            // Reschedule with current pace (updated when hypothesis with ms arrives)
            schedulePartialPoll()
          }, partialPollMs)
        }
        schedulePartialPoll()

        // Wait until window ends, user stop, or hard cap
        await new Promise<void>((resolve) => {
          let settled = false
          const done = () => {
            if (settled) return
            settled = true
            clearSegmentTimer()
            segmentStopTrigger = null
            resolve()
          }
          segmentStopTrigger = done
          // Soft-stop already requested before wait armed → end immediately
          if (pendingSoftStop || !wantListening) {
            pendingSoftStop = false
            done()
            return
          }
          segmentTimer = setTimeout(done, windowMs)
        })

        clearPartialTimer()
        const handle = pcmStream
        pcmStream = null
        if (handle) {
          try {
            await handle.stop()
          } catch {
            /* */
          }
        }

        if (dead || gen !== loopGen) return
        if (aborted) {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
          handlers.onError("aborted")
          handlers.onEnd()
          reset()
          return
        }

        // Final decode for this window — single commit (F3)
        phase = "waiting"
        handlers.onCaptureStopped?.()
        if (streamSeq === 0) {
          // No audio captured this window
          if (!wantListening) break
          handlers.onSegmentContinue?.()
          continue
        }
        const result = await new Promise<
          { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string }
        >(
          (resolve) => {
            pending = { sessionId: segSid, resolve }
            armPendingTimer(segSid)
            deps.send({
              type: "voice.stt.end",
              v: 1,
              sessionId: segSid,
              totalSeq: streamSeq,
            })
          },
        )

        if (dead || gen !== loopGen) return
        if (result.ok === false) {
          const streamErr = result.code
          if (streamErr === "aborted" || aborted) {
            handlers.onError("aborted")
            handlers.onEnd()
            reset()
            return
          }
          if (streamErr === "empty_result") {
            softFailStreak = 0
            handlers.onResult({ interim: "", finalChunk: "" })
          } else if (isSoftSttSegmentError(streamErr) && wantListening) {
            softFailStreak += 1
            handlers.onError(streamErr)
            handlers.onResult({ interim: "", finalChunk: "" })
            if (softFailStreak >= SOFT_FAIL_MAX) {
              handlers.onEnd()
              reset()
              return
            }
          } else {
            // conflict/busy/oom: try reclaim then hard stop (do not soft-loop max-1)
            if (streamErr === "resource_conflict" || streamErr === "session_busy") {
              try {
                deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
              } catch {
                /* */
              }
              await new Promise((r) => setTimeout(r, 200))
              // The abort's own "aborted" ACK may have torn us down during the
              // wait (no-pending kill path) — do not fire handlers a second time.
              if (dead || gen !== loopGen) return
            }
            handlers.onError(streamErr)
            handlers.onEnd()
            reset()
            return
          }
        } else if (result.text.trim()) {
          softFailStreak = 0
          // Window commit: one finalChunk for the whole window text
          handlers.onResult({
            interim: "",
            finalChunk: result.text.trim(),
            ...(result.postprocessed === true ? { postprocessed: true } : {}),
          })
          streamStable = result.text.trim()
        } else {
          softFailStreak = 0
          handlers.onResult({ interim: "", finalChunk: "" })
        }

        if (!wantListening || aborted || mode === "classic") break
        handlers.onSegmentContinue?.()
      }

      if (!dead) handlers.onEnd()
      reset()
    } catch {
      if (!dead) {
        handlers.onError("unknown")
        handlers.onEnd()
      }
      reset()
    }
  }

  const runContinuous = async (gen: number) => {
    if (streamPartial) {
      await runStreamingContinuous(gen)
      return
    }
    try {
      handlers.onStart()
      while (!dead && wantListening && gen === loopGen) {
        const remaining = hardCapMs - (Date.now() - wallStart)
        // Allow short test segments (<800ms wall hardCap with tiny segmentCapMs)
        if (remaining < Math.min(50, segmentCapMs)) break

        const segmentMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
        segmentIndex += 1
        const segSid = `${parentSessionId}-s${segmentIndex}`
        sessionId = segSid
        phase = "recording"

        // Do NOT voice.stt.start until upload: companion arms 10s idle on start
        // with zero chunks during record → forceAbort (Pi D1c blocker #2).
        let wav: Uint8Array | null
        try {
          wav = await recordSegment(segmentMs)
        } catch (e: any) {
          if (dead || gen !== loopGen) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
          return
        }

        if (dead || gen !== loopGen) return
        if (aborted || wav == null) {
          // User abort or cancelled before audio
          if (aborted) {
            handlers.onError("aborted")
          }
          handlers.onEnd()
          reset()
          return
        }

        // Open STT session then immediately stream chunks (keeps idle timer happy).
        sendStart(segSid, segmentMs)
        let result = await uploadAndWait(segSid, wav)
        // Conflict: abort any stale holder then one retry (must free max-1 slot).
        if (
          result.ok === false &&
          (result.code === "resource_conflict" || result.code === "session_busy") &&
          !dead &&
          !aborted &&
          gen === loopGen
        ) {
          const retrySid = `${segSid}-r1`
          // V1/L10: adopt the retry sid BEFORE abort+backoff. The rejected sid's
          // chunk/end session_unknown rejects and the abort's own error ACK land
          // during the sleep; with the old sid still current they hit the
          // no-pending kill path (onError+onEnd+reset) and orphaned this retry.
          sessionId = retrySid
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
          // Best-effort: also abort parent-prefixed sessions from this capture
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: parentSessionId })
          await new Promise((r) => setTimeout(r, 250))
          if (dead || aborted || gen !== loopGen) return
          // Belt-and-suspenders: never upload the retry without a subscription.
          ensureSub()
          sendStart(retrySid, segmentMs)
          result = await uploadAndWait(retrySid, wav)
        }
        if (dead || gen !== loopGen) return

        if (result.ok === false) {
          const errCode = result.code
          if (errCode === "aborted" || aborted) {
            handlers.onError("aborted")
            handlers.onEnd()
            reset()
            return
          }
          if (isHardSttSegmentError(errCode) || errCode === "oom") {
            handlers.onError(errCode)
            handlers.onEnd()
            reset()
            return
          }
          // Soft only after end() failures that drop companion bound
          if (isSoftSttSegmentError(errCode) && wantListening) {
            softFailStreak += 1
            handlers.onError(errCode)
            if (softFailStreak >= SOFT_FAIL_MAX) {
              handlers.onEnd()
              reset()
              return
            }
            handlers.onSegmentContinue?.()
            continue
          }
          // resource_conflict after retry, payload_too_large, etc. → hard stop
          handlers.onError(errCode)
          handlers.onEnd()
          reset()
          return
        }

        softFailStreak = 0
        if (result.text.trim()) {
          handlers.onResult({
            interim: "",
            finalChunk: result.text,
            ...(result.postprocessed === true ? { postprocessed: true } : {}),
          })
        }

        if (!wantListening || aborted) break

        // Resume listening chrome between segments
        handlers.onSegmentContinue?.()
      }

      if (!dead) handlers.onEnd()
      reset()
    } catch {
      if (!dead) {
        handlers.onError("unknown")
        handlers.onEnd()
      }
      reset()
    }
  }

  return {
    start(langOrOpts?: SpeechAdapterStartArg) {
      if (dead) return
      if (phase !== "idle") return

      aborted = false
      wantListening = true
      lang = VOICE_DEFAULT_LANG
      let sid = ""
      let mid = deps.modelId
      mode = "classic"
      hardCapMs = VOICE_CONTINUOUS_HARD_CAP_MS
      segmentCapMs = LOCAL_STT_MAX_RECORD_MS
      streamPartial = false

      if (typeof langOrOpts === "string") {
        lang = langOrOpts || VOICE_DEFAULT_LANG
      } else if (langOrOpts && typeof langOrOpts === "object") {
        if (langOrOpts.lang) lang = langOrOpts.lang
        if (langOrOpts.sessionId) sid = langOrOpts.sessionId
        if (langOrOpts.modelId) mid = langOrOpts.modelId
        if (langOrOpts.mode === "continuous") mode = "continuous"
        if (typeof (langOrOpts as { hardCapMs?: number }).hardCapMs === "number") {
          hardCapMs = (langOrOpts as { hardCapMs: number }).hardCapMs
        }
        if (typeof (langOrOpts as { segmentMs?: number }).segmentMs === "number") {
          segmentCapMs = Math.max(
            20,
            Math.min(LOCAL_STT_MAX_RECORD_MS, (langOrOpts as { segmentMs: number }).segmentMs),
          )
        }
        if ((langOrOpts as { streamPartial?: boolean }).streamPartial === true) {
          streamPartial = true
          // Prefer near-realtime segment defaults when streaming
          if (mode === "continuous" && segmentCapMs >= LOCAL_STT_MAX_RECORD_MS) {
            segmentCapMs = LOCAL_STT_NEAR_REALTIME_SEGMENT_MS
          }
        }
        // large-v3-turbo: progressive re-decode is too heavy (loads full model often).
        // Force final-only continuous windows even if caller asked for streamPartial.
        if (mid === "large-v3-turbo" || modelId === "large-v3-turbo") {
          streamPartial = false
          segmentCapMs = LOCAL_STT_MAX_RECORD_MS
        }
        // #259: SAPI is batch — no progressive hypotheses for system sessions.
        if (deps.engineKind === "system") {
          streamPartial = false
          segmentCapMs = LOCAL_STT_MAX_RECORD_MS
        }
      }

      if (!sid) {
        handlers.onError("session_busy")
        handlers.onEnd()
        return
      }

      parentSessionId = sid
      sessionId = sid
      modelId = mid || deps.modelId || ""
      if (mode === "classic" && streamPartial) {
        // Progressive preview for ordinary dictation, with one bounded final.
        // Leave transport/drain time before the daemon's 45 s recording lease expires.
        hardCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
        segmentCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
      }
      ensureSub()
      phase = "recording"
      wallStart = Date.now()
      segmentIndex = 0
      loopGen += 1
      const gen = loopGen

      if (streamPartial) {
        void runStreamingContinuous(gen)
      } else if (mode === "continuous") {
        void runContinuous(gen)
      } else {
        void runClassic(sid)
      }
    },

    stop() {
      if (dead) return
      if (phase === "idle") return

      wantListening = false

      // Continuous: finish current segment early, then exit after upload / end stream
      if (mode === "continuous" || streamPartial) {
        if (phase === "recording") {
          // N3: if window wait not armed yet (still in gUM), mark pending soft stop
          if (!segmentStopTrigger) {
            pendingSoftStop = true
          }
          segmentStopTrigger?.()
        }
        // Waiting for companion infer: re-arm with stopGrace so a dead
        // Companion (SIGTERM mid-window) cannot leave the mic/UI hung.
        if ((phase === "waiting" || phase === "uploading") && pending && sessionId) {
          armPendingTimer(sessionId)
        }
        return
      }

      // classic
      if (phase === "uploading" || phase === "waiting") {
        return
      }

      const handle = capture
      capture = null
      if (!handle) {
        // L10: double-click stop while the first stop's upload chain is in
        // flight — ignore the repeat instead of aborting the upload (which
        // silently discarded the whole recording).
        if (stopChainInFlight) return
        aborted = true
        handlers.onError("aborted")
        handlers.onEnd()
        reset()
        return
      }

      stopChainInFlight = true
      const genAtStop = loopGen
      void handle
        .stop()
        .then(async (wav) => {
          const sid = sessionId
          if (!sid) return
          if (dead || aborted || genAtStop !== loopGen) return
          // Open STT session then immediately stream chunks (keeps idle timer happy).
          sendStart(sid, LOCAL_STT_MAX_RECORD_MS)
          let result = await uploadAndWait(sid, wav)
          if (
            result.ok === false &&
            (result.code === "resource_conflict" || result.code === "session_busy") &&
            !dead &&
            genAtStop === loopGen
          ) {
            const retrySid = `${sid}-r1`
            // V1: adopt the retry sid BEFORE abort+backoff. The rejected sid's
            // chunk/end session_unknown rejects and the abort's own error ACK
            // land during the sleep; with the old sid still current they hit
            // the no-pending kill path (onError+onEnd+reset) and turned this
            // retry into a zombie (no subscription, pending never settled).
            sessionId = retrySid
            deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
            await new Promise((r) => setTimeout(r, 250))
            if (dead || genAtStop !== loopGen) return
            // Belt-and-suspenders: never upload the retry without a subscription.
            ensureSub()
            sendStart(retrySid, LOCAL_STT_MAX_RECORD_MS)
            result = await uploadAndWait(retrySid, wav)
          }
          if (dead) return
          if (result.ok === false) {
            const errCode = result.code
            // User-stop timeout uses empty_result so we can onEnd without a banner.
            if (errCode !== "empty_result") {
              handlers.onError(errCode === "aborted" ? "aborted" : errCode)
            }
          } else if (result.text.trim()) {
            handlers.onResult({
              interim: "",
              finalChunk: result.text,
              ...(result.postprocessed === true ? { postprocessed: true } : {}),
            })
          }
          handlers.onEnd()
          reset()
        })
        .catch((e: any) => {
          if (aborted || dead) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
        })
    },

    abort() {
      if (dead) return
      aborted = true
      wantListening = false
      loopGen += 1
      clearSegmentTimer()
      clearPartialTimer()
      segmentStopTrigger?.()
      segmentStopTrigger = null
      const sid = sessionId
      const handle = capture
      capture = null
      try {
        handle?.abort()
      } catch {
        /* */
      }
      if (pcmStream) {
        try {
          pcmStream.abort()
        } catch {
          /* */
        }
        pcmStream = null
      }
      if (sid) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
      }
      finishPending({ ok: false, code: "aborted" })
      handlers.onError("aborted")
      handlers.onEnd()
      reset()
    },

    destroy() {
      dead = true
      aborted = true
      wantListening = false
      pendingSoftStop = true
      loopGen += 1
      clearSegmentTimer()
      clearPartialTimer()
      // Fire wait resolvers so streaming coroutines do not hang (Pi destroy nit)
      try {
        segmentStopTrigger?.()
      } catch {
        /* */
      }
      segmentStopTrigger = null
      const sid = sessionId
      const handle = capture
      capture = null
      try {
        handle?.abort()
      } catch {
        /* */
      }
      if (pcmStream) {
        try {
          pcmStream.abort()
        } catch {
          /* */
        }
        pcmStream = null
      }
      if (sid) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
      }
      finishPending({ ok: false, code: "aborted" })
      reset()
    },
  }
}

MACHINE LOG TAIL companion-tests.log
    # Subtest: settings-cli: non-sensitive --set still works (model_name)
    ok 4 - settings-cli: non-sensitive --set still works (model_name)
      ---
      duration_ms: 0.251334
      type: 'test'
      ...
    1..4
ok 2 - settings-cli
  ---
  duration_ms: 2.063625
  type: 'suite'
  ...
1..2
# tests 20
# suites 2
# pass 20
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 49.301708

MACHINE LOG TAIL companion-build.log

> cmspark-agent@0.6.7 prebuild
> node scripts/generate-tray-icons.mjs

Connection tray icons generated (32px PNG, 16/32/48 ICO).

> cmspark-agent@0.6.7 build
> tsc && node -e "const fs=require('fs'),p=require('path');fs.mkdirSync('dist/computer',{recursive:true});fs.copyFileSync('src/computer/qwen-vl-worker.py','dist/computer/qwen-vl-worker.py');process.platform!=='win32'&&fs.chmodSync('dist/index.js',0o755)"


MACHINE LOG TAIL extension-tests.log
# Subtest: shouldRefuseWsFrame allows an 8MB JSON payload
ok 1326 - shouldRefuseWsFrame allows an 8MB JSON payload
  ---
  duration_ms: 0.044125
  type: 'test'
  ...
# Subtest: isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
ok 1327 - isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
  ---
  duration_ms: 0.04825
  type: 'test'
  ...
1..1327
# tests 1327
# suites 0
# pass 1327
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 9357.594959

MACHINE LOG TAIL extension-build.log
  icon_16x16@2x.png (333 bytes)
  icon_32x32.png (333 bytes)
  icon_32x32@2x.png (531 bytes)
  icon_128x128.png (1235 bytes)
  icon_128x128@2x.png (2619 bytes)
  icon_256x256.png (2619 bytes)
  icon_256x256@2x.png (5904 bytes)
  icon_512x512.png (5904 bytes)
  icon_512x512@2x.png (15004 bytes)

Connection icon generation complete!

> cmspark-browser-agent@0.6.7 build
> tsc --noEmit && plasmo build

🟣 Plasmo v0.90.5
🔴 The Browser Extension Framework
🔵 INFO   | Prepare to bundle the extension...
🔵 INFO   | Building for target: chrome-mv3
🔵 INFO   | Loaded environment variables from: []
🟢 DONE   | Finished in 8268ms!

MACHINE LOG TAIL mutations-ui-final.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpiecma1fd
PASS: actual App selection boundaries, busy/filter race, 60-item batching, ACK vs persisted result, offline/partial failure, restore, independent cleanup scope and responsive management capabilities.

MACHINE LOG TAIL management-ui.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpjhnhfeyu
PASS: responsive new chat+manager, tags/manual/AI groups, persisted metadata+failure, AI label retention, explicit AI/cleanup/graph paths, no automatic metadata writes.

MACHINE LOG TAIL workspace-ui.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/cmspark-workspace-ptos29ws
PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, A/B coding ownership and controls, reflow/reduced motion. Synthetic transport only.

MACHINE LOG TAIL settings-ui.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmp31iqisc1
PASS: settings pages responsive, all categories, retained model draft, stable deep links+focus, cross-page safety status, no implicit writes; cancelled voice callbacks, hidden hotkey capture, license keyboard isolation and focus restoration.

MACHINE LOG TAIL meeting-ui.log
PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation
