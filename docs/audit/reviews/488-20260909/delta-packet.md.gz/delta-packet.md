Independent delta review for CMspark #488. Initial full review was frozen at round1-source-manifest.json. No other judge conclusions included. Product code delta since that review: exactly ONE string in ComposeDrawer SECTION_SCOPE.history, from '查看与管理全部对话' to '查看当前对话的操作记录'. This corrects the scope: loadPanelData(history) sends history.query with activeThreadId; HistoryPanel shows current-thread operation history. Also actual UI regression tests were extended for single-row deletion, settings failure+retry, standalone MeetingPanel; no production behavior changed for those. Please examine this bounded delta and current supporting source for real regressions or wrong wording. Do not approve an unresolved earlier blocker; this delta verdict supplements your initial whole-change verdict. Final VERDICT: APPROVE / APPROVE_WITH_NITS / REJECT. No tools or preface.

CURRENT FILE chrome-extension/src/sidepanel/components/ComposeDrawer.tsx
// 装配 drawer — full Composition section UI (UIUX v2 PR6 / §4.5).
// Opens Host panels; Board / Fleet / multi-worker are Autonomy — never listed.
// Shell via BottomSheet (focus trap + Escape from ui/Modal); landfill
// one-surface rule enforced by parent.
// G4: MD3-ish sheet (radiusSheet + soft scrim) + settings-list groups.

import {
  useRef,
  useState,
  type CSSProperties,
  type ComponentType,
  type RefObject,
} from "react"
import {
  COMPOSE_GROUP_LABELS,
  COMPOSE_SECTIONS,
  composeSectionGroups,
  composeSectionsInGroup,
  type ComposeSection,
  type ComposeSectionGroup,
  type ComposeSectionId,
} from "../composer/meta-slash"
import type { ContextPanelId } from "./ContextPanelHost"
import type { CapabilityLevel } from "../types"
import { tokens } from "../ui/tokens"
import { BottomSheet } from "./ui/BottomSheet"
import {
  IconApps,
  IconChevronRight,
  IconClose,
  IconHistory,
  IconKnowledge,
  IconMcp,
  IconPacks,
  IconSkills,
  type IconProps,
} from "../ui/icons"

const FIRST_SECTION_ID: ComposeSectionId = COMPOSE_SECTIONS[0]?.id ?? "skills"

const SECTION_SCOPE: Record<ComposeSectionId, string> = {
  skills: "管理全局技能；按需用于对话",
  knowledge: "管理知识库；选择本次对话使用的知识",
  packs: "管理场景与专家；选择本对话工作区",
  mcp: "管理全局 MCP 连接",
  apps: "管理全局应用连接",
  history: "查看当前对话的操作记录",
}

const SECTION_ICONS: Record<ComposeSection["id"], ComponentType<IconProps>> = {
  skills: IconSkills,
  knowledge: IconKnowledge,
  packs: IconPacks,
  mcp: IconMcp,
  apps: IconApps,
  history: IconHistory,
}

export type ComposeDrawerProps = {
  open: boolean
  onClose: () => void
  /** Open Host panel and close drawer. */
  onOpenSection: (panelId: ContextPanelId) => void
  /** Accepted for caller compatibility; resource configuration is not Surface-scoped. */
  capabilityLevel?: CapabilityLevel
}

export function ComposeDrawer({
  open,
  onClose,
  onOpenSection,
}: ComposeDrawerProps) {
  const firstBtnRef = useRef<HTMLButtonElement>(null)
  const groups = composeSectionGroups()

  const handleSection = (section: ComposeSection) => {
    // Defense: never open Autonomy surfaces from 装配
    if (section.panelId === "board") return
    onOpenSection(section.panelId)
  }

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      ariaLabel="装配"
      initialFocusRef={firstBtnRef as RefObject<HTMLElement>}
    >
      <div data-testid="compose-drawer">
        <div style={styles.header}>
          <div style={{ minWidth: 0 }}>
            <div style={styles.title}>装配</div>
            <div style={styles.subtitle}>
              管理资源与连接，按需用于对话
            </div>
          </div>
          <button
            type="button"
            style={styles.closeBtn}
            onClick={onClose}
            aria-label="关闭装配"
            data-testid="compose-drawer-close"
          >
            <IconClose size={14} />
          </button>
        </div>

        {groups.map((group) => (
          <SectionGroup
            key={group}
            group={group}
            firstSectionId={FIRST_SECTION_ID}
            firstBtnRef={firstBtnRef}
            onOpen={handleSection}
          />
        ))}

        <p style={styles.footNote} data-testid="compose-autonomy-note">
          任务板可从“资料与工具”或 /board 打开
        </p>
      </div>
    </BottomSheet>
  )
}

function SectionGroup({
  group,
  firstSectionId,
  firstBtnRef,
  onOpen,
}: {
  group: ComposeSectionGroup
  firstSectionId: ComposeSectionId
  firstBtnRef: RefObject<HTMLButtonElement>
  onOpen: (section: ComposeSection) => void
}) {
  const sections = composeSectionsInGroup(group)
  if (sections.length === 0) return null

  return (
    <section style={styles.group} aria-labelledby={`compose-group-${group}`}>
      <h3 id={`compose-group-${group}`} style={styles.groupLabel}>
        {COMPOSE_GROUP_LABELS[group]}
      </h3>
      <ul style={styles.list} role="list">
        {sections.map((section, index) => {
          const Icon = SECTION_ICONS[section.id]
          return (
            <li
              key={section.id}
              style={{
                ...styles.listItem,
                borderTop: index > 0 ? `1px solid ${tokens.border}` : undefined,
              }}
            >
              <SectionRowButton
                section={section}
                Icon={Icon}
                attachLine={SECTION_SCOPE[section.id]}
                buttonRef={section.id === firstSectionId ? firstBtnRef : undefined}
                onOpen={onOpen}
              />
            </li>
          )
        })}
      </ul>
    </section>
  )
}

/** Settings-list row with hover (inline styles cannot use :hover). */
function SectionRowButton({
  section,
  Icon,
  attachLine,
  buttonRef,
  onOpen,
}: {
  section: ComposeSection
  Icon: ComponentType<IconProps>
  attachLine: string
  buttonRef?: RefObject<HTMLButtonElement>
  onOpen: (section: ComposeSection) => void
}) {
  const [hovered, setHovered] = useState(false)
  return (
    <button
      ref={buttonRef}
      type="button"
      style={{
        ...styles.sectionBtn,
        background: hovered ? tokens.bgHover : "transparent",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocus={() => setHovered(true)}
      onBlur={() => setHovered(false)}
      onClick={() => onOpen(section)}
      data-testid={`compose-section-${section.id}`}
    >
      <span style={styles.iconWrap} aria-hidden>
        <Icon size={16} />
      </span>
      <span style={styles.sectionBody}>
        <span style={styles.sectionTitleRow}>
          <span style={styles.sectionTitleZh}>{section.titleZh}</span>
          <span style={styles.sectionLabelEn}>{section.label}</span>
        </span>
        <span style={styles.sectionHint}>{section.hint}</span>
        <span style={styles.attachLine}>{attachLine}</span>
      </span>
      <IconChevronRight size={14} style={{ color: tokens.textMuted, flexShrink: 0 }} />
    </button>
  )
}

// Re-export for tests that import section list from drawer path (if any).
export { COMPOSE_SECTIONS }

const styles: Record<string, CSSProperties> = {
  header: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 8,
    padding: "0 16px 10px",
  },
  title: {
    fontSize: 16,
    fontWeight: 650,
    color: tokens.text,
    letterSpacing: "-0.02em",
  },
  subtitle: {
    fontSize: 11,
    color: tokens.textSecondary,
    marginTop: 3,
    lineHeight: 1.4,
  },
  closeBtn: {
    width: 30,
    height: 30,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusMd,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 0,
  },
  surfaceChip: {
    display: "inline-flex",
    margin: "0 16px 10px",
    padding: "3px 10px",
    borderRadius: tokens.radiusPill,
    background: tokens.accentSoft,
    color: tokens.accentText,
    fontSize: 10,
    fontWeight: 600,
    letterSpacing: "0.02em",
  },
  group: {
    margin: 0,
    padding: "0 0 10px",
  },
  groupLabel: {
    margin: "4px 16px 6px",
    fontSize: 10,
    fontWeight: 650,
    color: tokens.textMuted,
    textTransform: "uppercase" as const,
    letterSpacing: "0.06em",
  },
  /** G4: one elevated settings card per group (not a grid of caged buttons) */
  list: {
    listStyle: "none",
    margin: "0 12px",
    padding: 4,
    background: tokens.bg,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusLg,
    boxShadow: tokens.shadowSm,
    overflow: "hidden",
  },
  listItem: {
    margin: 0,
  },
  sectionBtn: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    width: "100%",
    textAlign: "left",
    border: "none",
    borderRadius: tokens.radiusMd,
    background: "transparent",
    padding: "10px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    transition: `background ${tokens.transitionFast} ease`,
  },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: tokens.radiusMd,
    background: tokens.accentSoft,
    color: tokens.accentText,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  sectionBody: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    gap: 2,
  },
  sectionTitleRow: {
    display: "flex",
    alignItems: "baseline",
    gap: 6,
  },
  sectionTitleZh: {
    fontSize: 13,
    fontWeight: 600,
    color: tokens.text,
  },
  sectionLabelEn: {
    fontSize: 10,
    fontWeight: 500,
    color: tokens.textMuted,
  },
  sectionHint: {
    fontSize: 11,
    color: tokens.textSecondary,
    lineHeight: 1.35,
  },
  attachLine: {
    fontSize: 10,
    color: tokens.accentText,
    marginTop: 1,
    lineHeight: 1.3,
  },
  footNote: {
    margin: "4px 16px 0",
    fontSize: 10,
    color: tokens.textMuted,
    lineHeight: 1.4,
  },
}

CURRENT FILE chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
// ContextPanelHost — single owner of context panel state, loaders, mounts,
// and cmspark:open-context-panel (UIUX v2 §4.7 M1). Host is SoT for panels.
// #321 PR-1: legacy permanent BottomBar tab strip deleted (was PR5-gated off).

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentType,
  type ReactNode,
} from "react"
import { useAgentStore } from "../store/agentStore"
import {
  contextBarTabsForLevel,
  contextBarOverflowTabsForLevel,
} from "../mode/mode-controller"
import type { CapabilityLevel } from "../types"
import { KnowledgeSubPanel } from "./KnowledgeSubPanel"
import { McpPanel } from "./McpPanel"
import { AppsPanel } from "./AppsPanel"
import { PacksPanel } from "./PacksPanel"
import { BoardPanel } from "./BoardPanel"
import { MeetingPanel } from "./MeetingPanel"
import { tokens } from "../ui/tokens"
import {
  IconTabs,
  IconHistory,
  IconSkills,
  IconKnowledge,
  IconMcp,
  IconApps,
  IconPacks,
  IconMic,
  IconList,
} from "../ui/icons"

// ── Registry ───────────────────────────────────────────────────────────────

export type ContextPanelId =
  | "tabs"
  | "history"
  | "skills"
  | "knowledge"
  | "packs"
  | "board"
  | "mcp"
  | "apps"
  | "meeting"

export type ContextPanelTabDef = {
  id: ContextPanelId
  label: string
  Icon: ComponentType<{ size?: number }>
}

/** Canonical panel registry (labels + icons). Strip and Host share this. */
// #321 PR-5: packs/meeting/board each get their own icon (were all IconSkills
// collisions); icons come from the existing ui/icons set — nothing new drawn.
export const CONTEXT_PANEL_TABS: ContextPanelTabDef[] = [
  { id: "tabs", label: "浏览器标签页", Icon: IconTabs },
  { id: "history", label: "历史", Icon: IconHistory },
  { id: "skills", label: "技能", Icon: IconSkills },
  { id: "knowledge", label: "知识", Icon: IconKnowledge },
  { id: "packs", label: "场景与专家", Icon: IconPacks },
  { id: "meeting", label: "会议", Icon: IconMic },
  { id: "board", label: "任务板", Icon: IconList },
  { id: "mcp", label: "MCP", Icon: IconMcp },
  { id: "apps", label: "应用", Icon: IconApps },
]

const KNOWN_IDS = new Set(CONTEXT_PANEL_TABS.map((t) => t.id))

export function isContextPanelId(id: string): id is ContextPanelId {
  return KNOWN_IDS.has(id as ContextPanelId)
}

export function contextPanelLabel(id: ContextPanelId): string {
  return CONTEXT_PANEL_TABS.find((t) => t.id === id)?.label ?? id
}

// ── Loaders ────────────────────────────────────────────────────────────────

export function loadPanelData(
  id: ContextPanelId,
  activeThreadId: string | null,
  dispatch: ReturnType<typeof useAgentStore>["dispatch"],
) {
  if (id === "tabs") {
    chrome.tabs.query({}, (tabs) => {
      dispatch({ type: "SET_TAB_LIST", tabs })
    })
  }
  if (id === "history") {
    chrome.runtime.sendMessage({ type: "history.query", limit: 50, thread_id: activeThreadId })
  }
  if (id === "skills") {
    // Force rescan when opening Skills — picks up Finder drops / external edits
    // even if mtime fingerprint was edge-case stale; cheap after ensureFresh path.
    chrome.runtime.sendMessage({ type: "skill.refresh" })
  }
  if (id === "knowledge") {
    chrome.runtime.sendMessage({ type: "knowledge.list" })
  }
  if (id === "packs") {
    chrome.runtime.sendMessage({ type: "pack.list" })
    chrome.runtime.sendMessage({ type: "modules.list" })
  }
  if (id === "mcp") {
    chrome.runtime.sendMessage({ type: "mcp.list" })
  }
  if (id === "apps") {
    chrome.runtime.sendMessage({ type: "apps.list" })
  }
}

// ── Host API context ───────────────────────────────────────────────────────

export type ContextPanelHostApi = {
  activePanel: ContextPanelId | null
  /** Toggle: same id closes; different id opens + loads. */
  openPanel: (id: ContextPanelId) => void
  /** Force-open (no toggle) — used by slash / custom events. */
  openPanelForce: (id: ContextPanelId) => void
  closePanel: () => void
  /** A recording panel can finish its last segment before navigation unmounts it. */
  registerBeforeClose: (guard: () => Promise<boolean>) => () => void
}

const ContextPanelHostContext = createContext<ContextPanelHostApi | null>(null)

export function useContextPanelHost(): ContextPanelHostApi {
  const ctx = useContext(ContextPanelHostContext)
  if (!ctx) {
    throw new Error("useContextPanelHost must be used within ContextPanelHostProvider")
  }
  return ctx
}

/** Soft read for optional chrome that may render outside provider in tests. */
export function useContextPanelHostOptional(): ContextPanelHostApi | null {
  return useContext(ContextPanelHostContext)
}

// ── Provider ───────────────────────────────────────────────────────────────

export function ContextPanelHostProvider({
  capabilityLevel,
  children,
}: {
  capabilityLevel: CapabilityLevel
  children: ReactNode
}) {
  const [activePanel, setActivePanel] = useState<ContextPanelId | null>(null)
  const activePanelRef = useRef(activePanel)
  activePanelRef.current = activePanel
  const beforeCloseRef = useRef<(() => Promise<boolean>) | null>(null)
  const transitionRef = useRef<Promise<boolean> | null>(null)
  const targetRef = useRef<ContextPanelId | null>(null)
  const transitionVersion = useRef(0)
  const pendingKnowledgeFocus = useRef<string | null>(null)
  const { state, dispatch } = useAgentStore()
  const activeThreadId = state.activeThreadId
  const activeThreadRef = useRef(activeThreadId)
  activeThreadRef.current = activeThreadId

  const allowedIds = useMemo(
    () => new Set(contextBarTabsForLevel(capabilityLevel)),
    [capabilityLevel],
  )
  const overflowIds = useMemo(
    () => contextBarOverflowTabsForLevel(capabilityLevel),
    [capabilityLevel],
  )

  const registerBeforeClose = useCallback((guard: () => Promise<boolean>) => {
    beforeCloseRef.current = guard
    return () => { if (beforeCloseRef.current === guard) beforeCloseRef.current = null }
  }, [])

  const requestPanelChange = useCallback((id: ContextPanelId | null): Promise<boolean> => {
    targetRef.current = id
    transitionVersion.current += 1
    if (transitionRef.current) return transitionRef.current
    if (activePanelRef.current === id) {
      if (id) loadPanelData(id, activeThreadRef.current, dispatch)
      return Promise.resolve(true)
    }
    const apply = () => {
      const target = targetRef.current
      activePanelRef.current = target
      setActivePanel(target)
      if (target) loadPanelData(target, activeThreadRef.current, dispatch)
    }
    const guard = beforeCloseRef.current
    if (!guard) { apply(); return Promise.resolve(true) }
    const pending = Promise.resolve().then(guard).then(allowed => {
      if (allowed) apply()
      return allowed
    }, () => false).finally(() => { transitionRef.current = null })
    transitionRef.current = pending
    return pending
  }, [dispatch])

  const closePanel = useCallback(() => { void requestPanelChange(null) }, [requestPanelChange])

  useEffect(() => {
    if (!state.settingsOpen) return
    if (!beforeCloseRef.current) { closePanel(); return }
    // Keep the finishing/error state visible; open settings after a successful close.
    dispatch({ type: "SET_SETTINGS_OPEN", open: false })
    const pending = requestPanelChange(null)
    const version = transitionVersion.current
    void pending.then(allowed => {
      if (allowed && version === transitionVersion.current) dispatch({ type: "SET_SETTINGS_OPEN", open: true })
    })
  }, [state.settingsOpen, closePanel, dispatch, requestPanelChange])

  const openPanelForce = useCallback(
    (id: ContextPanelId) => {
      void requestPanelChange(id)
    },
    [requestPanelChange],
  )

  const openPanel = useCallback(
    (id: ContextPanelId) => {
      void requestPanelChange(activePanelRef.current === id ? null : id)
    },
    [requestPanelChange],
  )

  // Close open panel if it is no longer primary or overflow for this level
  useEffect(() => {
    if (activePanel == null) return
    if (!allowedIds.has(activePanel) && !overflowIds.includes(activePanel)) {
      closePanel()
    }
  }, [activePanel, allowedIds, overflowIds, closePanel])

  // S1: slash meta commands (/packs /board /mcp) open panels via soft event
  useEffect(() => {
    const onOpen = (e: Event) => {
      const raw = (e as CustomEvent<{ panel?: string }>).detail?.panel
      if (!raw || !isContextPanelId(raw)) return
      openPanelForce(raw)
    }
    window.addEventListener("cmspark:open-context-panel", onOpen as EventListener)
    const onKnowledge = (e: Event) => {
      const id = (e as CustomEvent<{ id?: string }>).detail?.id
      if (id) pendingKnowledgeFocus.current = id
      openPanelForce("knowledge")
    }
    window.addEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
    const onGraphDoc = (msg: { type?: string; id?: string }) => {
      if (msg?.type !== "knowledge_graph.doc_selected" || !msg.id) return
      pendingKnowledgeFocus.current = msg.id
      openPanelForce("knowledge")
    }
    chrome.runtime.onMessage.addListener(onGraphDoc)
    return () => {
      window.removeEventListener("cmspark:open-context-panel", onOpen as EventListener)
      window.removeEventListener("cmspark:open-knowledge", onKnowledge as EventListener)
      chrome.runtime.onMessage.removeListener(onGraphDoc)
    }
  }, [openPanelForce])

  useEffect(() => {
    if (activePanel !== "knowledge") return
    const id = pendingKnowledgeFocus.current
    if (!id) return
    pendingKnowledgeFocus.current = null
    window.dispatchEvent(new CustomEvent("cmspark:focus-knowledge", { detail: { id } }))
  }, [activePanel])

  // Esc collapses any open context panel (priority stack §4.9 layer 2)
  useEffect(() => {
    if (!activePanel) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return
      const tag = (e.target as HTMLElement | null)?.tagName
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return
      e.preventDefault()
      closePanel()
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [activePanel, closePanel])

  const api = useMemo<ContextPanelHostApi>(
    () => ({ activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose }),
    [activePanel, openPanel, openPanelForce, closePanel, registerBeforeClose],
  )

  return (
    <ContextPanelHostContext.Provider value={api}>
      {children}
    </ContextPanelHostContext.Provider>
  )
}

// ── Panel body mount ───────────────────────────────────────────────────────

/**
 * Renders the open context panel body (header + body). Place above ComposerDock
 * (Host is SoT for panels).
 */
export function ContextPanelHost() {
  const { activePanel, closePanel, registerBeforeClose } = useContextPanelHost()
  const meetingCaptureActive = useAgentStore().state.meetingCaptureActive
  if (!activePanel) return null

  const label = contextPanelLabel(activePanel)
  const closeEndsMeeting = activePanel === "meeting" && meetingCaptureActive

  return (
    <div className="cm-context-panel" style={styles.panel} data-testid="context-panel-host">
      <div style={styles.panelHeader}>
        <span style={styles.panelTitle}>{label}</span>
        {closeEndsMeeting ? (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="结束并收起"
            aria-label="结束并收起"
            onClick={closePanel}
          >
            结束并收起
          </button>
        ) : (
          <button
            type="button"
            style={styles.panelCloseBtn}
            title="收起面板 (Esc)"
            aria-label="收起面板"
            onClick={closePanel}
          >
            收起
          </button>
        )}
      </div>
      {activePanel === "tabs" && <TabsPanel />}
      {activePanel === "history" && <HistoryPanel />}
      {activePanel === "skills" && <SkillsPanel />}
      {activePanel === "knowledge" && <KnowledgeSubPanel />}
      {activePanel === "packs" && <PacksPanel />}
      {activePanel === "meeting" && (
        <MeetingPanel
          onClose={closePanel}
          registerBeforeClose={registerBeforeClose}
          onSendToDraft={(text) => {
            window.dispatchEvent(
              new CustomEvent("cmspark:fill-composer", { detail: { text } }),
            )
            closePanel()
          }}
        />
      )}
      {activePanel === "board" && <BoardPanel />}
      {activePanel === "mcp" && <McpPanel />}
      {activePanel === "apps" && <AppsPanel />}
    </div>
  )
}

// ── Built-in panel bodies (moved from BottomBar) ───────────────────────────

function TabsPanel() {
  const { state, dispatch } = useAgentStore()

  const handleTogglePin = (tabId: number) => {
    const pinnedTabIds = state.pinnedTabIds.includes(tabId)
      ? state.pinnedTabIds.filter((id) => id !== tabId)
      : [...state.pinnedTabIds, tabId]

    dispatch({ type: "SET_PINNED_TABS", tabIds: pinnedTabIds })

    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { pinned_tabs: pinnedTabIds },
      })
    }
  }

  return (
    <div style={styles.panelContent}>
      {state.tabList.length === 0 && (
        <div style={styles.emptyText}>暂无标签页数据</div>
      )}
      {state.tabList.map((tab) => (
        <label key={tab.id} style={styles.tabRow}>
          <input
            type="checkbox"
            checked={state.pinnedTabIds.includes(tab.id!)}
            onChange={() => handleTogglePin(tab.id!)}
            style={{ marginRight: 8 }}
          />
          <span style={styles.tabTitle}>{tab.title || tab.url}</span>
          <span style={styles.tabUrl}>{tab.id}</span>
        </label>
      ))}
    </div>
  )
}

function HistoryPanel() {
  const { state } = useAgentStore()
  const operations = state.operations || []
  const groups = groupBy(operations, "thread_id")

  return (
    <div style={styles.panelContent}>
      {state.operations.length === 0 && (
        <div style={styles.emptyText}>暂无操作历史</div>
      )}
      {Object.entries(groups).map(([threadId, ops]) => (
        <div key={threadId} style={{ marginBottom: 8 }}>
          <div style={styles.groupHeader}>#{threadId}</div>
          {ops.map((op) => (
            <div key={op.id} style={styles.historyRow}>
              <span style={{ color: op.success ? tokens.success : tokens.danger }}>
                {op.success ? "✓" : "✗"}
              </span>
              <span style={{ flex: 1, marginLeft: 6, fontFamily: "monospace", fontSize: 11 }}>
                {op.tool_name}
              </span>
              <span style={{ color: tokens.textMuted, fontSize: 11 }}>
                {op.created_at?.slice(11, 19)}
              </span>
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

function SkillsPanel() {
  const { state, dispatch } = useAgentStore()
  const [importUrl, setImportUrl] = useState("")
  const [showUrlImport, setShowUrlImport] = useState(false)
  const [showPathImport, setShowPathImport] = useState(false)
  const [pathInput, setPathInput] = useState("")
  const [menuOpen, setMenuOpen] = useState<string | null>(null)
  const [currentHostname, setCurrentHostname] = useState<string>("")
  const menuRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const zipInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url
      if (url) {
        try {
          setCurrentHostname(new URL(url).hostname)
        } catch {
          setCurrentHostname("")
        }
      }
    })
  }, [state.tabList])

  const handleModeChange = (mode: "auto" | "all" | "manual") => {
    dispatch({ type: "SET_SKILL_SELECTION_MODE", mode })
    if (state.activeThreadId) {
      chrome.runtime.sendMessage({
        type: "thread.update",
        threadId: state.activeThreadId,
        updates: { skill_selection_mode: mode },
      })
    }
  }

  useEffect(() => {
    if (!menuOpen) return
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(null)
      }
    }
    document.addEventListener("mousedown", handler)
    return () => document.removeEventListener("mousedown", handler)
  }, [menuOpen])

  const handleFolderFiles = async (files: FileList | File[]) => {
    const fileArr = Array.from(files)
    if (fileArr.length === 0) return

    const hasSkillMd = fileArr.some(
      (f) => f.name === "SKILL.md" || f.webkitRelativePath.endsWith("/SKILL.md"),
    )
    if (!hasSkillMd) {
      alert("文件夹中未找到 SKILL.md 文件")
      return
    }

    const payload: { path: string; content: string }[] = []
    for (const file of fileArr) {
      const content = await file.text()
      const filePath = file.webkitRelativePath || file.name
      const parts = filePath.split("/")
      const relPath = parts.length > 1 ? parts.slice(1).join("/") : parts[0]
      payload.push({ path: relPath, content })
    }

    chrome.runtime.sendMessage({ type: "skill.import-files", files: payload })
  }

  const handlePathImport = () => {
    if (pathInput.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import-path", dir_path: pathInput.trim() })
      setPathInput("")
      setShowPathImport(false)
    }
  }

  const handleExport = (skillName: string) => {
    chrome.runtime.sendMessage({ type: "skill.export", skill_name: skillName })
    setMenuOpen(null)
  }

  const handleDelete = (skillName: string) => {
    if (confirm(`确定删除技能 "${skillName}"？`)) {
      chrome.runtime.sendMessage({ type: "skill.delete", skill_name: skillName })
    }
    setMenuOpen(null)
  }

  const handleImportFile = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const content = reader.result as string
      chrome.runtime.sendMessage({ type: "skill.import", content })
    }
    reader.readAsText(file)
  }

  const handleImportZip = (file: File) => {
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = reader.result as string
      const base64 = dataUrl.split(",")[1]
      if (base64) {
        chrome.runtime.sendMessage({ type: "skill.import-folder", zip_data: base64 })
      }
    }
    reader.readAsDataURL(file)
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()

    const items = e.dataTransfer.items
    if (items && items.length > 0) {
      const entry = items[0].webkitGetAsEntry()
      if (entry && entry.isDirectory) {
        const files = await readDirectoryEntry(entry as FileSystemDirectoryEntry)
        if (files.length > 0) {
          handleFolderFiles(files)
        }
        return
      }
    }

    const file = e.dataTransfer.files[0]
    if (!file) return
    if (file.name.endsWith(".zip")) {
      handleImportZip(file)
    } else if (file.name.endsWith(".md") || file.name.endsWith(".markdown")) {
      handleImportFile(file)
    }
  }

  const handleUrlImport = () => {
    if (importUrl.trim()) {
      chrome.runtime.sendMessage({ type: "skill.import", url: importUrl.trim() })
      setImportUrl("")
      setShowUrlImport(false)
    }
  }

  const skillList = Array.isArray(state.skills) ? state.skills : []
  const groupedSkills = groupSkillsBySite(skillList, currentHostname)

  const modeLabels: Record<string, string> = { auto: "自动", all: "全选", manual: "按需" }
  const skillMode = state.skillSelectionMode || "auto"
  const skillManual = skillMode === "manual"
  const skillModeHint =
    skillMode === "auto"
      ? "自动：按站点/消息匹配技能，列表勾选不生效（未勾选 ≠ 不会调用）。"
      : skillMode === "all"
        ? "全选：全部技能参与索引，无需单独勾选。"
        : "按需：仅勾选的技能会参与本对话。"

  return (
    <div style={styles.panelContent}>
      <div style={styles.modeSwitcher}>
        {(["auto", "all", "manual"] as const).map((mode) => (
          <button
            key={mode}
            style={{
              ...styles.modeBtn,
              background: skillMode === mode ? tokens.accent : tokens.bgElevated,
              color: skillMode === mode ? "#fff" : tokens.textSecondary,
              borderColor: skillMode === mode ? tokens.accent : tokens.border,
            }}
            onClick={() => handleModeChange(mode)}
            title={
              mode === "auto"
                ? "自动匹配当前站点和消息"
                : mode === "all"
                  ? "注入所有技能索引"
                  : "仅使用勾选技能"
            }
          >
            {modeLabels[mode]}
          </button>
        ))}
      </div>
      <div
        style={{
          fontSize: 10,
          color: tokens.textMuted,
          lineHeight: 1.4,
          marginBottom: 8,
        }}
      >
        {skillModeHint}
      </div>

      <div
        style={{
          fontSize: 10,
          color: tokens.textSecondary,
          lineHeight: 1.4,
          marginBottom: 8,
          padding: "6px 8px",
          background: tokens.accentSoft,
          borderRadius: tokens.radiusSm,
          border: `1px solid ${tokens.border}`,
        }}
      >
        <strong style={{ color: tokens.accentText }}>安装技能（推荐）</strong>
        <div style={{ marginTop: 3 }}>
          GitHub 仓库：下载 ZIP → <strong>导入 ZIP</strong>；或解压后用{" "}
          <strong>导入文件夹</strong>。单文件 skill 用「导入」.md。
        </div>
        <div style={{ marginTop: 3, color: tokens.textMuted }}>
          勿用「场景」里的「应用安全审查」装技能 — 那会限制本对话工具。
        </div>
      </div>

      <div style={styles.skillToolbar}>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => chrome.runtime.sendMessage({ type: "skill.refresh" })}
          title="重新扫描技能目录（含 ~/.cmspark-agent/skills 外部变更）"
        >
          ↻ 刷新
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => fileInputRef.current?.click()}
          title="从文件导入 .md"
        >
          📁 导入
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => zipInputRef.current?.click()}
          title="从 ZIP 导入文件夹技能"
        >
          📦 导入 ZIP
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowPathImport(!showPathImport)}
          title="从文件夹导入"
        >
          📂 导入文件夹
        </button>
        <button
          style={styles.skillToolbarBtn}
          onClick={() => setShowUrlImport(!showUrlImport)}
          title="从 URL 导入"
        >
          🔗 URL
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".md,.markdown"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportFile(file)
          }}
        />
        <input
          ref={zipInputRef}
          type="file"
          accept=".zip"
          style={{ display: "none" }}
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleImportZip(file)
          }}
        />
      </div>

      {showUrlImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="url"
            placeholder="https://...skill.md"
            value={importUrl}
            onChange={(e) => setImportUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleUrlImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handleUrlImport}>
            安装
          </button>
        </div>
      )}

      {showPathImport && (
        <div style={styles.urlImportRow}>
          <input
            style={styles.urlImportInput}
            type="text"
            placeholder="~/.claude/skills/datayes-api-search 或绝对路径"
            value={pathInput}
            onChange={(e) => setPathInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handlePathImport()}
          />
          <button style={styles.skillToolbarBtn} onClick={handlePathImport}>
            导入
          </button>
        </div>
      )}

      <div
        style={styles.dropZone}
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        {skillList.length === 0 && (
          <div style={styles.emptyText}>暂无技能，拖拽 .md 文件或点击导入</div>
        )}
      </div>

      {groupedSkills.map(([groupName, skills]) => (
        <div key={groupName}>
          <div style={styles.groupHeader}>{groupName}</div>
          {skills.map((skill) => {
            const active = state.activeSkillIds.includes(skill.name)
            return (
              <div
                key={skill.name}
                style={{
                  ...styles.skillRow,
                  background: skillManual && active ? tokens.bgActive : "transparent",
                }}
              >
                {skillManual ? (
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={() => {
                      const activeSkillIds = active
                        ? state.activeSkillIds.filter((id) => id !== skill.name)
                        : [...state.activeSkillIds, skill.name]
                      dispatch({ type: "TOGGLE_SKILL", skillId: skill.name })
                      if (state.activeThreadId) {
                        chrome.runtime.sendMessage({
                          type: "thread.update",
                          threadId: state.activeThreadId,
                          updates: { active_skill_ids: activeSkillIds },
                        })
                      }
                    }}
                    style={{ marginRight: 8, flexShrink: 0 }}
                    title="勾选后参与本对话"
                  />
                ) : (
                  <span
                    style={{
                      width: 16,
                      textAlign: "center",
                      color: tokens.textMuted,
                      fontSize: 11,
                      flexShrink: 0,
                      marginRight: 4,
                    }}
                    title={
                      skillMode === "all"
                        ? "全选模式：全部参与索引"
                        : "自动模式：由匹配决定，与勾选无关"
                    }
                    aria-hidden
                  >
                    {skillMode === "all" ? "◎" : "◇"}
                  </span>
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 500,
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    {skill.name}
                    {skill.site && <span style={styles.siteBadge}>{skill.site}</span>}
                  </div>
                  <div
                    style={{
                      fontSize: 11,
                      color: tokens.textSecondary,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {skill.description}
                  </div>
                </div>
                {skill.builtin && <span style={styles.badge}>内置</span>}
                {!skill.builtin && (
                  <div
                    style={{ position: "relative" }}
                    ref={menuOpen === skill.name ? menuRef : undefined}
                  >
                    <button
                      style={styles.menuBtn}
                      onClick={() => setMenuOpen(menuOpen === skill.name ? null : skill.name)}
                      title="更多操作"
                    >
                      ···
                    </button>
                    {menuOpen === skill.name && (
                      <div style={styles.menuDropdown}>
                        <button style={styles.menuItem} onClick={() => handleExport(skill.name)}>
                          📤 导出
                        </button>
                        <button
                          style={{ ...styles.menuItem, color: tokens.danger }}
                          onClick={() => handleDelete(skill.name)}
                        >
                          删除
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}

// ── Helpers ────────────────────────────────────────────────────────────────

async function readDirectoryEntry(dirEntry: FileSystemDirectoryEntry): Promise<File[]> {
  const files: File[] = []
  const folderName = dirEntry.name

  async function readDir(entry: FileSystemDirectoryEntry, prefix: string): Promise<void> {
    const reader = entry.createReader()
    const readBatch = (): Promise<FileSystemEntry[]> => {
      return new Promise((resolve) => {
        reader.readEntries((entries) => resolve(entries))
      })
    }

    let batch = await readBatch()
    while (batch.length > 0) {
      for (const e of batch) {
        if (e.isFile) {
          const file = await new Promise<File>((resolve) => {
            ;(e as FileSystemFileEntry).file(resolve)
          })
          ;(file as File & { webkitRelativePath: string }).webkitRelativePath = prefix + e.name
          files.push(file)
        } else if (e.isDirectory) {
          await readDir(e as FileSystemDirectoryEntry, prefix + e.name + "/")
        }
      }
      batch = await readBatch()
    }
  }

  await readDir(dirEntry, folderName + "/")
  return files
}

function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> {
  return arr.reduce(
    (acc, item) => {
      const k = String(item[key] ?? "unknown")
      if (!acc[k]) acc[k] = []
      acc[k].push(item)
      return acc
    },
    {} as Record<string, T[]>,
  )
}

type SkillListItem = {
  name: string
  description?: string
  site?: string
  builtin?: boolean
}

function groupSkillsBySite(
  skills: SkillListItem[],
  currentHostname: string,
): [string, SkillListItem[]][] {
  const list = Array.isArray(skills) ? skills : []
  const globalSkills = list.filter((s) => !s.site)
  const siteGroups = new Map<string, SkillListItem[]>()
  for (const skill of list.filter((s) => s.site)) {
    const key = skill.site!
    if (!siteGroups.has(key)) siteGroups.set(key, [])
    siteGroups.get(key)!.push(skill)
  }
  const result: [string, SkillListItem[]][] = []
  if (globalSkills.length > 0) {
    result.push(["全局", globalSkills])
  }
  const sortedSites = Array.from(siteGroups.entries()).sort((a, b) => {
    const aMatch = currentHostname && matchesSite(a[0], currentHostname) ? -1 : 0
    const bMatch = currentHostname && matchesSite(b[0], currentHostname) ? -1 : 0
    if (aMatch !== bMatch) return aMatch - bMatch
    return a[0].localeCompare(b[0])
  })
  for (const [site, siteSkills] of sortedSites) {
    result.push([site, siteSkills])
  }
  return result
}

function matchesSite(pattern: string, hostname: string): boolean {
  if (pattern.startsWith("*.")) {
    const suffix = pattern.slice(2)
    return hostname === suffix || hostname.endsWith("." + suffix)
  }
  return hostname === pattern
}

// ── Styles (panel body only) ───────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  panel: {
    borderTop: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
    // Apps「添加应用」needs room for search + policy + short list
    maxHeight: 320,
    overflowY: "auto",
    flexShrink: 0,
  },
  panelHeader: {
    position: "sticky",
    top: 0,
    zIndex: 2,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    padding: "6px 12px",
    background: tokens.bgElevated,
    borderBottom: `1px solid ${tokens.border}`,
  },
  panelTitle: {
    fontSize: 15,
    fontWeight: 600,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  panelCloseBtn: {
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusPill,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    fontSize: 11,
    fontWeight: 500,
    padding: "3px 10px",
    cursor: "pointer",
    fontFamily: tokens.font,
    flexShrink: 0,
  },
  panelContent: {
    padding: "10px 12px",
  },
  emptyText: {
    color: tokens.textSecondary,
    fontSize: 12,
    textAlign: "center",
    padding: 12,
  },
  tabRow: {
    display: "flex",
    alignItems: "center",
    padding: "3px 0",
    cursor: "pointer",
    fontSize: 12,
  },
  tabTitle: {
    flex: 1,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
  },
  tabUrl: {
    color: tokens.textMuted,
    fontSize: 10,
    fontFamily: tokens.fontMono,
  },
  groupHeader: {
    fontSize: 11,
    fontWeight: 600,
    fontFamily: tokens.fontMono,
    color: tokens.accent,
    marginBottom: 2,
  },
  historyRow: {
    display: "flex",
    alignItems: "center",
    padding: "2px 0",
  },
  skillRow: {
    display: "flex",
    alignItems: "center",
    padding: "6px 0",
    borderBottom: `1px solid ${tokens.bgMuted}`,
  },
  badge: {
    fontSize: 10,
    background: tokens.bgMuted,
    color: tokens.textSecondary,
    padding: "1px 6px",
    borderRadius: tokens.radiusSm,
  },
  skillToolbar: {
    display: "flex",
    flexWrap: "wrap",
    gap: 6,
    marginBottom: 8,
  },
  skillToolbarBtn: {
    whiteSpace: "nowrap",
    minHeight: 32,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    background: tokens.bgElevated,
    padding: "3px 10px",
    fontSize: 11,
    cursor: "pointer",
  },
  urlImportRow: {
    display: "flex",
    gap: 4,
    marginBottom: 8,
  },
  urlImportInput: {
    flex: 1,
    border: `1px solid ${tokens.border}`,
    borderRadius: tokens.radiusSm,
    padding: "4px 8px",
    fontSize: 11,
    fontFamily: tokens.fontMono,
    outline: "none",
  },
  dropZone: {
    minHeight: 24,
  },
  menuBtn: {
    background: "none",
    border: "none",
    fontSize: 14,
    cursor: "pointer",
    padding: "0 4px",
    color: tokens.textMuted,
  },
  menuDropdown: {
    position: "absolute",
    right: 0,
    top: "100%",
    background: tokens.bgElevated,
    border: `1px solid ${tokens.borderStrong}`,
    borderRadius: tokens.radiusMenu,
    boxShadow: tokens.shadowLg,
    zIndex: 10,
    overflow: "hidden",
    padding: 4,
    minWidth: 120,
  },
  menuItem: {
    display: "block",
    width: "100%",
    border: "none",
    background: "transparent",
    borderRadius: tokens.radiusMd,
    padding: "8px 12px",
    fontSize: 12,
    cursor: "pointer",
    textAlign: "left" as const,
    whiteSpace: "nowrap" as const,
    color: tokens.text,
    fontFamily: tokens.font,
  },
  modeSwitcher: {
    display: "flex",
    gap: 0,
    marginBottom: 8,
    borderRadius: tokens.radiusSm,
    overflow: "hidden",
    border: `1px solid ${tokens.border}`,
  },
  modeBtn: {
    flex: 1,
    border: "none",
    borderRight: `1px solid ${tokens.border}`,
    padding: "4px 0",
    fontSize: 11,
    cursor: "pointer",
    background: tokens.bgElevated,
  },
  siteBadge: {
    fontSize: 9,
    background: tokens.accentSoft,
    color: tokens.accentText,
    padding: "0px 4px",
    borderRadius: tokens.radiusSm,
    fontWeight: 400,
  },
}

CURRENT FILE chrome-extension/scripts/test-thread-mutations-ui.py
"""#488 actual App + recorded server payload shapes, isolated synthetic transport.
No live Chrome profile, conversation, microphone, or configuration is accessed.
"""
from pathlib import Path
import subprocess, tempfile
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-488-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
 with sync_playwright() as p:
  browser=p.chromium.launch(channel='chrome',headless=True)
  errors=[]
  def setup(count=60,trash=False,width=390,height=740):
   page=browser.new_page(viewport={'width':width,'height':height});page.set_default_timeout(7000)
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
   page.evaluate('''({count,trash})=>{
    const threads=Array.from({length:count},(_,i)=>({...window.demoThreads[0],id:'t'+i,alias:'对话 '+i,message_count:4,user_tags:[i<2?'支付':'架构'],trashed_at:trash?'2026-09-09T00:00:00Z':null}));
    window.fixtureServerThreads=structuredClone(threads);
    window.dispatchUI({type:'SET_THREADS',threads});window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'t0'});
   }''',{'count':count,'trash':trash})
   page.get_by_role('button',name='对话管理（历史对话）',exact=True).click()
   manager=page.get_by_role('dialog',name='历史对话列表',exact=True);manager.wait_for()
   if trash:
    manager.get_by_role('button',name='回收站',exact=True).click()
    manager.get_by_text(f'回收站 · {count}',exact=False).wait_for()
   return page,manager
  def select_all(manager):manager.get_by_role('button',name='全选',exact=True).click()
  def confirm_delete(manager,hard=False):
   manager.locator('.cm-thread-selection-bar').get_by_role('button',name='永久删除' if hard else '移入回收站',exact=True).click()
   dialog=manager.get_by_role('alertdialog',name='确认删除会话');dialog.wait_for()
   assert dialog.get_by_role('button',name='取消',exact=True).evaluate('(el)=>el===document.activeElement')
   dialog.get_by_role('button',name='永久删除' if hard else '移入回收站',exact=True).click()

  # A visible tag filter is the complete selection boundary.
  page,m=setup();m.get_by_role('button',name='标签',exact=True).click();m.get_by_role('button',name='#支付 2',exact=True).click()
  select_all(m);m.get_by_text('已选 2',exact=True).wait_for()
  page.evaluate('window.mutationReply="defer"');confirm_delete(m)
  assert page.evaluate('window.mutationRequests[0].thread_ids')==['t0','t1']
  assert page.evaluate('window.fixtureState.threads.length')==60
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.fixtureState.threads.length===58');page.close()

  # Single-row deletion also goes through the correlated batch protocol.
  page,m=setup(3);page.evaluate('window.mutationReply="defer"')
  m.locator('[data-thread-id="t1"]').get_by_role('button',name='删除 对话 1',exact=False).click()
  m.get_by_role('alertdialog').get_by_role('button',name='移入回收站',exact=True).click()
  assert page.evaluate('window.mutationRequests.map(m=>({type:m.type,ids:m.thread_ids}))')==[{'type':'thread.batch_delete','ids':['t1']}]
  assert page.evaluate('window.fixtureState.threads.length')==3
  assert not page.evaluate('window.sent.some(m=>m.type==="thread.delete")')
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.fixtureState.threads.length===2');page.close()

  # More than 50 items are sent serially; a transport ACK never removes rows.
  page,m=setup();page.evaluate('window.mutationReply="defer"');select_all(m);confirm_delete(m)
  assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids.length)')==[50]
  assert page.evaluate('window.fixtureState.threads.length')==60
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.mutationRequests.length===2')
  assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids.length)')==[50,10]
  page.evaluate('window.finishThreadMutation(window.mutationRequests[1])')
  page.wait_for_function('window.fixtureState.threads.length===0');page.close()

  # Busy/filter changes only shrink a selection; no deletion of another row.
  for change in ['busy','filter']:
   page,m=setup(3);m.get_by_role('button',name='选择',exact=True).click()
   m.locator('[data-thread-id="t0"] input[type="checkbox"]').check()
   if change=='busy':page.evaluate('window.dispatchUI({type:"SET_THREAD_BUSY",threadId:"t0",busy:true})')
   else:m.get_by_role('searchbox').fill('对话 1')
   m.get_by_text('已选 0',exact=True).wait_for()
   assert m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).is_disabled()
   assert page.evaluate('window.mutationRequests.length')==0;page.close()

  # Confirmation re-checks busy state even after the target preview was opened.
  page,m=setup(2);select_all(m)
  m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).click()
  page.evaluate('window.dispatchUI({type:"SET_THREAD_BUSY",threadId:"t0",busy:true})')
  m.get_by_role('alertdialog').get_by_role('button',name='移入回收站',exact=True).click()
  m.get_by_role('status').filter(has_text='状态已变化').wait_for()
  assert page.evaluate('window.mutationRequests.length')==0;page.close()

  # Offline and partial failures retain failed records with an actionable result.
  page,m=setup(3);page.evaluate('window.mutationReply="offline"');select_all(m);confirm_delete(m)
  m.get_by_role('status').filter(has_text='未发送').wait_for()
  assert page.evaluate('window.fixtureState.threads.length')==3;page.close()
  page,m=setup(3);page.evaluate('window.mutationFailedIds=["t1"]');select_all(m);confirm_delete(m)
  page.wait_for_function('window.fixtureState.threads.length===1')
  assert page.evaluate('window.fixtureState.threads[0].id')=='t1'
  m.get_by_role('status').filter(has_text='已移入回收站 2').wait_for();page.close()

  # Restore waits for persistence, then refreshes including remaining trash rows.
  page,m=setup(3,trash=True);page.evaluate('window.mutationReply="defer";window.mutationFailedIds=["t1"]');select_all(m)
  m.locator('.cm-thread-selection-bar').get_by_role('button',name='恢复',exact=True).click()
  assert page.evaluate('window.fixtureState.threads.filter(t=>t.trashed_at).length')==3
  page.evaluate('window.finishThreadMutation(window.mutationRequests[0])')
  page.wait_for_function('window.fixtureState.threads.filter(t=>t.trashed_at).length===1')
  assert page.evaluate('window.fixtureState.threads.find(t=>t.trashed_at).id')=='t1'
  assert page.evaluate('window.sent.filter(m=>m.type==="thread.list").at(-1).include_trashed') is True
  page.close()

  # Empty cleanup uses an in-app preview, probes safely, and rechecks server content.
  for legacy in [False,True]:
   page,m=setup(3)
   page.evaluate('''legacy=>{window.legacyEmptyProbe=legacy;
    const threads=window.fixtureState.threads.map(t=>({...t,message_count:0}));
    window.dispatchUI({type:'SET_THREADS',threads});
    window.fixtureServerThreads=threads.map(t=>({...t,message_count:t.id==='t1'?1:0}));
   }''',legacy)
   m.get_by_title('更多',exact=True).click()
   page.get_by_role('menu').get_by_role('button',name='🧹 清理空白',exact=True).click()
   m.get_by_role('alertdialog').get_by_role('button',name='永久删除',exact=True).click()
   if legacy:
    m.get_by_role('status').filter(has_text='请更新 Companion').wait_for()
    assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids)')==[[]]
    assert page.evaluate('window.fixtureState.threads.length')==3
   else:
    page.wait_for_function('window.fixtureState.threads.length===2')
    assert page.evaluate('window.mutationRequests.map(m=>m.thread_ids)')==[[],['t1','t2']]
    assert page.evaluate('window.fixtureState.threads.map(t=>t.id)')==['t0','t1']
   page.close()

  # Cleanup's checkboxes and bulk-list selection are visibly separate scopes.
  page,m=setup(4)
  page.evaluate('window.dispatchEvent(new CustomEvent("cmspark:cleanup_suggestions",{detail:{suggestions:[{thread_id:"t1",reason:"thin",detail:"test",precheck:true},{thread_id:"t2",reason:"thin",detail:"test"}]}}))')
  cleanup=m.get_by_role('region',name='整理建议');cleanup.wait_for()
  select_all(m)
  assert cleanup.locator('input:checked').count()==1
  cleanup.get_by_role('button',name='全选建议',exact=True).click()
  assert cleanup.locator('input:checked').count()==2
  m.get_by_role('button',name='取消全选',exact=True).click()
  assert cleanup.locator('input:checked').count()==2
  cleanup.get_by_role('button',name='清空建议选择',exact=True).click()
  assert cleanup.get_by_role('button',name='移入回收站（0）',exact=True).is_disabled();page.close()

  # Short windows retain scrollable rows, all management tools and outside stop.
  for width,height in [(320,480),(390,740),(760,740),(1440,900)]:
   page,m=setup(6,width=width,height=height)
   for view in ['时间','标签','手动分组','AI 分组']:
    m.get_by_role('button',name=view,exact=True).click()
    assert m.locator('.cm-thread-management-list').bounding_box()['height']>=100
    assert m.evaluate('(el)=>el.scrollWidth<=el.clientWidth')
   m.get_by_role('button',name='时间',exact=True).click();select_all(m)
   m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).scroll_into_view_if_needed()
   assert m.locator('.cm-thread-selection-bar').get_by_role('button',name='移入回收站',exact=True).evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
   m.get_by_role('button',name='取消选择',exact=True).click()
   for label in ['AI 提取标签','整理助手','关系图谱','回收站']:
    button=m.get_by_role('button',name=label,exact=True);button.scroll_into_view_if_needed();assert button.is_visible()
   m.evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(shots/f'manager-{width}.png'));page.close()
  assert not errors,errors
  browser.close()
print('PASS: actual App selection boundaries, busy/filter race, 60-item batching, ACK vs persisted result, offline/partial failure, restore, independent cleanup scope and responsive management capabilities.')

CURRENT FILE chrome-extension/scripts/test-meeting-close-ui.py
"""Production Host/Meeting/adapter, synthetic PCM + transport. No real audio."""
from pathlib import Path
import subprocess
import tempfile
from playwright.sync_api import sync_playwright

project = Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='cmspark-meeting-close-') as directory:
    subprocess.run(['node', 'scripts/render-meeting-close-fixture.cjs', directory], cwd=project, check=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        def open_fixture(standalone=False):
            page.goto((Path(directory)/'index.html').as_uri() + ('?standalone' if standalone else ''))
            page.get_by_test_id('meeting-start-capture').wait_for()
            page.wait_for_function('!document.querySelector("[data-testid=meeting-start-capture]").disabled')
        def start():
            page.get_by_test_id('meeting-start-capture').click()
            page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.start")')
            page.evaluate('window.capture.onPcmChunk(new Uint8Array(32000))')
        def final():
            page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
            assert page.get_by_test_id('meeting-panel').is_visible()
            assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
            page.evaluate("window.emit({type:'voice.stt.result',sessionId:window.sent.find(m=>m.type==='voice.stt.end').sessionId,text:'最后一段合成转写'})")
        for action in ['host', 'inner', 'skills', 'escape', 'settings', 'latest', 'owner']:
            open_fixture(); start()
            if action == 'host': page.get_by_role('button',name='结束并收起',exact=True).click()
            elif action == 'inner': page.get_by_role('button',name='结束录制并收起面板',exact=True).click()
            elif action == 'skills': page.get_by_role('button',name='切换技能',exact=True).click()
            elif action == 'settings': page.get_by_role('button',name='打开设置',exact=True).click()
            elif action == 'latest':
                page.get_by_role('button',name='切换技能',exact=True).click()
                page.get_by_role('button',name='切换知识',exact=True).click()
            elif action == 'owner':
                page.get_by_role('button',name='结束并收起',exact=True).click()
                page.evaluate("window.emit({type:'meeting.created',meeting:{id:'other-meeting'}})")
            else:
                page.get_by_role('button',name='结束并收起',exact=True).focus()
                page.keyboard.press('Escape')
            final()
            page.wait_for_function('window.activePanel!=="meeting"')
            assert page.evaluate('window.persisted') == ['最后一段合成转写']
            assert page.evaluate('window.captureStops') == 1
            assert page.evaluate('window.captureAborts') == 0
            types = page.evaluate('window.sent.map(m=>m.type)')
            assert types.index('meeting.append_transcript') < types.index('meeting.get') < types.index('meeting.end')
            assert page.evaluate("window.sent.filter(m=>['meeting.append_transcript','meeting.get','meeting.end'].includes(m.type)).every(m=>m.id==='meeting-fixture')")
            if action == 'settings': assert page.get_by_test_id('settings-state').inner_text() == '设置已打开'
            if action == 'latest': assert page.evaluate('window.activePanel') == 'knowledge'
        # A successful forwarding ACK / incorrect persisted snapshot must not close.
        open_fixture(); start(); page.evaluate('window.failRead=true')
        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
        page.get_by_role('alert').filter(has_text='尚未确认保存').wait_for()
        assert page.evaluate('window.activePanel') == 'meeting'
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        page.evaluate('window.failRead=false')
        page.get_by_role('button',name='收起面板',exact=True).click()
        page.wait_for_function('window.activePanel===null')
        # Review finding 2: failure retains the meeting and a repeated Settings
        # action retries successfully; it must not force-close or silently lose text.
        open_fixture(); start(); page.evaluate('window.failRead=true')
        settings_button = page.get_by_role('button',name='打开设置',exact=True)
        settings_button.click(); final()
        page.get_by_role('alert').filter(has_text='尚未确认保存').wait_for()
        assert page.evaluate('window.activePanel') == 'meeting'
        assert page.get_by_test_id('settings-state').inner_text() == '设置未打开'
        assert settings_button.is_enabled()
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        assert page.evaluate('window.persisted') == ['最后一段合成转写']
        page.evaluate('window.failRead=false')
        settings_button.click()
        page.wait_for_function('window.activePanel===null')
        assert page.get_by_test_id('settings-state').inner_text() == '设置已打开'
        assert page.evaluate('window.sent.filter(m=>m.type==="meeting.get").length') == 2
        print('PASS settings readback failure: visible error + meeting retained; repeated Settings action completes after recovery')
        # Review finding 3: no Host and no registerBeforeClose prop. The inner
        # button still uses the production fallback guard and delays onClose.
        open_fixture(standalone=True); start(); page.evaluate('window.deferEnd=true')
        page.get_by_role('button',name='结束录制并收起面板',exact=True).click(); final()
        page.wait_for_function('window.sent.some(m=>m.type==="meeting.end")')
        assert page.get_by_test_id('meeting-panel').is_visible()
        assert not page.evaluate('window.sent.some(m=>m.type==="fixture.closed")')
        page.evaluate("window.emit({type:'meeting.ended',meeting:window.snapshot()})")
        page.wait_for_function('window.activePanel===null')
        assert page.evaluate('window.persisted') == ['最后一段合成转写']
        types = page.evaluate('window.sent.map(m=>m.type)')
        assert types.index('meeting.append_transcript') < types.index('meeting.get') < types.index('meeting.end') < types.index('fixture.closed')
        assert types.count('fixture.closed') == 1
        print('PASS standalone MeetingPanel without registerBeforeClose: final → persisted readback → end ACK → exactly one onClose')
        # Final dispatch is not end confirmation: keep the owner mounted until ACK.
        open_fixture(); start(); page.evaluate('window.deferEnd=true')
        page.get_by_role('button',name='结束并收起',exact=True).click(); final()
        page.wait_for_function('window.sent.some(m=>m.type==="meeting.end")')
        assert page.evaluate('window.activePanel') == 'meeting'
        page.evaluate("window.emit({type:'meeting.ended',meeting:{id:'other'}})")
        assert page.evaluate('window.activePanel') == 'meeting'
        page.evaluate("window.emit({type:'meeting.ended',meeting:window.snapshot()})")
        page.wait_for_function('window.activePanel===null')
        # Closing before meeting.started must not acquire a mic when start arrives.
        open_fixture(); page.evaluate('window.deferStart=true')
        page.get_by_test_id('meeting-start-capture').click()
        page.get_by_role('button',name='结束并收起',exact=True).click()
        page.wait_for_timeout(20)
        page.evaluate("window.emit({type:'meeting.started',meeting:window.snapshot()})")
        page.wait_for_function('window.activePanel===null')
        assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start")')
        # Import stop keeps the current final, saves it, and skips remaining segments.
        open_fixture()
        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
        page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.end")')
        page.get_by_role('button',name='结束并收起',exact=True).click()
        final()
        page.wait_for_function('window.activePanel===null')
        assert page.evaluate('window.persisted') == ['最后一段合成转写']
        assert page.evaluate('window.sent.filter(m=>m.type==="voice.stt.start").length') == 1
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        # Closing while decoding cancels before creating a meeting or STT session.
        open_fixture(); page.evaluate('window.deferDecode=true')
        page.locator('input[type=file][accept^="audio/"]').set_input_files({'name':'synthetic.wav','mimeType':'audio/wav','buffer':b'synthetic decoder fixture'})
        page.wait_for_function('!!window.finishDecode')
        page.get_by_role('button',name='结束并收起',exact=True).click()
        page.wait_for_timeout(20); page.evaluate('window.finishDecode()')
        page.wait_for_function('window.activePanel===null')
        assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start"||m.type==="meeting.create")')
        # Accelerate only the production 20s stop deadline; transport/final absent.
        page.add_init_script("const timeout=window.setTimeout.bind(window);window.setTimeout=(f,ms,...args)=>timeout(f,ms===20000?40:ms,...args)")
        open_fixture(); start()
        page.get_by_role('button',name='结束并收起',exact=True).click()
        page.get_by_role('alert').filter(has_text='未完整处理').wait_for()
        assert page.evaluate('window.activePanel') == 'meeting'
        assert not page.evaluate('window.sent.some(m=>m.type==="meeting.end")')
        assert not errors, errors
        browser.close()
print('PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation')

CURRENT FILE chrome-extension/scripts/render-meeting-close-fixture.cjs
// Actual MeetingPanel + ContextPanelHost + local STT adapter. Only PCM input and
// transport are synthetic; no live Companion, microphone, or user data.
const fs = require('fs'), path = require('path');
const root = process.cwd(), out = process.argv[2];
if (!out) throw new Error('output directory required');
fs.mkdirSync(out, { recursive: true });
const source = `
import React,{useEffect,useState} from 'react';import{createRoot}from'react-dom/client';
import{AgentStoreProvider,initialState,useAgentStore}from'./src/sidepanel/store/agentStore';
import{ContextPanelHostProvider,ContextPanelHost,useContextPanelHost}from'./src/sidepanel/components/ContextPanelHost';
import{MeetingPanel}from'./src/sidepanel/components/MeetingPanel';
const listeners=new Set();window.sent=[];window.persisted=[];window.deferStart=false;window.failRead=false;window.deferEnd=false;
window.emit=m=>{for(const fn of [...listeners])fn(m)};
window.snapshot=()=>({id:'meeting-fixture',status:'ready',transcript:window.persisted.map(text=>({text,source:'stt'}))});
const event={addListener(){},removeListener(){}};
window.chrome={runtime:{id:'fixture',onMessage:{addListener:f=>listeners.add(f),removeListener:f=>listeners.delete(f)},sendMessage:(m,cb)=>{
window.sent.push(m);queueMicrotask(()=>{cb?.({ok:true});
if(m.type==='meeting.start'&&!window.deferStart)window.emit({type:'meeting.started',meeting:window.snapshot()});
if(m.type==='meeting.create')window.emit({type:'meeting.created',meeting:window.snapshot()});
if(m.type==='meeting.append_transcript'){window.persisted.push(m.text);window.emit({type:'meeting.updated',meeting:window.snapshot()})}
if(m.type==='meeting.set_transcript'){window.persisted=m.text.split('\\n');window.emit({type:'meeting.updated',meeting:window.snapshot()})}
if(m.type==='meeting.get')window.emit({type:'meeting.get_result',meeting:window.failRead?{...window.snapshot(),transcript:[]}:window.snapshot()});
if(m.type==='meeting.end'&&!window.deferEnd)window.emit({type:'meeting.ended',meeting:window.snapshot()});
});return Promise.resolve({ok:true})}},storage:{local:{get:(k,cb)=>{const r={meeting_privacy_ack_v1:true};cb?.(r);return Promise.resolve(r)},set:(v,cb)=>{cb?.();return Promise.resolve()}},onChanged:event},tabs:{query:(q,cb)=>{cb?.([]);return Promise.resolve([])}}};
function Harness(){const h=useContextPanelHost();const{state,dispatch}=useAgentStore();window.dispatchUI=dispatch;window.activePanel=h.activePanel;
useEffect(()=>h.openPanelForce('meeting'),[]);return <><button onClick={()=>h.openPanelForce('skills')}>切换技能</button><button onClick={()=>h.openPanelForce('knowledge')}>切换知识</button><button onClick={()=>dispatch({type:'SET_SETTINGS_OPEN',open:true})}>打开设置</button><span data-testid='settings-state'>{state.settingsOpen?'设置已打开':'设置未打开'}</span><ContextPanelHost/></>}
function Standalone(){const[open,setOpen]=useState(true);window.activePanel=open?'meeting':null;return open?<MeetingPanel onClose={()=>{window.sent.push({type:'fixture.closed'});setOpen(false)}} onSendToDraft={()=>{}}/>:<span>独立面板已关闭</span>}
createRoot(document.getElementById('root')).render(<AgentStoreProvider initialState={{...initialState,connectionState:'connected',activeThreadId:'thread-fixture',voicePrivacyAckV2:true,voiceRealtimeStreaming:true,voiceModel:{localModelId:'medium',binary:{status:'ready'},models:{medium:{status:'ready'}}}}}>{location.search.includes('standalone')?<Standalone/>:<ContextPanelHostProvider capabilityLevel='chat'><Harness/></ContextPanelHostProvider>}</AgentStoreProvider>);
`;
const capture = `export async function startPcmStreamCapture(opts){window.capture=opts;window.captureStops=0;window.captureAborts=0;return{backend:'scriptprocessor',stop:async()=>{window.captureStops++},abort:()=>{window.captureAborts++}}}`;
const audioImport = `export * from ${JSON.stringify(path.join(root,'src/sidepanel/voice/meeting-audio-import.ts'))};import{wrapPcmS16leAsWav}from ${JSON.stringify(path.join(root,'src/sidepanel/voice/pcm-encode.ts'))};export async function fileToWavSegments(){if(window.deferDecode)await new Promise(r=>window.finishDecode=r);const wav=wrapPcmS16leAsWav(new Uint8Array(32000),16000,1);return{ok:true,segments:[{wav},{wav}],durationSec:2}}`;
require(path.join(root,'node_modules/esbuild')).build({stdin:{contents:source,resolveDir:root,loader:'tsx'},bundle:true,outfile:path.join(out,'app.js'),jsx:'automatic',plugins:[{name:'synthetic-pcm',setup(b){b.onResolve({filter:/\/pcm-stream-capture$/},()=>({path:'pcm-fixture',namespace:'fixture'}));b.onResolve({filter:/\/meeting-audio-import$/},()=>({path:'import-fixture',namespace:'fixture'}));b.onLoad({filter:/.*/,namespace:'fixture'},args=>({contents:args.path==='import-fixture'?audioImport:capture,loader:'ts',resolveDir:root}));}}]}).then(()=>fs.writeFileSync(path.join(out,'index.html'),'<html lang="zh-CN"><meta charset="utf-8"><body><div id="root"></div><script src="app.js"></script></body></html>')).catch(e=>{console.error(e);process.exitCode=1});

MACHINE mutations-ui-final.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpnu_yx3wo
PASS: actual App selection boundaries, busy/filter race, 60-item batching, ACK vs persisted result, offline/partial failure, restore, independent cleanup scope and responsive management capabilities.

MACHINE meeting-review-rebuttal-ui.log
PASS settings readback failure: visible error + meeting retained; repeated Settings action completes after recovery
PASS standalone MeetingPanel without registerBeforeClose: final → persisted readback → end ACK → exactly one onClose
PASS meeting final PCM → STT result → append → readback → end → all close/navigation paths; failure retained/retry; pending start never opens mic; import in-flight final saved and next segment canceled; decode canceled before meeting creation

MACHINE resources-ui-final.log
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmp1jd8q5xf
PASS: six resource entries retained, explicit scope copy, responsive skills and resource drawer screenshots

Validation: Node22 npm run build exit0 after copy correction; actual resource UI PASS across320/390/1440; no privilege/channel/tool changes.
