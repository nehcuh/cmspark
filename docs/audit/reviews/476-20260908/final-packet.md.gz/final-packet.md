Independent two-part gate: (A) revised overall DESIGN #476, (B) isolated unintegrated identity primitive #480. Keep verdicts separate, under1100 words. Not release completion: #480 has no launcher/native host/transport integration and stays open. Do not demand integration in this primitive commit; do require the plan's launch/confirm prerequisites before later integration. No tools or other reports. Prototype tsc +6 meaningful negative/lifecycle test groups PASS. Review source for real correctness/security defects; plan for concrete trust roots, native OS confirmation, lifecycle/order/exit tests. End DESIGN_VERDICT and PROTOTYPE_VERDICT each APPROVE/APPROVE_WITH_NITS/REJECT.

## docs/superpowers/plans/2026-09-08-desktop-workbench.md
# Desktop workbench
GitHub: #476 · first UI slice #477
Status: revised design under independent review; not implementation-complete.

## Outcome and close rule
Without Codex, users can converse, manage conversations/MCP/skills/knowledge, work with local files/terminal and optional programming agents. Web tasks connect the user's existing Chrome through the current authenticated extension; no headless browser or copied login profile. Non-web tasks must not need that extension. Keep the existing summon hotkey and a compact view.

For this plan, complete native macOS/Windows desktop hosting is required before closing #476. Chromium app-mode in #477 is explicitly transitional; it is not evidence of browser-free hosting. #477 alone cannot close #476. No claim of Codex feature parity, no new mandatory agent/provider, no automatic changes to live configuration. Local processes running as the same user with access to application memory/credentials remain inside the existing local-user trust boundary; this design does not claim OS process attestation against them.

## Current evidence
- `summoner/shell-open.ts`: Chromium app-mode shell with isolated UI profile, originally360x420; it is not the user's automated Chrome profile and is not a native webview.
- `summoner-web.ts`: hidden resources, full-card history, list-only MCP with stale toggle calling404. Existing knowledge/skills controls only attach to a conversation.
- `ws/summoner-acl.ts`: overlay alias/trash policy; no web MCP writes/config/terminal/confirm. An older WS toggle allowlist exists and must be audited, never used as desktop bootstrap.
- `menu-bar-agent.ts`: HTTP/SSE shell delegates to authenticated summoner client. Existing tray client is a different role. Neither receives desktop privileges by rendering a wider window.
- `ws/lifecycle.ts`, `ws-auth.ts`: current shared-secret challenge authenticates existing clients; a forged surface string must not become a new grant.
- `message-router/handlers/mcp.ts`: stdio changes can spawn processes and require security confirmation. Handler reuse does not remove that requirement.
- `summoner/client.ts`: Chrome foreground flag currently controls opening only; background fallback can activate a window. This is not a per-task visibility policy.

## Interface
One visual language with the accepted extension chat: neutral paper/ink,220px text navigation,780px reading column, clear headings and search. Navigation: conversations, local work, MCP, skills, knowledge, browser; settings at foot. No icon-only ribbon, mountains, decorative counters or gradients. At760px and above use persistent navigation; below760 use bounded in-flow disclosure so composer/stop survive. Workspace1040x760; compact360x420; clamp to available screen, retain user-resized geometry. Resource management is a real content page, not a list with non-working buttons.

## Desktop trust root and lifecycle
The existing HTTP/SSE overlay remains overlay-restricted even when wide. Privileged desktop functionality starts only in the native host slice:
1. Companion launches its bundled, integrity-verified native desktop host. An internal launch function creates a32-byte cryptographically random capability, scoped to one host session and an explicit desktop method set, kept in daemon memory. The immutable single source is `desktop/capabilities.ts` (initial prototype colocates `DESKTOP_READ_METHODS` in `desktop/identity.ts`; move without semantic duplication at integration). A capability stores its issued method-set version. Adding methods requires revocation/remint by the launcher after the owning gate, never a renderer upgrade. This function is not exposed through WS, HTTP, MCP, overlay or renderer messages.
2. Deliver the capability to the child through an inherited anonymous pipe, never argv, environment, URL, file, HTML/JS, cookie or logs. Only issuer and intended native child may hold the bootstrap endpoint: use close-on-exec/explicit FD inheritance on macOS and an explicit Windows handle-inheritance allowlist, clear inheritance before any further child spawn. Native code consumes and closes the pipe. Tests inspect sibling/descendant handles and captured argv/env/logs; the capability must be absent outside issuer and intended native host. The app launcher reaches this daemon launch operation only through the existing authenticated local tray path; overlay cannot mint capabilities. A native host started without bootstrap may display setup/error, never gain privileges.
3. A dedicated desktop WS origin/auth kind accepts server challenge proofs made with that capability. The daemon resolves role from its own capability registry, not a client `surface` field. Use HMAC-SHA256, key=the32-byte capability secret, input=UTF-8 JSON array `["cmspark.desktop.auth.v1", capabilityId, serverConnectionId, protocolVersion, nonce]`, with IDs generated as ASCII hex and protocol a negotiated positive integer. This is a separate auth-kind/domain from pairing proof; wire handlers live in `desktop/auth.ts`, not `surfaceFromOrigin`. Bind nonce, protocol version and server-assigned session ID. Single-use challenge, handshake deadline and replay rejection. Existing pairing shared secret alone cannot authenticate as desktop.
4. Native bridge alone owns WS/proof. Bundled renderer assets cannot see credentials. macOS pins `cmspark-desktop://app/` via a bundle-only WKURLSchemeHandler; Windows pins `https://cmspark-desktop.invalid/` via bundle-only WebView2 virtual-host mapping with restrictive resource access. Bridge accepts only the expected main frame/document generation at that origin. Deny path traversal, subframe messages, new-window navigation, downloads, file/http/remote navigation and external scripts. Disable inspectable/DevTools in production. A CSP permits bundled assets only. Explicit external links use a separately validated user-action opener, never navigation of the privileged document. Unvalidated methods/fields are rejected. Untrusted chat/MCP/knowledge content remains inert text/sanitized Markdown. Native dialog/window visibility is not consent.
5. Disconnect immediately cancels origin-owned confirmations. A transient native WS reconnect may reauthenticate the same live host capability with a fresh nonce; it gets a new connection ID and cannot redeem previous challenges. Every normal exit, crash, kill, failed launch and OS process teardown deletes capability and stops its sockets. Parent process close/error monitoring owns this, not a renderer pagehide message. Explicit close/revoke does the same. Daemon restart rotates all by discarding registry; relaunch supplies a new capability. Never fall back to tray credentials on desktop-auth failure.
6. Compact/workspace sizes are views within that native host, with identical identity. Resizing never promotes/demotes access. Transitional Chromium overlay cannot become privileged by switching view. One running host per user instance: acquire a launcher singleton state/lock before minting or spawning, including the in-flight-launch state. Concurrent summon requests share that launch; another summon focuses/toggles existing host rather than minting a second grant. Release failed launches with revocation before retry. Switching conversations is explicit and does not transfer challenges.

## Ordered slices and exit gates
### 1. Transitional shell (#477, T2)
Implement visible text navigation/history search/resources,1040x760 workspace plus compact action. MCP read-only: remove stale toggle; no dispatch to mcp.add/update/remove/toggle. Expose current peer status and Chrome opening actions honestly. Keep same thread/store/ACL. Skills/knowledge here are only existing thread attachments, not install/import/edit/delete. No live-looking durable settings/skill/knowledge write controls. Exit: real HTML at320/390/760/1440 and420/480px heights; search/create/select, async panel race, empty/error states, new conversation, busy Stop hit testing with navigation open, Escape/focus and no overflow. GET peer status is authenticated. Native frozen overlay behavior remains unchanged. Cannot close #476.

### 2. Native host and desktop identity (T3; read-only)
First inventory every existing tray/summoner/extension constructor and handshake. Compatibility matrix must prove: authenticated explicit tray unchanged; tray-Origin omitted/unknown wire surface remains rejected (CompanionClient already emits explicit tray by default); extension omission resolves panel; extension cannot claim tray/desktop; summoner denied privileged methods; unknown/unissued desktop always denied. Do not replace legacy routing with a broad `surface !== summoner` grant for the third client. Any necessary legacy migration lands with its own tests before desktop enablement.
Implement trust lifecycle above on macOS WKWebView and Windows WebView2, using bundled assets and native-only bridge. Desktop allowlist initially ping plus masked read-only conversation/resource listing. No CRUD/connect/spawn/confirm response yet. Initial resource DTOs contain only IDs/names/descriptions/connection status, not config objects, tokens, env/header names or trust-setting fields. Prior-output browsing must pass this same read-only method table, resource binding and projection gate, not a shortcut. Exit: mint inaccessible to renderer/overlay; forged role, shared-secret-only proof, invalid/replayed/expired proof, wrong origin/frame, remote navigation and revoked session denied. Host restart/duplicate summon/compact-to-wide retains one instance and does not elevate. No auth material in logs/argv/document. Native builds and connection tests on both OSes. Test concurrent double-launch, failed spawn, crash/kill, sibling handle inheritance, custom-origin traversal/remote/new-window/download/DevTools denial. Once native is enabled, the existing summon hotkey targets this native singleton in compact/workspace mode; legacy Chromium is an explicitly separate unprivileged fallback only, never silently chosen for management. Missing WebView2 gives explicit setup failure, never privileged browser fallback.

### 3. Desktop confirmation (T3; prerequisite for every sensitive operation)
Reuse existing security confirmation manager, never a second acceptance queue. Register issuing native connection as confirmation owner. Bind challenge to connection, thread, exact normalized action/payload and expiry; consume once. Present decisions in native OS chrome (macOS NSAlert / Windows TaskDialog or equivalent isolated native dialog), never inside the WebView that renders chat/knowledge/MCP content. The native controller alone owns the challenge and decision callback; the renderer message allowlist excludes approval responses. Show exact normalized action and critical evidence in native controls. Test that forged main-frame/subframe/chat approval messages and DOM overlays cannot produce a decision. Reject wrong thread/connection/surface, valid web ID presented by desktop, duplicate response, expired/changed-payload response. Cancel on socket close, host exit, abort and revocation; cancellation wins an in-flight approve race, and reconnect cannot approve an old request. Explicitly test cancel-vs-approve and disconnect/reconnect races against the actual manager. Preserve critical-action wording, L2 policies, dangerous stdio/skill-install force-confirm and existing extension behavior. Exit includes every negative above plus approve/deny/abort/reconnect tests through actual manager. No management/execution slice may proceed without this gate passing.

### 4. Desktop management (T3; depends on2+3)
Reuse existing handlers and persisted stores; no new cache/agent. Each exposed method gets an exact schema and resource binding before UI:
| Family | Request boundary | Response / secret rule | Required acceptance |
|---|---|---|---|
| Conversation | validated thread ID; allowlisted alias/folder/user_tags only; trash explicit | actual persisted metadata; no trust fields | save failure retained; reload; wrong-thread/stale response |
| MCP | validated name and existing transport schema; reject unknown/prototype fields; connect/stdio uses existing confirmation | actual connection metadata; redact env/header secrets, never echo stored secrets to renderer | CRUD/connect failure, denied stdio spawn, masked-secret preservation |
| Skills | existing preview/install/update schema and source rules; per-action allowlist | sanitized metadata/content; no inferred installation success | preview/deny/confirm/import validation and actual disk result |
| Knowledge | existing import/update/delete schemas, document identity and SSRF/path gates | persisted document state; untrusted content inert | bad source, wrong document, deletion denial and reload |
| Settings | explicit preference keys only; security/trust/elevation excluded from generic patch | masked reads; confirmation-bound secret updates under the same schema/confirm/redaction bar as MCP | unknown key/prototype rejection; drafts preserved; persisted ACK |
Install/import/write routes absent until their individual schema+confirmation+redaction tests pass. Clipboard/UI drafts never equal persisted success. Exit: actual handler contract tests, injected wrong identity/thread/payload, read/write errors, slow saves, and browser UI tests for each manager. No live config migration.

### 5. Local files, terminal and programming agents (T3; depends on2+3)
Reuse PTY/ACP runtimes and file/tool policies. Bind session/cwd/repository/commit and output to current thread, preserve exact source evidence for review return. New spawn/input/file-write, including agent-initiated ACP/PTY loops, follows the same existing policy and confirmation rules with exact thread/payload binding; UI cannot assert a user gesture via untrusted message content. Stop/reconnect/exit update real lifecycle, process exit alone is not review success. No external agent installed is a recoverable state; built-in conversation/local tools continue. Exit: no-extension local task; PTY spawn/read/write/resize/stop; ACP result and review artifact returned to correct thread; cross-thread/replayed output rejected; denied shell/file actions; disconnect and unavailable-agent cases. Prior-output browsing may ship earlier under read-only identity, new execution may not.

### 6. Existing Chrome task visibility (T3; depends on2+3)
Read-only peer status stays in slice1/2. Foreground/tab control runs through the desktop identity after2+3; security-sensitive operations use the same confirmation manager, never a browser-specific approval queue. Visibility choice is not an approval of tool execution. Use actual extension peer, preserve user's profile/login; no remote-debugging defaults/headless/profile copying. Introduce an explicit adapter capability matrix per operation: supports background / requires foreground / unavailable. Background request must never silently call foreground fallback: return unsupported or obtain explicit foreground selection first. Foreground shows the relevant task page, not merely any Chrome window. Exit: fake adapter negatives plus real Chrome foreground/background actions; missing peer, unsupported background, permission denied, tab closing/reconnect, no unintended focus during a local-only job. #477 opening buttons are not evidence of this task policy.

### 7. Native packaging and full acceptance
Native macOS and Windows builds, summon hotkey registration/conflict recovery, existing permission denial behavior, no focus stealing on background work, normal close/reopen and workspace-open-while-compact alive. Clamp geometry and preserve resize; repeated summon must not spawn duplicate hosts. Verify installed signatures/assets/runtime and platform screenshots; no Windows runtime claim from macOS tests. Run two business scenarios already required by user (change-material traceability and development requirement/task/code/test loop), including no Codex, with/without programming agent, and local-only/no-extension case. #476 closes only after all preceding slices have evidence.

## Review discipline
Machine checks precede each implementation review: owning unit/contract negative tests, build, relevant real-render UI tests and native platform checks named by the slice. Freeze sources and evidence; actual Grok4.6 + DeepSeekV4Pro independent verdicts, fix blockers then resubmit. Invalid tool-call output is not a verdict. Record each slice in linked Issue/PR, keep #475 icon/history delivery separate. Current plan is not release approval.

## docs/audit/reviews/476-20260908/identity-baseline.md
# Existing identity audit (before desktop implementation)

Read-only evidence, 2026-09-08. No identity implementation changed.

| Connection | Actual baseline | Evidence |
|---|---|---|
| Tray menu | CompanionClient options omit surface, but the emitted handshake explicitly defaults to `tray` | menu-bar-agent.ts:2078, tray/companion-client.ts:648 |
| Summoner HTTP/SSE proxy | A separate CompanionClient explicitly emits `summoner`; it must remain restricted | menu-bar-agent.ts:2139–2144 |
| Extension | Omits wire surface, Origin identifies extension; server resolves `panel` | chrome-extension/src/background/ws-client.ts:186, ws/handshake-surface.ts |
| Tray Origin with omitted/unknown surface | REJECT (`omit_tray`) after authentication, not full tray | ws/handshake-surface.ts:surfaceFromOrigin |
| Extension claiming tray | Coerced to panel; claiming summoner rejected | ws/handshake-surface.ts |
| Desktop | Not a current supported wire role; must not add it to the existing tray pass-through | ws/validate.ts, ws/handshake-surface.ts, ws/lifecycle.ts |

The helper `assertSummonerAllowed(surface !== summoner)` alone appears permissive, but lifecycle first applies validation, HMAC authentication and surfaceFromOrigin. Do not misreport a reachable omitted-tray privilege bypass from the helper alone. Future desktop identity must still be an independently authenticated role with its own explicit allowlist, not merely another string accepted by this helper.

## companion/src/desktop/identity.ts
/** #480: isolated native-desktop identity primitive. Not wired to any transport.
 * Only the trusted host launcher may issue a bootstrap. Never expose this API
 * to a renderer, overlay, HTTP route or existing WS client.
 */
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto"

export const DESKTOP_READ_METHODS = Object.freeze([
  "system.ping", "thread.list", "thread.peek", "mcp.list", "skill.list", "knowledge.list",
] as const)

export type DesktopPrincipal = Readonly<{ hostSessionId: string; connectionId: string }>
export type DesktopBootstrap = Readonly<{ capabilityId: string; secret: string }>
export type DesktopChallenge = Readonly<{ nonce: string; signingInput: string }>

type Pending = {
  nonce: string
  connectionId: string
  protocolVersion: number
  signingInput: string
  expiresAt: number
}
type Capability = {
  hostSessionId: string
  secret: Buffer
  bootstrapExpiresAt: number
  activated: boolean
  pending?: Pending
  principal?: DesktopPrincipal
}

const BOOTSTRAP_TTL_MS = 30_000
const CHALLENGE_TTL_MS = 10_000
const MAX_HOST_SESSIONS = 64
const HEX_PROOF = /^[0-9a-f]{64}$/i
const CONNECTION_ID = /^[A-Za-z0-9_-]{1,128}$/

export class DesktopIdentityRegistry {
  private readonly capabilities = new Map<string, Capability>()
  private readonly principals = new WeakMap<DesktopPrincipal, string>()

  constructor(private readonly now: () => number = Date.now) {}

  /** The return value is for a native child bootstrap pipe, not a WS response. */
  issue(hostSessionId: string): DesktopBootstrap {
    if (!CONNECTION_ID.test(hostSessionId)) throw new Error("Invalid desktop host session")
    this.pruneUnactivated()
    if ([...this.capabilities.values()].some(c => c.hostSessionId === hostSessionId)) {
      throw new Error("Desktop host session already issued")
    }
    if (this.capabilities.size >= MAX_HOST_SESSIONS) throw new Error("Desktop host session limit reached")
    const capabilityId = randomBytes(16).toString("hex")
    const secret = randomBytes(32)
    this.capabilities.set(capabilityId, {
      hostSessionId, secret, activated: false,
      bootstrapExpiresAt: this.now() + BOOTSTRAP_TTL_MS,
    })
    return Object.freeze({ capabilityId, secret: secret.toString("hex") })
  }

  /** Connection ID and negotiated protocol come from the server, never payload claims. */
  challenge(capabilityId: string, connectionId: string, protocolVersion: number): DesktopChallenge | null {
    const capability = this.live(capabilityId)
    if (!capability || !CONNECTION_ID.test(connectionId) ||
        !Number.isSafeInteger(protocolVersion) || protocolVersion < 1) return null
    const nonce = randomBytes(32).toString("hex")
    const signingInput = JSON.stringify([
      "cmspark.desktop.auth.v1", capabilityId, connectionId, protocolVersion, nonce,
    ])
    capability.pending = {
      nonce, signingInput, connectionId, protocolVersion,
      expiresAt: this.now() + CHALLENGE_TTL_MS,
    }
    return Object.freeze({ nonce, signingInput })
  }

  authenticate(
    capabilityId: string, connectionId: string, protocolVersion: number, proof: unknown,
  ): DesktopPrincipal | null {
    const capability = this.live(capabilityId)
    const pending = capability?.pending
    if (!capability || !pending) return null
    // A stale/foreign socket must not consume the live connection's challenge.
    if (pending.connectionId !== connectionId) return null
    // Consume even a failed attempt: a challenge cannot be retried/replayed.
    delete capability.pending
    if (pending.expiresAt <= this.now() ||
        pending.protocolVersion !== protocolVersion || typeof proof !== "string" || !HEX_PROOF.test(proof)) return null
    const expected = createHmac("sha256", capability.secret).update(pending.signingInput).digest()
    if (!timingSafeEqual(expected, Buffer.from(proof, "hex"))) return null
    const principal = Object.freeze({ hostSessionId: capability.hostSessionId, connectionId })
    // A reconnect creates a fresh principal; the old connection loses access.
    capability.principal = principal
    capability.activated = true
    this.principals.set(principal, capabilityId)
    return principal
  }

  allows(principal: DesktopPrincipal, method: string): boolean {
    const id = this.principals.get(principal)
    return !!id && this.capabilities.get(id)?.principal === principal &&
      (DESKTOP_READ_METHODS as readonly string[]).includes(method)
  }

  /** Disconnect cancels connection authority; host may reconnect using a fresh challenge.
   * Caller must separately cancel the existing confirmation manager's owned requests.
   */
  disconnect(principal: DesktopPrincipal): void {
    const id = this.principals.get(principal)
    const capability = id ? this.capabilities.get(id) : undefined
    if (capability?.principal === principal) delete capability.principal
  }

  cancelChallenge(capabilityId: string, connectionId: string): void {
    const capability = this.capabilities.get(capabilityId)
    if (capability?.pending?.connectionId === connectionId) delete capability.pending
  }

  revoke(capabilityId: string): void {
    const capability = this.capabilities.get(capabilityId)
    if (capability) capability.secret.fill(0)
    this.capabilities.delete(capabilityId)
  }

  revokeAll(): void {
    for (const id of this.capabilities.keys()) this.revoke(id)
  }

  private live(id: string): Capability | undefined {
    const capability = this.capabilities.get(id)
    if (capability && !capability.activated && capability.bootstrapExpiresAt <= this.now()) {
      this.revoke(id)
      return undefined
    }
    return capability
  }

  private pruneUnactivated(): void {
    for (const id of this.capabilities.keys()) this.live(id)
  }
}

## companion/tests/desktop-identity-480.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import { createHmac } from "node:crypto"
import { DesktopIdentityRegistry, DESKTOP_READ_METHODS } from "../src/desktop/identity"

function fixture() {
  let now = 1000
  const registry = new DesktopIdentityRegistry(() => now)
  const bootstrap = registry.issue("host-1")
  const challenge = registry.challenge(bootstrap.capabilityId, "connection-1", 1)!
  const proof = createHmac("sha256", Buffer.from(bootstrap.secret, "hex")).update(challenge.signingInput).digest("hex")
  return { registry, bootstrap, proof, advance: (ms: number) => { now += ms } }
}

test("native-issued proof yields only the pinned read-only methods, never a renderer-claimed principal", () => {
  const f = fixture()
  const principal = f.registry.authenticate(f.bootstrap.capabilityId, "connection-1", 1, f.proof)!
  assert.ok(principal)
  for (const method of DESKTOP_READ_METHODS) assert.equal(f.registry.allows(principal, method), true)
  for (const method of ["mcp.add", "mcp.toggle_server", "config.set", "security.confirmation.response", "terminal.spawn", "chat.create"]) {
    assert.equal(f.registry.allows(principal, method), false, method)
  }
  assert.equal(f.registry.allows({ ...principal }, "thread.list"), false)
  assert.equal(JSON.stringify(principal).includes(f.bootstrap.secret), false)
  assert.ok(Object.isFrozen(principal))
  assert.ok(Object.isFrozen(DESKTOP_READ_METHODS))
})

test("proof is bound to capability, connection and negotiated protocol; failed attempts are consumed", () => {
  for (const mutation of ["secret", "protocol", "format"] as const) {
    const f = fixture()
    assert.equal(f.registry.authenticate(f.bootstrap.capabilityId,
      "connection-1", mutation === "protocol" ? 2 : 1,
      mutation === "secret" ? "00".repeat(32) : mutation === "format" ? "not-a-proof" : f.proof), null)
    assert.equal(f.registry.authenticate(f.bootstrap.capabilityId, "connection-1", 1, f.proof), null)
  }
  const f = fixture()
  assert.equal(f.registry.authenticate("unissued", "connection-1", 1, f.proof), null)
  assert.equal(f.registry.challenge("unissued", "connection-1", 1), null)
})

test("a foreign socket cannot consume a live challenge; pending socket close cancels only its own proof", () => {
  const f = fixture()
  assert.equal(f.registry.authenticate(f.bootstrap.capabilityId, "foreign", 1, f.proof), null)
  f.registry.cancelChallenge(f.bootstrap.capabilityId, "foreign")
  assert.ok(f.registry.authenticate(f.bootstrap.capabilityId, "connection-1", 1, f.proof))
  const other = fixture()
  other.registry.cancelChallenge(other.bootstrap.capabilityId, "connection-1")
  assert.equal(other.registry.authenticate(other.bootstrap.capabilityId, "connection-1", 1, other.proof), null)
})

test("expired challenge and expired bootstrap fail closed without extending bootstrap lifetime", () => {
  const f = fixture(); f.advance(10_000)
  assert.equal(f.registry.authenticate(f.bootstrap.capabilityId, "connection-1", 1, f.proof), null)
  assert.ok(f.registry.challenge(f.bootstrap.capabilityId, "connection-2", 1))
  f.advance(20_000)
  assert.equal(f.registry.challenge(f.bootstrap.capabilityId, "connection-3", 1), null)
})

test("replay, reconnect, disconnect, host exit and daemon restart revoke old authority", () => {
  const f = fixture()
  const old = f.registry.authenticate(f.bootstrap.capabilityId, "connection-1", 1, f.proof)!
  assert.equal(f.registry.authenticate(f.bootstrap.capabilityId, "connection-1", 1, f.proof), null)
  f.registry.disconnect(old)
  assert.equal(f.registry.allows(old, "thread.list"), false)
  const fresh = f.registry.challenge(f.bootstrap.capabilityId, "connection-2", 1)!
  const proof = createHmac("sha256", Buffer.from(f.bootstrap.secret, "hex")).update(fresh.signingInput).digest("hex")
  const current = f.registry.authenticate(f.bootstrap.capabilityId, "connection-2", 1, proof)!
  assert.ok(current)
  f.registry.disconnect(old) // a delayed old-socket close must not revoke the new one
  assert.equal(f.registry.allows(current, "thread.list"), true)
  f.registry.revokeAll()
  assert.equal(f.registry.allows(current, "thread.list"), false)
  assert.equal(f.registry.challenge(f.bootstrap.capabilityId, "connection-3", 1), null)
})

test("duplicate and excessive host sessions are bounded; unactivated expired grants can be reclaimed", () => {
  let now = 0
  const registry = new DesktopIdentityRegistry(() => now)
  registry.issue("host-0")
  assert.throws(() => registry.issue("host-0"), /already issued/)
  for (let i = 1; i < 64; i++) registry.issue(`host-${i}`)
  assert.throws(() => registry.issue("host-64"), /limit/)
  now = 30_000
  assert.ok(registry.issue("host-64"))
})

## docs/superpowers/plans/2026-09-08-desktop-identity-prototype.md
# Desktop identity isolated prototype
GitHub: #480; parent #476

This is an unintegrated primitive, not a native host or a desktop grant in the running product. No imports were added to daemon/WS/HTTP/renderer code. Design and implementation release gates remain pending.

`desktop/identity.ts` holds a bounded in-memory registry. Trusted launcher issuance returns a random bootstrap for the future inherited pipe. Read-only method table is immutable. Proof uses HMAC-SHA256 over the UTF-8 JSON array containing a desktop domain, capability ID, server connection ID, protocol and nonce. A principal is recognized by object identity, not client-claimed fields. Reconnect replaces authority; pending-close cancellation is connection-bound. Host revocation removes key and authority; issuer-owned buffer is zeroed, without claiming erasure of native copies.

Six test groups cover read-only permissions, forged principal/proof, connection/protocol binding, single-use and expiry, cross-socket challenge cancellation, reconnect/disconnect/revoke and bounded issuance. No wall-clock sleeping in tests.

Remaining integration: verified native process launch and inherited-handle discipline, singleton launch lock, OS crash/close monitoring, registered desktop auth kind, actual native WebView origins and resource projection, confirmation-manager lifecycle, platform packaging. None are implied by this prototype passing tests; #480 cannot close on this commit.
