Independent architecture/design review. User wants standalone CMspark without Codex, modern UI matching existing extension, conversations/MCP/skills/knowledge/local terminal and agent results, existing Chrome foreground/background. Review actual gaps and proposed slices. No other reviewer reports. Check outcome, trajectory, components and T3 capability declarations; identify blockers with concrete corrections. Do not require complete implementation at design gate; do not treat slice1 as whole completion. End VERDICT: APPROVE | APPROVE_WITH_NITS | REJECT.

## docs/superpowers/plans/2026-09-08-desktop-workbench.md
# Desktop workbench
GitHub: #476
Status: design under independent review; not implementation-complete.

## User outcome
CMspark is usable without Codex: a quiet conversation workspace with conversations, MCP, skills, knowledge and local work. Keep a quick summon action. For web jobs connect the user's existing Chrome; background means avoid foreground activation where supported, never headless or a different profile. Foreground explicitly shows the operation page. Existing Chrome extension remains the current authenticated browser transport, not a requirement for non-browser jobs.

## Evidence / actual gaps
- `companion/src/summoner/shell-open.ts`: 360x420 window, Chromium app-mode host with isolated UI profile. This UI profile is not the user's automated Chrome profile. There is no native WKWebView/WebView2 host here.
- `companion/src/summoner-web.ts`: nav and settings hidden, history overlays entire HUD; list-only MCP with a stale clickable toggle calling an intentionally unavailable API. Knowledge/skills only attach to current conversation, not full management.
- `companion/src/ws/summoner-acl.ts`: overlay alias-only updates, no MCP mutation/config/terminal/confirm grants. Restoring navigation cannot turn this channel into a full desktop manager.
- `companion/src/menu-bar-agent.ts`: HTTP/SSE shell dispatches through authenticated summoner client. Same Companion thread backend exists; do not create another store.
- `companion/src/summoner/client.ts`: foreground option only opens Chrome; this is not yet a per-task automation visibility policy. Silent fallback may open foreground when unsupported.
- `companion/src/message-router/handlers/mcp.ts`, `knowledge.ts`, skills, ACP and PTY runtimes are reuse candidates, subject to identity and response/event validation.

## Information architecture
Wide: 220px navigation with text labels, recent conversations, New conversation; central conversation with max780px reading column and composer aligned to it. Resources open a dedicated content region, with one clear heading, search and primary action. No icon-only vertical ribbon. Narrow: named navigation disclosure, permanent New conversation, content and stop remain reachable. Quick mode remains compact; workspace opens at a useful larger size. No mountains/mascots, gradients or fake dashboard metrics.

Navigation: 对话, 本地工作, MCP, 技能, 知识, 浏览器; 设置 at foot. Management must show loading/error/empty/save-in-progress and persisted success. Display server states from actual response fields, not `enabled` as connection health.

## Implementation slices and acceptance
1. Shell/navigation: usable wide/short layouts, visible history/search and resources, explicit read-only limitations until management slice lands. Fix dead MCP interaction. This slice alone cannot close #476.
2. Desktop management transport: separate typed local desktop identity, allowlisted methods and per-resource payload checks. Preserve overlay restrictions. Thread tags/folders, MCP CRUD/connect, skills and knowledge management share current handlers; no live configuration migration. Review config writes and secret redaction before adding forms.
3. Local work: reuse PTY and ACP; bind lifecycle and output to thread/session, local explicit terminal gestures, reconnect/stop, external review artifact return. Local agent unavailable is a recoverable state, never fabricated success.
4. Desktop confirmation: explicit origin ownership, challenge/action binding, expiry, cancel/disconnect; never replay a web approval or treat desktop visibility as permission. This is a dependency for sensitive standalone tools, not a late cosmetic step.
5. Browser: existing Chrome connection and real peer status; foreground/background task policy through actual browser adapter. No implicit remote debugging, no headless browser, no profile copying. Operations requiring visibility say so. Missing extension/peer shown with setup action.
6. Native packaging: macOS and Windows shell behavior validation; if native webview is required, implement and separately verify it before claiming browser-free hosting. UI host and web automation browser are separate concepts.

## Gates
T3. User-selected independent Grok4.6 + DeepSeekV4Pro. Frozen source/design packets, actual model verdicts, negative auth/payload/cross-thread/confirmation tests, actual rendered UI at320/390/760/1440 and short height, machine checks before implementation release review. Keep #475 icon/history delivery separate. Every slice must have linked implementation Issue/PR and concrete evidence; #476 stays open until full acceptance.

## Decisions
User confirmed existing Chrome, background or show operation page (2026-09-08). No Codex dependency. No new external services or mandatory coding Agent. No permission model bypass. Browser-free local work is an outcome requirement; current Chromium shell dependence is an explicit gap, not silently accepted as done.

## companion/src/ws/summoner-acl.ts
import { isUiCommandAction } from "../ui-command"

/** Per-connection method ACL keyed off handshake `surface` (S21).
 *
 * Origin stays `cmspark-tray://local`. Summoner is a second tray-origin WS
 * that must not run trust-elevation / settings / pack / MCP mutate / confirm.
 * Overlay chat.create already sees companion MCP tools; `mcp.list` is read-only
 * so the overlay can show connected servers. `mcp.add` stays denied.
 * `pack.apply` is allowed but router forces allowTrust=false + overlay-eligible.
 * `thread.delete` / `thread.update` are overlay-safe only via
 * `applySummonerPayloadPolicy` (trash-only; alias-only).
 * Tray (`surface !== "summoner"`, including omitted/undefined) is not gated —
 * origin-cleaving would break tray `skill.list`.
 */

const SUMMONER_ALLOW = new Set([
  "system.ping",
  "chat.create",
  "chat.abort",
  "chat.steer",
  "thread.list",
  "thread.select",
  "thread.create",
  "thread.delete",
  "thread.update",
  "history.query",
  "thread.search",
  "thread.peek",
  "composer.lease.claim",
  "composer.lease.release",
  "composer.lease.release_overlay",
  "composer.lease.get",
  "voice.stt.start",
  "voice.stt.chunk",
  "voice.stt.end",
  "voice.stt.abort",
  "voice.stt.partial_request",
  "meeting.create",
  "meeting.start",
  "meeting.end",
  "meeting.append_transcript",
  "meeting.generate_minutes",
  "meeting.list",
  "meeting.get",
  "mcp.list",
  "mcp.toggle_server",
  "pack.list",
  "pack.apply",
  "task_loop.arm",
  "skill.list",
  "skill.activate",
  "skill.deactivate",
  "knowledge.list",
  "knowledge.search",
  "knowledge.set_active",
  "file.upload",
  "companion.ui.rect",
  "ui.command",
  "thread.execution_policy.set",
])

export function assertSummonerAllowed(
  surface: string | undefined,
  type: string,
): { ok: true } | { ok: false; error_code: "SUMMONER_ACL"; error: string } {
  if (surface !== "summoner") return { ok: true }
  if (SUMMONER_ALLOW.has(type)) return { ok: true }
  return {
    ok: false,
    error_code: "SUMMONER_ACL",
    error: `SUMMONER_ACL: ${type} not allowed on summoner surface`,
  }
}

function overlayAlias(raw: unknown): string | null {
  if (typeof raw !== "string") return null
  const alias = raw.replace(/[\x00-\x1F\x7F]/g, "").trim().slice(0, 200)
  return alias || null
}

/**
 * Overlay-safe payload gate. Method allowlist is not enough: tray `thread.delete`
 * defaults to hard, and `thread.update` can mutate tool_whitelist / knowledge ids.
 * Mutates `msg` in place (strips non-alias updates). Tray / omitted surface: no-op.
 */
export function applySummonerPayloadPolicy(
  surface: string | undefined,
  msg: Record<string, unknown>,
): { ok: true } | { ok: false; error_code: "SUMMONER_ACL"; error: string } {
  if (surface !== "summoner") return { ok: true }
  const type = msg.type
  if (type === "thread.delete") {
    if (msg.mode !== "trash") {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: thread.delete on overlay must use mode=trash",
      }
    }
    return { ok: true }
  }
  if (type === "thread.update") {
    const updates = msg.updates
    if (!updates || typeof updates !== "object" || Array.isArray(updates)) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: thread.update overlay may only set alias",
      }
    }
    const alias = overlayAlias((updates as { alias?: unknown }).alias)
    if (!alias) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: thread.update overlay may only set alias",
      }
    }
    msg.updates = { alias }
    return { ok: true }
  }
  if (type === "knowledge.set_active") {
    const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
    if (!threadId) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: knowledge.set_active requires thread_id",
      }
    }
    const raw = Array.isArray(msg.ids) ? msg.ids : []
    const ids = raw.filter((id): id is string => typeof id === "string" && id.trim().length > 0).slice(0, 32)
    for (const key of Object.keys(msg)) {
      if (key !== "type" && key !== "thread_id" && key !== "ids") delete msg[key]
    }
    msg.thread_id = threadId
    msg.ids = ids
    return { ok: true }
  }
  if (type === "pack.apply") {
    delete msg.allowTrust
    delete msg.workspace_path
    delete msg.force_takeover
    delete msg.confirmation_phrase
    const packId = typeof msg.pack_id === "string" ? msg.pack_id.trim() : ""
    const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
    if (!packId || !threadId) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: pack.apply requires pack_id and thread_id",
      }
    }
    msg.pack_id = packId
    msg.thread_id = threadId
    msg.user_gesture = true
    return { ok: true }
  }
  if (type === "meeting.start") {
    msg.audio_retained = false
    delete msg.retain_days
    return { ok: true }
  }
  if (type === "ui.command") {
    const action = typeof msg.action === "string" ? msg.action.trim() : ""
    if (!isUiCommandAction(action)) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: ui.command action not on whitelist",
      }
    }
    for (const key of Object.keys(msg)) {
      if (key !== "type" && key !== "action" && key !== "id") delete msg[key]
    }
    msg.action = action
    return { ok: true }
  }
  if (type === "thread.execution_policy.set") {
    const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
    if (!threadId) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: thread.execution_policy.set requires thread_id",
      }
    }
    if (msg.policy !== "plan_readonly") {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: summoner may only downgrade to plan_readonly",
      }
    }
    for (const key of Object.keys(msg)) {
      if (key !== "type" && key !== "thread_id" && key !== "policy" && key !== "user_gesture" && key !== "id") {
        delete msg[key]
      }
    }
    msg.thread_id = threadId
    msg.policy = "plan_readonly"
    msg.user_gesture = true
    return { ok: true }
  }
  return { ok: true }
}

## companion/src/summoner/shell-open.ts
/**
 * C-thin P3: open the loopback HTML shell in a dedicated Chromium/Edge
 * `--app` window when a browser binary exists. Otherwise honest degrade to
 * the system URL handler (tab). Not Electron. Not a new Swift overlay.
 *
 * Native WKWebView / WebView2 / GTK remains a later host for the same HTML.
 */
import * as child_process from "child_process"
import * as fs from "fs"
import * as path from "path"

export type SummonerShellKind = "app-window" | "browser-tab"

export type SummonerShellPlan = {
  kind: SummonerShellKind
  command: string
  args: string[]
  shell?: boolean
}

export type SummonerShellOpenOpts = {
  platform: NodeJS.Platform
  browserPath?: string | null
  userDataDir?: string | null
  windowPosition?: { x: number; y: number }
}

/** Inner --app viewport. Outer adds ~28px title bar when centering. */
export const OVERLAY_WINDOW_SIZE = { w: 360, h: 420 } as const
const OVERLAY_TITLEBAR_PX = 28

export function overlayWindowPosition(
  screenW: number,
  screenH: number,
  innerW: number = OVERLAY_WINDOW_SIZE.w,
  innerH: number = OVERLAY_WINDOW_SIZE.h,
): { x: number; y: number } {
  const outerH = innerH + OVERLAY_TITLEBAR_PX
  return {
    x: Math.max(0, Math.floor((screenW - innerW) / 2)),
    y: Math.max(0, Math.floor((screenH - outerH) / 2)),
  }
}

export function parseOverlayChromePids(psOutput: string, userDataDir: string): number[] {
  if (!userDataDir) return []
  const needle = `--user-data-dir=${userDataDir}`
  const pids: number[] = []
  for (const line of psOutput.split("\n")) {
    if (!line.includes(needle)) continue
    const pid = parseInt(line.trim(), 10)
    if (Number.isInteger(pid) && pid > 0 && pid !== process.pid) pids.push(pid)
  }
  return pids
}

export function readOverlayChromePids(userDataDir: string): number[] {
  try {
    const out = child_process.execFileSync("ps", ["-axo", "pid=,command="], {
      encoding: "utf8",
      timeout: 2000,
    })
    return parseOverlayChromePids(out, userDataDir)
  } catch {
    return []
  }
}

export function closeOverlayChrome(userDataDir: string): number {
  const pids = readOverlayChromePids(userDataDir)
  let n = 0
  for (const pid of pids) {
    try {
      process.kill(pid, "SIGTERM")
      n += 1
    } catch {
      /* already gone */
    }
  }
  return n
}

export function parseFinderDesktopBounds(raw: string): { w: number; h: number } | null {
  const parts = String(raw)
    .split(/[,\s]+/)
    .map((s) => Number(s.trim()))
    .filter((n) => Number.isFinite(n))
  if (parts.length < 4) return null
  const w = parts[2] - parts[0]
  const h = parts[3] - parts[1]
  if (!(w > 0) || !(h > 0)) return null
  return { w, h }
}

export function isSummonerLoopbackUrl(url: string): boolean {
  if (typeof url !== "string" || !url) return false
  try {
    const u = new URL(url)
    if (u.protocol !== "http:") return false
    const host = u.hostname.toLowerCase()
    if (host !== "127.0.0.1" && host !== "localhost") return false
    if (u.pathname !== "/" && u.pathname !== "/summoner") return false
    const keys = [...u.searchParams.keys()]
    const unique = [...new Set(keys)]
    if (keys.length !== unique.length) return false
    // Batch D D3: token must not appear in --app argv / query.
    if (unique.includes("token")) return false
    if (unique.length === 0) return true
    if (unique.length === 1 && unique[0] === "thread") {
      const thread = u.searchParams.get("thread") || ""
      return thread.length > 0
    }
    return false
  } catch {
    return false
  }
}

export function planSummonerShellOpen(
  url: string,
  opts: SummonerShellOpenOpts,
): SummonerShellPlan | { error: string } {
  if (!isSummonerLoopbackUrl(url)) {
    return { error: "summoner shell only opens loopback token URLs" }
  }
  const browserPath = typeof opts.browserPath === "string" ? opts.browserPath.trim() : ""
  if (browserPath) {
    const { w, h } = OVERLAY_WINDOW_SIZE
    const args = [`--app=${url}`, `--window-size=${w},${h}`, "--no-first-run", "--no-default-browser-check"]
    const dir = typeof opts.userDataDir === "string" ? opts.userDataDir.trim() : ""
    if (dir) args.push(`--user-data-dir=${dir}`)
    const pos = opts.windowPosition
    if (pos && Number.isFinite(pos.x) && Number.isFinite(pos.y)) {
      args.push(`--window-position=${Math.max(0, pos.x | 0)},${Math.max(0, pos.y | 0)}`)
    }
    return {
      kind: "app-window",
      command: browserPath,
      args,
    }
  }
  if (opts.platform === "darwin") {
    return { kind: "browser-tab", command: "open", args: [url] }
  }
  if (opts.platform === "linux") {
    return { kind: "browser-tab", command: "xdg-open", args: [url] }
  }
  if (opts.platform === "win32") {
    return { kind: "browser-tab", command: "cmd.exe", args: ["/c", "start", "", url] }
  }
  return { error: `unsupported platform: ${opts.platform}` }
}

const DARWIN_BINS = [
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
  "/Applications/Chromium.app/Contents/MacOS/Chromium",
  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
]

const WIN_BINS = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
]

const POSIX_NAMES = [
  "google-chrome",
  "google-chrome-stable",
  "chromium",
  "chromium-browser",
  "microsoft-edge",
  "microsoft-edge-stable",
  "brave-browser",
]

function whichFromPath(name: string, pathEnv: string, exists: (p: string) => boolean): string | null {
  const sep = process.platform === "win32" ? ";" : ":"
  for (const dir of pathEnv.split(sep)) {
    if (!dir) continue
    const candidate = path.join(dir, name)
    if (exists(candidate)) return candidate
    if (process.platform === "win32" && exists(candidate + ".exe")) return candidate + ".exe"
  }
  return null
}

export function resolveSummonerBrowserPath(
  platform: NodeJS.Platform,
  exists: (p: string) => boolean = (p) => {
    try {
      return fs.existsSync(p)
    } catch {
      return false
    }
  },
  pathEnv: string = process.env.PATH || "",
): string | null {
  const fixed = platform === "darwin" ? DARWIN_BINS : platform === "win32" ? WIN_BINS : []
  for (const p of fixed) {
    if (exists(p)) return p
  }
  for (const name of POSIX_NAMES) {
    const hit = whichFromPath(name, pathEnv, exists)
    if (hit) return hit
  }
  if (platform === "win32") {
    for (const name of ["chrome", "msedge", "chrome.exe", "msedge.exe"]) {
      const hit = whichFromPath(name, pathEnv, exists)
      if (hit) return hit
    }
  }
  return null
}
