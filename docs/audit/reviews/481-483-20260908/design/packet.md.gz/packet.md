Independent DESIGN review for #481. User reports voice failures, missing summoner tags/groups, stale code controller on new conversations, requests overall UI/UX audit and asks whether a Project level is better. Review current scope vs future proposal, ownership, safe metadata-only ACL expansion, clear navigation, acceptance and migration. This is design approval only, not implementation or installed-app approval. No tools. End VERDICT: APPROVE, APPROVE_WITH_NITS or REJECT with concrete findings.

FILE DESIGN.md
# Design

## Source of truth
Active · 2026-09-08 · GitHub [#481](https://github.com/nehcuh/cmspark/issues/481).
This is the current UI/UX contract for the extension workspace, summoner, settings,
code panel, terminal, confirmation cockpit, meetings, graphs and tray. It consolidates
#469 / #471 / #473 / #474 / #476 / #477 instead of appending competing layout rules.
`docs/DESIGN.md` retains capability/safety contracts; its older mascot-first,
tiny-chrome and narrow-only presentation is superseded.

Evidence: [workspace audit](docs/audit/2026-09-08-workspace-ux-audit.md).
Scope and proposal: [current repairs and projects](docs/superpowers/plans/2026-09-08-workspace-projects-ux.md).
Native prerequisites: [#476 plan](docs/superpowers/plans/2026-09-08-desktop-workbench.md).
The user prefers Codex's quiet hierarchy. No current Codex screenshot was inspected
for this revision; this is not a pixel-matching or feature-parity claim.

## Brand
Calm, precise, capable. Neutral paper/ink, restrained indigo links/focus, semantic
risk colors. Avoid gradients, decorative counters, dense icon ribbons and large
mascots. Do not reintroduce the decorative 山 mark in summoner empty states.
The static app/extension mark is owned by `scripts/lib/brand-icon.mjs`. The tray
alone represents Companion process state: green solid center running, red hollow
stopped, amber unknown. No tray title or redundant menu header; tooltip and native
accessibility retain words. WebSocket connectivity is separate. Keep macOS,
Windows and extension assets aligned.

## Product goals
Make conversation, prior work and the next action easy to find. Input, recording
feedback, stop and pending confirmation remain reachable. A coding run belongs to
its originating conversation; changing views does not transfer ownership.
The complete #476 desktop workbench supports work without Codex, with optional
programming agents and existing Chrome for web tasks. This is a product goal;
the current Chromium summoner is transitional, not that complete native product.

Current #481 delivery: voice reliability/feedback (#482), coding-session scope
(#483), summoner manual tags/groups using existing metadata, and conversation-first
navigation. Project entities/defaults, a global activity center, merged code/terminal
workspace and native management are future work. No copied Codex assets, mandatory
external agent, blanket permission or automatic live-configuration migration.

## Personas and jobs
Change managers assemble sourced requirements, versions, artifacts, architecture,
runtime, code and test evidence. Developers continue across conversations and
repositories with optional programming agents. Others read websites, dictate a
message or record meetings. Ordinary conversations require no repository or project.

## Information architecture
Current navigation order: new conversation; search/recent conversations with
visible management; supporting resources; settings where actually available.
Use the same order on both surfaces. Preserve existing capability entries.
Name browser tabs “浏览器标签页”; conversation categories remain “标签 / 分组”.
Wide screens have left navigation and one main conversation. Narrow navigation is
a text-triggered, nonmodal, in-flow disclosure. StatusRail is the single header:
title, narrow navigation/new-conversation controls, existing popout/management/
status/more. FocusBand owns priority feedback; its coding slot shows only the
current conversation's session. A background event cannot open another thread's panel.

ThreadList owns extension history, time/tags/manual/AI views, trash and bulk actions.
Recent navigation projects the same store. Summoner uses persisted `user_tags` and
`topic_folder`, not a second grouping store. AI grouping derives from extracted tags
and never rewrites manual grouping. Keep AI extraction, cleanup and graph entries.
Existing resource panels use ContextPanelHost above the composer; summoner resource
attachments retain their current surface until native management lands. Label
“used in this conversation” separately from global configuration. Read-only lists
must not imply edit/install/connect capability. Settings uses one named dialog,
category pages (wide rail/narrow select), stable deep links and mounted forms that
preserve drafts. Pairing/elevated trust remains visible; independent saves stay explicit.

Future proposal: optional Project → Conversation → Execution records. Project is
a durable context with an optional local repository, not a renamed manual folder.
Conversations may remain outside projects. No project UI ships before its real model.

## Design principles
One dominant action per area; supporting controls on demand. Preserve existing
data/execution/confirmation owners. Fix state scope before adding task controls.
Keep completed code results reachable in their conversation; an old run cannot seize
a new conversation's header. Current scope repair does not delete results to simplify UI.
Layout does not grant trust. Confirmation handlers, order/roles, initial focus,
timeout, whitelist, auto-approve defaults and critical evidence retain their contracts.
FocusBand's confirmation/stop priority is authoritative. Cockpit confirmation
DOM/handlers are outside this visual batch. Resizing never grants desktop privileges.

## Visual language
`chrome-extension/src/sidepanel/ui/tokens.ts` owns new React colors; Companion HTML
mirrors the palette without a new bundler. Neutral surfaces, subtle borders,
readable secondary text, charcoal primary composer action and indigo focus.
System sans; body 14–15px, chrome 12–13px, headings 15–24px. Spacing 4/8/12/16/24/32px;
radii 8px controls, 12px cards, 20px composer. Quiet user bubbles, unboxed assistant
prose, shadows only for floating surfaces. Existing SVG icons; no network/font assets.
Terminal uses existing dark tokens. Respect reduced motion.

## Components
Reuse WorkspaceFrame/WorkspaceNavigation, StatusRail, ThreadList/metadata editor,
Modal/tokens, ChatView, ComposerDock, ContextPanelHost and settings pages. Session
selection belongs in shared typed selectors/reducers, not divergent component filters.
Voice state explains preparing/listening/processing/failure next to the mic.
Use explicit scoped classes, not arbitrary inline-style selectors. Share navigation,
copy and data projections with transport adapters when practical; no forced full
React/native rewrite, duplicated thread cache, Agent or confirmation manager.

## Accessibility
Target WCAG 2.2 AA practices: new ordinary text contrast at least 4.5:1, visible
focus, semantic buttons, text alongside risk colors, Enter/Space, Escape and focus
return, no nested interactive elements. Essential controls at least 32px, primary
36px. Preserve live status/destructive copy. Voice animation supplements text and
respects reduced motion. Automated checks are not a conformance certification.

## Responsive behavior
320–759px: full-width conversation, no fixed wide columns; nonmodal navigation
bounded to 36dvh (28dvh below 560px height), independently scrollable. At 760px+:
persistent 220px navigation; conversation reading width up to 780px. ContextPanelHost
is bounded to min(36dvh, 360px), or 28dvh at short height, and yields to confirmation.
Wide settings use a bounded centered dialog. Only message/supporting content shrinks;
composer/stop remain reachable. Long titles wrap/truncate without hiding actions.
Verify 320/390/759/760/1040/1440px widths, 420/480px heights and 200% equivalent reflow.
Summoner default 1040×760, explicit compact 360×420; clamp and retain user resizing.

## Interaction states
Empty suggestions fill, never send. Loading shows the pending action at its source,
never a silent mic. Listening begins only when capture is ready; partial recognition
is distinct from final text. Processing stays visible after stop; failure keeps drafts.
Do not promise hardware-independent transcription latency: record cold/warm setup,
first partial and finalization separately. Save success requires matching persisted
fields/identity, not transport ACK. Switching threads cannot redirect an in-flight
save, transcript, report, approval or session event. Offline offers recovery without
invented completion. Process exit, report import and review approval are distinct.

## Content voice
Chinese product chrome, clear verbs, short labels. Use 对话, 项目 (real entity only),
标签, 分组, 浏览器标签页, 知识, 场景, 设置. Code work may become “代码与终端”;
ACP/PTY details belong inside technical disclosure. Errors point to current settings
labels (“输入与语音”), not stale “设置 → 听写” navigation.

## Implementation constraints
React 18/Plasmo, existing styles/tokens; no new production dependency for this batch.
#481 narrowly expands the authenticated overlay's payload ACL for existing
`thread.update`: only alias/user_tags/topic_folder, using the shared HTTP/WS metadata
patch validator. Unknown fields (including alias plus config) reject the whole patch.
This is an ACL change and a T3 review focus, not an unchanged-policy claim. It
supersedes only #476's scheduling of these low-risk metadata fields; workspace,
trust/config, MCP writes, terminal, install/import and approval remain denied.
Native identity and native confirmation remain prerequisites for privileged #476
work. Current Chrome actions connect/open the existing browser; they are not a
per-operation background guarantee. No profile copying or silent foreground fallback.
Issue-first, owning machine/contract tests, real-render synthetic UI checks, build
and actual independent Grok + DeepSeek gates. Native host behavior, signatures,
microphone performance and Windows runtime need separate evidence. Reports distinguish
current delivery, reviewed design and future capabilities.

## Open questions
- [ ] Project proposal: maintainers to validate optional single-directory defaults,
  migration and storage in a subsequent implementation Issue; no shipped schema here.
- [ ] Native #476 management, Windows host visuals and task-level Chrome visibility
  remain owned by their slices; current repairs cannot close them.
- [ ] Voice #482: measure installed engine/model cold/warm timing before claiming
  the user's performance issue resolved.
- [ ] Resource/settings/meeting/graph improvements in the audit need separately
  tracked changes and surface-specific acceptance; an audit is not implementation.

FILE docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
# 工作空间、项目与对话 UI/UX

关联 [#481](https://github.com/nehcuh/cmspark/issues/481)，修复 [#482](https://github.com/nehcuh/cmspark/issues/482) / [#483](https://github.com/nehcuh/cmspark/issues/483)。
2026-09-08 · 设计与验收约定，待独立复审；不是已实现清单。
视觉规范：[root DESIGN.md](../../../DESIGN.md)。源码：[整体审计](../../audit/2026-09-08-workspace-ux-audit.md)。

## 1. 本次交付与后续提案

用户六项反馈关联到输入状态、对话归属和导航结构；不以一次皮肤调整替代这些问题。

| 范围 | 本次交付与验收 | 后续，不能在本次宣称完成 |
|---|---|---|
| 输入 #482 | 两端启动/失败/处理中可见；修复复现的延迟路径；保留取消、隐私、会议互斥 | 新引擎、无限会议、硬件无关的延迟保证 |
| 编程 #483 | 按 session/thread 处理事件；新对话不出现/自动打开旧代码任务；操作目标不串会话 | 全局活动中心、代码/终端整合、原生终端、多运行持久化产品 |
| 对话分类 | 召唤器人工标签/手动分组；真实保存确认；插件旧整理/图谱功能保留 | 项目数据库、项目继承/批量迁移；召唤器全部 AI 整理和图谱 |
| 导航 | 两端对话优先；搜索/最近/管理在辅助资源之前；术语明确 | 全部资源编辑器重写 |
| 项目 | 本文明确实体、归属、目录与迁移设计 | 不把 topic_folder 改名项目，不放空壳项目入口 |
| 整体 UI/UX | 主要界面源码梳理、统一规范、分阶段可验收清单 | 审计列出的后续改造不能计为本批已交付 |

用户问“项目是否更好”支持设计建议，本次不实施隐式目录继承或自动迁移。#481 完成
指本批修复与审计闭环，不关闭 #476，也不声称项目模型已经实现。

## 2. 本批导航与对话元数据

两端顺序：新对话 → 搜索/最近对话/管理 → 资料与工具 → 设置（实际可用时）。
320–759px 使用有高度上限的非模态导航；顶栏 +、输入、语音状态和停止始终可达。
760px+ 保留 220px 左栏。浏览器 tabs 称“浏览器标签页”，人工 tags 称“标签”。

插件继续由 ThreadList 管时间、标签、手动/AI 分组、批量选择、整理助手、关系图谱
与回收站。召唤器本次接入人工标签/手动组编辑与展示，不声称已补齐全部管理能力。
可输入新组名或选择已有名称，留空移出。保存只锁对应编辑动作；失败保留草稿；
切换对话不能把迟到回执应用给另一行。AI 重提取不得覆盖人工分类。

复用 Thread 和已有 sanitize/persisted response；HTTP/WS 共用
`companion/src/threads/metadata-patch.ts` 的纯验证。现有 `thread.update` 的 overlay
payload ACL 从 alias-only **窄扩展**为 alias/user_tags/topic_folder 精确子集。
不新增方法，不透传客户端 updates；未知字段整包拒绝，包含合法 alias 与非法 config
的混合包也不能静默剥离后成功。错误类型、NFC、控制字符、数量/长度上限与服务端一致。
未提交字段不变；尤其不能把未提交 alias 清成空。回执线程 ID 与提交字段匹配才成功。

该排期取代旧 #476 slice 4 将这些元数据全部延后到原生身份的约束。它是需要 T3
复审的实际 ACL 变化；不是“ACL 完全没改”。workspace_root、config/trust、MCP
写入、安装/导入、终端和确认响应均不因此开放。#476 其余原生身份与确认依赖不变。

## 3. 编程运行归属

事实键是启动时的 session_id 和 thread_id，不是当前选中页面。事件先定位相同
session，再更新它自己的字段；不同 session 不继承目标、目录、进度、结果、diff
或本机终端状态。未知会话的稀疏事件不能借用另一会话身份。显示选择器按当前 thread
取对应代码状态，不能每个组件采用不同规则。

- A 开始代码工作后切换/新建 B，A 控制器和顶栏状态不占用 B；迟到的 A 事件不再
  自动打开 B 面板。切回 A 可以在客户端支持的保留范围内查看，不因隐藏取消进程。
- 停止、继续、应用 diff、关闭监视均使用实际 session ID；旧 UI 闭包不能读 B 的
  目录/消息去继续 A。切换时关闭旧编辑视图或重建其上下文，避免混用。
- 关闭一项不清空其他会话；断连不代表完成；已结束的有效结果/diff 入口仍归 A。
- 重载恢复需实际协议验证，不以本批内存作用域修复宣称新增持久恢复产品。

后续可把编程面板/终端整合为“代码与终端”：当前对话运行列表、输出、变更、证据按需
展开；其他对话后台任务在侧栏活动入口显示并跳回所属对话；完成结果放消息卡。此方向
不是本批交付，也不能另造 Agent、确认队列或绕过 #476 原生能力门禁。

## 4. 语音状态与性能证据

区分“准备麦克风/模型”“正在听写”“正在识别最后一段”“失败”。点击后在异步准备
完成前显示反馈，capture 就绪后才能显示正在听写。权限、模型缺失、服务断开分别
给当前设置分类的恢复路径，不能统统提示“打开麦克风”。停止录音与等待 final 分开。
部分识别不冒充终稿、不重复拼接。开始时固定草稿/录音归属，切换/新建/取消/隐藏/
关闭或会议竞争时，旧结果不能写进新草稿。保留隐私确认、会议互斥与音频资源清理。
不因降延迟自动开麦或改用云服务。

记录引擎/模型、冷热启动、请求/capture-ready/first-partial/stop/final 时点。
同机器/录音前后比较，区分固定等待窗与计算耗时。合成测试证明准备/错误/取消/迟到
事件反馈；真实麦克风和模型时延另做实测，不能承诺所有硬件都毫秒级 final。

## 5. 后续项目实体设计

### 5.1 层级与最小模型（提案，未成协议）

```text
Project（可选的长期业务/代码范围）
  └─ Thread / 对话（消息、意图、人工分类）
       └─ Execution / 运行记录（ACP、PTY、浏览器执行；产物与来源）
```

| 字段/实体 | 建议语义 |
|---|---|
| Project.id / name | 服务端稳定 ID；改名称不改磁盘目录，目录不作主键 |
| Project.workspace_root? | 当前 Companion 主机的可选规范化绝对目录，可为空 |
| created_at / updated_at / archived_at? | 元数据时间与归档；归档不删除对话、文件或产物 |
| Thread.project_id? | 零或一个项目；空值为项目外对话 |
| Thread.workspace_root? | 保留现有显式线程绑定，允许不同于项目建议目录 |
| user_tags / topic_folder / digest | 原字段不变：人工标签、人工组、AI 索引各司其职 |
| 运行快照 | 创建时固定 thread/project ID（若有）、解析 cwd/仓库根、commit/base/head（适用时） |

新增独立 Project store，不复制 Thread 消息存储。业务项目允许没有目录，如跨系统
变更。首版至多一个建议目录，不自动克隆或创建 worktree；多仓库、远程主机、项目
共享资源/密钥继承另立需求。不额外强制一个“任务容器”，对话承载工作，运行解释执行。

### 5.2 目录建议与授权分离

创建只需名称；可通过既有目录选择/校验添加目录。Git 检测是可选只读提示，remote
URL 不必填，不把带凭据的 URL 写入 UI/日志。选择项目不能触发执行、下载、MCP
allow-dir 扩张或信任提升。项目名称、文件夹标签均不是安全身份。

建议有效目录顺序：显式 thread.workspace_root → 用户选择使用的项目目录 → 既有
默认沙箱。界面显示生效来源；接受项目目录建议仍走既有 workspace binding/安全
检查，不能仅有 project_id 就自动获取访问权限。改项目默认目录不偷偷改已有绑定。
运行前由服务端冻结有效 cwd/仓库，运行中不能随项目设置/activeThread 重绑。目录
失效/非 Git 是可恢复状态；普通业务对话继续，要求仓库/commit 的操作明确报缺失，
不能悄悄落到别的仓库。项目设置本身不授权访问目录中的内容。

### 5.3 创建、移动、归档、恢复

项目内新对话显式带 project_id；全局新对话允许项目外。复用 thread.create owner，
由服务端确认，不能从“最近代码会话”猜项目。Fork 默认保留来源项目并沿用既有目录
复制语义，但不复制运行 ID、活跃权限或待确认挑战。无效/归档项目 ID 有明确校验。

第一版在有运行/待确认时不允许移动对话，解释先结束执行/处理决定再整理。空闲对话
移入/移出项目只改元数据，保留原显式目录并在移动界面说明；换目录是独立操作。历史
审阅结果的 thread/仓库/commit 快照不随移动变化。归档代替级联删除；恢复保持关联。
项目记录损坏/缺失时对话仍可找回并显示“原项目不可用”，不误判为历史已删。并发元
数据编辑需要版本/更新时间冲突检测；原子写和失败恢复方案在实现 Issue 冻结。

### 5.4 旧数据迁移

增加可空字段，不批量重写历史。无 project_id 原样显示项目外，人工组/标签、AI tags、
workspace_root 全保留。可只读扫描相同规范化目录，给“整理到项目”的候选；显式
选中后才建归属。不能把同名 folder 自动变项目、同路径迁移变授权；记录迁移 ID
映射、写入失败不宣称成功，不复制消息或触碰代码文件。

### 5.5 项目验收（后续）

空/无仓库项目、项目外对话；创建/搜索/归档/恢复；重启归属；旧历史零迁移可读；
人工/AI 分类不丢；三种目录来源清晰；运行中目录不重绑；A/B 项目并发/迟到事件/
无效 ID/断连；缺失项目记录仍找回对话；不级联删文件；失败不假保存；需求→开发
对话→仓库/commit→审阅测试→变更材料可反向溯源；无 Codex/外部 Agent/浏览器
时非网页工作仍可开展。未实现这些不能宣称项目支持完成。

## 6. 全面 UI/UX 后续顺序

主要面证据与验收见审计：真实项目/归属 → 当前对话代码与终端 → 资源的线程选择/
全局管理分区 → 知识导入/会议渐进展开 → 图谱/独立设置/Cockpit chrome 一致性。
每项另有 Issue 和交互验收，不把更新 DESIGN.md 计为全部页面已重做。
#476 native/MCP/技能/知识/原生确认/浏览器可见性依赖保持；目前 Chrome 按钮只
控制连接/打开，不等于任意任务后台、不抢焦点。窗口宽度不改变权限。

## 7. 当前门禁与外部复审重点

- #482/#483 给根因和前后行为；运行 owning tests，不能只有静态字符串断言。
- 元数据：未知字段/错类型/超长/空组/错线程/保存失败/断连/迟到回执；HTTP 与 WS
  都验证同一精确集合，alias+config 整包拒绝；重载/跨表面可见实际保存结果。
- 真实组件/HTML 合成传输测宽窄/短屏、新建/导航/管理/语音/停止/确认优先。
  这些不证明真实 STT 速度或 Windows 原生效果。
- 冻结代码和证据，实际 Grok + DeepSeek 独立复审并记录模型/结论；空输出、超时、
  tool XML 非批准；阻断修复重审。PR 关联 Issues，当前提交 CI 通过后才称可合并。
- 设计评审核查：当批/未来不混淆；folder 不冒充 project；项目非权限；执行/回执/
  录音不跨对话；overlay payload ACL 窄扩展明确；导航保留旧功能；恢复/窄屏/确认
  可测试；设计通过、实现通过和安装验证分别报告。

FILE docs/audit/2026-09-08-workspace-ux-audit.md
# 工作空间 UI/UX 源码审计

关联 [#481](https://github.com/nehcuh/cmspark/issues/481)。2026-09-08。
基线 `abd9995b059d0e97a36286028b478416158bdd8a`；下列行号是基线定位，同期 #482/
#483 修复可能已改变工作树，不能用此表重新判定最终提交仍有缺陷。
方法为源码/类型/路由/设计交叉阅读；未做本批真实麦克风时延、安装截图、Windows
原生视觉验收。事实为代码直示，推断为产品判断，未知需运行证明。方案见
[当前计划](../superpowers/plans/2026-09-08-workspace-projects-ux.md)。

## 1. 排序结论

| 优先级/归属 | 事实（仓库相对文件定位） | 推断与验收 |
|---|---|---|
| P1 #483 | `chrome-extension/src/sidepanel/components/FocusBand.tsx:75` 直接取全局 codingSession；`App.tsx:162` 任意新 sessionId 自动开面板；`store/agentStore.tsx:1720` 用前会话字段兜底 | 可解释新对话残留；须修事件合并和显示选择。A→B→A、交错/稀疏事件、停止/diff 目标验收，不能只藏 UI |
| P1 #482 | 用户报告召唤器无反应/插件慢；`companion/src/summoner-web.ts:1712` 含缓冲/时窗，`:1880` 启动链；插件另有 STT 适配层 | 仅源码不能断定窗长是唯一原因。测 capture-ready/partial/final，验证准备/失败/取消可见；实际设备延迟未知 |
| P2 #481 | `summoner-web.ts:813` PATCH 只写 alias；`:1906` 行仅打开/重命名/回收站 | 标签/组确未接入；复用字段与保存回执，精确扩展 payload ACL，不能另存组或假装项目 |
| P2 #481 | `WorkspaceFrame.tsx:52` 资源排在最近对话之前；`ContextPanelHost.tsx:63` “标签”表示 browser tabs | 对话优先、浏览器标签页明确命名；检查键盘/宽窄/短屏并保留整理/图谱 |
| P2 后续项目 | `companion/src/threads/thread-manager.ts:78` workspace_root 在 Thread；`:149` topic_folder 注明 not Project/Pack | 没有 Project 实体；可空 project_id 加独立实体，不能把组当目录/权限 |
| P2 后续资源 | `McpPanel.tsx:49` 线程选择，`:60` 全局服务器开关，`:69` 全局总开关，`:90` 编辑在同一面板 | 区分“用于本对话/全局管理”；错误/待保存就地呈现，不改安全路径 |
| P2 后续设置 | `SettingsPage.tsx:5` 已八分类；`companion/src/settings-web.ts:586` 全局模型页但 `:667` 按钮、`:673` 视觉说明仍英文 | 不泛称设置完全无结构。统一术语/范围/独立保存语义，不能伪装完整管理台 |

## 2. 主要界面、证据与可验收改进

表内 `sidepanel/`、`terminal/`、`cockpit/`、图谱路径均以 `chrome-extension/src/`
为根；明确标为 companion 的文件则以 `companion/src/` 为根。

| 界面 | 事实/可复用部分 | 推断的改进与验收（除注明本批外均后续） |
|---|---|---|
| 主工作区 | `sidepanel/components/WorkspaceFrame.tsx:43` 是既有 store 的最近投影；`StatusRail.tsx:223` 导航，`:236` 标题，`:238` 新建，`:254` ThreadList；`sidepanel/App.tsx:235` 消息、`:239` 资源、`:240` 输入 | 保留中性视觉，只修导航优先级/作用域，不加第二全局任务顶栏。本批测空对话/长标题/离线/新建/200% 等效 reflow，Stop 与输入不被遮挡 |
| 对话管理 | `ThreadList.tsx:1397` 管理，`:1400` 四类视图，`:1543` AI提取/整理/图谱/回收站；`ThreadMetadataEditor.tsx:18` 规范化；`utils/thread-management.ts:13` persisted ACK，`:8` AI组派生 | 端间补齐，不再造缓存。本批测空分类、失败保留、错/迟回执、重载、AI不覆盖人工；不宣称召唤器已具备全部 AI/图谱 |
| 召唤器 | companion `summoner-web.ts:1462` 左栏，`:1496` 窄导航，`:2518` 排序，`:2524` 资源切换；`:260` MCP投影只名字/状态；`:2589` 技能/`:2606` 知识仅挂载本对话 | 导航名称不能暗示全量管理。元数据本批窄扩展，MCP/安装/终端仍按#476。测晚资源响应、线程切换、空/错误态；普通本地聊天不强开Chrome |
| 输入/附件/捕获 | `ComposerDock.tsx:13` 只是容器，输入内部在 App；companion `summoner-web.ts:1529` mic，`:1540` 附近 composer/capture，`:1552` 隐私卡；隐藏旧设置按钮 `:1538` | 改容器不能证明全部输入流程已修。听写/附件固定草稿目标，取消/隐藏释放资源；不得增加看似可用的死设置入口。捕获与正文的来源应可辨 |
| 语音/会议 | `VoiceStatusCapsule.tsx:5` 状态与live text，`:35` 电平动画；`MeetingPanel.tsx:1243` 模式/互斥/不自动开麦，`:1271` 仍旧设置路径，`:1445` 录制，`:1503` 说话人/导入，`:1675` 转写，`:1781` 纪要 | 本批准备/处理/失败清晰、停止和晚终稿、跨对话与会议互斥。后续按记录/导入→校对→生成组织，高级说话人折叠；手改转写不能被晚同步覆盖。时延需实机，不据动画推断 |
| 编程控制器 | `CodingAgentPanel.tsx:110` 接 workspace；`App.tsx:244` 取当前thread的目录/消息，但全局codingSession未同样限定；`CodingSessionShell.tsx:53` CLI单轮输入禁用 | 先修归属，保留有效结果。后续当前对话“代码与终端”，其他运行侧栏跳转；不能宣传所有 CLI 多轮。A/B与多个session、操作闭包、late event测清 |
| 内嵌终端 | `terminal/TerminalApp.tsx:61` thread/review关联；`:230` 标题仅“内嵌终端”/状态；`:256` 默认展开手工提示与JSON回传 | 后续加可读归属/回对话，回传按需展开。测正确review/thread收到、失败保留JSON、关闭实际生命周期；手工流程不能称自动回传，导入成功不等于审阅通过 |
| 场景/技能/知识 | `PacksPanel.tsx:1387` 场景状态内藏工作目录，`:1437` 场景绑定多资源；`ContextPanelHost.tsx:392` SkillsPanel；`KnowledgeSubPanel.tsx:1028` 文件/大文件/文件夹/URL/建夹五入口 | 后续目录回项目/对话上下文，保留场景兼容入口；知识导入可菜单收拢但保留不同picker/限额。测场景卸载不丢手工目录，各导入底层校验保留，管理与当前选择分开 |
| MCP/应用/任务板 | `McpPanel.tsx:49–104` 当前选择/全局管理混合；`AppsPanel.tsx:25` 独立应用；`ContextPanelHost.tsx:311` BoardPanel | 后续固定搜索/当前选择/管理分区；全局启停不能误称只影响本对话。任务板、编程、浏览器状态不互相覆盖；不得另造运行事实源 |
| 插件设置 | `SettingsPage.tsx:5` 模型/语音/文件知识/连接/安全/本机工具/密钥/实验八类，`:16` 隐藏但不卸载；`SettingsSlideout.tsx:829` 宽导航、`:831` 窄选择 | 保留分类与草稿；文件知识“偏好”区别资源内容管理，本机工具按对象分区。验收深链、切页草稿、masked secret保留、保存/下载/连接各自回执，不能一个Save越过确认 |
| 独立设置 | companion `settings-web.ts:586` 全局模型作用域；`:667` Save/Test/Cancel，`:673` Vision Model及说明英文 | 后续统一中文并注明只配置全局模型；未覆盖功能不显示假入口。模型/视觉测试与持久保存分开，错误保留输入，密钥不泄露 |
| 确认台 | `cockpit/CockpitApp.tsx:148` 标题含模式/连接/原始thread ID，`:189` 急停，`:197` 收起不停止提示，`:233` 独立ConfirmElevated | 后续标题可读化属chrome改进，不是权限缺陷。本批不改确认DOM/handler。验收风险证据/拒绝/急停可见、收起真实不停止、断连挑战正确取消 |
| 对话/知识图谱 | `thread-graph/ThreadGraphApp.tsx:692` 搜索/阈值toolbar，`:970` 键盘说明；`knowledge-graph/KnowledgeGraphApp.tsx:637` toolbar，`:708` 组，`:760` 图语义 | 保留两图及入口，后续共享返回/空态/toolbar文法。搜索/焦点优先、高级阈值展开；无标签/边/重建/错误可解释，节点回正确实体，相关度不冒充业务依赖证据 |
| 品牌/托盘/宿主 | `scripts/lib/brand-icon.mjs` 连接火花；#474已区分进程与连接状态；#477窗口仍Chromium，非完整native身份 | 保留已交付标识；Mac/Windows运行截图另验，不据PNG证明安装替换。放大/召唤不改权限，浏览器连接前后台不等于逐任务可见性保证 |

## 3. 项目与复用边界

**事实：** Thread（`companion/src/threads/thread-manager.ts:42–152`）含人工分类、
AI digest、workspace_root、资源选择和运行信息，没有 project_id；插件 `types.ts:55`
同为线程目录，`:77` topic_folder注明非Project。`message-router.ts:2984` 通用更新
有 user_tags/topic_folder，workspace_root走独立workspace路径。`ws/summoner-acl.ts`
基线payload gate为alias-only。因此当前窄扩展是实际ACL变化，需要协议/负例复审。

**推断：** 项目适合长期业务/代码范围，但不是多一个筛选器。可复用Thread/元数据
规范化与确认、目录选择校验、ACP/PTY IDs、资源库、确认manager。后续才新增独立
Project、可空归属、目录建议、迁移候选；不用新项目偷渡自动授权。详细流程见计划§5。

## 4. 完成标准与未知

- 本审计覆盖主要入口/所有权，不是逐控件WCAG或视觉认证，没有“美观分”。未验收的
  会议/设置/图谱/终端改进仍是后续工作；不得计入本批实现完成率。
- 用户语音症状需真实权限、音频设备、模型冷热启动实测。静态时窗不是唯一根因证据。
- 编程归属缺陷有高置信源码解释；最终需测当前提交，不能只引用此基线。
- 本批交付限计划§1；项目实体仍提案，#476原生/高权限/浏览器任务策略继续独立跟踪。
- 机器检查、真实双模型复审、当前CI、安装/运行证明分别留痕；设计通过不等于实现通过。
