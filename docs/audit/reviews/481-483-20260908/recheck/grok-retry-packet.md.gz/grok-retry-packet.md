Final delta re-review for #481/#482/#483 following initial full implementation review. Review independently; do not trust prior claims without checking actual code. Scope remains voice reliability + coding thread ownership + metadata-only overlay ACL + UI/audit. No Project entity/native desktop/real ASR speedup claim. Same model required. End explicit VERDICT: APPROVE, APPROVE_WITH_NITS or REJECT with remaining concrete blockers.

Verified dispositions to independently check:
1. Summoner poll NEVER assigns to s.queue. It observes current upload queue; stopping cancels its timer and checks stopping before issuing. applyEvent NEVER calls finish for SSE final. Only successful /api/stt/end HTTP calls finish, which clears current and marks cancelled. New deterministic and real-HTML tests send pending partial -> stop -> SSE final -> partial HTTP fake final -> end HTTP final and prove exactly one commit. This corrects a prior hypothetical duplicate path. Not a requirement to accept a self-review: inspect exact source/tests below.
2. overlaySttSessionId is an exit-cleanup tracker, not a session lock. Normal JSON errors on end/abort clear it; thrown transport failures preserve it so hide can abort. Tests prove both behaviors and new start after error. Do not clear the only recovery pointer on throw.
3. Real legacy early ui_start failure owner gap fixed: resolve/validate owner once from explicit input or ctx.threadId and reuse it for execution/reply. Created-session replies already used actual session owner. Tests cover early failure, explicit invalid, wrong owner before confirm, correct owner into existing confirm gate.
4. Unknown first background B events may precede thread.list and must cache under B; they never display in A. Cached owner reassignment rejected. New test covers this. Do not infer auth ownership from active UI or currently hydrated list.
5. Grok onStart-before-capture nit fixed: start fires only after production PCM capture resolves and cancellation checks, once per session; continuous segments use segment callback. Adapter tests and actual React useVoiceInput + production PCM browser test cover starting -> listening -> interim -> final, cancellation during permission, delayed final after thread switch.
6. Added pagehide controller cancel and small abort fetch keepalive. Switch/new/close cancel dictation and discard uncommitted result, no automatic write to departed thread.
7. Classification controls >=32px, save focuses same owner row (fallback search), alias NFC normalized. HTTP/WS exact whitelist stays alias/tags/folder, no scope expansion.
8. Same companion+extension build must ship together; absent owner on old responses stays unknown, never guessed active. Install instructions explicitly reload extension. Future skew diagnostics/legacy compatibility does not authorize cross-thread rendering.
9. Non-selected coding session payload retention is tracked separately in Issue #484; preserve dismissal and late-event behavior in this slice. Initial Grok classified it harmless-for-slice. This re-review must independently decide if any actual current blocker remains.
10. Initial DeepSeek report's claim that both judges identified a duplicate race was not evidence: only that report made the claim. Grok separately confirmed HTTP-only final. Judge attribution must describe your actual model only.

Machine: original full companion 5012 pass/23 skip+20 auxiliary; extension1293 pass. After delta: companion90 owning pass (server/controller/ACP/metadata), voice35 owning pass, actual hook browser PASS, metadata focus/stale-thread browser PASS. Final full CI will run after commit. Below is complete delta and full relevant changed code/context; unchanged initial full patch is pinned by manifest and prior report. No new broad permissions.

DELTA after initial full packet:
diff --git a/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts b/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
index c0b9d571..05696f26 100644
--- a/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
+++ b/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
@@ -548,21 +548,21 @@ export function createLocalSttAdapter(
     }
   }
 
   /**
    * M2 streaming continuous: PCM chunks live + partial_request → interim hypothesis;
    * window end → single final commit (F3: no mid-window finalChunk).
    * Window length honors segmentCapMs (F1), default ~8s when realtime.
    */
   const runStreamingContinuous = async (gen: number) => {
     try {
-      handlers.onStart()
+      let reportedStart = false
       while (!dead && wantListening && gen === loopGen) {
         const remaining = hardCapMs - (Date.now() - wallStart)
         if (remaining < 200) break
 
         // F1: honor near-realtime segmentCapMs (not always 45s)
         const windowMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
         segmentIndex += 1
         const segSid = `${parentSessionId}-s${segmentIndex}`
         sessionId = segSid
         phase = "recording"
@@ -647,20 +647,26 @@ export function createLocalSttAdapter(
           ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
           format: "pcm_s16le",
           sampleRate: LOCAL_STT_SAMPLE_RATE,
           channels: LOCAL_STT_CHANNELS,
           lang: lang.startsWith("zh") ? "zh" : lang,
           maxMs: windowMs,
           // P1: same wire gate as classic WAV start — continuous/hold path must not omit
           privacy_ack_v2: true,
         })
         sessionStarted = true
+        // Permission/capture acquisition is still "starting". Report listening
+        // only once capture is ready; later windows use onSegmentContinue.
+        if (!reportedStart) {
+          reportedStart = true
+          handlers.onStart()
+        }
 
         // Adaptive partial poll: setTimeout chain paced by last hypothesis `ms`
         clearPartialTimer()
         const schedulePartialPoll = () => {
           clearPartialTimer()
           if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
           if (phase !== "recording") return
           partialTimer = setTimeout(() => {
             partialTimer = null
             if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
diff --git a/chrome-extension/tests/coding-session-owner-483.test.ts b/chrome-extension/tests/coding-session-owner-483.test.ts
index 0b067cac..a63be19d 100644
--- a/chrome-extension/tests/coding-session-owner-483.test.ts
+++ b/chrome-extension/tests/coding-session-owner-483.test.ts
@@ -66,10 +66,26 @@ test("commands and result feedback require an exact nonempty conversation owner"
   const state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "running" })
   const session = selectCodingSession(state)
   assert.equal(codingSessionBelongsToThread(session, "a"), true)
   assert.equal(codingSessionBelongsToThread(session, "b"), false)
   assert.equal(codingSessionBelongsToThread(session, null), false)
   assert.equal(codingMessageTargetsThread({ thread_id: "a" }, "a"), true)
   assert.equal(codingMessageTargetsThread({ thread_id: "a" }, "b"), false)
   assert.equal(codingMessageTargetsThread({}, "b"), false)
   assert.equal(codingMessageTargetsThread({ thread_id: "" }, null), false)
 })
+
+
+test("first background B event before thread-list hydration remains in B and restores on navigation", () => {
+  let state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "running" })
+  assert.deepEqual(state.threads, [], "thread.list is not required to admit authenticated session events")
+  state = event(state, { session_id: "sb", thread_id: "b", state: "running", workspace_root: "/repo/b", goal: "background B" })
+  assert.equal(selectCodingSession(state)?.sessionId, "sa")
+  state = event(state, { session_id: "sb", progress_tail: "B progress before hydration" })
+  assert.equal(selectCodingSession(state)?.sessionId, "sa")
+  state = switchTo(state, "b")
+  assert.equal(selectCodingSession(state)?.sessionId, "sb")
+  assert.equal(selectCodingSession(state)?.workspaceRoot, "/repo/b")
+  assert.equal(selectCodingSession(state)?.progressTail, "B progress before hydration")
+  const conflict = event(state, { session_id: "sb", thread_id: "a", progress_tail: "rebind attempt" })
+  assert.equal(conflict, state, "the stored session owner remains immutable")
+})
diff --git a/chrome-extension/tests/voice-classic-preview.test.ts b/chrome-extension/tests/voice-classic-preview.test.ts
index 36364779..3e505d6e 100644
--- a/chrome-extension/tests/voice-classic-preview.test.ts
+++ b/chrome-extension/tests/voice-classic-preview.test.ts
@@ -1,17 +1,59 @@
 import test from "node:test"
 import assert from "node:assert/strict"
 import { createLocalSttAdapter } from "../src/sidepanel/voice/local-stt-adapter"
 import type { PcmStreamCaptureOpts } from "../src/sidepanel/voice/pcm-stream-capture"
+import type { PcmStreamHandle } from "../src/sidepanel/voice/pcm-stream-capture"
 
 const turn = () => new Promise<void>((resolve) => setTimeout(resolve, 0))
 
+test("#482 streaming remains starting until capture is ready; continuous windows report start once", async () => {
+  for (const mode of ["classic", "continuous"] as const) {
+    const sent: any[] = [], pending: { resolve: (h: PcmStreamHandle) => void; opts: PcmStreamCaptureOpts }[] = []
+    let receive: (msg: any) => void = () => {}, starts = 0
+    const adapter = createLocalSttAdapter({ onStart: () => { starts++ }, onResult() {}, onError() {}, onEnd() {} }, {
+      modelId: "small", send: (msg) => { sent.push(msg); if (msg.type === "voice.stt.end") queueMicrotask(() => receive({ type: "voice.stt.result", sessionId: msg.sessionId, text: "一段" })) },
+      onMessage: (h) => { receive = h; return () => {} },
+      startPcmStreamCapture: (opts) => new Promise((resolve) => pending.push({ resolve, opts })),
+    })
+    const handle = (): PcmStreamHandle => ({ backend: "scriptprocessor", stop: async () => {}, abort() {} })
+    try {
+      adapter.start({ sessionId: "permission-" + mode, mode, streamPartial: true, segmentMs: 25, hardCapMs: 1000 })
+      await turn()
+      assert.equal(pending.length, 1); assert.equal(starts, 0)
+      assert.equal(sent.some((m) => m.type === "voice.stt.start"), false)
+      pending[0].resolve(handle()); await turn()
+      assert.equal(starts, 1)
+      pending[0].opts.onPcmChunk(new Uint8Array(32000))
+      if (mode === "continuous") {
+        await new Promise((resolve) => setTimeout(resolve, 60))
+        assert.equal(pending.length, 2)
+        assert.equal(starts, 1, "a later permission/capture acquisition must not emit another ENGINE_START")
+        pending[1].resolve(handle()); await turn()
+        assert.equal(starts, 1)
+      }
+    } finally { adapter.abort(); adapter.destroy() }
+  }
+})
+
+test("#482 stopping while capture permission is pending never reports listening", async () => {
+  let grant!: (h: PcmStreamHandle) => void, starts = 0, released = 0, ends = 0
+  const adapter = createLocalSttAdapter({ onStart: () => { starts++ }, onResult() {}, onError() {}, onEnd: () => { ends++ } }, {
+    modelId: "medium", send() {}, onMessage: () => () => {},
+    startPcmStreamCapture: () => new Promise((resolve) => { grant = resolve }),
+  })
+  adapter.start({ sessionId: "permission-cancel", mode: "classic", streamPartial: true }); await turn()
+  adapter.stop(); grant({ backend: "scriptprocessor", stop: async () => {}, abort: () => { released++ } }); await turn()
+  assert.equal(starts, 0); assert.equal(released, 1); assert.equal(ends, 1)
+  adapter.destroy()
+})
+
 test("#482 ordinary local dictation previews during recording, then commits one final on stop", async () => {
   const sent: any[] = [], results: { interim: string; finalChunk: string }[] = []
   let receive: (msg: any) => void = () => {}, capture: PcmStreamCaptureOpts | undefined
   let ends = 0, stops = 0
   const adapter = createLocalSttAdapter({
     onStart() {}, onResult: (r) => results.push(r), onError: (e) => { throw new Error(e) }, onEnd: () => { ends++ },
   }, {
     modelId: "medium", send: (msg) => sent.push(msg),
     onMessage: (h) => { receive = h; return () => { receive = () => {} } },
     startCapture: async () => { throw new Error("batch capture should not run") },
diff --git a/companion/scripts/test-summoner-voice-ui.py b/companion/scripts/test-summoner-voice-ui.py
index 91c95901..3cdfc2d7 100644
--- a/companion/scripts/test-summoner-voice-ui.py
+++ b/companion/scripts/test-summoner-voice-ui.py
@@ -7,74 +7,111 @@ from pathlib import Path
 from urllib.parse import urlparse
 import json
 import subprocess
 import tempfile
 from playwright.sync_api import sync_playwright
 
 root = Path(__file__).resolve().parent.parent
 bootstrap = """
 window.EventSource=class {constructor(){window.fixtureEvents=this} addEventListener(){} close(){}};
 window.resizeTo=()=>{};window.moveTo=()=>{};
+const fixtureSetTimeout=window.setTimeout.bind(window);
+window.fixturePartialTimers=[];
+window.setTimeout=(fn,ms,...args)=>{
+  if(ms===1400){const id=fixtureSetTimeout(()=>{},999999);window.fixturePartialTimers.push({id,fn});return id}
+  return fixtureSetTimeout(fn,ms,...args);
+};
+window.fixtureFirePartial=()=>{const item=window.fixturePartialTimers.shift();clearTimeout(item.id);item.fn()};
 window.SpeechRecognition=class {
   constructor(){window.fixtureRecognition=this}
   start(){queueMicrotask(()=>this.onstart?.())}
   stop(){queueMicrotask(()=>this.onend?.())}
   abort(){}
 };
 Object.defineProperty(navigator,'mediaDevices',{value:{getUserMedia:async()=>({getTracks:()=>[{stop(){window.fixtureStopped=true}}]})}});
 window.AudioContext=class {
   state='running';sampleRate=16000;
   createMediaStreamSource(){return {connect(){},disconnect(){}}}
   createScriptProcessor(){return window.fixtureProcessor={connect(){},disconnect(){}}}
   createGain(){return {gain:{value:0},connect(){},disconnect(){}}}
   close(){return Promise.resolve()}
 };
 """
 with tempfile.TemporaryDirectory() as out:
     subprocess.run(['node', 'scripts/render-web-surface-fixtures.cjs', out], cwd=root, check=True)
     html = (Path(out) / 'capture.html').read_text().replace('%%CRUISE_LABEL%%', '每次确认')
     with sync_playwright() as p:
         browser = p.chromium.launch(channel='chrome', headless=True)
-        for engine in ['browser', 'local', 'system']:
+        for engine, scenario in [('browser', 'normal'), ('local', 'normal'), ('system', 'normal'), ('local', 'pending-partial'), ('local', 'pagehide')]:
             page = browser.new_page(viewport={'width': 360, 'height': 600})
             page.set_default_timeout(6000)
             page.add_init_script(bootstrap)
-            requests, errors = [], []
+            requests, errors, pending_routes = [], [], {}
             page.on('pageerror', lambda error: errors.append(str(error)))
             def route(r):
                 path = urlparse(r.request.url).path
                 body = r.request.post_data_json if r.request.post_data else {}
                 requests.append((path, body))
                 if path == '/':
                     r.fulfill(content_type='text/html', body=html)
                     return
+                if scenario == 'pending-partial' and path in ['/api/stt/partial', '/api/stt/end']:
+                    pending_routes[path] = (r, body)
+                    return
                 if path == '/api/voice-settings': data = {'sttEngine': engine, 'localModelId': 'medium', 'lang': 'zh-CN'}
                 elif path == '/api/threads': data = {'threads': [{'id': 'thread-a', 'alias': '语音验收'}]}
                 elif path == '/api/thread': data = {'messages': [], 'run_status': 'idle'}
                 elif path == '/api/stt/end': data = {'type': 'voice.stt.result', 'sessionId': body['sessionId'], 'text': '本机识别结果'}
                 else: data = {'type': 'ok'}
                 r.fulfill(content_type='application/json', body=json.dumps(data))
             page.route('http://voice.fixture/**', route)
             page.goto('http://voice.fixture/')
             page.locator('#mic').click()
             page.locator('#voicePrivacyAck').click()
             page.wait_for_function('document.querySelector("#voiceStatus").textContent.includes("正在听写")')
             if engine == 'browser':
                 page.evaluate('window.fixtureRecognition.onresult({resultIndex:0,results:[{0:{transcript:"浏览器结果"},isFinal:true}]})')
             else:
                 page.evaluate('window.fixtureProcessor.onaudioprocess({inputBuffer:{getChannelData:()=>new Float32Array(16000)}})')
+            if scenario == 'pagehide':
+                with page.expect_request('**/api/stt/abort'):
+                    page.evaluate('window.dispatchEvent(new PageTransitionEvent("pagehide"))')
+                assert page.evaluate('window.fixtureStopped === true')
+                assert page.locator('#text').input_value() == ''
+                assert not errors, errors
+                page.close()
+                continue
+            if scenario == 'pending-partial':
+                with page.expect_request('**/api/stt/partial'):
+                    page.evaluate('window.fixtureFirePartial()')
             page.locator('#mic').click()
+            if scenario == 'pending-partial':
+                # End must reach HTTP while partial remains unresolved.
+                page.wait_for_function('document.querySelector("#voiceStatus").textContent.includes("正在识别")')
+                page.evaluate('Promise.resolve()')
+                assert '/api/stt/end' in pending_routes, 'partial must not block final end'
+                end_route, end_body = pending_routes['/api/stt/end']
+                sid = end_body['sessionId']
+                page.evaluate('(sid)=>window.fixtureEvents.onmessage({data:JSON.stringify({type:"voice.stt.result",sessionId:sid,text:"重复结果"})})', sid)
+                assert page.locator('#text').input_value() == ''
+                partial_route, _ = pending_routes['/api/stt/partial']
+                partial_route.fulfill(content_type='application/json', body=json.dumps({'type': 'voice.stt.result', 'sessionId': sid, 'text': '重复结果'}))
+                end_route.fulfill(content_type='application/json', body=json.dumps({'type': 'voice.stt.result', 'sessionId': sid, 'text': '唯一结果'}))
             page.wait_for_function('document.querySelector("#text").value.includes("结果")')
+            if scenario == 'pending-partial':
+                assert page.locator('#text').input_value() == '唯一结果'
+                page.evaluate('(sid)=>window.fixtureEvents.onmessage({data:JSON.stringify({type:"voice.stt.result",sessionId:sid,text:"重复结果"})})', sid)
+                assert page.locator('#text').input_value() == '唯一结果'
             assert not errors, errors
             if engine == 'browser':
                 assert not any(path.startswith('/api/stt/') for path, _ in requests)
             else:
                 actual = [(path, body) for path, body in requests if path in ['/api/stt/start', '/api/stt/chunk', '/api/stt/end']]
                 assert [path for path, _ in actual] == ['/api/stt/start', '/api/stt/chunk', '/api/stt/end'], actual
                 assert actual[0][1]['engine'] == engine
                 assert actual[-1][1]['totalSeq'] == 1
                 assert page.evaluate('window.fixtureStopped === true')
             assert page.locator('#voiceStatus').is_visible()
             assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
             page.close()
         browser.close()
-print('PASS: real summoner HTML; browser/local/system selection, privacy action, visible recording state, preview/final, ordered HTTP upload and microphone cleanup. Synthetic capture only.')
+print('PASS: real summoner HTML; browser/local/system selection, privacy action, visible recording state, ordered HTTP upload; pending partial does not block end; duplicate SSE/partial finals never commit; final HTTP commits once; pagehide cancels microphone/session. Synthetic capture only.')
diff --git a/companion/scripts/test-summoner-workspace-ui.py b/companion/scripts/test-summoner-workspace-ui.py
index 0e09171a..99044491 100644
--- a/companion/scripts/test-summoner-workspace-ui.py
+++ b/companion/scripts/test-summoner-workspace-ui.py
@@ -1,13 +1,13 @@
 """Actual summoner HTML script, synthetic HTTP responses; no installed Companion."""
 from pathlib import Path
-from urllib.parse import urlparse
+from urllib.parse import urlparse,parse_qs
 import json,subprocess,tempfile
 from playwright.sync_api import sync_playwright
 root=Path(__file__).resolve().parent.parent
 shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
 with tempfile.TemporaryDirectory() as out:
  subprocess.run(['node','scripts/render-web-surface-fixtures.cjs',out],cwd=root,check=True)
  html=(Path(out)/'capture.html').read_text().replace('%%CRUISE_LABEL%%','每次确认')
  with sync_playwright() as p:
   b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':390,'height':740});page.set_default_timeout(6000)
   browser_status={'connected':False}
@@ -16,22 +16,24 @@ with tempfile.TemporaryDirectory() as out:
   extra_threads=[];held=[];delay_select={'enabled':False}
   errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.add_init_script('window.EventSource=class {constructor(){window.fixtureEvents=this} addEventListener(){} close(){}};window.resizeTo=()=>{};window.moveTo=()=>{};')
   def route(r):
    req=r.request;path=urlparse(req.url).path;requests.append((req.method,path))
    if path=='/':r.fulfill(content_type='text/html',body=html);return
    if path=='/api/threads':data={'thread':{'id':'fixture-1'}} if req.method=='POST' else {'threads':[thread]+extra_threads}
    elif path=='/api/thread':
     if req.method=='POST' and delay_select['enabled'] and req.post_data_json.get('thread_id')=='fixture-1':held.append(r);return
     if req.method=='PATCH':
-     if metadata_ack['valid']:thread.update(req.post_data_json)
-     data={'type':'thread.updated','thread':thread.copy()}
+     owner_id=parse_qs(urlparse(req.url).query).get('id',['fixture-1'])[0]
+     owner_thread=next(t for t in [thread]+extra_threads if t['id']==owner_id)
+     if metadata_ack['valid']:owner_thread.update(req.post_data_json)
+     data={'type':'thread.updated','thread':owner_thread.copy()}
     else:data={'thread':thread,'messages':[],'run_status':'idle'}
    elif path=='/api/mcp':data={'servers':[]}
    elif path=='/api/browser-status':data=browser_status
    else:data={'ok':True}
    r.fulfill(content_type='application/json',body=json.dumps(data))
   page.route('http://fixture.test/**',route);page.goto('http://fixture.test/')
   text=page.get_by_role('textbox',name='发送到当前对话',exact=True);text.wait_for()
   page.wait_for_timeout(200);assert not errors,errors
   page.get_by_role('button',name='新对话',exact=True).first.click()
   page.wait_for_function('document.querySelector("#empty strong")')
@@ -104,20 +106,24 @@ with tempfile.TemporaryDirectory() as out:
   page.screenshot(path=str(shots/'summoner-477-narrow.png'))
   page.get_by_role('button',name='导航',exact=True).click()
   page.set_viewport_size({'width':1000,'height':800});page.keyboard.press('Escape')
   assert page.locator('#newChat').evaluate('(el)=>el===document.activeElement')
   with page.expect_file_chooser():page.get_by_role('button',name='添加附件',exact=True).click()
   text.fill('请整理变更材料');page.get_by_role('button',name='发送',exact=True).click()
   page.wait_for_timeout(200);assert ('POST','/api/chat') in requests
   extra_threads.append({'id':'fixture-2','alias':'第二对话'})
   page.get_by_role('button',name='对话',exact=True).click()
   page.locator('#threads .item').filter(has_text='第二对话').wait_for()
+  page.get_by_role('button',name='分类 · 第二对话',exact=True).click()
+  page.get_by_role('textbox',name='人工标签',exact=True).fill('第二个标签')
+  page.get_by_role('button',name='保存',exact=True).click()
+  page.wait_for_function('document.querySelector("#threadMetadata").hidden && document.activeElement?.dataset.threadId==="fixture-2"')
   delay_select['enabled']=True
   page.locator('#threads .item').filter(has_text='演示对话').click()
   page.locator('#threads .item').filter(has_text='第二对话').click()
   page.wait_for_function('document.querySelector("#workspaceTitle").textContent==="第二对话"')
   assert held,'first select request should be held'
   for r in held:r.fulfill(content_type='application/json',body=json.dumps({'messages':[{'role':'assistant','content':'旧对话迟到内容'}],'run_status':'llm'}))
   page.wait_for_timeout(100)
   assert '旧对话迟到内容' not in page.locator('#log').inner_text()
   assert not page.locator('#stopGo').is_visible()
   assert not errors,errors
diff --git a/companion/src/acp/handlers.ts b/companion/src/acp/handlers.ts
index 57dcfff1..31c66227 100644
--- a/companion/src/acp/handlers.ts
+++ b/companion/src/acp/handlers.ts
@@ -62,25 +62,34 @@ export async function handleAcpWsMessage(
     : type === "acp.session.followup" && typeof msg.parent_session_id === "string" ? msg.parent_session_id : ""
   const session = controlsSession && sid ? mgr.getSession(sid) : undefined
   const claimedOwner = msg.thread_id !== undefined ? msg.thread_id : ctx.threadId
   if (controlsSession && claimedOwner !== undefined &&
       (typeof claimedOwner !== "string" || !claimedOwner || (session && session.thread_id !== claimedOwner))) {
     return {
       type: "error", family: "acp", error: "acp: session does not belong to the requested conversation",
       session_id: sid, ...(session ? { thread_id: session.thread_id } : {}),
     }
   }
-  const result = await handleAcpWsMessageInternal(type, msg, ctx)
+  // Resolve a start owner once, before any side effect. The legacy context is
+  // used only for an omitted field, never to rescue an explicitly invalid one.
+  const startCandidate = msg.thread_id !== undefined ? msg.thread_id : ctx.threadId
+  const startOwner = type === "acp.ui_start" && typeof startCandidate === "string" && startCandidate.trim()
+    ? startCandidate : undefined
+  if (type === "acp.ui_start" && !startOwner) {
+    return { type: "error", family: "acp", error: "acp: thread_id required" }
+  }
+  const executionMessage = startOwner ? { ...msg, thread_id: startOwner } : msg
+  const result = await handleAcpWsMessageInternal(type, executionMessage, ctx)
   if (!result || typeof result !== "object") return result
   const resultSession = typeof result.session_id === "string" ? mgr.getSession(result.session_id) : undefined
   const owner = resultSession?.thread_id ?? session?.thread_id ??
-    (type === "acp.ui_start" && typeof msg.thread_id === "string" ? msg.thread_id : undefined)
+    startOwner
   return {
     ...result,
     ...(result.type === "error" ? { family: "acp" } : {}),
     ...(owner ? { thread_id: owner } : {}),
     ...(!result.session_id && sid ? { session_id: sid } : {}),
   }
 }
 
 async function handleAcpWsMessageInternal(
   type: string,
@@ -247,21 +256,21 @@ async function handleAcpWsMessageInternal(
       }
       return { type: "error", error: r.error }
     }
     return { type: "acp.session.prompt.accepted", session_id: sid, mode: "live" }
   }
 
   if (type === "acp.ui_start" || type === "acp.session.followup") {
     // Workers never start ACP — check before enabled so isolation holds even when feature off
     // and tests need not mutate global config.json (CI DATA_DIR).
     if (type === "acp.ui_start") {
-      const tid = String(msg.thread_id || ctx.threadId || "")
+      const tid = String(msg.thread_id || "")
       if (tid && ctx.getAgentRole?.(tid) === "worker") {
         return { type: "error", error: "acp: worker threads cannot start ACP sessions" }
       }
       // RN1: require disclosure flag before feature-disabled so UI can distinguish
       // missing checkbox vs master switch (no home config mutation needed in tests).
       if (msg.cloud_disclosure_accepted !== true) {
         return {
           type: "error",
           error: "acp: cloud_disclosure_accepted required (勾选云模型披露)",
         }
@@ -289,21 +298,21 @@ async function handleAcpWsMessageInternal(
       const followMode =
         msg.mode === "propose_diff" || msg.mode === "review_readonly"
           ? (msg.mode as "review_readonly" | "propose_diff")
           : parent?.mode || "review_readonly"
       proposed = mgr.followup({
         parentSessionId: parentId,
         goal,
         mode: followMode,
       })
     } else {
-      const threadId = String(msg.thread_id || ctx.threadId || "")
+      const threadId = String(msg.thread_id || "")
       if (!threadId) return { type: "error", error: "thread_id required" }
       const agentId = String(msg.agent_id || "")
       const goal = String(msg.goal || "").trim()
       if (!agentId) return { type: "error", error: "agent_id required" }
       if (!goal) return { type: "error", error: "goal required" }
       const workspaceRoot =
         (typeof msg.workspace_root === "string" && msg.workspace_root) ||
         ctx.getWorkspaceRoot?.(threadId) ||
         null
       const pageContext =
diff --git a/companion/src/summoner-web.ts b/companion/src/summoner-web.ts
index 5f6b00bc..6b0c0aff 100644
--- a/companion/src/summoner-web.ts
+++ b/companion/src/summoner-web.ts
@@ -1447,21 +1447,21 @@ button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px soli
 .thread-search[hidden]{display:none}.thread-search input{display:block;width:100%;margin-top:6px;padding:8px 10px;border:1px solid var(--line);border-radius:8px;font:inherit;background:var(--paper);color:var(--text)}
 .resource-note{padding:10px;font-size:12px;line-height:1.6;color:var(--secondary)}
 .resource-readonly{cursor:default}.resource-readonly:hover{background:transparent}
 .rail{display:flex;align-items:stretch;gap:2px;padding:12px 8px;border:0;overflow:auto}
 .rail-btn{display:flex;align-items:center;gap:10px;width:100%;height:36px;padding:0 10px;font:inherit;text-align:left;border-radius:8px}
 .rail-btn svg{width:18px;height:18px;flex:none}.rail-btn[aria-current="true"]{background:#eaeae7;color:var(--text)}
 .hud.expanded .body{flex-direction:row;border-bottom:0}
 .list{display:flex;width:220px;flex:none;background:var(--rail-bg)}
 .hud.history .list{position:static;inset:auto;width:220px;border-right:1px solid var(--line)}
 .list-head{font-size:12px;letter-spacing:0;color:var(--secondary)}
-.item.active{background:#eaeae7;color:var(--text)}.item strong{overflow-wrap:anywhere}.trow{flex-wrap:wrap}.trow .item{flex-basis:100%}.trow .icon-mini{height:28px}
+.item.active{background:#eaeae7;color:var(--text)}.item strong{overflow-wrap:anywhere}.trow{flex-wrap:wrap}.trow .item{flex-basis:100%}.trow .icon-mini{height:32px;min-height:32px}
 #historyClose{display:none}.log{padding:32px 28px}.empty{margin:auto;max-width:440px;line-height:1.8;color:var(--secondary)}
 .empty strong{font-size:28px;color:var(--text);margin-bottom:8px}
 @media(min-width:760px){.hud{background:var(--rail-bg)}.capture-row{background:var(--paper)}.log{max-width:none;padding-left:max(24px,calc((100vw - 1000px)/2));padding-right:max(24px,calc((100vw - 1000px)/2))}.composer,.capture-row,.status,.cta-box{margin-left:220px;max-width:none;width:calc(100% - 220px)}.composer{padding-left:max(24px,calc((100vw - 1000px)/2));padding-right:max(24px,calc((100vw - 1000px)/2))}.cta-box,.status{width:calc(100% - 244px)}#historyOpen{display:none}}
 @media(max-width:759px){.brand{flex-wrap:wrap}.brand-actions{flex-wrap:wrap;min-width:0}.hud.expanded .body{flex-direction:column}.list{display:none}.hud.history .list{display:flex;width:100%;max-height:36vh;min-height:0;border-right:0;border-bottom:1px solid var(--line)}.rail{flex-direction:row;flex-wrap:wrap;flex-shrink:0;padding:6px}.rail-btn{width:auto;height:32px;padding:0 8px;font-size:12px}.rail-btn svg{display:none}.list-head{padding:4px 12px}.list-scroll{min-height:0}#historyClose{display:block}.log{padding:20px}.empty strong{font-size:22px}}
 @media(max-height:560px){.hud.history .list{max-height:28vh}.log{padding:12px}.empty{padding:8px}.empty strong{font-size:20px}.capture-row{padding-bottom:6px}.composer{padding-top:6px}}
 
 .brand-id{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}.brand-actions{flex:none}
 .workspace-tools{width:100%;min-width:0;flex:none;border-top:1px solid var(--line)}.workspace-tools[open]{max-height:24vh;overflow:auto}.workspace-tools summary{cursor:pointer;padding:10px;font-size:12px;color:var(--secondary)}.workspace-tools summary:focus-visible{outline:2px solid var(--indigo)}
 .thread-search select{display:block;width:100%;margin-top:6px;padding:8px;border:1px solid var(--line);border-radius:8px;background:var(--paper);color:var(--text);font:inherit}
 .organization-hint{font-size:11px;line-height:1.6;margin:8px 0;color:var(--secondary)}
@@ -1955,21 +1955,21 @@ try{
         if(group!==previousGroup){var heading=document.createElement("h3");heading.className="thread-group-heading";heading.textContent=group;box.appendChild(heading);previousGroup=group}
       }
       var row=document.createElement("div");
       row.className="trow";
       var b=document.createElement("button");
       b.className="item"+(t.id===threadId?" active":"");
       b.innerHTML="<strong>"+esc(title)+"</strong>";
       var details=[t.topic_folder?"分组 · "+t.topic_folder:"",(t.user_tags||[]).map(function(tag){return "#"+tag}).join(" ")].filter(Boolean).join(" · ");
       if(details){var meta=document.createElement("small");meta.textContent=details;b.appendChild(meta)}
       b.onclick=function(){closeThreadMetadata();selectThread(t.id)};
-      var classify=document.createElement("button");classify.className="icon-mini thread-classify";classify.type="button";classify.textContent="分类";classify.setAttribute("aria-label","分类 · "+title);classify.onclick=function(){openThreadMetadata(t,classify)};
+      var classify=document.createElement("button");classify.className="icon-mini thread-classify";classify.type="button";classify.dataset.threadId=t.id;classify.textContent="分类";classify.setAttribute("aria-label","分类 · "+title);classify.onclick=function(){openThreadMetadata(t,classify)};
       var rn=document.createElement("button");
       rn.className="icon-mini";
       rn.title="重命名";
       rn.setAttribute("aria-label","重命名");
       rn.innerHTML='<svg viewBox="0 0 24 24"><path d="M4 20h4l11-11-4-4L4 16v4z"/></svg>';
       rn.onclick=function(ev){
         ev.stopPropagation();
         var alias=window.prompt("重命名", title);
         if(!alias||!String(alias).trim()) return;
         api("/api/thread?id="+encodeURIComponent(t.id),{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({alias:String(alias).trim()})}).then(function(d){
@@ -2697,20 +2697,21 @@ try{
   });
   $("composeList").style.display="none";
   function releaseLease(){
     if(!threadId) return;
     try{
       var body=new Blob([JSON.stringify({thread_id:threadId})],{type:"application/json"});
       navigator.sendBeacon(url("/api/lease/release"), body);
     }catch(e){}
   }
   window.addEventListener("pagehide", function(){
+    summonerVoice.cancel();
     if(sttLive) stopStt(true);
     if(meetingId){
       try{
         var body=new Blob([JSON.stringify({id:meetingId})],{type:"application/json"});
         navigator.sendBeacon(url("/api/meeting/end"), body);
       }catch(e){}
     }
     releaseLease();
   });
   function statusFromEvent(d){
diff --git a/companion/src/summoner/thread-management.ts b/companion/src/summoner/thread-management.ts
index 8de40a19..7ad394aa 100644
--- a/companion/src/summoner/thread-management.ts
+++ b/companion/src/summoner/thread-management.ts
@@ -40,17 +40,18 @@ export const SUMMONER_THREAD_MANAGEMENT_JS = String.raw`
     if(tags.length>20||tags.some(function(tag){return tag.length>40})){$("metadataError").textContent="最多 20 个标签，每个不超过 40 字";return}
     var folder=$("metadataFolder").value.normalize("NFC").replace(/[\x00-\x1f\x7f\\/]/g,"").trim()||null;
     var updates={user_tags:tags,topic_folder:folder};
     metadataSaving=true;$("metadataSave").disabled=true;$("metadataCancel").disabled=true;$("metadataTags").disabled=true;$("metadataFolder").disabled=true;$("metadataSave").textContent="保存中…";$("metadataError").textContent="";
     api("/api/thread?id="+encodeURIComponent(owner),{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(updates)}).then(function(d){
       if(!d||d.type!=="thread.updated"||!d.thread||d.thread.id!==owner)throw new Error(d&&d.error||"未收到分类保存确认");
       var saved=d.thread;
       if(JSON.stringify(metadataTags((saved.user_tags||[]).join(",")).map(function(t){return t.toLowerCase()}).sort())!==JSON.stringify(tags.map(function(t){return t.toLowerCase()}).sort())||(saved.topic_folder||null)!==folder)throw new Error("服务端未保存所提交的分类，请更新 Companion 后重试");
       threads=threads.map(function(t){return t.id===owner?Object.assign({},t,saved):t});
       renderThreads();$("threadMetadata").hidden=true;editingMetadata=null;
-      var next=document.querySelector('#threads .thread-classify');if(next)next.focus();
+      var next=Array.from(document.querySelectorAll("#threads .thread-classify")).find(function(button){return button.dataset.threadId===owner});
+      (next||$("threadSearch")).focus();
       setStatus("分类已保存");
     }).catch(function(err){$("metadataError").textContent=err&&err.message||"分类保存失败"}).finally(function(){
       metadataSaving=false;$("metadataSave").disabled=false;$("metadataCancel").disabled=false;$("metadataTags").disabled=false;$("metadataFolder").disabled=false;$("metadataSave").textContent="保存";
     });
   };
 `
diff --git a/companion/src/summoner/voice-input.ts b/companion/src/summoner/voice-input.ts
index 04d4705a..b8da7196 100644
--- a/companion/src/summoner/voice-input.ts
+++ b/companion/src/summoner/voice-input.ts
@@ -1,21 +1,21 @@
 /** Browser-side dictation controller. Kept separate from meeting capture and navigation. */
 export const SUMMONER_DICTATION_JS = String.raw`
 function createSummonerDictation(o){
   var current=null,acks={},pendingEngine=null,serial=0;
   var status=document.createElement("div");
   status.id="voiceStatus";status.className="voice-status";status.hidden=true;
   status.setAttribute("role","status");status.setAttribute("aria-live","polite");
   status.style.cssText="font-size:12px;line-height:1.5;padding:6px 12px;white-space:pre-wrap";
   o.mic.parentNode.parentNode.appendChild(status);
   function say(text){status.textContent=text||"";status.hidden=!text}
-  function post(path,body){return o.api(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)})}
+  function post(path,body,keepalive){return o.api(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),keepalive:keepalive===true})}
   function checked(d){
     if(!d||d.error||d.type==="error"||d.type==="voice.stt.error"){
       var e=new Error(d&&(d.message||d.error)||"听写服务未返回结果");e.code=d&&(d.code||d.error_code);throw e;
     }
     return d;
   }
   function live(s){return current===s && s.owner===o.threadId() && !s.cancelled}
   function mic(on){o.mic.setAttribute("aria-pressed",on?"true":"false");o.mic.title=on?"停止听写":"听写"}
   function cleanup(s,keepOwner){
     clearTimeout(s.timer);clearTimeout(s.startTimer);if(!keepOwner)clearInterval(s.ownerTimer);clearTimeout(s.partialTimer);
@@ -38,21 +38,21 @@ function createSummonerDictation(o){
     if(c==="engine_not_local")return "听写引擎配置已变化，请重新开始听写";
     if(c==="network")return "浏览器语音服务连接失败，请检查网络或在 Chrome 侧栏设置 → 输入与语音中选择本机听写";
     if(c==="no-speech"||c==="empty_result")return "没有识别到语音，请重试";
     return e&&e.message||"听写失败，请重试";
   }
   function cancel(s){
     s=s||current;if(!s||s.cancelled)return;
     s.cancelled=true;cleanup(s);if(current===s)current=null;
     if(s.rec){try{s.rec.abort()}catch(e){}}
     // Queue abort after any start/chunk already in flight so delayed start cannot leak a session.
-    s.queue.catch(function(){}).then(function(){if(s.started)return post("/api/stt/abort",{sessionId:s.sid})}).catch(function(){});
+    s.queue.catch(function(){}).then(function(){if(s.started)return post("/api/stt/abort",{sessionId:s.sid},true)}).catch(function(){});
     say("已取消听写");
   }
   function fail(s,e){if(current!==s||s.cancelled)return;cancel(s);say(copyError(e))}
   function applyEvent(d){
     var s=current;if(!s||!d||d.sessionId!==s.sid)return false;
     if(!live(s)){cancel(s);return true}
     if(d.type==="voice.stt.error"){fail(s,{code:d.code||d.error_code,message:d.message||d.error});return true}
     // The final HTTP response is authoritative; an SSE duplicate cannot commit twice.
     if(d.type==="voice.stt.partial" && d.status==="hypothesis" && !s.stopping && d.text)say("正在听写… "+d.text);
     return true;
diff --git a/companion/src/threads/metadata-patch.ts b/companion/src/threads/metadata-patch.ts
index 62bb97bd..52f502e1 100644
--- a/companion/src/threads/metadata-patch.ts
+++ b/companion/src/threads/metadata-patch.ts
@@ -5,21 +5,21 @@ import { sanitizeTopicFolder } from "./distill"
 export function summonerThreadMetadata(body: unknown): Record<string, unknown> {
   if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("分类必须是对象")
   const fields = body as Record<string, unknown>
   const keys = Object.keys(fields)
   if (!keys.length || keys.some(key => !["alias", "user_tags", "topic_folder"].includes(key))) {
     throw new Error("仅支持修改名称、人工标签和手动分组")
   }
   const result: Record<string, unknown> = {}
   if ("alias" in fields) {
     if (typeof fields.alias !== "string" || !fields.alias.trim()) throw new Error("名称不能为空")
-    const alias = fields.alias.replace(/[\x00-\x1f\x7f]/g, "").trim().slice(0, 200)
+    const alias = fields.alias.normalize("NFC").replace(/[\x00-\x1f\x7f]/g, "").trim().slice(0, 200)
     if (!alias) throw new Error("名称不能为空")
     result.alias = alias
   }
   if ("user_tags" in fields) result.user_tags = sanitizeUserTags(fields.user_tags)
   if ("topic_folder" in fields) {
     if (fields.topic_folder !== null && typeof fields.topic_folder !== "string") throw new Error("分组必须是名称或空值")
     result.topic_folder = sanitizeTopicFolder(fields.topic_folder)
   }
   return result
 }
diff --git a/companion/tests/acp-handlers-gates.test.ts b/companion/tests/acp-handlers-gates.test.ts
index f72f2852..4cadc4f5 100644
--- a/companion/tests/acp-handlers-gates.test.ts
+++ b/companion/tests/acp-handlers-gates.test.ts
@@ -411,32 +411,51 @@ describe("acp manager protocol argv wiring", () => {
       }, { requestConfirmation: async () => { confirmations++; return { approved: false } as any } })
       assert.equal(ownedApply.type, "acp.apply_diff.denied")
       assert.equal(ownedApply.thread_id, "owner-a")
       assert.equal(confirmations, 1, "correct owner reaches the unchanged confirmation gate")
       const malformed = await handleAcpWsMessage("acp.session.cancel", { session_id: proposed.session.session_id, thread_id: "" }, {})
       assert.equal(malformed.type, "error")
       const nullOwner = await handleAcpWsMessage("acp.session.cancel", { session_id: proposed.session.session_id, thread_id: null }, {})
       assert.equal(nullOwner.type, "error")
       const parentFallback = await handleAcpWsMessage("acp.session.followup", { session_id: "", parent_session_id: proposed.session.session_id, thread_id: "other-b", goal: "do not run" }, {})
       assert.match(parentFallback.error, /does not belong/)
+      const legacyStart = await handleAcpWsMessage("acp.ui_start", {
+        agent_id: "echo", goal: "legacy context owner", workspace_root: dir, cloud_disclosure_accepted: true,
+      }, { threadId: "legacy-start-owner", requestConfirmation: async () => ({ approved: false } as any) })
+      assert.equal(legacyStart.type, "acp.ui_start.denied")
+      assert.equal(legacyStart.thread_id, "legacy-start-owner")
+      assert.equal(mgr.getSession(legacyStart.session_id)?.thread_id, "legacy-start-owner")
       // Existing callers without thread_id still operate on the stored owner.
       const legacyCancel = await handleAcpWsMessage("acp.session.cancel", { session_id: proposed.session.session_id }, {})
       assert.equal(legacyCancel.type, "acp.session.cancel.ack")
       assert.equal(legacyCancel.thread_id, "owner-a")
       assert.equal(legacyCancel.session_id, proposed.session.session_id)
     } finally {
       fs.rmSync(dir, { recursive: true, force: true })
     }
   })
 
   it("#483 pre-session start errors carry the explicitly requested thread; missing prompt session is not invented", async () => {
     const start = await handleAcpWsMessage("acp.ui_start", { thread_id: "owner-a", agent_id: "echo", goal: "review", cloud_disclosure_accepted: true }, {})
     assert.equal(start.type, "error")
     assert.equal(start.thread_id, "owner-a")
     assert.equal(start.family, "acp")
+    const legacyStart = await handleAcpWsMessage("acp.ui_start", { agent_id: "echo", goal: "review" }, { threadId: "legacy-owner-a" })
+    assert.equal(legacyStart.type, "error")
+    assert.match(legacyStart.error, /cloud_disclosure_accepted/)
+    assert.equal(legacyStart.session_id, undefined)
+    assert.equal(legacyStart.thread_id, "legacy-owner-a")
+    const explicitStart = await handleAcpWsMessage("acp.ui_start", { thread_id: "explicit-owner-b", agent_id: "echo", goal: "review" }, { threadId: "legacy-owner-a" })
+    assert.equal(explicitStart.thread_id, "explicit-owner-b")
+    for (const invalid of ["", "  ", null, 123]) {
+      const rejected = await handleAcpWsMessage("acp.ui_start", { thread_id: invalid, agent_id: "echo", goal: "review" }, { threadId: "legacy-owner-a" })
+      assert.equal(rejected.type, "error")
+      assert.match(rejected.error, /thread_id required/)
+      assert.equal(rejected.thread_id, undefined, "invalid explicit owner must not borrow context owner")
+    }
     const prompt = await handleAcpWsMessage("acp.session.prompt", { session_id: "absent", text: "continue" }, { threadId: "foreground-b" })
     assert.equal(prompt.type, "error")
     assert.equal(prompt.session_id, "absent")
     assert.equal(prompt.thread_id, undefined)
   })
 
 })
diff --git a/companion/tests/summoner-thread-metadata-481.test.ts b/companion/tests/summoner-thread-metadata-481.test.ts
index 4513f194..af34e0c7 100644
--- a/companion/tests/summoner-thread-metadata-481.test.ts
+++ b/companion/tests/summoner-thread-metadata-481.test.ts
@@ -1,18 +1,19 @@
 import test from "node:test"
 import assert from "node:assert/strict"
 import { summonerThreadMetadata } from "../src/threads/metadata-patch"
 import { applySummonerPayloadPolicy } from "../src/ws/summoner-acl"
 
 test("HTTP and summoner WS share an exact metadata boundary", () => {
   const input = { alias: "  回顾\u0000  ", user_tags: ["Review", "review", "支付"], topic_folder: "收入/支付" }
   const expected = { alias: "回顾", user_tags: ["Review", "支付"], topic_folder: "收入支付" }
+  assert.deepEqual(summonerThreadMetadata({ alias: "e\u0301" }), { alias: "é" })
   assert.deepEqual(summonerThreadMetadata(input), expected)
   const msg: Record<string, unknown> = { type: "thread.update", thread_id: "t1", updates: input }
   assert.deepEqual(applySummonerPayloadPolicy("summoner", msg), { ok: true })
   assert.deepEqual(msg.updates, expected)
   assert.deepEqual(summonerThreadMetadata({ user_tags: [], topic_folder: null }), { user_tags: [], topic_folder: null })
 })
 
 test("metadata cannot carry policy, project, path or model changes even with a valid alias", () => {
   for (const key of ["workspace_root", "project_id", "config_override", "tool_whitelist", "active_skill_ids", "execution_policy", "digest", "__proto__", "constructor"]) {
     const input = JSON.parse(JSON.stringify({ alias: "safe", [key]: "unsafe" }))
diff --git a/companion/tests/summoner-voice-input.test.ts b/companion/tests/summoner-voice-input.test.ts
index 0767a54a..6f33a5a8 100644
--- a/companion/tests/summoner-voice-input.test.ts
+++ b/companion/tests/summoner-voice-input.test.ts
@@ -2,20 +2,22 @@ import test from "node:test"
 import assert from "node:assert/strict"
 import vm from "node:vm"
 import { SUMMONER_DICTATION_JS, summonerVoiceRequestTimeout } from "../src/summoner/voice-input"
 
 const settle = async () => { for (let i = 0; i < 20; i++) await Promise.resolve() }
 function deferred<T>() { let resolve!: (v: T) => void; const promise = new Promise<T>((r) => { resolve = r }); return { promise, resolve } }
 
 function fixture(engine = "local", response?: (path: string, data: any) => unknown) {
   const requests: { path: string; data: any }[] = []
   const elements: any[] = []
+  const timers = new Map<number, { fn: () => void; delay: number }>()
+  let timerId = 0
   let owner = "thread-a", stopped = 0, processor: any, recognition: any
   const parent = { appendChild: (el: any) => elements.push(el) }
   const mic = { parentNode: { parentNode: parent }, setAttribute() {} }
   const input = { value: "原草稿", dispatchEvent() {} }
   const stream = { getTracks: () => [{ stop: () => { stopped++ } }] }
   const node = () => ({ connect() {}, disconnect() {} })
   class AudioContext {
     state = "running"; sampleRate = 16000
     createMediaStreamSource() { return node() }
     createScriptProcessor() { processor = { ...node(), onaudioprocess: null }; return processor }
@@ -26,36 +28,42 @@ function fixture(engine = "local", response?: (path: string, data: any) => unkno
     onstart?: () => void; onresult?: (e: any) => void; onend?: () => void
     constructor() { recognition = this }
     start() { queueMicrotask(() => this.onstart?.()) }
     stop() { queueMicrotask(() => this.onend?.()) }
     abort() {}
   }
   const context = vm.createContext({
     window: { AudioContext, SpeechRecognition }, navigator: { mediaDevices: { getUserMedia: async () => stream } },
     document: { createElement: () => ({ style: {}, setAttribute() {} }) },
     Event: class {}, btoa: (v: string) => Buffer.from(v, "binary").toString("base64"),
-    setTimeout, clearTimeout, setInterval, clearInterval, Promise, Uint8Array, DataView,
+    setTimeout: (fn: () => void, delay: number) => { const id = ++timerId; timers.set(id, { fn, delay }); return id },
+    clearTimeout: (id: number) => timers.delete(id), setInterval: () => ++timerId, clearInterval() {}, Promise, Uint8Array, DataView,
   })
   vm.runInContext(SUMMONER_DICTATION_JS, context)
   const controller = context.createSummonerDictation({
     mic, input, threadId: () => owner, blocked: () => false, privacy() {},
     api: async (path: string, opts: any) => {
       const data = opts?.body ? JSON.parse(opts.body) : undefined; requests.push({ path, data })
       if (path === "/api/voice-settings") return { sttEngine: engine, localModelId: "medium", lang: "zh-CN" }
       if (response) { const value = response(path, data); if (value !== undefined) return value }
       if (path === "/api/stt/end") return { type: "voice.stt.result", sessionId: data.sessionId, text: "识别结果" }
       return { type: "ok" }
     },
   })
   return {
     controller, requests, input, elements, get stopped() { return stopped }, get recognition() { return recognition },
     owner: (v: string) => { owner = v },
+    fireTimer: (delay: number) => {
+      const item = [...timers.entries()].find(([, value]) => value.delay === delay)
+      if (!item) return false
+      timers.delete(item[0]); item[1].fn(); return true
+    },
     audio: () => processor.onaudioprocess?.({ inputBuffer: { getChannelData: () => new Float32Array(16000) } }),
     start: async () => { controller.toggle(); await settle(); controller.ack(); await settle() },
   }
 }
 
 test("#482 browser engine uses browser recognition, previews immediately and never posts local STT", async () => {
   const f = fixture("browser"); await f.start()
   try {
     assert.match(f.elements[0].textContent, /正在听写/)
     f.recognition.onresult({ resultIndex: 0, results: [{ 0: { transcript: "即时预览" }, isFinal: false }] })
@@ -115,10 +123,40 @@ test("#482 upload failures stop capture and never call end or commit partial tex
   assert.match(f.elements[0].textContent, /连接已断开/)
   assert.equal(f.requests.some((r) => r.path === "/api/stt/end"), false)
   assert.equal(f.input.value, "原草稿")
 })
 
 test("#482 voice final / partial transport deadlines cover the inference budgets", () => {
   assert.ok(summonerVoiceRequestTimeout("voice.stt.end")! > 300_000)
   assert.ok(summonerVoiceRequestTimeout("voice.stt.partial_request")! > 25_000)
   assert.equal(summonerVoiceRequestTimeout("thread.list"), undefined)
 })
+
+test("#482 pending partial cannot delay end or commit a duplicate SSE / HTTP final", async () => {
+  const partial = deferred<any>(), end = deferred<any>()
+  const f = fixture("local", (path) => path === "/api/stt/partial" ? partial.promise : path === "/api/stt/end" ? end.promise : undefined)
+  await f.start(); f.audio(); await settle()
+  assert.equal(f.fireTimer(1400), true); await settle()
+  assert.equal(f.requests.filter((r) => r.path === "/api/stt/partial").length, 1)
+  f.controller.toggle(); await settle()
+  // The partial is unresolved: reaching end proves it is outside the upload queue.
+  assert.equal(f.requests.filter((r) => r.path === "/api/stt/end").length, 1)
+  const sid = f.requests.find((r) => r.path === "/api/stt/start")!.data.sessionId
+  assert.equal(f.controller.onEvent({ type: "voice.stt.result", sessionId: sid, text: "重复最终结果" }), true)
+  assert.equal(f.input.value, "原草稿")
+  // Even a malformed engine returning a final to the partial endpoint cannot commit.
+  partial.resolve({ type: "voice.stt.result", sessionId: sid, text: "重复最终结果" }); await settle()
+  assert.equal(f.input.value, "原草稿")
+  end.resolve({ type: "voice.stt.result", sessionId: sid, text: "唯一最终结果" }); await settle()
+  assert.equal(f.input.value, "原草稿 唯一最终结果")
+  assert.equal(f.controller.active(), false)
+  assert.equal(f.fireTimer(1400), false)
+  f.controller.onEvent({ type: "voice.stt.result", sessionId: sid, text: "重复最终结果" })
+  assert.equal(f.input.value, "原草稿 唯一最终结果")
+})
+
+test("#482 stopping cancels a scheduled partial before it can issue another decode", async () => {
+  const f = fixture(); await f.start(); f.audio(); f.controller.toggle(); await settle()
+  assert.equal(f.fireTimer(1400), false)
+  assert.equal(f.requests.some((r) => r.path === "/api/stt/partial"), false)
+  assert.equal(f.input.value, "原草稿 识别结果")
+})
diff --git a/companion/tests/summoner-web.test.ts b/companion/tests/summoner-web.test.ts
index 1269515d..965f15c3 100644
--- a/companion/tests/summoner-web.test.ts
+++ b/companion/tests/summoner-web.test.ts
@@ -1421,20 +1421,53 @@ describe("summoner-web server", { concurrency: 1 }, () => {
       abortN,
       "second hide must not abort STT again",
     )
     assert.equal(
       seen.filter((m) => m.type === "meeting.end").length,
       endN,
       "second hide must not end meeting again",
     )
   })
 
+  test("#482 STT tracker is cleanup state: JSON errors clear it, thrown end retains fallback abort", async () => {
+    for (const mode of ["json-error", "throw"] as const) {
+      const seen: Record<string, unknown>[] = []
+      await startSummonerWebServer({
+        preferredPort: 23510,
+        dispatch: async (msg) => {
+          seen.push(msg)
+          if (msg.type === "voice.stt.end") {
+            if (mode === "throw") throw new Error("synthetic transport timeout")
+            return { type: "voice.stt.error", sessionId: msg.sessionId, code: "session_unknown", message: "no matching session" }
+          }
+          return { type: "ok" }
+        },
+      })
+      const post = (route: string, body: Record<string, unknown>) => request({
+        method: "POST", port, path: `${route}?token=${token}`,
+        headers: { "Content-Type": "application/json", Origin: `http://127.0.0.1:${port}` },
+        body: JSON.stringify(body),
+      })
+      await post("/api/stt/start", { sessionId: "cleanup-old", modelId: "medium" })
+      const ended = await post("/api/stt/end", { sessionId: "cleanup-old", totalSeq: 0 })
+      assert.equal(ended.status, mode === "throw" ? 500 : 200)
+      hideSummonerWebShell()
+      await Promise.resolve()
+      assert.equal(seen.filter((m) => m.type === "voice.stt.abort" && m.sessionId === "cleanup-old").length, mode === "throw" ? 1 : 0)
+      // The tracker never gates a subsequent start; it adopts the new cleanup target.
+      assert.equal((await post("/api/stt/start", { sessionId: "cleanup-new", modelId: "medium" })).status, 200)
+      hideSummonerWebShell()
+      await Promise.resolve()
+      assert.equal(seen.filter((m) => m.type === "voice.stt.abort" && m.sessionId === "cleanup-new").length, 1)
+    }
+  })
+
   test("SSE reconnect during grace cancels the pending shell close", async () => {
     let n = 0
     await startSummonerWebServer({
       preferredPort: 23510,
       dispatch: async (msg) => ({ type: "ok", echo: msg.type }),
       onShellClosed: () => {
         n += 1
       },
     })
     const openSse = (): Promise<http.ClientRequest> =>
diff --git a/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md b/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
index 086b6e41..77ebca9d 100644
--- a/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
+++ b/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
@@ -61,20 +61,21 @@ session，再更新它自己的字段；不同 session 不继承目标、目录
 展开；其他对话后台任务在侧栏活动入口显示并跳回所属对话；完成结果放消息卡。此方向
 不是本批交付，也不能另造 Agent、确认队列或绕过 #476 原生能力门禁。
 
 ## 4. 语音状态与性能证据
 
 区分“准备麦克风/模型”“正在听写”“正在识别最后一段”“失败”。点击后在异步准备
 完成前显示反馈，capture 就绪后才能显示正在听写。权限、模型缺失、服务断开分别
 给当前设置分类的恢复路径，不能统统提示“打开麦克风”。停止录音与等待 final 分开。
 部分识别不冒充终稿、不重复拼接。开始时固定草稿/录音归属，切换/新建/取消/隐藏/
 关闭或会议竞争时，旧结果不能写进新草稿。保留隐私确认、会议互斥与音频资源清理。
+切换、新建或关闭窗口会取消当前听写、丢弃尚未提交的语音结果，不自动回填已经离开的对话。
 不因降延迟自动开麦或改用云服务。
 
 记录引擎/模型、冷热启动、请求/capture-ready/first-partial/stop/final 时点。
 同机器/录音前后比较，区分固定等待窗与计算耗时。合成测试证明准备/错误/取消/迟到
 事件反馈；真实麦克风和模型时延另做实测，不能承诺所有硬件都毫秒级 final。本批可机核的通过条件是：点击所在事件轮次出现准备状态；
 合成 final 返回后下一轮状态更新写入所属草稿；录音中支持 partial 预览；正常停止不再使用
 8秒通用请求/12秒取消截止。真实机器 final 性能仍需单独前后测量，不据此关闭性能提升主张。
 
 ## 5. 后续项目实体设计
 

FULL FILE companion/src/summoner/voice-input.ts
/** Browser-side dictation controller. Kept separate from meeting capture and navigation. */
export const SUMMONER_DICTATION_JS = String.raw`
function createSummonerDictation(o){
  var current=null,acks={},pendingEngine=null,serial=0;
  var status=document.createElement("div");
  status.id="voiceStatus";status.className="voice-status";status.hidden=true;
  status.setAttribute("role","status");status.setAttribute("aria-live","polite");
  status.style.cssText="font-size:12px;line-height:1.5;padding:6px 12px;white-space:pre-wrap";
  o.mic.parentNode.parentNode.appendChild(status);
  function say(text){status.textContent=text||"";status.hidden=!text}
  function post(path,body,keepalive){return o.api(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),keepalive:keepalive===true})}
  function checked(d){
    if(!d||d.error||d.type==="error"||d.type==="voice.stt.error"){
      var e=new Error(d&&(d.message||d.error)||"听写服务未返回结果");e.code=d&&(d.code||d.error_code);throw e;
    }
    return d;
  }
  function live(s){return current===s && s.owner===o.threadId() && !s.cancelled}
  function mic(on){o.mic.setAttribute("aria-pressed",on?"true":"false");o.mic.title=on?"停止听写":"听写"}
  function cleanup(s,keepOwner){
    clearTimeout(s.timer);clearTimeout(s.startTimer);if(!keepOwner)clearInterval(s.ownerTimer);clearTimeout(s.partialTimer);
    if(s.proc){s.proc.onaudioprocess=null;try{s.proc.disconnect()}catch(e){}}
    [s.src,s.mute].forEach(function(n){try{if(n)n.disconnect()}catch(e){}});
    if(s.stream)s.stream.getTracks().forEach(function(t){t.stop()});
    if(s.ctx)Promise.resolve(s.ctx.close()).catch(function(){});
    s.stream=s.ctx=s.proc=null;mic(false);
  }
  function finish(s,text){
    if(!live(s)){cancel(s);return}
    var value=String(text||"").trim();
    if(value){var old=o.input.value;o.input.value=old&&old.trim()?old.replace(/\s*$/,"")+" "+value:value;o.input.dispatchEvent(new Event("input",{bubbles:true}))}
    cleanup(s);current=null;s.cancelled=true;say(value?"已填入草稿，请核对后发送":"没有识别到语音，请重试");
  }
  function copyError(e){
    var c=String(e&&e.code||e&&e.name||"");
    if(c==="NotAllowedError"||c==="not-allowed"||c==="service-not-allowed")return "麦克风未获授权，请在 Chrome 网站设置及系统隐私设置中允许麦克风";
    if(c==="model_missing"||c==="binary_missing")return "本机听写组件未就绪，请在 Chrome 侧栏的设置 → 输入与语音中下载组件和模型";
    if(c==="engine_not_local")return "听写引擎配置已变化，请重新开始听写";
    if(c==="network")return "浏览器语音服务连接失败，请检查网络或在 Chrome 侧栏设置 → 输入与语音中选择本机听写";
    if(c==="no-speech"||c==="empty_result")return "没有识别到语音，请重试";
    return e&&e.message||"听写失败，请重试";
  }
  function cancel(s){
    s=s||current;if(!s||s.cancelled)return;
    s.cancelled=true;cleanup(s);if(current===s)current=null;
    if(s.rec){try{s.rec.abort()}catch(e){}}
    // Queue abort after any start/chunk already in flight so delayed start cannot leak a session.
    s.queue.catch(function(){}).then(function(){if(s.started)return post("/api/stt/abort",{sessionId:s.sid},true)}).catch(function(){});
    say("已取消听写");
  }
  function fail(s,e){if(current!==s||s.cancelled)return;cancel(s);say(copyError(e))}
  function applyEvent(d){
    var s=current;if(!s||!d||d.sessionId!==s.sid)return false;
    if(!live(s)){cancel(s);return true}
    if(d.type==="voice.stt.error"){fail(s,{code:d.code||d.error_code,message:d.message||d.error});return true}
    // The final HTTP response is authoritative; an SSE duplicate cannot commit twice.
    if(d.type==="voice.stt.partial" && d.status==="hypothesis" && !s.stopping && d.text)say("正在听写… "+d.text);
    return true;
  }
  function startBrowser(s){
    var C=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!C){fail(s,new Error("此浏览器不支持浏览器听写，请在 Chrome 侧栏设置 → 输入与语音中选择本机听写"));return}
    var rec=new C();s.rec=rec;s.finals=[];rec.lang=s.settings.lang||"zh-CN";rec.continuous=true;rec.interimResults=true;rec.maxAlternatives=1;
    rec.onstart=function(){if(live(s)){clearTimeout(s.startTimer);say("正在听写… 再点麦克风结束");mic(true)}};
    rec.onresult=function(ev){
      if(!live(s))return;
      var interim="";
      for(var i=ev.resultIndex||0;i<ev.results.length;i++){
        var r=ev.results[i],text=r[0]&&r[0].transcript||"";
        if(r.isFinal)s.finals[i]=text;else interim+=text;
      }
      say("正在听写… "+s.finals.join("")+interim);
    };
    rec.onerror=function(e){if(e.error!=="aborted")fail(s,{code:e.error,message:"浏览器听写失败"})};
    rec.onend=function(){if(live(s))finish(s,s.finals.join(""))};
    try{rec.start();s.timer=setTimeout(function(){stop()},45000)}catch(e){fail(s,e)}
  }
  function queueChunk(s,bytes){
    var seq=s.seq++,binary="";for(var i=0;i<bytes.length;i++)binary+=String.fromCharCode(bytes[i]);
    var data=btoa(binary);
    s.queue=s.queue.then(function(){if(!live(s))return;return post("/api/stt/chunk",{sessionId:s.sid,seq:seq,data:data}).then(checked)});
    s.queue.catch(function(e){fail(s,e)});
  }
  function flush(s){if(!s.buf.length)return;var b=s.buf;s.buf=new Uint8Array(0);queueChunk(s,b)}
  function poll(s){
    if(!live(s)||s.stopping||s.settings.sttEngine!=="local"||s.settings.localModelId==="large-v3-turbo")return;
    s.partialTimer=setTimeout(function(){
      if(!live(s)||s.stopping)return;
      // A single outstanding partial; final end is independent and cancels it server-side.
      s.queue.then(function(){if(!live(s)||s.stopping)return;return post("/api/stt/partial",{sessionId:s.sid})}).then(function(d){if(d)applyEvent(d)}).catch(function(){}).finally(function(){poll(s)});
    },1400);
  }
  function startLocal(s){
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){fail(s,new Error("此窗口无法访问麦克风"));return}
    navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}}).then(function(stream){
      if(!live(s)){stream.getTracks().forEach(function(t){t.stop()});return}
      s.stream=stream;var AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw new Error("此窗口无法捕获麦克风音频");
      var ctx=new AC();s.ctx=ctx;
      return Promise.resolve(ctx.state==="suspended"?ctx.resume():undefined).then(function(){
        if(!live(s))return;
        s.queue=post("/api/stt/start",{sessionId:s.sid,modelId:s.settings.localModelId,engine:s.settings.sttEngine,privacy_ack_v2:true,lang:s.settings.lang||"zh-CN",maxMs:45000}).then(function(d){checked(d);s.started=true;return d});
        return s.queue.then(function(){
          if(!live(s))return;
          s.src=ctx.createMediaStreamSource(stream);s.proc=ctx.createScriptProcessor(4096,1,1);s.mute=ctx.createGain();s.mute.gain.value=0;
          s.proc.onaudioprocess=function(ev){
            if(!live(s)||s.stopping)return;
            var input=ev.inputBuffer.getChannelData(0),rate=ctx.sampleRate||48000;
            var n=Math.max(1,Math.round(input.length*16000/rate)),bytes=new Uint8Array(n*2),v=new DataView(bytes.buffer);
            for(var i=0;i<n;i++){var pos=i*rate/16000,a=Math.min(Math.floor(pos),input.length-1),b=Math.min(a+1,input.length-1),f=pos-a;var x=Math.max(-1,Math.min(1,input[a]*(1-f)+input[b]*f));v.setInt16(i*2,Math.round(x<0?x*32768:x*32767),true)}
            var buf=new Uint8Array(s.buf.length+bytes.length);buf.set(s.buf);buf.set(bytes,s.buf.length);s.buf=buf;if(s.buf.length>=32000)flush(s);
          };
          s.src.connect(s.proc);s.proc.connect(s.mute);s.mute.connect(ctx.destination);clearTimeout(s.startTimer);mic(true);say("正在听写… 再点麦克风结束");
          // Finish ahead of the daemon's 45 s recording lease so final upload can drain.
          s.timer=setTimeout(function(){stop()},44000);poll(s);
        });
      });
    }).catch(function(e){fail(s,e)});
  }
  function begin(settings){
    if(current||o.blocked())return;
    var s={sid:"dict-"+Date.now().toString(36)+"-"+(++serial),owner:o.threadId(),settings:settings,queue:Promise.resolve(),buf:new Uint8Array(0),seq:0};
    current=s;mic(true);say("正在请求麦克风…");
    s.ownerTimer=setInterval(function(){if(!live(s))cancel(s)},200);
    // Bound the permission/start phase; permission resolution after cancel is harmless.
    s.startTimer=setTimeout(function(){fail(s,new Error("麦克风启动超时，请检查浏览器权限后重试"))},15000);
    if(settings.sttEngine==="browser")startBrowser(s);else startLocal(s);
  }
  function stop(){
    var s=current;if(!s)return;
    if(s.stopping){cancel(s);return}
    if(s.rec){s.stopping=true;say("正在完成识别…");try{s.rec.stop()}catch(e){fail(s,e)};clearTimeout(s.timer);s.timer=setTimeout(function(){if(live(s))finish(s,s.finals.join(""))},5000);return}
    if(!s.started||!s.proc){cancel(s);return}
    s.stopping=true;flush(s);cleanup(s,true);say("正在识别… 再点麦克风取消");
    s.queue.then(function(){if(!live(s))return;return post("/api/stt/end",{sessionId:s.sid,totalSeq:s.seq})}).then(function(d){if(!live(s)||!d)return;checked(d);if(d.type!=="voice.stt.result")throw new Error("听写服务没有返回识别结果");finish(s,d.text)}).catch(function(e){fail(s,e)});
  }
  var requested=0;
  function toggle(){
    if(current){stop();return}
    if(o.blocked()){say("请先结束会议录音");return}
    var turn=++requested;say("正在准备听写…");
    o.api("/api/voice-settings").then(function(settings){
      if(turn!==requested||current)return;
      checked(settings);if(["browser","local","system"].indexOf(settings.sttEngine)<0)throw new Error("无法读取听写引擎，请重试");
      if(!acks[settings.sttEngine]){pendingEngine=settings;o.privacy(settings.sttEngine);say("");return}
      begin(settings);
    }).catch(function(e){say(copyError(e))});
  }
  return {toggle:toggle,cancel:function(){requested++;pendingEngine=null;cancel()},active:function(){return !!current},onEvent:applyEvent,ack:function(){if(!pendingEngine)return;var settings=pendingEngine;pendingEngine=null;acks[settings.sttEngine]=true;begin(settings)}};
}
`

/** Voice final decode can outlive ordinary metadata requests. */
export function summonerVoiceRequestTimeout(type: string): number | undefined {
  if (type === "voice.stt.end") return 305_000
  if (type === "voice.stt.partial_request") return 30_000
  return undefined
}

FULL FILE companion/tests/summoner-voice-input.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import vm from "node:vm"
import { SUMMONER_DICTATION_JS, summonerVoiceRequestTimeout } from "../src/summoner/voice-input"

const settle = async () => { for (let i = 0; i < 20; i++) await Promise.resolve() }
function deferred<T>() { let resolve!: (v: T) => void; const promise = new Promise<T>((r) => { resolve = r }); return { promise, resolve } }

function fixture(engine = "local", response?: (path: string, data: any) => unknown) {
  const requests: { path: string; data: any }[] = []
  const elements: any[] = []
  const timers = new Map<number, { fn: () => void; delay: number }>()
  let timerId = 0
  let owner = "thread-a", stopped = 0, processor: any, recognition: any
  const parent = { appendChild: (el: any) => elements.push(el) }
  const mic = { parentNode: { parentNode: parent }, setAttribute() {} }
  const input = { value: "原草稿", dispatchEvent() {} }
  const stream = { getTracks: () => [{ stop: () => { stopped++ } }] }
  const node = () => ({ connect() {}, disconnect() {} })
  class AudioContext {
    state = "running"; sampleRate = 16000
    createMediaStreamSource() { return node() }
    createScriptProcessor() { processor = { ...node(), onaudioprocess: null }; return processor }
    createGain() { return { ...node(), gain: { value: 0 } } }
    close() { return Promise.resolve() }
  }
  class SpeechRecognition {
    onstart?: () => void; onresult?: (e: any) => void; onend?: () => void
    constructor() { recognition = this }
    start() { queueMicrotask(() => this.onstart?.()) }
    stop() { queueMicrotask(() => this.onend?.()) }
    abort() {}
  }
  const context = vm.createContext({
    window: { AudioContext, SpeechRecognition }, navigator: { mediaDevices: { getUserMedia: async () => stream } },
    document: { createElement: () => ({ style: {}, setAttribute() {} }) },
    Event: class {}, btoa: (v: string) => Buffer.from(v, "binary").toString("base64"),
    setTimeout: (fn: () => void, delay: number) => { const id = ++timerId; timers.set(id, { fn, delay }); return id },
    clearTimeout: (id: number) => timers.delete(id), setInterval: () => ++timerId, clearInterval() {}, Promise, Uint8Array, DataView,
  })
  vm.runInContext(SUMMONER_DICTATION_JS, context)
  const controller = context.createSummonerDictation({
    mic, input, threadId: () => owner, blocked: () => false, privacy() {},
    api: async (path: string, opts: any) => {
      const data = opts?.body ? JSON.parse(opts.body) : undefined; requests.push({ path, data })
      if (path === "/api/voice-settings") return { sttEngine: engine, localModelId: "medium", lang: "zh-CN" }
      if (response) { const value = response(path, data); if (value !== undefined) return value }
      if (path === "/api/stt/end") return { type: "voice.stt.result", sessionId: data.sessionId, text: "识别结果" }
      return { type: "ok" }
    },
  })
  return {
    controller, requests, input, elements, get stopped() { return stopped }, get recognition() { return recognition },
    owner: (v: string) => { owner = v },
    fireTimer: (delay: number) => {
      const item = [...timers.entries()].find(([, value]) => value.delay === delay)
      if (!item) return false
      timers.delete(item[0]); item[1].fn(); return true
    },
    audio: () => processor.onaudioprocess?.({ inputBuffer: { getChannelData: () => new Float32Array(16000) } }),
    start: async () => { controller.toggle(); await settle(); controller.ack(); await settle() },
  }
}

test("#482 browser engine uses browser recognition, previews immediately and never posts local STT", async () => {
  const f = fixture("browser"); await f.start()
  try {
    assert.match(f.elements[0].textContent, /正在听写/)
    f.recognition.onresult({ resultIndex: 0, results: [{ 0: { transcript: "即时预览" }, isFinal: false }] })
    assert.match(f.elements[0].textContent, /即时预览/)
    assert.equal(f.input.value, "原草稿")
    f.recognition.onresult({ resultIndex: 0, results: [{ 0: { transcript: "最终结果" }, isFinal: true }] })
    f.controller.toggle(); await settle()
    assert.equal(f.input.value, "原草稿 最终结果")
    assert.equal(f.requests.filter((r) => r.path.startsWith("/api/stt/")).length, 0)
  } finally { f.controller.cancel() }
})

test("#482 local HTTP final commits without SSE; chunks finish in sequence before end", async () => {
  const first = deferred<any>()
  const f = fixture("local", (path, data) => path === "/api/stt/chunk" && data.seq === 0 ? first.promise : undefined)
  await f.start()
  try {
    f.audio(); f.audio(); f.controller.toggle(); await settle()
    assert.equal(f.requests.filter((r) => r.path === "/api/stt/chunk").length, 1)
    assert.equal(f.requests.some((r) => r.path === "/api/stt/end"), false)
    assert.match(f.elements[0].textContent, /正在识别/)
    first.resolve({ type: "ok" }); await settle()
    assert.deepEqual(f.requests.filter((r) => r.path.startsWith("/api/stt/")).map((r) => r.path), ["/api/stt/start", "/api/stt/chunk", "/api/stt/chunk", "/api/stt/end"])
    assert.equal(f.requests.find((r) => r.path === "/api/stt/end")?.data.totalSeq, 2)
    assert.equal(f.input.value, "原草稿 识别结果")
    const sid = f.requests.find((r) => r.path === "/api/stt/start")?.data.sessionId
    assert.equal(f.controller.onEvent({ type: "voice.stt.result", sessionId: sid, text: "重复" }), false)
    assert.equal(f.input.value, "原草稿 识别结果")
    assert.ok(f.stopped > 0)
  } finally { f.controller.cancel() }
})

test("#482 a delayed result cannot enter another thread or a cancelled dictation", async () => {
  for (const cancel of [false, true]) {
    const end = deferred<any>()
    const f = fixture("local", (path) => path === "/api/stt/end" ? end.promise : undefined)
    await f.start(); f.audio(); f.controller.toggle(); await settle()
    if (cancel) f.controller.cancel(); else f.owner("thread-b")
    end.resolve({ type: "voice.stt.result", text: "旧会话结果" }); await settle()
    assert.equal(f.input.value, "原草稿"); f.controller.cancel()
  }
})

test("#482 cancel while start is pending releases mic and aborts after start acknowledgement", async () => {
  const start = deferred<any>()
  const f = fixture("local", (path) => path === "/api/stt/start" ? start.promise : undefined)
  await f.start(); f.controller.cancel(); start.resolve({ type: "ok" }); await settle()
  assert.ok(f.stopped > 0)
  assert.deepEqual(f.requests.filter((r) => r.path.startsWith("/api/stt/")).map((r) => r.path), ["/api/stt/start", "/api/stt/abort"])
  assert.equal(f.controller.active(), false)
})

test("#482 upload failures stop capture and never call end or commit partial text", async () => {
  const f = fixture("local", (path) => path === "/api/stt/chunk" ? { type: "error", error: "连接已断开" } : undefined)
  await f.start(); f.audio(); await settle()
  assert.equal(f.controller.active(), false); assert.ok(f.stopped > 0)
  assert.match(f.elements[0].textContent, /连接已断开/)
  assert.equal(f.requests.some((r) => r.path === "/api/stt/end"), false)
  assert.equal(f.input.value, "原草稿")
})

test("#482 voice final / partial transport deadlines cover the inference budgets", () => {
  assert.ok(summonerVoiceRequestTimeout("voice.stt.end")! > 300_000)
  assert.ok(summonerVoiceRequestTimeout("voice.stt.partial_request")! > 25_000)
  assert.equal(summonerVoiceRequestTimeout("thread.list"), undefined)
})

test("#482 pending partial cannot delay end or commit a duplicate SSE / HTTP final", async () => {
  const partial = deferred<any>(), end = deferred<any>()
  const f = fixture("local", (path) => path === "/api/stt/partial" ? partial.promise : path === "/api/stt/end" ? end.promise : undefined)
  await f.start(); f.audio(); await settle()
  assert.equal(f.fireTimer(1400), true); await settle()
  assert.equal(f.requests.filter((r) => r.path === "/api/stt/partial").length, 1)
  f.controller.toggle(); await settle()
  // The partial is unresolved: reaching end proves it is outside the upload queue.
  assert.equal(f.requests.filter((r) => r.path === "/api/stt/end").length, 1)
  const sid = f.requests.find((r) => r.path === "/api/stt/start")!.data.sessionId
  assert.equal(f.controller.onEvent({ type: "voice.stt.result", sessionId: sid, text: "重复最终结果" }), true)
  assert.equal(f.input.value, "原草稿")
  // Even a malformed engine returning a final to the partial endpoint cannot commit.
  partial.resolve({ type: "voice.stt.result", sessionId: sid, text: "重复最终结果" }); await settle()
  assert.equal(f.input.value, "原草稿")
  end.resolve({ type: "voice.stt.result", sessionId: sid, text: "唯一最终结果" }); await settle()
  assert.equal(f.input.value, "原草稿 唯一最终结果")
  assert.equal(f.controller.active(), false)
  assert.equal(f.fireTimer(1400), false)
  f.controller.onEvent({ type: "voice.stt.result", sessionId: sid, text: "重复最终结果" })
  assert.equal(f.input.value, "原草稿 唯一最终结果")
})

test("#482 stopping cancels a scheduled partial before it can issue another decode", async () => {
  const f = fixture(); await f.start(); f.audio(); f.controller.toggle(); await settle()
  assert.equal(f.fireTimer(1400), false)
  assert.equal(f.requests.some((r) => r.path === "/api/stt/partial"), false)
  assert.equal(f.input.value, "原草稿 识别结果")
})

FULL FILE companion/scripts/test-summoner-voice-ui.py
"""#482: execute the real summoner HTML with synthetic microphone/recognizer/HTTP.

No microphone permission, audio files, model service, or installed app are touched.
Run after nvm use 22: uv run --no-project --with playwright python scripts/test-summoner-voice-ui.py
"""
from pathlib import Path
from urllib.parse import urlparse
import json
import subprocess
import tempfile
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent.parent
bootstrap = """
window.EventSource=class {constructor(){window.fixtureEvents=this} addEventListener(){} close(){}};
window.resizeTo=()=>{};window.moveTo=()=>{};
const fixtureSetTimeout=window.setTimeout.bind(window);
window.fixturePartialTimers=[];
window.setTimeout=(fn,ms,...args)=>{
  if(ms===1400){const id=fixtureSetTimeout(()=>{},999999);window.fixturePartialTimers.push({id,fn});return id}
  return fixtureSetTimeout(fn,ms,...args);
};
window.fixtureFirePartial=()=>{const item=window.fixturePartialTimers.shift();clearTimeout(item.id);item.fn()};
window.SpeechRecognition=class {
  constructor(){window.fixtureRecognition=this}
  start(){queueMicrotask(()=>this.onstart?.())}
  stop(){queueMicrotask(()=>this.onend?.())}
  abort(){}
};
Object.defineProperty(navigator,'mediaDevices',{value:{getUserMedia:async()=>({getTracks:()=>[{stop(){window.fixtureStopped=true}}]})}});
window.AudioContext=class {
  state='running';sampleRate=16000;
  createMediaStreamSource(){return {connect(){},disconnect(){}}}
  createScriptProcessor(){return window.fixtureProcessor={connect(){},disconnect(){}}}
  createGain(){return {gain:{value:0},connect(){},disconnect(){}}}
  close(){return Promise.resolve()}
};
"""
with tempfile.TemporaryDirectory() as out:
    subprocess.run(['node', 'scripts/render-web-surface-fixtures.cjs', out], cwd=root, check=True)
    html = (Path(out) / 'capture.html').read_text().replace('%%CRUISE_LABEL%%', '每次确认')
    with sync_playwright() as p:
        browser = p.chromium.launch(channel='chrome', headless=True)
        for engine, scenario in [('browser', 'normal'), ('local', 'normal'), ('system', 'normal'), ('local', 'pending-partial'), ('local', 'pagehide')]:
            page = browser.new_page(viewport={'width': 360, 'height': 600})
            page.set_default_timeout(6000)
            page.add_init_script(bootstrap)
            requests, errors, pending_routes = [], [], {}
            page.on('pageerror', lambda error: errors.append(str(error)))
            def route(r):
                path = urlparse(r.request.url).path
                body = r.request.post_data_json if r.request.post_data else {}
                requests.append((path, body))
                if path == '/':
                    r.fulfill(content_type='text/html', body=html)
                    return
                if scenario == 'pending-partial' and path in ['/api/stt/partial', '/api/stt/end']:
                    pending_routes[path] = (r, body)
                    return
                if path == '/api/voice-settings': data = {'sttEngine': engine, 'localModelId': 'medium', 'lang': 'zh-CN'}
                elif path == '/api/threads': data = {'threads': [{'id': 'thread-a', 'alias': '语音验收'}]}
                elif path == '/api/thread': data = {'messages': [], 'run_status': 'idle'}
                elif path == '/api/stt/end': data = {'type': 'voice.stt.result', 'sessionId': body['sessionId'], 'text': '本机识别结果'}
                else: data = {'type': 'ok'}
                r.fulfill(content_type='application/json', body=json.dumps(data))
            page.route('http://voice.fixture/**', route)
            page.goto('http://voice.fixture/')
            page.locator('#mic').click()
            page.locator('#voicePrivacyAck').click()
            page.wait_for_function('document.querySelector("#voiceStatus").textContent.includes("正在听写")')
            if engine == 'browser':
                page.evaluate('window.fixtureRecognition.onresult({resultIndex:0,results:[{0:{transcript:"浏览器结果"},isFinal:true}]})')
            else:
                page.evaluate('window.fixtureProcessor.onaudioprocess({inputBuffer:{getChannelData:()=>new Float32Array(16000)}})')
            if scenario == 'pagehide':
                with page.expect_request('**/api/stt/abort'):
                    page.evaluate('window.dispatchEvent(new PageTransitionEvent("pagehide"))')
                assert page.evaluate('window.fixtureStopped === true')
                assert page.locator('#text').input_value() == ''
                assert not errors, errors
                page.close()
                continue
            if scenario == 'pending-partial':
                with page.expect_request('**/api/stt/partial'):
                    page.evaluate('window.fixtureFirePartial()')
            page.locator('#mic').click()
            if scenario == 'pending-partial':
                # End must reach HTTP while partial remains unresolved.
                page.wait_for_function('document.querySelector("#voiceStatus").textContent.includes("正在识别")')
                page.evaluate('Promise.resolve()')
                assert '/api/stt/end' in pending_routes, 'partial must not block final end'
                end_route, end_body = pending_routes['/api/stt/end']
                sid = end_body['sessionId']
                page.evaluate('(sid)=>window.fixtureEvents.onmessage({data:JSON.stringify({type:"voice.stt.result",sessionId:sid,text:"重复结果"})})', sid)
                assert page.locator('#text').input_value() == ''
                partial_route, _ = pending_routes['/api/stt/partial']
                partial_route.fulfill(content_type='application/json', body=json.dumps({'type': 'voice.stt.result', 'sessionId': sid, 'text': '重复结果'}))
                end_route.fulfill(content_type='application/json', body=json.dumps({'type': 'voice.stt.result', 'sessionId': sid, 'text': '唯一结果'}))
            page.wait_for_function('document.querySelector("#text").value.includes("结果")')
            if scenario == 'pending-partial':
                assert page.locator('#text').input_value() == '唯一结果'
                page.evaluate('(sid)=>window.fixtureEvents.onmessage({data:JSON.stringify({type:"voice.stt.result",sessionId:sid,text:"重复结果"})})', sid)
                assert page.locator('#text').input_value() == '唯一结果'
            assert not errors, errors
            if engine == 'browser':
                assert not any(path.startswith('/api/stt/') for path, _ in requests)
            else:
                actual = [(path, body) for path, body in requests if path in ['/api/stt/start', '/api/stt/chunk', '/api/stt/end']]
                assert [path for path, _ in actual] == ['/api/stt/start', '/api/stt/chunk', '/api/stt/end'], actual
                assert actual[0][1]['engine'] == engine
                assert actual[-1][1]['totalSeq'] == 1
                assert page.evaluate('window.fixtureStopped === true')
            assert page.locator('#voiceStatus').is_visible()
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
            page.close()
        browser.close()
print('PASS: real summoner HTML; browser/local/system selection, privacy action, visible recording state, ordered HTTP upload; pending partial does not block end; duplicate SSE/partial finals never commit; final HTTP commits once; pagehide cancels microphone/session. Synthetic capture only.')

FULL FILE chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
/**
 * Path B — local STT adapter (gUM → WAV/PCM chunks → voice.stt.* WS).
 * classic: one shot ≤45s then onEnd.
 * continuous (D1c): serial segments ≤45s until hard cap or user stop.
 * continuous + streamPartial (M2): PCM stream + partial_request progressive hypothesis.
 */

import {
  LOCAL_STT_CHANNELS,
  LOCAL_STT_MAX_CHUNK_RAW_BYTES,
  LOCAL_STT_MAX_RECORD_MS,
  LOCAL_STT_NEAR_REALTIME_SEGMENT_MS,
  LOCAL_STT_SAMPLE_RATE,
} from "./local-stt-detect"
import { splitIntoChunks } from "./pcm-encode"
import {
  startCapture as defaultStartCapture,
  type CaptureHandle,
  type StartCaptureOpts,
} from "./audio-capture"
import {
  startPcmStreamCapture as defaultStartPcmStreamCapture,
  type PcmStreamCaptureOpts,
  type PcmStreamHandle,
} from "./pcm-stream-capture"
import {
  nextPartialPollMs,
  STREAM_PARTIAL_POLL_DEFAULT_MS,
} from "./stream-partial-poll"
import type {
  SpeechAdapter,
  SpeechAdapterHandlers,
  SpeechAdapterStartArg,
} from "./web-speech-adapter"
import {
  VOICE_CONTINUOUS_HARD_CAP_MS,
  VOICE_DEFAULT_LANG,
  type VoiceDictationMode,
} from "./detect"

export type LocalSttSend = (msg: Record<string, unknown>) => void

/** Subscribe to inbound companion messages; returns unsubscribe. */
export type LocalSttOnMessage = (handler: (msg: any) => void) => () => void

export type LocalSttAdapterDeps = {
  send: LocalSttSend
  onMessage: LocalSttOnMessage
  /**
   * Whisper model id. #259: optional for engineKind "system" (Windows SAPI
   * sessions carry no whisper model on the wire).
   */
  modelId?: string
  /** #259: "system" stamps voice.stt.start engine:"system" (per-session SAPI). */
  engineKind?: "local" | "system"
  startCapture?: (opts?: StartCaptureOpts) => Promise<CaptureHandle>
  startPcmStreamCapture?: (opts: PcmStreamCaptureOpts) => Promise<PcmStreamHandle>
  /**
   * Wall timeout waiting for voice.stt.result/error after end().
   * Companion infer cap is 90s; default a hair over that so a live infer can finish.
   */
  pendingTimeoutMs?: number
  /**
   * After user stop(), do not wait the full pendingTimeoutMs — Companion restart
   * mid-window used to leave meeting "正在听" forever because stop() while
   * waiting was a no-op until the missing ACK.
   */
  stopGraceMs?: number
}

/** Client wait for companion infer ACK (server STT_INFER_MAX_MS = 90s). */
export const LOCAL_STT_PENDING_TIMEOUT_MS = 95_000

/** After user stop, give the in-flight window this long then end anyway. */
export const LOCAL_STT_STOP_GRACE_MS = 12_000

/**
 * Soft-continue only for failures after end() when companion has dropBound.
 * NEVER soft-continue session_busy / resource_conflict / oom / binary_broken
 * without reclaiming the slot (adversary B F1/F2 + dual-review: binary_broken is sticky).
 */
export function isSoftSttSegmentError(code: string): boolean {
  const c = (code || "").toLowerCase()
  return (
    c === "infer_failed" ||
    c === "empty_result" ||
    c === "infer_timeout" ||
    c === "partial_skipped"
  )
}

/** Hard stop — do not keep mic open. */
export function isHardSttSegmentError(code: string): boolean {
  const c = (code || "").toLowerCase()
  return (
    c === "oom" ||
    c === "binary_broken" ||
    c === "model_missing" ||
    c === "binary_missing" ||
    c === "hash_fail" ||
    c === "engine_not_local" ||
    c === "need_privacy_ack" ||
    c === "origin_denied" ||
    c === "peer_mismatch"
  )
}

/** uint8 → base64 without Node Buffer (Side Panel / tests). */
export function uint8ToBase64(data: Uint8Array): string {
  const chunkSize = 0x8000
  let binary = ""
  for (let i = 0; i < data.length; i += chunkSize) {
    const slice = data.subarray(i, Math.min(i + chunkSize, data.length))
    binary += String.fromCharCode.apply(null, Array.from(slice) as number[])
  }
  if (typeof btoa === "function") {
    return btoa(binary)
  }
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  let out = ""
  for (let i = 0; i < data.length; i += 3) {
    const a = data[i]
    const b = i + 1 < data.length ? data[i + 1] : 0
    const c = i + 2 < data.length ? data[i + 2] : 0
    const triple = (a << 16) | (b << 8) | c
    out += alphabet[(triple >> 18) & 63]
    out += alphabet[(triple >> 12) & 63]
    out += i + 1 < data.length ? alphabet[(triple >> 6) & 63] : "="
    out += i + 2 < data.length ? alphabet[triple & 63] : "="
  }
  return out
}

type PendingWait = {
  sessionId: string
  resolve: (
    r: { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string },
  ) => void
}

export function createLocalSttAdapter(
  handlers: SpeechAdapterHandlers,
  deps: LocalSttAdapterDeps,
): SpeechAdapter {
  let dead = false
  let capture: CaptureHandle | null = null
  let sessionId: string | null = null
  let modelId = deps.modelId ?? ""
  let unsub: (() => void) | null = null
  let phase: "idle" | "recording" | "uploading" | "waiting" = "idle"
  let aborted = false
  let wantListening = false
  let mode: VoiceDictationMode = "classic"
  let parentSessionId = ""
  let lang = VOICE_DEFAULT_LANG
  let hardCapMs = VOICE_CONTINUOUS_HARD_CAP_MS
  /** Optional per-segment window override (tests); clamped to LOCAL_STT_MAX_RECORD_MS. */
  let segmentCapMs = LOCAL_STT_MAX_RECORD_MS
  let streamPartial = false
  let wallStart = 0
  let segmentIndex = 0
  let pending: PendingWait | null = null
  let pendingTimer: ReturnType<typeof setTimeout> | null = null
  let loopGen = 0
  /** Continuous: resolve when current segment should stop recording. */
  let segmentStopTrigger: (() => void) | null = null
  let segmentTimer: ReturnType<typeof setTimeout> | null = null
  let partialTimer: ReturnType<typeof setTimeout> | null = null
  let pcmStream: PcmStreamHandle | null = null
  let streamSeq = 0
  let streamStable = ""
  let streamPrevHypothesis = ""
  /** Adaptive partial poll (ms); paced by last hypothesis infer time. */
  let partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
  /**
   * N3: soft stop requested while awaiting gUM / before window wait is armed.
   * Checked after each await so we never run a full unintended window.
   */
  let pendingSoftStop = false
  /** Consecutive soft segment failures — hard stop after threshold (adversary B F2). */
  let softFailStreak = 0
  /** Classic: first stop() already started the stop→upload chain; repeat stops are ignored. */
  let stopChainInFlight = false
  const SOFT_FAIL_MAX = 3
  const beginCapture = deps.startCapture ?? defaultStartCapture
  const beginPcmStream = deps.startPcmStreamCapture ?? defaultStartPcmStreamCapture
  const pendingTimeoutMs = deps.pendingTimeoutMs ?? LOCAL_STT_PENDING_TIMEOUT_MS
  const stopGraceMs = deps.stopGraceMs ?? LOCAL_STT_STOP_GRACE_MS

  const clearSegmentTimer = () => {
    if (segmentTimer) {
      clearTimeout(segmentTimer)
      segmentTimer = null
    }
  }

  const clearPartialTimer = () => {
    if (partialTimer) {
      clearTimeout(partialTimer)
      partialTimer = null
    }
  }

  const clearPendingTimer = () => {
    if (pendingTimer) {
      clearTimeout(pendingTimer)
      pendingTimer = null
    }
  }

  const pendingWaitMs = () => {
    const budget = deps.pendingTimeoutMs ?? (modelId === "large-v3-turbo" ? 305_000 : pendingTimeoutMs)
    // Ending an ordinary recording is the normal route to its final, not cancellation.
    return mode === "classic" || wantListening ? budget : Math.min(stopGraceMs, budget)
  }

  const armPendingTimer = (sid: string) => {
    clearPendingTimer()
    const ms = pendingWaitMs()
    pendingTimer = setTimeout(() => {
      pendingTimer = null
      if (!pending || pending.sessionId !== sid) return
      // Still listening: surface infer_timeout (soft streak). After user stop:
      // empty_result so the loop can onEnd without a scary banner.
      finishPending({
        ok: false,
        code: mode === "classic" || wantListening ? "infer_timeout" : "empty_result",
      })
    }, ms)
  }

  const clearSub = () => {
    if (unsub) {
      try {
        unsub()
      } catch {
        /* */
      }
      unsub = null
    }
  }

  const reset = () => {
    // V1: invalidate every in-flight coroutine gen guard (classic stop chain,
    // continuous loops). Without this a coroutine sleeping in conflict backoff
    // survived reset() and woke as a zombie — uploading with no subscription,
    // pending never settled, phase stuck "waiting" → mic locked for good.
    loopGen += 1
    clearSegmentTimer()
    clearPartialTimer()
    clearPendingTimer()
    segmentStopTrigger = null
    if (pcmStream) {
      try {
        pcmStream.abort()
      } catch {
        /* */
      }
      pcmStream = null
    }
    clearSub()
    capture = null
    sessionId = null
    phase = "idle"
    aborted = false
    wantListening = false
    mode = "classic"
    streamPartial = false
    parentSessionId = ""
    segmentIndex = 0
    pending = null
    streamSeq = 0
    streamStable = ""
    streamPrevHypothesis = ""
    partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
    pendingSoftStop = false
    softFailStreak = 0
    stopChainInFlight = false
  }

  const finishPending = (
    r: { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string },
  ) => {
    clearPendingTimer()
    const p = pending
    pending = null
    p?.resolve(r)
  }

  const onWs = (msg: any) => {
    if (dead || !msg || typeof msg.type !== "string") return
    const sid = typeof msg.sessionId === "string" ? msg.sessionId : ""
    if (!sessionId || sid !== sessionId) return

    if (msg.type === "voice.stt.partial") {
      // M2 hypothesis text (status === "hypothesis"); ignore status-only partials
      // N4: drop late partials after window end / while waiting for final
      if (phase !== "recording") return
      if (msg.status === "hypothesis" && typeof msg.text === "string") {
        const hyp = msg.text.trim()
        if (!hyp) return
        // Pace next poll from companion infer wall time (medium models often >1.4s)
        if (typeof msg.ms === "number" && Number.isFinite(msg.ms) && msg.ms > 0) {
          partialPollMs = nextPartialPollMs(msg.ms)
        }
        // F3: interim-only within a window — never commit finalChunk mid-window.
        streamPrevHypothesis = hyp
        const display = hyp.startsWith(streamStable) ? hyp.slice(streamStable.length) : hyp
        handlers.onResult({
          interim: display,
          finalChunk: "",
        })
      }
      return
    }

    if (msg.type === "voice.stt.result") {
      const text = typeof msg.text === "string" ? msg.text : ""
      if (pending && pending.sessionId === sid) {
        finishPending({
          ok: true,
          text,
          ...(msg.postprocessed === true ? { postprocessed: true } : {}),
        })
        return
      }
      if (aborted) {
        handlers.onEnd()
        reset()
        return
      }
      if (text.trim()) {
        handlers.onResult({
          interim: "",
          finalChunk: text,
          ...(msg.postprocessed === true ? { postprocessed: true } : {}),
        })
      }
      handlers.onEnd()
      reset()
      return
    }

    if (msg.type === "voice.stt.error") {
      const code = typeof msg.code === "string" && msg.code ? msg.code : "unknown"
      if (pending && pending.sessionId === sid) {
        finishPending({
          ok: false,
          code: code === "aborted" || aborted ? "aborted" : code,
        })
        return
      }
      if (code === "aborted" || aborted) {
        handlers.onError("aborted")
        handlers.onEnd()
        reset()
        return
      }
      // No pending (e.g. start rejected mid-stream).
      // Hard errors always stop. Soft: only when streamPartial is false —
      // streaming loop already counts soft fails on end() (Pi nit: avoid double streak).
      if (isHardSttSegmentError(code) || code === "oom") {
        handlers.onError(code)
        handlers.onEnd()
        reset()
        return
      }
      if (
        mode === "continuous" &&
        wantListening &&
        isSoftSttSegmentError(code) &&
        !streamPartial
      ) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
        softFailStreak += 1
        handlers.onError(code)
        if (softFailStreak >= SOFT_FAIL_MAX) {
          handlers.onEnd()
          reset()
          return
        }
        handlers.onSegmentContinue?.()
        return
      }
      // Streaming with pending null on soft: notify UI but let loop own streak via end path
      if (mode === "continuous" && streamPartial && isSoftSttSegmentError(code)) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
        handlers.onError(code)
        return
      }
      handlers.onError(code)
      handlers.onEnd()
      reset()
    }
  }

  const ensureSub = () => {
    if (unsub) return
    unsub = deps.onMessage(onWs)
  }

  const uploadAndWait = (
    sid: string,
    wav: Uint8Array,
  ): Promise<{ ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string }> => {
    return new Promise((resolve) => {
      if (!sid || dead) {
        resolve({ ok: false, code: "aborted" })
        return
      }
      phase = "uploading"
      handlers.onCaptureStopped?.()

      if (wav.length === 0) {
        resolve({ ok: false, code: "empty_result" })
        return
      }

      pending = { sessionId: sid, resolve }
      sessionId = sid
      armPendingTimer(sid)

      const chunks = splitIntoChunks(wav, LOCAL_STT_MAX_CHUNK_RAW_BYTES)
      for (let seq = 0; seq < chunks.length; seq++) {
        if (dead || aborted || sessionId !== sid) {
          finishPending({ ok: false, code: "aborted" })
          return
        }
        deps.send({
          type: "voice.stt.chunk",
          v: 1,
          sessionId: sid,
          seq,
          data: uint8ToBase64(chunks[seq]!),
        })
      }

      if (dead || aborted || sessionId !== sid) {
        finishPending({ ok: false, code: "aborted" })
        return
      }
      phase = "waiting"
      deps.send({
        type: "voice.stt.end",
        v: 1,
        sessionId: sid,
        totalSeq: chunks.length,
      })
    })
  }

  const sendStart = (sid: string, maxMs: number) => {
    deps.send({
      type: "voice.stt.start",
      v: 1,
      sessionId: sid,
      ...(modelId ? { modelId } : {}),
      ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
      format: "wav",
      sampleRate: LOCAL_STT_SAMPLE_RATE,
      channels: LOCAL_STT_CHANNELS,
      lang: lang.startsWith("zh") ? "zh" : lang,
      maxMs,
      // P1: server-enforced privacy ack (chrome.storage alone is not enough)
      privacy_ack_v2: true,
    })
  }

  /**
   * Record one segment: wait segmentMs or user stop(), then return WAV.
   */
  const recordSegment = async (segmentMs: number): Promise<Uint8Array | null> => {
    const handle = await beginCapture({ maxMs: segmentMs, onLevel: handlers.onLevel })
    if (dead || aborted || !wantListening) {
      try {
        handle.abort()
      } catch {
        /* */
      }
      return null
    }
    capture = handle

    await new Promise<void>((resolve) => {
      let settled = false
      const done = () => {
        if (settled) return
        settled = true
        clearSegmentTimer()
        segmentStopTrigger = null
        resolve()
      }
      segmentStopTrigger = done
      segmentTimer = setTimeout(done, segmentMs)
    })

    capture = null
    if (dead || aborted) {
      try {
        handle.abort()
      } catch {
        /* */
      }
      return null
    }
    try {
      return await handle.stop()
    } catch (e: any) {
      if (e?.code === "aborted" || aborted) return null
      throw e
    }
  }

  const runClassic = async (sid: string) => {
    try {
      const handle = await beginCapture({ maxMs: LOCAL_STT_MAX_RECORD_MS, onLevel: handlers.onLevel })
      if (dead || aborted || sessionId !== sid) {
        handle.abort()
        return
      }
      capture = handle
      // C1 / D1c: do NOT voice.stt.start until upload. Companion arms 10s idle
      // on start with zero chunks during record → forceAbort (classic ≥10s).
      if (dead || aborted) {
        handle.abort()
        return
      }
      handlers.onStart()
    } catch (e: any) {
      if (dead || aborted) return
      const code =
        e?.code === "aborted"
          ? "aborted"
          : e?.name === "NotAllowedError" || e?.name === "PermissionDeniedError"
            ? "not-allowed"
            : "audio-capture"
      handlers.onError(code)
      handlers.onEnd()
      reset()
    }
  }

  /**
   * M2 streaming continuous: PCM chunks live + partial_request → interim hypothesis;
   * window end → single final commit (F3: no mid-window finalChunk).
   * Window length honors segmentCapMs (F1), default ~8s when realtime.
   */
  const runStreamingContinuous = async (gen: number) => {
    try {
      let reportedStart = false
      while (!dead && wantListening && gen === loopGen) {
        const remaining = hardCapMs - (Date.now() - wallStart)
        if (remaining < 200) break

        // F1: honor near-realtime segmentCapMs (not always 45s)
        const windowMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
        segmentIndex += 1
        const segSid = `${parentSessionId}-s${segmentIndex}`
        sessionId = segSid
        phase = "recording"
        streamSeq = 0
        streamStable = ""
        streamPrevHypothesis = ""
        partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
        let sessionStarted = false

        // N3: soft-stop may arrive while we await gUM — honor after resolve
        if (pendingSoftStop || !wantListening) {
          pendingSoftStop = false
          if (!dead) {
            handlers.onEnd()
            reset()
          }
          return
        }

        // F7: open mic first, then voice.stt.start (avoid idle abort during gUM)
        try {
          pcmStream = await beginPcmStream({
            maxMs: windowMs,
            onLevel: handlers.onLevel,
            onPcmChunk: (pcm) => {
              if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
              if (!sessionStarted || pcm.length === 0) return
              const chunks = splitIntoChunks(pcm, LOCAL_STT_MAX_CHUNK_RAW_BYTES)
              for (const c of chunks) {
                deps.send({
                  type: "voice.stt.chunk",
                  v: 1,
                  sessionId: segSid,
                  seq: streamSeq,
                  data: uint8ToBase64(c),
                })
                streamSeq += 1
              }
            },
          })
        } catch (e: any) {
          if (dead || gen !== loopGen) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
          return
        }

        // N3: soft stop during gUM — release mic, clean end (no full window)
        if (dead || gen !== loopGen) {
          try {
            pcmStream?.abort()
          } catch {
            /* */
          }
          pcmStream = null
          return
        }
        if (aborted || pendingSoftStop || !wantListening) {
          try {
            pcmStream?.abort()
          } catch {
            /* */
          }
          pcmStream = null
          pendingSoftStop = false
          if (aborted) {
            handlers.onError("aborted")
          }
          if (!dead) {
            handlers.onEnd()
            reset()
          }
          return
        }

        deps.send({
          type: "voice.stt.start",
          v: 1,
          sessionId: segSid,
          ...(modelId ? { modelId } : {}),
          ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
          format: "pcm_s16le",
          sampleRate: LOCAL_STT_SAMPLE_RATE,
          channels: LOCAL_STT_CHANNELS,
          lang: lang.startsWith("zh") ? "zh" : lang,
          maxMs: windowMs,
          // P1: same wire gate as classic WAV start — continuous/hold path must not omit
          privacy_ack_v2: true,
        })
        sessionStarted = true
        // Permission/capture acquisition is still "starting". Report listening
        // only once capture is ready; later windows use onSegmentContinue.
        if (!reportedStart) {
          reportedStart = true
          handlers.onStart()
        }

        // Adaptive partial poll: setTimeout chain paced by last hypothesis `ms`
        clearPartialTimer()
        const schedulePartialPoll = () => {
          clearPartialTimer()
          if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
          if (phase !== "recording") return
          partialTimer = setTimeout(() => {
            partialTimer = null
            if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
            if (phase !== "recording") return
            deps.send({
              type: "voice.stt.partial_request",
              v: 1,
              sessionId: segSid,
            })
            // Reschedule with current pace (updated when hypothesis with ms arrives)
            schedulePartialPoll()
          }, partialPollMs)
        }
        schedulePartialPoll()

        // Wait until window ends, user stop, or hard cap
        await new Promise<void>((resolve) => {
          let settled = false
          const done = () => {
            if (settled) return
            settled = true
            clearSegmentTimer()
            segmentStopTrigger = null
            resolve()
          }
          segmentStopTrigger = done
          // Soft-stop already requested before wait armed → end immediately
          if (pendingSoftStop || !wantListening) {
            pendingSoftStop = false
            done()
            return
          }
          segmentTimer = setTimeout(done, windowMs)
        })

        clearPartialTimer()
        const handle = pcmStream
        pcmStream = null
        if (handle) {
          try {
            await handle.stop()
          } catch {
            /* */
          }
        }

        if (dead || gen !== loopGen) return
        if (aborted) {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
          handlers.onError("aborted")
          handlers.onEnd()
          reset()
          return
        }

        // Final decode for this window — single commit (F3)
        phase = "waiting"
        handlers.onCaptureStopped?.()
        if (streamSeq === 0) {
          // No audio captured this window
          if (!wantListening) break
          handlers.onSegmentContinue?.()
          continue
        }
        const result = await new Promise<
          { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string }
        >(
          (resolve) => {
            pending = { sessionId: segSid, resolve }
            armPendingTimer(segSid)
            deps.send({
              type: "voice.stt.end",
              v: 1,
              sessionId: segSid,
              totalSeq: streamSeq,
            })
          },
        )

        if (dead || gen !== loopGen) return
        if (result.ok === false) {
          const streamErr = result.code
          if (streamErr === "aborted" || aborted) {
            handlers.onError("aborted")
            handlers.onEnd()
            reset()
            return
          }
          if (streamErr === "empty_result") {
            softFailStreak = 0
            handlers.onResult({ interim: "", finalChunk: "" })
          } else if (isSoftSttSegmentError(streamErr) && wantListening) {
            softFailStreak += 1
            handlers.onError(streamErr)
            handlers.onResult({ interim: "", finalChunk: "" })
            if (softFailStreak >= SOFT_FAIL_MAX) {
              handlers.onEnd()
              reset()
              return
            }
          } else {
            // conflict/busy/oom: try reclaim then hard stop (do not soft-loop max-1)
            if (streamErr === "resource_conflict" || streamErr === "session_busy") {
              try {
                deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
              } catch {
                /* */
              }
              await new Promise((r) => setTimeout(r, 200))
              // The abort's own "aborted" ACK may have torn us down during the
              // wait (no-pending kill path) — do not fire handlers a second time.
              if (dead || gen !== loopGen) return
            }
            handlers.onError(streamErr)
            handlers.onEnd()
            reset()
            return
          }
        } else if (result.text.trim()) {
          softFailStreak = 0
          // Window commit: one finalChunk for the whole window text
          handlers.onResult({
            interim: "",
            finalChunk: result.text.trim(),
            ...(result.postprocessed === true ? { postprocessed: true } : {}),
          })
          streamStable = result.text.trim()
        } else {
          softFailStreak = 0
          handlers.onResult({ interim: "", finalChunk: "" })
        }

        if (!wantListening || aborted || mode === "classic") break
        handlers.onSegmentContinue?.()
      }

      if (!dead) handlers.onEnd()
      reset()
    } catch {
      if (!dead) {
        handlers.onError("unknown")
        handlers.onEnd()
      }
      reset()
    }
  }

  const runContinuous = async (gen: number) => {
    if (streamPartial) {
      await runStreamingContinuous(gen)
      return
    }
    try {
      handlers.onStart()
      while (!dead && wantListening && gen === loopGen) {
        const remaining = hardCapMs - (Date.now() - wallStart)
        // Allow short test segments (<800ms wall hardCap with tiny segmentCapMs)
        if (remaining < Math.min(50, segmentCapMs)) break

        const segmentMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
        segmentIndex += 1
        const segSid = `${parentSessionId}-s${segmentIndex}`
        sessionId = segSid
        phase = "recording"

        // Do NOT voice.stt.start until upload: companion arms 10s idle on start
        // with zero chunks during record → forceAbort (Pi D1c blocker #2).
        let wav: Uint8Array | null
        try {
          wav = await recordSegment(segmentMs)
        } catch (e: any) {
          if (dead || gen !== loopGen) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
          return
        }

        if (dead || gen !== loopGen) return
        if (aborted || wav == null) {
          // User abort or cancelled before audio
          if (aborted) {
            handlers.onError("aborted")
          }
          handlers.onEnd()
          reset()
          return
        }

        // Open STT session then immediately stream chunks (keeps idle timer happy).
        sendStart(segSid, segmentMs)
        let result = await uploadAndWait(segSid, wav)
        // Conflict: abort any stale holder then one retry (must free max-1 slot).
        if (
          result.ok === false &&
          (result.code === "resource_conflict" || result.code === "session_busy") &&
          !dead &&
          !aborted &&
          gen === loopGen
        ) {
          const retrySid = `${segSid}-r1`
          // V1/L10: adopt the retry sid BEFORE abort+backoff. The rejected sid's
          // chunk/end session_unknown rejects and the abort's own error ACK land
          // during the sleep; with the old sid still current they hit the
          // no-pending kill path (onError+onEnd+reset) and orphaned this retry.
          sessionId = retrySid
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
          // Best-effort: also abort parent-prefixed sessions from this capture
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: parentSessionId })
          await new Promise((r) => setTimeout(r, 250))
          if (dead || aborted || gen !== loopGen) return
          // Belt-and-suspenders: never upload the retry without a subscription.
          ensureSub()
          sendStart(retrySid, segmentMs)
          result = await uploadAndWait(retrySid, wav)
        }
        if (dead || gen !== loopGen) return

        if (result.ok === false) {
          const errCode = result.code
          if (errCode === "aborted" || aborted) {
            handlers.onError("aborted")
            handlers.onEnd()
            reset()
            return
          }
          if (isHardSttSegmentError(errCode) || errCode === "oom") {
            handlers.onError(errCode)
            handlers.onEnd()
            reset()
            return
          }
          // Soft only after end() failures that drop companion bound
          if (isSoftSttSegmentError(errCode) && wantListening) {
            softFailStreak += 1
            handlers.onError(errCode)
            if (softFailStreak >= SOFT_FAIL_MAX) {
              handlers.onEnd()
              reset()
              return
            }
            handlers.onSegmentContinue?.()
            continue
          }
          // resource_conflict after retry, payload_too_large, etc. → hard stop
          handlers.onError(errCode)
          handlers.onEnd()
          reset()
          return
        }

        softFailStreak = 0
        if (result.text.trim()) {
          handlers.onResult({
            interim: "",
            finalChunk: result.text,
            ...(result.postprocessed === true ? { postprocessed: true } : {}),
          })
        }

        if (!wantListening || aborted) break

        // Resume listening chrome between segments
        handlers.onSegmentContinue?.()
      }

      if (!dead) handlers.onEnd()
      reset()
    } catch {
      if (!dead) {
        handlers.onError("unknown")
        handlers.onEnd()
      }
      reset()
    }
  }

  return {
    start(langOrOpts?: SpeechAdapterStartArg) {
      if (dead) return
      if (phase !== "idle") return

      aborted = false
      wantListening = true
      lang = VOICE_DEFAULT_LANG
      let sid = ""
      let mid = deps.modelId
      mode = "classic"
      hardCapMs = VOICE_CONTINUOUS_HARD_CAP_MS
      segmentCapMs = LOCAL_STT_MAX_RECORD_MS
      streamPartial = false

      if (typeof langOrOpts === "string") {
        lang = langOrOpts || VOICE_DEFAULT_LANG
      } else if (langOrOpts && typeof langOrOpts === "object") {
        if (langOrOpts.lang) lang = langOrOpts.lang
        if (langOrOpts.sessionId) sid = langOrOpts.sessionId
        if (langOrOpts.modelId) mid = langOrOpts.modelId
        if (langOrOpts.mode === "continuous") mode = "continuous"
        if (typeof (langOrOpts as { hardCapMs?: number }).hardCapMs === "number") {
          hardCapMs = (langOrOpts as { hardCapMs: number }).hardCapMs
        }
        if (typeof (langOrOpts as { segmentMs?: number }).segmentMs === "number") {
          segmentCapMs = Math.max(
            20,
            Math.min(LOCAL_STT_MAX_RECORD_MS, (langOrOpts as { segmentMs: number }).segmentMs),
          )
        }
        if ((langOrOpts as { streamPartial?: boolean }).streamPartial === true) {
          streamPartial = true
          // Prefer near-realtime segment defaults when streaming
          if (mode === "continuous" && segmentCapMs >= LOCAL_STT_MAX_RECORD_MS) {
            segmentCapMs = LOCAL_STT_NEAR_REALTIME_SEGMENT_MS
          }
        }
        // large-v3-turbo: progressive re-decode is too heavy (loads full model often).
        // Force final-only continuous windows even if caller asked for streamPartial.
        if (mid === "large-v3-turbo" || modelId === "large-v3-turbo") {
          streamPartial = false
          segmentCapMs = LOCAL_STT_MAX_RECORD_MS
        }
        // #259: SAPI is batch — no progressive hypotheses for system sessions.
        if (deps.engineKind === "system") {
          streamPartial = false
          segmentCapMs = LOCAL_STT_MAX_RECORD_MS
        }
      }

      if (!sid) {
        handlers.onError("session_busy")
        handlers.onEnd()
        return
      }

      parentSessionId = sid
      sessionId = sid
      modelId = mid || deps.modelId || ""
      if (mode === "classic" && streamPartial) {
        // Progressive preview for ordinary dictation, with one bounded final.
        // Leave transport/drain time before the daemon's 45 s recording lease expires.
        hardCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
        segmentCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
      }
      ensureSub()
      phase = "recording"
      wallStart = Date.now()
      segmentIndex = 0
      loopGen += 1
      const gen = loopGen

      if (streamPartial) {
        void runStreamingContinuous(gen)
      } else if (mode === "continuous") {
        void runContinuous(gen)
      } else {
        void runClassic(sid)
      }
    },

    stop() {
      if (dead) return
      if (phase === "idle") return

      wantListening = false

      // Continuous: finish current segment early, then exit after upload / end stream
      if (mode === "continuous" || streamPartial) {
        if (phase === "recording") {
          // N3: if window wait not armed yet (still in gUM), mark pending soft stop
          if (!segmentStopTrigger) {
            pendingSoftStop = true
          }
          segmentStopTrigger?.()
        }
        // Waiting for companion infer: re-arm with stopGrace so a dead
        // Companion (SIGTERM mid-window) cannot leave the mic/UI hung.
        if ((phase === "waiting" || phase === "uploading") && pending && sessionId) {
          armPendingTimer(sessionId)
        }
        return
      }

      // classic
      if (phase === "uploading" || phase === "waiting") {
        return
      }

      const handle = capture
      capture = null
      if (!handle) {
        // L10: double-click stop while the first stop's upload chain is in
        // flight — ignore the repeat instead of aborting the upload (which
        // silently discarded the whole recording).
        if (stopChainInFlight) return
        aborted = true
        handlers.onError("aborted")
        handlers.onEnd()
        reset()
        return
      }

      stopChainInFlight = true
      const genAtStop = loopGen
      void handle
        .stop()
        .then(async (wav) => {
          const sid = sessionId
          if (!sid) return
          if (dead || aborted || genAtStop !== loopGen) return
          // Open STT session then immediately stream chunks (keeps idle timer happy).
          sendStart(sid, LOCAL_STT_MAX_RECORD_MS)
          let result = await uploadAndWait(sid, wav)
          if (
            result.ok === false &&
            (result.code === "resource_conflict" || result.code === "session_busy") &&
            !dead &&
            genAtStop === loopGen
          ) {
            const retrySid = `${sid}-r1`
            // V1: adopt the retry sid BEFORE abort+backoff. The rejected sid's
            // chunk/end session_unknown rejects and the abort's own error ACK
            // land during the sleep; with the old sid still current they hit
            // the no-pending kill path (onError+onEnd+reset) and turned this
            // retry into a zombie (no subscription, pending never settled).
            sessionId = retrySid
            deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
            await new Promise((r) => setTimeout(r, 250))
            if (dead || genAtStop !== loopGen) return
            // Belt-and-suspenders: never upload the retry without a subscription.
            ensureSub()
            sendStart(retrySid, LOCAL_STT_MAX_RECORD_MS)
            result = await uploadAndWait(retrySid, wav)
          }
          if (dead) return
          if (result.ok === false) {
            const errCode = result.code
            // User-stop timeout uses empty_result so we can onEnd without a banner.
            if (errCode !== "empty_result") {
              handlers.onError(errCode === "aborted" ? "aborted" : errCode)
            }
          } else if (result.text.trim()) {
            handlers.onResult({
              interim: "",
              finalChunk: result.text,
              ...(result.postprocessed === true ? { postprocessed: true } : {}),
            })
          }
          handlers.onEnd()
          reset()
        })
        .catch((e: any) => {
          if (aborted || dead) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
        })
    },

    abort() {
      if (dead) return
      aborted = true
      wantListening = false
      loopGen += 1
      clearSegmentTimer()
      clearPartialTimer()
      segmentStopTrigger?.()
      segmentStopTrigger = null
      const sid = sessionId
      const handle = capture
      capture = null
      try {
        handle?.abort()
      } catch {
        /* */
      }
      if (pcmStream) {
        try {
          pcmStream.abort()
        } catch {
          /* */
        }
        pcmStream = null
      }
      if (sid) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
      }
      finishPending({ ok: false, code: "aborted" })
      handlers.onError("aborted")
      handlers.onEnd()
      reset()
    },

    destroy() {
      dead = true
      aborted = true
      wantListening = false
      pendingSoftStop = true
      loopGen += 1
      clearSegmentTimer()
      clearPartialTimer()
      // Fire wait resolvers so streaming coroutines do not hang (Pi destroy nit)
      try {
        segmentStopTrigger?.()
      } catch {
        /* */
      }
      segmentStopTrigger = null
      const sid = sessionId
      const handle = capture
      capture = null
      try {
        handle?.abort()
      } catch {
        /* */
      }
      if (pcmStream) {
        try {
          pcmStream.abort()
        } catch {
          /* */
        }
        pcmStream = null
      }
      if (sid) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
      }
      finishPending({ ok: false, code: "aborted" })
      reset()
    },
  }
}

FULL FILE chrome-extension/tests/voice-classic-preview.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import { createLocalSttAdapter } from "../src/sidepanel/voice/local-stt-adapter"
import type { PcmStreamCaptureOpts } from "../src/sidepanel/voice/pcm-stream-capture"
import type { PcmStreamHandle } from "../src/sidepanel/voice/pcm-stream-capture"

const turn = () => new Promise<void>((resolve) => setTimeout(resolve, 0))

test("#482 streaming remains starting until capture is ready; continuous windows report start once", async () => {
  for (const mode of ["classic", "continuous"] as const) {
    const sent: any[] = [], pending: { resolve: (h: PcmStreamHandle) => void; opts: PcmStreamCaptureOpts }[] = []
    let receive: (msg: any) => void = () => {}, starts = 0
    const adapter = createLocalSttAdapter({ onStart: () => { starts++ }, onResult() {}, onError() {}, onEnd() {} }, {
      modelId: "small", send: (msg) => { sent.push(msg); if (msg.type === "voice.stt.end") queueMicrotask(() => receive({ type: "voice.stt.result", sessionId: msg.sessionId, text: "一段" })) },
      onMessage: (h) => { receive = h; return () => {} },
      startPcmStreamCapture: (opts) => new Promise((resolve) => pending.push({ resolve, opts })),
    })
    const handle = (): PcmStreamHandle => ({ backend: "scriptprocessor", stop: async () => {}, abort() {} })
    try {
      adapter.start({ sessionId: "permission-" + mode, mode, streamPartial: true, segmentMs: 25, hardCapMs: 1000 })
      await turn()
      assert.equal(pending.length, 1); assert.equal(starts, 0)
      assert.equal(sent.some((m) => m.type === "voice.stt.start"), false)
      pending[0].resolve(handle()); await turn()
      assert.equal(starts, 1)
      pending[0].opts.onPcmChunk(new Uint8Array(32000))
      if (mode === "continuous") {
        await new Promise((resolve) => setTimeout(resolve, 60))
        assert.equal(pending.length, 2)
        assert.equal(starts, 1, "a later permission/capture acquisition must not emit another ENGINE_START")
        pending[1].resolve(handle()); await turn()
        assert.equal(starts, 1)
      }
    } finally { adapter.abort(); adapter.destroy() }
  }
})

test("#482 stopping while capture permission is pending never reports listening", async () => {
  let grant!: (h: PcmStreamHandle) => void, starts = 0, released = 0, ends = 0
  const adapter = createLocalSttAdapter({ onStart: () => { starts++ }, onResult() {}, onError() {}, onEnd: () => { ends++ } }, {
    modelId: "medium", send() {}, onMessage: () => () => {},
    startPcmStreamCapture: () => new Promise((resolve) => { grant = resolve }),
  })
  adapter.start({ sessionId: "permission-cancel", mode: "classic", streamPartial: true }); await turn()
  adapter.stop(); grant({ backend: "scriptprocessor", stop: async () => {}, abort: () => { released++ } }); await turn()
  assert.equal(starts, 0); assert.equal(released, 1); assert.equal(ends, 1)
  adapter.destroy()
})

test("#482 ordinary local dictation previews during recording, then commits one final on stop", async () => {
  const sent: any[] = [], results: { interim: string; finalChunk: string }[] = []
  let receive: (msg: any) => void = () => {}, capture: PcmStreamCaptureOpts | undefined
  let ends = 0, stops = 0
  const adapter = createLocalSttAdapter({
    onStart() {}, onResult: (r) => results.push(r), onError: (e) => { throw new Error(e) }, onEnd: () => { ends++ },
  }, {
    modelId: "medium", send: (msg) => sent.push(msg),
    onMessage: (h) => { receive = h; return () => { receive = () => {} } },
    startCapture: async () => { throw new Error("batch capture should not run") },
    startPcmStreamCapture: async (opts) => { capture = opts; return { backend: "scriptprocessor", stop: async () => { stops++ }, abort() {} } },
    pendingTimeoutMs: 200, stopGraceMs: 1,
  })
  try {
    adapter.start({ sessionId: "classic-preview", mode: "classic", streamPartial: true })
    await turn()
    const start = sent.find((m) => m.type === "voice.stt.start")
    assert.equal(start.format, "pcm_s16le"); assert.equal(start.privacy_ack_v2, true)
    assert.ok(start.maxMs <= 45_000 && start.maxMs > 40_000)
    capture!.onPcmChunk(new Uint8Array(32000))
    receive({ type: "voice.stt.partial", sessionId: start.sessionId, status: "hypothesis", text: "听写预览" })
    assert.deepEqual(results, [{ interim: "听写预览", finalChunk: "" }])
    assert.equal(sent.some((m) => m.type === "voice.stt.end"), false)
    adapter.stop(); await turn()
    const end = sent.find((m) => m.type === "voice.stt.end")
    assert.equal(end.totalSeq, 1)
    // Classic stop is normal finalization, so the short continuous stop-grace cannot discard it.
    await new Promise((r) => setTimeout(r, 15))
    assert.equal(ends, 0)
    receive({ type: "voice.stt.result", sessionId: start.sessionId, text: "最终听写" })
    await turn()
    assert.equal(ends, 1); assert.equal(stops, 1)
    assert.deepEqual(results.map((r) => r.finalChunk).filter(Boolean), ["最终听写"])
    assert.equal(sent.filter((m) => m.type === "voice.stt.start").length, 1)
  } finally { adapter.destroy() }
})

test("#482 cancel ordinary streaming dictation discards a late final", async () => {
  const sent: any[] = [], finals: string[] = []
  let receive: (msg: any) => void = () => {}, capture: PcmStreamCaptureOpts | undefined
  const adapter = createLocalSttAdapter({ onStart() {}, onError() {}, onEnd() {}, onResult: (r) => { if (r.finalChunk) finals.push(r.finalChunk) } }, {
    modelId: "small", send: (m) => sent.push(m), onMessage: (h) => { receive = h; return () => {} },
    startPcmStreamCapture: async (opts) => { capture = opts; return { backend: "scriptprocessor", stop: async () => {}, abort() {} } },
  })
  try {
    adapter.start({ sessionId: "cancel-preview", mode: "classic", streamPartial: true }); await turn()
    capture!.onPcmChunk(new Uint8Array(32000)); adapter.stop(); await turn()
    const end = sent.find((m) => m.type === "voice.stt.end")
    adapter.abort(); receive({ type: "voice.stt.result", sessionId: end.sessionId, text: "不应写入" }); await turn()
    assert.deepEqual(finals, [])
    assert.ok(sent.some((m) => m.type === "voice.stt.abort" && m.sessionId === end.sessionId))
  } finally { adapter.destroy() }
})

FULL FILE chrome-extension/scripts/test-voice-hook-ui.py
"""#482 real React useVoiceInput + production PCM adapter, synthetic capture/runtime.

After nvm use 22: uv run --no-project --with playwright python scripts/test-voice-hook-ui.py
No installed extension, audio device, or model service is used.
"""
import json
import subprocess
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

project = Path(__file__).resolve().parent.parent
hook = json.dumps(str(project / 'src/sidepanel/hooks/useVoiceInput.ts'))
source = """
import React,{useRef,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {useVoiceInput} from HOOK_PATH;
window.sent=[];window.drafts=[];window.voiceListeners=new Set();
window.pushVoice=msg=>{for(const handler of window.voiceListeners)handler(msg)};
window.chrome={runtime:{sendMessage:msg=>{window.sent.push(msg);return Promise.resolve()},onMessage:{addListener:fn=>window.voiceListeners.add(fn),removeListener:fn=>window.voiceListeners.delete(fn)}}};
Object.defineProperty(navigator,'permissions',{value:{query:async()=>({state:'granted'})}});
Object.defineProperty(navigator,'mediaDevices',{value:{getUserMedia:()=>new Promise(resolve=>{window.grantCapture=()=>resolve({getTracks:()=>[{stop(){window.captureStopped=true}}]})})}});
window.AudioContext=class {
  state='running';sampleRate=16000;
  createMediaStreamSource(){return {connect(){},disconnect(){}}}
  createScriptProcessor(){return window.captureProcessor={connect(){},disconnect(){}}}
  createGain(){return {gain:{value:0},connect(){},disconnect(){}}}
  close(){return Promise.resolve()}
};
window.MediaRecorder=class {};
function Fixture(){
  const [draft,setDraft]=useState('已有草稿');const ref=useRef(draft);ref.current=draft;
  const [owner,setOwner]=useState('thread-a');
  const voice=useVoiceInput({getBaseText:()=>ref.current,onDraft:text=>{window.drafts.push(text);setDraft(text)},threadId:owner,
    allowStart:true,enabled:true,privacyAck:true,privacyAckV2:true,privacyAckV3:true,onNeedPrivacyAck(){throw new Error('unexpected privacy request')},onNeedPermissionBootstrap(){throw new Error('unexpected permission bootstrap')},
    sttEngine:'local',companionConnected:true,localReady:{model:true,binary:true},localStateHydrated:true,autoFallbackToBrowser:false,modelId:'medium',dictationMode:'classic',realtimeStreaming:true});
  return <><p id='phase'>{voice.phase}</p><textarea id='preview' readOnly value={voice.liveOverlay??draft}/><p id='draft'>{draft}</p><button id='toggle' onClick={()=>voice.toggle()}>听写</button><button id='switch' onClick={()=>setOwner('thread-b')}>切换</button></>;
}
createRoot(document.getElementById('root')).render(<Fixture/>);
""".replace('HOOK_PATH', hook)

with tempfile.TemporaryDirectory(prefix='cmspark-voice-hook-') as directory:
    root = Path(directory)
    build = "const x=JSON.parse(require('fs').readFileSync(0,'utf8'));require('esbuild').buildSync({stdin:{contents:x.source,resolveDir:process.cwd(),loader:'tsx'},bundle:true,outfile:x.outfile,jsx:'automatic'});"
    subprocess.run(['node', '-e', build], cwd=project, input=json.dumps({'source': source, 'outfile': str(root / 'app.js')}), text=True, check=True)
    (root / 'index.html').write_text('<html><meta charset="utf-8"><div id="root"></div><script src="app.js"></script></html>')
    with sync_playwright() as p:
        browser = p.chromium.launch(channel='chrome', headless=True)
        for scenario in ['final', 'switch']:
            page = browser.new_page();page.set_default_timeout(5000)
            errors = [];page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto((root / 'index.html').as_uri());page.locator('#toggle').click()
            page.wait_for_function('document.querySelector("#phase").textContent==="starting" && typeof window.grantCapture==="function"')
            assert not page.evaluate('window.sent.some(m=>m.type==="voice.stt.start")')
            page.evaluate('window.grantCapture()')
            page.wait_for_function('document.querySelector("#phase").textContent==="listening"')
            sid = page.evaluate('window.sent.find(m=>m.type==="voice.stt.start").sessionId')
            page.evaluate('window.captureProcessor.onaudioprocess({inputBuffer:{getChannelData:()=>new Float32Array(16000)}})')
            page.evaluate('(sid)=>window.pushVoice({type:"voice.stt.partial",sessionId:sid,status:"hypothesis",text:"预览文字"})', sid)
            page.wait_for_function('document.querySelector("#preview").value.includes("预览文字")')
            assert page.locator('#draft').inner_text() == '已有草稿'
            page.locator('#toggle').click()
            page.wait_for_function('document.querySelector("#phase").textContent==="processing"')
            if scenario == 'switch':
                page.locator('#switch').click()
                page.wait_for_function('window.sent.some(m=>m.type==="voice.stt.abort")')
            page.evaluate('(sid)=>window.pushVoice({type:"voice.stt.result",sessionId:sid,text:"最终文字"})', sid)
            page.wait_for_function('document.querySelector("#phase").textContent==="idle"')
            if scenario == 'final':
                page.wait_for_function('document.querySelector("#draft").textContent.includes("最终文字")')
                assert page.locator('#draft').inner_text().count('最终文字') == 1
                assert '预览文字' not in page.locator('#draft').inner_text()
            else:
                assert page.locator('#draft').inner_text() == '已有草稿'
                assert page.evaluate('window.drafts.length') == 0
            assert page.evaluate('window.captureStopped===true')
            assert not page.evaluate('window.sent.some(m=>m.type.startsWith("chat."))')
            assert not errors, errors
            page.close()
        browser.close()
print('PASS: real React useVoiceInput and PCM adapter; pending capture remains starting; readiness enters listening; interim stays preview; final commits once; thread switch discards late final; no auto-send.')

FULL FILE companion/src/threads/metadata-patch.ts
import { sanitizeUserTags } from "./user-tags"
import { sanitizeTopicFolder } from "./distill"

/** Existing metadata only; never pass arbitrary thread policy/config through HTTP. */
export function summonerThreadMetadata(body: unknown): Record<string, unknown> {
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("分类必须是对象")
  const fields = body as Record<string, unknown>
  const keys = Object.keys(fields)
  if (!keys.length || keys.some(key => !["alias", "user_tags", "topic_folder"].includes(key))) {
    throw new Error("仅支持修改名称、人工标签和手动分组")
  }
  const result: Record<string, unknown> = {}
  if ("alias" in fields) {
    if (typeof fields.alias !== "string" || !fields.alias.trim()) throw new Error("名称不能为空")
    const alias = fields.alias.normalize("NFC").replace(/[\x00-\x1f\x7f]/g, "").trim().slice(0, 200)
    if (!alias) throw new Error("名称不能为空")
    result.alias = alias
  }
  if ("user_tags" in fields) result.user_tags = sanitizeUserTags(fields.user_tags)
  if ("topic_folder" in fields) {
    if (fields.topic_folder !== null && typeof fields.topic_folder !== "string") throw new Error("分组必须是名称或空值")
    result.topic_folder = sanitizeTopicFolder(fields.topic_folder)
  }
  return result
}


FULL FILE companion/src/summoner/thread-management.ts
/** Small adapter over the same thread.update owner used by the extension. */
export const SUMMONER_THREAD_MANAGEMENT_JS = String.raw`
  var editingMetadata=null,metadataTrigger=null,metadataSaving=false;
  function metadataTags(raw){
    var seen={};
    return raw.split(/[,，\n]/).map(function(v){return v.normalize("NFC").replace(/[\x00-\x1f\x7f]/g,"").replace(/\s+/g," ").trim()}).filter(function(v){var key=v.toLowerCase();if(!v||Object.prototype.hasOwnProperty.call(seen,key))return false;Object.defineProperty(seen,key,{value:true});return true});
  }
  function threadEntries(items,view){
    var rows=[];
    items.forEach(function(t){
      var groups=view==="folders"?[t.topic_folder||"未分组"]:view==="ai"?[(t.digest&&t.digest.tags||[])[0]||"待 AI 整理"]:view==="tags"?metadataTags((t.user_tags||[]).concat(t.digest&&t.digest.tags||[]).join(",")):[];
      if(!groups.length)groups=[view==="tags"?"未标注":""];
      groups.forEach(function(group){rows.push({thread:t,group:group})});
    });
    if(view!=="recent") rows.sort(function(a,b){return a.group.localeCompare(b.group,"zh")});
    return rows;
  }
  function closeThreadMetadata(){
    if(metadataSaving)return;
    $("threadMetadata").hidden=true;editingMetadata=null;
    if(metadataTrigger&&metadataTrigger.isConnected)metadataTrigger.focus();
    metadataTrigger=null;
  }
  function openThreadMetadata(t,trigger){
    if(metadataSaving)return;
    editingMetadata=t.id;metadataTrigger=trigger;
    $("metadataTitle").textContent="分类 · "+(t.title||t.alias||t.id);
    $("metadataTags").value=(t.user_tags||[]).join("，");
    $("metadataFolder").value=t.topic_folder||"";
    $("metadataError").textContent="";
    $("threadFolders").replaceChildren();
    Array.from(new Set(threads.map(function(row){return row.topic_folder}).filter(Boolean))).forEach(function(name){var option=document.createElement("option");option.value=name;$("threadFolders").appendChild(option)});
    $("threadMetadata").hidden=false;$("metadataTags").focus();
  }
  $("metadataCancel").onclick=closeThreadMetadata;
  $("threadMetadata").addEventListener("keydown",function(e){if(e.key==="Escape"&&!metadataSaving){e.preventDefault();e.stopPropagation();closeThreadMetadata()}});
  $("threadMetadata").onsubmit=function(e){
    e.preventDefault();if(!editingMetadata||metadataSaving)return;
    var owner=editingMetadata,tags=metadataTags($("metadataTags").value);
    if(tags.length>20||tags.some(function(tag){return tag.length>40})){$("metadataError").textContent="最多 20 个标签，每个不超过 40 字";return}
    var folder=$("metadataFolder").value.normalize("NFC").replace(/[\x00-\x1f\x7f\\/]/g,"").trim()||null;
    var updates={user_tags:tags,topic_folder:folder};
    metadataSaving=true;$("metadataSave").disabled=true;$("metadataCancel").disabled=true;$("metadataTags").disabled=true;$("metadataFolder").disabled=true;$("metadataSave").textContent="保存中…";$("metadataError").textContent="";
    api("/api/thread?id="+encodeURIComponent(owner),{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(updates)}).then(function(d){
      if(!d||d.type!=="thread.updated"||!d.thread||d.thread.id!==owner)throw new Error(d&&d.error||"未收到分类保存确认");
      var saved=d.thread;
      if(JSON.stringify(metadataTags((saved.user_tags||[]).join(",")).map(function(t){return t.toLowerCase()}).sort())!==JSON.stringify(tags.map(function(t){return t.toLowerCase()}).sort())||(saved.topic_folder||null)!==folder)throw new Error("服务端未保存所提交的分类，请更新 Companion 后重试");
      threads=threads.map(function(t){return t.id===owner?Object.assign({},t,saved):t});
      renderThreads();$("threadMetadata").hidden=true;editingMetadata=null;
      var next=Array.from(document.querySelectorAll("#threads .thread-classify")).find(function(button){return button.dataset.threadId===owner});
      (next||$("threadSearch")).focus();
      setStatus("分类已保存");
    }).catch(function(err){$("metadataError").textContent=err&&err.message||"分类保存失败"}).finally(function(){
      metadataSaving=false;$("metadataSave").disabled=false;$("metadataCancel").disabled=false;$("metadataTags").disabled=false;$("metadataFolder").disabled=false;$("metadataSave").textContent="保存";
    });
  };
`

FULL FILE chrome-extension/tests/coding-session-owner-483.test.ts
import test from "node:test"
import assert from "node:assert/strict"
import { agentReducer, initialState, selectCodingSession, codingSessionBelongsToThread, type AgentState, type CodingSessionEvent } from "../src/sidepanel/store/agentStore"
import { codingMessageTargetsThread } from "../src/sidepanel/hooks/useWebSocket"

function event(state: AgentState, value: CodingSessionEvent): AgentState {
  return agentReducer(state, { type: "ACP_SESSION_EVENT", event: value })
}
function switchTo(state: AgentState, threadId: string): AgentState {
  return agentReducer(state, { type: "SET_ACTIVE_THREAD", threadId })
}

test("A task remains in A when creating B; background handback updates A and return restores it", () => {
  let state = event(switchTo(initialState, "a"), {
    session_id: "sa", thread_id: "a", state: "running", workspace_root: "/repo/a", goal: "review A",
  })
  state = switchTo(state, "b")
  assert.equal(selectCodingSession(state), null)
  state = event(state, { session_id: "sa", thread_id: "a", state: "closed", handback: "A findings", pending_diffs: [{ applyable: true }] })
  assert.equal(selectCodingSession(state), null)
  state = switchTo(state, "a")
  assert.equal(selectCodingSession(state)?.handback, "A findings")
  assert.equal(selectCodingSession(state)?.workspaceRoot, "/repo/a")
  assert.equal(selectCodingSession(state)?.hasPendingDiff, true)
})

test("a new session never inherits another session's mode, diff, workspace or terminal flags", () => {
  let state = event(switchTo(initialState, "a"), {
    session_id: "sa", thread_id: "a", state: "closed", mode: "propose_diff", workspace_root: "/repo/a", handback: "private A", pending_diffs: [{ applyable: true }], open_local_terminal: true,
  })
  state = event(switchTo(state, "b"), { session_id: "sb", thread_id: "b", state: "running" })
  const selected = selectCodingSession(state)!
  for (const key of ["mode", "hasPendingDiff", "workspaceRoot", "handback", "openLocalTerminal"] as const) assert.equal(selected[key], undefined)
  assert.equal(selected.threadId, "b")
})

test("late prior-session events and stale dismiss timers cannot replace or dismiss a newer session", () => {
  let state = event(switchTo(initialState, "a"), { session_id: "old", thread_id: "a", state: "closed" })
  state = event(state, { session_id: "new", thread_id: "a", state: "running" })
  state = event(state, { session_id: "old", thread_id: "a", state: "closed", handback: "late" })
  state = agentReducer(state, { type: "CLEAR_CODING_SESSION", sessionId: "old" })
  assert.equal(selectCodingSession(state)?.sessionId, "new")
  assert.equal(state.codingSessionsById.old.handback, "late")
})

test("unknown ownerless events are ignored; known partial events use only their existing owner", () => {
  const active = switchTo(initialState, "b")
  assert.equal(event(active, { session_id: "unknown", state: "running" }), active)
  let state = event(active, { session_id: "sa", thread_id: "a", state: "running" })
  state = event(state, { session_id: "sa", progress_tail: "progress" })
  assert.equal(selectCodingSession(state), null)
  assert.equal(state.codingSessionsById.sa.threadId, "a")
  assert.equal(event(state, { session_id: "sa", thread_id: "b", handback: "forged ownership" }), state)
})

test("dismiss is scoped and late progress cannot resurrect a dismissed session", () => {
  let state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "closed" })
  state = event(state, { session_id: "sb", thread_id: "b", state: "running" })
  state = agentReducer(state, { type: "CLEAR_CODING_SESSION", sessionId: "sa" })
  state = event(state, { session_id: "sa", state: "closed" })
  assert.equal(selectCodingSession(state), null)
  assert.equal(selectCodingSession(state, "b")?.sessionId, "sb")
})

test("commands and result feedback require an exact nonempty conversation owner", () => {
  const state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "running" })
  const session = selectCodingSession(state)
  assert.equal(codingSessionBelongsToThread(session, "a"), true)
  assert.equal(codingSessionBelongsToThread(session, "b"), false)
  assert.equal(codingSessionBelongsToThread(session, null), false)
  assert.equal(codingMessageTargetsThread({ thread_id: "a" }, "a"), true)
  assert.equal(codingMessageTargetsThread({ thread_id: "a" }, "b"), false)
  assert.equal(codingMessageTargetsThread({}, "b"), false)
  assert.equal(codingMessageTargetsThread({ thread_id: "" }, null), false)
})


test("first background B event before thread-list hydration remains in B and restores on navigation", () => {
  let state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "running" })
  assert.deepEqual(state.threads, [], "thread.list is not required to admit authenticated session events")
  state = event(state, { session_id: "sb", thread_id: "b", state: "running", workspace_root: "/repo/b", goal: "background B" })
  assert.equal(selectCodingSession(state)?.sessionId, "sa")
  state = event(state, { session_id: "sb", progress_tail: "B progress before hydration" })
  assert.equal(selectCodingSession(state)?.sessionId, "sa")
  state = switchTo(state, "b")
  assert.equal(selectCodingSession(state)?.sessionId, "sb")
  assert.equal(selectCodingSession(state)?.workspaceRoot, "/repo/b")
  assert.equal(selectCodingSession(state)?.progressTail, "B progress before hydration")
  const conflict = event(state, { session_id: "sb", thread_id: "a", progress_tail: "rebind attempt" })
  assert.equal(conflict, state, "the stored session owner remains immutable")
})

HTTP routes
    if (pathOnly === "/api/stt/start" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      const cfgModel = getConfig().voice?.localModelId
      const modelId =
        body.modelId === "small" || body.modelId === "medium" || body.modelId === "large-v3-turbo"
          ? body.modelId
          : cfgModel === "small" || cfgModel === "medium" || cfgModel === "large-v3-turbo"
            ? cfgModel
            : "medium"
      const payload: Record<string, unknown> = {
        v: 1,
        sessionId,
        modelId,
        format: "pcm_s16le",
        sampleRate: 16000,
        channels: 1,
        privacy_ack_v2: true,
      }
      // Engine is read from trusted configuration, never promoted by a page claim.
      if (getConfig().voice?.sttEngine === "system") payload.engine = "system"
      if (typeof body.lang === "string" && body.lang.trim()) {
        payload.lang = body.lang.startsWith("zh") ? "zh" : body.lang
      } else {
        payload.lang = "zh"
      }
      if (typeof body.maxMs === "number" && Number.isFinite(body.maxMs)) payload.maxMs = body.maxMs
      const started = await dispatchAllowed("voice.stt.start", payload)
      jsonResponse(res, started)
      if (!overlayDispatchFailed(started) && sessionId) overlaySttSessionId = sessionId
      return
    }

    if (pathOnly === "/api/stt/chunk" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, STT_CHUNK_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      const seq = Number.isInteger(body.seq) ? body.seq : 0
      const data = typeof body.data === "string" ? body.data : ""
      jsonResponse(
        res,
        await dispatchAllowed("voice.stt.chunk", { v: 1, sessionId, seq, data }),
      )
      return
    }

    if (pathOnly === "/api/stt/end" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      const totalSeq = Number.isInteger(body.totalSeq) ? body.totalSeq : 0
      jsonResponse(res, await dispatchAllowed("voice.stt.end", { v: 1, sessionId, totalSeq }))
      if (sessionId && overlaySttSessionId === sessionId) overlaySttSessionId = ""
      return
    }

    if (pathOnly === "/api/stt/abort" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      jsonResponse(res, await dispatchAllowed("voice.stt.abort", { v: 1, sessionId }))
      if (sessionId && overlaySttSessionId === sessionId) overlaySttSessionId = ""
      return
    }

    if (pathOnly === "/api/stt/partial" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      jsonResponse(
        res,
        await dispatchAllowed("voice.stt.partial_request", { v: 1, sessionId }),
      )
      return
    }


ACP entry and ui_start
// ACP WS handlers — list / cancel / UI-start / followup / adopt / apply.

import * as fs from "fs"
import { getConfig, saveConfig } from "../config"
import { logger } from "../logger"
import type {
  SecurityConfirmationDecision,
  SecurityConfirmationDetails,
} from "../security-confirmation"
import { getAcpManager } from "./manager"
import { discoverCodingAgents, _resetDiscoverCache } from "./discover"
import {
  formatAcpStartConfirmCode,
  formatAcpApplyConfirmCode,
} from "./confirm-copy"
import { getWorkspaceGitStatus } from "./git-status"

export interface AcpHandlerContext {
  requestConfirmation?: (
    details: SecurityConfirmationDetails,
  ) => Promise<SecurityConfirmationDecision>
  broadcast?: (data: any) => void
  threadId?: string
  getWorkspaceRoot?: (threadId: string) => string | null | undefined
  /** Return agent_role for thread if known (refuse worker). */
  getAgentRole?: (threadId: string) => string | undefined
}

let broadcastHooked = false

export function ensureAcpBroadcast(broadcast: (data: any) => void): void {
  if (broadcastHooked) return
  broadcastHooked = true
  getAcpManager().onEvent((ev) => {
    try {
      broadcast(ev)
    } catch {
      /* ignore */
    }
  })
}

async function confirmOrDeny(
  ctx: AcpHandlerContext,
  details: SecurityConfirmationDetails,
): Promise<boolean> {
  if (!ctx.requestConfirmation) return false
  const decision = await ctx.requestConfirmation(details)
  return !!decision?.approved
}

/** Session ownership is fixed at proposal. Legacy callers may omit thread_id;
 * explicit owners must match, and every session reply carries the stored owner. */
export async function handleAcpWsMessage(
  type: string,
  msg: Record<string, unknown>,
  ctx: AcpHandlerContext,
): Promise<any> {
  const mgr = getAcpManager()
  const controlsSession = ["acp.session.cancel", "acp.session.prompt", "acp.session.followup", "acp.apply_diff"].includes(type)
  const sid = typeof msg.session_id === "string" && msg.session_id ? msg.session_id
    : type === "acp.session.followup" && typeof msg.parent_session_id === "string" ? msg.parent_session_id : ""
  const session = controlsSession && sid ? mgr.getSession(sid) : undefined
  const claimedOwner = msg.thread_id !== undefined ? msg.thread_id : ctx.threadId
  if (controlsSession && claimedOwner !== undefined &&
      (typeof claimedOwner !== "string" || !claimedOwner || (session && session.thread_id !== claimedOwner))) {
    return {
      type: "error", family: "acp", error: "acp: session does not belong to the requested conversation",
      session_id: sid, ...(session ? { thread_id: session.thread_id } : {}),
    }
  }
  // Resolve a start owner once, before any side effect. The legacy context is
  // used only for an omitted field, never to rescue an explicitly invalid one.
  const startCandidate = msg.thread_id !== undefined ? msg.thread_id : ctx.threadId
  const startOwner = type === "acp.ui_start" && typeof startCandidate === "string" && startCandidate.trim()
    ? startCandidate : undefined
  if (type === "acp.ui_start" && !startOwner) {
    return { type: "error", family: "acp", error: "acp: thread_id required" }
  }
  const executionMessage = startOwner ? { ...msg, thread_id: startOwner } : msg
  const result = await handleAcpWsMessageInternal(type, executionMessage, ctx)
  if (!result || typeof result !== "object") return result
  const resultSession = typeof result.session_id === "string" ? mgr.getSession(result.session_id) : undefined
  const owner = resultSession?.thread_id ?? session?.thread_id ??
    startOwner
  return {
    ...result,
    ...(result.type === "error" ? { family: "acp" } : {}),
    ...(owner ? { thread_id: owner } : {}),
    ...(!result.session_id && sid ? { session_id: sid } : {}),
  }
}

async function handleAcpWsMessageInternal(
  type: string,
  msg: Record<string, unknown>,
  ctx: AcpHandlerContext,
): Promise<any> {
  const mgr = getAcpManager()
  if (ctx.broadcast) ensureAcpBroadcast(ctx.broadcast)

  if (type === "acp.list" || type === "acp.rediscover") {
    const cfg = getConfig()
    if (type === "acp.rediscover") {
      _resetDiscoverCache()
      discoverCodingAgents(true)
    }
    return {
      type: "acp.list",
      enabled: !!cfg.acp?.enabled,
      agents: mgr.listAgents(),
      auto_suggest: cfg.coding_handoff?.auto_suggest !== false,
    }
  }

  if (type === "acp.adopt_discovered") {
    // Persist discovered agents into config.acp.servers (user gesture from settings)
    const cfg = getConfig()
    if (!cfg.acp) {
      return { type: "error", error: "acp config missing" }
    }
    const ids = Array.isArray(msg.agent_ids)
      ? msg.agent_ids.map(String)
      : discoverCodingAgents(true).map((d) => d.id)
    const discovered = discoverCodingAgents(true)
    const servers = { ...(cfg.acp.servers || {}) }
    let added = 0
    for (const d of discovered) {
      if (ids.length && !ids.includes(d.id)) continue
      if (servers[d.id]?.command) continue
      servers[d.id] = {
        enabled: true,
        display_name: d.display_name,
        transport: "stdio",
        command: d.command,
        args: [],
        policy: {
          profile: "review_readonly",
          allow_write: false,
          allow_exec: false,
        },
      }
      added++
    }
    saveConfig({
      acp: {
        ...cfg.acp,
        enabled: cfg.acp.enabled === true ? true : cfg.acp.enabled,
        servers,
      },
    })
    logger.info("acp.adopt_discovered", { added, total: Object.keys(servers).length })
    return {
      type: "acp.list",
      enabled: !!getConfig().acp?.enabled,
      agents: mgr.listAgents(),
      adopted: added,
    }
  }


YOUR PRIOR REPORT (untrusted assertions to recheck)
## Independent implementation review — #481 / #482 / #483

Frozen vs `abd9995b`. Reviewed from the supplied diff + full ACL / STT-adapter context only. Machine companion + extension tests reported green; browser harness is synthetic HTTP/audio. This is **not** native-desktop, Project-entity, real-ASR, or Windows-runtime acceptance.

Delivery vs claims is honest: overlay `thread.update` ACL is a real narrow expansion; Project / native workbench / resource CRUD are docs-only.

---

### P2 — Overlay dictation is not torn down on `pagehide`

**Trigger:** Start summoner dictation (local/system), close or hide the overlay before stop/cancel.

**What happens:** Meeting capture still does `if (sttLive) stopStt(true)` on `pagehide`. The new `summonerVoice` controller is not cancelled there. Mic tracks, AudioContext, and an in-flight `voice.stt.*` session can outlive the document until idle/infer timeout (end budget is now 305s).

**Why it matters:** The batch’s own contract is privacy + resource cleanup and “取消后丢弃旧结果”. Meeting already had this hook; the new path forgot it. Chromium *may* drop gUM on destroy, but Companion can still hold the STT slot.

**Fix:** `companion/src/summoner-web.ts` `pagehide` / `visibilitychange` — also `summonerVoice.cancel()`. Add a unit case next to the existing start-pending abort test.

---

### P2 — Extension classic+preview reports listening before capture is ready

**Trigger:** Local dictation with `realtimeStreaming` (the path this batch turns on for ordinary classic).

**What happens:** `createLocalSttAdapter` now routes `mode === "classic" && streamPartial` into `runStreamingContinuous`, which calls `handlers.onStart()` **before** `beginPcmStream` / gUM. Old `runClassic` only called `onStart` after capture succeeded. DESIGN / #482: listening starts only when capture is ready; preparing is a distinct state.

**Fix:** `chrome-extension/src/sidepanel/voice/local-stt-adapter.ts` — move `onStart()` to after PCM capture resolves (same as the gUM-success branch in summoner `startLocal`). Keep interim vs `finalChunk` as they are (adapter test correctly emits one final).

---

### P2 — New `thread_id` display filters fail closed on mixed companion/extension versions

**Trigger:** New sidepanel + older Companion (or the reverse) for `coding.git_status` / `acp.apply_diff.result` / `acp.ui_start.*`.

**What happens:** Client now requires `codingMessageTargetsThread` (`thread_id` string === active thread). Git status also requires `d.thread_id === threadId` and exact `workspace_root`. Same-batch Companion stamps `thread_id`. An old binary that omits it yields a blank git line and swallowed apply/start status — even on the owning thread.

**Fix:** Ship companion+extension together. If skew is supported, treat missing `thread_id` as “unknown” only when `session_id` matches the selected session; never treat missing owner as the active thread (current “missing ≠ active” rule is the right default).

---

### P2 — Dismissed coding sessions remain in `codingSessionsById` forever

**Trigger:** Many A/B coding runs in one sidepanel lifetime.

**What happens:** `CLEAR_CODING_SESSION` drops selection only, by design, so a late event cannot resurrect a chip. The record is never pruned. Harmless for this slice; unbounded growth later.

**Fix:** Cap or GC non-selected, non-live, aged records (e.g. same 12s chip window, or on thread delete). Do not re-bind `codingSessionIdByThread` on late events.

---

### NIT — A11y / focus / chrome

- Summoner **分类** uses `.icon-mini` height 28px; DESIGN asks 32px for essential controls (`summoner-web.ts` + `.trow .icon-mini`).
- Successful metadata save focuses the first `.thread-classify`, not the trigger (`thread-management.ts`).
- Alias is not NFC-normalized; tags/folders are (`metadata-patch.ts`). Rename vs 分类 can diverge on composed characters.
- Extension `#482` draft assembly is only proven at the adapter (`voice-classic-preview.test.ts`), not through `useVoiceInput` interim→final. Adapter itself does not double-emit finals.

---

### ACL (#481 T3) — no reject

Shared `summonerThreadMetadata` is an **exact** allowlist (`alias` | `user_tags` | `topic_folder`). Empty object, unknown keys, `__proto__` / `constructor`, `workspace_root`, `config_override`, `tool_whitelist`, mixed `alias`+policy all reject the **whole** patch (no silent strip). HTTP PATCH validates **before** `dispatchAllowed`; WS `applySummonerPayloadPolicy` uses the same function. Unspecified fields are not sent (分类 omits `alias`). No new WS methods, no confirm/approve surface, no overlay terminal/MCP-write/workspace bind via this path. Tray remains ungated (pre-existing, documented).

This **is** an ACL change vs alias-only; it matches the stated low-risk metadata subset.

---

### #483 ownership — holds

Sessions are keyed by `session_id`, owner frozen at first `thread_id`, sparse events cannot borrow the foreground, owner reassignment is ignored. `selectCodingSession` is the single display rule (FocusBand/App/panel). Thread switch closes the panel and does not auto-open B for A’s events; commands send `session_id`+`thread_id` and no-op if `!codingSessionBelongsToThread`. Companion rejects **explicit** mismatch (including `parent_session_id` followup, empty/null owner) **before** confirm/cancel/prompt/apply; omit `thread_id` with empty ctx still operates on the stored owner. Git/pick replies are ignored unless they name this thread; basename matching is gone (correct).

`CLEAR_CODING_SESSION` not resurrecting is covered by tests. Panel `key={activeThreadId}` avoids stale closures. Tests + App harness cover A→B→A, late handback, prompt/cancel/apply targeting B then A.

Legacy omit + **mismatched** `ctx.threadId` would now deny; that is tighter than “omit always works”, but UI send sites in this batch always pass `thread_id`. Acceptable if extension+companion ship together.

---

### #482 voice — holds for the claimed machine bar

Summoner engine comes from **config** (`local` | `system` | `browser`), not a page-promoted engine on the dispatched start payload. Chunks are serialized; `end` waits; HTTP `voice.stt.result` is the only dictation commit; SSE duplicates are swallowed; owner is pinned and polled; switch/cancel drop late finals. Overlay end timeout is 305s (not 8s); classic extension stop uses infer budget, not meeting `stopGraceMs`. Preparing vs listening vs processing copy exists on summoner. Privacy ack, meeting mutex, and ordered upload are tested (synthetic).

Do **not** treat this as measured ASR speedup or Windows SAPI UX.

---

### Scope honesty

`DESIGN.md` + audit + plan correctly separate this batch from Project / #476 native / merged code+terminal / resource editors. CHANGELOG matches. Navigation order and “浏览器标签页” / “资料与工具” are implemented; confirmation DOM/handlers are not rewritten.

---

VERDICT: APPROVE_WITH_NITS


Respond with the actual review and final VERDICT in this answer. Do not announce a plan to inspect later. Every relevant source is embedded above. No tool calls are needed or permitted. Re-evaluate the final delta now, including exact source assertions and the tests.
