Independent implementation review for Issues #481/#482/#483. User authorized Grok4.6 + DeepSeekV4Pro independent gates. T3: narrow overlay thread.update payload expansion from alias-only to alias/user_tags/topic_folder; unknown mixed policy keys rejected by shared HTTP/WS validator, no new WS methods/confirm authority. Fix summoner engine selection, HTTP final dropped, ordered chunks and realistic timeout; extension classic streaming preview/final wait. Code sessions cached by session then selected by thread; background events cannot open foreground, commands explicit owner; backend rejects explicit mismatch but legacy omission remains compatible. Overall UI audit and project proposal are included; Project entity/native desktop/full resource CRUD NOT implemented. Audit actual diff + supplied full context for correctness, security, race/lifecycle, accessibility and regression. Focus on terminal/diff targets, asynchronous callbacks, final text duplication/loss, permissions and payload ACL. Do not treat new files as wired without inspecting call sites. Give severity, concrete trigger/file fix. End VERDICT: APPROVE, APPROVE_WITH_NITS or REJECT. No tools/edits. Machine full companion tests and extension tests passed, browser harness uses synthetic HTTP/audio only. No claim of real ASR speedup or Windows runtime UI acceptance.

FILE DESIGN.md
# Design

## Source of truth
Active · 2026-09-08 · GitHub [#481](https://github.com/nehcuh/cmspark/issues/481).
This is the current UI/UX contract for the extension workspace, summoner, settings,
code panel, terminal, confirmation cockpit, meetings, graphs and tray. It consolidates
#469 / #471 / #473 / #474 / #476 / #477 instead of appending competing layout rules.
`docs/DESIGN.md` retains capability/safety contracts; its older mascot-first,
tiny-chrome and narrow-only presentation is superseded.

Evidence: [workspace audit](docs/audit/2026-09-08-workspace-ux-audit.md).
Scope and proposal: [current repairs and projects](docs/superpowers/plans/2026-09-08-workspace-projects-ux.md).
Native prerequisites: [#476 plan](docs/superpowers/plans/2026-09-08-desktop-workbench.md).
The user prefers Codex's quiet hierarchy. No current Codex screenshot was inspected
for this revision; this is not a pixel-matching or feature-parity claim.

## Brand
Calm, precise, capable. Neutral paper/ink, restrained indigo links/focus, semantic
risk colors. Avoid gradients, decorative counters, dense icon ribbons and large
mascots. Do not reintroduce the decorative 山 mark in summoner empty states.
The static app/extension mark is owned by `scripts/lib/brand-icon.mjs`. The tray
alone represents Companion process state: green solid center running, red hollow
stopped, amber unknown. No tray title or redundant menu header; tooltip and native
accessibility retain words. WebSocket connectivity is separate. Keep macOS,
Windows and extension assets aligned.

## Product goals
Make conversation, prior work and the next action easy to find. Input, recording
feedback, stop and pending confirmation remain reachable. A coding run belongs to
its originating conversation; changing views does not transfer ownership.
The complete #476 desktop workbench supports work without Codex, with optional
programming agents and existing Chrome for web tasks. This is a product goal;
the current Chromium summoner is transitional, not that complete native product.

Current #481 delivery: voice reliability/feedback (#482), coding-session scope
(#483), summoner manual tags/groups using existing metadata, and conversation-first
navigation. Project entities/defaults, a global activity center, merged code/terminal
workspace and native management are future work. No copied Codex assets, mandatory
external agent, blanket permission or automatic live-configuration migration.

## Personas and jobs
Change managers assemble sourced requirements, versions, artifacts, architecture,
runtime, code and test evidence. Developers continue across conversations and
repositories with optional programming agents. Others read websites, dictate a
message or record meetings. Ordinary conversations require no repository or project.

## Information architecture
Current navigation order: new conversation; search/recent conversations with
visible management; supporting resources; settings where actually available.
Use the same order on both surfaces. Preserve existing capability entries.
Name browser tabs “浏览器标签页”; conversation categories remain “标签 / 分组”.
Wide screens have left navigation and one main conversation. Narrow navigation is
a text-triggered, nonmodal, in-flow disclosure. StatusRail is the single header:
title, narrow navigation/new-conversation controls, existing popout/management/
status/more. FocusBand owns priority feedback; its coding slot shows only the
current conversation's session. A background event cannot open another thread's panel.

ThreadList owns extension history, time/tags/manual/AI views, trash and bulk actions.
Recent navigation projects the same store. Summoner uses persisted `user_tags` and
`topic_folder`, not a second grouping store. AI grouping derives from extracted tags
and never rewrites manual grouping. Keep AI extraction, cleanup and graph entries.
Existing resource panels use ContextPanelHost above the composer; summoner resource
attachments retain their current surface until native management lands. Label
“used in this conversation” separately from global configuration. Read-only lists
must not imply edit/install/connect capability. Settings uses one named dialog,
category pages (wide rail/narrow select), stable deep links and mounted forms that
preserve drafts. Pairing/elevated trust remains visible; independent saves stay explicit.

Future proposal: optional Project → Conversation → Execution records. Project is
a durable context with an optional local repository, not a renamed manual folder.
Conversations may remain outside projects. No project UI ships before its real model.

## Design principles
One dominant action per area; supporting controls on demand. Preserve existing
data/execution/confirmation owners. Fix state scope before adding task controls.
Keep completed code results reachable in their conversation; an old run cannot seize
a new conversation's header. Current scope repair does not delete results to simplify UI.
Layout does not grant trust. Confirmation handlers, order/roles, initial focus,
timeout, whitelist, auto-approve defaults and critical evidence retain their contracts.
FocusBand's confirmation/stop priority is authoritative. Cockpit confirmation
DOM/handlers are outside this visual batch. Resizing never grants desktop privileges.

## Visual language
`chrome-extension/src/sidepanel/ui/tokens.ts` owns new React colors; Companion HTML
mirrors the palette without a new bundler. Neutral surfaces, subtle borders,
readable secondary text, charcoal primary composer action and indigo focus.
System sans; body 14–15px, chrome 12–13px, headings 15–24px. Spacing 4/8/12/16/24/32px;
radii 8px controls, 12px cards, 20px composer. Quiet user bubbles, unboxed assistant
prose, shadows only for floating surfaces. Existing SVG icons; no network/font assets.
Terminal uses existing dark tokens. Respect reduced motion.

## Components
Reuse WorkspaceFrame/WorkspaceNavigation, StatusRail, ThreadList/metadata editor,
Modal/tokens, ChatView, ComposerDock, ContextPanelHost and settings pages. Session
selection belongs in shared typed selectors/reducers, not divergent component filters.
Voice state explains preparing/listening/processing/failure next to the mic.
Use explicit scoped classes, not arbitrary inline-style selectors. Share navigation,
copy and data projections with transport adapters when practical; no forced full
React/native rewrite, duplicated thread cache, Agent or confirmation manager.

## Accessibility
Target WCAG 2.2 AA practices: new ordinary text contrast at least 4.5:1, visible
focus, semantic buttons, text alongside risk colors, Enter/Space, Escape and focus
return, no nested interactive elements. Essential controls at least 32px, primary
36px. Preserve live status/destructive copy. Voice animation supplements text and
respects reduced motion. Automated checks are not a conformance certification.

## Responsive behavior
320–759px: full-width conversation, no fixed wide columns; nonmodal navigation
bounded to 36dvh (28dvh below 560px height), independently scrollable. At 760px+:
persistent 220px navigation; conversation reading width up to 780px. ContextPanelHost
is bounded to min(36dvh, 360px), or 28dvh at short height, and yields to confirmation.
Wide settings use a bounded centered dialog. Only message/supporting content shrinks;
composer/stop remain reachable. Long titles wrap/truncate without hiding actions.
Verify 320/390/759/760/1040/1440px widths, 420/480px heights and 200% equivalent reflow.
Summoner default 1040×760, explicit compact 360×420; clamp and retain user resizing.

## Interaction states
Empty suggestions fill, never send. Loading shows the pending action at its source,
never a silent mic. Listening begins only when capture is ready; partial recognition
is distinct from final text. Processing stays visible after stop; failure keeps drafts.
Do not promise hardware-independent transcription latency: record cold/warm setup,
first partial and finalization separately. Save success requires matching persisted
fields/identity, not transport ACK. Switching threads cannot redirect an in-flight
save, transcript, report, approval or session event. Offline offers recovery without
invented completion. Process exit, report import and review approval are distinct.

## Content voice
Chinese product chrome, clear verbs, short labels. Use 对话, 项目 (real entity only),
标签, 分组, 浏览器标签页, 知识, 场景, 设置. Code work may become “代码与终端”;
ACP/PTY details belong inside technical disclosure. Errors point to current settings
labels (“输入与语音”), not stale “设置 → 听写” navigation.

## Implementation constraints
React 18/Plasmo, existing styles/tokens; no new production dependency for this batch.
#481 narrowly expands the authenticated overlay's payload ACL for existing
`thread.update`: only alias/user_tags/topic_folder, using the shared HTTP/WS metadata
patch validator. Unknown fields (including alias plus config) reject the whole patch.
This is an ACL change and a T3 review focus, not an unchanged-policy claim. It
supersedes only #476's scheduling of these low-risk metadata fields; workspace,
trust/config, MCP writes, terminal, install/import and approval remain denied.
Native identity and native confirmation remain prerequisites for privileged #476
work. Current Chrome actions connect/open the existing browser; they are not a
per-operation background guarantee. No profile copying or silent foreground fallback.
Issue-first, owning machine/contract tests, real-render synthetic UI checks, build
and actual independent Grok + DeepSeek gates. Native host behavior, signatures,
microphone performance and Windows runtime need separate evidence. Reports distinguish
current delivery, reviewed design and future capabilities.

## Open questions
- [ ] Project proposal: maintainers to validate optional single-directory defaults,
  migration and storage in a subsequent implementation Issue; no shipped schema here.
- [ ] Native #476 management, Windows host visuals and task-level Chrome visibility
  remain owned by their slices; current repairs cannot close them.
- [ ] Voice #482: measure installed engine/model cold/warm timing before claiming
  the user's performance issue resolved.
- [ ] Resource/settings/meeting/graph improvements in the audit need separately
  tracked changes and surface-specific acceptance; an audit is not implementation.

FILE docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
# 工作空间、项目与对话 UI/UX

关联 [#481](https://github.com/nehcuh/cmspark/issues/481)，修复 [#482](https://github.com/nehcuh/cmspark/issues/482) / [#483](https://github.com/nehcuh/cmspark/issues/483)。
2026-09-08 · 设计与验收约定，待独立复审；不是已实现清单。
视觉规范：[root DESIGN.md](../../../DESIGN.md)。源码：[整体审计](../../audit/2026-09-08-workspace-ux-audit.md)。

## 1. 本次交付与后续提案

用户六项反馈关联到输入状态、对话归属和导航结构；不以一次皮肤调整替代这些问题。

| 范围 | 本次交付与验收 | 后续，不能在本次宣称完成 |
|---|---|---|
| 输入 #482 | 两端启动/失败/处理中可见；修复复现的延迟路径；保留取消、隐私、会议互斥 | 新引擎、无限会议、硬件无关的延迟保证 |
| 编程 #483 | 按 session/thread 处理事件；新对话不出现/自动打开旧代码任务；操作目标不串会话 | 全局活动中心、代码/终端整合、原生终端、多运行持久化产品 |
| 对话分类 | 召唤器人工标签/手动分组；真实保存确认；插件旧整理/图谱功能保留 | 项目数据库、项目继承/批量迁移；召唤器全部 AI 整理和图谱 |
| 导航 | 两端对话优先；搜索/最近/管理在辅助资源之前；术语明确 | 全部资源编辑器重写 |
| 项目 | 本文明确实体、归属、目录与迁移设计 | 不把 topic_folder 改名项目，不放空壳项目入口 |
| 整体 UI/UX | 主要界面源码梳理、统一规范、分阶段可验收清单 | 审计列出的后续改造不能计为本批已交付 |

用户问“项目是否更好”支持设计建议，本次不实施隐式目录继承或自动迁移。#481 完成
指本批修复与审计闭环，不关闭 #476，也不声称项目模型已经实现。

## 2. 本批导航与对话元数据

两端顺序：新对话 → 搜索/最近对话/管理 → 资料与工具 → 设置（实际可用时）。
320–759px 使用有高度上限的非模态导航；顶栏 +、输入、语音状态和停止始终可达。
760px+ 保留 220px 左栏。浏览器 tabs 称“浏览器标签页”，人工 tags 称“标签”。

插件继续由 ThreadList 管时间、标签、手动/AI 分组、批量选择、整理助手、关系图谱
与回收站。召唤器本次接入人工标签/手动组编辑与展示，不声称已补齐全部管理能力。
可输入新组名或选择已有名称，留空移出。保存只锁对应编辑动作；失败保留草稿；
切换对话不能把迟到回执应用给另一行。AI 重提取不得覆盖人工分类。

复用 Thread 和已有 sanitize/persisted response；HTTP/WS 共用
`companion/src/threads/metadata-patch.ts` 的纯验证。现有 `thread.update` 的 overlay
payload ACL 从 alias-only **窄扩展**为 alias/user_tags/topic_folder 精确子集。
HTTP 先校验，再经 dispatchAllowed；WS lifecycle 在通用 router 之前再次应用同一 payload gate。
不新增方法，不透传客户端 updates；未知字段整包拒绝，包含合法 alias 与非法 config
的混合包也不能静默剥离后成功。错误类型、NFC、控制字符、数量/长度上限与服务端一致。
未提交字段不变；尤其不能把未提交 alias 清成空。回执线程 ID 与提交字段匹配才成功。

该排期取代旧 #476 slice 4 将这些元数据全部延后到原生身份的约束。它是需要 T3
复审的实际 ACL 变化；不是“ACL 完全没改”。workspace_root、config/trust、MCP
写入、安装/导入、终端和确认响应均不因此开放。#476 其余原生身份与确认依赖不变。

## 3. 编程运行归属

事实键是启动时的 session_id 和 thread_id，不是当前选中页面。事件先定位相同
session，再更新它自己的字段；不同 session 不继承目标、目录、进度、结果、diff
或本机终端状态。未知会话的稀疏事件不能借用另一会话身份。显示选择器按当前 thread
取对应代码状态，不能每个组件采用不同规则。

- A 开始代码工作后切换/新建 B，A 控制器和顶栏状态不占用 B；迟到的 A 事件不再
  自动打开 B 面板。切回 A 可以在客户端支持的保留范围内查看，不因隐藏取消进程。
- 停止、继续、应用 diff、关闭监视均使用实际 session ID；旧 UI 闭包不能读 B 的
  目录/消息去继续 A。切换时关闭旧编辑视图或重建其上下文，避免混用。
- 关闭一项不清空其他会话；断连不代表完成；已结束的有效结果/diff 入口仍归 A。
- 重载恢复需实际协议验证，不以本批内存作用域修复宣称新增持久恢复产品。

后续可把编程面板/终端整合为“代码与终端”：当前对话运行列表、输出、变更、证据按需
展开；其他对话后台任务在侧栏活动入口显示并跳回所属对话；完成结果放消息卡。此方向
不是本批交付，也不能另造 Agent、确认队列或绕过 #476 原生能力门禁。

## 4. 语音状态与性能证据

区分“准备麦克风/模型”“正在听写”“正在识别最后一段”“失败”。点击后在异步准备
完成前显示反馈，capture 就绪后才能显示正在听写。权限、模型缺失、服务断开分别
给当前设置分类的恢复路径，不能统统提示“打开麦克风”。停止录音与等待 final 分开。
部分识别不冒充终稿、不重复拼接。开始时固定草稿/录音归属，切换/新建/取消/隐藏/
关闭或会议竞争时，旧结果不能写进新草稿。保留隐私确认、会议互斥与音频资源清理。
不因降延迟自动开麦或改用云服务。

记录引擎/模型、冷热启动、请求/capture-ready/first-partial/stop/final 时点。
同机器/录音前后比较，区分固定等待窗与计算耗时。合成测试证明准备/错误/取消/迟到
事件反馈；真实麦克风和模型时延另做实测，不能承诺所有硬件都毫秒级 final。本批可机核的通过条件是：点击所在事件轮次出现准备状态；
合成 final 返回后下一轮状态更新写入所属草稿；录音中支持 partial 预览；正常停止不再使用
8秒通用请求/12秒取消截止。真实机器 final 性能仍需单独前后测量，不据此关闭性能提升主张。

## 5. 后续项目实体设计

### 5.1 层级与最小模型（提案，未成协议）

```text
Project（可选的长期业务/代码范围）
  └─ Thread / 对话（消息、意图、人工分类）
       └─ Execution / 运行记录（ACP、PTY、浏览器执行；产物与来源）
```

| 字段/实体 | 建议语义 |
|---|---|
| Project.id / name | 服务端稳定 ID；改名称不改磁盘目录，目录不作主键 |
| Project.workspace_root? | 当前 Companion 主机的可选规范化绝对目录，可为空 |
| created_at / updated_at / archived_at? | 元数据时间与归档；归档不删除对话、文件或产物 |
| Thread.project_id? | 零或一个项目；空值为项目外对话 |
| Thread.workspace_root? | 保留现有显式线程绑定，允许不同于项目建议目录 |
| user_tags / topic_folder / digest | 原字段不变：人工标签、人工组、AI 索引各司其职 |
| 运行快照 | 创建时固定 thread/project ID（若有）、解析 cwd/仓库根、commit/base/head（适用时） |

新增独立 Project store，不复制 Thread 消息存储。业务项目允许没有目录，如跨系统
变更。首版至多一个建议目录，不自动克隆或创建 worktree；多仓库、远程主机、项目
共享资源/密钥继承另立需求。不额外强制一个“任务容器”，对话承载工作，运行解释执行。

### 5.2 目录建议与授权分离

创建只需名称；可通过既有目录选择/校验添加目录。Git 检测是可选只读提示，remote
URL 不必填，不把带凭据的 URL 写入 UI/日志。选择项目不能触发执行、下载、MCP
allow-dir 扩张或信任提升。项目名称、文件夹标签均不是安全身份。

建议有效目录顺序：显式 thread.workspace_root → 用户选择使用的项目目录 → 既有
默认沙箱。界面显示生效来源；接受项目目录建议仍走既有 workspace binding/安全
检查，不能仅有 project_id 就自动获取访问权限。改项目默认目录不偷偷改已有绑定。
运行前由服务端冻结有效 cwd/仓库，运行中不能随项目设置/activeThread 重绑。目录
失效/非 Git 是可恢复状态；普通业务对话继续，要求仓库/commit 的操作明确报缺失，
不能悄悄落到别的仓库。项目设置本身不授权访问目录中的内容。

### 5.3 创建、移动、归档、恢复

项目内新对话显式带 project_id；全局新对话允许项目外。复用 thread.create owner，
由服务端确认，不能从“最近代码会话”猜项目。建议 Fork 默认保留来源项目（在后续实现 Issue 冻结）并沿用既有目录
复制语义，但不复制运行 ID、活跃权限或待确认挑战。无效/归档项目 ID 有明确校验。

第一版在有运行/待确认时不允许移动对话，解释先结束执行/处理决定再整理。空闲对话
移入/移出项目只改元数据，保留原显式目录并在移动界面说明；换目录是独立操作。历史
审阅结果的 thread/仓库/commit 快照不随移动变化。归档代替级联删除；恢复保持关联。
项目记录损坏/缺失时对话仍可找回并显示“原项目不可用”，不误判为历史已删。并发元
数据编辑需要版本/更新时间冲突检测；原子写和失败恢复方案在实现 Issue 冻结。

### 5.4 旧数据迁移

增加可空字段，不批量重写历史。无 project_id 原样显示项目外，人工组/标签、AI tags、
workspace_root 全保留。可只读扫描相同规范化目录，给“整理到项目”的候选；显式
选中后才建归属。不能把同名 folder 自动变项目、同路径迁移变授权；记录迁移 ID
映射、写入失败不宣称成功，不复制消息或触碰代码文件。

### 5.5 项目验收（后续）

空/无仓库项目、项目外对话；创建/搜索/归档/恢复；重启归属；旧历史零迁移可读；
人工/AI 分类不丢；三种目录来源清晰；运行中目录不重绑；A/B 项目并发/迟到事件/
无效 ID/断连；缺失项目记录仍找回对话；不级联删文件；失败不假保存；需求→开发
对话→仓库/commit→审阅测试→变更材料可反向溯源；无 Codex/外部 Agent/浏览器
时非网页工作仍可开展，属于 #476 原生产品验收，不由项目元数据功能单独承担。未实现项目专属验收项不能宣称项目支持完成。

## 6. 全面 UI/UX 后续顺序

主要面证据与验收见审计：真实项目/归属 → 当前对话代码与终端 → 资源的线程选择/
全局管理分区 → 知识导入/会议渐进展开 → 图谱/独立设置/Cockpit chrome 一致性。
旧会议/独立设置文案等未触及恢复入口列为后续；本次新增语音文案使用实际“输入与语音”分类。
每项另有 Issue 和交互验收，不把更新 DESIGN.md 计为全部页面已重做。
#476 native/MCP/技能/知识/原生确认/浏览器可见性依赖保持；目前 Chrome 按钮只
控制连接/打开，不等于任意任务后台、不抢焦点。窗口宽度不改变权限。

## 7. 当前门禁与外部复审重点

- #482/#483 给根因和前后行为；运行 owning tests，不能只有静态字符串断言。
- 元数据：未知字段/错类型/超长/空组/错线程/保存失败/断连/迟到回执；HTTP 与 WS
  都验证同一精确集合，alias+config 整包拒绝；重载/跨表面可见实际保存结果。
- 真实组件/HTML 合成传输测宽窄/短屏、新建/导航/管理/语音/停止/确认优先。
  这些不证明真实 STT 速度或 Windows 原生效果。
- 冻结代码和证据，实际 Grok + DeepSeek 独立复审并记录模型/结论；空输出、超时、
  tool XML 非批准；阻断修复重审。PR 关联 Issues，当前提交 CI 通过后才称可合并。
- 设计评审核查：当批/未来不混淆；folder 不冒充 project；项目非权限；执行/回执/
  录音不跨对话；overlay payload ACL 窄扩展明确；导航保留旧功能；恢复/窄屏/确认
  可测试；设计通过、实现通过和安装验证分别报告。

FROZEN DIFF vs main abd9995b:
diff --git a/CHANGELOG.md b/CHANGELOG.md
index 88eec867..c00c0ed4 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -1,18 +1,22 @@
 # Changelog
 
 格式大致遵循 [Keep a Changelog](https://keepachangelog.com/)。版本号与 `companion/package.json` / `chrome-extension/package.json` 对齐。
 
 ## [Unreleased]
 
+- 听写修复（#482）：召唤器遵循所选引擎，展示启动/识别状态并接收实际 HTTP 转写结果；音频块按序上传，切换对话及取消后丢弃旧结果。插件普通本机听写复用渐进预览，停止后保留完整推理等待，不再套用连续会议的短截止时间。
+- 代码工作归属修复（#483）：按会话缓存、按对话展示代码运行；后台和迟到事件不打开新对话面板，操作携带所属对话并核对服务端会话，目录选择与 Git 状态回包也按归属隔离。
+- 工作空间整理（#481）：召唤器补齐人工标签/手动分组及派生查看方式，使用共享校验和真实保存回执；两端对话优先、辅助入口收纳为“资料与工具”。完成整体 UI/UX 审计和独立项目层级方案；项目实体、原生完整工作台仍未交付。
+
 - 召唤器工作空间首批（#477 / #476）：宽窗口与紧凑切换、文字资源导航、独立历史搜索、可见停止按钮和现有 Chrome 连接入口；MCP 保持只读，完整桌面管理与终端仍在 #476 跟踪。
 
 - 扩展、应用与托盘采用清晰连接图标；托盘去掉重复状态标题，绿实心运行 / 红空心停止 / 黄未知，保留状态详情与可访问说明（#474）。Windows桌面/开始菜单、安装与卸载器同步使用新应用ICO，并在打包时检查图标资产。
 
 - 对话管理入口与分类（#473）：窄栏顶栏常驻“+”，显式对话管理/AI提取/规则整理/图谱入口；新增独立人工标签、应用内手动分组编辑及按 AI 主标签派生的分组视图。匹配服务端确认后才显示保存成功，管理面板让出停止和待确认操作。
 
 - 召唤器与设置重设计（#471）：删除召唤器所有装饰性“山”，统一聊天输入和操作布局；设置改为八类导航页面，保留草稿和深链，明确保存范围，补齐语音取消及许可证弹窗键盘隔离。
 
 - 整体 UI/UX 工作区重设计（#469）：宽屏常驻导航与可读对话列，窄屏非遮罩导航，统一输入区、历史键盘操作、设置分类和上下文布局；终端、确认台、图谱、召唤窗口和独立设置页同步视觉语言。保持现有确认和执行策略，未发版或替换安装程序。
 
 - 代码审阅开发切片（#465/#466/#467）：从网页观察解析实际 unified diff，锁定仓库和完整 base/head；CMspark 网页评语与可选终端 Agent 报告分别保存，关联真实任务引用和材料版本。终端支持登录 shell、连接归属校验、显式确认回传及幂等回执；不自动执行 Agent。通用网页覆盖与业务关系仍待核实，真实企业双场景验收继续作为发布门槛。
 
diff --git a/DESIGN.md b/DESIGN.md
index 742db141..449c502b 100644
--- a/DESIGN.md
+++ b/DESIGN.md
@@ -1,138 +1,158 @@
 # Design
 
 ## Source of truth
-Active · 2026-09-08 · GitHub #469 / #471. This file owns product-wide UI/UX direction.
-`docs/DESIGN.md` retains detailed capability and safety contracts; this revision
-supersedes its consumer-mascot-first layout, tiny chrome and narrow-only shell.
-Evidence: Sidepanel App, StatusRail, ThreadList, ChatView, ComposerDock,
-ContextPanelHost, SettingsSlideout, shared tokens/Modal, Cockpit, graphs, terminal, capture and standalone web settings.
-No current Codex screenshot was accessed: the reference is the user's stated
-preference for quiet, spacious hierarchy, not a pixel-matching target.
+Active · 2026-09-08 · GitHub [#481](https://github.com/nehcuh/cmspark/issues/481).
+This is the current UI/UX contract for the extension workspace, summoner, settings,
+code panel, terminal, confirmation cockpit, meetings, graphs and tray. It consolidates
+#469 / #471 / #473 / #474 / #476 / #477 instead of appending competing layout rules.
+`docs/DESIGN.md` retains capability/safety contracts; its older mascot-first,
+tiny-chrome and narrow-only presentation is superseded.
+
+Evidence: [workspace audit](docs/audit/2026-09-08-workspace-ux-audit.md).
+Scope and proposal: [current repairs and projects](docs/superpowers/plans/2026-09-08-workspace-projects-ux.md).
+Native prerequisites: [#476 plan](docs/superpowers/plans/2026-09-08-desktop-workbench.md).
+The user prefers Codex's quiet hierarchy. No current Codex screenshot was inspected
+for this revision; this is not a pixel-matching or feature-parity claim.
 
 ## Brand
-Calm, precise, capable. CMspark remains its own identity. Neutral paper and ink,
-text-led summoner without a decorative mark, restrained indigo links/focus, semantic risk colors.
-Avoid promotional dashboards, gradients, oversized mascots, dense icon ribbons,
-unexplained technical acronyms and decorative status lights.
+Calm, precise, capable. Neutral paper/ink, restrained indigo links/focus, semantic
+risk colors. Avoid gradients, decorative counters, dense icon ribbons and large
+mascots. Do not reintroduce the decorative 山 mark in summoner empty states.
+The static app/extension mark is owned by `scripts/lib/brand-icon.mjs`. The tray
+alone represents Companion process state: green solid center running, red hollow
+stopped, amber unknown. No tray title or redundant menu header; tooltip and native
+accessibility retain words. WebSocket connectivity is separate. Keep macOS,
+Windows and extension assets aligned.
 
 ## Product goals
-Make the next action obvious; keep conversation readable; let users find prior
-work and supporting capabilities without remembering hidden menus. Preserve all
-existing functions, confirmations, busy states and honest evidence gaps.
-Success: no horizontal page overflow at 320px; usable content at 1440px; keyboard
-reachable navigation/history/settings; input and stop remain reachable at short
-height; dangerous actions never gain an implicit approval.
-Non-goals: runtime redesign, new permission model, copying Codex assets, release.
+Make conversation, prior work and the next action easy to find. Input, recording
+feedback, stop and pending confirmation remain reachable. A coding run belongs to
+its originating conversation; changing views does not transfer ownership.
+The complete #476 desktop workbench supports work without Codex, with optional
+programming agents and existing Chrome for web tasks. This is a product goal;
+the current Chromium summoner is transitional, not that complete native product.
+
+Current #481 delivery: voice reliability/feedback (#482), coding-session scope
+(#483), summoner manual tags/groups using existing metadata, and conversation-first
+navigation. Project entities/defaults, a global activity center, merged code/terminal
+workspace and native management are future work. No copied Codex assets, mandatory
+external agent, blanket permission or automatic live-configuration migration.
 
 ## Personas and jobs
-Enterprise change manager assembles sourced material across websites; developer
-connects requirements/code/tests and optionally uses a terminal; everyday user
-reads and acts on the current page. Each needs a quiet primary conversation and
-clear separation of supporting configuration from execution.
+Change managers assemble sourced requirements, versions, artifacts, architecture,
+runtime, code and test evidence. Developers continue across conversations and
+repositories with optional programming agents. Others read websites, dictate a
+message or record meetings. Ordinary conversations require no repository or project.
 
 ## Information architecture
-One responsive conversation workspace. At wide width, a quiet left navigation
-shows new conversation, recent conversations and supporting resources. At narrow
-width, navigation opens through the text-labeled header control 导航 as an in-flow, nonmodal disclosure (maximum28dvh, independently scrollable); primary conversation keeps full
-width. Existing full history preserves search, folders, trash and bulk actions.
-StatusRail remains the single conversation header: 导航 (narrow only), task title, existing popout/history/status/more. New conversation uses the existing createBlankThread owner: WorkspaceNavigation on wide screens and a persistent header + below760px (#473). Recent rows are a projection of the existing store, while full history preserves its original owner. Conversation header shows task title (existing title resolver, 新对话 fallback); page/context and pending confirmation stay
-in the existing FocusBand. Knowledge/scenes/skills/MCP/apps/meetings use existing
-ContextPanelHost. The host is already vertically stacked, not a fixed-width side column: preserve that safe layout, cap it to36dvh (28dvh below560px height), and close supporting panels before opening configuration. Do not overlay pending confirmation. Settings is one named dialog with category pages; the #471 refinement below owns its navigation.
-No duplicated data loader, thread cache, Agent or confirmation center.
+Current navigation order: new conversation; search/recent conversations with
+visible management; supporting resources; settings where actually available.
+Use the same order on both surfaces. Preserve existing capability entries.
+Name browser tabs “浏览器标签页”; conversation categories remain “标签 / 分组”.
+Wide screens have left navigation and one main conversation. Narrow navigation is
+a text-triggered, nonmodal, in-flow disclosure. StatusRail is the single header:
+title, narrow navigation/new-conversation controls, existing popout/management/
+status/more. FocusBand owns priority feedback; its coding slot shows only the
+current conversation's session. A background event cannot open another thread's panel.
+
+ThreadList owns extension history, time/tags/manual/AI views, trash and bulk actions.
+Recent navigation projects the same store. Summoner uses persisted `user_tags` and
+`topic_folder`, not a second grouping store. AI grouping derives from extracted tags
+and never rewrites manual grouping. Keep AI extraction, cleanup and graph entries.
+Existing resource panels use ContextPanelHost above the composer; summoner resource
+attachments retain their current surface until native management lands. Label
+“used in this conversation” separately from global configuration. Read-only lists
+must not imply edit/install/connect capability. Settings uses one named dialog,
+category pages (wide rail/narrow select), stable deep links and mounted forms that
+preserve drafts. Pairing/elevated trust remains visible; independent saves stay explicit.
+
+Future proposal: optional Project → Conversation → Execution records. Project is
+a durable context with an optional local repository, not a renamed manual folder.
+Conversations may remain outside projects. No project UI ships before its real model.
 
 ## Design principles
-One dominant action per area. Progressive disclosure keeps tools/details on
-demand; pending confirmation and stop stay visible. Text labels explain navigation.
-Layout changes never change trust policy. Confirmation modifications are limited to shared surface colors, type, spacing and focus visibility; component handlers, button order/roles, initial focus, timeout, whitelist and auto-approve copy/defaults stay unchanged. Decision-critical evidence remains at least as visible as baseline. FocusBand confirmation/stop priority remains authoritative, with no second sticky header. Cockpit is in shared visual-token scope; confirmation DOM/handlers remain byte-unchanged. Small screens are a first-class surface.
+One dominant action per area; supporting controls on demand. Preserve existing
+data/execution/confirmation owners. Fix state scope before adding task controls.
+Keep completed code results reachable in their conversation; an old run cannot seize
+a new conversation's header. Current scope repair does not delete results to simplify UI.
+Layout does not grant trust. Confirmation handlers, order/roles, initial focus,
+timeout, whitelist, auto-approve defaults and critical evidence retain their contracts.
+FocusBand's confirmation/stop priority is authoritative. Cockpit confirmation
+DOM/handlers are outside this visual batch. Resizing never grants desktop privileges.
 
 ## Visual language
-Keep shared `sidepanel/ui/tokens.ts` the only new React color-value owner. Companion HTML constants mirror the palette without a new bundling dependency; their existing transport/permission behavior stays unchanged; #471 updates semantic composer markup and empty-state copy. Neutral
-surfaces and subtle borders, readable secondary text; charcoal primary composer
-action, indigo links/focus. Font system sans; body14–15, chrome12–13, headings
-15–24. Spacing4/8/12/16/24/32; rounded controls8, cards12, composer20.
-Flat navigation, quiet user bubble, unboxed assistant prose, restrained shadows
-for floating surfaces only. Existing SVG icons; no added font/network assets.
-Respect reduced motion and use short feedback transitions.
+`chrome-extension/src/sidepanel/ui/tokens.ts` owns new React colors; Companion HTML
+mirrors the palette without a new bundler. Neutral surfaces, subtle borders,
+readable secondary text, charcoal primary composer action and indigo focus.
+System sans; body 14–15px, chrome 12–13px, headings 15–24px. Spacing 4/8/12/16/24/32px;
+radii 8px controls, 12px cards, 20px composer. Quiet user bubbles, unboxed assistant
+prose, shadows only for floating surfaces. Existing SVG icons; no network/font assets.
+Terminal uses existing dark tokens. Respect reduced motion.
 
 ## Components
-Responsive WorkspaceNavigation plus existing StatusRail/ThreadList; shared
-Workspace styles, tokens and Modal. Conversation/readable-width wrappers,
-ComposerDock, settings sections, tool disclosure cards, ContextPanelHost and
-terminal adopt the same spacing and hierarchy. New classes are explicit, scoped,
-and do not infer semantic roles from arbitrary inline-style selectors.
+Reuse WorkspaceFrame/WorkspaceNavigation, StatusRail, ThreadList/metadata editor,
+Modal/tokens, ChatView, ComposerDock, ContextPanelHost and settings pages. Session
+selection belongs in shared typed selectors/reducers, not divergent component filters.
+Voice state explains preparing/listening/processing/failure next to the mic.
+Use explicit scoped classes, not arbitrary inline-style selectors. Share navigation,
+copy and data projections with transport adapters when practical; no forced full
+React/native rewrite, duplicated thread cache, Agent or confirmation manager.
 
 ## Accessibility
-Target WCAG 2.2 AA practices: text contrast at least4.5:1 for newly styled ordinary text, non-color risk labels, visible
-focus, semantic buttons, keyboard Enter/Space, Escape and focus return for
-drawers/dialogs, no nested interactive elements. Essential controls at least32px
-and primary actions36px; preserve live status and destructive confirmation copy.
-Do not claim formal conformance certification from automated testing.
+Target WCAG 2.2 AA practices: new ordinary text contrast at least 4.5:1, visible
+focus, semantic buttons, text alongside risk colors, Enter/Space, Escape and focus
+return, no nested interactive elements. Essential controls at least 32px, primary
+36px. Preserve live status/destructive copy. Voice animation supplements text and
+respects reduced motion. Automated checks are not a conformance certification.
 
 ## Responsive behavior
-320–759px: full-width chat, nonmodal navigation disclosure, narrow dialogs and no fixed wide
-columns. At760px+: persistent220px navigation, central conversation max780px;
-wide settings use bounded centered dialog. Short screens scroll the content,
-not the entire composer; supporting panel has viewport-relative height cap (min36dvh/360px, or28dvh below560px). Only message space may shrink; if confirmation competes, supporting context must yield.
-Browser zoom and long titles/URLs must wrap or truncate without hiding actions.
+320–759px: full-width conversation, no fixed wide columns; nonmodal navigation
+bounded to 36dvh (28dvh below 560px height), independently scrollable. At 760px+:
+persistent 220px navigation; conversation reading width up to 780px. ContextPanelHost
+is bounded to min(36dvh, 360px), or 28dvh at short height, and yields to confirmation.
+Wide settings use a bounded centered dialog. Only message/supporting content shrinks;
+composer/stop remain reachable. Long titles wrap/truncate without hiding actions.
+Verify 320/390/759/760/1040/1440px widths, 420/480px heights and 200% equivalent reflow.
+Summoner default 1040×760, explicit compact 360×420; clamp and retain user resizing.
 
 ## Interaction states
-Empty state: a short invitation and useful action suggestions; suggestions fill
-input, never send. Loading/streaming keeps stop; errors show recovery near source;
-offline retains explicit reconnect. Selected navigation uses text plus background.
-Confirmation remains distinct from normal tool success; disconnection does not
-invent completion. Details expand deliberately without dumping raw JSON first.
+Empty suggestions fill, never send. Loading shows the pending action at its source,
+never a silent mic. Listening begins only when capture is ready; partial recognition
+is distinct from final text. Processing stays visible after stop; failure keeps drafts.
+Do not promise hardware-independent transcription latency: record cold/warm setup,
+first partial and finalization separately. Save success requires matching persisted
+fields/identity, not transport ACK. Switching threads cannot redirect an in-flight
+save, transcript, report, approval or session event. Offline offers recovery without
+invented completion. Process exit, report import and review approval are distinct.
 
 ## Content voice
-Chinese product chrome, clear verbs, short labels. Prefer 对话/知识/场景/设置.
-Technical detail belongs inside relevant settings or expanded evidence. Never
-relabel an unverified report as approval, a process exit as task success, or a
-permission setting as mere appearance.
+Chinese product chrome, clear verbs, short labels. Use 对话, 项目 (real entity only),
+标签, 分组, 浏览器标签页, 知识, 场景, 设置. Code work may become “代码与终端”;
+ACP/PTY details belong inside technical disclosure. Errors point to current settings
+labels (“输入与语音”), not stale “设置 → 听写” navigation.
 
 ## Implementation constraints
-React18/Plasmo, inline styles plus scoped CSS, existing token owner and icons.
-No new production dependency. Real component browser harness with synthetic
-transport for wide/narrow/short layouts including759/760 breakpoints and200% equivalent CSS-viewport reflow, keyboard, message/tool/confirmation and
-settings flows; production build, full suites and external dual reviews.
-Native Swift/Windows platform chrome cannot be certified by the browser harness;
-shared web surfaces are verified here, native surfaces remain separately tracked.
+React 18/Plasmo, existing styles/tokens; no new production dependency for this batch.
+#481 narrowly expands the authenticated overlay's payload ACL for existing
+`thread.update`: only alias/user_tags/topic_folder, using the shared HTTP/WS metadata
+patch validator. Unknown fields (including alias plus config) reject the whole patch.
+This is an ACL change and a T3 review focus, not an unchanged-policy claim. It
+supersedes only #476's scheduling of these low-risk metadata fields; workspace,
+trust/config, MCP writes, terminal, install/import and approval remain denied.
+Native identity and native confirmation remain prerequisites for privileged #476
+work. Current Chrome actions connect/open the existing browser; they are not a
+per-operation background guarantee. No profile copying or silent foreground fallback.
+Issue-first, owning machine/contract tests, real-render synthetic UI checks, build
+and actual independent Grok + DeepSeek gates. Native host behavior, signatures,
+microphone performance and Windows runtime need separate evidence. Reports distinguish
+current delivery, reviewed design and future capabilities.
 
 ## Open questions
-- [ ] #469: native host-window visuals on Windows require platform validation;
-  owner maintainers. No claim of native cross-platform pixel acceptance.
-- [ ] User can refine density after using the shipped redesign; current default
-  assumes readable enterprise work rather than dense diagnostics.
-
-## 2026-09-08 refinement · #471
-
-The summoner is a lightweight conversation surface using the same neutral chat
-hierarchy and full-width composer above its actions. Remove every decorative 山
-mark from initial and dynamically recreated empty states; no replacement hero.
-Settings uses category navigation and one visible content page (wide left rail,
-narrow select), not navigation chips above a giant accordion. Split voice/input
-and file/knowledge from model configuration. Keep all pages mounted so drafts
-and safety forms survive switching; retain stable deep-link IDs and save semantics.
-Pairing/elevated-trust status remains visible across categories. Root specification:
-`docs/superpowers/plans/2026-09-08-summoner-settings-redesign.md`.
-
-## 2026-09-08 conversation management · #473
-
-Keep the approved chat visual. Narrow headers retain a + button and named conversation management; wide navigation exposes management beside recent conversations. A single ThreadList owns time/tags/manual groups/derived AI groups and visible AI extraction, rules cleanup, graph and trash entry points. Manual labels persist separately from AI digest. AI grouping is a view of the first extracted AI label and can change on re-extraction, never rewriting manual folders. Replies must confirm the matching persisted update and its fields before showing save success. The nonmodal manager stays above the composer and yields immediately to pending confirmations; it never intercepts Stop. Narrow rows put actions below readable titles. See #473 plan and tests.
-
-## Brand assets and tray status (#474)
-
-The extension and macOS app use a static connection-and-spark mark. The tray alone encodes Companion process state: green solid center for running, red hollow center for stopped, amber for unknown. No glow or texture. Geometry and sRGB colors are pinned in `scripts/lib/brand-icon.mjs`; Swift follows the same 24-unit contract and is compared by offscreen render. The app asset uses a dark rounded tile; the extension/tray use transparent backgrounds. Existing chat decorative illustrations remain unchanged.
-
-Tray title is empty and the redundant menu header is removed. Tooltip, native accessibility label and status details retain words; unknown is explicitly “状态未知”. WebSocket connectivity does not change the process-state meaning. Generated 16–32px and Retina assets require visual verification on light/dark backgrounds. See the #474 plan for coordinates, colors and rendering gates.
-
-## 2026-09-08 desktop workspace · #476 / #477
-
-#476 supersedes the lightweight-only product goal for the summoner. The complete
-workbench requires explicit desktop management identity and confirmations before
-sensitive management/terminal actions. #477 is the first UI slice only: a1040x760
-workspace with220px text navigation, compact360x420 user-requested window, visible
-resources and history search. At widths below760px navigation is an in-flow
-bounded disclosure; composer/stop stay outside it. Native hosting, MCP CRUD,
-terminal and complete knowledge/skill editing remain tracked gaps, never claimed
-from restored resource lists. Do not broaden the summoner ACL for this slice.
-Chrome connects the user's existing browser; launch visibility is not a per-task
-background automation guarantee. See the #476 plan for acceptance dependencies.
+- [ ] Project proposal: maintainers to validate optional single-directory defaults,
+  migration and storage in a subsequent implementation Issue; no shipped schema here.
+- [ ] Native #476 management, Windows host visuals and task-level Chrome visibility
+  remain owned by their slices; current repairs cannot close them.
+- [ ] Voice #482: measure installed engine/model cold/warm timing before claiming
+  the user's performance issue resolved.
+- [ ] Resource/settings/meeting/graph improvements in the audit need separately
+  tracked changes and surface-specific acceptance; an audit is not implementation.
diff --git a/chrome-extension/scripts/test-workspace-ui.py b/chrome-extension/scripts/test-workspace-ui.py
index 40688847..3d9168f1 100644
--- a/chrome-extension/scripts/test-workspace-ui.py
+++ b/chrome-extension/scripts/test-workspace-ui.py
@@ -62,25 +62,25 @@ with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
         history.click()
         dialog=page.get_by_role('dialog',name='历史对话列表',exact=True)
         dialog.wait_for()
         page.wait_for_function('document.activeElement?.getAttribute("aria-label")==="搜索线程"')
         row=dialog.get_by_role('button',name='打开 发布 v2.8',exact=False).first
         row.focus();page.keyboard.press('Enter')
         assert not dialog.is_visible()
         assert page.evaluate('window.sent.some(x=>x.type==="thread.select" && x.threadId==="demo-0")')
         history.click();dialog.wait_for();page.wait_for_timeout(100);page.keyboard.press('Escape')
         assert not dialog.is_visible()
         assert history.evaluate('(el)=>el===document.activeElement')
         # Context panel fits the short viewport; closes without losing composer.
-        toggle.click();nav.get_by_role('button',name='知识',exact=True).click()
+        toggle.click();nav.locator('summary').filter(has_text='资料与工具').click();nav.get_by_role('button',name='知识',exact=True).click()
         context=page.get_by_test_id('context-panel-host')
         context.wait_for()
         assert context.bounding_box()['height'] <= 480*.28+2
         assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
         history.click();dialog.wait_for();page.wait_for_timeout(100)
         row=dialog.get_by_role('button',name='打开 发布 v2.8',exact=False).first
         row.focus();page.keyboard.press('Escape')
         assert not dialog.is_visible() and context.is_visible(), 'Escape must close only history'
         history.click();dialog.wait_for();page.wait_for_timeout(100)
         dialog.get_by_title('更多',exact=True).click()
         menu=page.get_by_role('menu').last;menu.wait_for()
         composer.focus();page.keyboard.press('Escape')
@@ -103,26 +103,81 @@ with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
         assert page.get_by_role('complementary',name='工作区',exact=True).bounding_box()['width']==220
         assert page.locator('.cm-chat-content').bounding_box()['width']<=780
         assert page.locator('.cm-composer-dock').bounding_box()['width']<=780
         page.evaluate("window.dispatchEvent(new Event('cmspark:open-coding-handoff'))")
         coding=page.get_by_role('dialog',name='编程接力 面板',exact=True)
         coding.wait_for()
         for width,height in [(1440,900),(320,480)]:
             page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(100)
             rail=page.locator('.cm-status-rail').bounding_box()
             assert coding.bounding_box()['y'] >= rail['y']+rail['height']-1
         coding.get_by_role('button',name='关闭',exact=True).click()
         page.set_viewport_size({'width':1440,'height':900})
+        # #483 actual App owner isolation: A → B → A, including delayed events.
+        page.evaluate("""() => {
+          window.dispatchUI({type:'UPSERT_THREAD',thread:{...window.demoThreads[0],workspace_root:'/repo/owner-a'}});
+          window.dispatchUI({type:'UPSERT_THREAD',thread:{...window.demoThreads[1],workspace_root:'/repo/owner-b'}});
+          window.dispatchUI({type:'ACP_SESSION_EVENT',event:{session_id:'coding-a',thread_id:'demo-0',state:'running',agent_id:'Fixture A',transport:'acp',mode:'propose_diff',workspace_root:'/repo/owner-a',progress_tail:'OWNER_A_PROGRESS'}});
+        }""")
+        coding.wait_for()
+        assert coding.get_by_text('OWNER_A_PROGRESS',exact=True).is_visible()
+        coding.get_by_role('button',name='关闭',exact=True).click()
+        chip=page.get_by_role('status',name='编程助手会话',exact=True)
+        assert chip.is_visible() and 'Fixture A' in chip.inner_text()
+        page.evaluate("window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'demo-1'});window.dispatchUI({type:'SET_MESSAGES',messages:[]})")
+        page.wait_for_function("window.fixtureState.activeThreadId==='demo-1'")
+        assert not coding.is_visible() and not chip.is_visible()
+        page.evaluate("window.dispatchUI({type:'ACP_SESSION_EVENT',event:{session_id:'coding-a',thread_id:'demo-0',state:'closed',progress_tail:'OWNER_A_RETURNED',handback:'A complete',pending_diffs:[{applyable:true}]}})")
+        page.wait_for_timeout(100)
+        assert not coding.is_visible() and not chip.is_visible(), 'A background completion must not open B'
+        page.evaluate("window.dispatchUI({type:'ACP_SESSION_EVENT',event:{session_id:'coding-b',thread_id:'demo-1',state:'running',agent_id:'Fixture B',transport:'acp',workspace_root:'/repo/owner-b',progress_tail:'OWNER_B_PROGRESS'}})")
+        coding.wait_for()
+        assert coding.get_by_text('OWNER_B_PROGRESS',exact=True).is_visible()
+        assert not coding.get_by_text('OWNER_A_RETURNED',exact=True).count()
+        page.evaluate("window.dispatchUI({type:'ACP_SESSION_EVENT',event:{session_id:'coding-a',thread_id:'demo-0',state:'closed',progress_tail:'OWNER_A_LATE'}})")
+        page.wait_for_timeout(100)
+        assert coding.get_by_text('OWNER_B_PROGRESS',exact=True).is_visible(), 'A late event cannot replace B panel'
+        coding.get_by_placeholder('继续对编程助手说…（侧栏监视）',exact=True).fill('Continue owner B')
+        coding.get_by_role('button',name='发送',exact=True).click()
+        coding.get_by_role('button',name='停止编程会话',exact=True).click()
+        assert page.evaluate("window.sent.some(x=>x.type==='acp.session.prompt' && x.session_id==='coding-b' && x.thread_id==='demo-1')")
+        assert page.evaluate("window.sent.some(x=>x.type==='acp.session.cancel' && x.session_id==='coding-b' && x.thread_id==='demo-1')")
+        page.screenshot(path=str(shots/'coding-owner-b.png'))
+        page.evaluate("window.dispatchUI({type:'SET_ACTIVE_THREAD',threadId:'demo-0'});window.dispatchUI({type:'SET_MESSAGES',messages:[]})")
+        page.wait_for_function("window.fixtureState.activeThreadId==='demo-0'")
+        assert not coding.is_visible()
+        assert chip.is_visible() and 'Fixture A' in chip.inner_text() and 'Fixture B' not in chip.inner_text()
+        page.evaluate("window.dispatchEvent(new Event('cmspark:open-coding-handoff'))")
+        coding.wait_for()
+        assert coding.get_by_text('OWNER_A_LATE',exact=True).is_visible()
+        assert not coding.get_by_text('OWNER_B_PROGRESS',exact=True).count()
+        # A delayed B folder/Git reply cannot change A's workspace context.
+        page.evaluate("""() => {
+          window.emitRuntime({type:'workspace.pick_result',thread_id:'demo-1',thread:{id:'demo-1',workspace_root:'/repo/wrong-owner'},path:'/repo/wrong-owner',bound:true});
+          window.dispatchEvent(new CustomEvent('cmspark:coding.git_status',{detail:{thread_id:'demo-1',workspace_root:'/repo/owner-a',is_repo:true,branch:'WRONG_OWNER_BRANCH',dirty_count:99}}));
+        }""")
+        page.wait_for_timeout(100)
+        assert '/repo/wrong-owner' not in coding.inner_text() and 'WRONG_OWNER_BRANCH' not in coding.inner_text()
+        coding.get_by_role('button',name='应用 diff',exact=True).click()
+        assert page.evaluate("window.sent.some(x=>x.type==='acp.apply_diff' && x.session_id==='coding-a' && x.thread_id==='demo-0')")
+        page.screenshot(path=str(shots/'coding-owner-return-a.png'))
+        coding.get_by_role('button',name='关闭',exact=True).click()
+        page.evaluate("window.dispatchUI({type:'CLEAR_CODING_SESSION',sessionId:'coding-a'});window.dispatchUI({type:'CLEAR_CODING_SESSION',sessionId:'coding-b'})")
+        page.wait_for_timeout(100)
+        assert not chip.is_visible()
+        page.evaluate("window.dispatchUI({type:'UPSERT_THREAD',thread:{...window.demoThreads[0],workspace_root:null}});window.dispatchUI({type:'UPSERT_THREAD',thread:{...window.demoThreads[1],workspace_root:null}})")
+        page.evaluate('(messages)=>window.dispatchUI({type:"SET_MESSAGES",messages})',messages)
         # Confirmation queue is still rendered by the unchanged production gate.
         confirmation={'confirmation_id':'fixture-confirm','tool_name':'shell_exec','dangerous_apis':['shell'], 'code_preview':'git diff base..head','risk_level':'high','requested_at':'2026-09-07T10:00:00Z','timeout_ms':45000}
+        page.locator('.cm-nav-tools summary').click()
         page.get_by_role('navigation',name='资源与能力').get_by_role('button',name='知识',exact=True).click()
         page.evaluate('(request)=>window.dispatchUI({type:"ADD_SECURITY_CONFIRMATION",request})',confirmation)
         page.set_viewport_size({'width':320,'height':480})
         page.wait_for_timeout(100)
         assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
         assert composer.bounding_box()['y']+composer.bounding_box()['height'] <= 480
         gate=page.get_by_role('alertdialog').first
         for name in ['允许','拒绝','停止']:
             button=gate.get_by_role('button',name=name,exact=True)
             box=button.bounding_box()
             assert box and 0 <= box['y'] and box['y']+box['height'] <= 480
             assert button.evaluate('(el)=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
@@ -144,13 +199,13 @@ with tempfile.TemporaryDirectory(prefix='cmspark-workspace-') as directory:
         page.screenshot(path=str(shots/'running-320.png'))
         page.evaluate("window.dispatchUI({type:'SET_THREAD_BUSY',threadId:'demo-0',busy:false});window.dispatchUI({type:'SET_CONNECTION',state:'disconnected'})")
         page.get_by_role('button',name='重新连接',exact=True).wait_for()
         assert composer.is_disabled()
         page.screenshot(path=str(shots/'offline-320.png'))
         # 200% equivalent CSS viewport reflow + reduced motion (actual media).
         page.emulate_media(reduced_motion='reduce')
         page.set_viewport_size({'width':720,'height':450})
         assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
         assert page.locator('.cm-workspace').evaluate('(el)=>getComputedStyle(el).scrollBehavior')=='auto'
         assert not errors, errors
         browser.close()
-print('PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, reflow/reduced motion. Synthetic transport only.')
+print('PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, A/B coding ownership and controls, reflow/reduced motion. Synthetic transport only.')
diff --git a/chrome-extension/src/sidepanel/App.tsx b/chrome-extension/src/sidepanel/App.tsx
index 34bc56b9..0eb6a8f0 100644
--- a/chrome-extension/src/sidepanel/App.tsx
+++ b/chrome-extension/src/sidepanel/App.tsx
@@ -20,25 +20,25 @@ import { AtThreadPopover } from "./components/AtThreadPopover"
 import { SkillCraftPanel } from "./components/SkillCraftPanel"
 import { NotebooklmImporterPanel } from "./components/NotebooklmImporterPanel"
 import { StatusRail } from "./components/StatusRail"
 import { ComposerChips } from "./components/ComposerChips"
 import { ComposerCruisePicker } from "./components/ComposerCruisePicker"
 import { WorkspaceFrame } from "./components/WorkspaceFrame"
 import { workspaceCSS } from "./ui/workspace-styles"
 import { ComposerDock } from "./components/ComposerDock"
 import { ComposeDrawer } from "./components/ComposeDrawer"
 import { ThreadRefChips } from "./components/ThreadRefChips"
 import { UploadChips } from "./components/UploadChips"
 import { VoiceBanner } from "./components/VoiceBanner"
-import { AgentStoreProvider, useAgentStore } from "./store/agentStore"
+import { AgentStoreProvider, useAgentStore, selectCodingSession } from "./store/agentStore"
 import type { CapabilityLevel, FileAttachment } from "./types"
 import {
   composerPlaceholder,
   type ComposerChipAction,
 } from "./composer/meta-slash"
 import { tokens } from "./ui/tokens"
 import { PanelBanner, panelBannerBtnStyles } from "./ui/PanelBanner"
 import {
   IconSend,
   IconStop,
   IconAttach,
   IconAlert,
@@ -150,28 +150,36 @@ function AppContent() {
   const [codingPanelSeed, setCodingPanelSeed] = useState<string | undefined>()
 
   useEffect(() => {
     const onOpen = (ev: Event) => {
       const detail = (ev as CustomEvent).detail as { seedGoal?: string } | undefined
       setCodingPanelSeed(detail?.seedGoal)
       setCodingPanelOpen(true)
     }
     window.addEventListener("cmspark:open-coding-handoff", onOpen as EventListener)
     return () => window.removeEventListener("cmspark:open-coding-handoff", onOpen as EventListener)
   }, [])
 
-  // Auto-open panel when a coding session starts (e.g. from offer CTA)
+  const activeCodingSession = selectCodingSession(appState)
+  const codingPanelThreadRef = useRef(appState.activeThreadId)
+  // Background progress never opens the foreground conversation's panel.
   useEffect(() => {
-    if (appState.codingSession) setCodingPanelOpen(true)
-  }, [appState.codingSession?.sessionId])
+    if (codingPanelThreadRef.current !== appState.activeThreadId) {
+      codingPanelThreadRef.current = appState.activeThreadId
+      setCodingPanelOpen(false)
+      setCodingPanelSeed(undefined)
+      return
+    }
+    if (activeCodingSession) setCodingPanelOpen(true)
+  }, [appState.activeThreadId, activeCodingSession?.sessionId])
 
   // Show auto-matched skill toast (#321 PR-3: single queue, no bare setToast)
   useEffect(() => {
     if (appState.autoSkillNames) {
       showToast(`🤖 自动匹配: ${appState.autoSkillNames}`)
       dispatch({ type: "SET_AUTO_SKILLS", names: "" })
     }
   }, [appState.autoSkillNames, showToast, dispatch])
 
   // Capability level (chat / browser / computer) — StatusRail badge, chips / FocusBand
   const onEscalate = useCallback((msg: string) => {
     showToast(msg)
@@ -233,25 +241,26 @@ function AppContent() {
       </div>
 
       <ChatView />
       <FleetWorkerListPortal />
       {/* R3: ComputerTaskBar removed — step timeline only in Cockpit dual-track */}
       {/* #321 PR-1: legacy BottomBar strip deleted (was permanently gated off). Host is SoT. */}
       <ContextPanelHost />
       <InputArea capabilityLevel={level} />
       {showLogs && <LogBar onClose={() => setShowLogs(false)} />}
       <SettingsSlideout />
       {/* Full-height 编程接力 壳 — replaces old task-package-only modal as primary UX */}
       <CodingAgentPanel
-        open={codingPanelOpen}
+        key={appState.activeThreadId || "no-thread"}
+        open={codingPanelOpen && codingPanelThreadRef.current === appState.activeThreadId}
         onClose={() => setCodingPanelOpen(false)}
         workspaceRoot={
           (
             appState.threads.find((t) => t.id === appState.activeThreadId) as
               | { workspace_root?: string | null }
               | undefined
           )?.workspace_root ?? null
         }
         messages={(appState.messages || []) as Array<{ role?: string; content?: string }>}
         pageUrl={(appState as { lastTabUrl?: string }).lastTabUrl || null}
         pageTitle={(appState as { lastTabTitle?: string }).lastTabTitle || null}
         seedGoal={codingPanelSeed}
diff --git a/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx b/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx
index 55d32fd8..4e9b7455 100644
--- a/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx
+++ b/chrome-extension/src/sidepanel/components/CodingAgentPanel.tsx
@@ -12,25 +12,25 @@ import {
 import { tokens } from "../ui/tokens"
 import { codingHandoffCopy } from "../coding-handoff/copy"
 import {
   buildCodingTaskPackage,
   copyTextToClipboard,
   summarizeDialogMessages,
 } from "../coding-handoff/task-package"
 import {
   parseRepoFromUrl,
   formatPageContext,
   cloneCommand,
 } from "../coding-handoff/repo-context"
-import { useAgentStore } from "../store/agentStore"
+import { useAgentStore, selectCodingSession, codingSessionBelongsToThread } from "../store/agentStore"
 import { MinimalConfirm } from "./MinimalConfirm"
 
 /**
  * Progress tail display caps — mirror companion/src/acp/progress-caps.ts.
  * Companion emits PROGRESS_TAIL_CLI_CHARS (12k) for CLI / 2k for ACP;
  * UI shows last PROGRESS_TAIL_DISPLAY_LINES of that tail (dual-synthesis ~200 lines / 64KB intent).
  */
 const PROGRESS_TAIL_CLI_CHARS = 12_000
 const PROGRESS_TAIL_DISPLAY_LINES = 200
 
 /** Last N lines (and at most maxChars) of a progress_tail for the live log pre. */
 function displayProgressTail(
@@ -124,25 +124,25 @@ export function CodingAgentPanel({
   onClose,
   workspaceRoot,
   messages,
   pageUrl,
   pageTitle,
   seedGoal,
   threadId,
   acpEnabled = false,
   acpAgents = [],
   openLocalTerminal = false,
 }: Props) {
   const { state, dispatch } = useAgentStore()
-  const session = state.codingSession
+  const session = threadId === state.activeThreadId ? selectCodingSession(state, threadId) : null
   const confirmQueue = state.pendingSecurityConfirmations
   const pendingConfirm = confirmQueue.length > 0
   const headConfirm = confirmQueue[0]
   // Companion errors also land on processingStatus for ACP
   const externalStatus = state.processingStatus
   /** Store-level enabled flag (updated by acp.list / SET_ACP_LIST). */
   const storeAcpEnabled = state.acpEnabled === true
   /** Prefer prop; fall back to config store (settings optimistically sets coding_handoff). */
   const configOpenLocalTerminal =
     openLocalTerminal ||
     (state.config as { coding_handoff?: { open_local_terminal?: boolean } } | undefined)
       ?.coding_handoff?.open_local_terminal === true
@@ -347,116 +347,115 @@ export function CodingAgentPanel({
   useEffect(() => {
     if (!open) return
     chrome.runtime.sendMessage({ type: "thread.list" }, () => {
       void chrome.runtime.lastError
     })
   }, [open])
 
   // pick_result may arrive via SW before store prop updates — bind optimistically.
   useEffect(() => {
     if (!open) return
     const onMsg = (msg: {
       type?: string
+      thread_id?: string
       thread?: { id?: string; workspace_root?: string | null }
       path?: string
       bound?: boolean
       error?: string
       cancelled?: boolean
     }) => {
       if (msg?.type !== "workspace.pick_result") return
+      const owner = msg.thread_id || msg.thread?.id
+      if (!owner || owner !== threadId) return
       if (msg.error || msg.cancelled) {
         pendingStartAfterPickRef.current = false
         if (startingRef.current) setStarting(false)
         return
       }
       const path =
         (typeof msg.thread?.workspace_root === "string" && msg.thread.workspace_root) ||
         (typeof msg.path === "string" && msg.path) ||
         ""
       if (path.trim()) setLocalWorkspace(path.trim())
     }
     chrome.runtime.onMessage.addListener(onMsg)
     return () => chrome.runtime.onMessage.removeListener(onMsg)
-  }, [open])
+  }, [open, threadId])
 
   /**
    * B-lite S1: fetch git status when workspace is bound.
    * Fail soft — never blocks start. Companion asserts spawn cwd == workspace_root
    * (true today), so we label under 工作区 as agent workspace status.
    */
   useEffect(() => {
     if (!open || !effectiveWorkspace) {
       setGitStatusLine(null)
       return
     }
     // Soft placeholder until response; omit spinner that would feel blocking
     setGitStatusLine("—")
     chrome.runtime.sendMessage(
-      { type: "coding.git_status", workspace_root: effectiveWorkspace },
+      { type: "coding.git_status", thread_id: threadId, workspace_root: effectiveWorkspace },
       () => {
         void chrome.runtime.lastError
       },
     )
-  }, [open, effectiveWorkspace])
+  }, [open, effectiveWorkspace, threadId])
 
   useEffect(() => {
     if (!open) return
     const onGitStatus = (ev: Event) => {
       const d = (ev as CustomEvent).detail as {
         workspace_root?: string | null
+        thread_id?: string
         branch?: string | null
         dirty_count?: number
         is_repo?: boolean
         error?: string
         agent_cwd_is_workspace?: boolean
       } | null
-      if (!d || !effectiveWorkspace) return
-      // Match request path or companion realpath (basename / string equality)
+      if (!d || !effectiveWorkspace || d.thread_id !== threadId) return
+      // Exact canonical workspace match; same basename is not repository identity.
       const returned = typeof d.workspace_root === "string" ? d.workspace_root : ""
       const req = effectiveWorkspace
-      const pathMatch =
-        !returned ||
-        returned === req ||
-        returned.endsWith(req) ||
-        req.endsWith(returned) ||
-        returned.split(/[/\\]/).pop() === req.split(/[/\\]/).filter(Boolean).pop()
+      const pathMatch = !!returned && returned === req
       if (!pathMatch) return
 
       // Only show as agent workspace status when spawn cwd == workspace (true today)
       if (d.agent_cwd_is_workspace === false) {
         setGitStatusLine("工作区状态，非 Agent 目录")
         return
       }
       if (d.error && !d.is_repo) {
         // soft omit / dash — never fake clean
         setGitStatusLine("—")
         return
       }
       if (!d.is_repo) {
         setGitStatusLine("非 git")
         return
       }
       const branch = (d.branch || "HEAD").trim() || "HEAD"
       const dirty =
         typeof d.dirty_count === "number" && d.dirty_count >= 0 ? d.dirty_count : 0
       setGitStatusLine(`${branch} · dirty ${dirty}`)
     }
     window.addEventListener("cmspark:coding.git_status", onGitStatus)
     return () => window.removeEventListener("cmspark:coding.git_status", onGitStatus)
-  }, [open, effectiveWorkspace])
+  }, [open, effectiveWorkspace, threadId])
 
   /** Fire acp.ui_start (Companion still L2-confirms — confirm UI is in this panel). */
   const sendUiStart = useCallback(() => {
     const ws = effectiveWorkspace
-    if (!threadId || !agentId || !ws) {
+    if (!mountedRef.current || threadId !== state.activeThreadId || !threadId || !agentId || !ws) {
       setStarting(false)
       return
     }
     flash("正在启动…请在下方确认条点「允许」")
     const page_context = formatPageContext({
       pageUrl,
       pageTitle,
       repo: repoHint,
     })
     chrome.runtime.sendMessage(
       {
         type: "acp.ui_start",
@@ -487,24 +486,25 @@ export function CodingAgentPanel({
           setStarting(false)
           return
         }
         // Fallback: if no confirm/session/error within 12s, re-enable CTA
         const tid = window.setTimeout(() => {
           if (mountedRef.current && startingRef.current) setStarting(false)
         }, 12000)
         enablePollTimersRef.current.push(tid)
       },
     )
   }, [
     threadId,
+    state.activeThreadId,
     agentId,
     effectiveWorkspace,
     goal,
     mode,
     pageUrl,
     pageTitle,
     repoHint,
     setStoreAcpEnabledFalse,
   ])
 
   /**
    * After config.set acp.enabled=true is *sent*, wait until store reflects enabled
@@ -674,27 +674,27 @@ export function CodingAgentPanel({
     goal,
     sendUiStart,
     waitUntilAcpEnabledThenStart,
   ])
 
   /** CLI transport is one-shot; only ACP keeps multi-turn send. */
   const isCliTransport = session?.transport === "cli"
   const composerDisabled = isCliTransport
 
   const onSend = () => {
     if (composerDisabled) return
     const t = input.trim()
-    if (!t || !session?.sessionId) return
+    if (!t || !session?.sessionId || !codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.session.prompt", session_id: session.sessionId, text: t },
+      { type: "acp.session.prompt", session_id: session.sessionId, thread_id: session.threadId, text: t },
       () => {
         void chrome.runtime.lastError
       },
     )
     setInput("")
   }
 
   const toggleOpenLocalTerminal = useCallback((v: boolean) => {
     dispatch({
       type: "SET_CONFIG",
       config: {
         coding_handoff: {
@@ -702,37 +702,37 @@ export function CodingAgentPanel({
             {}),
           open_local_terminal: v,
         },
       } as any,
     })
     chrome.runtime.sendMessage({
       type: "config.set",
       config: { coding_handoff: { open_local_terminal: v } },
     })
   }, [dispatch, state.config])
 
   const onStop = () => {
-    if (!session?.sessionId) return
+    if (!session?.sessionId || !codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.session.cancel", session_id: session.sessionId },
+      { type: "acp.session.cancel", session_id: session.sessionId, thread_id: session.threadId },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   const onApply = () => {
-    if (!session?.sessionId) return
+    if (!session?.sessionId || !codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.apply_diff", session_id: session.sessionId },
+      { type: "acp.apply_diff", session_id: session.sessionId, thread_id: session.threadId },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   if (!open) return null
 
   const wsBase = effectiveWorkspace
     ? effectiveWorkspace.split(/[/\\]/).filter(Boolean).pop()
     : null
 
@@ -1037,25 +1037,25 @@ export function CodingAgentPanel({
                       : codingHandoffCopy.ctaStopSession}
                   </button>
                 ) : null}
                 {!live && session.hasPendingDiff ? (
                   <button type="button" style={styles.secondary} onClick={onApply}>
                     {codingHandoffCopy.ctaApplyDiff}
                   </button>
                 ) : null}
                 {!live ? (
                   <button
                     type="button"
                     style={styles.linkBtn}
-                    onClick={() => dispatch({ type: "CLEAR_CODING_SESSION" })}
+                    onClick={() => dispatch({ type: "CLEAR_CODING_SESSION", sessionId: session.sessionId })}
                   >
                     清除会话
                   </button>
                 ) : null}
               </div>
             </div>
 
             {session.error ? <div style={styles.err}>{session.error}</div> : null}
 
             {/* Transport honesty: CLI bridge ≠ embedded Claude TUI */}
             {session.transport === "cli" ? (
               <div style={styles.transportNote}>
diff --git a/chrome-extension/src/sidepanel/components/CodingSessionChip.tsx b/chrome-extension/src/sidepanel/components/CodingSessionChip.tsx
index 40ecca0b..857d1d8e 100644
--- a/chrome-extension/src/sidepanel/components/CodingSessionChip.tsx
+++ b/chrome-extension/src/sidepanel/components/CodingSessionChip.tsx
@@ -1,83 +1,86 @@
 // FocusBand chip for live ACP coding handoff — stop ≠ 急停 (CU).
 
 import { useEffect, type CSSProperties } from "react"
 import { tokens } from "../ui/tokens"
 import { codingHandoffCopy } from "../coding-handoff/copy"
 import type { CodingSessionState } from "../store/agentStore"
-import { useAgentStore } from "../store/agentStore"
+import { useAgentStore, codingSessionBelongsToThread } from "../store/agentStore"
 
 export function CodingSessionChip({
   session,
   compact = false,
 }: {
   session: CodingSessionState
   compact?: boolean
 }) {
-  const { dispatch } = useAgentStore()
+  const { state, dispatch } = useAgentStore()
   const live = session.state === "running" || session.state === "offered"
 
   useEffect(() => {
     if (session.state !== "closed") return
     // Do not auto-dismiss while applyable diffs remain (UX: 应用 diff must stay reachable)
     if (session.hasPendingDiff) return
     const t = window.setTimeout(() => {
-      dispatch({ type: "CLEAR_CODING_SESSION" })
+      dispatch({ type: "CLEAR_CODING_SESSION", sessionId: session.sessionId })
     }, 12_000)
     return () => window.clearTimeout(t)
   }, [session.state, session.sessionId, session.hasPendingDiff, dispatch])
   const label = session.displayName || session.agentId || "Agent"
   const modeBadge =
     session.mode === "propose_diff"
       ? codingHandoffCopy.modeBadgeDraft
       : codingHandoffCopy.modeBadgeReview
   const tail = (session.progressTail || "").replace(/\s+/g, " ").trim().slice(0, 80)
   // Authoritative Mode C: only when a host terminal is/was actually involved.
   // Exclude `failed` — then the bridge is the only process (Stop = 停止编程会话).
   const modeCMonitorStop =
     session.localTerminal === "opened" ||
     session.localTerminal === "opened_l0" ||
     session.localTerminal === "pending" ||
     (session.openLocalTerminal === true &&
       session.localTerminal !== "failed" &&
       session.localTerminal !== "skipped")
 
   const onStop = () => {
+    if (!codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.session.cancel", session_id: session.sessionId },
+      { type: "acp.session.cancel", session_id: session.sessionId, thread_id: session.threadId },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   const onFollowup = () => {
+    if (!codingSessionBelongsToThread(session, state.activeThreadId)) return
     const goal = window.prompt("继续追问编程助手（将开新一轮并确认）")
     if (!goal?.trim()) return
     chrome.runtime.sendMessage(
       {
         type: "acp.session.followup",
-        session_id: session.sessionId,
+        session_id: session.sessionId, thread_id: session.threadId,
         goal: goal.trim(),
         mode: session.mode === "propose_diff" ? "propose_diff" : "review_readonly",
       },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   const onApply = () => {
+    if (!codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.apply_diff", session_id: session.sessionId },
+      { type: "acp.apply_diff", session_id: session.sessionId, thread_id: session.threadId },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   return (
     <div style={{ ...styles.row, ...(compact ? styles.compact : {}) }} role="status" aria-label="编程助手会话">
       <div style={styles.meta}>
         <span style={styles.dot} data-live={live ? "1" : "0"} />
         <span style={styles.title}>
           {codingHandoffCopy.productName} · {label} · {modeBadge}
diff --git a/chrome-extension/src/sidepanel/components/CodingSessionShell.tsx b/chrome-extension/src/sidepanel/components/CodingSessionShell.tsx
index 099db48d..9d2f1090 100644
--- a/chrome-extension/src/sidepanel/components/CodingSessionShell.tsx
+++ b/chrome-extension/src/sidepanel/components/CodingSessionShell.tsx
@@ -1,96 +1,99 @@
 // Coding Session Shell — browser-side ACP Client surface (Zed-like, 320px).
 // User stays here for input / timeline / stop — no forced terminal switch.
 
 import { useState, type CSSProperties } from "react"
 import { tokens } from "../ui/tokens"
 import { codingHandoffCopy } from "../coding-handoff/copy"
 import type { CodingSessionState } from "../store/agentStore"
-import { useAgentStore } from "../store/agentStore"
+import { useAgentStore, codingSessionBelongsToThread } from "../store/agentStore"
 
 export type TimelineRow = {
   id?: string
   kind?: string
   label?: string
   detail?: string
   path?: string
   status?: string
   at?: string
 }
 
 export function CodingSessionShell({
   session,
   onClose,
 }: {
   session: CodingSessionState
   onClose?: () => void
 }) {
-  const { dispatch } = useAgentStore()
+  const { state, dispatch } = useAgentStore()
   const [text, setText] = useState("")
   const live = session.state === "running" || session.state === "offered"
   const modeBadge =
     session.mode === "propose_diff"
       ? codingHandoffCopy.modeBadgeDraft
       : codingHandoffCopy.modeBadgeReview
   const timeline = (session.timeline || []) as TimelineRow[]
   // Same Mode C honesty as Chip/Panel (exclude failed — bridge is sole process)
   const modeCMonitorStop =
     session.localTerminal === "opened" ||
     session.localTerminal === "opened_l0" ||
     session.localTerminal === "pending" ||
     (session.openLocalTerminal === true &&
       session.localTerminal !== "failed" &&
       session.localTerminal !== "skipped")
 
   const onStop = () => {
+    if (!codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.session.cancel", session_id: session.sessionId },
+      { type: "acp.session.cancel", session_id: session.sessionId, thread_id: session.threadId },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   /** CLI bridge is one-shot; multi-turn only on ACP transport. */
   const isCliTransport = session.transport === "cli"
   const composerDisabled = isCliTransport
 
   const onSend = () => {
+    if (!codingSessionBelongsToThread(session, state.activeThreadId)) return
     if (composerDisabled) return
     const t = text.trim()
     if (!t) return
     chrome.runtime.sendMessage(
       {
         type: "acp.session.prompt",
-        session_id: session.sessionId,
+        session_id: session.sessionId, thread_id: session.threadId,
         text: t,
       },
       () => {
         void chrome.runtime.lastError
       },
     )
     setText("")
   }
 
   const onApply = () => {
+    if (!codingSessionBelongsToThread(session, state.activeThreadId)) return
     chrome.runtime.sendMessage(
-      { type: "acp.apply_diff", session_id: session.sessionId },
+      { type: "acp.apply_diff", session_id: session.sessionId, thread_id: session.threadId },
       () => {
         void chrome.runtime.lastError
       },
     )
   }
 
   const dismiss = () => {
-    dispatch({ type: "CLEAR_CODING_SESSION" })
+    dispatch({ type: "CLEAR_CODING_SESSION", sessionId: session.sessionId })
     onClose?.()
   }
 
   return (
     <div style={styles.root} role="region" aria-label="编程会话壳">
       <div style={styles.header}>
         <div style={styles.title}>
           {codingHandoffCopy.offerTitle} · {session.displayName || session.agentId} · {modeBadge}
         </div>
         <div style={styles.meta}>
           {live ? codingHandoffCopy.statusRunning : codingHandoffCopy.statusDone}
           {session.transport ? ` · ${session.transport}` : ""}
diff --git a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
index a6c7d258..75b355b4 100644
--- a/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
+++ b/chrome-extension/src/sidepanel/components/ContextPanelHost.tsx
@@ -52,25 +52,25 @@ export type ContextPanelId =
   | "meeting"
 
 export type ContextPanelTabDef = {
   id: ContextPanelId
   label: string
   Icon: ComponentType<{ size?: number }>
 }
 
 /** Canonical panel registry (labels + icons). Strip and Host share this. */
 // #321 PR-5: packs/meeting/board each get their own icon (were all IconSkills
 // collisions); icons come from the existing ui/icons set — nothing new drawn.
 export const CONTEXT_PANEL_TABS: ContextPanelTabDef[] = [
-  { id: "tabs", label: "标签", Icon: IconTabs },
+  { id: "tabs", label: "浏览器标签页", Icon: IconTabs },
   { id: "history", label: "历史", Icon: IconHistory },
   { id: "skills", label: "技能", Icon: IconSkills },
   { id: "knowledge", label: "知识", Icon: IconKnowledge },
   { id: "packs", label: "场景与专家", Icon: IconPacks },
   { id: "meeting", label: "会议", Icon: IconMic },
   { id: "board", label: "任务板", Icon: IconList },
   { id: "mcp", label: "MCP", Icon: IconMcp },
   { id: "apps", label: "应用", Icon: IconApps },
 ]
 
 const KNOWN_IDS = new Set(CONTEXT_PANEL_TABS.map((t) => t.id))
 
diff --git a/chrome-extension/src/sidepanel/components/FocusBand.tsx b/chrome-extension/src/sidepanel/components/FocusBand.tsx
index de266a9f..7529d4dd 100644
--- a/chrome-extension/src/sidepanel/components/FocusBand.tsx
+++ b/chrome-extension/src/sidepanel/components/FocusBand.tsx
@@ -1,21 +1,21 @@
 // FocusBand — Zone B (UIUX v2 PR3 / §4.3) — #321 PR-2「一条 Now」.
 // Single-slot priority: Confirm > L2 Safety+急停 > Coding > Fleet > Thread tools >
 // Worker scope > Run busy > L1 Context > Scene. The former standalone bands
 // (SceneStatusBar / RunBusyChip / WorkerScopeBar) live here as light rows; dark
 // chrome stays exclusive to Confirm/急停. Hard cap ≤80px; 急停 never buried when
 // L2 task active.
 
 import { useState, useEffect, type CSSProperties } from "react"
-import { useAgentStore } from "../store/agentStore"
+import { useAgentStore, selectCodingSession } from "../store/agentStore"
 import type { CapabilityLevel } from "../types"
 import { tokens } from "../ui/tokens"
 import { IconStop } from "../ui/icons"
 import { MinimalConfirm } from "./MinimalConfirm"
 import { SafetyStrip } from "./SafetyStrip"
 import { CodingSessionChip } from "./CodingSessionChip"
 import { ContextStrip } from "./ContextStrip"
 import { FleetStrip } from "./FleetStrip"
 import { SceneStatusRow, readSceneStatus } from "./SceneStatusRow"
 import {
   FOCUS_BAND_MAX_PX,
   FOCUS_BAND_PRIMARY_MAX_PX,
@@ -63,25 +63,25 @@ export function FocusBand({
     classifyFleetActivity({
       workerCount: scoped.workerCount,
       lockCount: scoped.lockCount,
       openIntents: scoped.openIntents,
       worstStatus: scoped.worstStatus,
     }) === "active"
   const isBrowserContext = capabilityLevel === "browser"
   // #au4dch ST-4: long tools must surface in FocusBand (not only chat footer).
   const runningTools = collectRunningTools(state.messages)
   const hasThreadTools = runningTools.length > 0
   const toolsLabel = formatRunningToolsLabel(runningTools)
 
-  const coding = state.codingSession
+  const coding = selectCodingSession(state)
   // Keep chip after close so 追问 / 应用 diff CTAs remain reachable (manager emits state=closed, not handback)
   const hasCodingSession =
     !!coding &&
     (coding.state === "running" ||
       coding.state === "offered" ||
       coding.state === "handback" ||
       coding.state === "closed")
 
   // #321 PR-2「一条 Now」inputs — former standalone bands.
   const scene = readSceneStatus(state)
   const hasScene =
     !!scene.packId || !!scene.workspaceRoot || scene.surfaceLabel != null
diff --git a/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx b/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
index 8f8b832b..87677c93 100644
--- a/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
+++ b/chrome-extension/src/sidepanel/components/WorkspaceFrame.tsx
@@ -41,29 +41,31 @@ export function WorkspaceFrame({ children }: { children: ReactNode }) {
 }
 
 function WorkspaceNavigation({ onNavigate, onClose }: { onNavigate: () => void; onClose?: () => void }) {
   const { state, dispatch } = useAgentStore()
   const { activePanel, openPanelForce, closePanel } = useContextPanelHost()
   const [query, setQuery] = useState("")
   const recent = state.threads.filter(t => !t.trashed_at && displayThreadTitle(t).toLocaleLowerCase().includes(query.toLocaleLowerCase())).sort((a, b) => threadRecency(b).localeCompare(threadRecency(a))).slice(0, 30)
   return <aside className="cm-navigation" aria-label="工作区">
     <div className="cm-nav-brand"><CompanionMark size={24} /><strong>CMspark</strong>
       {onClose && <button type="button" className="cm-icon-button" aria-label="关闭导航" onClick={onClose}>×</button>}
     </div>
     <button type="button" className="cm-nav-new" onClick={() => { createBlankThread(dispatch); onNavigate() }}><IconNewChat size={17} />新对话</button>
-    <nav aria-label="资源与能力" className="cm-nav-resources">
-      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" aria-current={activePanel === id ? "true" : undefined} onClick={() => {
-        dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
-      }}><Icon size={16} /><span>{label}</span></button>)}
-    </nav>
     <div className="cm-nav-section"><span>最近对话</span><button type="button" className="cm-nav-manage" disabled={state.pendingSecurityConfirmations.length > 0} onClick={() => { onNavigate(); window.dispatchEvent(new Event("cmspark:open-thread-manager")) }}>管理对话</button></div>
     <input className="cm-nav-search" aria-label="筛选最近对话" placeholder="查找对话…" value={query} onChange={e => setQuery(e.target.value)} />
     <div className="cm-nav-threads">
       {recent.map(thread => <button type="button" className="cm-nav-thread" key={thread.id} aria-current={thread.id === state.activeThreadId ? "page" : undefined}
         title={displayThreadTitle(thread)} onClick={() => {
           dispatch({ type: "SET_ACTIVE_THREAD", threadId: thread.id }); chrome.runtime.sendMessage({ type: "thread.select", threadId: thread.id }); onNavigate()
         }}><span>{displayThreadTitle(thread)}</span>{state.threadBusyById[thread.id] && <span className="cm-nav-running" aria-label="运行中">·</span>}</button>)}
       {!recent.length && <p className="cm-nav-empty">{query ? "没有匹配的对话" : "新对话会保存在这里"}</p>}
     </div>
+    <details className="cm-nav-tools"><summary>资料与工具</summary>
+    <nav aria-label="资源与能力" className="cm-nav-resources">
+      {CONTEXT_PANEL_TABS.filter(t => t.id !== "history").map(({ id, label, Icon }) => <button type="button" key={id} className="cm-nav-item" aria-current={activePanel === id ? "true" : undefined} onClick={() => {
+        dispatch({ type: "SET_SETTINGS_OPEN", open: false }); openPanelForce(id); onNavigate()
+      }}><Icon size={16} /><span>{label}</span></button>)}
+    </nav>
+    </details>
     <button type="button" className="cm-nav-item cm-nav-settings" onClick={() => { closePanel(); dispatch({ type: "SET_SETTINGS_OPEN", open: true }); onNavigate() }}><IconSettings size={16} />设置</button>
   </aside>
 }
diff --git a/chrome-extension/src/sidepanel/hooks/useVoiceInput.ts b/chrome-extension/src/sidepanel/hooks/useVoiceInput.ts
index f6fe2202..de9af23b 100644
--- a/chrome-extension/src/sidepanel/hooks/useVoiceInput.ts
+++ b/chrome-extension/src/sidepanel/hooks/useVoiceInput.ts
@@ -810,34 +810,33 @@ export function useVoiceInput(opts: UseVoiceInputOpts) {
             code: "system_fallback",
           })
         } else if (systemDegradedRef.current) {
           // #259: configured system but probe/off-win32 → honest browser notice.
           dispatchEv({
             type: "SOFT_CAP_HINT",
             message: SYSTEM_UNAVAILABLE_BROWSER_BANNER,
             code: "system_unavailable",
           })
         }
         try {
           if (eng === "local") {
-            const nearRt =
-              o.realtimeStreaming === true && modeNow === "continuous"
+            const nearRt = o.realtimeStreaming === true
             adapterRef.current.start({
               lang: VOICE_DEFAULT_LANG,
               sessionId: sid,
               modelId: o.modelId || "medium",
               mode: modeNow,
               hardCapMs: maxMs,
               // Shorter windows ≈ near-real-time finals when not streaming.
-              segmentMs: nearRt ? LOCAL_STT_NEAR_REALTIME_SEGMENT_MS : undefined,
+              segmentMs: nearRt && modeNow === "continuous" ? LOCAL_STT_NEAR_REALTIME_SEGMENT_MS : undefined,
               // M2: progressive hypothesis via PCM stream + partial_request.
               streamPartial: nearRt === true,
             })
           } else if (eng === "system") {
             // #259: same capture mechanics as local; adapter stamps
             // engine:"system" on the wire and forces batch segments.
             adapterRef.current.start({
               lang: VOICE_DEFAULT_LANG,
               sessionId: sid,
               mode: modeNow,
               hardCapMs: maxMs,
               streamPartial: false,
diff --git a/chrome-extension/src/sidepanel/hooks/useWebSocket.ts b/chrome-extension/src/sidepanel/hooks/useWebSocket.ts
index d4d58ba1..1b8bf2de 100644
--- a/chrome-extension/src/sidepanel/hooks/useWebSocket.ts
+++ b/chrome-extension/src/sidepanel/hooks/useWebSocket.ts
@@ -14,24 +14,29 @@ import { newTempUserMessageId } from "../../utils/temp-message-id"
 import { knowledgePreviewErrorText, sanitizeKnowledgeSuggestion } from "../utils/knowledge-preview"
 import {
   KNOWLEDGE_DUPLICATE_CONFIRM_PREFIX,
   KNOWLEDGE_DUPLICATE_CONFIRM_SUFFIX,
   KNOWLEDGE_IMPORT_REJECTED_TAIL,
 } from "../utils/knowledge-distribution"
 
 import { normalizeConfig } from "../utils/normalize-config"
 export { normalizeConfig }
 
 const hydrateRetryIds = new Set<string>()
 
+/** Session feedback must carry its stored owner; missing owner never means the active thread. */
+export function codingMessageTargetsThread(msg: { thread_id?: unknown }, threadId: string | null): boolean {
+  return !!threadId && typeof msg.thread_id === "string" && msg.thread_id === threadId
+}
+
 export function isHydrateSelectError(err: string): boolean {
   return /Thread not found/i.test(err)
 }
 
 export function nextHydrateRetry(threadId: string, err: string): "retry" | "fail" | "ignore" {
   if (!threadId || !isHydrateSelectError(err)) return "ignore"
   if (!hydrateRetryIds.has(threadId)) {
     hydrateRetryIds.add(threadId)
     return "retry"
   }
   return "fail"
 }
@@ -1616,40 +1621,43 @@ export function useWebSocket() {
                 session_id: msg.session_id,
                 thread_id: msg.thread_id,
                 state: "closed",
                 mode: msg.mode,
                 pending_diffs: msg.pending_diffs,
                 handback: msg.message?.content,
               },
             })
           }
           break
 
         case "acp.apply_diff.result":
+          if (!codingMessageTargetsThread(msg, activeThreadRef.current)) break
           dispatch({
             type: "SET_PROCESSING_STATUS",
             status: msg.ok
               ? `已应用 ${Array.isArray(msg.applied) ? msg.applied.length : 0} 个文件`
               : `应用 diff 失败: ${msg.error || "unknown"}`,
           })
           break
 
         case "acp.ui_start.accepted":
+          if (!codingMessageTargetsThread(msg, activeThreadRef.current)) break
           // progress follows acp.session.event — keep status for panel feedback
           dispatch({
             type: "SET_PROCESSING_STATUS",
             status: "编程助手已确认启动…",
           })
           break
         case "acp.ui_start.denied":
+          if (!codingMessageTargetsThread(msg, activeThreadRef.current)) break
           dispatch({
             type: "SET_PROCESSING_STATUS",
             status:
               msg.error === "user_denied"
                 ? "编程助手启动已取消"
                 : typeof msg.error === "string" && msg.error
                   ? msg.error
                   : "编程助手启动失败",
           })
           break
 
         case "computer.task.abort.ack":
@@ -2320,24 +2328,26 @@ export function useWebSocket() {
               error: typeof msg.error === "string" && msg.error ? msg.error : "Unknown voice.model error",
             })
             break
           }
           // ACP / coding agent panel — surface in processingStatus (panel rollback/start UX).
           // Must break before generic path that nulls processingStatus (Pi dual R1).
           if (
             msg.family === "acp" ||
             (typeof msg.error === "string" &&
               (/^acp[:.]|acp:\s|编程助手|cloud_disclosure|feature disabled/i.test(msg.error) ||
                 /\bacp\b/i.test(msg.error) && /disabled|未启用|disclosure/i.test(msg.error)))
           ) {
+            if ((msg.session_id !== undefined || msg.thread_id !== undefined) &&
+                !codingMessageTargetsThread(msg, activeThreadRef.current)) break
             dispatch({
               type: "SET_PROCESSING_STATUS",
               status:
                 typeof msg.error === "string" && msg.error
                   ? msg.error
                   : "编程助手错误",
             })
             break
           }
           // App tab (WP4, routing hardened in WP6a): apps.* failures
           // (biometric cancel, policy cap, add-flow validation, …) render in
           // the panel's error area instead of the chat stream — the user is
diff --git a/chrome-extension/src/sidepanel/store/agentStore.tsx b/chrome-extension/src/sidepanel/store/agentStore.tsx
index c6eae832..8100270b 100644
--- a/chrome-extension/src/sidepanel/store/agentStore.tsx
+++ b/chrome-extension/src/sidepanel/store/agentStore.tsx
@@ -72,24 +72,40 @@ export type CodingSessionEvent = {
   goal?: string
   workspace_root?: string
   display_name?: string
   partial?: boolean
   mode?: string
   pending_diffs?: unknown[]
   transport?: string
   timeline?: CodingSessionState["timeline"]
   open_local_terminal?: boolean
   local_terminal?: string
 }
 
+/** Current conversation only; background sessions remain cached for return navigation. */
+export function selectCodingSession(
+  state: Pick<AgentState, "activeThreadId" | "codingSessionsById" | "codingSessionIdByThread">,
+  threadId: string | null = state.activeThreadId,
+): CodingSessionState | null {
+  if (!threadId) return null
+  const id = state.codingSessionIdByThread[threadId]
+  const session = id ? state.codingSessionsById[id] : undefined
+  return session?.threadId === threadId ? session : null
+}
+
+/** A delayed click must never act on a session that belongs to another conversation. */
+export function codingSessionBelongsToThread(session: CodingSessionState | null, threadId: string | null): boolean {
+  return !!session && !!threadId && session.threadId === threadId
+}
+
 export type AcpAgentInfo = {
   id: string
   display_name: string
   enabled: boolean
   profile: string
   command: string
   source?: "config" | "discovered"
 }
 
 export interface AgentState {
   connectionState: ConnectionState
   threads: Thread[]
@@ -273,25 +289,26 @@ export interface AgentState {
   /** Last apps.* error (BIOMETRIC_DENIED / POLICY_CAP_EXCEEDED / ...). */
   appsError: string | null
   /** WP6a (Finding 2): companion platform from apps.list (null = unknown /
    *  pre-WP6a companion → panel keeps the add UI enabled). */
   appsPlatform: string | null
   // 坐标 computer-use(WP4)— computer.task.event 折叠视图 + 全局坐标开关只读镜像。
   /** 当前/最近一个坐标任务的折叠状态(null = 无任务;驱动任务条 + 急停按钮)。 */
   computerTask: ComputerTaskState | null
   /**
    * 编程接力 ACP live session (acp.session.event). null = none.
    * Not L2 computer-use — separate Composition handoff surface.
    */
-  codingSession: CodingSessionState | null
+  codingSessionsById: Record<string, CodingSessionState>
+  codingSessionIdByThread: Record<string, string>
   /** Last acp.list payload (agents + enabled flag). */
   acpAgents: AcpAgentInfo[]
   acpEnabled: boolean
   /** computer.state 只读镜像(null = 尚未查询;WP4 不做面板内全局开关切换)。 */
   computerCoordinateEnabled: boolean | null
   // WP5-I4 实验层模型切片——全部只读镜像,无乐观更新(设置页实验区消费):
   // 每次操作只发 WS 消息,UI 态由 companion state 广播/应答驱动刷新。
   /** computer.model.state 最新镜像(null = 尚未查询;设置页打开时拉一次)。 */
   computerModel: ComputerModelState | null
   /** 最后一条 computer.model.progress(非下载中 state 到达时由 reducer 清除)。 */
   computerModelProgress: ComputerModelProgress | null
   /** license_required 载荷(非 null = 许可证门应弹出;渲染载荷原文)。 */
@@ -514,25 +531,25 @@ export type AgentAction =
   | { type: "TOGGLE_MCP_SERVER"; serverName: string }
   | { type: "SET_MCP_SELECTION_MODE"; mode: McpSelectionMode }
   | { type: "OPEN_MCP_SERVER_FORM"; editing: string | null }
   | { type: "CLOSE_MCP_SERVER_FORM" }
   | { type: "SET_APPS_STATE"; enabled: boolean; entries: AppEntry[]; presets?: AppPresetStatus[]; platform?: string }
   | { type: "SET_APPS_CANDIDATES"; candidates: AppEnumerateCandidate[] | null }
   | { type: "SET_APPS_WARNINGS"; warnings: AppAddWarning[] }
   | { type: "SET_APPS_ERROR"; error: string | null }
   | { type: "COMPUTER_TASK_EVENT"; event: ComputerTaskEventView }
   | { type: "COMPUTER_TASK_ABORT_ACK"; taskId: string; matched: number }
   | { type: "ACP_SESSION_EVENT"; event: CodingSessionEvent }
   | { type: "SET_ACP_LIST"; enabled: boolean; agents: AcpAgentInfo[] }
-  | { type: "CLEAR_CODING_SESSION" }
+  | { type: "CLEAR_CODING_SESSION"; sessionId: string }
   /** Cockpit/panel hydrate from SW mirror — full snapshot, not incremental event. */
   | { type: "HYDRATE_COMPUTER_TASK"; task: ComputerTaskState | null }
   | { type: "HYDRATE_SECURITY_CONFIRMATIONS"; requests: SecurityConfirmationRequest[] }
   | { type: "SET_COMPUTER_COORDINATE_STATE"; enabled: boolean }
   | { type: "SET_COMPUTER_MODEL_STATE"; modelState: ComputerModelState }
   | { type: "SET_COMPUTER_MODEL_PROGRESS"; progress: ComputerModelProgress }
   | { type: "SET_COMPUTER_MODEL_LICENSE_DOOR"; door: ComputerModelLicenseDoor | null }
   | { type: "SET_COMPUTER_MODEL_ERROR"; error: string | null }
   | { type: "SET_VOICE_MODEL_STATE"; modelState: VoiceModelState }
   | { type: "SET_VOICE_SYSTEM_STATE"; systemState: VoiceSystemState | null }
   | { type: "SET_VOICE_MODEL_PROGRESS"; progress: VoiceModelProgress | null }
   | {
@@ -686,25 +703,26 @@ export const initialState: AgentState = {
   mcpSelectionMode: "auto",
   activeMcpServerIds: [],
   mcpServerFormOpen: false,
   mcpServerFormEditing: null,
   appsEnabled: true,
   appEntries: [],
   appPresets: [],
   appCandidates: null,
   appsWarnings: [],
   appsError: null,
   appsPlatform: null,
   computerTask: null,
-  codingSession: null,
+  codingSessionsById: {},
+  codingSessionIdByThread: {},
   acpAgents: [],
   acpEnabled: false,
   computerCoordinateEnabled: null,
   computerModel: null,
   computerModelProgress: null,
   computerModelLicenseDoor: null,
   computerModelError: null,
   voiceModel: null,
   voiceSystemState: null,
   voiceModelProgress: null,
   voiceBinaryProgress: null,
   voiceModelError: null,
@@ -1711,84 +1729,75 @@ export function agentReducer(state: AgentState, action: AgentAction): AgentState
     case "SET_APPS_CANDIDATES":
       return { ...state, appCandidates: action.candidates }
     case "SET_APPS_WARNINGS":
       return { ...state, appsWarnings: action.warnings }
     case "SET_APPS_ERROR":
       return { ...state, appsError: action.error }
     case "COMPUTER_TASK_EVENT":
       // 状态机(含 P4 懒创建/完结后丢弃)全部在纯函数 reduceComputerTaskEvent 里。
       return { ...state, computerTask: reduceComputerTaskEvent(state.computerTask, action.event) }
     case "ACP_SESSION_EVENT": {
       const e = action.event
       if (!e?.session_id) return state
-      const nextState = e.state || state.codingSession?.state || "running"
-      const nextHasPendingDiff = (() => {
-        const pd = (e as any).pending_diffs
-        if (Array.isArray(pd)) {
-          if (pd.length === 0) return false
-          // require explicit applyable:true when field present
-          return pd.some((d: any) => d && d.applyable === true)
-        }
-        return state.codingSession?.hasPendingDiff
-      })()
-      // Drop chip after terminal closed only when no applyable diffs remain
-      if (
-        nextState === "closed" &&
-        state.codingSession?.state === "closed" &&
-        !nextHasPendingDiff &&
-        !state.codingSession?.hasPendingDiff
-      ) {
-        const age = Date.now() - (state.codingSession?.updatedAt || 0)
-        if (age > 12_000) return { ...state, codingSession: null }
+      const previous = state.codingSessionsById[e.session_id]
+      const owner = typeof e.thread_id === "string" && e.thread_id ? e.thread_id : previous?.threadId
+      // An unknown event cannot borrow the current conversation as its owner.
+      if (!owner || (previous && previous.threadId !== owner)) return state
+      const pending = e.pending_diffs
+      const next: CodingSessionState = {
+        sessionId: e.session_id,
+        threadId: owner,
+        agentId: e.agent_id ?? previous?.agentId ?? "",
+        displayName: e.display_name ?? previous?.displayName,
+        state: e.state ?? previous?.state ?? "running",
+        progressTail: e.progress_tail ?? previous?.progressTail,
+        handback: e.handback ?? previous?.handback,
+        error: e.error ?? previous?.error,
+        goal: e.goal ?? previous?.goal,
+        workspaceRoot: e.workspace_root ?? previous?.workspaceRoot,
+        partial: e.partial ?? previous?.partial,
+        updatedAt: Date.now(),
+        mode: e.mode ?? previous?.mode,
+        hasPendingDiff: Array.isArray(pending)
+          ? pending.some((d: any) => d && d.applyable === true)
+          : previous?.hasPendingDiff,
+        transport: e.transport ?? previous?.transport,
+        timeline: Array.isArray(e.timeline) ? e.timeline : previous?.timeline,
+        openLocalTerminal: e.open_local_terminal ?? previous?.openLocalTerminal,
+        localTerminal: e.local_terminal ?? previous?.localTerminal,
       }
       return {
         ...state,
-        codingSession: {
-          sessionId: e.session_id,
-          threadId: e.thread_id || state.codingSession?.threadId || "",
-          agentId: e.agent_id || state.codingSession?.agentId || "",
-          displayName: e.display_name || state.codingSession?.displayName,
-          state: nextState,
-          progressTail: e.progress_tail ?? state.codingSession?.progressTail,
-          handback: e.handback ?? state.codingSession?.handback,
-          error: e.error ?? state.codingSession?.error,
-          goal: e.goal ?? state.codingSession?.goal,
-          workspaceRoot: e.workspace_root ?? state.codingSession?.workspaceRoot,
-          partial: e.partial ?? state.codingSession?.partial,
-          updatedAt: Date.now(),
-          mode: (e as any).mode ?? state.codingSession?.mode,
-          hasPendingDiff: nextHasPendingDiff,
-          transport: (e as any).transport ?? state.codingSession?.transport,
-          timeline: Array.isArray((e as any).timeline)
-            ? (e as any).timeline
-            : state.codingSession?.timeline,
-          openLocalTerminal:
-            typeof (e as any).open_local_terminal === "boolean"
-              ? (e as any).open_local_terminal
-              : state.codingSession?.openLocalTerminal,
-          localTerminal:
-            typeof (e as any).local_terminal === "string"
-              ? (e as any).local_terminal
-              : state.codingSession?.localTerminal,
+        codingSessionsById: { ...state.codingSessionsById, [next.sessionId]: next },
+        // A late event for an older session updates its own record, without
+        // replacing a newer session in the same conversation.
+        codingSessionIdByThread: previous ? state.codingSessionIdByThread : {
+          ...state.codingSessionIdByThread, [owner]: next.sessionId,
         },
       }
     }
     case "SET_ACP_LIST":
       return {
         ...state,
         acpEnabled: action.enabled === true,
         acpAgents: Array.isArray(action.agents) ? action.agents : [],
       }
-    case "CLEAR_CODING_SESSION":
-      return { ...state, codingSession: null }
+    case "CLEAR_CODING_SESSION": {
+      const session = state.codingSessionsById[action.sessionId]
+      if (!session || state.codingSessionIdByThread[session.threadId] !== action.sessionId) return state
+      const selection = { ...state.codingSessionIdByThread }
+      delete selection[session.threadId]
+      // Retain the record so delayed progress cannot resurrect a dismissed chip.
+      return { ...state, codingSessionIdByThread: selection }
+    }
     case "COMPUTER_TASK_ABORT_ACK": {
       // matched>0 才置位;task_id="*"(急停全部)对当前任务同样生效。
       const t = state.computerTask
       if (!t || action.matched <= 0) return state
       if (t.taskId !== action.taskId && action.taskId !== "*") return state
       return { ...state, computerTask: { ...t, abortAcked: true } }
     }
     case "HYDRATE_COMPUTER_TASK":
       return { ...state, computerTask: action.task }
     case "HYDRATE_SECURITY_CONFIRMATIONS":
       return {
         ...state,
diff --git a/chrome-extension/src/sidepanel/ui/workspace-styles.ts b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
index 77f1dcb3..dd10ca00 100644
--- a/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -2,24 +2,25 @@ import { tokens } from "./tokens"
 
 /** Scoped shell styles; colors remain owned by tokens.ts. */
 export const workspaceCSS = `
 .cm-workspace{display:flex;height:100dvh;min-height:0;width:100%;overflow:hidden;background:${tokens.bg};font-family:${tokens.font};color:${tokens.text}}
 .cm-workspace-main{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;position:relative}
 .cm-navigation{width:220px;height:100%;box-sizing:border-box;flex-shrink:0;display:flex;flex-direction:column;padding:20px 12px 12px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};gap:6px;overflow-y:auto}
 [aria-label="工作区导航"] .cm-navigation{width:100%}
 .cm-nav-brand{display:flex;align-items:center;gap:10px;padding:0 8px 20px;font-size:15px;letter-spacing:-.03em}
 .cm-nav-brand .cm-icon-button{margin-left:auto}
 .cm-nav-new,.cm-nav-item,.cm-nav-thread{font:inherit;border:0;border-radius:${tokens.radiusMd}px;cursor:pointer;display:flex;align-items:center;gap:10px;text-align:left;min-height:36px;width:100%;padding:8px 10px;color:${tokens.text};background:transparent;font-size:13px;flex-shrink:0}
 .cm-nav-new{background:${tokens.bgElevated};border:1px solid ${tokens.border};margin-bottom:10px;font-weight:500}
 .cm-nav-item:hover,.cm-nav-thread:hover,.cm-icon-button:hover{background:${tokens.bgHover}}
+.cm-nav-tools{flex:none;border-top:1px solid ${tokens.border};margin-top:8px}.cm-nav-tools summary{cursor:pointer;min-height:36px;padding:10px 4px;font-size:12px}.cm-nav-tools summary:focus-visible{outline:2px solid currentColor;outline-offset:2px}
 .cm-nav-resources{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-bottom:16px}
 .cm-nav-resources .cm-nav-item{font-size:12px;gap:6px;padding:8px 6px;min-width:0}
 .cm-nav-resources .cm-nav-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
 .cm-nav-section{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:${tokens.textSecondary};padding:0 8px}
 .cm-nav-search{box-sizing:border-box;width:100%;border:1px solid ${tokens.border};border-radius:${tokens.radiusMd}px;padding:9px 10px;font:inherit;font-size:12px;background:${tokens.bgElevated};color:${tokens.text}}
 .cm-nav-threads{flex:1;min-height:80px;overflow-y:auto;margin-top:4px}
 .cm-nav-thread{min-height:38px;color:${tokens.textSecondary}}
 .cm-nav-thread>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
 .cm-nav-item[aria-current="true"],.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
 .cm-nav-running{color:${tokens.success};font-size:20px}
 .cm-nav-empty{font-size:12px;color:${tokens.textSecondary};padding:8px}
 .cm-nav-settings{margin-top:12px;border-top:1px solid ${tokens.border};border-radius:0;padding-top:14px}
diff --git a/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts b/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
index efa338ef..c0b9d571 100644
--- a/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
+++ b/chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
@@ -199,37 +199,41 @@ export function createLocalSttAdapter(
       clearTimeout(partialTimer)
       partialTimer = null
     }
   }
 
   const clearPendingTimer = () => {
     if (pendingTimer) {
       clearTimeout(pendingTimer)
       pendingTimer = null
     }
   }
 
-  const pendingWaitMs = () => (wantListening ? pendingTimeoutMs : Math.min(stopGraceMs, pendingTimeoutMs))
+  const pendingWaitMs = () => {
+    const budget = deps.pendingTimeoutMs ?? (modelId === "large-v3-turbo" ? 305_000 : pendingTimeoutMs)
+    // Ending an ordinary recording is the normal route to its final, not cancellation.
+    return mode === "classic" || wantListening ? budget : Math.min(stopGraceMs, budget)
+  }
 
   const armPendingTimer = (sid: string) => {
     clearPendingTimer()
     const ms = pendingWaitMs()
     pendingTimer = setTimeout(() => {
       pendingTimer = null
       if (!pending || pending.sessionId !== sid) return
       // Still listening: surface infer_timeout (soft streak). After user stop:
       // empty_result so the loop can onEnd without a scary banner.
       finishPending({
         ok: false,
-        code: wantListening ? "infer_timeout" : "empty_result",
+        code: mode === "classic" || wantListening ? "infer_timeout" : "empty_result",
       })
     }, ms)
   }
 
   const clearSub = () => {
     if (unsub) {
       try {
         unsub()
       } catch {
         /* */
       }
       unsub = null
@@ -780,25 +784,25 @@ export function createLocalSttAdapter(
           // Window commit: one finalChunk for the whole window text
           handlers.onResult({
             interim: "",
             finalChunk: result.text.trim(),
             ...(result.postprocessed === true ? { postprocessed: true } : {}),
           })
           streamStable = result.text.trim()
         } else {
           softFailStreak = 0
           handlers.onResult({ interim: "", finalChunk: "" })
         }
 
-        if (!wantListening || aborted) break
+        if (!wantListening || aborted || mode === "classic") break
         handlers.onSegmentContinue?.()
       }
 
       if (!dead) handlers.onEnd()
       reset()
     } catch {
       if (!dead) {
         handlers.onError("unknown")
         handlers.onEnd()
       }
       reset()
     }
@@ -959,25 +963,25 @@ export function createLocalSttAdapter(
         if (typeof (langOrOpts as { hardCapMs?: number }).hardCapMs === "number") {
           hardCapMs = (langOrOpts as { hardCapMs: number }).hardCapMs
         }
         if (typeof (langOrOpts as { segmentMs?: number }).segmentMs === "number") {
           segmentCapMs = Math.max(
             20,
             Math.min(LOCAL_STT_MAX_RECORD_MS, (langOrOpts as { segmentMs: number }).segmentMs),
           )
         }
         if ((langOrOpts as { streamPartial?: boolean }).streamPartial === true) {
           streamPartial = true
           // Prefer near-realtime segment defaults when streaming
-          if (segmentCapMs >= LOCAL_STT_MAX_RECORD_MS) {
+          if (mode === "continuous" && segmentCapMs >= LOCAL_STT_MAX_RECORD_MS) {
             segmentCapMs = LOCAL_STT_NEAR_REALTIME_SEGMENT_MS
           }
         }
         // large-v3-turbo: progressive re-decode is too heavy (loads full model often).
         // Force final-only continuous windows even if caller asked for streamPartial.
         if (mid === "large-v3-turbo" || modelId === "large-v3-turbo") {
           streamPartial = false
           segmentCapMs = LOCAL_STT_MAX_RECORD_MS
         }
         // #259: SAPI is batch — no progressive hypotheses for system sessions.
         if (deps.engineKind === "system") {
           streamPartial = false
@@ -985,46 +989,54 @@ export function createLocalSttAdapter(
         }
       }
 
       if (!sid) {
         handlers.onError("session_busy")
         handlers.onEnd()
         return
       }
 
       parentSessionId = sid
       sessionId = sid
       modelId = mid || deps.modelId || ""
+      if (mode === "classic" && streamPartial) {
+        // Progressive preview for ordinary dictation, with one bounded final.
+        // Leave transport/drain time before the daemon's 45 s recording lease expires.
+        hardCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
+        segmentCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
+      }
       ensureSub()
       phase = "recording"
       wallStart = Date.now()
       segmentIndex = 0
       loopGen += 1
       const gen = loopGen
 
-      if (mode === "continuous") {
+      if (streamPartial) {
+        void runStreamingContinuous(gen)
+      } else if (mode === "continuous") {
         void runContinuous(gen)
       } else {
         void runClassic(sid)
       }
     },
 
     stop() {
       if (dead) return
       if (phase === "idle") return
 
       wantListening = false
 
       // Continuous: finish current segment early, then exit after upload / end stream
-      if (mode === "continuous") {
+      if (mode === "continuous" || streamPartial) {
         if (phase === "recording") {
           // N3: if window wait not armed yet (still in gUM), mark pending soft stop
           if (!segmentStopTrigger) {
             pendingSoftStop = true
           }
           segmentStopTrigger?.()
         }
         // Waiting for companion infer: re-arm with stopGrace so a dead
         // Companion (SIGTERM mid-window) cannot leave the mic/UI hung.
         if ((phase === "waiting" || phase === "uploading") && pending && sessionId) {
           armPendingTimer(sessionId)
         }
diff --git a/chrome-extension/tests/coding-session-owner-483.test.ts b/chrome-extension/tests/coding-session-owner-483.test.ts
new file mode 100644
index 00000000..0b067cac
--- /dev/null
+++ b/chrome-extension/tests/coding-session-owner-483.test.ts
@@ -0,0 +1,75 @@
+import test from "node:test"
+import assert from "node:assert/strict"
+import { agentReducer, initialState, selectCodingSession, codingSessionBelongsToThread, type AgentState, type CodingSessionEvent } from "../src/sidepanel/store/agentStore"
+import { codingMessageTargetsThread } from "../src/sidepanel/hooks/useWebSocket"
+
+function event(state: AgentState, value: CodingSessionEvent): AgentState {
+  return agentReducer(state, { type: "ACP_SESSION_EVENT", event: value })
+}
+function switchTo(state: AgentState, threadId: string): AgentState {
+  return agentReducer(state, { type: "SET_ACTIVE_THREAD", threadId })
+}
+
+test("A task remains in A when creating B; background handback updates A and return restores it", () => {
+  let state = event(switchTo(initialState, "a"), {
+    session_id: "sa", thread_id: "a", state: "running", workspace_root: "/repo/a", goal: "review A",
+  })
+  state = switchTo(state, "b")
+  assert.equal(selectCodingSession(state), null)
+  state = event(state, { session_id: "sa", thread_id: "a", state: "closed", handback: "A findings", pending_diffs: [{ applyable: true }] })
+  assert.equal(selectCodingSession(state), null)
+  state = switchTo(state, "a")
+  assert.equal(selectCodingSession(state)?.handback, "A findings")
+  assert.equal(selectCodingSession(state)?.workspaceRoot, "/repo/a")
+  assert.equal(selectCodingSession(state)?.hasPendingDiff, true)
+})
+
+test("a new session never inherits another session's mode, diff, workspace or terminal flags", () => {
+  let state = event(switchTo(initialState, "a"), {
+    session_id: "sa", thread_id: "a", state: "closed", mode: "propose_diff", workspace_root: "/repo/a", handback: "private A", pending_diffs: [{ applyable: true }], open_local_terminal: true,
+  })
+  state = event(switchTo(state, "b"), { session_id: "sb", thread_id: "b", state: "running" })
+  const selected = selectCodingSession(state)!
+  for (const key of ["mode", "hasPendingDiff", "workspaceRoot", "handback", "openLocalTerminal"] as const) assert.equal(selected[key], undefined)
+  assert.equal(selected.threadId, "b")
+})
+
+test("late prior-session events and stale dismiss timers cannot replace or dismiss a newer session", () => {
+  let state = event(switchTo(initialState, "a"), { session_id: "old", thread_id: "a", state: "closed" })
+  state = event(state, { session_id: "new", thread_id: "a", state: "running" })
+  state = event(state, { session_id: "old", thread_id: "a", state: "closed", handback: "late" })
+  state = agentReducer(state, { type: "CLEAR_CODING_SESSION", sessionId: "old" })
+  assert.equal(selectCodingSession(state)?.sessionId, "new")
+  assert.equal(state.codingSessionsById.old.handback, "late")
+})
+
+test("unknown ownerless events are ignored; known partial events use only their existing owner", () => {
+  const active = switchTo(initialState, "b")
+  assert.equal(event(active, { session_id: "unknown", state: "running" }), active)
+  let state = event(active, { session_id: "sa", thread_id: "a", state: "running" })
+  state = event(state, { session_id: "sa", progress_tail: "progress" })
+  assert.equal(selectCodingSession(state), null)
+  assert.equal(state.codingSessionsById.sa.threadId, "a")
+  assert.equal(event(state, { session_id: "sa", thread_id: "b", handback: "forged ownership" }), state)
+})
+
+test("dismiss is scoped and late progress cannot resurrect a dismissed session", () => {
+  let state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "closed" })
+  state = event(state, { session_id: "sb", thread_id: "b", state: "running" })
+  state = agentReducer(state, { type: "CLEAR_CODING_SESSION", sessionId: "sa" })
+  state = event(state, { session_id: "sa", state: "closed" })
+  assert.equal(selectCodingSession(state), null)
+  assert.equal(selectCodingSession(state, "b")?.sessionId, "sb")
+})
+
+test("commands and result feedback require an exact nonempty conversation owner", () => {
+  const state = event(switchTo(initialState, "a"), { session_id: "sa", thread_id: "a", state: "running" })
+  const session = selectCodingSession(state)
+  assert.equal(codingSessionBelongsToThread(session, "a"), true)
+  assert.equal(codingSessionBelongsToThread(session, "b"), false)
+  assert.equal(codingSessionBelongsToThread(session, null), false)
+  assert.equal(codingMessageTargetsThread({ thread_id: "a" }, "a"), true)
+  assert.equal(codingMessageTargetsThread({ thread_id: "a" }, "b"), false)
+  assert.equal(codingMessageTargetsThread({}, "b"), false)
+  assert.equal(codingMessageTargetsThread({ thread_id: "" }, null), false)
+})
diff --git a/chrome-extension/tests/voice-classic-preview.test.ts b/chrome-extension/tests/voice-classic-preview.test.ts
new file mode 100644
index 00000000..36364779
--- /dev/null
+++ b/chrome-extension/tests/voice-classic-preview.test.ts
@@ -0,0 +1,60 @@
+import test from "node:test"
+import assert from "node:assert/strict"
+import { createLocalSttAdapter } from "../src/sidepanel/voice/local-stt-adapter"
+import type { PcmStreamCaptureOpts } from "../src/sidepanel/voice/pcm-stream-capture"
+
+const turn = () => new Promise<void>((resolve) => setTimeout(resolve, 0))
+
+test("#482 ordinary local dictation previews during recording, then commits one final on stop", async () => {
+  const sent: any[] = [], results: { interim: string; finalChunk: string }[] = []
+  let receive: (msg: any) => void = () => {}, capture: PcmStreamCaptureOpts | undefined
+  let ends = 0, stops = 0
+  const adapter = createLocalSttAdapter({
+    onStart() {}, onResult: (r) => results.push(r), onError: (e) => { throw new Error(e) }, onEnd: () => { ends++ },
+  }, {
+    modelId: "medium", send: (msg) => sent.push(msg),
+    onMessage: (h) => { receive = h; return () => { receive = () => {} } },
+    startCapture: async () => { throw new Error("batch capture should not run") },
+    startPcmStreamCapture: async (opts) => { capture = opts; return { backend: "scriptprocessor", stop: async () => { stops++ }, abort() {} } },
+    pendingTimeoutMs: 200, stopGraceMs: 1,
+  })
+  try {
+    adapter.start({ sessionId: "classic-preview", mode: "classic", streamPartial: true })
+    await turn()
+    const start = sent.find((m) => m.type === "voice.stt.start")
+    assert.equal(start.format, "pcm_s16le"); assert.equal(start.privacy_ack_v2, true)
+    assert.ok(start.maxMs <= 45_000 && start.maxMs > 40_000)
+    capture!.onPcmChunk(new Uint8Array(32000))
+    receive({ type: "voice.stt.partial", sessionId: start.sessionId, status: "hypothesis", text: "听写预览" })
+    assert.deepEqual(results, [{ interim: "听写预览", finalChunk: "" }])
+    assert.equal(sent.some((m) => m.type === "voice.stt.end"), false)
+    adapter.stop(); await turn()
+    const end = sent.find((m) => m.type === "voice.stt.end")
+    assert.equal(end.totalSeq, 1)
+    // Classic stop is normal finalization, so the short continuous stop-grace cannot discard it.
+    await new Promise((r) => setTimeout(r, 15))
+    assert.equal(ends, 0)
+    receive({ type: "voice.stt.result", sessionId: start.sessionId, text: "最终听写" })
+    await turn()
+    assert.equal(ends, 1); assert.equal(stops, 1)
+    assert.deepEqual(results.map((r) => r.finalChunk).filter(Boolean), ["最终听写"])
+    assert.equal(sent.filter((m) => m.type === "voice.stt.start").length, 1)
+  } finally { adapter.destroy() }
+})
+
+test("#482 cancel ordinary streaming dictation discards a late final", async () => {
+  const sent: any[] = [], finals: string[] = []
+  let receive: (msg: any) => void = () => {}, capture: PcmStreamCaptureOpts | undefined
+  const adapter = createLocalSttAdapter({ onStart() {}, onError() {}, onEnd() {}, onResult: (r) => { if (r.finalChunk) finals.push(r.finalChunk) } }, {
+    modelId: "small", send: (m) => sent.push(m), onMessage: (h) => { receive = h; return () => {} },
+    startPcmStreamCapture: async (opts) => { capture = opts; return { backend: "scriptprocessor", stop: async () => {}, abort() {} } },
+  })
+  try {
+    adapter.start({ sessionId: "cancel-preview", mode: "classic", streamPartial: true }); await turn()
+    capture!.onPcmChunk(new Uint8Array(32000)); adapter.stop(); await turn()
+    const end = sent.find((m) => m.type === "voice.stt.end")
+    adapter.abort(); receive({ type: "voice.stt.result", sessionId: end.sessionId, text: "不应写入" }); await turn()
+    assert.deepEqual(finals, [])
+    assert.ok(sent.some((m) => m.type === "voice.stt.abort" && m.sessionId === end.sessionId))
+  } finally { adapter.destroy() }
+})
diff --git a/chrome-extension/tests/voice-local-stt-adapter-ws.test.ts b/chrome-extension/tests/voice-local-stt-adapter-ws.test.ts
index 3e6e8563..d811fbe2 100644
--- a/chrome-extension/tests/voice-local-stt-adapter-ws.test.ts
+++ b/chrome-extension/tests/voice-local-stt-adapter-ws.test.ts
@@ -588,52 +588,55 @@ test("error from companion while waiting: maps code", async () => {
     code: "model_missing",
     message: "no model",
   })
   await new Promise((r) => setTimeout(r, 5))
 
   assert.ok(events.includes("error:model_missing"))
   assert.ok(events.includes("end"))
   assert.ok(!events.includes("result"))
 
   adapter.destroy()
 })
 
-test("classic: companion never ACKs end → stop still fires onEnd after stopGrace", async () => {
+test("classic: final gets its inference budget, then reports a missing ACK as timeout", async () => {
   const wav = silentWav()
   const events: string[] = []
   const adapter = createLocalSttAdapter(
     {
       onStart: () => events.push("start"),
       onResult: () => events.push("result"),
       onError: (c) => events.push(`error:${c}`),
       onEnd: () => events.push("end"),
       onCaptureStopped: () => events.push("capture_stopped"),
     },
     {
       send: () => {},
       onMessage: () => () => {},
       modelId: "medium",
       startCapture: fakeCaptureFactory(wav),
-      pendingTimeoutMs: 5_000,
-      stopGraceMs: 40,
+      pendingTimeoutMs: 80,
+      stopGraceMs: 5,
     },
   )
 
   adapter.start({ sessionId: "s-hang-classic", modelId: "medium" })
   await new Promise((r) => setTimeout(r, 20))
   adapter.stop()
+  await new Promise((r) => setTimeout(r, 20))
+  assert.ok(!events.includes("end"), "normal finalization must survive the continuous stop grace")
   await new Promise((r) => setTimeout(r, 120))
 
   assert.ok(events.includes("capture_stopped"), `got ${events.join(",")}`)
   assert.ok(events.includes("end"), `stop must not hang waiting for STT ACK; got ${events.join(",")}`)
+  assert.ok(events.includes("error:infer_timeout"), `got ${events.join(",")}`)
   assert.ok(!events.includes("result"))
   adapter.destroy()
 })
 
 test("streaming: stop while waiting for missing end ACK fires onEnd within stopGrace", async () => {
   const events: string[] = []
   const sent: any[] = []
   const adapter = createLocalSttAdapter(
     {
       onStart: () => events.push("start"),
       onResult: () => events.push("result"),
       onError: (c) => events.push(`error:${c}`),
diff --git a/companion/scripts/test-summoner-voice-ui.py b/companion/scripts/test-summoner-voice-ui.py
new file mode 100644
index 00000000..91c95901
--- /dev/null
+++ b/companion/scripts/test-summoner-voice-ui.py
@@ -0,0 +1,80 @@
+"""#482: execute the real summoner HTML with synthetic microphone/recognizer/HTTP.
+
+No microphone permission, audio files, model service, or installed app are touched.
+Run after nvm use 22: uv run --no-project --with playwright python scripts/test-summoner-voice-ui.py
+"""
+from pathlib import Path
+from urllib.parse import urlparse
+import json
+import subprocess
+import tempfile
+from playwright.sync_api import sync_playwright
+
+root = Path(__file__).resolve().parent.parent
+bootstrap = """
+window.EventSource=class {constructor(){window.fixtureEvents=this} addEventListener(){} close(){}};
+window.resizeTo=()=>{};window.moveTo=()=>{};
+window.SpeechRecognition=class {
+  constructor(){window.fixtureRecognition=this}
+  start(){queueMicrotask(()=>this.onstart?.())}
+  stop(){queueMicrotask(()=>this.onend?.())}
+  abort(){}
+};
+Object.defineProperty(navigator,'mediaDevices',{value:{getUserMedia:async()=>({getTracks:()=>[{stop(){window.fixtureStopped=true}}]})}});
+window.AudioContext=class {
+  state='running';sampleRate=16000;
+  createMediaStreamSource(){return {connect(){},disconnect(){}}}
+  createScriptProcessor(){return window.fixtureProcessor={connect(){},disconnect(){}}}
+  createGain(){return {gain:{value:0},connect(){},disconnect(){}}}
+  close(){return Promise.resolve()}
+};
+"""
+with tempfile.TemporaryDirectory() as out:
+    subprocess.run(['node', 'scripts/render-web-surface-fixtures.cjs', out], cwd=root, check=True)
+    html = (Path(out) / 'capture.html').read_text().replace('%%CRUISE_LABEL%%', '每次确认')
+    with sync_playwright() as p:
+        browser = p.chromium.launch(channel='chrome', headless=True)
+        for engine in ['browser', 'local', 'system']:
+            page = browser.new_page(viewport={'width': 360, 'height': 600})
+            page.set_default_timeout(6000)
+            page.add_init_script(bootstrap)
+            requests, errors = [], []
+            page.on('pageerror', lambda error: errors.append(str(error)))
+            def route(r):
+                path = urlparse(r.request.url).path
+                body = r.request.post_data_json if r.request.post_data else {}
+                requests.append((path, body))
+                if path == '/':
+                    r.fulfill(content_type='text/html', body=html)
+                    return
+                if path == '/api/voice-settings': data = {'sttEngine': engine, 'localModelId': 'medium', 'lang': 'zh-CN'}
+                elif path == '/api/threads': data = {'threads': [{'id': 'thread-a', 'alias': '语音验收'}]}
+                elif path == '/api/thread': data = {'messages': [], 'run_status': 'idle'}
+                elif path == '/api/stt/end': data = {'type': 'voice.stt.result', 'sessionId': body['sessionId'], 'text': '本机识别结果'}
+                else: data = {'type': 'ok'}
+                r.fulfill(content_type='application/json', body=json.dumps(data))
+            page.route('http://voice.fixture/**', route)
+            page.goto('http://voice.fixture/')
+            page.locator('#mic').click()
+            page.locator('#voicePrivacyAck').click()
+            page.wait_for_function('document.querySelector("#voiceStatus").textContent.includes("正在听写")')
+            if engine == 'browser':
+                page.evaluate('window.fixtureRecognition.onresult({resultIndex:0,results:[{0:{transcript:"浏览器结果"},isFinal:true}]})')
+            else:
+                page.evaluate('window.fixtureProcessor.onaudioprocess({inputBuffer:{getChannelData:()=>new Float32Array(16000)}})')
+            page.locator('#mic').click()
+            page.wait_for_function('document.querySelector("#text").value.includes("结果")')
+            assert not errors, errors
+            if engine == 'browser':
+                assert not any(path.startswith('/api/stt/') for path, _ in requests)
+            else:
+                actual = [(path, body) for path, body in requests if path in ['/api/stt/start', '/api/stt/chunk', '/api/stt/end']]
+                assert [path for path, _ in actual] == ['/api/stt/start', '/api/stt/chunk', '/api/stt/end'], actual
+                assert actual[0][1]['engine'] == engine
+                assert actual[-1][1]['totalSeq'] == 1
+                assert page.evaluate('window.fixtureStopped === true')
+            assert page.locator('#voiceStatus').is_visible()
+            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
+            page.close()
+        browser.close()
+print('PASS: real summoner HTML; browser/local/system selection, privacy action, visible recording state, preview/final, ordered HTTP upload and microphone cleanup. Synthetic capture only.')
diff --git a/companion/scripts/test-summoner-workspace-ui.py b/companion/scripts/test-summoner-workspace-ui.py
index a1fcaceb..0e09171a 100644
--- a/companion/scripts/test-summoner-workspace-ui.py
+++ b/companion/scripts/test-summoner-workspace-ui.py
@@ -2,31 +2,39 @@
 from pathlib import Path
 from urllib.parse import urlparse
 import json,subprocess,tempfile
 from playwright.sync_api import sync_playwright
 root=Path(__file__).resolve().parent.parent
 shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
 with tempfile.TemporaryDirectory() as out:
  subprocess.run(['node','scripts/render-web-surface-fixtures.cjs',out],cwd=root,check=True)
  html=(Path(out)/'capture.html').read_text().replace('%%CRUISE_LABEL%%','每次确认')
  with sync_playwright() as p:
   b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':390,'height':740});page.set_default_timeout(6000)
   browser_status={'connected':False}
+  thread={'id':'fixture-1','alias':'演示对话','user_tags':[],'topic_folder':None}
+  metadata_ack={'valid':True}
+  extra_threads=[];held=[];delay_select={'enabled':False}
   errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.add_init_script('window.EventSource=class {constructor(){window.fixtureEvents=this} addEventListener(){} close(){}};window.resizeTo=()=>{};window.moveTo=()=>{};')
   def route(r):
    req=r.request;path=urlparse(req.url).path;requests.append((req.method,path))
    if path=='/':r.fulfill(content_type='text/html',body=html);return
-   if path=='/api/threads':data={'thread':{'id':'fixture-1'}} if req.method=='POST' else {'threads':[{'id':'fixture-1','alias':'演示对话'}]}
-   elif path=='/api/thread':data={'messages':[],'run_status':'idle'}
+   if path=='/api/threads':data={'thread':{'id':'fixture-1'}} if req.method=='POST' else {'threads':[thread]+extra_threads}
+   elif path=='/api/thread':
+    if req.method=='POST' and delay_select['enabled'] and req.post_data_json.get('thread_id')=='fixture-1':held.append(r);return
+    if req.method=='PATCH':
+     if metadata_ack['valid']:thread.update(req.post_data_json)
+     data={'type':'thread.updated','thread':thread.copy()}
+    else:data={'thread':thread,'messages':[],'run_status':'idle'}
    elif path=='/api/mcp':data={'servers':[]}
    elif path=='/api/browser-status':data=browser_status
    else:data={'ok':True}
    r.fulfill(content_type='application/json',body=json.dumps(data))
   page.route('http://fixture.test/**',route);page.goto('http://fixture.test/')
   text=page.get_by_role('textbox',name='发送到当前对话',exact=True);text.wait_for()
   page.wait_for_timeout(200);assert not errors,errors
   page.get_by_role('button',name='新对话',exact=True).first.click()
   page.wait_for_function('document.querySelector("#empty strong")')
   assert page.locator('.mark').count()==0 and '山' not in page.locator('#empty').inner_text()
   assert ('POST','/api/threads') in requests
   page.get_by_role('button',name='导航',exact=True).click();assert page.locator('.hud.history .list').is_visible()
@@ -36,24 +44,48 @@ with tempfile.TemporaryDirectory() as out:
    page.set_viewport_size({'width':width,'height':height})
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    assert page.locator('.composer-actions button:visible').evaluate_all('(els)=>els.map(el=>el.id)')==['attachFile','mic','sendGo']
    assert page.get_by_role('button',name='新对话',exact=True).count()>=1
    field=text.bounding_box();send=page.get_by_role('button',name='发送',exact=True).bounding_box()
    assert field and send and field['y']+field['height']<=send['y']+1 and send['y']+send['height']<=height
    page.screenshot(path=str(shots/f'summoner-{width}.png'))
   page.set_viewport_size({'width':1040,'height':760})
   page.get_by_role('searchbox',name='搜索对话').fill('不存在')
   assert page.locator('#threads .trow').count()==0
   page.get_by_role('searchbox',name='搜索对话').fill('演示')
   assert page.locator('#threads .trow').count()==1
+  page.get_by_role('button',name='分类 · 演示对话',exact=True).click()
+  page.get_by_role('textbox',name='人工标签',exact=True).fill('支付，待复核')
+  page.get_by_role('combobox',name='手动分组',exact=True).fill('九月变更')
+  page.get_by_role('button',name='保存',exact=True).click()
+  page.wait_for_function('document.querySelector("#threadMetadata").hidden')
+  assert thread['user_tags']==['支付','待复核'] and thread['topic_folder']=='九月变更'
+  page.get_by_role('combobox',name='查看方式',exact=True).select_option('folders')
+  assert page.locator('.thread-group-heading').inner_text()=='九月变更'
+  page.get_by_role('searchbox',name='搜索对话').fill('待复核')
+  assert page.locator('#threads .trow').count()==1
+  page.get_by_role('combobox',name='查看方式',exact=True).select_option('tags')
+  assert page.locator('.thread-group-heading').all_text_contents()==['待复核','支付']
+  page.get_by_role('button',name='分类 · 演示对话',exact=True).first.click()
+  metadata_ack['valid']=False
+  page.get_by_role('textbox',name='人工标签',exact=True).fill('未保存')
+  page.get_by_role('button',name='保存',exact=True).click()
+  page.get_by_text('服务端未保存所提交的分类，请更新 Companion 后重试',exact=True).wait_for()
+  assert page.locator('#threadMetadata').is_visible()
+  page.get_by_role('button',name='取消',exact=True).click()
+  metadata_ack['valid']=True
+  page.get_by_role('combobox',name='查看方式',exact=True).select_option('recent')
+  page.get_by_role('searchbox',name='搜索对话').fill('')
+  page.screenshot(path=str(shots/'summoner-481-management.png'))
+  page.locator('summary').filter(has_text='资料与工具').click()
   page.get_by_role('button',name='MCP',exact=True).click()
   page.get_by_text('尚未配置 MCP 服务',exact=True).wait_for()
   assert not any(path=='/api/mcp/toggle' for method,path in requests)
   page.get_by_role('button',name='浏览器',exact=True).click()
   page.get_by_text('尚未连接 CMspark 扩展',exact=True).wait_for()
   page.get_by_role('button',name='后台连接',exact=True).click()
   assert ('POST','/api/attach') in requests
   page.get_by_role('button',name='展示浏览器',exact=True).click()
   browser_status.clear();browser_status['error']='unavailable'
   page.get_by_role('button',name='浏览器',exact=True).click()
   page.get_by_text('无法读取浏览器连接状态',exact=True).wait_for()
   assert '尚未连接 CMspark 扩展' not in page.locator('#composeList').inner_text()
@@ -67,15 +99,27 @@ with tempfile.TemporaryDirectory() as out:
   assert ('POST','/api/abort') in requests
   page.evaluate('window.fixtureEvents.onmessage({data:JSON.stringify({type:"chat.aborted",thread_id:"fixture-1"})})')
   assert not page.locator('#stopGo').is_visible()
   page.keyboard.press('Escape')
   assert not page.locator('#hud').evaluate('(el)=>el.classList.contains("history")')
   page.screenshot(path=str(shots/'summoner-477-narrow.png'))
   page.get_by_role('button',name='导航',exact=True).click()
   page.set_viewport_size({'width':1000,'height':800});page.keyboard.press('Escape')
   assert page.locator('#newChat').evaluate('(el)=>el===document.activeElement')
   with page.expect_file_chooser():page.get_by_role('button',name='添加附件',exact=True).click()
   text.fill('请整理变更材料');page.get_by_role('button',name='发送',exact=True).click()
   page.wait_for_timeout(200);assert ('POST','/api/chat') in requests
+  extra_threads.append({'id':'fixture-2','alias':'第二对话'})
+  page.get_by_role('button',name='对话',exact=True).click()
+  page.locator('#threads .item').filter(has_text='第二对话').wait_for()
+  delay_select['enabled']=True
+  page.locator('#threads .item').filter(has_text='演示对话').click()
+  page.locator('#threads .item').filter(has_text='第二对话').click()
+  page.wait_for_function('document.querySelector("#workspaceTitle").textContent==="第二对话"')
+  assert held,'first select request should be held'
+  for r in held:r.fulfill(content_type='application/json',body=json.dumps({'messages':[{'role':'assistant','content':'旧对话迟到内容'}],'run_status':'llm'}))
+  page.wait_for_timeout(100)
+  assert '旧对话迟到内容' not in page.locator('#log').inner_text()
+  assert not page.locator('#stopGo').is_visible()
   assert not errors,errors
   b.close()
 print('PASS: real summoner script, reset without mark, history, input/action DOM order, keyboard-native attachment, send; synthetic HTTP/SSE only.')
diff --git a/companion/src/acp/handlers.ts b/companion/src/acp/handlers.ts
index 43c7e0ff..57dcfff1 100644
--- a/companion/src/acp/handlers.ts
+++ b/companion/src/acp/handlers.ts
@@ -40,28 +40,61 @@ export function ensureAcpBroadcast(broadcast: (data: any) => void): void {
   })
 }
 
 async function confirmOrDeny(
   ctx: AcpHandlerContext,
   details: SecurityConfirmationDetails,
 ): Promise<boolean> {
   if (!ctx.requestConfirmation) return false
   const decision = await ctx.requestConfirmation(details)
   return !!decision?.approved
 }
 
+/** Session ownership is fixed at proposal. Legacy callers may omit thread_id;
+ * explicit owners must match, and every session reply carries the stored owner. */
 export async function handleAcpWsMessage(
   type: string,
   msg: Record<string, unknown>,
   ctx: AcpHandlerContext,
+): Promise<any> {
+  const mgr = getAcpManager()
+  const controlsSession = ["acp.session.cancel", "acp.session.prompt", "acp.session.followup", "acp.apply_diff"].includes(type)
+  const sid = typeof msg.session_id === "string" && msg.session_id ? msg.session_id
+    : type === "acp.session.followup" && typeof msg.parent_session_id === "string" ? msg.parent_session_id : ""
+  const session = controlsSession && sid ? mgr.getSession(sid) : undefined
+  const claimedOwner = msg.thread_id !== undefined ? msg.thread_id : ctx.threadId
+  if (controlsSession && claimedOwner !== undefined &&
+      (typeof claimedOwner !== "string" || !claimedOwner || (session && session.thread_id !== claimedOwner))) {
+    return {
+      type: "error", family: "acp", error: "acp: session does not belong to the requested conversation",
+      session_id: sid, ...(session ? { thread_id: session.thread_id } : {}),
+    }
+  }
+  const result = await handleAcpWsMessageInternal(type, msg, ctx)
+  if (!result || typeof result !== "object") return result
+  const resultSession = typeof result.session_id === "string" ? mgr.getSession(result.session_id) : undefined
+  const owner = resultSession?.thread_id ?? session?.thread_id ??
+    (type === "acp.ui_start" && typeof msg.thread_id === "string" ? msg.thread_id : undefined)
+  return {
+    ...result,
+    ...(result.type === "error" ? { family: "acp" } : {}),
+    ...(owner ? { thread_id: owner } : {}),
+    ...(!result.session_id && sid ? { session_id: sid } : {}),
+  }
+}
+
+async function handleAcpWsMessageInternal(
+  type: string,
+  msg: Record<string, unknown>,
+  ctx: AcpHandlerContext,
 ): Promise<any> {
   const mgr = getAcpManager()
   if (ctx.broadcast) ensureAcpBroadcast(ctx.broadcast)
 
   if (type === "acp.list" || type === "acp.rediscover") {
     const cfg = getConfig()
     if (type === "acp.rediscover") {
       _resetDiscoverCache()
       discoverCodingAgents(true)
     }
     return {
       type: "acp.list",
@@ -148,24 +181,25 @@ export async function handleAcpWsMessage(
           // Ignore mismatched client path — do not probe arbitrary dirs
           raw = a
         }
       } catch {
         /* keep bound */
       }
     }
     const st = await getWorkspaceGitStatus(
       typeof raw === "string" ? raw : null,
     )
     return {
       type: "coding.git_status",
+      ...(tid ? { thread_id: tid } : {}),
       // Agent spawn uses session.workspace_root as cwd (manager.ts) — true today.
       agent_cwd_is_workspace: true,
       branch: st.branch,
       dirty_count: st.dirty_count,
       is_repo: st.is_repo,
       workspace_root: st.workspace_root ?? (typeof raw === "string" ? raw : null),
       ...(st.error ? { error: st.error } : {}),
     }
   }
 
   // S2: multi-turn input into live shell (ACP process) or followup path
   if (type === "acp.session.prompt") {
diff --git a/companion/src/menu-bar-agent.ts b/companion/src/menu-bar-agent.ts
index c1dad831..4bf28990 100644
--- a/companion/src/menu-bar-agent.ts
+++ b/companion/src/menu-bar-agent.ts
@@ -77,24 +77,25 @@ import {
   invalidateOverlaySession,
   overlaySessionIsLive,
   shouldReclaimLiveOverlayThread,
   type OverlayClaimResult,
   type OverlayLeaseState,
 } from "./summoner/overlay-session"
 import {
   claimOverlayLeaseCas,
   releaseOverlayLeaseAtRev,
   type LeaseRpc,
 } from "./ws/composer-lease"
 import { acceptedSummonerHotkey, nextSummonerHotkeyCmd } from "./summoner/hotkey"
+import { summonerVoiceRequestTimeout } from "./summoner/voice-input"
 
 // node-notifier does not ship TypeScript declarations
 // eslint-disable-next-line @typescript-eslint/no-var-requires
 const notifier = require("node-notifier") as {
   notify(options: { title?: string; message?: string; sound?: boolean | string; timeout?: number }): void
 }
 
 function safeNotify(options: { title?: string; message?: string; sound?: boolean | string; timeout?: number }): void {
   // Debug log to file (stdout is swallowed in SEA mode)
   try {
     const logPath = path.join(getConfigDir(), "tray-debug.log")
     fs.appendFileSync(logPath, `[${new Date().toISOString()}] safeNotify called: ${options.title} - ${options.message}\n`)
@@ -1820,40 +1821,40 @@ function dispatchSummonerWeb(
   delete params.type
   if (
     type === "chat.create" ||
     type === "chat.steer" ||
     type === "chat.abort" ||
     type === "file.upload"
   ) {
     const ok = client.sendAppMessage(type, params)
     return Promise.resolve(ok ? { type: "accepted" } : { type: "error", error: "未连接" })
   }
   // voice.stt.chunk / abort have no WS ack — sendAppRequest would hang the HTTP 8s timeout.
   if (type === "voice.stt.chunk" || type === "voice.stt.abort") {
-    client.sendAppMessage(type, params)
-    return Promise.resolve({ type: "ok" })
+    const ok = client.sendAppMessage(type, params)
+    return Promise.resolve(ok ? { type: "ok" } : { type: "error", error: "未连接" })
   }
   if (type === "mcp.toggle_server" || type === "mcp.add") {
     return Promise.resolve({
       type: "error",
       error: `not allowed: ${type}`,
       error_code: "SUMMONER_L0",
     })
   }
-  const timeout =
+  const timeout = summonerVoiceRequestTimeout(type) ?? (
     type === "meeting.generate_minutes"
       ? 90_000
       : type === "pack.apply" || type === "file.upload"
         ? 30_000
-        : 8_000
+        : 8_000)
   return client.sendAppRequest(type, params, timeout)
 }
 
 function reportOverlayShellUnavailable(): void {
   companionClient?.sendAppMessage("error", {
     error_code: "OVERLAY_SHELL_UNAVAILABLE",
     error: "无法弹出对话框",
   })
 }
 
 async function openSummonerWebShell(threadId: string): Promise<void> {
   const client = summonerClient
diff --git a/companion/src/message-router.ts b/companion/src/message-router.ts
index 4cd89b94..6bef0cb3 100644
--- a/companion/src/message-router.ts
+++ b/companion/src/message-router.ts
@@ -5109,51 +5109,52 @@ export async function handleMessage(
     }
     case "modules.update": {
       const { updateModuleConfig } = await import("./capability/modules")
       if (!rest.module || typeof rest.module !== "string") {
         return { type: "error", error: "module required" }
       }
       const r = updateModuleConfig(rest.module as any, rest.patch || {})
       if (!r.ok) return { type: "error", error: r.error }
       return { type: "modules.updated", module: r.module, modules: getConfig().modules }
     }
     case "workspace.pick": {
       // Optional thread_id: pick + bind in one step (avoids UI race / stale set)
+      const owner = typeof rest.thread_id === "string" && rest.thread_id ? { thread_id: rest.thread_id } : {}
       const result = await pickFolderNative()
-      if (result.error) return { type: "workspace.pick_result", error: result.error }
-      if (!result.path) return { type: "workspace.pick_result", error: "未选择文件夹" }
+      if (result.error) return { type: "workspace.pick_result", ...owner, error: result.error }
+      if (!result.path) return { type: "workspace.pick_result", ...owner, error: "未选择文件夹" }
       const { recordNativePick, setWorkspaceRoot } = await import("./capability/workspace")
       let abs = result.path
       try {
         abs = fs.realpathSync(path.resolve(result.path))
       } catch {
         /* keep result.path */
       }
       recordNativePick(abs)
       if (typeof rest.thread_id === "string" && rest.thread_id) {
         const thread = threadManager.get(rest.thread_id)
         if (!thread) {
-          return { type: "workspace.pick_result", path: abs, error: `thread not found: ${rest.thread_id}` }
+          return { type: "workspace.pick_result", ...owner, path: abs, error: `thread not found: ${rest.thread_id}` }
         }
         const bind = setWorkspaceRoot(abs)
-        if (!bind.ok) return { type: "workspace.pick_result", path: abs, error: bind.error }
+        if (!bind.ok) return { type: "workspace.pick_result", ...owner, path: abs, error: bind.error }
         threadManager.update(rest.thread_id, { workspace_root: bind.path } as any)
         return {
-          type: "workspace.pick_result",
+          type: "workspace.pick_result", ...owner,
           path: bind.path,
           bound: true,
           thread: threadManager.get(rest.thread_id),
         }
       }
-      return { type: "workspace.pick_result", path: abs, bound: false }
+      return { type: "workspace.pick_result", ...owner, path: abs, bound: false }
     }
     case "workspace.set": {
       if (!rest.thread_id) return { type: "error", error: "thread_id required" }
       const { setWorkspaceRoot } = await import("./capability/workspace")
       const pathVal = typeof rest.path === "string" ? rest.path : ""
       const r = setWorkspaceRoot(pathVal)
       if (!r.ok) return { type: "error", error: r.error }
       const thread = threadManager.get(rest.thread_id)
       if (!thread) return { type: "error", error: "thread not found" }
       threadManager.update(rest.thread_id, { workspace_root: r.path } as any)
       return { type: "workspace.set_result", thread: threadManager.get(rest.thread_id) }
     }
diff --git a/companion/src/summoner-web.ts b/companion/src/summoner-web.ts
index 1a4c29b6..5f6b00bc 100644
--- a/companion/src/summoner-web.ts
+++ b/companion/src/summoner-web.ts
@@ -32,24 +32,27 @@ import {
   SUMMONER_CHEVRON_COLLAPSE,
   SUMMONER_CHEVRON_EXPAND,
   SUMMONER_L0_CHROME_DOWN,
   SUMMONER_RENTER_CHROME_DOWN,
   CHAT_SHELL_TITLE_NONE,
   VOICE_PRIVACY_ACK_V2_CLAUSES,
   MEETING_PRIVACY_ACK_V1_CLAUSES,
 } from "./summoner/client"
 import { getChromeOpener } from "./platform"
 import { getConfig } from "./config"
 import { OVERLAY_RENDER_MD_JS } from "./summoner/overlay-md"
 import { currentOverlayCruiseChipLabel } from "./summoner/hydrate"
+import { SUMMONER_DICTATION_JS } from "./summoner/voice-input"
+import { SUMMONER_THREAD_MANAGEMENT_JS } from "./summoner/thread-management"
+import { summonerThreadMetadata } from "./threads/metadata-patch"
 
 export type SummonerWebDispatch = (msg: Record<string, unknown>) => Promise<unknown>
 export type SummonerWebAttachChrome = (opts?: { foreground?: boolean }) => string
 export type SummonerWebRequestOpenSidePanel = () => Promise<{ error_code?: string } | void>
 export type SummonerWebHasExtensionPeer = () => boolean
 
 export const SUMMONER_WEB_DISPATCH_ALLOW = new Set([
   "system.ping",
   "chat.create",
   "chat.abort",
   "chat.steer",
   "thread.list",
@@ -738,25 +741,25 @@ async function handleRequest(
       jsonResponse(res, { send_shortcut })
       return
     }
 
     if (pathOnly === "/api/voice-settings" && req.method === "GET") {
       const voice = getConfig().voice
       const localModelId =
         voice?.localModelId === "small" ||
         voice?.localModelId === "medium" ||
         voice?.localModelId === "large-v3-turbo"
           ? voice.localModelId
           : "medium"
-      const sttEngine = voice?.sttEngine === "local" ? "local" : "browser"
+      const sttEngine = voice?.sttEngine === "local" ? "local" : voice?.sttEngine === "system" ? "system" : "browser"
       jsonResponse(res, { sttEngine, localModelId, lang: "zh-CN" })
       return
     }
 
     if (pathOnly === "/api/events" && req.method === "GET") {
       if (sseClients.size >= MAX_SSE_CLIENTS) {
         jsonResponse(res, { type: "error", error: "too many listeners" }, 429)
         return
       }
       res.writeHead(200, {
         "Content-Type": "text/event-stream; charset=utf-8",
         "Cache-Control": "no-cache",
@@ -808,26 +811,28 @@ async function handleRequest(
       }
       jsonResponse(res, await dispatchAllowed("thread.select", { thread_id: id }))
       return
     }
 
     if (pathOnly === "/api/thread" && req.method === "PATCH") {
       const id = query.get("id") || ""
       if (!id) {
         jsonResponse(res, { type: "error", error: "id required" }, 400)
         return
       }
       const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
-      const alias = typeof body.alias === "string" ? body.alias : ""
-      jsonResponse(res, await dispatchAllowed("thread.update", { thread_id: id, updates: { alias } }))
+      let updates: Record<string, unknown>
+      try { updates = summonerThreadMetadata(body) }
+      catch (error) { jsonResponse(res, { type: "error", error: error instanceof Error ? error.message : "Invalid metadata" }, 400); return }
+      jsonResponse(res, await dispatchAllowed("thread.update", { thread_id: id, updates }))
       return
     }
 
     if (pathOnly === "/api/thread" && req.method === "DELETE") {
       const id = query.get("id") || ""
       if (!id) {
         jsonResponse(res, { type: "error", error: "id required" }, 400)
         return
       }
       jsonResponse(res, await dispatchAllowed("thread.delete", { thread_id: id, mode: "trash" }))
       return
     }
@@ -1040,24 +1045,26 @@ async function handleRequest(
           : cfgModel === "small" || cfgModel === "medium" || cfgModel === "large-v3-turbo"
             ? cfgModel
             : "medium"
       const payload: Record<string, unknown> = {
         v: 1,
         sessionId,
         modelId,
         format: "pcm_s16le",
         sampleRate: 16000,
         channels: 1,
         privacy_ack_v2: true,
       }
+      // Engine is read from trusted configuration, never promoted by a page claim.
+      if (getConfig().voice?.sttEngine === "system") payload.engine = "system"
       if (typeof body.lang === "string" && body.lang.trim()) {
         payload.lang = body.lang.startsWith("zh") ? "zh" : body.lang
       } else {
         payload.lang = "zh"
       }
       if (typeof body.maxMs === "number" && Number.isFinite(body.maxMs)) payload.maxMs = body.maxMs
       const started = await dispatchAllowed("voice.stt.start", payload)
       jsonResponse(res, started)
       if (!overlayDispatchFailed(started) && sessionId) overlaySttSessionId = sessionId
       return
     }
 
@@ -1445,56 +1452,80 @@ button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px soli
 .rail-btn svg{width:18px;height:18px;flex:none}.rail-btn[aria-current="true"]{background:#eaeae7;color:var(--text)}
 .hud.expanded .body{flex-direction:row;border-bottom:0}
 .list{display:flex;width:220px;flex:none;background:var(--rail-bg)}
 .hud.history .list{position:static;inset:auto;width:220px;border-right:1px solid var(--line)}
 .list-head{font-size:12px;letter-spacing:0;color:var(--secondary)}
 .item.active{background:#eaeae7;color:var(--text)}.item strong{overflow-wrap:anywhere}.trow{flex-wrap:wrap}.trow .item{flex-basis:100%}.trow .icon-mini{height:28px}
 #historyClose{display:none}.log{padding:32px 28px}.empty{margin:auto;max-width:440px;line-height:1.8;color:var(--secondary)}
 .empty strong{font-size:28px;color:var(--text);margin-bottom:8px}
 @media(min-width:760px){.hud{background:var(--rail-bg)}.capture-row{background:var(--paper)}.log{max-width:none;padding-left:max(24px,calc((100vw - 1000px)/2));padding-right:max(24px,calc((100vw - 1000px)/2))}.composer,.capture-row,.status,.cta-box{margin-left:220px;max-width:none;width:calc(100% - 220px)}.composer{padding-left:max(24px,calc((100vw - 1000px)/2));padding-right:max(24px,calc((100vw - 1000px)/2))}.cta-box,.status{width:calc(100% - 244px)}#historyOpen{display:none}}
 @media(max-width:759px){.brand{flex-wrap:wrap}.brand-actions{flex-wrap:wrap;min-width:0}.hud.expanded .body{flex-direction:column}.list{display:none}.hud.history .list{display:flex;width:100%;max-height:36vh;min-height:0;border-right:0;border-bottom:1px solid var(--line)}.rail{flex-direction:row;flex-wrap:wrap;flex-shrink:0;padding:6px}.rail-btn{width:auto;height:32px;padding:0 8px;font-size:12px}.rail-btn svg{display:none}.list-head{padding:4px 12px}.list-scroll{min-height:0}#historyClose{display:block}.log{padding:20px}.empty strong{font-size:22px}}
 @media(max-height:560px){.hud.history .list{max-height:28vh}.log{padding:12px}.empty{padding:8px}.empty strong{font-size:20px}.capture-row{padding-bottom:6px}.composer{padding-top:6px}}
 
+.brand-id{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}.brand-actions{flex:none}
+.workspace-tools{width:100%;min-width:0;flex:none;border-top:1px solid var(--line)}.workspace-tools[open]{max-height:24vh;overflow:auto}.workspace-tools summary{cursor:pointer;padding:10px;font-size:12px;color:var(--secondary)}.workspace-tools summary:focus-visible{outline:2px solid var(--indigo)}
+.thread-search select{display:block;width:100%;margin-top:6px;padding:8px;border:1px solid var(--line);border-radius:8px;background:var(--paper);color:var(--text);font:inherit}
+.organization-hint{font-size:11px;line-height:1.6;margin:8px 0;color:var(--secondary)}
+#threadOrganization[hidden],#threadMetadata[hidden]{display:none}
+#threadMetadata{padding:12px 0;border-top:1px solid var(--line)}#threadMetadata label{display:block;margin-top:10px}
+#metadataTitle{display:block;overflow-wrap:anywhere}.metadata-actions{display:flex;gap:8px}.metadata-actions button{min-height:32px;border:1px solid var(--line);border-radius:8px;padding:4px 10px;background:var(--paper);font:inherit;color:var(--text)}
+#metadataError{color:#b91c1c;font-size:12px;overflow-wrap:anywhere}.thread-group-heading{font-size:12px;color:var(--secondary);padding:12px 10px 4px;overflow-wrap:anywhere}.trow .thread-classify{width:auto;min-width:40px;padding:0 6px;font:inherit;font-size:12px;color:var(--secondary)}
 </style>
 </head>
 <body>
 <div class="hud expanded" id="hud">
   <div class="body">
     <aside class="list" aria-label="工作空间导航">
     <nav class="rail" id="secs" aria-label="工作空间">
       <button class="rail-btn" data-sec="threads" aria-current="true" type="button" title="对话" aria-label="对话">
         <svg viewBox="0 0 24 24"><path d="M5 7h14M5 12h10M5 17h7"/></svg><span>对话</span>
       </button>
+
+    </nav>
+
+      <div class="list-head"><span id="secHead">历史会话</span><button type="button" id="historyClose">完成</button></div>
+      <div class="list-scroll">
+        <button class="item" id="newThread" type="button"><strong>新对话</strong><small>快捷提问</small></button>
+        <label class="thread-search" id="threadSearchLabel">搜索对话<input id="threadSearch" type="search" placeholder="标题、标签或分组" autocomplete="off"></label>
+        <div id="threadOrganization" class="thread-search">
+          <label>查看方式<select id="threadView"><option value="recent">最近对话</option><option value="folders">手动分组</option><option value="tags">对话标签</option><option value="ai">AI 分组</option></select></label>
+          <p class="organization-hint">在对话的「分类」中创建分组或添加标签。</p>
+          <form id="threadMetadata" hidden aria-label="编辑对话分类">
+            <strong id="metadataTitle">对话分类</strong>
+            <label>人工标签<input id="metadataTags" placeholder="用逗号分隔" maxlength="820"></label>
+            <label>手动分组<input id="metadataFolder" list="threadFolders" maxlength="40" placeholder="选择或输入新分组"></label>
+            <datalist id="threadFolders"></datalist>
+            <p class="organization-hint">留空可移出分组。人工分类不会被 AI 整理覆盖。</p>
+            <p id="metadataError" role="alert"></p>
+            <div class="metadata-actions"><button id="metadataCancel" type="button">取消</button><button id="metadataSave" type="submit">保存</button></div>
+          </form>
+        </div>
+        <div id="threads"></div>
+        <div id="composeList"></div>
+      </div>
+      <details class="workspace-tools"><summary>资料与工具</summary>
       <button class="rail-btn" data-sec="packs" type="button" title="场景" aria-label="场景">
         <svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1.4"/><rect x="13" y="4" width="7" height="7" rx="1.4"/><rect x="4" y="13" width="7" height="7" rx="1.4"/><rect x="13" y="13" width="7" height="7" rx="1.4"/></svg><span>场景</span>
       </button>
       <button class="rail-btn" data-sec="knowledge" type="button" title="知识" aria-label="知识">
         <svg viewBox="0 0 24 24"><path d="M5 5.5h9.2A2.3 2.3 0 0 1 16.5 7.8V19H7.4A2.4 2.4 0 0 1 5 16.6V5.5z"/><path d="M16.5 8h1.4A2.1 2.1 0 0 1 20 10.1V19h-3.5"/></svg><span>知识</span>
       </button>
       <button class="rail-btn" data-sec="skills" type="button" title="技能" aria-label="技能">
         <svg viewBox="0 0 24 24"><path d="M8 15.2 4.8 12 8 8.8M16 8.8 19.2 12 16 15.2M13.1 6.8 10.9 17.2"/></svg><span>技能</span>
       </button>
       <button class="rail-btn" data-sec="mcp" type="button" title="MCP" aria-label="MCP">
         <svg viewBox="0 0 24 24"><rect x="8" y="8" width="8" height="8" rx="1.2"/><path d="M12 4.6v3.2M12 16.2v3.2M4.6 12H8M16 12h3.4"/></svg><span>MCP</span>
       </button>
       <button class="rail-btn" data-sec="browser" type="button"><span>浏览器</span></button>
-    </nav>
-
-      <div class="list-head"><span id="secHead">历史会话</span><button type="button" id="historyClose">完成</button></div>
-      <div class="list-scroll">
-        <button class="item" id="newThread" type="button"><strong>新对话</strong><small>快捷提问</small></button>
-        <label class="thread-search" id="threadSearchLabel">搜索对话<input id="threadSearch" type="search" placeholder="标题或名称" autocomplete="off"></label>
-        <div id="threads"></div>
-        <div id="composeList"></div>
-      </div>
+      </details>
     </aside>
     <section class="main">
       <div class="brand">
         <span class="brand-id" id="workspaceTitle">CMspark</span>
         <span class="brand-actions">
           <button type="button" id="cruiseChip" class="cruise-chip" title="点此打开侧栏调整档位">%%CRUISE_LABEL%%</button>
           <button type="button" id="windowMode">紧凑窗口</button>
           <button type="button" id="historyOpen" aria-expanded="false">导航</button>
           <button type="button" id="newChat">新对话</button>
         </span>
       </div>
       <div class="log" id="log">
@@ -1860,24 +1891,25 @@ try{
         var poll=function(){
           if(!sttLive || sttSid!==sid) return;
           api("/api/stt/partial",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:sid})});
           sttPartialTimer=setTimeout(poll,1400);
         };
         sttPartialTimer=setTimeout(poll,1400);
       }
     };
     if(ctx.state==="suspended") ctx.resume().then(go).catch(go);
     else go();
   }
   function startStt(){
+    if(typeof summonerVoice!=="undefined" && summonerVoice) summonerVoice.cancel();
     if(sttLive){ stopStt(false); return; }
     if(!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia!=="function"){
       setStatus(STT_MIC_FAIL);
       return;
     }
     var sid="ov-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10);
     sttSid=sid;
     sttSeq=0;
     sttBuf=new Uint8Array(0);
     sttFloat=new Float32Array(0);
     sttLive=true;
     $("mic").setAttribute("aria-pressed","true");
@@ -1894,37 +1926,52 @@ try{
           stopStt(true);
           return;
         }
         beginPcm(sid, stream);
       });
     }).catch(function(){
       sttLive=false;
       sttSid="";
       $("mic").setAttribute("aria-pressed","false");
       setStatus(STT_MIC_FAIL);
     });
   }
+  ${SUMMONER_THREAD_MANAGEMENT_JS}
   function renderThreads(filter){
+    var selected=threads.find(function(t){return t.id===threadId});
+    $("workspaceTitle").textContent=selected?(selected.title||selected.alias||"新对话"):"CMspark";
+    $("workspaceTitle").title=$("workspaceTitle").textContent;
     var q=(filter===undefined?$("threadSearch").value:filter||"").trim().toLocaleLowerCase();
     var box=$("threads");
     box.innerHTML="";
-    threads.forEach(function(t){
+    var view=$("threadView").value, previousGroup=null;
+    var listed=threadEntries(threads,view);
+    listed.forEach(function(entry){
+      var t=entry.thread;
       var title=(t.title||t.alias||t.id||"").trim()||t.id;
-      if(q && title.toLocaleLowerCase().indexOf(q)<0 && String(t.alias||"").toLocaleLowerCase().indexOf(q)<0) return;
+      var search=[title,t.alias,t.topic_folder].concat(t.user_tags||[],t.digest&&t.digest.tags||[]).join(" ").toLocaleLowerCase();
+      if(q && search.indexOf(q)<0) return;
+      if(view!=="recent"){
+        var group=entry.group;
+        if(group!==previousGroup){var heading=document.createElement("h3");heading.className="thread-group-heading";heading.textContent=group;box.appendChild(heading);previousGroup=group}
+      }
       var row=document.createElement("div");
       row.className="trow";
       var b=document.createElement("button");
       b.className="item"+(t.id===threadId?" active":"");
       b.innerHTML="<strong>"+esc(title)+"</strong>";
-      b.onclick=function(){selectThread(t.id)};
+      var details=[t.topic_folder?"分组 · "+t.topic_folder:"",(t.user_tags||[]).map(function(tag){return "#"+tag}).join(" ")].filter(Boolean).join(" · ");
+      if(details){var meta=document.createElement("small");meta.textContent=details;b.appendChild(meta)}
+      b.onclick=function(){closeThreadMetadata();selectThread(t.id)};
+      var classify=document.createElement("button");classify.className="icon-mini thread-classify";classify.type="button";classify.textContent="分类";classify.setAttribute("aria-label","分类 · "+title);classify.onclick=function(){openThreadMetadata(t,classify)};
       var rn=document.createElement("button");
       rn.className="icon-mini";
       rn.title="重命名";
       rn.setAttribute("aria-label","重命名");
       rn.innerHTML='<svg viewBox="0 0 24 24"><path d="M4 20h4l11-11-4-4L4 16v4z"/></svg>';
       rn.onclick=function(ev){
         ev.stopPropagation();
         var alias=window.prompt("重命名", title);
         if(!alias||!String(alias).trim()) return;
         api("/api/thread?id="+encodeURIComponent(t.id),{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({alias:String(alias).trim()})}).then(function(d){
           if(d&&(d.error||d.type==="error")){setStatus(d.error||"无法重命名");return}
           return refresh();
@@ -1940,24 +1987,25 @@ try{
         if(!window.confirm("把「"+title+"」移到回收站？")) return;
         api("/api/thread?id="+encodeURIComponent(t.id),{method:"DELETE"}).then(function(d){
           if(d&&(d.error||d.type==="error")){setStatus(d.error||"无法移到回收站");return}
           var gone=threadId===t.id;
           return refresh().then(function(){
             if(!gone) return;
             if(threads[0]) return selectThread(threads[0].id);
             $("newThread").click();
           });
         });
       };
       row.appendChild(b);
+      row.appendChild(classify);
       row.appendChild(rn);
       row.appendChild(tr);
       box.appendChild(row);
     });
   }
   function clearStreamMsg(){
     if(streamMsg&&streamMsg.parentNode) streamMsg.parentNode.removeChild(streamMsg);
     streamMsg=null;
   }
   function showStreamMsg(text){
     var log=$("log");
     if(!streamMsg||!streamMsg.parentNode){
@@ -1991,48 +2039,57 @@ try{
       empty.id="empty";
       empty.innerHTML="<strong>${CHAT_SHELL_TITLE_NONE}</strong>回车发送。附件和听写不用开浏览器。";
       log.appendChild(empty);
     }
     log.scrollTop=log.scrollHeight;
   }
   function syncBusyUi(){
     $("stopGo").hidden=!busy;
     $("hint").textContent=busy
       ?"回车纠偏 · Shift+Enter 排队 · 忙时附件请等本轮结束 · 点击右上角 ⋮ 设置快捷键"
       :"回车发送 · Shift+Enter 排队 · # 搜标题 · 点击右上角 ⋮ 设置快捷键";
   }
+  var selectionRevision=0;
   function selectThread(id){
+    var revision=++selectionRevision;
+    if(typeof summonerVoice!=="undefined" && summonerVoice) summonerVoice.cancel();
     threadId=id;
     clearStreamMsg();
     showHistory(false);
     renderThreads($("text").value.charAt(0)==="#"?$("text").value.slice(1):"");
     return api("/api/lease",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:id})})
       .then(function(d){
+        if(revision!==selectionRevision || threadId!==id) return null;
         if(d && (d.error || d.error_code || (d.data&&d.data.error_code) || d.type==="error" || d.type==="chat.error" || d.type==="composer.lease.error")){
           setStatus(statusFromEvent(d));
         }
+        if(revision!==selectionRevision || threadId!==id) return null;
         return api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:id})});
       })
       .then(function(d){
+        if(!d || revision!==selectionRevision || threadId!==id) return;
+        if(d.error||d.type==="error"){setStatus(d.error||"无法读取对话");return}
         renderMsgs(d.messages||[]);
         busy=d.run_status==="llm";
         syncBusyUi();
         if(busy) startPoll(); else stopPoll();
       });
   }
   function startPoll(){
     if(poll) return;
     poll=setInterval(function(){
       if(!threadId) return;
-      api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})}).then(function(d){
+      var owner=threadId,revision=selectionRevision;
+      api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:owner})}).then(function(d){
+        if(owner!==threadId || revision!==selectionRevision || d.error || d.type==="error")return;
         var next=d.run_status==="llm";
         // SSE 流式气泡存活期间不做整表重绘（会拆掉 streaming bubble）；轮询仅作兜底
         if(!(streamMsg&&next)) renderMsgs(d.messages||[]);
         if(next!==busy){busy=next;syncBusyUi()}
         if(!busy) stopPoll();
       });
     },1200);
   }
   function stopPoll(){if(poll){clearInterval(poll);poll=null}}
   function filesToPayload(list){
     var arr=[].slice.call(list||[]);
     return Promise.all(arr.map(function(f){
@@ -2112,38 +2169,44 @@ try{
   $("stopGo").onclick=function(){$("stop").click()};
   $("stop").onclick=function(){
     if(!threadId) return;
     api("/api/abort",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})});
   };
   $("chev").onclick=function(){ setExpanded(true); };
   $("attachSilent").onclick=function(){attachChrome(false)};
   $("attachFront").onclick=function(){attachChrome(true)};
   $("openConfirm").onclick=function(){attachChrome(true)};
   $("settings").onclick=function(){
     alert("快捷键设置需要在 Chrome 侧栏的设置面板中配置。\\n\\n请打开 Chrome 侧栏，点击设置图标，在「模型与推理」部分找到「发送快捷键」设置。\\n\\n召唤器使用相同的快捷键配置。");
   };
-  $("mic").onclick=function(){
-    if(sttLive){ stopStt(false); return; }
-    if(!voiceAck){
+  ${SUMMONER_DICTATION_JS}
+  var summonerVoice=createSummonerDictation({
+    api:api,mic:$("mic"),input:$("text"),threadId:function(){return threadId},blocked:function(){return sttLive||!!meetingId},
+    privacy:function(engine){
       var sheet=$("voicePrivacy");
-      if(sheet) sheet.hidden=false;
-      return;
+      var browser=engine==="browser";
+      sheet.querySelector("p").textContent=browser?"浏览器听写":engine==="system"?"系统听写":"本机听写";
+      sheet.querySelector("ol").hidden=browser;
+      var notice=sheet.querySelector(".browser-privacy");
+      if(!notice){notice=document.createElement("p");notice.className="browser-privacy";sheet.insertBefore(notice,sheet.querySelector(".cta-actions"))}
+      notice.hidden=!browser;
+      notice.textContent="可选麦克风：浏览器将语音转成文字后填入输入框，默认不自动发送。转写可能使用 Chrome 语音服务（音频可能经网络发送至浏览器厂商），不经过 CMspark Companion。发送后的文字与键入相同，仍受现有确认与信任设置约束。";
+      sheet.hidden=false;
     }
-    startStt();
-  };
+  });
+  $("mic").onclick=function(){summonerVoice.toggle()};
   $("voicePrivacyAck").onclick=function(){
-    voiceAck=true;
     var sheet=$("voicePrivacy");
     if(sheet) sheet.hidden=true;
-    startStt();
+    summonerVoice.ack();
   };
   function setMeetingUi(on){
     var b=$("meetingStart");
     if(!b) return;
     b.textContent=on?"会议中":"开始会议";
     b.setAttribute("aria-pressed", on?"true":"false");
   }
   var recStartedAt=0;
   var recTimer=null;
   function fmtElapsed(ms){
     var s=Math.floor(ms/1000);
     if(s<0) s=0;
@@ -2472,30 +2535,32 @@ try{
   };
   function showHistory(on){
     var hud=$("hud");
     if(!hud) return;
     if(on){ hud.classList.add("history"); if(sec==="threads") refresh().catch(function(){setStatus("无法刷新对话列表")}); }
     else hud.classList.remove("history");
     $("historyOpen").setAttribute("aria-expanded",String(on));
   }
   var compactWindow=false;
   $("windowMode").onclick=function(){compactWindow=!compactWindow;placeWindow(compactWindow);$("windowMode").textContent=compactWindow?"工作窗口":"紧凑窗口";setStatus("已请求调整窗口；如果当前宿主未响应，可手动调整窗口大小。")};
   $("historyOpen").onclick=function(){ showHistory(!$("hud").classList.contains("history")); };
   $("threadSearch").oninput=function(){renderThreads()};
+  $("threadView").onchange=function(){renderThreads()};
   document.addEventListener("keydown",function(e){if(e.key==="Escape" && $("hud").classList.contains("history")){closeNavigation()}});
   function closeNavigation(){showHistory(false);(window.matchMedia("(min-width:760px)").matches?$("newChat"):$("historyOpen")).focus()}
   $("historyClose").onclick=closeNavigation;
   $("newChat").onclick=function(){ $("newThread").click(); };
   $("newThreadBar").onclick=function(){$("newThread").click()};
   $("newThread").onclick=function(){
+    summonerVoice.cancel();
     api("/api/threads",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(function(d){
       var id=d.thread&&d.thread.id;
       if(!id){setStatus("新建失败");return}
       showHistory(false);
       return refresh().then(function(){return selectThread(id)});
     });
   };
   $("attachFile").addEventListener("click",function(){ $("files").click(); });
   $("text").addEventListener("keydown",function(e){
     if(e.key!=="Enter" || e.isComposing || e.keyCode===229) return;
     if(e.shiftKey && !e.metaKey && !e.ctrlKey){
       if(busy){e.preventDefault();send("enqueue")}
@@ -2515,31 +2580,33 @@ try{
   });
   function refresh(){
     return api("/api/threads").then(function(d){
       threads=(d.threads||[]).slice().sort(function(a,b){
         return String(b.last_message_at||b.created_at||"").localeCompare(String(a.last_message_at||a.created_at||""));
       });
       renderThreads();
     });
   }
   var sec="threads";
   function showSec(name){
     sec=name;
-    document.querySelectorAll("#secs [data-sec]").forEach(function(b){
+    document.querySelectorAll(".list [data-sec]").forEach(function(b){
       if(b.getAttribute("data-sec")===name) b.setAttribute("aria-current","true");
       else b.removeAttribute("aria-current");
     });
     setExpanded(true);
     var heads={threads:"对话",packs:"场景",knowledge:"知识",skills:"技能",mcp:"MCP",browser:"浏览器"};
     $("threadSearchLabel").hidden=name!=="threads";
+    $("threadOrganization").hidden=name!=="threads";
+    if(name!=="threads") closeThreadMetadata();
     $("secHead").textContent=heads[name]||name;
     $("newThread").style.display=name==="threads"?"":"none";
     $("threads").style.display=name==="threads"?"":"none";
     $("composeList").style.display=name==="threads"?"none":"";
     if(name==="threads") return refresh();
     loadCompose(name);
   }
   var composeRevision=0;
   function loadCompose(name){
     var revision=++composeRevision,ownerThread=threadId;
     var target=$("composeList"),box=document.createElement("div");
     target.textContent="加载中…";
@@ -2616,25 +2683,25 @@ try{
             if(threadId!==ownerThread){loadCompose(name);return}
             if(!threadId){setStatus("没有当前对话");return}
             var next=on?cur.filter(function(x){return x!==id}):cur.concat([id]);
             api("/api/knowledge/active",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId,ids:next})}).then(function(d){if(d.error||d.type==="error") throw new Error(d.error||"保存失败");loadCompose("knowledge")}).catch(function(e){setStatus(String(e&&e.message||e))});
           };
           box.appendChild(b);
         });
       }).catch(function(e){setStatus(String(e&&e.message||e))}).then(markEmpty);
     }
     }
     return Promise.resolve(load()).then(function(){if(revision===composeRevision && sec===name && threadId===ownerThread){target.replaceChildren();while(box.firstChild)target.appendChild(box.firstChild)}});
   }
-  document.querySelectorAll("#secs [data-sec]").forEach(function(b){
+  document.querySelectorAll(".list [data-sec]").forEach(function(b){
     b.onclick=function(){showSec(b.getAttribute("data-sec"))};
   });
   $("composeList").style.display="none";
   function releaseLease(){
     if(!threadId) return;
     try{
       var body=new Blob([JSON.stringify({thread_id:threadId})],{type:"application/json"});
       navigator.sendBeacon(url("/api/lease/release"), body);
     }catch(e){}
   }
   window.addEventListener("pagehide", function(){
     if(sttLive) stopStt(true);
@@ -2696,56 +2763,61 @@ try{
         if(threadId&&tok) showStreamMsg(tok);
         return;
       }
       if(t==="chat.user"||t==="chat.steered"||t==="chat.enqueued"){
         $("text").value="";
         $("files").value="";
         setStatus(t==="chat.enqueued"?"已排队": t==="chat.steered"?"已纠偏":"已发送");
         busy=t!=="chat.enqueued"?true:busy;
         syncBusyUi();
         startPoll();
         return;
       }
+      if(t.indexOf("voice.stt.")===0 && summonerVoice.onEvent(d)) return;
       if(t==="voice.stt.partial"){
         if(meetingId){
           var pt=typeof d.text==="string"?d.text:"";
           var mp=$("meetingPartial");
           if(mp && pt) mp.textContent=pt;
         }
         return;
       }
       if(t==="voice.stt.result"){
+        // Dictation commits only its matching HTTP result. Unowned / duplicate pushes are ignored.
+        if(!meetingId) return;
         var sid=typeof d.sessionId==="string"?d.sessionId:"";
+        if(!sid || !sttFeatsBySid[sid]) return;
         var txt=typeof d.text==="string"?d.text.trim():"";
         if(txt && meetingId){
           var feat=sid&&sttFeatsBySid[sid];
           if(feat) meetingFeats.push(feat);
           else meetingFeats.push([0,0,0]);
           appendMeetingLive(txt, "");
           var mp2=$("meetingPartial");
           if(mp2) mp2.textContent="";
           api("/api/meeting/append",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:meetingId,text:txt})});
         } else if(txt && !meetingId){
           var cur=$("text").value;
           $("text").value=cur&&cur.trim()?cur.replace(/\\s*$/,"")+" "+txt:txt;
         }
         if(sttLive && (!sid || sttSid===sid)) stopStt(false);
         if(meetingId && !sttLive) startStt();
         return;
       }
       if(t==="meeting.diarized"){
         paintDiarized(d);
         return;
       }
       if(t==="voice.stt.error"){
+        if(!meetingId || d.sessionId!==sttSid) return;
         setStatus(sttUserCopy(d.code||d.error_code, d.message||d.error));
         if(sttLive) stopStt(true);
         return;
       }
       if(t==="meeting.error"){
         setStatus(sttUserCopy(d.code||d.error_code, d.message||d.error||"会议出错"));
         return;
       }
       if(t==="meeting.ended"){
         if(meetingId) lastMeetingId=meetingId;
         meetingId="";
         stopRecClock();
diff --git a/companion/src/summoner/thread-management.ts b/companion/src/summoner/thread-management.ts
new file mode 100644
index 00000000..8de40a19
--- /dev/null
+++ b/companion/src/summoner/thread-management.ts
@@ -0,0 +1,56 @@
+/** Small adapter over the same thread.update owner used by the extension. */
+export const SUMMONER_THREAD_MANAGEMENT_JS = String.raw`
+  var editingMetadata=null,metadataTrigger=null,metadataSaving=false;
+  function metadataTags(raw){
+    var seen={};
+    return raw.split(/[,，\n]/).map(function(v){return v.normalize("NFC").replace(/[\x00-\x1f\x7f]/g,"").replace(/\s+/g," ").trim()}).filter(function(v){var key=v.toLowerCase();if(!v||Object.prototype.hasOwnProperty.call(seen,key))return false;Object.defineProperty(seen,key,{value:true});return true});
+  }
+  function threadEntries(items,view){
+    var rows=[];
+    items.forEach(function(t){
+      var groups=view==="folders"?[t.topic_folder||"未分组"]:view==="ai"?[(t.digest&&t.digest.tags||[])[0]||"待 AI 整理"]:view==="tags"?metadataTags((t.user_tags||[]).concat(t.digest&&t.digest.tags||[]).join(",")):[];
+      if(!groups.length)groups=[view==="tags"?"未标注":""];
+      groups.forEach(function(group){rows.push({thread:t,group:group})});
+    });
+    if(view!=="recent") rows.sort(function(a,b){return a.group.localeCompare(b.group,"zh")});
+    return rows;
+  }
+  function closeThreadMetadata(){
+    if(metadataSaving)return;
+    $("threadMetadata").hidden=true;editingMetadata=null;
+    if(metadataTrigger&&metadataTrigger.isConnected)metadataTrigger.focus();
+    metadataTrigger=null;
+  }
+  function openThreadMetadata(t,trigger){
+    if(metadataSaving)return;
+    editingMetadata=t.id;metadataTrigger=trigger;
+    $("metadataTitle").textContent="分类 · "+(t.title||t.alias||t.id);
+    $("metadataTags").value=(t.user_tags||[]).join("，");
+    $("metadataFolder").value=t.topic_folder||"";
+    $("metadataError").textContent="";
+    $("threadFolders").replaceChildren();
+    Array.from(new Set(threads.map(function(row){return row.topic_folder}).filter(Boolean))).forEach(function(name){var option=document.createElement("option");option.value=name;$("threadFolders").appendChild(option)});
+    $("threadMetadata").hidden=false;$("metadataTags").focus();
+  }
+  $("metadataCancel").onclick=closeThreadMetadata;
+  $("threadMetadata").addEventListener("keydown",function(e){if(e.key==="Escape"&&!metadataSaving){e.preventDefault();e.stopPropagation();closeThreadMetadata()}});
+  $("threadMetadata").onsubmit=function(e){
+    e.preventDefault();if(!editingMetadata||metadataSaving)return;
+    var owner=editingMetadata,tags=metadataTags($("metadataTags").value);
+    if(tags.length>20||tags.some(function(tag){return tag.length>40})){$("metadataError").textContent="最多 20 个标签，每个不超过 40 字";return}
+    var folder=$("metadataFolder").value.normalize("NFC").replace(/[\x00-\x1f\x7f\\/]/g,"").trim()||null;
+    var updates={user_tags:tags,topic_folder:folder};
+    metadataSaving=true;$("metadataSave").disabled=true;$("metadataCancel").disabled=true;$("metadataTags").disabled=true;$("metadataFolder").disabled=true;$("metadataSave").textContent="保存中…";$("metadataError").textContent="";
+    api("/api/thread?id="+encodeURIComponent(owner),{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(updates)}).then(function(d){
+      if(!d||d.type!=="thread.updated"||!d.thread||d.thread.id!==owner)throw new Error(d&&d.error||"未收到分类保存确认");
+      var saved=d.thread;
+      if(JSON.stringify(metadataTags((saved.user_tags||[]).join(",")).map(function(t){return t.toLowerCase()}).sort())!==JSON.stringify(tags.map(function(t){return t.toLowerCase()}).sort())||(saved.topic_folder||null)!==folder)throw new Error("服务端未保存所提交的分类，请更新 Companion 后重试");
+      threads=threads.map(function(t){return t.id===owner?Object.assign({},t,saved):t});
+      renderThreads();$("threadMetadata").hidden=true;editingMetadata=null;
+      var next=document.querySelector('#threads .thread-classify');if(next)next.focus();
+      setStatus("分类已保存");
+    }).catch(function(err){$("metadataError").textContent=err&&err.message||"分类保存失败"}).finally(function(){
+      metadataSaving=false;$("metadataSave").disabled=false;$("metadataCancel").disabled=false;$("metadataTags").disabled=false;$("metadataFolder").disabled=false;$("metadataSave").textContent="保存";
+    });
+  };
+`
diff --git a/companion/src/summoner/voice-input.ts b/companion/src/summoner/voice-input.ts
new file mode 100644
index 00000000..04d4705a
--- /dev/null
+++ b/companion/src/summoner/voice-input.ts
@@ -0,0 +1,157 @@
+/** Browser-side dictation controller. Kept separate from meeting capture and navigation. */
+export const SUMMONER_DICTATION_JS = String.raw`
+function createSummonerDictation(o){
+  var current=null,acks={},pendingEngine=null,serial=0;
+  var status=document.createElement("div");
+  status.id="voiceStatus";status.className="voice-status";status.hidden=true;
+  status.setAttribute("role","status");status.setAttribute("aria-live","polite");
+  status.style.cssText="font-size:12px;line-height:1.5;padding:6px 12px;white-space:pre-wrap";
+  o.mic.parentNode.parentNode.appendChild(status);
+  function say(text){status.textContent=text||"";status.hidden=!text}
+  function post(path,body){return o.api(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)})}
+  function checked(d){
+    if(!d||d.error||d.type==="error"||d.type==="voice.stt.error"){
+      var e=new Error(d&&(d.message||d.error)||"听写服务未返回结果");e.code=d&&(d.code||d.error_code);throw e;
+    }
+    return d;
+  }
+  function live(s){return current===s && s.owner===o.threadId() && !s.cancelled}
+  function mic(on){o.mic.setAttribute("aria-pressed",on?"true":"false");o.mic.title=on?"停止听写":"听写"}
+  function cleanup(s,keepOwner){
+    clearTimeout(s.timer);clearTimeout(s.startTimer);if(!keepOwner)clearInterval(s.ownerTimer);clearTimeout(s.partialTimer);
+    if(s.proc){s.proc.onaudioprocess=null;try{s.proc.disconnect()}catch(e){}}
+    [s.src,s.mute].forEach(function(n){try{if(n)n.disconnect()}catch(e){}});
+    if(s.stream)s.stream.getTracks().forEach(function(t){t.stop()});
+    if(s.ctx)Promise.resolve(s.ctx.close()).catch(function(){});
+    s.stream=s.ctx=s.proc=null;mic(false);
+  }
+  function finish(s,text){
+    if(!live(s)){cancel(s);return}
+    var value=String(text||"").trim();
+    if(value){var old=o.input.value;o.input.value=old&&old.trim()?old.replace(/\s*$/,"")+" "+value:value;o.input.dispatchEvent(new Event("input",{bubbles:true}))}
+    cleanup(s);current=null;s.cancelled=true;say(value?"已填入草稿，请核对后发送":"没有识别到语音，请重试");
+  }
+  function copyError(e){
+    var c=String(e&&e.code||e&&e.name||"");
+    if(c==="NotAllowedError"||c==="not-allowed"||c==="service-not-allowed")return "麦克风未获授权，请在 Chrome 网站设置及系统隐私设置中允许麦克风";
+    if(c==="model_missing"||c==="binary_missing")return "本机听写组件未就绪，请在 Chrome 侧栏的设置 → 输入与语音中下载组件和模型";
+    if(c==="engine_not_local")return "听写引擎配置已变化，请重新开始听写";
+    if(c==="network")return "浏览器语音服务连接失败，请检查网络或在 Chrome 侧栏设置 → 输入与语音中选择本机听写";
+    if(c==="no-speech"||c==="empty_result")return "没有识别到语音，请重试";
+    return e&&e.message||"听写失败，请重试";
+  }
+  function cancel(s){
+    s=s||current;if(!s||s.cancelled)return;
+    s.cancelled=true;cleanup(s);if(current===s)current=null;
+    if(s.rec){try{s.rec.abort()}catch(e){}}
+    // Queue abort after any start/chunk already in flight so delayed start cannot leak a session.
+    s.queue.catch(function(){}).then(function(){if(s.started)return post("/api/stt/abort",{sessionId:s.sid})}).catch(function(){});
+    say("已取消听写");
+  }
+  function fail(s,e){if(current!==s||s.cancelled)return;cancel(s);say(copyError(e))}
+  function applyEvent(d){
+    var s=current;if(!s||!d||d.sessionId!==s.sid)return false;
+    if(!live(s)){cancel(s);return true}
+    if(d.type==="voice.stt.error"){fail(s,{code:d.code||d.error_code,message:d.message||d.error});return true}
+    // The final HTTP response is authoritative; an SSE duplicate cannot commit twice.
+    if(d.type==="voice.stt.partial" && d.status==="hypothesis" && !s.stopping && d.text)say("正在听写… "+d.text);
+    return true;
+  }
+  function startBrowser(s){
+    var C=window.SpeechRecognition||window.webkitSpeechRecognition;
+    if(!C){fail(s,new Error("此浏览器不支持浏览器听写，请在 Chrome 侧栏设置 → 输入与语音中选择本机听写"));return}
+    var rec=new C();s.rec=rec;s.finals=[];rec.lang=s.settings.lang||"zh-CN";rec.continuous=true;rec.interimResults=true;rec.maxAlternatives=1;
+    rec.onstart=function(){if(live(s)){clearTimeout(s.startTimer);say("正在听写… 再点麦克风结束");mic(true)}};
+    rec.onresult=function(ev){
+      if(!live(s))return;
+      var interim="";
+      for(var i=ev.resultIndex||0;i<ev.results.length;i++){
+        var r=ev.results[i],text=r[0]&&r[0].transcript||"";
+        if(r.isFinal)s.finals[i]=text;else interim+=text;
+      }
+      say("正在听写… "+s.finals.join("")+interim);
+    };
+    rec.onerror=function(e){if(e.error!=="aborted")fail(s,{code:e.error,message:"浏览器听写失败"})};
+    rec.onend=function(){if(live(s))finish(s,s.finals.join(""))};
+    try{rec.start();s.timer=setTimeout(function(){stop()},45000)}catch(e){fail(s,e)}
+  }
+  function queueChunk(s,bytes){
+    var seq=s.seq++,binary="";for(var i=0;i<bytes.length;i++)binary+=String.fromCharCode(bytes[i]);
+    var data=btoa(binary);
+    s.queue=s.queue.then(function(){if(!live(s))return;return post("/api/stt/chunk",{sessionId:s.sid,seq:seq,data:data}).then(checked)});
+    s.queue.catch(function(e){fail(s,e)});
+  }
+  function flush(s){if(!s.buf.length)return;var b=s.buf;s.buf=new Uint8Array(0);queueChunk(s,b)}
+  function poll(s){
+    if(!live(s)||s.stopping||s.settings.sttEngine!=="local"||s.settings.localModelId==="large-v3-turbo")return;
+    s.partialTimer=setTimeout(function(){
+      if(!live(s)||s.stopping)return;
+      // A single outstanding partial; final end is independent and cancels it server-side.
+      s.queue.then(function(){if(!live(s)||s.stopping)return;return post("/api/stt/partial",{sessionId:s.sid})}).then(function(d){if(d)applyEvent(d)}).catch(function(){}).finally(function(){poll(s)});
+    },1400);
+  }
+  function startLocal(s){
+    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){fail(s,new Error("此窗口无法访问麦克风"));return}
+    navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}}).then(function(stream){
+      if(!live(s)){stream.getTracks().forEach(function(t){t.stop()});return}
+      s.stream=stream;var AC=window.AudioContext||window.webkitAudioContext;if(!AC)throw new Error("此窗口无法捕获麦克风音频");
+      var ctx=new AC();s.ctx=ctx;
+      return Promise.resolve(ctx.state==="suspended"?ctx.resume():undefined).then(function(){
+        if(!live(s))return;
+        s.queue=post("/api/stt/start",{sessionId:s.sid,modelId:s.settings.localModelId,engine:s.settings.sttEngine,privacy_ack_v2:true,lang:s.settings.lang||"zh-CN",maxMs:45000}).then(function(d){checked(d);s.started=true;return d});
+        return s.queue.then(function(){
+          if(!live(s))return;
+          s.src=ctx.createMediaStreamSource(stream);s.proc=ctx.createScriptProcessor(4096,1,1);s.mute=ctx.createGain();s.mute.gain.value=0;
+          s.proc.onaudioprocess=function(ev){
+            if(!live(s)||s.stopping)return;
+            var input=ev.inputBuffer.getChannelData(0),rate=ctx.sampleRate||48000;
+            var n=Math.max(1,Math.round(input.length*16000/rate)),bytes=new Uint8Array(n*2),v=new DataView(bytes.buffer);
+            for(var i=0;i<n;i++){var pos=i*rate/16000,a=Math.min(Math.floor(pos),input.length-1),b=Math.min(a+1,input.length-1),f=pos-a;var x=Math.max(-1,Math.min(1,input[a]*(1-f)+input[b]*f));v.setInt16(i*2,Math.round(x<0?x*32768:x*32767),true)}
+            var buf=new Uint8Array(s.buf.length+bytes.length);buf.set(s.buf);buf.set(bytes,s.buf.length);s.buf=buf;if(s.buf.length>=32000)flush(s);
+          };
+          s.src.connect(s.proc);s.proc.connect(s.mute);s.mute.connect(ctx.destination);clearTimeout(s.startTimer);mic(true);say("正在听写… 再点麦克风结束");
+          // Finish ahead of the daemon's 45 s recording lease so final upload can drain.
+          s.timer=setTimeout(function(){stop()},44000);poll(s);
+        });
+      });
+    }).catch(function(e){fail(s,e)});
+  }
+  function begin(settings){
+    if(current||o.blocked())return;
+    var s={sid:"dict-"+Date.now().toString(36)+"-"+(++serial),owner:o.threadId(),settings:settings,queue:Promise.resolve(),buf:new Uint8Array(0),seq:0};
+    current=s;mic(true);say("正在请求麦克风…");
+    s.ownerTimer=setInterval(function(){if(!live(s))cancel(s)},200);
+    // Bound the permission/start phase; permission resolution after cancel is harmless.
+    s.startTimer=setTimeout(function(){fail(s,new Error("麦克风启动超时，请检查浏览器权限后重试"))},15000);
+    if(settings.sttEngine==="browser")startBrowser(s);else startLocal(s);
+  }
+  function stop(){
+    var s=current;if(!s)return;
+    if(s.stopping){cancel(s);return}
+    if(s.rec){s.stopping=true;say("正在完成识别…");try{s.rec.stop()}catch(e){fail(s,e)};clearTimeout(s.timer);s.timer=setTimeout(function(){if(live(s))finish(s,s.finals.join(""))},5000);return}
+    if(!s.started||!s.proc){cancel(s);return}
+    s.stopping=true;flush(s);cleanup(s,true);say("正在识别… 再点麦克风取消");
+    s.queue.then(function(){if(!live(s))return;return post("/api/stt/end",{sessionId:s.sid,totalSeq:s.seq})}).then(function(d){if(!live(s)||!d)return;checked(d);if(d.type!=="voice.stt.result")throw new Error("听写服务没有返回识别结果");finish(s,d.text)}).catch(function(e){fail(s,e)});
+  }
+  var requested=0;
+  function toggle(){
+    if(current){stop();return}
+    if(o.blocked()){say("请先结束会议录音");return}
+    var turn=++requested;say("正在准备听写…");
+    o.api("/api/voice-settings").then(function(settings){
+      if(turn!==requested||current)return;
+      checked(settings);if(["browser","local","system"].indexOf(settings.sttEngine)<0)throw new Error("无法读取听写引擎，请重试");
+      if(!acks[settings.sttEngine]){pendingEngine=settings;o.privacy(settings.sttEngine);say("");return}
+      begin(settings);
+    }).catch(function(e){say(copyError(e))});
+  }
+  return {toggle:toggle,cancel:function(){requested++;pendingEngine=null;cancel()},active:function(){return !!current},onEvent:applyEvent,ack:function(){if(!pendingEngine)return;var settings=pendingEngine;pendingEngine=null;acks[settings.sttEngine]=true;begin(settings)}};
+}
+`
+
+/** Voice final decode can outlive ordinary metadata requests. */
+export function summonerVoiceRequestTimeout(type: string): number | undefined {
+  if (type === "voice.stt.end") return 305_000
+  if (type === "voice.stt.partial_request") return 30_000
+  return undefined
+}
diff --git a/companion/src/threads/metadata-patch.ts b/companion/src/threads/metadata-patch.ts
new file mode 100644
index 00000000..62bb97bd
--- /dev/null
+++ b/companion/src/threads/metadata-patch.ts
@@ -0,0 +1,26 @@
+import { sanitizeUserTags } from "./user-tags"
+import { sanitizeTopicFolder } from "./distill"
+
+/** Existing metadata only; never pass arbitrary thread policy/config through HTTP. */
+export function summonerThreadMetadata(body: unknown): Record<string, unknown> {
+  if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("分类必须是对象")
+  const fields = body as Record<string, unknown>
+  const keys = Object.keys(fields)
+  if (!keys.length || keys.some(key => !["alias", "user_tags", "topic_folder"].includes(key))) {
+    throw new Error("仅支持修改名称、人工标签和手动分组")
+  }
+  const result: Record<string, unknown> = {}
+  if ("alias" in fields) {
+    if (typeof fields.alias !== "string" || !fields.alias.trim()) throw new Error("名称不能为空")
+    const alias = fields.alias.replace(/[\x00-\x1f\x7f]/g, "").trim().slice(0, 200)
+    if (!alias) throw new Error("名称不能为空")
+    result.alias = alias
+  }
+  if ("user_tags" in fields) result.user_tags = sanitizeUserTags(fields.user_tags)
+  if ("topic_folder" in fields) {
+    if (fields.topic_folder !== null && typeof fields.topic_folder !== "string") throw new Error("分组必须是名称或空值")
+    result.topic_folder = sanitizeTopicFolder(fields.topic_folder)
+  }
+  return result
+}
+
diff --git a/companion/src/ws/summoner-acl.ts b/companion/src/ws/summoner-acl.ts
index 62bbaa58..27f0c673 100644
--- a/companion/src/ws/summoner-acl.ts
+++ b/companion/src/ws/summoner-acl.ts
@@ -1,23 +1,24 @@
 import { isUiCommandAction } from "../ui-command"
+import { summonerThreadMetadata } from "../threads/metadata-patch"
 
 /** Per-connection method ACL keyed off handshake `surface` (S21).
  *
  * Origin stays `cmspark-tray://local`. Summoner is a second tray-origin WS
  * that must not run trust-elevation / settings / pack / MCP mutate / confirm.
  * Overlay chat.create already sees companion MCP tools; `mcp.list` is read-only
  * so the overlay can show connected servers. `mcp.add` stays denied.
  * `pack.apply` is allowed but router forces allowTrust=false + overlay-eligible.
  * `thread.delete` / `thread.update` are overlay-safe only via
- * `applySummonerPayloadPolicy` (trash-only; alias-only).
+ * `applySummonerPayloadPolicy` (trash-only; name/tags/folder-only).
  * Tray (`surface !== "summoner"`, including omitted/undefined) is not gated —
  * origin-cleaving would break tray `skill.list`.
  */
 
 const SUMMONER_ALLOW = new Set([
   "system.ping",
   "chat.create",
   "chat.abort",
   "chat.steer",
   "thread.list",
   "thread.select",
   "thread.create",
@@ -63,70 +64,52 @@ export function assertSummonerAllowed(
   surface: string | undefined,
   type: string,
 ): { ok: true } | { ok: false; error_code: "SUMMONER_ACL"; error: string } {
   if (surface !== "summoner") return { ok: true }
   if (SUMMONER_ALLOW.has(type)) return { ok: true }
   return {
     ok: false,
     error_code: "SUMMONER_ACL",
     error: `SUMMONER_ACL: ${type} not allowed on summoner surface`,
   }
 }
 
-function overlayAlias(raw: unknown): string | null {
-  if (typeof raw !== "string") return null
-  const alias = raw.replace(/[\x00-\x1F\x7F]/g, "").trim().slice(0, 200)
-  return alias || null
-}
-
 /**
  * Overlay-safe payload gate. Method allowlist is not enough: tray `thread.delete`
  * defaults to hard, and `thread.update` can mutate tool_whitelist / knowledge ids.
- * Mutates `msg` in place (strips non-alias updates). Tray / omitted surface: no-op.
+ * Mutates `msg` in place with validated metadata; rejects all other update keys. Tray / omitted surface: no-op.
  */
 export function applySummonerPayloadPolicy(
   surface: string | undefined,
   msg: Record<string, unknown>,
 ): { ok: true } | { ok: false; error_code: "SUMMONER_ACL"; error: string } {
   if (surface !== "summoner") return { ok: true }
   const type = msg.type
   if (type === "thread.delete") {
     if (msg.mode !== "trash") {
       return {
         ok: false,
         error_code: "SUMMONER_ACL",
         error: "SUMMONER_ACL: thread.delete on overlay must use mode=trash",
       }
     }
     return { ok: true }
   }
   if (type === "thread.update") {
-    const updates = msg.updates
-    if (!updates || typeof updates !== "object" || Array.isArray(updates)) {
-      return {
-        ok: false,
-        error_code: "SUMMONER_ACL",
-        error: "SUMMONER_ACL: thread.update overlay may only set alias",
-      }
+    try {
+      msg.updates = summonerThreadMetadata(msg.updates)
+      return { ok: true }
+    } catch (error) {
+      return { ok: false, error_code: "SUMMONER_ACL", error: "SUMMONER_ACL: " + (error instanceof Error ? error.message : "invalid metadata") }
     }
-    const alias = overlayAlias((updates as { alias?: unknown }).alias)
-    if (!alias) {
-      return {
-        ok: false,
-        error_code: "SUMMONER_ACL",
-        error: "SUMMONER_ACL: thread.update overlay may only set alias",
-      }
-    }
-    msg.updates = { alias }
-    return { ok: true }
   }
   if (type === "knowledge.set_active") {
     const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
     if (!threadId) {
       return {
         ok: false,
         error_code: "SUMMONER_ACL",
         error: "SUMMONER_ACL: knowledge.set_active requires thread_id",
       }
     }
     const raw = Array.isArray(msg.ids) ? msg.ids : []
     const ids = raw.filter((id): id is string => typeof id === "string" && id.trim().length > 0).slice(0, 32)
diff --git a/companion/tests/acp-handlers-gates.test.ts b/companion/tests/acp-handlers-gates.test.ts
index b8334111..f72f2852 100644
--- a/companion/tests/acp-handlers-gates.test.ts
+++ b/companion/tests/acp-handlers-gates.test.ts
@@ -370,13 +370,73 @@ describe("acp manager protocol argv wiring", () => {
         acp: {
           enabled: false,
           servers: {},
           policy: {
             require_workspace: true,
             force_confirm_session_start: true,
             default_profile: "review_readonly",
           },
         },
       })
     }
   })
+
+  it("#483 rejects an explicit wrong owner before cancel, prompt, followup or apply can act", async () => {
+    const fs = await import("node:fs")
+    const os = await import("node:os")
+    const path = await import("node:path")
+    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "acp-owner-483-"))
+    try {
+      saveConfig({ acp: { enabled: true, servers: { echo: {
+        enabled: true, display_name: "Echo", command: process.execPath, args: ["-e", "process.exit(0)"], protocol: "cli", transport: "stdio",
+        policy: { profile: "propose_diff", allow_write: false, allow_exec: false },
+      } }, policy: { require_workspace: true, force_confirm_session_start: true, default_profile: "review_readonly" } } })
+      const mgr = getAcpManager()
+      const proposed = mgr.propose({ threadId: "owner-a", agentId: "echo", goal: "review A", workspaceRoot: dir, mode: "propose_diff" })
+      assert.equal(proposed.ok, true)
+      if (!proposed.ok) return
+      let confirmations = 0
+      for (const type of ["acp.session.cancel", "acp.session.prompt", "acp.session.followup", "acp.apply_diff"]) {
+        const reply = await handleAcpWsMessage(type, {
+          session_id: proposed.session.session_id, thread_id: "other-b", text: "do not run", goal: "do not run",
+        }, { requestConfirmation: async () => { confirmations++; return { approved: true } as any } })
+        assert.equal(reply.type, "error", type)
+        assert.equal(reply.thread_id, proposed.session.thread_id, type)
+        assert.equal(reply.session_id, proposed.session.session_id, type)
+        assert.match(reply.error, /does not belong/, type)
+        assert.equal(mgr.getSession(proposed.session.session_id)?.state, "offered", type)
+      }
+      assert.equal(confirmations, 0)
+      const ownedApply = await handleAcpWsMessage("acp.apply_diff", {
+        session_id: proposed.session.session_id, thread_id: "owner-a",
+      }, { requestConfirmation: async () => { confirmations++; return { approved: false } as any } })
+      assert.equal(ownedApply.type, "acp.apply_diff.denied")
+      assert.equal(ownedApply.thread_id, "owner-a")
+      assert.equal(confirmations, 1, "correct owner reaches the unchanged confirmation gate")
+      const malformed = await handleAcpWsMessage("acp.session.cancel", { session_id: proposed.session.session_id, thread_id: "" }, {})
+      assert.equal(malformed.type, "error")
+      const nullOwner = await handleAcpWsMessage("acp.session.cancel", { session_id: proposed.session.session_id, thread_id: null }, {})
+      assert.equal(nullOwner.type, "error")
+      const parentFallback = await handleAcpWsMessage("acp.session.followup", { session_id: "", parent_session_id: proposed.session.session_id, thread_id: "other-b", goal: "do not run" }, {})
+      assert.match(parentFallback.error, /does not belong/)
+      // Existing callers without thread_id still operate on the stored owner.
+      const legacyCancel = await handleAcpWsMessage("acp.session.cancel", { session_id: proposed.session.session_id }, {})
+      assert.equal(legacyCancel.type, "acp.session.cancel.ack")
+      assert.equal(legacyCancel.thread_id, "owner-a")
+      assert.equal(legacyCancel.session_id, proposed.session.session_id)
+    } finally {
+      fs.rmSync(dir, { recursive: true, force: true })
+    }
+  })
+
+  it("#483 pre-session start errors carry the explicitly requested thread; missing prompt session is not invented", async () => {
+    const start = await handleAcpWsMessage("acp.ui_start", { thread_id: "owner-a", agent_id: "echo", goal: "review", cloud_disclosure_accepted: true }, {})
+    assert.equal(start.type, "error")
+    assert.equal(start.thread_id, "owner-a")
+    assert.equal(start.family, "acp")
+    const prompt = await handleAcpWsMessage("acp.session.prompt", { session_id: "absent", text: "continue" }, { threadId: "foreground-b" })
+    assert.equal(prompt.type, "error")
+    assert.equal(prompt.session_id, "absent")
+    assert.equal(prompt.thread_id, undefined)
+  })
+
 })
diff --git a/companion/tests/summoner-capture-card-threads.test.ts b/companion/tests/summoner-capture-card-threads.test.ts
index 68bb03fb..d99d2e26 100644
--- a/companion/tests/summoner-capture-card-threads.test.ts
+++ b/companion/tests/summoner-capture-card-threads.test.ts
@@ -34,63 +34,63 @@ test("#243 ① 顶栏保留新对话，#477 导航取代历史盖层", () => {
 test("#243 ② 「新对话」清空到文字空态（newChat → newThread → create → selectThread → renderMsgs 空）", () => {
   assert.match(web, /\$\("newChat"\)\.onclick=function\(\)\{ \$\("newThread"\)\.click\(\); \};/)
   assert.match(
     web,
     /\$\("newThread"\)\.onclick=function\(\)\{[\s\S]{0,400}?api\("\/api\/threads",\{method:"POST"/,
   )
   assert.match(
     web,
     /method:"POST"[\s\S]{0,300}?showHistory\(false\);[\s\S]{0,200}?selectThread\(id\)/,
   )
   assert.match(
     web,
-    /function selectThread\(id\)\{[\s\S]{0,1000}?renderMsgs\(d\.messages\|\|\[\]\)/,
+    /function selectThread\(id\)\{[\s\S]{0,1800}?renderMsgs\(d\.messages\|\|\[\]\)/,
   )
   // 空线程渲染文字空态：无装饰标识 + 无任务标题 + 发送提示（不是工作台首页）
   assert.match(
     web,
     /if\(!n\)\{[\s\S]{0,400}?empty\.id="empty";[\s\S]{0,300}?<strong>\$\{CHAT_SHELL_TITLE_NONE\}<\/strong>回车发送。/,
   )
   assert.equal(CHAT_SHELL_TITLE_NONE, "要我帮你做什么？")
 })
 
 test("#243 ③ 「历史」盖住卡片列出会话：点选进入、重命名、移到回收站", () => {
   // #477 replaces full-card overlay with in-flow navigation; browser harness verifies Stop remains reachable.
   assert.match(web, /\$\("historyClose"\)\.onclick=closeNavigation;/)
-  assert.match(web, /function renderThreads\(filter\)\{[\s\S]{0,450}?threads\.forEach/)
+  assert.match(web, /function renderThreads\(filter\)\{[\s\S]{0,500}?listed\.forEach/)
 
   // 点选进入（selectThread 内含 showHistory(false)，选完收起盖层）
-  assert.match(web, /b\.onclick=function\(\)\{selectThread\(t\.id\)\};/)
+  assert.match(web, /b\.onclick=function\(\)\{closeThreadMetadata\(\);selectThread\(t\.id\)\};/)
   assert.match(web, /function selectThread\(id\)\{[\s\S]{0,200}?showHistory\(false\);/)
 
   // 重命名：prompt → PATCH alias（trim 后上送）→ refresh
   assert.match(web, /window\.prompt\("重命名", title\)/)
   assert.match(
     web,
     /method:"PATCH"[\s\S]{0,200}?body:JSON\.stringify\(\{alias:String\(alias\)\.trim\(\)\}\)/,
   )
 
   // 移到回收站：confirm → DELETE；删的是当前线程时落到最新一条或新对话
   assert.match(web, /window\.confirm\("把「"\+title\+"」移到回收站？"\)/)
   assert.match(web, /api\("\/api\/thread\?id="\+encodeURIComponent\(t\.id\),\{method:"DELETE"\}\)/)
   assert.match(
     web,
     /threads\[0\]\.id[\s\S]{0,200}?\$\("newThread"\)\.click\(\);/,
   )
 })
 
-test("#243 ③' 服务端合同复用：PATCH=thread.update(alias)、DELETE=thread.delete(trash)、list/create 原样", () => {
+test("#243 ③' 服务端合同复用：PATCH=thread.update(metadata)、DELETE=thread.delete(trash)、list/create 原样", () => {
   assert.match(
     web,
-    /dispatchAllowed\("thread\.update", \{ thread_id: id, updates: \{ alias \} \}\)/,
+    /dispatchAllowed\("thread\.update", \{ thread_id: id, updates \}\)/,
   )
   assert.match(
     web,
     /dispatchAllowed\("thread\.delete", \{ thread_id: id, mode: "trash" \}\)/,
   )
   assert.match(web, /dispatchAllowed\("thread\.list", \{\}\)/)
   assert.match(web, /dispatchAllowed\("thread\.create", \{\}\)/)
   assert.doesNotMatch(web, /mode:\s*"hard"/)
   // 复用既有 dispatch 允许集，不新造通道
   for (const t of ["thread.create", "thread.list", "thread.select", "thread.update", "thread.delete"]) {
     assert.equal(SUMMONER_WEB_DISPATCH_ALLOW.has(t), true, t)
   }
diff --git a/companion/tests/summoner-thread-manage.test.ts b/companion/tests/summoner-thread-manage.test.ts
index 0a5c89c9..a477782d 100644
--- a/companion/tests/summoner-thread-manage.test.ts
+++ b/companion/tests/summoner-thread-manage.test.ts
@@ -57,33 +57,32 @@ test("overlay thread.delete must be trash; hard and omitted are ACL-denied", ()
     thread_id: "t1",
   })
   assert.equal(omitted.ok, false)
   if (!omitted.ok) assert.equal(omitted.error_code, "SUMMONER_ACL")
 
   const trayHard = applySummonerPayloadPolicy("tray", {
     type: "thread.delete",
     thread_id: "t1",
   })
   assert.equal(trayHard.ok, true)
 })
 
-test("overlay thread.update keeps only alias and rejects empty / dangerous keys-only", () => {
+test("overlay thread.update rejects mixed dangerous keys and preserves tray policy", () => {
   const msg: Record<string, unknown> = {
     type: "thread.update",
     thread_id: "t1",
     updates: { alias: "  发票  ", tool_whitelist: null, active_knowledge_ids: ["k1"] },
   }
   const ok = applySummonerPayloadPolicy("summoner", msg)
-  assert.equal(ok.ok, true)
-  assert.deepEqual(msg.updates, { alias: "发票" })
+  assert.equal(ok.ok, false)
 
   const empty = applySummonerPayloadPolicy("summoner", {
     type: "thread.update",
     thread_id: "t1",
     updates: { alias: "   " },
   })
   assert.equal(empty.ok, false)
 
   const onlyWl = applySummonerPayloadPolicy("summoner", {
     type: "thread.update",
     thread_id: "t1",
     updates: { tool_whitelist: null },
diff --git a/companion/tests/summoner-thread-metadata-481.test.ts b/companion/tests/summoner-thread-metadata-481.test.ts
new file mode 100644
index 00000000..4513f194
--- /dev/null
+++ b/companion/tests/summoner-thread-metadata-481.test.ts
@@ -0,0 +1,23 @@
+import test from "node:test"
+import assert from "node:assert/strict"
+import { summonerThreadMetadata } from "../src/threads/metadata-patch"
+import { applySummonerPayloadPolicy } from "../src/ws/summoner-acl"
+
+test("HTTP and summoner WS share an exact metadata boundary", () => {
+  const input = { alias: "  回顾\u0000  ", user_tags: ["Review", "review", "支付"], topic_folder: "收入/支付" }
+  const expected = { alias: "回顾", user_tags: ["Review", "支付"], topic_folder: "收入支付" }
+  assert.deepEqual(summonerThreadMetadata(input), expected)
+  const msg: Record<string, unknown> = { type: "thread.update", thread_id: "t1", updates: input }
+  assert.deepEqual(applySummonerPayloadPolicy("summoner", msg), { ok: true })
+  assert.deepEqual(msg.updates, expected)
+  assert.deepEqual(summonerThreadMetadata({ user_tags: [], topic_folder: null }), { user_tags: [], topic_folder: null })
+})
+
+test("metadata cannot carry policy, project, path or model changes even with a valid alias", () => {
+  for (const key of ["workspace_root", "project_id", "config_override", "tool_whitelist", "active_skill_ids", "execution_policy", "digest", "__proto__", "constructor"]) {
+    const input = JSON.parse(JSON.stringify({ alias: "safe", [key]: "unsafe" }))
+    assert.throws(() => summonerThreadMetadata(input))
+    assert.equal(applySummonerPayloadPolicy("summoner", { type: "thread.update", updates: input }).ok, false)
+  }
+  for (const input of [null, [], {}, { alias: "\u0000" }, { user_tags: Array(21).fill("x") }, { topic_folder: {} }]) assert.throws(() => summonerThreadMetadata(input))
+})
diff --git a/companion/tests/summoner-voice-input.test.ts b/companion/tests/summoner-voice-input.test.ts
new file mode 100644
index 00000000..0767a54a
--- /dev/null
+++ b/companion/tests/summoner-voice-input.test.ts
@@ -0,0 +1,124 @@
+import test from "node:test"
+import assert from "node:assert/strict"
+import vm from "node:vm"
+import { SUMMONER_DICTATION_JS, summonerVoiceRequestTimeout } from "../src/summoner/voice-input"
+
+const settle = async () => { for (let i = 0; i < 20; i++) await Promise.resolve() }
+function deferred<T>() { let resolve!: (v: T) => void; const promise = new Promise<T>((r) => { resolve = r }); return { promise, resolve } }
+
+function fixture(engine = "local", response?: (path: string, data: any) => unknown) {
+  const requests: { path: string; data: any }[] = []
+  const elements: any[] = []
+  let owner = "thread-a", stopped = 0, processor: any, recognition: any
+  const parent = { appendChild: (el: any) => elements.push(el) }
+  const mic = { parentNode: { parentNode: parent }, setAttribute() {} }
+  const input = { value: "原草稿", dispatchEvent() {} }
+  const stream = { getTracks: () => [{ stop: () => { stopped++ } }] }
+  const node = () => ({ connect() {}, disconnect() {} })
+  class AudioContext {
+    state = "running"; sampleRate = 16000
+    createMediaStreamSource() { return node() }
+    createScriptProcessor() { processor = { ...node(), onaudioprocess: null }; return processor }
+    createGain() { return { ...node(), gain: { value: 0 } } }
+    close() { return Promise.resolve() }
+  }
+  class SpeechRecognition {
+    onstart?: () => void; onresult?: (e: any) => void; onend?: () => void
+    constructor() { recognition = this }
+    start() { queueMicrotask(() => this.onstart?.()) }
+    stop() { queueMicrotask(() => this.onend?.()) }
+    abort() {}
+  }
+  const context = vm.createContext({
+    window: { AudioContext, SpeechRecognition }, navigator: { mediaDevices: { getUserMedia: async () => stream } },
+    document: { createElement: () => ({ style: {}, setAttribute() {} }) },
+    Event: class {}, btoa: (v: string) => Buffer.from(v, "binary").toString("base64"),
+    setTimeout, clearTimeout, setInterval, clearInterval, Promise, Uint8Array, DataView,
+  })
+  vm.runInContext(SUMMONER_DICTATION_JS, context)
+  const controller = context.createSummonerDictation({
+    mic, input, threadId: () => owner, blocked: () => false, privacy() {},
+    api: async (path: string, opts: any) => {
+      const data = opts?.body ? JSON.parse(opts.body) : undefined; requests.push({ path, data })
+      if (path === "/api/voice-settings") return { sttEngine: engine, localModelId: "medium", lang: "zh-CN" }
+      if (response) { const value = response(path, data); if (value !== undefined) return value }
+      if (path === "/api/stt/end") return { type: "voice.stt.result", sessionId: data.sessionId, text: "识别结果" }
+      return { type: "ok" }
+    },
+  })
+  return {
+    controller, requests, input, elements, get stopped() { return stopped }, get recognition() { return recognition },
+    owner: (v: string) => { owner = v },
+    audio: () => processor.onaudioprocess?.({ inputBuffer: { getChannelData: () => new Float32Array(16000) } }),
+    start: async () => { controller.toggle(); await settle(); controller.ack(); await settle() },
+  }
+}
+
+test("#482 browser engine uses browser recognition, previews immediately and never posts local STT", async () => {
+  const f = fixture("browser"); await f.start()
+  try {
+    assert.match(f.elements[0].textContent, /正在听写/)
+    f.recognition.onresult({ resultIndex: 0, results: [{ 0: { transcript: "即时预览" }, isFinal: false }] })
+    assert.match(f.elements[0].textContent, /即时预览/)
+    assert.equal(f.input.value, "原草稿")
+    f.recognition.onresult({ resultIndex: 0, results: [{ 0: { transcript: "最终结果" }, isFinal: true }] })
+    f.controller.toggle(); await settle()
+    assert.equal(f.input.value, "原草稿 最终结果")
+    assert.equal(f.requests.filter((r) => r.path.startsWith("/api/stt/")).length, 0)
+  } finally { f.controller.cancel() }
+})
+
+test("#482 local HTTP final commits without SSE; chunks finish in sequence before end", async () => {
+  const first = deferred<any>()
+  const f = fixture("local", (path, data) => path === "/api/stt/chunk" && data.seq === 0 ? first.promise : undefined)
+  await f.start()
+  try {
+    f.audio(); f.audio(); f.controller.toggle(); await settle()
+    assert.equal(f.requests.filter((r) => r.path === "/api/stt/chunk").length, 1)
+    assert.equal(f.requests.some((r) => r.path === "/api/stt/end"), false)
+    assert.match(f.elements[0].textContent, /正在识别/)
+    first.resolve({ type: "ok" }); await settle()
+    assert.deepEqual(f.requests.filter((r) => r.path.startsWith("/api/stt/")).map((r) => r.path), ["/api/stt/start", "/api/stt/chunk", "/api/stt/chunk", "/api/stt/end"])
+    assert.equal(f.requests.find((r) => r.path === "/api/stt/end")?.data.totalSeq, 2)
+    assert.equal(f.input.value, "原草稿 识别结果")
+    const sid = f.requests.find((r) => r.path === "/api/stt/start")?.data.sessionId
+    assert.equal(f.controller.onEvent({ type: "voice.stt.result", sessionId: sid, text: "重复" }), false)
+    assert.equal(f.input.value, "原草稿 识别结果")
+    assert.ok(f.stopped > 0)
+  } finally { f.controller.cancel() }
+})
+
+test("#482 a delayed result cannot enter another thread or a cancelled dictation", async () => {
+  for (const cancel of [false, true]) {
+    const end = deferred<any>()
+    const f = fixture("local", (path) => path === "/api/stt/end" ? end.promise : undefined)
+    await f.start(); f.audio(); f.controller.toggle(); await settle()
+    if (cancel) f.controller.cancel(); else f.owner("thread-b")
+    end.resolve({ type: "voice.stt.result", text: "旧会话结果" }); await settle()
+    assert.equal(f.input.value, "原草稿"); f.controller.cancel()
+  }
+})
+
+test("#482 cancel while start is pending releases mic and aborts after start acknowledgement", async () => {
+  const start = deferred<any>()
+  const f = fixture("local", (path) => path === "/api/stt/start" ? start.promise : undefined)
+  await f.start(); f.controller.cancel(); start.resolve({ type: "ok" }); await settle()
+  assert.ok(f.stopped > 0)
+  assert.deepEqual(f.requests.filter((r) => r.path.startsWith("/api/stt/")).map((r) => r.path), ["/api/stt/start", "/api/stt/abort"])
+  assert.equal(f.controller.active(), false)
+})
+
+test("#482 upload failures stop capture and never call end or commit partial text", async () => {
+  const f = fixture("local", (path) => path === "/api/stt/chunk" ? { type: "error", error: "连接已断开" } : undefined)
+  await f.start(); f.audio(); await settle()
+  assert.equal(f.controller.active(), false); assert.ok(f.stopped > 0)
+  assert.match(f.elements[0].textContent, /连接已断开/)
+  assert.equal(f.requests.some((r) => r.path === "/api/stt/end"), false)
+  assert.equal(f.input.value, "原草稿")
+})
+
+test("#482 voice final / partial transport deadlines cover the inference budgets", () => {
+  assert.ok(summonerVoiceRequestTimeout("voice.stt.end")! > 300_000)
+  assert.ok(summonerVoiceRequestTimeout("voice.stt.partial_request")! > 25_000)
+  assert.equal(summonerVoiceRequestTimeout("thread.list"), undefined)
+})
diff --git a/companion/tests/summoner-web.test.ts b/companion/tests/summoner-web.test.ts
index 70d68bb1..1269515d 100644
--- a/companion/tests/summoner-web.test.ts
+++ b/companion/tests/summoner-web.test.ts
@@ -96,25 +96,25 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     attachCalls.length = 0
     const started = await startSummonerWebServer({
       preferredPort: 23510,
       attachChrome: (opts) => {
         attachCalls.push({ foreground: opts?.foreground })
         return opts?.foreground
           ? "已打开并前置浏览器。我们不能替你打开侧栏。要盯着页面，请点工具栏的 CMspark。"
           : "已在后台打开浏览器。我们不能替你打开侧栏。要盯着页面，请点工具栏的 CMspark。"
       },
       dispatch: async (msg) => {
         dispatched.push(msg)
         if (msg.type === "thread.list") return { type: "thread.list", threads: [{ id: "t1", title: "One" }] }
-        if (msg.type === "thread.update") return { type: "thread.updated", thread: { id: msg.thread_id, alias: (msg.updates as any)?.alias } }
+        if (msg.type === "thread.update") return { type: "thread.updated", thread: { id: msg.thread_id, ...(msg.updates as any) } }
         if (msg.type === "thread.delete") return { type: "thread.trashed", thread_id: msg.thread_id, mode: msg.mode }
         if (msg.type === "file.upload") return { type: "file.uploaded", thread_id: msg.thread_id, files: ["a.txt"] }
         if (msg.type === "pack.apply") return { type: "pack.applied", pack_id: msg.pack_id }
         if (msg.type === "composer.lease.get") {
           return { type: "composer.lease", thread_id: msg.thread_id, holder: "panel", rev: 3 }
         }
         if (msg.type === "composer.lease.claim") {
           return { type: "composer.lease", thread_id: msg.thread_id, holder: msg.holder, rev: 4 }
         }
         if (msg.type === "composer.lease.release") {
           return { type: "composer.lease", thread_id: msg.thread_id, holder: "panel", rev: 5 }
         }
@@ -238,25 +238,25 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     assert.match(r.body, /@keyframes streamBlink/)
     assert.match(r.body, /streamMsg\.textContent=text/)
     assert.match(r.body, /if\(t==="chat\.token"\)\{/)
     assert.doesNotMatch(r.body, /t==="chat\.token"\|\|t==="chat\.done"/)
     assert.match(r.body, /t==="chat\.done"\|\|t==="chat\.aborted"\)\{[\s\S]{0,80}?clearStreamMsg\(\)/)
     assert.match(r.body, /t==="error"\|\|t==="chat\.error"\)\{[\s\S]{0,80}?clearStreamMsg\(\)/)
     assert.match(r.body, /threadId && \(t==="chat\.done"\|\|t==="chat\.user"\|\|t==="file\.uploaded"\)/)
     assert.match(r.body, /clearStreamMsg\(\);paintUser/)
     // Review fixes (2026-08-31): cross-thread token guard, poll must not wipe the
     // streaming bubble, thread switch clears it, recreated empty state keeps its id
     assert.match(r.body, /if\(t==="chat\.token"\)\{\s*if\(d\.thread_id&&threadId&&d\.thread_id!==threadId\) return;/)
     assert.match(r.body, /if\(d\.thread_id&&threadId&&d\.thread_id!==threadId\) return;\s*clearStreamMsg\(\);\s*busy=false/)
-    assert.match(r.body, /function selectThread\(id\)\{\s*threadId=id;\s*clearStreamMsg\(\)/)
+    assert.match(r.body, /function selectThread\(id\)\{[\s\S]{0,220}?threadId=id;\s*clearStreamMsg\(\)/)
     assert.match(r.body, /if\(!\(streamMsg&&next\)\) renderMsgs/)
     assert.match(r.body, /empty\.id="empty"/)
     assert.match(r.body, /\.hint\{[^}]*display:none/)
     assert.doesNotMatch(r.body, /grid-template-columns:var\(--rail\) var\(--list\)/)
     assert.match(r.body, /\.rail,\.list\{[^}]*display:none/)
     assert.match(r.body, /id="operateOpen"/)
     assert.match(r.body, /打开浏览器并打开侧栏/)
     assert.match(r.body, /\/api\/operate/)
     assert.match(r.body, /请点工具栏 C/)
     assert.doesNotMatch(r.body, /ui\.open_sidepanel/)
     assert.match(r.body, /id="meetingStart"/)
     assert.doesNotMatch(r.body, /要对这页做什么|当前页：|听写在侧栏|召唤器（实验）/)
@@ -293,25 +293,27 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     assert.match(r.body, /重命名/)
     assert.match(r.body, /移到回收站/)
     assert.doesNotMatch(r.body, /Raycast|uTools|启动器|第二大脑|图谱|双链/)
     assert.match(r.body, /pagehide|visibilitychange/)
     assert.match(r.body, /\/api\/lease\/release/)
     assert.match(r.body, /EventSource/)
     assert.match(r.body, /\/api\/events/)
     assert.match(r.body, /已提交/)
     assert.match(r.body, /侧栏占用了输入/)
     assert.match(r.body, /data\.error_code/)
     assert.match(r.body, /statusFromEvent/)
     assert.doesNotMatch(r.body, /mode==="enqueue"\?"已排队"/)
-    assert.doesNotMatch(r.body, /允许|拒绝|Allow|Deny/)
+    // Microphone permission copy may say 允许. The overlay must not render approval controls.
+    assert.doesNotMatch(r.body, /<button\b[^>]*>\s*(?:允许|拒绝|Allow|Deny)\s*<\/button>/i)
+    assert.doesNotMatch(r.body, /\/api\/(?:approve|deny|confirmation\/respond)/)
     assert.match(r.body, /id="cruiseChip"/)
     assert.doesNotMatch(r.body, /%%CRUISE_LABEL%%/)
     assert.match(r.body, /点此打开侧栏调整档位/)
     assert.match(r.body, /overlay\.cruise/)
     assert.match(r.body, /确认台/)
     assert.doesNotMatch(r.body, /confirmation_id/)
     assert.doesNotMatch(r.body, /ws:\/\//)
     assert.equal(r.headers["referrer-policy"], "no-referrer")
   })
 
   test("GET /api/send-shortcut returns Enter|Cmd+Enter|Ctrl+Enter", async () => {
     const r = await request({ method: "GET", port, path: `/api/send-shortcut?token=${token}` })
@@ -392,35 +394,50 @@ describe("summoner-web server", { concurrency: 1 }, () => {
   })
 
   test("PATCH /api/thread renames via alias-only thread.update", async () => {
     dispatched.length = 0
     const r = await request({
       method: "PATCH",
       port,
       path: `/api/thread?token=${token}&id=t1`,
       headers: {
         "Content-Type": "application/json",
         Origin: `http://127.0.0.1:${port}`,
       },
-      body: JSON.stringify({ alias: "周报", tool_whitelist: null }),
+      body: JSON.stringify({ alias: "周报" }),
     })
     assert.equal(r.status, 200, r.body)
     const data = JSON.parse(r.body)
     assert.equal(data.type, "thread.updated")
     assert.equal(dispatched.length, 1)
     assert.equal(dispatched[0].type, "thread.update")
     assert.equal(dispatched[0].thread_id, "t1")
     assert.deepEqual(dispatched[0].updates, { alias: "周报" })
   })
 
+  test("PATCH metadata persists tags and folder through the existing owner; rejects mixed policy fields", async () => {
+    dispatched.length = 0
+    const updates = { user_tags: ["  支付  ", "支付", "Review"], topic_folder: "变更" }
+    const send = (body: unknown) => request({ method: "PATCH", port, path: `/api/thread?token=${token}&id=t1`, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
+    const saved = await send(updates)
+    assert.equal(saved.status, 200)
+    assert.deepEqual(JSON.parse(saved.body).thread, { id: "t1", user_tags: ["支付", "Review"], topic_folder: "变更" })
+    assert.deepEqual(dispatched[0].updates, { user_tags: ["支付", "Review"], topic_folder: "变更" })
+    for (const payload of [{ alias: "safe", config_override: {} }, { user_tags: ["safe"], workspace_root: "/tmp" }, { topic_folder: 5 }, { user_tags: "tag" }, {}]) {
+      dispatched.length = 0
+      assert.equal((await send(payload)).status, 400)
+      assert.equal(dispatched.length, 0)
+    }
+  })
+
   test("DELETE /api/thread always trashes and ignores hard", async () => {
     dispatched.length = 0
     const body = JSON.stringify({ mode: "hard", thread_id: "other" })
     const r = await request({
       method: "DELETE",
       port,
       path: `/api/thread?token=${token}&id=t1&mode=hard`,
       headers: {
         "Content-Type": "application/json",
         "Content-Length": Buffer.byteLength(body),
         Origin: `http://127.0.0.1:${port}`,
       },
diff --git a/docs/audit/2026-09-08-workspace-ux-audit.md b/docs/audit/2026-09-08-workspace-ux-audit.md
new file mode 100644
index 00000000..c7aefbd9
--- /dev/null
+++ b/docs/audit/2026-09-08-workspace-ux-audit.md
@@ -0,0 +1,63 @@
+# 工作空间 UI/UX 源码审计
+
+关联 [#481](https://github.com/nehcuh/cmspark/issues/481)。2026-09-08。
+基线 `abd9995b059d0e97a36286028b478416158bdd8a`；下列行号是基线定位，同期 #482/
+#483 修复可能已改变工作树，不能用此表重新判定最终提交仍有缺陷。
+方法为源码/类型/路由/设计交叉阅读；未做本批真实麦克风时延、安装截图、Windows
+原生视觉验收。事实为代码直示，推断为产品判断，未知需运行证明。方案见
+[当前计划](../superpowers/plans/2026-09-08-workspace-projects-ux.md)。
+
+## 1. 排序结论
+
+| 优先级/归属 | 事实（仓库相对文件定位） | 推断与验收 |
+|---|---|---|
+| P1 #483 | `chrome-extension/src/sidepanel/components/FocusBand.tsx:75` 直接取全局 codingSession；`App.tsx:162` 任意新 sessionId 自动开面板；`store/agentStore.tsx:1720` 用前会话字段兜底 | 可解释新对话残留；须修事件合并和显示选择。A→B→A、交错/稀疏事件、停止/diff 目标验收，不能只藏 UI |
+| P1 #482 | 用户报告召唤器无反应/插件慢；`companion/src/summoner-web.ts:1712` 含缓冲/时窗，`:1880` 启动链；插件另有 STT 适配层 | 仅源码不能断定窗长是唯一原因。测 capture-ready/partial/final，验证准备/失败/取消可见；实际设备延迟未知 |
+| P2 #481 | `summoner-web.ts:813` PATCH 只写 alias；`:1906` 行仅打开/重命名/回收站 | 标签/组确未接入；复用字段与保存回执，精确扩展 payload ACL，不能另存组或假装项目 |
+| P2 #481 | `WorkspaceFrame.tsx:52` 资源排在最近对话之前；`ContextPanelHost.tsx:63` “标签”表示 browser tabs | 对话优先、浏览器标签页明确命名；检查键盘/宽窄/短屏并保留整理/图谱 |
+| P2 后续项目 | `companion/src/threads/thread-manager.ts:78` workspace_root 在 Thread；`:149` topic_folder 注明 not Project/Pack | 没有 Project 实体；可空 project_id 加独立实体，不能把组当目录/权限 |
+| P2 后续资源 | `McpPanel.tsx:49` 线程选择，`:60` 全局服务器开关，`:69` 全局总开关，`:90` 编辑在同一面板 | 区分“用于本对话/全局管理”；错误/待保存就地呈现，不改安全路径 |
+| P2 后续设置 | `SettingsPage.tsx:5` 已八分类；`companion/src/settings-web.ts:586` 全局模型页但 `:667` 按钮、`:673` 视觉说明仍英文 | 不泛称设置完全无结构。统一术语/范围/独立保存语义，不能伪装完整管理台 |
+
+## 2. 主要界面、证据与可验收改进
+
+表内 `sidepanel/`、`terminal/`、`cockpit/`、图谱路径均以 `chrome-extension/src/`
+为根；明确标为 companion 的文件则以 `companion/src/` 为根。
+
+| 界面 | 事实/可复用部分 | 推断的改进与验收（除注明本批外均后续） |
+|---|---|---|
+| 主工作区 | `sidepanel/components/WorkspaceFrame.tsx:43` 是既有 store 的最近投影；`StatusRail.tsx:223` 导航，`:236` 标题，`:238` 新建，`:254` ThreadList；`sidepanel/App.tsx:235` 消息、`:239` 资源、`:240` 输入 | 保留中性视觉，只修导航优先级/作用域，不加第二全局任务顶栏。本批测空对话/长标题/离线/新建/200% 等效 reflow，Stop 与输入不被遮挡 |
+| 对话管理 | `ThreadList.tsx:1397` 管理，`:1400` 四类视图，`:1543` AI提取/整理/图谱/回收站；`ThreadMetadataEditor.tsx:18` 规范化；`utils/thread-management.ts:13` persisted ACK，`:8` AI组派生 | 端间补齐，不再造缓存。本批测空分类、失败保留、错/迟回执、重载、AI不覆盖人工；不宣称召唤器已具备全部 AI/图谱 |
+| 召唤器 | companion `summoner-web.ts:1462` 左栏，`:1496` 窄导航，`:2518` 排序，`:2524` 资源切换；`:260` MCP投影只名字/状态；`:2589` 技能/`:2606` 知识仅挂载本对话 | 导航名称不能暗示全量管理。元数据本批窄扩展，MCP/安装/终端仍按#476。测晚资源响应、线程切换、空/错误态；普通本地聊天不强开Chrome |
+| 输入/附件/捕获 | `ComposerDock.tsx:13` 只是容器，输入内部在 App；companion `summoner-web.ts:1529` mic，`:1540` 附近 composer/capture，`:1552` 隐私卡；隐藏旧设置按钮 `:1538` | 改容器不能证明全部输入流程已修。听写/附件固定草稿目标，取消/隐藏释放资源；不得增加看似可用的死设置入口。捕获与正文的来源应可辨 |
+| 语音/会议 | `VoiceStatusCapsule.tsx:5` 状态与live text，`:35` 电平动画；`MeetingPanel.tsx:1243` 模式/互斥/不自动开麦，`:1271` 仍旧设置路径，`:1445` 录制，`:1503` 说话人/导入，`:1675` 转写，`:1781` 纪要 | 本批准备/处理/失败清晰、停止和晚终稿、跨对话与会议互斥。后续按记录/导入→校对→生成组织，高级说话人折叠；手改转写不能被晚同步覆盖。时延需实机，不据动画推断 |
+| 编程控制器 | `CodingAgentPanel.tsx:110` 接 workspace；`App.tsx:244` 取当前thread的目录/消息，但全局codingSession未同样限定；`CodingSessionShell.tsx:53` CLI单轮输入禁用 | 先修归属，保留有效结果。后续当前对话“代码与终端”，其他运行侧栏跳转；不能宣传所有 CLI 多轮。A/B与多个session、操作闭包、late event测清 |
+| 内嵌终端 | `terminal/TerminalApp.tsx:61` thread/review关联；`:230` 标题仅“内嵌终端”/状态；`:256` 默认展开手工提示与JSON回传 | 后续加可读归属/回对话，回传按需展开。测正确review/thread收到、失败保留JSON、关闭实际生命周期；手工流程不能称自动回传，导入成功不等于审阅通过 |
+| 场景/技能/知识 | `PacksPanel.tsx:1387` 场景状态内藏工作目录，`:1437` 场景绑定多资源；`ContextPanelHost.tsx:392` SkillsPanel；`KnowledgeSubPanel.tsx:1028` 文件/大文件/文件夹/URL/建夹五入口 | 后续目录回项目/对话上下文，保留场景兼容入口；知识导入可菜单收拢但保留不同picker/限额。测场景卸载不丢手工目录，各导入底层校验保留，管理与当前选择分开 |
+| MCP/应用/任务板 | `McpPanel.tsx:49–104` 当前选择/全局管理混合；`AppsPanel.tsx:25` 独立应用；`ContextPanelHost.tsx:311` BoardPanel | 后续固定搜索/当前选择/管理分区；全局启停不能误称只影响本对话。任务板、编程、浏览器状态不互相覆盖；不得另造运行事实源 |
+| 插件设置 | `SettingsPage.tsx:5` 模型/语音/文件知识/连接/安全/本机工具/密钥/实验八类，`:16` 隐藏但不卸载；`SettingsSlideout.tsx:829` 宽导航、`:831` 窄选择 | 保留分类与草稿；文件知识“偏好”区别资源内容管理，本机工具按对象分区。验收深链、切页草稿、masked secret保留、保存/下载/连接各自回执，不能一个Save越过确认 |
+| 独立设置 | companion `settings-web.ts:586` 全局模型作用域；`:667` Save/Test/Cancel，`:673` Vision Model及说明英文 | 后续统一中文并注明只配置全局模型；未覆盖功能不显示假入口。模型/视觉测试与持久保存分开，错误保留输入，密钥不泄露 |
+| 确认台 | `cockpit/CockpitApp.tsx:148` 标题含模式/连接/原始thread ID，`:189` 急停，`:197` 收起不停止提示，`:233` 独立ConfirmElevated | 后续标题可读化属chrome改进，不是权限缺陷。本批不改确认DOM/handler。验收风险证据/拒绝/急停可见、收起真实不停止、断连挑战正确取消 |
+| 对话/知识图谱 | `thread-graph/ThreadGraphApp.tsx:692` 搜索/阈值toolbar，`:970` 键盘说明；`knowledge-graph/KnowledgeGraphApp.tsx:637` toolbar，`:708` 组，`:760` 图语义 | 保留两图及入口，后续共享返回/空态/toolbar文法。搜索/焦点优先、高级阈值展开；无标签/边/重建/错误可解释，节点回正确实体，相关度不冒充业务依赖证据 |
+| 品牌/托盘/宿主 | `scripts/lib/brand-icon.mjs` 连接火花；#474已区分进程与连接状态；#477窗口仍Chromium，非完整native身份 | 保留已交付标识；Mac/Windows运行截图另验，不据PNG证明安装替换。放大/召唤不改权限，浏览器连接前后台不等于逐任务可见性保证 |
+
+## 3. 项目与复用边界
+
+**事实：** Thread（`companion/src/threads/thread-manager.ts:42–152`）含人工分类、
+AI digest、workspace_root、资源选择和运行信息，没有 project_id；插件 `types.ts:55`
+同为线程目录，`:77` topic_folder注明非Project。`message-router.ts:2984` 通用更新
+有 user_tags/topic_folder，workspace_root走独立workspace路径。`ws/summoner-acl.ts`
+基线payload gate为alias-only。因此当前窄扩展是实际ACL变化，需要协议/负例复审。
+
+**推断：** 项目适合长期业务/代码范围，但不是多一个筛选器。可复用Thread/元数据
+规范化与确认、目录选择校验、ACP/PTY IDs、资源库、确认manager。后续才新增独立
+Project、可空归属、目录建议、迁移候选；不用新项目偷渡自动授权。详细流程见计划§5。
+
+## 4. 完成标准与未知
+
+- 本审计覆盖主要入口/所有权，不是逐控件WCAG或视觉认证，没有“美观分”。未验收的
+  会议/设置/图谱/终端改进仍是后续工作；不得计入本批实现完成率。
+- 用户语音症状需真实权限、音频设备、模型冷热启动实测。静态时窗不是唯一根因证据。
+- 编程归属缺陷有高置信源码解释；最终需测当前提交，不能只引用此基线。
+- 本批交付限计划§1；项目实体仍提案，#476原生/高权限/浏览器任务策略继续独立跟踪。
+- 机器检查、真实双模型复审、当前CI、安装/运行证明分别留痕；设计通过不等于实现通过。
diff --git a/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md b/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
new file mode 100644
index 00000000..086b6e41
--- /dev/null
+++ b/docs/superpowers/plans/2026-09-08-workspace-projects-ux.md
@@ -0,0 +1,163 @@
+# 工作空间、项目与对话 UI/UX
+
+关联 [#481](https://github.com/nehcuh/cmspark/issues/481)，修复 [#482](https://github.com/nehcuh/cmspark/issues/482) / [#483](https://github.com/nehcuh/cmspark/issues/483)。
+2026-09-08 · 设计与验收约定，待独立复审；不是已实现清单。
+视觉规范：[root DESIGN.md](../../../DESIGN.md)。源码：[整体审计](../../audit/2026-09-08-workspace-ux-audit.md)。
+
+## 1. 本次交付与后续提案
+
+用户六项反馈关联到输入状态、对话归属和导航结构；不以一次皮肤调整替代这些问题。
+
+| 范围 | 本次交付与验收 | 后续，不能在本次宣称完成 |
+|---|---|---|
+| 输入 #482 | 两端启动/失败/处理中可见；修复复现的延迟路径；保留取消、隐私、会议互斥 | 新引擎、无限会议、硬件无关的延迟保证 |
+| 编程 #483 | 按 session/thread 处理事件；新对话不出现/自动打开旧代码任务；操作目标不串会话 | 全局活动中心、代码/终端整合、原生终端、多运行持久化产品 |
+| 对话分类 | 召唤器人工标签/手动分组；真实保存确认；插件旧整理/图谱功能保留 | 项目数据库、项目继承/批量迁移；召唤器全部 AI 整理和图谱 |
+| 导航 | 两端对话优先；搜索/最近/管理在辅助资源之前；术语明确 | 全部资源编辑器重写 |
+| 项目 | 本文明确实体、归属、目录与迁移设计 | 不把 topic_folder 改名项目，不放空壳项目入口 |
+| 整体 UI/UX | 主要界面源码梳理、统一规范、分阶段可验收清单 | 审计列出的后续改造不能计为本批已交付 |
+
+用户问“项目是否更好”支持设计建议，本次不实施隐式目录继承或自动迁移。#481 完成
+指本批修复与审计闭环，不关闭 #476，也不声称项目模型已经实现。
+
+## 2. 本批导航与对话元数据
+
+两端顺序：新对话 → 搜索/最近对话/管理 → 资料与工具 → 设置（实际可用时）。
+320–759px 使用有高度上限的非模态导航；顶栏 +、输入、语音状态和停止始终可达。
+760px+ 保留 220px 左栏。浏览器 tabs 称“浏览器标签页”，人工 tags 称“标签”。
+
+插件继续由 ThreadList 管时间、标签、手动/AI 分组、批量选择、整理助手、关系图谱
+与回收站。召唤器本次接入人工标签/手动组编辑与展示，不声称已补齐全部管理能力。
+可输入新组名或选择已有名称，留空移出。保存只锁对应编辑动作；失败保留草稿；
+切换对话不能把迟到回执应用给另一行。AI 重提取不得覆盖人工分类。
+
+复用 Thread 和已有 sanitize/persisted response；HTTP/WS 共用
+`companion/src/threads/metadata-patch.ts` 的纯验证。现有 `thread.update` 的 overlay
+payload ACL 从 alias-only **窄扩展**为 alias/user_tags/topic_folder 精确子集。
+HTTP 先校验，再经 dispatchAllowed；WS lifecycle 在通用 router 之前再次应用同一 payload gate。
+不新增方法，不透传客户端 updates；未知字段整包拒绝，包含合法 alias 与非法 config
+的混合包也不能静默剥离后成功。错误类型、NFC、控制字符、数量/长度上限与服务端一致。
+未提交字段不变；尤其不能把未提交 alias 清成空。回执线程 ID 与提交字段匹配才成功。
+
+该排期取代旧 #476 slice 4 将这些元数据全部延后到原生身份的约束。它是需要 T3
+复审的实际 ACL 变化；不是“ACL 完全没改”。workspace_root、config/trust、MCP
+写入、安装/导入、终端和确认响应均不因此开放。#476 其余原生身份与确认依赖不变。
+
+## 3. 编程运行归属
+
+事实键是启动时的 session_id 和 thread_id，不是当前选中页面。事件先定位相同
+session，再更新它自己的字段；不同 session 不继承目标、目录、进度、结果、diff
+或本机终端状态。未知会话的稀疏事件不能借用另一会话身份。显示选择器按当前 thread
+取对应代码状态，不能每个组件采用不同规则。
+
+- A 开始代码工作后切换/新建 B，A 控制器和顶栏状态不占用 B；迟到的 A 事件不再
+  自动打开 B 面板。切回 A 可以在客户端支持的保留范围内查看，不因隐藏取消进程。
+- 停止、继续、应用 diff、关闭监视均使用实际 session ID；旧 UI 闭包不能读 B 的
+  目录/消息去继续 A。切换时关闭旧编辑视图或重建其上下文，避免混用。
+- 关闭一项不清空其他会话；断连不代表完成；已结束的有效结果/diff 入口仍归 A。
+- 重载恢复需实际协议验证，不以本批内存作用域修复宣称新增持久恢复产品。
+
+后续可把编程面板/终端整合为“代码与终端”：当前对话运行列表、输出、变更、证据按需
+展开；其他对话后台任务在侧栏活动入口显示并跳回所属对话；完成结果放消息卡。此方向
+不是本批交付，也不能另造 Agent、确认队列或绕过 #476 原生能力门禁。
+
+## 4. 语音状态与性能证据
+
+区分“准备麦克风/模型”“正在听写”“正在识别最后一段”“失败”。点击后在异步准备
+完成前显示反馈，capture 就绪后才能显示正在听写。权限、模型缺失、服务断开分别
+给当前设置分类的恢复路径，不能统统提示“打开麦克风”。停止录音与等待 final 分开。
+部分识别不冒充终稿、不重复拼接。开始时固定草稿/录音归属，切换/新建/取消/隐藏/
+关闭或会议竞争时，旧结果不能写进新草稿。保留隐私确认、会议互斥与音频资源清理。
+不因降延迟自动开麦或改用云服务。
+
+记录引擎/模型、冷热启动、请求/capture-ready/first-partial/stop/final 时点。
+同机器/录音前后比较，区分固定等待窗与计算耗时。合成测试证明准备/错误/取消/迟到
+事件反馈；真实麦克风和模型时延另做实测，不能承诺所有硬件都毫秒级 final。本批可机核的通过条件是：点击所在事件轮次出现准备状态；
+合成 final 返回后下一轮状态更新写入所属草稿；录音中支持 partial 预览；正常停止不再使用
+8秒通用请求/12秒取消截止。真实机器 final 性能仍需单独前后测量，不据此关闭性能提升主张。
+
+## 5. 后续项目实体设计
+
+### 5.1 层级与最小模型（提案，未成协议）
+
+```text
+Project（可选的长期业务/代码范围）
+  └─ Thread / 对话（消息、意图、人工分类）
+       └─ Execution / 运行记录（ACP、PTY、浏览器执行；产物与来源）
+```
+
+| 字段/实体 | 建议语义 |
+|---|---|
+| Project.id / name | 服务端稳定 ID；改名称不改磁盘目录，目录不作主键 |
+| Project.workspace_root? | 当前 Companion 主机的可选规范化绝对目录，可为空 |
+| created_at / updated_at / archived_at? | 元数据时间与归档；归档不删除对话、文件或产物 |
+| Thread.project_id? | 零或一个项目；空值为项目外对话 |
+| Thread.workspace_root? | 保留现有显式线程绑定，允许不同于项目建议目录 |
+| user_tags / topic_folder / digest | 原字段不变：人工标签、人工组、AI 索引各司其职 |
+| 运行快照 | 创建时固定 thread/project ID（若有）、解析 cwd/仓库根、commit/base/head（适用时） |
+
+新增独立 Project store，不复制 Thread 消息存储。业务项目允许没有目录，如跨系统
+变更。首版至多一个建议目录，不自动克隆或创建 worktree；多仓库、远程主机、项目
+共享资源/密钥继承另立需求。不额外强制一个“任务容器”，对话承载工作，运行解释执行。
+
+### 5.2 目录建议与授权分离
+
+创建只需名称；可通过既有目录选择/校验添加目录。Git 检测是可选只读提示，remote
+URL 不必填，不把带凭据的 URL 写入 UI/日志。选择项目不能触发执行、下载、MCP
+allow-dir 扩张或信任提升。项目名称、文件夹标签均不是安全身份。
+
+建议有效目录顺序：显式 thread.workspace_root → 用户选择使用的项目目录 → 既有
+默认沙箱。界面显示生效来源；接受项目目录建议仍走既有 workspace binding/安全
+检查，不能仅有 project_id 就自动获取访问权限。改项目默认目录不偷偷改已有绑定。
+运行前由服务端冻结有效 cwd/仓库，运行中不能随项目设置/activeThread 重绑。目录
+失效/非 Git 是可恢复状态；普通业务对话继续，要求仓库/commit 的操作明确报缺失，
+不能悄悄落到别的仓库。项目设置本身不授权访问目录中的内容。
+
+### 5.3 创建、移动、归档、恢复
+
+项目内新对话显式带 project_id；全局新对话允许项目外。复用 thread.create owner，
+由服务端确认，不能从“最近代码会话”猜项目。建议 Fork 默认保留来源项目（在后续实现 Issue 冻结）并沿用既有目录
+复制语义，但不复制运行 ID、活跃权限或待确认挑战。无效/归档项目 ID 有明确校验。
+
+第一版在有运行/待确认时不允许移动对话，解释先结束执行/处理决定再整理。空闲对话
+移入/移出项目只改元数据，保留原显式目录并在移动界面说明；换目录是独立操作。历史
+审阅结果的 thread/仓库/commit 快照不随移动变化。归档代替级联删除；恢复保持关联。
+项目记录损坏/缺失时对话仍可找回并显示“原项目不可用”，不误判为历史已删。并发元
+数据编辑需要版本/更新时间冲突检测；原子写和失败恢复方案在实现 Issue 冻结。
+
+### 5.4 旧数据迁移
+
+增加可空字段，不批量重写历史。无 project_id 原样显示项目外，人工组/标签、AI tags、
+workspace_root 全保留。可只读扫描相同规范化目录，给“整理到项目”的候选；显式
+选中后才建归属。不能把同名 folder 自动变项目、同路径迁移变授权；记录迁移 ID
+映射、写入失败不宣称成功，不复制消息或触碰代码文件。
+
+### 5.5 项目验收（后续）
+
+空/无仓库项目、项目外对话；创建/搜索/归档/恢复；重启归属；旧历史零迁移可读；
+人工/AI 分类不丢；三种目录来源清晰；运行中目录不重绑；A/B 项目并发/迟到事件/
+无效 ID/断连；缺失项目记录仍找回对话；不级联删文件；失败不假保存；需求→开发
+对话→仓库/commit→审阅测试→变更材料可反向溯源；无 Codex/外部 Agent/浏览器
+时非网页工作仍可开展，属于 #476 原生产品验收，不由项目元数据功能单独承担。未实现项目专属验收项不能宣称项目支持完成。
+
+## 6. 全面 UI/UX 后续顺序
+
+主要面证据与验收见审计：真实项目/归属 → 当前对话代码与终端 → 资源的线程选择/
+全局管理分区 → 知识导入/会议渐进展开 → 图谱/独立设置/Cockpit chrome 一致性。
+旧会议/独立设置文案等未触及恢复入口列为后续；本次新增语音文案使用实际“输入与语音”分类。
+每项另有 Issue 和交互验收，不把更新 DESIGN.md 计为全部页面已重做。
+#476 native/MCP/技能/知识/原生确认/浏览器可见性依赖保持；目前 Chrome 按钮只
+控制连接/打开，不等于任意任务后台、不抢焦点。窗口宽度不改变权限。
+
+## 7. 当前门禁与外部复审重点
+
+- #482/#483 给根因和前后行为；运行 owning tests，不能只有静态字符串断言。
+- 元数据：未知字段/错类型/超长/空组/错线程/保存失败/断连/迟到回执；HTTP 与 WS
+  都验证同一精确集合，alias+config 整包拒绝；重载/跨表面可见实际保存结果。
+- 真实组件/HTML 合成传输测宽窄/短屏、新建/导航/管理/语音/停止/确认优先。
+  这些不证明真实 STT 速度或 Windows 原生效果。
+- 冻结代码和证据，实际 Grok + DeepSeek 独立复审并记录模型/结论；空输出、超时、
+  tool XML 非批准；阻断修复重审。PR 关联 Issues，当前提交 CI 通过后才称可合并。
+- 设计评审核查：当批/未来不混淆；folder 不冒充 project；项目非权限；执行/回执/
+  录音不跨对话；overlay payload ACL 窄扩展明确；导航保留旧功能；恢复/窄屏/确认
+  可测试；设计通过、实现通过和安装验证分别报告。

FULL CONTEXT companion/src/ws/summoner-acl.ts
import { isUiCommandAction } from "../ui-command"
import { summonerThreadMetadata } from "../threads/metadata-patch"

/** Per-connection method ACL keyed off handshake `surface` (S21).
 *
 * Origin stays `cmspark-tray://local`. Summoner is a second tray-origin WS
 * that must not run trust-elevation / settings / pack / MCP mutate / confirm.
 * Overlay chat.create already sees companion MCP tools; `mcp.list` is read-only
 * so the overlay can show connected servers. `mcp.add` stays denied.
 * `pack.apply` is allowed but router forces allowTrust=false + overlay-eligible.
 * `thread.delete` / `thread.update` are overlay-safe only via
 * `applySummonerPayloadPolicy` (trash-only; name/tags/folder-only).
 * Tray (`surface !== "summoner"`, including omitted/undefined) is not gated —
 * origin-cleaving would break tray `skill.list`.
 */

const SUMMONER_ALLOW = new Set([
  "system.ping",
  "chat.create",
  "chat.abort",
  "chat.steer",
  "thread.list",
  "thread.select",
  "thread.create",
  "thread.delete",
  "thread.update",
  "history.query",
  "thread.search",
  "thread.peek",
  "composer.lease.claim",
  "composer.lease.release",
  "composer.lease.release_overlay",
  "composer.lease.get",
  "voice.stt.start",
  "voice.stt.chunk",
  "voice.stt.end",
  "voice.stt.abort",
  "voice.stt.partial_request",
  "meeting.create",
  "meeting.start",
  "meeting.end",
  "meeting.append_transcript",
  "meeting.generate_minutes",
  "meeting.list",
  "meeting.get",
  "mcp.list",
  "mcp.toggle_server",
  "pack.list",
  "pack.apply",
  "task_loop.arm",
  "skill.list",
  "skill.activate",
  "skill.deactivate",
  "knowledge.list",
  "knowledge.search",
  "knowledge.set_active",
  "file.upload",
  "companion.ui.rect",
  "ui.command",
  "thread.execution_policy.set",
])

export function assertSummonerAllowed(
  surface: string | undefined,
  type: string,
): { ok: true } | { ok: false; error_code: "SUMMONER_ACL"; error: string } {
  if (surface !== "summoner") return { ok: true }
  if (SUMMONER_ALLOW.has(type)) return { ok: true }
  return {
    ok: false,
    error_code: "SUMMONER_ACL",
    error: `SUMMONER_ACL: ${type} not allowed on summoner surface`,
  }
}

/**
 * Overlay-safe payload gate. Method allowlist is not enough: tray `thread.delete`
 * defaults to hard, and `thread.update` can mutate tool_whitelist / knowledge ids.
 * Mutates `msg` in place with validated metadata; rejects all other update keys. Tray / omitted surface: no-op.
 */
export function applySummonerPayloadPolicy(
  surface: string | undefined,
  msg: Record<string, unknown>,
): { ok: true } | { ok: false; error_code: "SUMMONER_ACL"; error: string } {
  if (surface !== "summoner") return { ok: true }
  const type = msg.type
  if (type === "thread.delete") {
    if (msg.mode !== "trash") {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: thread.delete on overlay must use mode=trash",
      }
    }
    return { ok: true }
  }
  if (type === "thread.update") {
    try {
      msg.updates = summonerThreadMetadata(msg.updates)
      return { ok: true }
    } catch (error) {
      return { ok: false, error_code: "SUMMONER_ACL", error: "SUMMONER_ACL: " + (error instanceof Error ? error.message : "invalid metadata") }
    }
  }
  if (type === "knowledge.set_active") {
    const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
    if (!threadId) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: knowledge.set_active requires thread_id",
      }
    }
    const raw = Array.isArray(msg.ids) ? msg.ids : []
    const ids = raw.filter((id): id is string => typeof id === "string" && id.trim().length > 0).slice(0, 32)
    for (const key of Object.keys(msg)) {
      if (key !== "type" && key !== "thread_id" && key !== "ids") delete msg[key]
    }
    msg.thread_id = threadId
    msg.ids = ids
    return { ok: true }
  }
  if (type === "pack.apply") {
    delete msg.allowTrust
    delete msg.workspace_path
    delete msg.force_takeover
    delete msg.confirmation_phrase
    const packId = typeof msg.pack_id === "string" ? msg.pack_id.trim() : ""
    const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
    if (!packId || !threadId) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: pack.apply requires pack_id and thread_id",
      }
    }
    msg.pack_id = packId
    msg.thread_id = threadId
    msg.user_gesture = true
    return { ok: true }
  }
  if (type === "meeting.start") {
    msg.audio_retained = false
    delete msg.retain_days
    return { ok: true }
  }
  if (type === "ui.command") {
    const action = typeof msg.action === "string" ? msg.action.trim() : ""
    if (!isUiCommandAction(action)) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: ui.command action not on whitelist",
      }
    }
    for (const key of Object.keys(msg)) {
      if (key !== "type" && key !== "action" && key !== "id") delete msg[key]
    }
    msg.action = action
    return { ok: true }
  }
  if (type === "thread.execution_policy.set") {
    const threadId = typeof msg.thread_id === "string" ? msg.thread_id.trim() : ""
    if (!threadId) {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: thread.execution_policy.set requires thread_id",
      }
    }
    if (msg.policy !== "plan_readonly") {
      return {
        ok: false,
        error_code: "SUMMONER_ACL",
        error: "SUMMONER_ACL: summoner may only downgrade to plan_readonly",
      }
    }
    for (const key of Object.keys(msg)) {
      if (key !== "type" && key !== "thread_id" && key !== "policy" && key !== "user_gesture" && key !== "id") {
        delete msg[key]
      }
    }
    msg.thread_id = threadId
    msg.policy = "plan_readonly"
    msg.user_gesture = true
    return { ok: true }
  }
  return { ok: true }
}

FULL CONTEXT chrome-extension/src/sidepanel/voice/local-stt-adapter.ts
/**
 * Path B — local STT adapter (gUM → WAV/PCM chunks → voice.stt.* WS).
 * classic: one shot ≤45s then onEnd.
 * continuous (D1c): serial segments ≤45s until hard cap or user stop.
 * continuous + streamPartial (M2): PCM stream + partial_request progressive hypothesis.
 */

import {
  LOCAL_STT_CHANNELS,
  LOCAL_STT_MAX_CHUNK_RAW_BYTES,
  LOCAL_STT_MAX_RECORD_MS,
  LOCAL_STT_NEAR_REALTIME_SEGMENT_MS,
  LOCAL_STT_SAMPLE_RATE,
} from "./local-stt-detect"
import { splitIntoChunks } from "./pcm-encode"
import {
  startCapture as defaultStartCapture,
  type CaptureHandle,
  type StartCaptureOpts,
} from "./audio-capture"
import {
  startPcmStreamCapture as defaultStartPcmStreamCapture,
  type PcmStreamCaptureOpts,
  type PcmStreamHandle,
} from "./pcm-stream-capture"
import {
  nextPartialPollMs,
  STREAM_PARTIAL_POLL_DEFAULT_MS,
} from "./stream-partial-poll"
import type {
  SpeechAdapter,
  SpeechAdapterHandlers,
  SpeechAdapterStartArg,
} from "./web-speech-adapter"
import {
  VOICE_CONTINUOUS_HARD_CAP_MS,
  VOICE_DEFAULT_LANG,
  type VoiceDictationMode,
} from "./detect"

export type LocalSttSend = (msg: Record<string, unknown>) => void

/** Subscribe to inbound companion messages; returns unsubscribe. */
export type LocalSttOnMessage = (handler: (msg: any) => void) => () => void

export type LocalSttAdapterDeps = {
  send: LocalSttSend
  onMessage: LocalSttOnMessage
  /**
   * Whisper model id. #259: optional for engineKind "system" (Windows SAPI
   * sessions carry no whisper model on the wire).
   */
  modelId?: string
  /** #259: "system" stamps voice.stt.start engine:"system" (per-session SAPI). */
  engineKind?: "local" | "system"
  startCapture?: (opts?: StartCaptureOpts) => Promise<CaptureHandle>
  startPcmStreamCapture?: (opts: PcmStreamCaptureOpts) => Promise<PcmStreamHandle>
  /**
   * Wall timeout waiting for voice.stt.result/error after end().
   * Companion infer cap is 90s; default a hair over that so a live infer can finish.
   */
  pendingTimeoutMs?: number
  /**
   * After user stop(), do not wait the full pendingTimeoutMs — Companion restart
   * mid-window used to leave meeting "正在听" forever because stop() while
   * waiting was a no-op until the missing ACK.
   */
  stopGraceMs?: number
}

/** Client wait for companion infer ACK (server STT_INFER_MAX_MS = 90s). */
export const LOCAL_STT_PENDING_TIMEOUT_MS = 95_000

/** After user stop, give the in-flight window this long then end anyway. */
export const LOCAL_STT_STOP_GRACE_MS = 12_000

/**
 * Soft-continue only for failures after end() when companion has dropBound.
 * NEVER soft-continue session_busy / resource_conflict / oom / binary_broken
 * without reclaiming the slot (adversary B F1/F2 + dual-review: binary_broken is sticky).
 */
export function isSoftSttSegmentError(code: string): boolean {
  const c = (code || "").toLowerCase()
  return (
    c === "infer_failed" ||
    c === "empty_result" ||
    c === "infer_timeout" ||
    c === "partial_skipped"
  )
}

/** Hard stop — do not keep mic open. */
export function isHardSttSegmentError(code: string): boolean {
  const c = (code || "").toLowerCase()
  return (
    c === "oom" ||
    c === "binary_broken" ||
    c === "model_missing" ||
    c === "binary_missing" ||
    c === "hash_fail" ||
    c === "engine_not_local" ||
    c === "need_privacy_ack" ||
    c === "origin_denied" ||
    c === "peer_mismatch"
  )
}

/** uint8 → base64 without Node Buffer (Side Panel / tests). */
export function uint8ToBase64(data: Uint8Array): string {
  const chunkSize = 0x8000
  let binary = ""
  for (let i = 0; i < data.length; i += chunkSize) {
    const slice = data.subarray(i, Math.min(i + chunkSize, data.length))
    binary += String.fromCharCode.apply(null, Array.from(slice) as number[])
  }
  if (typeof btoa === "function") {
    return btoa(binary)
  }
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  let out = ""
  for (let i = 0; i < data.length; i += 3) {
    const a = data[i]
    const b = i + 1 < data.length ? data[i + 1] : 0
    const c = i + 2 < data.length ? data[i + 2] : 0
    const triple = (a << 16) | (b << 8) | c
    out += alphabet[(triple >> 18) & 63]
    out += alphabet[(triple >> 12) & 63]
    out += i + 1 < data.length ? alphabet[(triple >> 6) & 63] : "="
    out += i + 2 < data.length ? alphabet[triple & 63] : "="
  }
  return out
}

type PendingWait = {
  sessionId: string
  resolve: (
    r: { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string },
  ) => void
}

export function createLocalSttAdapter(
  handlers: SpeechAdapterHandlers,
  deps: LocalSttAdapterDeps,
): SpeechAdapter {
  let dead = false
  let capture: CaptureHandle | null = null
  let sessionId: string | null = null
  let modelId = deps.modelId ?? ""
  let unsub: (() => void) | null = null
  let phase: "idle" | "recording" | "uploading" | "waiting" = "idle"
  let aborted = false
  let wantListening = false
  let mode: VoiceDictationMode = "classic"
  let parentSessionId = ""
  let lang = VOICE_DEFAULT_LANG
  let hardCapMs = VOICE_CONTINUOUS_HARD_CAP_MS
  /** Optional per-segment window override (tests); clamped to LOCAL_STT_MAX_RECORD_MS. */
  let segmentCapMs = LOCAL_STT_MAX_RECORD_MS
  let streamPartial = false
  let wallStart = 0
  let segmentIndex = 0
  let pending: PendingWait | null = null
  let pendingTimer: ReturnType<typeof setTimeout> | null = null
  let loopGen = 0
  /** Continuous: resolve when current segment should stop recording. */
  let segmentStopTrigger: (() => void) | null = null
  let segmentTimer: ReturnType<typeof setTimeout> | null = null
  let partialTimer: ReturnType<typeof setTimeout> | null = null
  let pcmStream: PcmStreamHandle | null = null
  let streamSeq = 0
  let streamStable = ""
  let streamPrevHypothesis = ""
  /** Adaptive partial poll (ms); paced by last hypothesis infer time. */
  let partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
  /**
   * N3: soft stop requested while awaiting gUM / before window wait is armed.
   * Checked after each await so we never run a full unintended window.
   */
  let pendingSoftStop = false
  /** Consecutive soft segment failures — hard stop after threshold (adversary B F2). */
  let softFailStreak = 0
  /** Classic: first stop() already started the stop→upload chain; repeat stops are ignored. */
  let stopChainInFlight = false
  const SOFT_FAIL_MAX = 3
  const beginCapture = deps.startCapture ?? defaultStartCapture
  const beginPcmStream = deps.startPcmStreamCapture ?? defaultStartPcmStreamCapture
  const pendingTimeoutMs = deps.pendingTimeoutMs ?? LOCAL_STT_PENDING_TIMEOUT_MS
  const stopGraceMs = deps.stopGraceMs ?? LOCAL_STT_STOP_GRACE_MS

  const clearSegmentTimer = () => {
    if (segmentTimer) {
      clearTimeout(segmentTimer)
      segmentTimer = null
    }
  }

  const clearPartialTimer = () => {
    if (partialTimer) {
      clearTimeout(partialTimer)
      partialTimer = null
    }
  }

  const clearPendingTimer = () => {
    if (pendingTimer) {
      clearTimeout(pendingTimer)
      pendingTimer = null
    }
  }

  const pendingWaitMs = () => {
    const budget = deps.pendingTimeoutMs ?? (modelId === "large-v3-turbo" ? 305_000 : pendingTimeoutMs)
    // Ending an ordinary recording is the normal route to its final, not cancellation.
    return mode === "classic" || wantListening ? budget : Math.min(stopGraceMs, budget)
  }

  const armPendingTimer = (sid: string) => {
    clearPendingTimer()
    const ms = pendingWaitMs()
    pendingTimer = setTimeout(() => {
      pendingTimer = null
      if (!pending || pending.sessionId !== sid) return
      // Still listening: surface infer_timeout (soft streak). After user stop:
      // empty_result so the loop can onEnd without a scary banner.
      finishPending({
        ok: false,
        code: mode === "classic" || wantListening ? "infer_timeout" : "empty_result",
      })
    }, ms)
  }

  const clearSub = () => {
    if (unsub) {
      try {
        unsub()
      } catch {
        /* */
      }
      unsub = null
    }
  }

  const reset = () => {
    // V1: invalidate every in-flight coroutine gen guard (classic stop chain,
    // continuous loops). Without this a coroutine sleeping in conflict backoff
    // survived reset() and woke as a zombie — uploading with no subscription,
    // pending never settled, phase stuck "waiting" → mic locked for good.
    loopGen += 1
    clearSegmentTimer()
    clearPartialTimer()
    clearPendingTimer()
    segmentStopTrigger = null
    if (pcmStream) {
      try {
        pcmStream.abort()
      } catch {
        /* */
      }
      pcmStream = null
    }
    clearSub()
    capture = null
    sessionId = null
    phase = "idle"
    aborted = false
    wantListening = false
    mode = "classic"
    streamPartial = false
    parentSessionId = ""
    segmentIndex = 0
    pending = null
    streamSeq = 0
    streamStable = ""
    streamPrevHypothesis = ""
    partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
    pendingSoftStop = false
    softFailStreak = 0
    stopChainInFlight = false
  }

  const finishPending = (
    r: { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string },
  ) => {
    clearPendingTimer()
    const p = pending
    pending = null
    p?.resolve(r)
  }

  const onWs = (msg: any) => {
    if (dead || !msg || typeof msg.type !== "string") return
    const sid = typeof msg.sessionId === "string" ? msg.sessionId : ""
    if (!sessionId || sid !== sessionId) return

    if (msg.type === "voice.stt.partial") {
      // M2 hypothesis text (status === "hypothesis"); ignore status-only partials
      // N4: drop late partials after window end / while waiting for final
      if (phase !== "recording") return
      if (msg.status === "hypothesis" && typeof msg.text === "string") {
        const hyp = msg.text.trim()
        if (!hyp) return
        // Pace next poll from companion infer wall time (medium models often >1.4s)
        if (typeof msg.ms === "number" && Number.isFinite(msg.ms) && msg.ms > 0) {
          partialPollMs = nextPartialPollMs(msg.ms)
        }
        // F3: interim-only within a window — never commit finalChunk mid-window.
        streamPrevHypothesis = hyp
        const display = hyp.startsWith(streamStable) ? hyp.slice(streamStable.length) : hyp
        handlers.onResult({
          interim: display,
          finalChunk: "",
        })
      }
      return
    }

    if (msg.type === "voice.stt.result") {
      const text = typeof msg.text === "string" ? msg.text : ""
      if (pending && pending.sessionId === sid) {
        finishPending({
          ok: true,
          text,
          ...(msg.postprocessed === true ? { postprocessed: true } : {}),
        })
        return
      }
      if (aborted) {
        handlers.onEnd()
        reset()
        return
      }
      if (text.trim()) {
        handlers.onResult({
          interim: "",
          finalChunk: text,
          ...(msg.postprocessed === true ? { postprocessed: true } : {}),
        })
      }
      handlers.onEnd()
      reset()
      return
    }

    if (msg.type === "voice.stt.error") {
      const code = typeof msg.code === "string" && msg.code ? msg.code : "unknown"
      if (pending && pending.sessionId === sid) {
        finishPending({
          ok: false,
          code: code === "aborted" || aborted ? "aborted" : code,
        })
        return
      }
      if (code === "aborted" || aborted) {
        handlers.onError("aborted")
        handlers.onEnd()
        reset()
        return
      }
      // No pending (e.g. start rejected mid-stream).
      // Hard errors always stop. Soft: only when streamPartial is false —
      // streaming loop already counts soft fails on end() (Pi nit: avoid double streak).
      if (isHardSttSegmentError(code) || code === "oom") {
        handlers.onError(code)
        handlers.onEnd()
        reset()
        return
      }
      if (
        mode === "continuous" &&
        wantListening &&
        isSoftSttSegmentError(code) &&
        !streamPartial
      ) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
        softFailStreak += 1
        handlers.onError(code)
        if (softFailStreak >= SOFT_FAIL_MAX) {
          handlers.onEnd()
          reset()
          return
        }
        handlers.onSegmentContinue?.()
        return
      }
      // Streaming with pending null on soft: notify UI but let loop own streak via end path
      if (mode === "continuous" && streamPartial && isSoftSttSegmentError(code)) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
        handlers.onError(code)
        return
      }
      handlers.onError(code)
      handlers.onEnd()
      reset()
    }
  }

  const ensureSub = () => {
    if (unsub) return
    unsub = deps.onMessage(onWs)
  }

  const uploadAndWait = (
    sid: string,
    wav: Uint8Array,
  ): Promise<{ ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string }> => {
    return new Promise((resolve) => {
      if (!sid || dead) {
        resolve({ ok: false, code: "aborted" })
        return
      }
      phase = "uploading"
      handlers.onCaptureStopped?.()

      if (wav.length === 0) {
        resolve({ ok: false, code: "empty_result" })
        return
      }

      pending = { sessionId: sid, resolve }
      sessionId = sid
      armPendingTimer(sid)

      const chunks = splitIntoChunks(wav, LOCAL_STT_MAX_CHUNK_RAW_BYTES)
      for (let seq = 0; seq < chunks.length; seq++) {
        if (dead || aborted || sessionId !== sid) {
          finishPending({ ok: false, code: "aborted" })
          return
        }
        deps.send({
          type: "voice.stt.chunk",
          v: 1,
          sessionId: sid,
          seq,
          data: uint8ToBase64(chunks[seq]!),
        })
      }

      if (dead || aborted || sessionId !== sid) {
        finishPending({ ok: false, code: "aborted" })
        return
      }
      phase = "waiting"
      deps.send({
        type: "voice.stt.end",
        v: 1,
        sessionId: sid,
        totalSeq: chunks.length,
      })
    })
  }

  const sendStart = (sid: string, maxMs: number) => {
    deps.send({
      type: "voice.stt.start",
      v: 1,
      sessionId: sid,
      ...(modelId ? { modelId } : {}),
      ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
      format: "wav",
      sampleRate: LOCAL_STT_SAMPLE_RATE,
      channels: LOCAL_STT_CHANNELS,
      lang: lang.startsWith("zh") ? "zh" : lang,
      maxMs,
      // P1: server-enforced privacy ack (chrome.storage alone is not enough)
      privacy_ack_v2: true,
    })
  }

  /**
   * Record one segment: wait segmentMs or user stop(), then return WAV.
   */
  const recordSegment = async (segmentMs: number): Promise<Uint8Array | null> => {
    const handle = await beginCapture({ maxMs: segmentMs, onLevel: handlers.onLevel })
    if (dead || aborted || !wantListening) {
      try {
        handle.abort()
      } catch {
        /* */
      }
      return null
    }
    capture = handle

    await new Promise<void>((resolve) => {
      let settled = false
      const done = () => {
        if (settled) return
        settled = true
        clearSegmentTimer()
        segmentStopTrigger = null
        resolve()
      }
      segmentStopTrigger = done
      segmentTimer = setTimeout(done, segmentMs)
    })

    capture = null
    if (dead || aborted) {
      try {
        handle.abort()
      } catch {
        /* */
      }
      return null
    }
    try {
      return await handle.stop()
    } catch (e: any) {
      if (e?.code === "aborted" || aborted) return null
      throw e
    }
  }

  const runClassic = async (sid: string) => {
    try {
      const handle = await beginCapture({ maxMs: LOCAL_STT_MAX_RECORD_MS, onLevel: handlers.onLevel })
      if (dead || aborted || sessionId !== sid) {
        handle.abort()
        return
      }
      capture = handle
      // C1 / D1c: do NOT voice.stt.start until upload. Companion arms 10s idle
      // on start with zero chunks during record → forceAbort (classic ≥10s).
      if (dead || aborted) {
        handle.abort()
        return
      }
      handlers.onStart()
    } catch (e: any) {
      if (dead || aborted) return
      const code =
        e?.code === "aborted"
          ? "aborted"
          : e?.name === "NotAllowedError" || e?.name === "PermissionDeniedError"
            ? "not-allowed"
            : "audio-capture"
      handlers.onError(code)
      handlers.onEnd()
      reset()
    }
  }

  /**
   * M2 streaming continuous: PCM chunks live + partial_request → interim hypothesis;
   * window end → single final commit (F3: no mid-window finalChunk).
   * Window length honors segmentCapMs (F1), default ~8s when realtime.
   */
  const runStreamingContinuous = async (gen: number) => {
    try {
      handlers.onStart()
      while (!dead && wantListening && gen === loopGen) {
        const remaining = hardCapMs - (Date.now() - wallStart)
        if (remaining < 200) break

        // F1: honor near-realtime segmentCapMs (not always 45s)
        const windowMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
        segmentIndex += 1
        const segSid = `${parentSessionId}-s${segmentIndex}`
        sessionId = segSid
        phase = "recording"
        streamSeq = 0
        streamStable = ""
        streamPrevHypothesis = ""
        partialPollMs = STREAM_PARTIAL_POLL_DEFAULT_MS
        let sessionStarted = false

        // N3: soft-stop may arrive while we await gUM — honor after resolve
        if (pendingSoftStop || !wantListening) {
          pendingSoftStop = false
          if (!dead) {
            handlers.onEnd()
            reset()
          }
          return
        }

        // F7: open mic first, then voice.stt.start (avoid idle abort during gUM)
        try {
          pcmStream = await beginPcmStream({
            maxMs: windowMs,
            onLevel: handlers.onLevel,
            onPcmChunk: (pcm) => {
              if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
              if (!sessionStarted || pcm.length === 0) return
              const chunks = splitIntoChunks(pcm, LOCAL_STT_MAX_CHUNK_RAW_BYTES)
              for (const c of chunks) {
                deps.send({
                  type: "voice.stt.chunk",
                  v: 1,
                  sessionId: segSid,
                  seq: streamSeq,
                  data: uint8ToBase64(c),
                })
                streamSeq += 1
              }
            },
          })
        } catch (e: any) {
          if (dead || gen !== loopGen) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
          return
        }

        // N3: soft stop during gUM — release mic, clean end (no full window)
        if (dead || gen !== loopGen) {
          try {
            pcmStream?.abort()
          } catch {
            /* */
          }
          pcmStream = null
          return
        }
        if (aborted || pendingSoftStop || !wantListening) {
          try {
            pcmStream?.abort()
          } catch {
            /* */
          }
          pcmStream = null
          pendingSoftStop = false
          if (aborted) {
            handlers.onError("aborted")
          }
          if (!dead) {
            handlers.onEnd()
            reset()
          }
          return
        }

        deps.send({
          type: "voice.stt.start",
          v: 1,
          sessionId: segSid,
          ...(modelId ? { modelId } : {}),
          ...(deps.engineKind === "system" ? { engine: "system" as const } : {}),
          format: "pcm_s16le",
          sampleRate: LOCAL_STT_SAMPLE_RATE,
          channels: LOCAL_STT_CHANNELS,
          lang: lang.startsWith("zh") ? "zh" : lang,
          maxMs: windowMs,
          // P1: same wire gate as classic WAV start — continuous/hold path must not omit
          privacy_ack_v2: true,
        })
        sessionStarted = true

        // Adaptive partial poll: setTimeout chain paced by last hypothesis `ms`
        clearPartialTimer()
        const schedulePartialPoll = () => {
          clearPartialTimer()
          if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
          if (phase !== "recording") return
          partialTimer = setTimeout(() => {
            partialTimer = null
            if (dead || aborted || gen !== loopGen || sessionId !== segSid) return
            if (phase !== "recording") return
            deps.send({
              type: "voice.stt.partial_request",
              v: 1,
              sessionId: segSid,
            })
            // Reschedule with current pace (updated when hypothesis with ms arrives)
            schedulePartialPoll()
          }, partialPollMs)
        }
        schedulePartialPoll()

        // Wait until window ends, user stop, or hard cap
        await new Promise<void>((resolve) => {
          let settled = false
          const done = () => {
            if (settled) return
            settled = true
            clearSegmentTimer()
            segmentStopTrigger = null
            resolve()
          }
          segmentStopTrigger = done
          // Soft-stop already requested before wait armed → end immediately
          if (pendingSoftStop || !wantListening) {
            pendingSoftStop = false
            done()
            return
          }
          segmentTimer = setTimeout(done, windowMs)
        })

        clearPartialTimer()
        const handle = pcmStream
        pcmStream = null
        if (handle) {
          try {
            await handle.stop()
          } catch {
            /* */
          }
        }

        if (dead || gen !== loopGen) return
        if (aborted) {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
          handlers.onError("aborted")
          handlers.onEnd()
          reset()
          return
        }

        // Final decode for this window — single commit (F3)
        phase = "waiting"
        handlers.onCaptureStopped?.()
        if (streamSeq === 0) {
          // No audio captured this window
          if (!wantListening) break
          handlers.onSegmentContinue?.()
          continue
        }
        const result = await new Promise<
          { ok: true; text: string; postprocessed?: boolean } | { ok: false; code: string }
        >(
          (resolve) => {
            pending = { sessionId: segSid, resolve }
            armPendingTimer(segSid)
            deps.send({
              type: "voice.stt.end",
              v: 1,
              sessionId: segSid,
              totalSeq: streamSeq,
            })
          },
        )

        if (dead || gen !== loopGen) return
        if (result.ok === false) {
          const streamErr = result.code
          if (streamErr === "aborted" || aborted) {
            handlers.onError("aborted")
            handlers.onEnd()
            reset()
            return
          }
          if (streamErr === "empty_result") {
            softFailStreak = 0
            handlers.onResult({ interim: "", finalChunk: "" })
          } else if (isSoftSttSegmentError(streamErr) && wantListening) {
            softFailStreak += 1
            handlers.onError(streamErr)
            handlers.onResult({ interim: "", finalChunk: "" })
            if (softFailStreak >= SOFT_FAIL_MAX) {
              handlers.onEnd()
              reset()
              return
            }
          } else {
            // conflict/busy/oom: try reclaim then hard stop (do not soft-loop max-1)
            if (streamErr === "resource_conflict" || streamErr === "session_busy") {
              try {
                deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
              } catch {
                /* */
              }
              await new Promise((r) => setTimeout(r, 200))
              // The abort's own "aborted" ACK may have torn us down during the
              // wait (no-pending kill path) — do not fire handlers a second time.
              if (dead || gen !== loopGen) return
            }
            handlers.onError(streamErr)
            handlers.onEnd()
            reset()
            return
          }
        } else if (result.text.trim()) {
          softFailStreak = 0
          // Window commit: one finalChunk for the whole window text
          handlers.onResult({
            interim: "",
            finalChunk: result.text.trim(),
            ...(result.postprocessed === true ? { postprocessed: true } : {}),
          })
          streamStable = result.text.trim()
        } else {
          softFailStreak = 0
          handlers.onResult({ interim: "", finalChunk: "" })
        }

        if (!wantListening || aborted || mode === "classic") break
        handlers.onSegmentContinue?.()
      }

      if (!dead) handlers.onEnd()
      reset()
    } catch {
      if (!dead) {
        handlers.onError("unknown")
        handlers.onEnd()
      }
      reset()
    }
  }

  const runContinuous = async (gen: number) => {
    if (streamPartial) {
      await runStreamingContinuous(gen)
      return
    }
    try {
      handlers.onStart()
      while (!dead && wantListening && gen === loopGen) {
        const remaining = hardCapMs - (Date.now() - wallStart)
        // Allow short test segments (<800ms wall hardCap with tiny segmentCapMs)
        if (remaining < Math.min(50, segmentCapMs)) break

        const segmentMs = Math.min(segmentCapMs, LOCAL_STT_MAX_RECORD_MS, remaining)
        segmentIndex += 1
        const segSid = `${parentSessionId}-s${segmentIndex}`
        sessionId = segSid
        phase = "recording"

        // Do NOT voice.stt.start until upload: companion arms 10s idle on start
        // with zero chunks during record → forceAbort (Pi D1c blocker #2).
        let wav: Uint8Array | null
        try {
          wav = await recordSegment(segmentMs)
        } catch (e: any) {
          if (dead || gen !== loopGen) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
          return
        }

        if (dead || gen !== loopGen) return
        if (aborted || wav == null) {
          // User abort or cancelled before audio
          if (aborted) {
            handlers.onError("aborted")
          }
          handlers.onEnd()
          reset()
          return
        }

        // Open STT session then immediately stream chunks (keeps idle timer happy).
        sendStart(segSid, segmentMs)
        let result = await uploadAndWait(segSid, wav)
        // Conflict: abort any stale holder then one retry (must free max-1 slot).
        if (
          result.ok === false &&
          (result.code === "resource_conflict" || result.code === "session_busy") &&
          !dead &&
          !aborted &&
          gen === loopGen
        ) {
          const retrySid = `${segSid}-r1`
          // V1/L10: adopt the retry sid BEFORE abort+backoff. The rejected sid's
          // chunk/end session_unknown rejects and the abort's own error ACK land
          // during the sleep; with the old sid still current they hit the
          // no-pending kill path (onError+onEnd+reset) and orphaned this retry.
          sessionId = retrySid
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: segSid })
          // Best-effort: also abort parent-prefixed sessions from this capture
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: parentSessionId })
          await new Promise((r) => setTimeout(r, 250))
          if (dead || aborted || gen !== loopGen) return
          // Belt-and-suspenders: never upload the retry without a subscription.
          ensureSub()
          sendStart(retrySid, segmentMs)
          result = await uploadAndWait(retrySid, wav)
        }
        if (dead || gen !== loopGen) return

        if (result.ok === false) {
          const errCode = result.code
          if (errCode === "aborted" || aborted) {
            handlers.onError("aborted")
            handlers.onEnd()
            reset()
            return
          }
          if (isHardSttSegmentError(errCode) || errCode === "oom") {
            handlers.onError(errCode)
            handlers.onEnd()
            reset()
            return
          }
          // Soft only after end() failures that drop companion bound
          if (isSoftSttSegmentError(errCode) && wantListening) {
            softFailStreak += 1
            handlers.onError(errCode)
            if (softFailStreak >= SOFT_FAIL_MAX) {
              handlers.onEnd()
              reset()
              return
            }
            handlers.onSegmentContinue?.()
            continue
          }
          // resource_conflict after retry, payload_too_large, etc. → hard stop
          handlers.onError(errCode)
          handlers.onEnd()
          reset()
          return
        }

        softFailStreak = 0
        if (result.text.trim()) {
          handlers.onResult({
            interim: "",
            finalChunk: result.text,
            ...(result.postprocessed === true ? { postprocessed: true } : {}),
          })
        }

        if (!wantListening || aborted) break

        // Resume listening chrome between segments
        handlers.onSegmentContinue?.()
      }

      if (!dead) handlers.onEnd()
      reset()
    } catch {
      if (!dead) {
        handlers.onError("unknown")
        handlers.onEnd()
      }
      reset()
    }
  }

  return {
    start(langOrOpts?: SpeechAdapterStartArg) {
      if (dead) return
      if (phase !== "idle") return

      aborted = false
      wantListening = true
      lang = VOICE_DEFAULT_LANG
      let sid = ""
      let mid = deps.modelId
      mode = "classic"
      hardCapMs = VOICE_CONTINUOUS_HARD_CAP_MS
      segmentCapMs = LOCAL_STT_MAX_RECORD_MS
      streamPartial = false

      if (typeof langOrOpts === "string") {
        lang = langOrOpts || VOICE_DEFAULT_LANG
      } else if (langOrOpts && typeof langOrOpts === "object") {
        if (langOrOpts.lang) lang = langOrOpts.lang
        if (langOrOpts.sessionId) sid = langOrOpts.sessionId
        if (langOrOpts.modelId) mid = langOrOpts.modelId
        if (langOrOpts.mode === "continuous") mode = "continuous"
        if (typeof (langOrOpts as { hardCapMs?: number }).hardCapMs === "number") {
          hardCapMs = (langOrOpts as { hardCapMs: number }).hardCapMs
        }
        if (typeof (langOrOpts as { segmentMs?: number }).segmentMs === "number") {
          segmentCapMs = Math.max(
            20,
            Math.min(LOCAL_STT_MAX_RECORD_MS, (langOrOpts as { segmentMs: number }).segmentMs),
          )
        }
        if ((langOrOpts as { streamPartial?: boolean }).streamPartial === true) {
          streamPartial = true
          // Prefer near-realtime segment defaults when streaming
          if (mode === "continuous" && segmentCapMs >= LOCAL_STT_MAX_RECORD_MS) {
            segmentCapMs = LOCAL_STT_NEAR_REALTIME_SEGMENT_MS
          }
        }
        // large-v3-turbo: progressive re-decode is too heavy (loads full model often).
        // Force final-only continuous windows even if caller asked for streamPartial.
        if (mid === "large-v3-turbo" || modelId === "large-v3-turbo") {
          streamPartial = false
          segmentCapMs = LOCAL_STT_MAX_RECORD_MS
        }
        // #259: SAPI is batch — no progressive hypotheses for system sessions.
        if (deps.engineKind === "system") {
          streamPartial = false
          segmentCapMs = LOCAL_STT_MAX_RECORD_MS
        }
      }

      if (!sid) {
        handlers.onError("session_busy")
        handlers.onEnd()
        return
      }

      parentSessionId = sid
      sessionId = sid
      modelId = mid || deps.modelId || ""
      if (mode === "classic" && streamPartial) {
        // Progressive preview for ordinary dictation, with one bounded final.
        // Leave transport/drain time before the daemon's 45 s recording lease expires.
        hardCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
        segmentCapMs = LOCAL_STT_MAX_RECORD_MS - 1_000
      }
      ensureSub()
      phase = "recording"
      wallStart = Date.now()
      segmentIndex = 0
      loopGen += 1
      const gen = loopGen

      if (streamPartial) {
        void runStreamingContinuous(gen)
      } else if (mode === "continuous") {
        void runContinuous(gen)
      } else {
        void runClassic(sid)
      }
    },

    stop() {
      if (dead) return
      if (phase === "idle") return

      wantListening = false

      // Continuous: finish current segment early, then exit after upload / end stream
      if (mode === "continuous" || streamPartial) {
        if (phase === "recording") {
          // N3: if window wait not armed yet (still in gUM), mark pending soft stop
          if (!segmentStopTrigger) {
            pendingSoftStop = true
          }
          segmentStopTrigger?.()
        }
        // Waiting for companion infer: re-arm with stopGrace so a dead
        // Companion (SIGTERM mid-window) cannot leave the mic/UI hung.
        if ((phase === "waiting" || phase === "uploading") && pending && sessionId) {
          armPendingTimer(sessionId)
        }
        return
      }

      // classic
      if (phase === "uploading" || phase === "waiting") {
        return
      }

      const handle = capture
      capture = null
      if (!handle) {
        // L10: double-click stop while the first stop's upload chain is in
        // flight — ignore the repeat instead of aborting the upload (which
        // silently discarded the whole recording).
        if (stopChainInFlight) return
        aborted = true
        handlers.onError("aborted")
        handlers.onEnd()
        reset()
        return
      }

      stopChainInFlight = true
      const genAtStop = loopGen
      void handle
        .stop()
        .then(async (wav) => {
          const sid = sessionId
          if (!sid) return
          if (dead || aborted || genAtStop !== loopGen) return
          // Open STT session then immediately stream chunks (keeps idle timer happy).
          sendStart(sid, LOCAL_STT_MAX_RECORD_MS)
          let result = await uploadAndWait(sid, wav)
          if (
            result.ok === false &&
            (result.code === "resource_conflict" || result.code === "session_busy") &&
            !dead &&
            genAtStop === loopGen
          ) {
            const retrySid = `${sid}-r1`
            // V1: adopt the retry sid BEFORE abort+backoff. The rejected sid's
            // chunk/end session_unknown rejects and the abort's own error ACK
            // land during the sleep; with the old sid still current they hit
            // the no-pending kill path (onError+onEnd+reset) and turned this
            // retry into a zombie (no subscription, pending never settled).
            sessionId = retrySid
            deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
            await new Promise((r) => setTimeout(r, 250))
            if (dead || genAtStop !== loopGen) return
            // Belt-and-suspenders: never upload the retry without a subscription.
            ensureSub()
            sendStart(retrySid, LOCAL_STT_MAX_RECORD_MS)
            result = await uploadAndWait(retrySid, wav)
          }
          if (dead) return
          if (result.ok === false) {
            const errCode = result.code
            // User-stop timeout uses empty_result so we can onEnd without a banner.
            if (errCode !== "empty_result") {
              handlers.onError(errCode === "aborted" ? "aborted" : errCode)
            }
          } else if (result.text.trim()) {
            handlers.onResult({
              interim: "",
              finalChunk: result.text,
              ...(result.postprocessed === true ? { postprocessed: true } : {}),
            })
          }
          handlers.onEnd()
          reset()
        })
        .catch((e: any) => {
          if (aborted || dead) return
          handlers.onError(e?.code === "aborted" ? "aborted" : "audio-capture")
          handlers.onEnd()
          reset()
        })
    },

    abort() {
      if (dead) return
      aborted = true
      wantListening = false
      loopGen += 1
      clearSegmentTimer()
      clearPartialTimer()
      segmentStopTrigger?.()
      segmentStopTrigger = null
      const sid = sessionId
      const handle = capture
      capture = null
      try {
        handle?.abort()
      } catch {
        /* */
      }
      if (pcmStream) {
        try {
          pcmStream.abort()
        } catch {
          /* */
        }
        pcmStream = null
      }
      if (sid) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
      }
      finishPending({ ok: false, code: "aborted" })
      handlers.onError("aborted")
      handlers.onEnd()
      reset()
    },

    destroy() {
      dead = true
      aborted = true
      wantListening = false
      pendingSoftStop = true
      loopGen += 1
      clearSegmentTimer()
      clearPartialTimer()
      // Fire wait resolvers so streaming coroutines do not hang (Pi destroy nit)
      try {
        segmentStopTrigger?.()
      } catch {
        /* */
      }
      segmentStopTrigger = null
      const sid = sessionId
      const handle = capture
      capture = null
      try {
        handle?.abort()
      } catch {
        /* */
      }
      if (pcmStream) {
        try {
          pcmStream.abort()
        } catch {
          /* */
        }
        pcmStream = null
      }
      if (sid) {
        try {
          deps.send({ type: "voice.stt.abort", v: 1, sessionId: sid })
        } catch {
          /* */
        }
      }
      finishPending({ ok: false, code: "aborted" })
      reset()
    },
  }
}
