Independent implementation gate #477 UI-only slice of #476. Complete current source follows, not a truncated diff. User requested a readable workspace and visible resources; old hidden-navigation requirements intentionally superseded. Do NOT require full management/terminal/native hosting for this UI slice, and do NOT approve full #476. No ACL expansion. MCP remains read-only, existing skills/knowledge only attach to thread. New browser-status GET follows auth/Host gate. New visible Stop calls same existing abort owner. Narrow history no longer covers composer. Large1040x760 shell + compact360x420. Existing external models need not be available to test this UI.
Machine: build exit0; full5023 tests5000pass23skip+20aux before final history-refresh correction; final94 owning tests PASS; actual HTML Playwright widths320/360/390/760/1000/1440 andshort420/480, search, MCPempty, actual peer-statusauth, browser attach, busy Stop with navigation open, Escape andsendPASS. Current final correction restores history-open refresh and adds gate comment.
Check concrete security/correctness/async/focus/layout regressions. Source is authoritative over old docs/comments. No tools, no other reviewer reports. Output under1000 words, rank actionable defects with paths, final VERDICT: APPROVE | APPROVE_WITH_NITS | REJECT.

## companion/src/summoner-web.ts
/**
 * C-thin summoner shell: loopback HTML + token (settings-web pattern).
 *
 * The page never upgrades companion WS — Origin allowlist stays
 * chrome-extension:// and cmspark-tray://local. Tray dispatch uses the
 * existing summoner-stamped CompanionClient.
 */
import * as http from "http"
import * as crypto from "crypto"
import * as child_process from "child_process"
import * as fs from "fs"
import * as os from "os"
import * as path from "path"
import {
  closeOverlayChrome,
  overlayWindowPosition,
  OVERLAY_WINDOW_SIZE,
  parseFinderDesktopBounds,
  planSummonerShellOpen,
  resolveSummonerBrowserPath,
} from "./summoner/shell-open"
import { applySummonerPayloadPolicy } from "./ws/summoner-acl"
import { MCP_OVERLAY_CONFIRM_NOTICE } from "./mcp/confirm-target"
import {
  attachChromeOnly,
  SUMMONER_ATTACH_FOOTNOTE,
  SUMMONER_ATTACH_PRIMARY,
  SUMMONER_ATTACH_SECONDARY,
  SUMMONER_CONFIRM_NEED,
  SUMMONER_OPEN_CONFIRM,
  SUMMONER_CDP_NEEDED,
  SUMMONER_CHEVRON_COLLAPSE,
  SUMMONER_CHEVRON_EXPAND,
  SUMMONER_L0_CHROME_DOWN,
  SUMMONER_RENTER_CHROME_DOWN,
  CHAT_SHELL_TITLE_NONE,
  VOICE_PRIVACY_ACK_V2_CLAUSES,
  MEETING_PRIVACY_ACK_V1_CLAUSES,
} from "./summoner/client"
import { getChromeOpener } from "./platform"
import { getConfig } from "./config"
import { OVERLAY_RENDER_MD_JS } from "./summoner/overlay-md"
import { currentOverlayCruiseChipLabel } from "./summoner/hydrate"

export type SummonerWebDispatch = (msg: Record<string, unknown>) => Promise<unknown>
export type SummonerWebAttachChrome = (opts?: { foreground?: boolean }) => string
export type SummonerWebRequestOpenSidePanel = () => Promise<{ error_code?: string } | void>
export type SummonerWebHasExtensionPeer = () => boolean

export const SUMMONER_WEB_DISPATCH_ALLOW = new Set([
  "system.ping",
  "chat.create",
  "chat.abort",
  "chat.steer",
  "thread.list",
  "thread.select",
  "thread.create",
  "thread.delete",
  "thread.update",
  "mcp.list",
  "pack.list",
  "pack.apply",
  "skill.list",
  "skill.activate",
  "skill.deactivate",
  "knowledge.list",
  "knowledge.set_active",
  "file.upload",
  "composer.lease.get",
  "composer.lease.claim",
  "composer.lease.release",
  "voice.stt.start",
  "voice.stt.chunk",
  "voice.stt.end",
  "voice.stt.abort",
  "voice.stt.partial_request",
  "meeting.create",
  "meeting.start",
  "meeting.end",
  "meeting.append_transcript",
  "meeting.generate_minutes",
  "meeting.list",
  "meeting.get",
])

/** Fan-out to HTML EventSource. Confirm / Trust / config frames stay off this list.
 *  overlay.cruise is a derived display string (#324), not a config dump. */
export const SUMMONER_WEB_EVENT_ALLOW = new Set([
  "overlay.cruise",
  "chat.token",
  "chat.done",
  "chat.error",
  "chat.user",
  "chat.steered",
  "chat.enqueued",
  "chat.aborted",
  "error",
  "file.upload_status",
  "file.upload_error",
  "file.uploaded",
  "run_status",
  "thread.updated",
  "composer.lease",
  "tool.start",
  "mcp.confirm.pending",
  "voice.stt.partial",
  "voice.stt.result",
  "voice.stt.error",
  "meeting.created",
  "meeting.started",
  "meeting.ended",
  "meeting.error",
  "meeting.updated",
  "meeting.minutes_result",
  "meeting.list_result",
  "meeting.get_result",
  "meeting.diarized",
])

const MAX_SSE_CLIENTS = 4
const sseClients = new Set<http.ServerResponse>()

const FILE_BODY_MAX = 15 * 1024 * 1024
const JSON_BODY_MAX = 64 * 1024
/** /api/stt/chunk only: JSON around base64(256KiB PCM) ≈ 342KiB + envelope. */
const STT_CHUNK_BODY_MAX = 400 * 1024

function escHtml(s: string): string {
  return String(s).replace(/[&<>"]/g, (c) =>
    c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : "&quot;",
  )
}

let activeServer: http.Server | null = null
let activePort: number | null = null
let sessionToken: string | null = null
let activeDispatch: SummonerWebDispatch | null = null
let activeAttachChrome: SummonerWebAttachChrome | null = null
let activeRequestOpenSidePanel: SummonerWebRequestOpenSidePanel | null = null
let activeHasExtensionPeer: SummonerWebHasExtensionPeer | null = null
let activeOnShellClosed: (() => void) | null = null
let lastAccessTime = Date.now()
let autoCloseTimer: ReturnType<typeof setInterval> | null = null

function defaultAttachChrome(opts?: { foreground?: boolean }): string {
  return attachChromeOnly(getChromeOpener(), opts)
}

async function findAvailablePort(startPort: number): Promise<number> {
  for (let port = startPort; port < startPort + 10; port++) {
    try {
      await new Promise<void>((resolve, reject) => {
        const probe = http.createServer()
        probe.on("error", reject)
        probe.listen(port, "127.0.0.1", () => {
          probe.close(() => resolve())
        })
      })
      return port
    } catch {
      continue
    }
  }
  throw new Error("No available port for summoner web server")
}

function parseQuery(qs: string): Map<string, string> {
  const out = new Map<string, string>()
  if (!qs) return out
  for (const pair of qs.split("&")) {
    if (!pair) continue
    const eq = pair.indexOf("=")
    const k = eq < 0 ? decodeURIComponent(pair) : decodeURIComponent(pair.slice(0, eq))
    const v = eq < 0 ? "" : decodeURIComponent(pair.slice(eq + 1))
    out.set(k, v)
  }
  return out
}

function overlayCookieToken(req: http.IncomingMessage): string | undefined {
  const raw = String(req.headers.cookie || "")
  const m = raw.match(/(?:^|;\s*)cmspark_overlay=([0-9a-fA-F]{64})/)
  return m?.[1]
}

function overlayHeaderToken(req: http.IncomingMessage): string | undefined {
  const h = req.headers["x-cmspark-overlay-token"]
  return typeof h === "string" ? h.trim() : undefined
}

function tokenOk(req: http.IncomingMessage, expected: string): boolean {
  const provided = overlayHeaderToken(req) || overlayCookieToken(req)
  if (!provided || provided.length !== expected.length) return false
  return crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(expected))
}

function hostOk(req: http.IncomingMessage, port: number): boolean {
  const host = (req.headers.host || "").toLowerCase()
  return host === `127.0.0.1:${port}` || host === `localhost:${port}` || host === `[::1]:${port}`
}

function originOk(req: http.IncomingMessage, port: number): boolean {
  const origin = (req.headers.origin || "").toLowerCase()
  if (!origin || origin === "null") return false
  return (
    origin === `http://127.0.0.1:${port}` ||
    origin === `http://localhost:${port}` ||
    origin === `http://[::1]:${port}`
  )
}

function forbidden(res: http.ServerResponse, reason: string) {
  if (res.headersSent) {
    res.end()
    return
  }
  res.writeHead(403, { "Content-Type": "text/plain; charset=utf-8" })
  res.end(`Forbidden: ${reason}`)
}

function jsonResponse(res: http.ServerResponse, data: unknown, status = 200) {
  if (!res.headersSent) {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" })
  }
  res.end(JSON.stringify(data))
}

function readBody(req: http.IncomingMessage, maxSize: number): Promise<string> {
  return new Promise((resolve, reject) => {
    let body = ""
    let size = 0
    req.on("data", (chunk: Buffer) => {
      size += chunk.length
      if (size > maxSize) {
        reject(new Error("Request body too large"))
        req.destroy()
        return
      }
      body += chunk.toString()
    })
    req.on("end", () => resolve(body))
    req.on("error", reject)
  })
}

async function dispatchAllowed(type: string, payload: Record<string, unknown>): Promise<unknown> {
  if (!SUMMONER_WEB_DISPATCH_ALLOW.has(type)) {
    throw Object.assign(new Error(`not allowed: ${type}`), { status: 403 })
  }
  const msg: Record<string, unknown> = { ...payload, type }
  const gate = applySummonerPayloadPolicy("summoner", msg)
  if (!gate.ok) {
    throw Object.assign(new Error(gate.error), { status: 403, error_code: gate.error_code })
  }
  if (!activeDispatch) throw Object.assign(new Error("summoner dispatch unavailable"), { status: 503 })
  return activeDispatch(msg)
}

export function summonerWebPageUrl(port: number, _token?: string): string {
  return `http://127.0.0.1:${port}/`
}

const STATUS_LABELS: Record<string, string> = {
  run_active: "本轮还在跑 · 回车纠偏或排队",
  queue_full: "排队已满（最多 8 条）",
  steer_queue_full: "纠偏队列已满",
  idle_enqueue: "空闲时直接发送，不必排队",
  OVERLAY_STANDBY: "侧栏占用了输入",
  LEASE_REV_MISMATCH: "侧栏占用了输入",
  LEASE_HOLDER_SURFACE_MISMATCH: "侧栏占用了输入",
  BROWSER_UNAVAILABLE: SUMMONER_CDP_NEEDED,
}

/** Map router/SSE errors to overlay copy. Keys `data.error_code`, not the English `error` sentence. */
export function summonerWebEventStatus(msg: unknown): string {
  if (!msg || typeof msg !== "object" || Array.isArray(msg)) return "出错了"
  const m = msg as Record<string, unknown>
  const data = m.data && typeof m.data === "object" && !Array.isArray(m.data)
    ? (m.data as Record<string, unknown>)
    : {}
  const raw = String(m.error_code || data.error_code || m.error || "")
  const code = raw.includes("OVERLAY_STANDBY")
    ? "OVERLAY_STANDBY"
    : raw.includes("LEASE_REV_MISMATCH")
      ? "LEASE_REV_MISMATCH"
      : raw.includes("BROWSER_UNAVAILABLE")
        ? "BROWSER_UNAVAILABLE"
        : raw
  if (STATUS_LABELS[code]) return STATUS_LABELS[code]
  if (typeof m.error === "string" && m.error.trim()) return m.error
  if (typeof m.message === "string" && m.message.trim()) return m.message
  return "出错了"
}

export function pushSummonerWebEvent(msg: unknown): boolean {
  if (!msg || typeof msg !== "object" || Array.isArray(msg)) return false
  const type = (msg as { type?: unknown }).type
  if (typeof type !== "string" || !SUMMONER_WEB_EVENT_ALLOW.has(type)) return false
  if (/confirm/i.test(type) && type !== "mcp.confirm.pending") return false
  const line = `data: ${JSON.stringify(msg)}\n\n`
  for (const res of sseClients) {
    try {
      res.write(line)
    } catch {
      sseClients.delete(res)
    }
  }
  return true
}

function closeSseClients(): void {
  for (const res of sseClients) {
    try {
      res.end()
    } catch {
      /* ignore */
    }
  }
  sseClients.clear()
}

export type OpenLoopbackPageDeps = {
  platform?: NodeJS.Platform
  browserPath?: string | null
  userDataDir?: string
  screen?: { w: number; h: number }
  spawn?: (
    command: string,
    args: string[],
    options: { detached?: boolean; stdio?: "ignore"; windowsHide?: boolean; shell?: boolean },
  ) => { unref: () => void; pid?: number }
}

/** win32 has no ps(1); keep the spawned PID so hide can TerminateProcess it. */
let overlayShellPid = 0
let overlayShellPlatform: NodeJS.Platform = process.platform

function killOverlayShellPid(): void {
  const pid = overlayShellPid
  overlayShellPid = 0
  if (!pid) return
  try {
    process.kill(pid) // win32 maps to TerminateProcess
  } catch {
    /* ESRCH / already exited */
  }
}

export function defaultOverlayChromeDir(): string {
  const root = process.env.CMSPARK_DATA_DIR || path.join(os.homedir(), ".cmspark-agent")
  return path.join(root, "overlay-chrome")
}

let overlayLaunchAt = 0
const OVERLAY_LAUNCH_GRACE_MS_DEFAULT = 2000
let overlayLaunchGraceMs = OVERLAY_LAUNCH_GRACE_MS_DEFAULT
/** EventSource auto-reconnects (~3s) after a transient drop; never kill on the first close. */
const OVERLAY_SSE_RECONNECT_GRACE_MS_DEFAULT = 8000
let overlaySseReconnectGraceMs = OVERLAY_SSE_RECONNECT_GRACE_MS_DEFAULT
/** After an explicit close request, an SSE drop is the page going away, not reconnecting. */
const OVERLAY_CLOSE_AFTER_REQUEST_MS = 1000
/** Explicit hide but SSE never drops (close failed): bound the lease release. */
const OVERLAY_HIDE_FALLBACK_MS = 8000
let overlayShellCloseTimer: ReturnType<typeof setTimeout> | null = null
let overlayShellCloseGen = 0
let overlayCloseRequested = false
let overlaySttSessionId = ""
let overlayMeetingId = ""

function overlayLaunchInGrace(): boolean {
  return !!(overlayLaunchAt && Date.now() - overlayLaunchAt < overlayLaunchGraceMs)
}

export function __testSetOverlayLaunchGraceMs(ms: number): void {
  overlayLaunchGraceMs =
    Number.isFinite(ms) && ms > 0 ? ms : OVERLAY_LAUNCH_GRACE_MS_DEFAULT
}

export function __testSetOverlaySseReconnectGraceMs(ms: number): void {
  overlaySseReconnectGraceMs =
    Number.isFinite(ms) && ms > 0 ? ms : OVERLAY_SSE_RECONNECT_GRACE_MS_DEFAULT
}

function clearOverlayShellCloseTimer(): void {
  overlayShellCloseGen += 1
  if (overlayShellCloseTimer) {
    clearTimeout(overlayShellCloseTimer)
    overlayShellCloseTimer = null
  }
}

/** Deferred last-SSE close; a new SSE client or a fresh launch cancels it. */
function scheduleOnShellClosed(delayMs: number): void {
  clearOverlayShellCloseTimer()
  const gen = overlayShellCloseGen
  const timer = setTimeout(() => {
    if (gen !== overlayShellCloseGen) return
    overlayShellCloseTimer = null
    if (sseClients.size > 0) return
    invokeOnShellClosed()
  }, Math.max(0, delayMs))
  if (typeof timer.unref === "function") timer.unref()
  overlayShellCloseTimer = timer
}

function overlayDispatchFailed(result: unknown): boolean {
  if (!result || typeof result !== "object" || Array.isArray(result)) return true
  const t = (result as { type?: unknown }).type
  return t === "error" || t === "voice.stt.error" || t === "meeting.error"
}

function readMeetingIdFromDispatch(result: unknown, fallback: string): string {
  if (!result || typeof result !== "object" || Array.isArray(result)) return fallback
  const r = result as Record<string, unknown>
  const meeting =
    r.meeting && typeof r.meeting === "object" && !Array.isArray(r.meeting)
      ? (r.meeting as Record<string, unknown>)
      : null
  if (typeof meeting?.id === "string" && meeting.id.trim()) return meeting.id.trim()
  const data =
    r.data && typeof r.data === "object" && !Array.isArray(r.data)
      ? (r.data as Record<string, unknown>)
      : null
  const nested =
    data?.meeting && typeof data.meeting === "object" && !Array.isArray(data.meeting)
      ? (data.meeting as Record<string, unknown>)
      : null
  if (typeof nested?.id === "string" && nested.id.trim()) return nested.id.trim()
  return fallback
}

/** Hide / last-SSE / idle-stop: stop overlay capture even if HTML pagehide never ran. */
function abortOverlayCaptureSessions(): void {
  const sid = overlaySttSessionId
  const mid = overlayMeetingId
  overlaySttSessionId = ""
  overlayMeetingId = ""
  if (sid) {
    void dispatchAllowed("voice.stt.abort", { v: 1, sessionId: sid }).catch(() => {
      /* close path must not throw */
    })
  }
  if (mid) {
    void dispatchAllowed("meeting.end", { v: 1, id: mid }).catch(() => {
      /* close path must not throw */
    })
  }
}

/** Hide/last-SSE/idle-stop share this path; twice is a no-throw. */
function invokeOnShellClosed(): void {
  clearOverlayShellCloseTimer()
  overlayCloseRequested = false
  abortOverlayCaptureSessions()
  const cb = activeOnShellClosed
  if (!cb) return
  try {
    cb()
  } catch {
    /* close path must not throw */
  }
}

export function summonerWebHasPage(): boolean {
  return sseClients.size > 0
}

/** SSE connected, or Chrome --app still coming up after spawn. */
export function summonerWebIsShowing(): boolean {
  if (sseClients.size > 0) return true
  if (overlayLaunchInGrace()) return true
  return false
}

export function requestSummonerWebClose(): boolean {
  overlayLaunchAt = 0
  overlayCloseRequested = true
  if (sseClients.size === 0) return false
  const line = `data: ${JSON.stringify({ type: "shell.close" })}\n\n`
  for (const res of sseClients) {
    try {
      res.write(line)
    } catch {
      sseClients.delete(res)
    }
  }
  return true
}

export function hideSummonerWebShell(): void {
  requestSummonerWebClose()
  if (overlayShellPlatform === "win32" && overlayShellPid) {
    killOverlayShellPid()
  } else {
    overlayShellPid = 0
    closeOverlayChrome(defaultOverlayChromeDir())
  }
  if (sseClients.size === 0) {
    // Page already gone (or never connected): nothing to wait for.
    invokeOnShellClosed()
    return
  }
  // Page may still be dying; lease release converges on the last SSE drop.
  // The fallback timer bounds the case where the close request failed.
  scheduleOnShellClosed(OVERLAY_HIDE_FALLBACK_MS)
}

function probeScreen(platform: NodeJS.Platform): { w: number; h: number } {
  if (platform === "darwin") {
    try {
      const raw = child_process.execFileSync(
        "osascript",
        ["-e", 'tell application "Finder" to get bounds of window of desktop'],
        { encoding: "utf8", timeout: 2000 },
      )
      const parsed = parseFinderDesktopBounds(raw)
      if (parsed) return parsed
    } catch {
      /* fallback */
    }
  }
  return { w: 1440, h: 900 }
}

/** Returns false when the URL is rejected (no spawn). */
export function openLoopbackPage(url: string, deps: OpenLoopbackPageDeps = {}): boolean {
  const platform = deps.platform ?? process.platform
  const browserPath =
    deps.browserPath !== undefined ? deps.browserPath : resolveSummonerBrowserPath(platform)
  const userDataDir = deps.userDataDir || defaultOverlayChromeDir()
  try {
    fs.mkdirSync(userDataDir, { recursive: true })
  } catch {
    /* Chrome can still create the profile dir */
  }
  const screen = deps.screen || probeScreen(platform)
  const plan = planSummonerShellOpen(url, {
    platform,
    browserPath,
    userDataDir,
    windowPosition: overlayWindowPosition(screen.w, screen.h),
  })
  if ("error" in plan) {
    console.error(`[summoner-web] ${plan.error}`)
    return false
  }
  overlayLaunchAt = Date.now()
  overlayCloseRequested = false
  clearOverlayShellCloseTimer()
  const spawn = deps.spawn ?? ((cmd, args, opts) => child_process.spawn(cmd, args, opts))
  const child = spawn(plan.command, plan.args, {
    detached: true,
    stdio: "ignore",
    windowsHide: true,
  })
  child.unref()
  overlayShellPid = typeof child.pid === "number" && child.pid > 0 ? child.pid : 0
  overlayShellPlatform = platform
  return true
}

export async function startSummonerWebServer(opts: {
  preferredPort?: number
  dispatch: SummonerWebDispatch
  attachChrome?: SummonerWebAttachChrome
  requestOpenSidePanel?: SummonerWebRequestOpenSidePanel
  hasExtensionPeer?: SummonerWebHasExtensionPeer
  onShellClosed?: () => void
}): Promise<{ port: number; token: string }> {
  activeDispatch = opts.dispatch
  activeAttachChrome = opts.attachChrome ?? defaultAttachChrome
  activeRequestOpenSidePanel = opts.requestOpenSidePanel ?? null
  activeHasExtensionPeer = opts.hasExtensionPeer ?? null
  activeOnShellClosed = opts.onShellClosed ?? null
  if (activeServer && activePort && sessionToken) {
    lastAccessTime = Date.now()
    return { port: activePort, token: sessionToken }
  }

  const port = await findAvailablePort(opts.preferredPort ?? 23403)
  lastAccessTime = Date.now()
  const token = crypto.randomBytes(32).toString("hex")

  const server = http.createServer((req, res) => {
    lastAccessTime = Date.now()
    void handleRequest(req, res, port, token)
  })

  await new Promise<void>((resolve, reject) => {
    server.on("error", reject)
    server.listen(port, "127.0.0.1", resolve)
  })

  activeServer = server
  activePort = port
  sessionToken = token

  autoCloseTimer = setInterval(() => {
    if (Date.now() - lastAccessTime > 30 * 60 * 1000) {
      stopSummonerWebServer()
    }
  }, 60 * 1000)

  return { port, token }
}

export function stopSummonerWebServer(): void {
  if (autoCloseTimer) {
    clearInterval(autoCloseTimer)
    autoCloseTimer = null
  }
  if (activeServer) {
    closeSseClients()
    invokeOnShellClosed()
    activeServer.close()
    activeServer = null
    activePort = null
    sessionToken = null
    activeDispatch = null
    activeAttachChrome = null
    activeRequestOpenSidePanel = null
    activeHasExtensionPeer = null
    activeOnShellClosed = null
    overlaySttSessionId = ""
    overlayMeetingId = ""
    overlayLaunchGraceMs = OVERLAY_LAUNCH_GRACE_MS_DEFAULT
    overlaySseReconnectGraceMs = OVERLAY_SSE_RECONNECT_GRACE_MS_DEFAULT
    overlayCloseRequested = false
    overlayShellPid = 0
    clearOverlayShellCloseTimer()
  }
}

async function handleRequest(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  port: number,
  token: string,
): Promise<void> {
  let pathOnly = "/"
  let query = new Map<string, string>()
  try {
    const raw = req.url || "/"
    const qIdx = raw.indexOf("?")
    pathOnly = (qIdx < 0 ? raw : raw.slice(0, qIdx)) || "/"
    query = qIdx < 0 ? new Map<string, string>() : parseQuery(raw.slice(qIdx + 1))
    if (query.has("token")) {
      forbidden(res, "query token is not allowed")
      return
    }
    const isDoc = (pathOnly === "/" || pathOnly === "/summoner") && req.method === "GET"
    if (!isDoc && !tokenOk(req, token)) {
      forbidden(res, "missing or invalid session token")
      return
    }
  } catch {
    forbidden(res, "missing or invalid session token")
    return
  }
  if (!hostOk(req, port)) {
    forbidden(res, `unexpected Host header "${req.headers.host || ""}"`)
    return
  }

  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": `http://127.0.0.1:${port}`,
      "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, X-CMspark-Overlay-Token",
    })
    res.end()
    return
  }

  if (
    (req.method === "POST" || req.method === "PATCH" || req.method === "DELETE") &&
    !originOk(req, port)
  ) {
    forbidden(res, `unexpected Origin header "${req.headers.origin || ""}"`)
    return
  }

  try {
    if ((pathOnly === "/" || pathOnly === "/summoner") && req.method === "GET") {
      const nonce = crypto.randomBytes(16).toString("base64")
      res.writeHead(200, {
        "Content-Type": "text/html; charset=utf-8",
        "Referrer-Policy": "no-referrer",
        "Set-Cookie": `cmspark_overlay=${token}; HttpOnly; SameSite=Strict; Path=/`,
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Content-Security-Policy":
          `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'`,
      })
      let cruise = "每次确认"
      try {
        cruise = currentOverlayCruiseChipLabel()
      } catch {
        cruise = "每次确认"
      }
      const html = SUMMONER_HTML.replace("<script>", `<script nonce="${nonce}">`).replace(
        "%%CRUISE_LABEL%%",
        escHtml(cruise),
      )
      res.end(html)
      return
    }

    if (pathOnly === "/api/health" && req.method === "GET") {
      jsonResponse(res, { status: "ok", uptime: process.uptime() })
      return
    }

    // All API routes below share the Host/session-token gate above.
    if (pathOnly === "/api/browser-status" && req.method === "GET") {
      jsonResponse(res, { connected: activeHasExtensionPeer?.() === true })
      return
    }

    if (pathOnly === "/api/send-shortcut" && req.method === "GET") {
      const v = getConfig().summoner?.send_shortcut
      const send_shortcut = v === "Cmd+Enter" || v === "Ctrl+Enter" || v === "Enter" ? v : "Enter"
      jsonResponse(res, { send_shortcut })
      return
    }

    if (pathOnly === "/api/voice-settings" && req.method === "GET") {
      const voice = getConfig().voice
      const localModelId =
        voice?.localModelId === "small" ||
        voice?.localModelId === "medium" ||
        voice?.localModelId === "large-v3-turbo"
          ? voice.localModelId
          : "medium"
      const sttEngine = voice?.sttEngine === "local" ? "local" : "browser"
      jsonResponse(res, { sttEngine, localModelId, lang: "zh-CN" })
      return
    }

    if (pathOnly === "/api/events" && req.method === "GET") {
      if (sseClients.size >= MAX_SSE_CLIENTS) {
        jsonResponse(res, { type: "error", error: "too many listeners" }, 429)
        return
      }
      res.writeHead(200, {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
        "Referrer-Policy": "no-referrer",
        "X-Content-Type-Options": "nosniff",
      })
      res.write(":\n\n")
      // A (re)connect cancels any pending deferred close.
      overlayCloseRequested = false
      clearOverlayShellCloseTimer()
      sseClients.add(res)
      req.on("close", () => {
        sseClients.delete(res)
        if (sseClients.size !== 0) return
        // Defer onShellClosed: EventSource auto-reconnects after transient drops.
        if (overlayLaunchInGrace()) {
          scheduleOnShellClosed(overlayLaunchAt + overlayLaunchGraceMs - Date.now())
          return
        }
        scheduleOnShellClosed(
          overlayCloseRequested ? OVERLAY_CLOSE_AFTER_REQUEST_MS : overlaySseReconnectGraceMs,
        )
      })
      return
    }

    if (pathOnly === "/api/threads" && req.method === "GET") {
      jsonResponse(res, await dispatchAllowed("thread.list", {}))
      return
    }

    if (pathOnly === "/api/threads" && req.method === "POST") {
      jsonResponse(res, await dispatchAllowed("thread.create", {}))
      return
    }

    if (pathOnly === "/api/thread" && req.method === "GET") {
      jsonResponse(res, { type: "error", error: "use POST to select a thread" }, 405)
      return
    }

    if (pathOnly === "/api/thread" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const id = typeof body.thread_id === "string" ? body.thread_id : query.get("id") || ""
      if (!id) {
        jsonResponse(res, { type: "error", error: "id required" }, 400)
        return
      }
      jsonResponse(res, await dispatchAllowed("thread.select", { thread_id: id }))
      return
    }

    if (pathOnly === "/api/thread" && req.method === "PATCH") {
      const id = query.get("id") || ""
      if (!id) {
        jsonResponse(res, { type: "error", error: "id required" }, 400)
        return
      }
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const alias = typeof body.alias === "string" ? body.alias : ""
      jsonResponse(res, await dispatchAllowed("thread.update", { thread_id: id, updates: { alias } }))
      return
    }

    if (pathOnly === "/api/thread" && req.method === "DELETE") {
      const id = query.get("id") || ""
      if (!id) {
        jsonResponse(res, { type: "error", error: "id required" }, 400)
        return
      }
      jsonResponse(res, await dispatchAllowed("thread.delete", { thread_id: id, mode: "trash" }))
      return
    }

    if (pathOnly === "/api/packs" && req.method === "GET") {
      jsonResponse(res, await dispatchAllowed("pack.list", {}))
      return
    }

    if (pathOnly === "/api/mcp" && req.method === "GET") {
      jsonResponse(res, await dispatchAllowed("mcp.list", {}))
      return
    }

    if (pathOnly === "/api/mcp/toggle") {
      jsonResponse(res, { type: "error", error: "mcp toggle is not available on overlay" }, 404)
      return
    }

    if (pathOnly === "/api/skills" && req.method === "GET") {
      jsonResponse(res, await dispatchAllowed("skill.list", {}))
      return
    }

    if (pathOnly === "/api/skills/toggle" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      const skill_name = typeof body.skill_name === "string" ? body.skill_name : ""
      const on = body.on !== false
      if (!thread_id || !skill_name) {
        jsonResponse(res, { type: "error", error: "thread_id and skill_name required" }, 400)
        return
      }
      jsonResponse(
        res,
        await dispatchAllowed(on ? "skill.activate" : "skill.deactivate", { thread_id, skill_name }),
      )
      return
    }

    if (pathOnly === "/api/knowledge" && req.method === "GET") {
      jsonResponse(res, await dispatchAllowed("knowledge.list", {}))
      return
    }

    if (pathOnly === "/api/knowledge/active" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      const ids = Array.isArray(body.ids) ? body.ids : []
      if (!thread_id) {
        jsonResponse(res, { type: "error", error: "thread_id required" }, 400)
        return
      }
      jsonResponse(res, await dispatchAllowed("knowledge.set_active", { thread_id, ids }))
      return
    }

    if (pathOnly === "/api/chat" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      const message = typeof body.message === "string" ? body.message : ""
      if (!thread_id || !message.trim()) {
        jsonResponse(res, { type: "error", error: "thread_id and message required" }, 400)
        return
      }
      const mode = body.mode === "steer" || body.mode === "enqueue" ? body.mode : "create"
      if (mode === "steer") {
        jsonResponse(res, await dispatchAllowed("chat.steer", { thread_id, message }))
        return
      }
      jsonResponse(
        res,
        await dispatchAllowed("chat.create", {
          thread_id,
          message,
          ...(mode === "enqueue" ? { enqueue: true } : {}),
        }),
      )
      return
    }

    if (pathOnly === "/api/files" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, FILE_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      if (!thread_id || !Array.isArray(body.files)) {
        jsonResponse(res, { type: "error", error: "thread_id and files required" }, 400)
        return
      }
      const payload: Record<string, unknown> = { thread_id, files: body.files }
      if (typeof body.message === "string" && body.message.trim()) payload.message = body.message
      jsonResponse(res, await dispatchAllowed("file.upload", payload))
      return
    }

    if (pathOnly === "/api/packs/apply" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const pack_id = typeof body.pack_id === "string" ? body.pack_id : ""
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      if (!pack_id || !thread_id) {
        jsonResponse(res, { type: "error", error: "pack_id and thread_id required" }, 400)
        return
      }
      jsonResponse(
        res,
        await dispatchAllowed("pack.apply", { pack_id, thread_id, user_gesture: true }),
      )
      return
    }

    if (pathOnly === "/api/lease/release" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      if (!thread_id) {
        jsonResponse(res, { type: "error", error: "thread_id required" }, 400)
        return
      }
      const got = (await dispatchAllowed("composer.lease.get", { thread_id })) as {
        rev?: number
      }
      const rev = typeof got?.rev === "number" ? got.rev : 0
      jsonResponse(res, await dispatchAllowed("composer.lease.release", { thread_id, rev }))
      return
    }

    if (pathOnly === "/api/lease" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      if (!thread_id) {
        jsonResponse(res, { type: "error", error: "thread_id required" }, 400)
        return
      }
      const got = (await dispatchAllowed("composer.lease.get", { thread_id })) as {
        rev?: number
      }
      const rev = typeof got?.rev === "number" ? got.rev : 0
      jsonResponse(
        res,
        await dispatchAllowed("composer.lease.claim", {
          thread_id,
          holder: "overlay",
          rev,
        }),
      )
      return
    }

    if (pathOnly === "/api/abort" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX))
      const thread_id = typeof body.thread_id === "string" ? body.thread_id : ""
      if (!thread_id) {
        jsonResponse(res, { type: "error", error: "thread_id required" }, 400)
        return
      }
      jsonResponse(res, await dispatchAllowed("chat.abort", { thread_id }))
      return
    }

    if (pathOnly === "/api/attach" && req.method === "POST") {
      let foreground = false
      try {
        const raw = await readBody(req, JSON_BODY_MAX)
        if (raw.trim()) {
          const parsed = JSON.parse(raw) as { foreground?: unknown }
          foreground = parsed.foreground === true
        }
      } catch {
        foreground = false
      }
      const attach = activeAttachChrome ?? defaultAttachChrome
      const message = attach({ foreground })
      jsonResponse(res, { type: "ok", message })
      return
    }

    if (pathOnly === "/api/operate" && req.method === "POST") {
      const attach = activeAttachChrome ?? defaultAttachChrome
      const message = attach({ foreground: true })
      const fail = () => {
        jsonResponse(
          res,
          { type: "error", error: "请点工具栏 C", error_code: "OPERATE_SIDEPANEL_UNAVAILABLE", attach: message },
          503,
        )
      }
      if (!activeRequestOpenSidePanel || !activeHasExtensionPeer || !activeHasExtensionPeer()) {
        fail()
        return
      }
      try {
        const r = await activeRequestOpenSidePanel()
        if (r && r.error_code) {
          fail()
          return
        }
      } catch {
        fail()
        return
      }
      jsonResponse(res, { type: "ok", message })
      return
    }

    if (pathOnly === "/api/stt/start" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      const cfgModel = getConfig().voice?.localModelId
      const modelId =
        body.modelId === "small" || body.modelId === "medium" || body.modelId === "large-v3-turbo"
          ? body.modelId
          : cfgModel === "small" || cfgModel === "medium" || cfgModel === "large-v3-turbo"
            ? cfgModel
            : "medium"
      const payload: Record<string, unknown> = {
        v: 1,
        sessionId,
        modelId,
        format: "pcm_s16le",
        sampleRate: 16000,
        channels: 1,
        privacy_ack_v2: true,
      }
      if (typeof body.lang === "string" && body.lang.trim()) {
        payload.lang = body.lang.startsWith("zh") ? "zh" : body.lang
      } else {
        payload.lang = "zh"
      }
      if (typeof body.maxMs === "number" && Number.isFinite(body.maxMs)) payload.maxMs = body.maxMs
      const started = await dispatchAllowed("voice.stt.start", payload)
      jsonResponse(res, started)
      if (!overlayDispatchFailed(started) && sessionId) overlaySttSessionId = sessionId
      return
    }

    if (pathOnly === "/api/stt/chunk" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, STT_CHUNK_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      const seq = Number.isInteger(body.seq) ? body.seq : 0
      const data = typeof body.data === "string" ? body.data : ""
      jsonResponse(
        res,
        await dispatchAllowed("voice.stt.chunk", { v: 1, sessionId, seq, data }),
      )
      return
    }

    if (pathOnly === "/api/stt/end" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      const totalSeq = Number.isInteger(body.totalSeq) ? body.totalSeq : 0
      jsonResponse(res, await dispatchAllowed("voice.stt.end", { v: 1, sessionId, totalSeq }))
      if (sessionId && overlaySttSessionId === sessionId) overlaySttSessionId = ""
      return
    }

    if (pathOnly === "/api/stt/abort" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      jsonResponse(res, await dispatchAllowed("voice.stt.abort", { v: 1, sessionId }))
      if (sessionId && overlaySttSessionId === sessionId) overlaySttSessionId = ""
      return
    }

    if (pathOnly === "/api/stt/partial" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const sessionId = typeof body.sessionId === "string" ? body.sessionId : ""
      jsonResponse(
        res,
        await dispatchAllowed("voice.stt.partial_request", { v: 1, sessionId }),
      )
      return
    }

    if (pathOnly === "/api/meeting/start" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const payload: Record<string, unknown> = {
        v: 1,
        privacy_ack_v1: true,
        audio_retained: false,
      }
      if (typeof body.title === "string") payload.title = body.title
      if (typeof body.thread_id === "string") payload.thread_id = body.thread_id
      if (typeof body.id === "string" && body.id.trim()) payload.id = body.id.trim()
      const started = await dispatchAllowed("meeting.start", payload)
      jsonResponse(res, started)
      if (!overlayDispatchFailed(started)) {
        const fallback = typeof payload.id === "string" ? payload.id : ""
        overlayMeetingId = readMeetingIdFromDispatch(started, fallback)
      }
      return
    }

    if (pathOnly === "/api/meeting/end" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const id = typeof body.id === "string" ? body.id : ""
      jsonResponse(res, await dispatchAllowed("meeting.end", { v: 1, id }))
      if (id && overlayMeetingId === id) overlayMeetingId = ""
      return
    }

    if (pathOnly === "/api/meeting/append" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const id = typeof body.id === "string" ? body.id : ""
      const text = typeof body.text === "string" ? body.text : ""
      jsonResponse(
        res,
        await dispatchAllowed("meeting.append_transcript", { v: 1, id, text, source: "stt" }),
      )
      return
    }

    if (pathOnly === "/api/meeting/minutes" && req.method === "POST") {
      const body = JSON.parse(await readBody(req, JSON_BODY_MAX)) as Record<string, unknown>
      const id = typeof body.id === "string" ? body.id : ""
      jsonResponse(res, await dispatchAllowed("meeting.generate_minutes", { v: 1, id }))
      return
    }

    if (pathOnly === "/api/meetings" && req.method === "GET") {
      jsonResponse(res, await dispatchAllowed("meeting.list", { v: 1 }))
      return
    }

    if (pathOnly === "/api/meeting" && req.method === "GET") {
      const raw = req.url || ""
      const qIdx = raw.indexOf("?")
      const query = qIdx >= 0 ? parseQuery(raw.slice(qIdx + 1)) : new Map<string, string>()
      const id = query.get("id") || ""
      jsonResponse(res, await dispatchAllowed("meeting.get", { v: 1, id }))
      return
    }

    res.writeHead(404)
    res.end("Not found")
  } catch (e: any) {
    const status = typeof e?.status === "number" ? e.status : 500
    jsonResponse(res, { type: "error", error: e?.message || String(e) }, status)
  }
}

const SUMMONER_HTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CMspark</title>
<style>
:root{
  --paper:#fff;--canvas:#f7f7f5;--rail-bg:#f7f7f5;--text:#171717;--secondary:#525252;
  --faint:#666666;--line:rgba(23,23,23,.08);--indigo:#4f46e5;--indigo-soft:#eef2ff;
  --radius:20px;--radius-sm:10px;--rail:52px;--list:216px;
  --focus:0 0 0 2px #fff,0 0 0 4px var(--indigo);
  --shadow:0 1px 0 var(--line),0 18px 40px rgba(23,23,23,.10);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;width:100%;overflow:hidden}
body{
  font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei UI","PingFang SC","Noto Sans SC",sans-serif;
  color:var(--text);background:var(--paper);
}
.hud{height:100%;display:flex;flex-direction:column;background:var(--paper);overflow:hidden;position:relative}
.body{display:none;flex:1;min-height:0;border-bottom:1px solid var(--line);overflow:hidden}
.hud.expanded .body{display:flex;flex-direction:column}
.rail{
  background:var(--rail-bg);border-right:1px solid var(--line);
  display:none;flex-direction:column;align-items:center;padding:10px 0;gap:4px;overflow:hidden;flex-shrink:0
}
.rail-btn{
  width:44px;height:44px;border:0;background:transparent;border-radius:var(--radius-sm);
  color:var(--secondary);cursor:pointer;display:grid;place-items:center;
}
.rail-btn svg{width:20px;height:20px;stroke:currentColor;fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.rail-btn:hover{background:var(--canvas);color:var(--text)}
.rail-btn[aria-current="true"]{background:var(--indigo-soft);color:var(--indigo)}
.rail-btn:focus-visible{outline:none;box-shadow:var(--focus)}
.rail-btn[hidden]{display:none}
.list{border-right:1px solid var(--line);display:none;flex-direction:column;min-width:0;background:var(--paper);overflow:hidden}
.rail,.list{display:none}
.list-scroll{overflow-y:auto;overflow-x:hidden;flex:1;padding:0 6px 10px}
.item,.row{
  display:block;width:100%;text-align:left;border:0;background:transparent;border-radius:10px;
  padding:10px;cursor:pointer;min-height:44px;font:inherit;color:var(--text);
}
.item:hover,.row:hover{background:var(--canvas)}
.item.active,.row[aria-current="true"],.item.active{background:var(--indigo-soft);color:var(--indigo)}
.item:focus-visible,.row:focus-visible{outline:none;box-shadow:var(--focus)}
.item.muted,.row.muted{opacity:.45;cursor:not-allowed}
.row strong,.item strong{display:block;font-weight:500;font-size:13px}
.row small,.item small{display:block;margin-top:2px;font-size:11px;color:var(--faint)}
.trow{display:flex;align-items:stretch;gap:2px}
.trow .item{flex:1;min-width:0}
.icon-mini{
  flex:none;width:36px;height:44px;border:0;background:transparent;color:var(--faint);cursor:pointer;
  border-radius:8px;display:grid;place-items:center;
}
.icon-mini svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.icon-mini:hover{background:var(--canvas);color:var(--text)}
.main{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;background:var(--paper);overflow:hidden}
.brand{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:12px 16px 4px;font-size:14px;font-weight:600;flex-shrink:0}
.brand-id{display:flex;align-items:center;gap:8px;min-width:0}
.brand-actions{display:flex;gap:4px;flex:none}
.brand-actions button{
  min-height:36px;padding:6px 10px;border:0;background:var(--canvas);border-radius:8px;
  font:12px inherit;cursor:pointer;color:var(--text);
}
.cruise-chip{
  max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  background:var(--indigo-soft)!important;color:var(--indigo)!important;font-weight:600;
}
.list-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:14px 14px 8px;font-size:11px;font-weight:600;letter-spacing:.06em;color:var(--faint)}
.list-head button{min-height:36px;padding:6px 10px;border:0;background:var(--canvas);border-radius:8px;font:12px inherit;cursor:pointer;color:var(--text);letter-spacing:0;font-weight:500}
.hud.history .list{
  display:flex!important;position:absolute;inset:0;z-index:5;border-right:0;width:auto;background:var(--paper);
}
.meeting-desk{
  position:absolute;inset:0;z-index:7;margin:0;
  display:flex;flex-direction:column;background:var(--paper);color:var(--text);
}
.meeting-desk[hidden]{display:none!important;pointer-events:none!important}
.meeting-head{
  display:flex;align-items:center;justify-content:space-between;gap:8px;
  padding:10px 12px 8px;border-bottom:1px solid var(--line);flex-shrink:0;
}
.meeting-head strong{font-size:14px;font-weight:600}
.meeting-back{
  min-height:32px;padding:4px 10px;border:0;background:transparent;border-radius:8px;
  font:12px inherit;cursor:pointer;color:var(--faint);
}
.meeting-back:hover{background:var(--canvas);color:var(--text)}
.meeting-back:focus-visible{outline:none;box-shadow:var(--focus)}
.meeting-status{
  display:flex;align-items:center;gap:8px;flex-wrap:wrap;
  padding:8px 12px 0;font-size:12px;color:var(--faint);
}
.meeting-dot{width:8px;height:8px;border-radius:50%;background:#d4d4d4;flex:none}
.meeting-desk.recording .meeting-dot{
  background:#dc2626;box-shadow:0 0 0 0 rgba(220,38,38,.4);
  animation:recPulse 1.4s ease-out infinite;
}
@keyframes recPulse{
  0%{box-shadow:0 0 0 0 rgba(220,38,38,.4)}
  70%{box-shadow:0 0 0 8px rgba(220,38,38,0)}
  100%{box-shadow:0 0 0 0 rgba(220,38,38,0)}
}
.meeting-live{
  flex:1;min-height:0;overflow:auto;margin:8px 12px 0;
  padding:10px 12px;background:var(--canvas);border-radius:12px;font-size:13px;line-height:1.5;
}
.meeting-live p{margin:0 0 8px}
.meeting-live .empty-live{
  color:var(--faint);font-size:12.5px;line-height:1.45;padding:22px 8px;text-align:center;
}
.meeting-partial{
  min-height:1.4em;font-size:13px;color:var(--indigo);padding:4px 16px 6px;font-style:italic;
  max-height:4.2em;overflow:auto;
}
.meeting-live .spk{display:inline;font-weight:600;color:var(--indigo);margin-right:4px}
.meeting-tools{
  display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding:4px 12px 0;
}
.meeting-tools button,.meeting-tools select{
  min-height:28px;padding:3px 8px;border-radius:8px;border:0;cursor:pointer;font:11px inherit;
  background:var(--canvas);color:var(--text);
}
.meeting-diarize-hint{font-size:11px;color:var(--faint);line-height:1.4}
.meeting-tools button:focus-visible,.meeting-tools select:focus-visible{outline:none;box-shadow:var(--focus)}
.meeting-hist{
  position:absolute;left:12px;right:12px;top:72px;bottom:72px;z-index:8;
  background:var(--paper);border:1px solid var(--line);border-radius:12px;
  overflow:auto;padding:6px;box-shadow:var(--shadow);
}
.meeting-hist[hidden]{display:none!important}
.meeting-hist button{
  display:block;width:100%;text-align:left;border:0;background:transparent;
  padding:8px 10px;border-radius:8px;cursor:pointer;font:inherit;color:var(--text);
}
.meeting-hist button:hover,.meeting-hist button.active{background:var(--indigo-soft);color:var(--indigo)}
.meeting-hist button small{display:block;margin-top:2px;font-size:11px;color:var(--faint)}
.meeting-hist-empty{padding:18px 10px;text-align:center;color:var(--faint);font-size:12.5px}
.meeting-minutes{
  flex:0 1 36%;min-height:0;overflow:auto;margin:0 12px 8px;
  padding:8px 10px;background:var(--canvas);border-radius:12px;
}
.meeting-minutes[hidden]{display:none!important}
.meeting-actions{
  display:flex;flex-wrap:wrap;gap:8px;padding:8px 12px 12px;
  border-top:1px solid var(--line);
}
.meeting-actions button{
  min-height:36px;padding:6px 12px;border-radius:8px;border:0;cursor:pointer;font:inherit;
  background:var(--canvas);color:var(--text);
}
.meeting-actions button:focus-visible{outline:none;box-shadow:var(--focus)}
.meeting-actions button:disabled{opacity:.45;cursor:not-allowed}
#meetingRec{background:var(--indigo);color:#fff;font-weight:500;flex:1}
.meeting-desk.recording #meetingRec{background:#dc2626;color:#fff}
#meetingMinutesBtn{background:var(--indigo-soft);color:var(--indigo)}
.log{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding:20px 22px;display:flex;flex-direction:column;gap:16px}
.msg{max-width:46rem;font-size:14px;line-height:1.7;word-break:break-word}
.msg.user{align-self:flex-end;background:var(--canvas);padding:8px 12px;border-radius:12px 12px 4px 12px;white-space:pre-wrap}
.msg.assistant{align-self:flex-start;color:var(--text);white-space:normal}
.msg.assistant p{margin:0 0 8px}
.msg.assistant p:last-child{margin:0}
.msg.assistant h1,.msg.assistant h2,.msg.assistant h3{font-size:15px;font-weight:600;margin:10px 0 6px}
.msg.assistant ul,.msg.assistant ol{margin:6px 0 6px 1.2em}
.msg.assistant a{color:var(--indigo)}
.msg.assistant pre{background:var(--canvas);padding:8px 10px;border-radius:8px;overflow:auto;font-size:12.5px;line-height:1.45}
.msg.assistant code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px}
.msg.assistant :not(pre)>code{background:var(--canvas);padding:1px 4px;border-radius:4px}
.msg.assistant blockquote{margin:6px 0;padding:0 0 0 10px;border-left:3px solid var(--line);color:var(--secondary)}
.msg.assistant.streaming{white-space:pre-wrap}
.msg.assistant.streaming::after{content:"▍";color:var(--indigo);animation:streamBlink 1s steps(2) infinite}
@keyframes streamBlink{
  0%,50%{opacity:1}
  51%,100%{opacity:0}
}
.empty{margin:auto;color:var(--secondary);font-size:14px;line-height:1.6;text-align:center;display:flex;flex-direction:column;align-items:center}
.empty strong{display:block;font-size:22px;font-weight:600;color:var(--text);margin-bottom:8px;letter-spacing:-.03em}
.composer{display:flex;flex-direction:column;gap:6px;padding:10px 12px 8px;background:var(--paper);flex-shrink:0;position:relative;z-index:2}
.composer-row{display:flex;align-items:center;gap:6px;min-width:0}
.icon-btn{
  width:44px;height:44px;border:0;background:transparent;border-radius:var(--radius-sm);
  cursor:pointer;color:var(--text);display:grid;place-items:center;flex:none;
}
.icon-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.icon-btn:hover{background:var(--canvas)}
.icon-btn:focus-visible{outline:none;box-shadow:var(--focus)}
.icon-btn:disabled{opacity:.35;cursor:not-allowed}
.field{
  flex:1;display:flex;align-items:flex-end;gap:4px;min-height:48px;padding:4px 8px 4px 14px;
  background:var(--paper);border:1px solid var(--line);border-radius:20px;min-width:0;overflow:hidden;
}
.field:focus-within{box-shadow:inset 0 0 0 1.5px rgba(79,70,229,.45);background:var(--paper)}
.field textarea{
  flex:1;min-width:0;width:100%;border:0;background:transparent;outline:none;resize:none;min-height:36px;max-height:120px;
  font:15px/1.35 inherit;color:var(--text);padding:8px 0;
}
.field .icon-btn{position:relative;z-index:1}
.field textarea::placeholder{color:var(--faint)}
.ghosts{display:flex;gap:4px;padding:0 12px 4px}
.ghost{
  border:0;background:transparent;color:var(--faint);font:11px inherit;padding:6px 8px;border-radius:8px;cursor:pointer;min-height:32px;
}
.ghost:hover{background:var(--canvas);color:var(--text)}
.hint{display:none;padding:0 16px 10px;font-size:11px;color:var(--faint);line-height:1.4}
#chev{display:none}
#settings{display:none}
#newThreadBar{display:none}
.status:empty{display:none}
.status{margin:0 12px 8px;padding:8px 10px;font-size:12px;color:#92400e;background:#fffbeb;border-radius:8px}
.cta-box{
  margin:0 12px 8px;padding:10px 12px;border-radius:12px;
  background:#fffbeb;border:1px solid #fde68a;color:#92400e;
}
.cta-box[hidden]{display:none}
.cta-box p{font-size:12.5px;line-height:1.45}
.cta-actions{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}
.cta-actions button{
  min-height:36px;padding:6px 12px;border-radius:8px;border:0;cursor:pointer;font:inherit;
}
#attachSilent{background:var(--indigo);color:#fff}
#attachFront{background:var(--canvas);color:var(--text)}
#openConfirm{background:var(--indigo);color:#fff}
.cta-foot{font-size:11px;color:var(--faint)!important;line-height:1.4}
.privacy-sheet{
  position:absolute;inset:0;z-index:6;margin:0;padding:16px 18px 20px;
  overflow:auto;border-radius:0;
  background:#fffbeb;border:0;color:#92400e;
}
.privacy-sheet[hidden],.cta-box[hidden]{display:none!important;pointer-events:none!important}
.privacy-sheet[hidden]{display:none}
.privacy-sheet ol{margin:6px 0 8px;padding-left:1.3em;color:var(--text);font-size:12px;line-height:1.45}
.privacy-sheet .cta-actions button{background:var(--indigo);color:#fff}
.privacy-sheet p{font-size:12.5px;font-weight:600;color:var(--text)}
#meetingVoiceSection{margin-bottom:8px}
.capture-row{display:flex;gap:8px;padding:0 2px;flex-wrap:wrap;position:relative;z-index:1}
#meetingStart,#operateOpen{
  min-height:36px;padding:6px 12px;border-radius:8px;border:0;cursor:pointer;font:inherit;
  background:var(--canvas);color:var(--text);
}
#meetingStart[aria-pressed="true"]{background:var(--indigo-soft);color:var(--indigo)}
#mic[aria-pressed="true"]{background:var(--indigo-soft);color:var(--indigo)}
.hud:not(.expanded) .ghosts{display:none}
.hud.expanded .ghosts{display:none}
.hud.expanded .hint{display:none}

/* #469 shared workspace craft; transport and capture ACL are unchanged. */
button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid var(--indigo);outline-offset:2px}
@media(min-width:760px){.log,.composer{width:100%;max-width:780px;margin-left:auto;margin-right:auto}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}

/* #471: same conversation hierarchy as the extension workspace. */
.brand{padding:12px 16px;border-bottom:1px solid var(--line);font-size:13px}
.brand-actions button{background:transparent}.brand-actions button:hover{background:var(--canvas)}
.cruise-chip{max-width:104px;font-weight:400;background:var(--canvas)!important;color:var(--secondary)!important}
.empty{max-width:360px;padding:24px 12px;gap:4px}.empty strong{font-size:22px;font-weight:500;letter-spacing:-.03em}
.msg.user{background:#f3f3f1;border:1px solid var(--line);border-radius:14px;padding:12px 16px}
.msg.assistant{padding:8px 0;line-height:1.75}
.log{gap:24px;padding:24px 20px}
.composer{padding:12px 16px 8px}.composer-row{width:100%}
.field{width:100%;display:flex;flex-direction:column;align-items:stretch;gap:6px;padding:10px 12px;border-radius:20px;box-shadow:0 1px 2px rgba(0,0,0,.03)}
.field textarea{box-sizing:border-box;flex:none;font-family:inherit;font-size:14px;line-height:1.6;padding:2px;min-height:42px}
.field:focus-within{box-shadow:0 0 0 2px rgba(79,70,229,.12);border-color:var(--indigo)}
.composer-actions{display:flex;align-items:center;gap:6px}.composer-actions .icon-btn{width:36px;height:36px;color:var(--secondary)}
#mic{margin-left:auto}#sendGo{border-radius:50%;background:#242424;color:#fff}
.capture-row{padding:0 16px 12px;gap:8px}.capture-row button{background:transparent;border:1px solid var(--line);font-size:12px;color:var(--secondary)}
@media(max-width:380px){.brand{flex-wrap:wrap;gap:4px;padding:10px 12px}.brand-actions{margin-left:auto}.brand-actions button{padding:6px}.log{padding:16px}.composer{padding:8px 12px}.empty strong{font-size:20px}}

/* #477: a readable workspace; existing overlay privileges remain unchanged. */
#stopGo[hidden]{display:none}.thread-search{display:block;padding:8px 10px;font-size:12px;color:var(--secondary)}
.thread-search[hidden]{display:none}.thread-search input{display:block;width:100%;margin-top:6px;padding:8px 10px;border:1px solid var(--line);border-radius:8px;font:inherit;background:var(--paper);color:var(--text)}
.resource-note{padding:10px;font-size:12px;line-height:1.6;color:var(--secondary)}
.resource-readonly{cursor:default}.resource-readonly:hover{background:transparent}
.rail{display:flex;align-items:stretch;gap:2px;padding:12px 8px;border:0;overflow:auto}
.rail-btn{display:flex;align-items:center;gap:10px;width:100%;height:36px;padding:0 10px;font:inherit;text-align:left;border-radius:8px}
.rail-btn svg{width:18px;height:18px;flex:none}.rail-btn[aria-current="true"]{background:#eaeae7;color:var(--text)}
.hud.expanded .body{flex-direction:row;border-bottom:0}
.list{display:flex;width:220px;flex:none;background:var(--rail-bg)}
.hud.history .list{position:static;inset:auto;width:220px;border-right:1px solid var(--line)}
.list-head{font-size:12px;letter-spacing:0;color:var(--secondary)}
.item.active{background:#eaeae7;color:var(--text)}.item strong{overflow-wrap:anywhere}.trow{flex-wrap:wrap}.trow .item{flex-basis:100%}.trow .icon-mini{height:28px}
#historyClose{display:none}.log{padding:32px 28px}.empty{margin:auto;max-width:440px;line-height:1.8;color:var(--secondary)}
.empty strong{font-size:28px;color:var(--text);margin-bottom:8px}
@media(min-width:760px){.composer,.capture-row,.status,.cta-box{margin-left:220px;max-width:none;width:calc(100% - 220px)}.composer{padding-left:max(24px,calc((100vw - 1000px)/2));padding-right:max(24px,calc((100vw - 1000px)/2))}.cta-box,.status{width:calc(100% - 244px)}#historyOpen{display:none}}
@media(max-width:759px){.brand{flex-wrap:wrap}.brand-actions{flex-wrap:wrap;min-width:0}.hud.expanded .body{flex-direction:column}.list{display:none}.hud.history .list{display:flex;width:100%;max-height:36vh;min-height:0;border-right:0;border-bottom:1px solid var(--line)}.rail{flex-direction:row;flex-wrap:wrap;flex-shrink:0;padding:6px}.rail-btn{width:auto;height:32px;padding:0 8px;font-size:12px}.rail-btn svg{display:none}.list-head{padding:4px 12px}.list-scroll{min-height:0}#historyClose{display:block}.log{padding:20px}.empty strong{font-size:22px}}
@media(max-height:560px){.hud.history .list{max-height:28vh}.log{padding:12px}.empty{padding:8px}.empty strong{font-size:20px}.capture-row{padding-bottom:6px}.composer{padding-top:6px}}

</style>
</head>
<body>
<div class="hud expanded" id="hud">
  <div class="body">
    <aside class="list" aria-label="工作空间导航">
    <nav class="rail" id="secs" aria-label="工作空间">
      <button class="rail-btn" data-sec="threads" aria-current="true" type="button" title="对话" aria-label="对话">
        <svg viewBox="0 0 24 24"><path d="M5 7h14M5 12h10M5 17h7"/></svg><span>对话</span>
      </button>
      <button class="rail-btn" data-sec="packs" type="button" title="场景" aria-label="场景">
        <svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7" rx="1.4"/><rect x="13" y="4" width="7" height="7" rx="1.4"/><rect x="4" y="13" width="7" height="7" rx="1.4"/><rect x="13" y="13" width="7" height="7" rx="1.4"/></svg><span>场景</span>
      </button>
      <button class="rail-btn" data-sec="knowledge" type="button" title="知识" aria-label="知识">
        <svg viewBox="0 0 24 24"><path d="M5 5.5h9.2A2.3 2.3 0 0 1 16.5 7.8V19H7.4A2.4 2.4 0 0 1 5 16.6V5.5z"/><path d="M16.5 8h1.4A2.1 2.1 0 0 1 20 10.1V19h-3.5"/></svg><span>知识</span>
      </button>
      <button class="rail-btn" data-sec="skills" type="button" title="技能" aria-label="技能">
        <svg viewBox="0 0 24 24"><path d="M8 15.2 4.8 12 8 8.8M16 8.8 19.2 12 16 15.2M13.1 6.8 10.9 17.2"/></svg><span>技能</span>
      </button>
      <button class="rail-btn" data-sec="mcp" type="button" title="MCP" aria-label="MCP">
        <svg viewBox="0 0 24 24"><rect x="8" y="8" width="8" height="8" rx="1.2"/><path d="M12 4.6v3.2M12 16.2v3.2M4.6 12H8M16 12h3.4"/></svg><span>MCP</span>
      </button>
      <button class="rail-btn" data-sec="browser" type="button"><span>浏览器</span></button>
    </nav>

      <div class="list-head"><span id="secHead">历史会话</span><button type="button" id="historyClose">完成</button></div>
      <div class="list-scroll">
        <button class="item" id="newThread" type="button"><strong>新对话</strong><small>快捷提问</small></button>
        <label class="thread-search" id="threadSearchLabel">搜索对话<input id="threadSearch" type="search" placeholder="标题或名称" autocomplete="off"></label>
        <div id="threads"></div>
        <div id="composeList"></div>
      </div>
    </aside>
    <section class="main">
      <div class="brand">
        <span class="brand-id" id="workspaceTitle">CMspark</span>
        <span class="brand-actions">
          <button type="button" id="cruiseChip" class="cruise-chip" title="点此打开侧栏调整档位">%%CRUISE_LABEL%%</button>
          <button type="button" id="windowMode">紧凑窗口</button>
          <button type="button" id="historyOpen" aria-expanded="false">导航</button>
          <button type="button" id="newChat">新对话</button>
        </span>
      </div>
      <div class="log" id="log">
        <div class="empty" id="empty">
          <strong>${CHAT_SHELL_TITLE_NONE}</strong>
          回车发送。附件和听写不用开浏览器。
        </div>
      </div>
    </section>
  </div>
  <!-- Retained handler targets, excluded from the composer and accessibility tree. -->
  <div hidden>
      <button class="icon-btn" id="newThreadBar" type="button" title="新对话" aria-label="新对话">
        <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
      </button>
        <button class="icon-btn" id="chev" type="button" hidden aria-pressed="true" title="${SUMMONER_CHEVRON_COLLAPSE}" aria-label="${SUMMONER_CHEVRON_COLLAPSE}">
          <svg viewBox="0 0 24 24"><path d="M6 14l6-6 6 6"/></svg>
        </button>
        <button class="icon-btn" id="settings" type="button" hidden title="设置（快捷键等）" aria-label="设置">
          <svg viewBox="0 0 24 24"><path d="M12.2 2.2a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V3a.8.8 0 0 1 .8-.8zm0 16a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V19a.8.8 0 0 1 .8-.8zM19.1 7.4a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1l-2.6 2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zM4.9 16.6a.8.8 0 0 1 0-1.1l2.6-2.6a.8.8 0 0 1 1.1 0 .8.8 0 0 1 0 1.1L7.1 15.5l1.5 1.5a.8.8 0 0 1 0 1.1l-1.9 1.9a.8.8 0 0 1-1.1 0zm0-9.2a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1L7.3 13l2.6 2.6a.8.8 0 0 1-1.1 0l-1.9-1.9a.8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zm14.2 9.2a.8.8 0 0 1 0-1.1l-2.6-2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0 1.1l1.5 1.5-1.5 1.5a.8.8 0 0 1 0 1.1l1.9 1.9a.8.8 0 0 1 1.1 0z"/></svg>
        </button>
  </div>
  <div class="composer">
    <div class="composer-row">
      <input type="file" id="files" multiple hidden>
      <div class="field">
        <textarea id="text" rows="1" placeholder="问 CMspark…" aria-label="发送到当前对话"></textarea>
        <div class="composer-actions">
      <button type="button" class="icon-btn" id="attachFile" title="📎 添加附件" aria-label="添加附件">
        <svg viewBox="0 0 24 24"><path d="M8.2 12.8 14 7a2.8 2.8 0 0 1 4 4l-7.4 7.4a4 4 0 0 1-5.7-5.7l7.1-7.1"/></svg>
      </button>
        <button class="icon-btn" id="mic" type="button" title="听写" aria-label="听写" aria-pressed="false">
          <svg viewBox="0 0 24 24"><rect x="9" y="4" width="6" height="10" rx="3"/><path d="M6.5 11a5.5 5.5 0 0 0 11 0M12 16.5V20"/></svg>
        </button>
        <button class="icon-btn" id="stopGo" type="button" hidden title="停止" aria-label="停止"><svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2"/></svg></button>
        <button class="icon-btn" id="sendGo" type="button" title="发送" aria-label="发送">
          <svg viewBox="0 0 24 24"><path d="M5 12h12M13 6l6 6-6 6"/></svg>
        </button>
        </div>
      </div>
    </div>
    <div class="capture-row">
      <button type="button" id="meetingStart" aria-pressed="false">开始会议</button>
      <button type="button" id="operateOpen">打开浏览器并打开侧栏</button>
    </div>
    <div class="cta-box" id="ctaBox" hidden>
      <p id="ctaCopy">${SUMMONER_L0_CHROME_DOWN}</p>
      <div class="cta-actions">
        <button type="button" id="attachSilent" title="${SUMMONER_ATTACH_PRIMARY}" aria-label="${SUMMONER_ATTACH_PRIMARY}">${SUMMONER_ATTACH_PRIMARY}</button>
        <button type="button" id="attachFront" title="${SUMMONER_ATTACH_SECONDARY}" aria-label="${SUMMONER_ATTACH_SECONDARY}">${SUMMONER_ATTACH_SECONDARY}</button>
        <button type="button" id="openConfirm" hidden title="${SUMMONER_OPEN_CONFIRM}" aria-label="${SUMMONER_OPEN_CONFIRM}">${SUMMONER_OPEN_CONFIRM}</button>
      </div>
      <p class="cta-foot">${SUMMONER_ATTACH_FOOTNOTE}</p>
    </div>
    <div class="privacy-sheet" id="voicePrivacy" hidden>
      <p>本机听写</p>
      <ol>
        ${VOICE_PRIVACY_ACK_V2_CLAUSES.map((c) => `<li>${escHtml(c)}</li>`).join("\n        ")}
      </ol>
      <div class="cta-actions">
        <button type="button" id="voicePrivacyAck">我已了解</button>
      </div>
    </div>
    <div class="privacy-sheet" id="meetingPrivacy" hidden>
      <div id="meetingVoiceSection">
        <p>本机听写</p>
        <ol>
          ${VOICE_PRIVACY_ACK_V2_CLAUSES.map((c) => `<li>${escHtml(c)}</li>`).join("\n          ")}
        </ol>
      </div>
      <p>会议隐私说明</p>
      <ol>
        ${MEETING_PRIVACY_ACK_V1_CLAUSES.map((c) => `<li>${escHtml(c)}</li>`).join("\n        ")}
      </ol>
      <div class="cta-actions">
        <button type="button" id="meetingPrivacyAck">我已了解</button>
      </div>
    </div>
  </div>
  <div class="ghosts">
    <button class="ghost" id="send" type="button">发送</button>
    <button class="ghost" id="steer" type="button">纠偏</button>
    <button class="ghost" id="queue" type="button">排队</button>
    <button class="ghost" id="stop" type="button">停止</button>
  </div>
  <div class="hint" id="hint">回车发送 · Shift+Enter 排队 · 点击右上角 ⋮ 设置快捷键</div>
  <div class="status" id="status"></div>
  <div class="meeting-desk" id="meetingDesk" hidden>
    <div class="meeting-head">
      <strong>会议</strong>
      <button type="button" class="meeting-back" id="meetingBack">返回对话</button>
    </div>
    <div class="meeting-status">
      <span class="meeting-dot" aria-hidden="true"></span>
      <span id="meetingHint">未录制</span>
      <span id="meetingVoiceMeta"></span>
    </div>
    <div class="meeting-tools">
      <button type="button" id="meetingHistToggle" aria-pressed="false">历史会议</button>
      <span class="meeting-diarize-hint">说话人标注请在侧栏会议面板使用</span>
    </div>
    <div class="meeting-hist" id="meetingHistList" hidden></div>
    <div class="meeting-live" id="meetingLive">
      <div class="empty-live" id="meetingEmpty">点「开始录制」后约 8 秒出字。语音识别用侧栏听写设置。说话人是匿名「发言人N」，不是认人。</div>
    </div>
    <div class="meeting-partial" id="meetingPartial"></div>
    <div class="meeting-minutes" id="meetingMinutes" hidden></div>
    <div class="meeting-actions">
      <button type="button" id="meetingRec" aria-pressed="false">开始录制</button>
      <button type="button" id="meetingMinutesBtn" hidden>生成会议纪要</button>
    </div>
  </div>
</div>
<script>
try{
(function(){
  var wanted=(location.search.match(/[?&]thread=([^&]+)/)||[])[1]||"";
  try{if(wanted) wanted=decodeURIComponent(wanted)}catch(e){}
  function url(path){return path}
  var threadId="";
  var threadReady=null;
  var sendShortcut="Enter";
  api("/api/send-shortcut").then(function(d){
    var s=d&&d.send_shortcut;
    if(s==="Enter"||s==="Cmd+Enter"||s==="Ctrl+Enter") sendShortcut=s;
  }).catch(function(){});
  var voiceSettings={sttEngine:"browser",localModelId:"medium",lang:"zh-CN"};
  function paintMeetingVoiceMeta(){
    var el=$("meetingVoiceMeta");
    if(!el) return;
    var engine=voiceSettings.sttEngine==="local"?"本机":"浏览器";
    el.textContent=engine+" · "+voiceSettings.localModelId;
  }
  function loadVoiceSettings(){
    return api("/api/voice-settings").then(function(d){
      if(!d||typeof d!=="object") return;
      if(d.sttEngine==="browser"||d.sttEngine==="local") voiceSettings.sttEngine=d.sttEngine;
      if(d.localModelId==="small"||d.localModelId==="medium"||d.localModelId==="large-v3-turbo") voiceSettings.localModelId=d.localModelId;
      if(typeof d.lang==="string"&&d.lang) voiceSettings.lang=d.lang;
      paintMeetingVoiceMeta();
    }).catch(function(){});
  }
  loadVoiceSettings();
  var busy=false;
  var threads=[];
  var poll=null;
  var streamMsg=null;
  function $(id){return document.getElementById(id)}
  function setStatus(t){$("status").textContent=t||""}
  var CHROME_DOWN={
    l0:${JSON.stringify(SUMMONER_L0_CHROME_DOWN)},
    cdp:${JSON.stringify(SUMMONER_CDP_NEEDED)},
    renter:${JSON.stringify(SUMMONER_RENTER_CHROME_DOWN)}
  };
  function showChromeCta(kind){
    var box=$("ctaBox"); if(!box) return;
    box.hidden=false;
    $("ctaCopy").textContent=kind==="renter"?CHROME_DOWN.renter:kind==="cdp"?CHROME_DOWN.cdp:CHROME_DOWN.l0;
    $("attachSilent").hidden=false;
    $("attachFront").hidden=false;
    $("openConfirm").hidden=true;
  }
  function showConfirmCta(){
    showHistory(false);
    var box=$("ctaBox"); if(!box) return;
    box.hidden=false;
    $("ctaCopy").textContent=${JSON.stringify(SUMMONER_CONFIRM_NEED)};
    $("attachSilent").hidden=true;
    $("attachFront").hidden=true;
    $("openConfirm").hidden=false;
  }
  function hideChromeCta(){ var box=$("ctaBox"); if(box) box.hidden=true; }
  function attachChrome(foreground){
    api("/api/attach",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({foreground:!!foreground})}).then(function(d){
      setStatus(d&&(d.message||d.error)||"");
    });
  }
  function esc(s){return String(s).replace(/[&<>]/g,function(c){return c==="&"?"&amp;":c==="<"?"&lt;":"&gt;"})}
  ${OVERLAY_RENDER_MD_JS}
  function placeWindow(compact){
    var w=${OVERLAY_WINDOW_SIZE.w},h=${OVERLAY_WINDOW_SIZE.h};
    if(compact){w=360;h=420}
    var sw=screen.availWidth||screen.width||w;
    var sh=screen.availHeight||screen.height||h;
    w=Math.min(w,sw);h=Math.min(h,sh);
    var x=Math.max(0, ((sw-w)/2)|0);
    var y=Math.max(0, ((sh-h)/2)|0);
    try{window.resizeTo(w,h);window.moveTo(x,y)}catch(e){}
  }
  function setExpanded(on){
    $("hud").classList.add("expanded");
  }
  function api(path, opts){
    return fetch(url(path), opts).then(function(r){return r.json().catch(function(){return {error:r.statusText}})})
  }
  var voiceAck=false;
  var meetingAck=false;
  var meetingId="";
  var lastMeetingId="";
  var sttLive=false;
  var sttSid="";
  var sttSeq=0;
  var sttBuf=new Uint8Array(0);
  var sttFloat=new Float32Array(0);
  var sttStream=null;
  var sttCtx=null;
  var sttSrc=null;
  var sttProc=null;
  var sttMute=null;
  var sttTimer=null;
  var sttPartialTimer=null;
  var sttFeatsBySid={};
  var meetingFeats=[];
  var meetingLines=[];
  var STT_RATE=16000;
  var STT_FLUSH=32000;
  var STT_CHUNK=256*1024;
  var STT_DICTATION_MS=45000;
  var STT_MEETING_MS=8000;
  var STT_MIC_FAIL="请在系统设置中打开 127.0.0.1 的麦克风";
  var STT_NEED_MODEL="侧栏 ⋯ → 设置 → 听写 → 下载组件/模型";
  function sttUserCopy(code, fallback){
    var c=String(code||"").toLowerCase();
    if(c.indexOf("model")>=0 || c.indexOf("binary")>=0 || c.indexOf("engine")>=0) return STT_NEED_MODEL;
    return fallback || "听写失败";
  }
  function uint8ToB64(u8){
    var binary="";
    var step=0x8000;
    for(var i=0;i<u8.length;i+=step){
      binary+=String.fromCharCode.apply(null, Array.prototype.slice.call(u8.subarray(i, Math.min(i+step, u8.length))));
    }
    return btoa(binary);
  }
  function concatU8(a,b){
    var o=new Uint8Array(a.length+b.length);
    o.set(a,0); o.set(b,a.length); return o;
  }
  function concatF32(a,b){
    var o=new Float32Array(a.length+b.length);
    o.set(a,0); o.set(b,a.length); return o;
  }
  function extractFeat(samples){
    var n=samples.length;
    if(!n) return [0,0,0];
    var energy=0,zc=0,prev=samples[0]||0,diffSum=0;
    for(var i=0;i<n;i++){
      var x=samples[i]||0;
      energy+=x*x;
      if(i>0){
        if((prev>=0&&x<0)||(prev<0&&x>=0)) zc++;
        diffSum+=Math.abs(x-prev);
      }
      prev=x;
    }
    return [Math.log1p(energy/n), zc/n, Math.min(1, diffSum/(n*0.5+1e-9))];
  }
  function floatToS16(input){
    var out=new Uint8Array(input.length*2);
    var view=new DataView(out.buffer);
    for(var i=0;i<input.length;i++){
      var s=input[i];
      if(s>1)s=1; else if(s<-1)s=-1;
      view.setInt16(i*2, s<0?Math.round(s*0x8000):Math.round(s*0x7fff), true);
    }
    return out;
  }
  function resampleMono(input, fromRate, toRate){
    if(fromRate===toRate || !input.length) return input;
    var outLen=Math.max(1, Math.round((input.length*toRate)/fromRate));
    var out=new Float32Array(outLen);
    var ratio=fromRate/toRate;
    for(var i=0;i<outLen;i++){
      var src=i*ratio;
      var i0=Math.floor(src);
      var i1=Math.min(i0+1, input.length-1);
      var t=src-i0;
      out[i]=input[i0]*(1-t)+input[i1]*t;
    }
    return out;
  }
  function teardownStt(){
    sttLive=false;
    if(sttTimer){clearTimeout(sttTimer);sttTimer=null}
    if(sttPartialTimer){clearTimeout(sttPartialTimer);sttPartialTimer=null}
    try{ if(sttProc){sttProc.onaudioprocess=null;sttProc.disconnect()} }catch(e){}
    try{ if(sttMute) sttMute.disconnect(); }catch(e){}
    try{ if(sttSrc) sttSrc.disconnect(); }catch(e){}
    try{ if(sttStream) sttStream.getTracks().forEach(function(t){t.stop()}); }catch(e){}
    try{ if(sttCtx) sttCtx.close(); }catch(e){}
    sttProc=sttMute=sttSrc=sttStream=sttCtx=null;
    sttBuf=new Uint8Array(0);
    sttFloat=new Float32Array(0);
    var mic=$("mic");
    if(mic) mic.setAttribute("aria-pressed","false");
  }
  function flushStt(force){
    if(!sttSid) return;
    var min=force?1:STT_FLUSH;
    while(sttBuf.length>=min){
      var n=Math.min(STT_CHUNK, sttBuf.length);
      if(!force && n<STT_FLUSH) break;
      var slice=sttBuf.subarray(0,n);
      api("/api/stt/chunk",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:sttSid,seq:sttSeq,data:uint8ToB64(slice)})});
      sttSeq+=1;
      sttBuf=n===sttBuf.length?new Uint8Array(0):new Uint8Array(sttBuf.subarray(n));
    }
  }
  function stopStt(abort){
    var sid=sttSid;
    if(abort){
      teardownStt();
      sttSid="";
      sttSeq=0;
      if(sid) api("/api/stt/abort",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:sid})});
      return;
    }
    flushStt(true);
    if(sid) sttFeatsBySid[sid]=extractFeat(sttFloat);
    var total=sttSeq;
    teardownStt();
    sttSid="";
    sttSeq=0;
    if(sid) api("/api/stt/end",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:sid,totalSeq:total})});
  }
  function beginPcm(sid, stream){
    var AC=window.AudioContext||window.webkitAudioContext;
    if(!AC){ setStatus(STT_MIC_FAIL); stopStt(true); return; }
    var ctx=new AC();
    sttCtx=ctx;
    var go=function(){
      if(!sttLive || sttSid!==sid){ teardownStt(); return; }
      if(typeof ctx.createScriptProcessor!=="function"){ setStatus("无法捕获麦克风音频"); stopStt(true); return; }
      var src=ctx.createMediaStreamSource(stream);
      sttSrc=src;
      var proc=ctx.createScriptProcessor(4096,1,1);
      sttProc=proc;
      var mute=ctx.createGain();
      mute.gain.value=0;
      sttMute=mute;
      proc.onaudioprocess=function(ev){
        if(!sttLive || sttSid!==sid) return;
        var ch=ev.inputBuffer.getChannelData(0);
        if(!ch||!ch.length) return;
        var copy=new Float32Array(ch.length);
        copy.set(ch);
        var rate=ctx.sampleRate||48000;
        var mono=rate===STT_RATE?copy:resampleMono(copy,rate,STT_RATE);
        if(!mono.length) return;
        sttFloat=concatF32(sttFloat, mono);
        sttBuf=concatU8(sttBuf, floatToS16(mono));
        if(sttBuf.length>=STT_FLUSH) flushStt(false);
      };
      src.connect(proc);
      proc.connect(mute);
      mute.connect(ctx.destination);
      var windowMs=meetingId?STT_MEETING_MS:STT_DICTATION_MS;
      sttTimer=setTimeout(function(){
        if(!sttLive || sttSid!==sid) return;
        stopStt(false);
      }, windowMs);
      if(meetingId){
        var poll=function(){
          if(!sttLive || sttSid!==sid) return;
          api("/api/stt/partial",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:sid})});
          sttPartialTimer=setTimeout(poll,1400);
        };
        sttPartialTimer=setTimeout(poll,1400);
      }
    };
    if(ctx.state==="suspended") ctx.resume().then(go).catch(go);
    else go();
  }
  function startStt(){
    if(sttLive){ stopStt(false); return; }
    if(!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia!=="function"){
      setStatus(STT_MIC_FAIL);
      return;
    }
    var sid="ov-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10);
    sttSid=sid;
    sttSeq=0;
    sttBuf=new Uint8Array(0);
    sttFloat=new Float32Array(0);
    sttLive=true;
    $("mic").setAttribute("aria-pressed","true");
    navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}}).then(function(stream){
      if(!sttLive || sttSid!==sid){ stream.getTracks().forEach(function(t){t.stop()}); return; }
      sttStream=stream;
      var sttLang=(voiceSettings.lang||"zh-CN").indexOf("zh")===0?"zh":(voiceSettings.lang||"zh");
      var sttModel=voiceSettings.localModelId||"medium";
      var sttMax=meetingId?STT_MEETING_MS:STT_DICTATION_MS;
      return api("/api/stt/start",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:sid,modelId:sttModel,privacy_ack_v2:true,lang:sttLang,maxMs:sttMax})}).then(function(d){
        if(!sttLive || sttSid!==sid){ teardownStt(); return; }
        if(d && (d.type==="voice.stt.error" || d.type==="error" || d.error)){
          setStatus(sttUserCopy(d.code||d.error_code, d.error||d.message));
          stopStt(true);
          return;
        }
        beginPcm(sid, stream);
      });
    }).catch(function(){
      sttLive=false;
      sttSid="";
      $("mic").setAttribute("aria-pressed","false");
      setStatus(STT_MIC_FAIL);
    });
  }
  function renderThreads(filter){
    var q=(filter===undefined?$("threadSearch").value:filter||"").trim().toLocaleLowerCase();
    var box=$("threads");
    box.innerHTML="";
    threads.forEach(function(t){
      var title=(t.title||t.alias||t.id||"").trim()||t.id;
      if(q && title.toLocaleLowerCase().indexOf(q)<0 && String(t.alias||"").toLocaleLowerCase().indexOf(q)<0) return;
      var row=document.createElement("div");
      row.className="trow";
      var b=document.createElement("button");
      b.className="item"+(t.id===threadId?" active":"");
      b.innerHTML="<strong>"+esc(title)+"</strong>";
      b.onclick=function(){selectThread(t.id)};
      var rn=document.createElement("button");
      rn.className="icon-mini";
      rn.title="重命名";
      rn.setAttribute("aria-label","重命名");
      rn.innerHTML='<svg viewBox="0 0 24 24"><path d="M4 20h4l11-11-4-4L4 16v4z"/></svg>';
      rn.onclick=function(ev){
        ev.stopPropagation();
        var alias=window.prompt("重命名", title);
        if(!alias||!String(alias).trim()) return;
        api("/api/thread?id="+encodeURIComponent(t.id),{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({alias:String(alias).trim()})}).then(function(d){
          if(d&&(d.error||d.type==="error")){setStatus(d.error||"无法重命名");return}
          return refresh();
        });
      };
      var tr=document.createElement("button");
      tr.className="icon-mini";
      tr.title="移到回收站";
      tr.setAttribute("aria-label","移到回收站");
      tr.innerHTML='<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M8 7l1 12h6l1-12"/></svg>';
      tr.onclick=function(ev){
        ev.stopPropagation();
        if(!window.confirm("把「"+title+"」移到回收站？")) return;
        api("/api/thread?id="+encodeURIComponent(t.id),{method:"DELETE"}).then(function(d){
          if(d&&(d.error||d.type==="error")){setStatus(d.error||"无法移到回收站");return}
          var gone=threadId===t.id;
          return refresh().then(function(){
            if(!gone) return;
            if(threads[0]) return selectThread(threads[0].id);
            $("newThread").click();
          });
        });
      };
      row.appendChild(b);
      row.appendChild(rn);
      row.appendChild(tr);
      box.appendChild(row);
    });
  }
  function clearStreamMsg(){
    if(streamMsg&&streamMsg.parentNode) streamMsg.parentNode.removeChild(streamMsg);
    streamMsg=null;
  }
  function showStreamMsg(text){
    var log=$("log");
    if(!streamMsg||!streamMsg.parentNode){
      var empty=$("empty");
      if(empty&&empty.parentNode) empty.parentNode.removeChild(empty);
      streamMsg=document.createElement("div");
      streamMsg.className="msg assistant streaming";
      log.appendChild(streamMsg);
    }
    streamMsg.textContent=text;
    log.scrollTop=log.scrollHeight;
  }
  function renderMsgs(messages){
    var log=$("log");
    log.innerHTML="";
    streamMsg=null;
    var n=0;
    (messages||[]).forEach(function(m){
      if(!m||(m.role!=="user"&&m.role!=="assistant")) return;
      n++;
      var d=document.createElement("div");
      d.className="msg "+m.role;
      var text=typeof m.content==="string"?m.content:(m.content&&m.content[0]&&m.content[0].text)||"";
      if(m.role==="assistant") d.innerHTML=renderMd(text);
      else d.textContent=text;
      log.appendChild(d);
    });
    if(!n){
      var empty=document.createElement("div");
      empty.className="empty";
      empty.id="empty";
      empty.innerHTML="<strong>${CHAT_SHELL_TITLE_NONE}</strong>回车发送。附件和听写不用开浏览器。";
      log.appendChild(empty);
    }
    log.scrollTop=log.scrollHeight;
  }
  function syncBusyUi(){
    $("stopGo").hidden=!busy;
    $("hint").textContent=busy
      ?"回车纠偏 · Shift+Enter 排队 · 忙时附件请等本轮结束 · 点击右上角 ⋮ 设置快捷键"
      :"回车发送 · Shift+Enter 排队 · # 搜标题 · 点击右上角 ⋮ 设置快捷键";
  }
  function selectThread(id){
    threadId=id;
    clearStreamMsg();
    showHistory(false);
    renderThreads($("text").value.charAt(0)==="#"?$("text").value.slice(1):"");
    return api("/api/lease",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:id})})
      .then(function(d){
        if(d && (d.error || d.error_code || (d.data&&d.data.error_code) || d.type==="error" || d.type==="chat.error" || d.type==="composer.lease.error")){
          setStatus(statusFromEvent(d));
        }
        return api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:id})});
      })
      .then(function(d){
        renderMsgs(d.messages||[]);
        busy=d.run_status==="llm";
        syncBusyUi();
        if(busy) startPoll(); else stopPoll();
      });
  }
  function startPoll(){
    if(poll) return;
    poll=setInterval(function(){
      if(!threadId) return;
      api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})}).then(function(d){
        var next=d.run_status==="llm";
        // SSE 流式气泡存活期间不做整表重绘（会拆掉 streaming bubble）；轮询仅作兜底
        if(!(streamMsg&&next)) renderMsgs(d.messages||[]);
        if(next!==busy){busy=next;syncBusyUi()}
        if(!busy) stopPoll();
      });
    },1200);
  }
  function stopPoll(){if(poll){clearInterval(poll);poll=null}}
  function filesToPayload(list){
    var arr=[].slice.call(list||[]);
    return Promise.all(arr.map(function(f){
      return new Promise(function(resolve,reject){
        var r=new FileReader();
        r.onload=function(){
          var s=String(r.result||"");
          var i=s.indexOf(",");
          resolve({name:f.name,type:f.type||"application/octet-stream",content:i>=0?s.slice(i+1):s});
        };
        r.onerror=reject;
        r.readAsDataURL(f);
      });
    }));
  }
  function createThread(){
    return api("/api/threads",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(function(d){
      var id=d.thread&&d.thread.id;
      if(!id) return Promise.reject(new Error("没有当前对话"));
      return refresh().then(function(){ return selectThread(id); }).then(function(){ return id; });
    });
  }
  function ensureThread(){
    if(threadId) return Promise.resolve(threadId);
    var wait=threadReady||Promise.resolve();
    return wait.then(function(){
      if(threadId) return threadId;
      return createThread();
    });
  }
  function paintUser(text){
    var empty=$("empty");
    if(empty&&empty.parentNode) empty.parentNode.removeChild(empty);
    var d=document.createElement("div");
    d.className="msg user";
    d.textContent=text;
    $("log").appendChild(d);
    $("log").scrollTop=$("log").scrollHeight;
  }
  function send(mode){
    var text=$("text").value;
    if(text.trim().charAt(0)==="#"){
      renderThreads(text.trim().slice(1));
      return;
    }
    var fileEl=$("files");
    var hasFiles=fileEl.files&&fileEl.files.length;
    if(!text.trim() && !hasFiles) return;
    setStatus("发送中…");
    ensureThread().then(function(){
      if(!threadId){setStatus("没有当前对话");return}
      if(hasFiles && (busy || mode==="steer" || mode==="enqueue")){
        setStatus("忙时不能上传附件（run_active）");
        return;
      }
      if(text.trim()){clearStreamMsg();paintUser(text.trim())}
      $("text").value="";
      return api("/api/lease",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})}).then(function(){
        var go=hasFiles
          ? filesToPayload(fileEl.files).then(function(files){
              return api("/api/files",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId,files:files,message:text})});
            })
          : api("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId,message:text,mode:mode|| (busy?"steer":"create")})});
        return go;
      });
    }).then(function(d){
      if(!d) return;
      if(d.error||d.type==="error"){setStatus(d.error||"发送失败");return}
      fileEl.value="";
      setStatus("已提交");
    }).catch(function(e){setStatus(String(e&&e.message||e))})
  }
  $("send").onclick=function(){send(busy?"steer":"create")};
  $("sendGo").onclick=function(){send(busy?"steer":"create")};
  $("steer").onclick=function(){send("steer")};
  $("queue").onclick=function(){send("enqueue")};
  $("stopGo").onclick=function(){$("stop").click()};
  $("stop").onclick=function(){
    if(!threadId) return;
    api("/api/abort",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})});
  };
  $("chev").onclick=function(){ setExpanded(true); };
  $("attachSilent").onclick=function(){attachChrome(false)};
  $("attachFront").onclick=function(){attachChrome(true)};
  $("openConfirm").onclick=function(){attachChrome(true)};
  $("settings").onclick=function(){
    alert("快捷键设置需要在 Chrome 侧栏的设置面板中配置。\\n\\n请打开 Chrome 侧栏，点击设置图标，在「模型与推理」部分找到「发送快捷键」设置。\\n\\n召唤器使用相同的快捷键配置。");
  };
  $("mic").onclick=function(){
    if(sttLive){ stopStt(false); return; }
    if(!voiceAck){
      var sheet=$("voicePrivacy");
      if(sheet) sheet.hidden=false;
      return;
    }
    startStt();
  };
  $("voicePrivacyAck").onclick=function(){
    voiceAck=true;
    var sheet=$("voicePrivacy");
    if(sheet) sheet.hidden=true;
    startStt();
  };
  function setMeetingUi(on){
    var b=$("meetingStart");
    if(!b) return;
    b.textContent=on?"会议中":"开始会议";
    b.setAttribute("aria-pressed", on?"true":"false");
  }
  var recStartedAt=0;
  var recTimer=null;
  function fmtElapsed(ms){
    var s=Math.floor(ms/1000);
    if(s<0) s=0;
    var m=Math.floor(s/60);
    s=s%60;
    return (m<10?"0":"")+m+":"+(s<10?"0":"")+s;
  }
  function stopRecClock(){
    if(recTimer){ clearInterval(recTimer); recTimer=null; }
    recStartedAt=0;
  }
  function startRecClock(){
    stopRecClock();
    recStartedAt=Date.now();
    recTimer=setInterval(function(){
      var hint=$("meetingHint");
      if(hint && meetingId) hint.textContent="录制中 "+fmtElapsed(Date.now()-recStartedAt);
    },250);
  }
  function setRecordingUi(on){
    var desk=$("meetingDesk");
    var rec=$("meetingRec");
    var mins=$("meetingMinutesBtn");
    if(desk){
      if(on) desk.classList.add("recording");
      else desk.classList.remove("recording");
    }
    if(rec){
      rec.textContent=on?"结束录制":"开始录制";
      rec.setAttribute("aria-pressed", on?"true":"false");
      rec.disabled=false;
    }
    if(mins){
      if(on || lastMeetingId){
        mins.hidden=false;
        mins.textContent=on?"结束并生成纪要":"生成会议纪要";
      } else {
        mins.hidden=true;
      }
    }
    setMeetingUi(!!meetingId || on);
  }
  function showMeetingDesk(on){
    var d=$("meetingDesk");
    if(!d) return;
    if(on){
      d.hidden=false;
      d.removeAttribute("hidden");
      d.style.display="flex";
      paintMeetingVoiceMeta();
      var hint=$("meetingHint");
      if(hint && !meetingId) hint.textContent="未录制";
      var empty=$("meetingEmpty");
      var live=$("meetingLive");
      if(empty && live && !live.querySelector("p")) empty.hidden=false;
      loadMeetingHistory();
    } else {
      d.hidden=true;
      d.style.display="none";
      showMeetingHistory(false);
    }
  }
  function showMeetingHistory(on){
    var list=$("meetingHistList");
    var btn=$("meetingHistToggle");
    if(!list) return;
    if(on){
      list.hidden=false;
      if(btn) btn.setAttribute("aria-pressed","true");
      loadMeetingHistory();
    } else {
      list.hidden=true;
      if(btn) btn.setAttribute("aria-pressed","false");
    }
  }
  function fmtMeetingWhen(iso){
    var s=String(iso||"");
    if(s.length>=16) return s.slice(0,16).replace("T"," ");
    return s||"";
  }
  function loadMeetingHistory(){
    var list=$("meetingHistList");
    if(!list) return;
    api("/api/meetings").then(function(d){
      var items=(d&&d.meetings)||[];
      list.innerHTML="";
      if(!items.length){
        list.innerHTML="<div class=\\"empty-live meeting-hist-empty\\">还没有历史会议</div>";
        return;
      }
      items.forEach(function(m){
        if(!m||!m.id) return;
        var b=document.createElement("button");
        b.type="button";
        if(m.id===(meetingId||lastMeetingId)) b.className="active";
        var title=(m.title||"会议").trim()||"会议";
        var when=fmtMeetingWhen(m.started_at);
        var st=m.status||"";
        b.innerHTML="<strong>"+esc(title)+"</strong><small>"+esc(when+(st?" · "+st:""))+"</small>";
        b.onclick=function(){ openPastMeeting(m.id); };
        list.appendChild(b);
      });
    }).catch(function(){});
  }
  function paintTranscript(lines){
    var box=$("meetingLive");
    if(!box) return;
    box.innerHTML="";
    meetingLines=[];
    if(!lines||!lines.length){
      box.innerHTML="<div class=\\"empty-live\\" id=\\"meetingEmpty\\">点「开始录制」后约 8 秒出字。语音识别用侧栏听写设置。说话人是匿名「发言人N」，不是认人。</div>";
      return;
    }
    lines.forEach(function(l){
      var text=typeof l==="string"?l:(l&&l.text)||"";
      var sp=l&&typeof l.speaker==="string"?l.speaker:"";
      if(text) appendMeetingLive(text, sp);
    });
  }
  function openPastMeeting(id){
    if(meetingId) endMeetingCapture();
    api("/api/meeting?id="+encodeURIComponent(id)).then(function(d){
      var m=d&&d.meeting;
      if(!m||!m.id){ setStatus("打不开这场会议"); return; }
      lastMeetingId=m.id;
      meetingId="";
      meetingFeats=[];
      showMeetingHistory(false);
      paintTranscript(m.transcript||[]);
      var mins=$("meetingMinutes");
      var md=m.minutes&&(m.minutes.raw_md||m.minutes.md);
      if(mins){
        if(md){ mins.hidden=false; mins.innerHTML=renderMd(md); }
        else { mins.hidden=true; mins.innerHTML=""; }
      }
      var hint=$("meetingHint");
      if(hint) hint.textContent=(m.title||"会议")+" · "+(m.status||"历史");
      setRecordingUi(false);
      setStatus("");
    }).catch(function(e){setStatus(String(e&&e.message||e))});
  }
  function paintDiarized(d){
    var m=d&&d.meeting;
    if(!m||!Array.isArray(m.transcript)) return;
    paintTranscript(m.transcript);
    var method=d.diarize&&d.diarize.method||m.diarize&&m.diarize.method;
    var k=d.diarize&&d.diarize.k||m.diarize&&m.diarize.k;
    var kPart=typeof k==="number"&&k>=1?" · K="+Math.floor(k):"";
    setStatus((method==="text_gap"?"已弱标说话人（按行交替 · 非声学）":"已标匿名发言人（实验 · 非身份识别）")+kPart);
  }
  function appendMeetingLive(text, speaker){
    var box=$("meetingLive");
    if(!box||!text) return;
    var empty=$("meetingEmpty");
    if(empty) empty.hidden=true;
    var p=document.createElement("p");
    if(speaker){
      p.innerHTML="<span class=\\"spk\\">"+esc(speaker)+"</span> "+esc(text);
    } else {
      p.textContent=text;
    }
    box.appendChild(p);
    box.scrollTop=box.scrollHeight;
    meetingLines.push({text:text,speaker:speaker||""});
  }
  function startMeetingCapture(){
    if(meetingId) return;
    var rec=$("meetingRec");
    if(rec) rec.disabled=true;
    loadVoiceSettings().then(function(){
    if(voiceSettings.sttEngine!=="local"){
      var need=STT_NEED_MODEL;
      setStatus(need);
      var h0=$("meetingHint");
      if(h0) h0.textContent="请在侧栏设置启用本机转写";
      if(rec) rec.disabled=false;
      return;
    }
    meetingFeats=[];
    meetingLines=[];
    sttFeatsBySid={};
    showMeetingHistory(false);
    var part=$("meetingPartial");
    if(part) part.textContent="";
    var mins=$("meetingMinutes");
    if(mins){ mins.hidden=true; mins.innerHTML=""; }
    var live=$("meetingLive");
    if(live) live.innerHTML="<div class=\\"empty-live\\" id=\\"meetingEmpty\\">正在听…约 8 秒出第一段字。</div>";
    showMeetingDesk(true);
    var hint=$("meetingHint");
    if(hint) hint.textContent="正在开始…";
    var payload={};
    if(threadId) payload.thread_id=threadId;
    return api("/api/meeting/start",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}).then(function(d){
      if(d && (d.type==="meeting.error" || d.type==="error" || d.error)){
        var msg=sttUserCopy(d.code||d.error_code, d.message||d.error||"会议开始失败");
        setStatus(msg);
        if(hint) hint.textContent=msg;
        if(rec) rec.disabled=false;
        return;
      }
      var mid=(d&&d.meeting&&d.meeting.id)||(d&&d.data&&d.data.meeting&&d.data.meeting.id)||"";
      if(typeof mid!=="string" || mid.indexOf("tray-")===0 || mid.indexOf("mtg_")!==0) mid="";
      meetingId=mid;
      if(!meetingId){
        var fail="会议开始失败";
        setStatus(fail);
        if(hint) hint.textContent=fail;
        if(rec) rec.disabled=false;
        return;
      }
      lastMeetingId=meetingId;
      setRecordingUi(true);
      if(hint) hint.textContent="录制中 00:00";
      startRecClock();
      if(!sttLive) startStt();
    }).catch(function(e){
      var msg=String(e&&e.message||e);
      setStatus(msg);
      if(hint) hint.textContent=msg;
      if(rec) rec.disabled=false;
    });
    }).catch(function(e){
      var rec2=$("meetingRec");
      if(rec2) rec2.disabled=false;
      setStatus(String(e&&e.message||e));
    });
  }
  function endMeetingCapture(){
    var id=meetingId;
    meetingId="";
    stopRecClock();
    setRecordingUi(false);
    if(sttLive) stopStt(false);
    var hint=$("meetingHint");
    if(hint) hint.textContent=id?"已结束 · 可生成纪要":"未录制";
    var part=$("meetingPartial");
    if(part) part.textContent="";
    if(!id){ setStatus("未在录制"); return; }
    lastMeetingId=id;
    api("/api/meeting/end",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:id})}).then(function(d){
      if(d && (d.type==="meeting.error" || d.type==="error" || d.error)){
        setStatus(d.message||d.error||"结束录制失败");
        return;
      }
      setStatus("录制已结束");
      loadMeetingHistory();
    }).catch(function(e){setStatus(String(e&&e.message||e))});
  }
  function requestMeetingMinutes(){
    var id=meetingId||lastMeetingId;
    if(!id){ setStatus("请先录制"); return; }
    if(meetingId) endMeetingCapture();
    setStatus("正在生成纪要…");
    var hint=$("meetingHint");
    if(hint) hint.textContent="正在生成纪要…";
    api("/api/meeting/minutes",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:id})}).then(function(d){
      if(d && (d.type==="meeting.error" || d.type==="error" || d.error)){
        setStatus(d.message||d.error||"纪要生成失败");
        if(hint) hint.textContent="纪要生成失败";
        return;
      }
      var md=(d&&d.minutes&&(d.minutes.raw_md||d.minutes.md))||(d&&d.raw_md)||"";
      if(!md && d&&d.minutes&&typeof d.minutes==="string") md=d.minutes;
      if(!md){
        setStatus("纪要生成失败");
        if(hint) hint.textContent="纪要生成失败";
        return;
      }
      var box=$("meetingMinutes");
      if(box && md){
        box.hidden=false;
        box.innerHTML=renderMd(md);
      }
      setStatus("纪要已生成");
      if(hint) hint.textContent="纪要";
    }).catch(function(e){
      setStatus(String(e&&e.message||e)||"纪要生成失败");
      if(hint) hint.textContent="纪要生成失败";
    });
  }
  $("meetingStart").onclick=function(){
    if(!meetingAck){
      var sheet=$("meetingPrivacy");
      var vsec=$("meetingVoiceSection");
      if(!voiceAck){
        if(vsec) vsec.hidden=false;
      } else if(vsec) vsec.hidden=true;
      if(sheet) sheet.hidden=false;
      return;
    }
    showMeetingDesk(true);
    startMeetingCapture();
  };
  $("meetingPrivacyAck").onclick=function(){
    meetingAck=true;
    voiceAck=true;
    var sheet=$("meetingPrivacy");
    if(sheet) sheet.hidden=true;
    showMeetingDesk(true);
    startMeetingCapture();
  };
  $("meetingRec").onclick=function(){
    if(meetingId){ endMeetingCapture(); return; }
    startMeetingCapture();
  };
  $("meetingHistToggle").onclick=function(){
    var list=$("meetingHistList");
    showMeetingHistory(!(list && !list.hidden));
  };
  $("meetingMinutesBtn").onclick=function(){ requestMeetingMinutes(); };
  $("meetingBack").onclick=function(){
    if(meetingId) endMeetingCapture();
    showMeetingDesk(false);
  };
  $("cruiseChip").onclick=function(){ $("operateOpen").click(); };
  $("operateOpen").onclick=function(){
    setStatus("正在打开侧栏…");
    api("/api/operate",{method:"POST"}).then(function(d){
      if(d && (d.type==="error" || d.error)){
        setStatus("请点工具栏 C");
        return;
      }
      setStatus("已请浏览器打开侧栏");
    }).catch(function(){setStatus("请点工具栏 C")});
  };
  function showHistory(on){
    var hud=$("hud");
    if(!hud) return;
    if(on){ hud.classList.add("history"); if(sec==="threads") refresh().catch(function(){setStatus("无法刷新对话列表")}); }
    else hud.classList.remove("history");
    $("historyOpen").setAttribute("aria-expanded",String(on));
  }
  var compactWindow=false;
  $("windowMode").onclick=function(){compactWindow=!compactWindow;placeWindow(compactWindow);$("windowMode").textContent=compactWindow?"工作窗口":"紧凑窗口";setStatus("已请求调整窗口；如果当前宿主未响应，可手动调整窗口大小。")};
  $("historyOpen").onclick=function(){ showHistory(!$("hud").classList.contains("history")); };
  $("threadSearch").oninput=function(){renderThreads()};
  document.addEventListener("keydown",function(e){if(e.key==="Escape" && $("hud").classList.contains("history")){showHistory(false);$("historyOpen").focus()}});
  $("historyClose").onclick=function(){ showHistory(false); };
  $("newChat").onclick=function(){ $("newThread").click(); };
  $("newThreadBar").onclick=function(){$("newThread").click()};
  $("newThread").onclick=function(){
    api("/api/threads",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(function(d){
      var id=d.thread&&d.thread.id;
      if(!id){setStatus("新建失败");return}
      showHistory(false);
      return refresh().then(function(){return selectThread(id)});
    });
  };
  $("attachFile").addEventListener("click",function(){ $("files").click(); });
  $("text").addEventListener("keydown",function(e){
    if(e.key!=="Enter" || e.isComposing || e.keyCode===229) return;
    if(e.shiftKey && !e.metaKey && !e.ctrlKey){
      if(busy){e.preventDefault();send("enqueue")}
      return;
    }
    var go=false;
    if(sendShortcut==="Enter") go=!e.shiftKey && !e.metaKey && !e.ctrlKey;
    else if(sendShortcut==="Cmd+Enter") go=e.metaKey && !e.ctrlKey;
    else if(sendShortcut==="Ctrl+Enter") go=e.ctrlKey && !e.metaKey;
    if(!go) return;
    e.preventDefault();
    send(busy?"steer":"create");
  });
  $("text").addEventListener("input",function(){
    var v=$("text").value;
    if(v.trim().charAt(0)==="#") renderThreads(v.trim().slice(1));
  });
  function refresh(){
    return api("/api/threads").then(function(d){
      threads=(d.threads||[]).slice().sort(function(a,b){
        return String(b.last_message_at||b.created_at||"").localeCompare(String(a.last_message_at||a.created_at||""));
      });
      renderThreads();
    });
  }
  var sec="threads";
  function showSec(name){
    sec=name;
    document.querySelectorAll("#secs [data-sec]").forEach(function(b){
      if(b.getAttribute("data-sec")===name) b.setAttribute("aria-current","true");
      else b.removeAttribute("aria-current");
    });
    setExpanded(true);
    var heads={threads:"对话",packs:"场景",knowledge:"知识",skills:"技能",mcp:"MCP",browser:"浏览器"};
    $("threadSearchLabel").hidden=name!=="threads";
    $("secHead").textContent=heads[name]||name;
    $("newThread").style.display=name==="threads"?"":"none";
    $("threads").style.display=name==="threads"?"":"none";
    $("composeList").style.display=name==="threads"?"none":"";
    if(name==="threads") return refresh();
    loadCompose(name);
  }
  var composeRevision=0;
  function loadCompose(name){
    var revision=++composeRevision,ownerThread=threadId;
    var target=$("composeList"),box=document.createElement("div");
    target.textContent="加载中…";
    function load(){
    function markEmpty(){
      if(box.children.length) return;
      var p=document.createElement("div");
      p.className="row muted";
      p.innerHTML="<strong>这一栏是空的</strong><small>没有可显示的项目</small>";
      box.appendChild(p);
    }
    if(name==="packs"){
      return api("/api/packs").then(function(d){
        (d.packs||[]).forEach(function(p){
          var b=document.createElement("button");
          b.className="row"+(p.overlay_eligible?"":" muted");
          b.innerHTML="<strong>"+esc(p.name||p.id)+"</strong><small>"+(p.overlay_eligible?"套到当前对话":"召唤器不可用")+"</small>";
          b.onclick=function(){
            if(threadId!==ownerThread){loadCompose(name);return}
            if(!threadId){setStatus("没有当前对话");return}
            if(!p.overlay_eligible){setStatus("这个场景不能在召唤器套用");return}
            api("/api/packs/apply",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({pack_id:p.id,thread_id:threadId})}).then(function(r){
              setStatus((r&&r.error)||"已套到当前对话");
            });
          };
          box.appendChild(b);
        });
      }).catch(function(e){setStatus(String(e&&e.message||e))}).then(markEmpty);
    }
    if(name==="browser"){
      box.innerHTML='<p class="resource-note">连接现有 Chrome。后台连接会尽量避免展示窗口；需要查看操作时展示浏览器。网页操作仍需要已连接的 CMspark 扩展。</p>';
      [["后台连接",false],["展示浏览器",true]].forEach(function(item){var b=document.createElement("button");b.className="row";b.textContent=item[0];b.onclick=function(){attachChrome(item[1])};box.appendChild(b)});
      return api("/api/browser-status").then(function(d){var p=document.createElement("p");p.className="resource-note";p.textContent=d.connected===true?"CMspark 扩展已连接":"尚未连接 CMspark 扩展";box.prepend(p)}).catch(function(){setStatus("无法读取浏览器连接状态")});
    }
    if(name==="mcp"){
      return api("/api/mcp").then(function(d){
        if(d.error||d.type==="error") throw new Error(d.error||"无法读取 MCP");
        var note=document.createElement("p");note.className="resource-note";note.textContent="查看已配置的服务。桌面配置编辑将在工作台管理功能中提供。";box.appendChild(note);
        (d.servers||[]).forEach(function(s){
          var row=document.createElement("div");row.className="row resource-readonly";
          row.innerHTML="<strong>"+esc(s.name||"")+"</strong><small>"+esc(({connected:"已连接",connecting:"连接中",disconnected:"未连接",error:"连接失败",dead:"已停止"})[s.connection&&s.connection.status]||"状态未知")+"</small>";
          box.appendChild(row);
        });
        if(!(d.servers||[]).length){var empty=document.createElement("p");empty.className="resource-note";empty.textContent="尚未配置 MCP 服务";box.appendChild(empty)}
      }).catch(function(e){setStatus(String(e&&e.message||e))});
    }
    if(name==="skills"){
      return Promise.all([api("/api/skills"), threadId?api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})}):Promise.resolve({})]).then(function(pair){
        var ids=pair[1].active_skill_ids||[];
        (pair[0].skills||[]).forEach(function(s){
          var on=ids.indexOf(s.name)>=0;
          var b=document.createElement("button");
          b.className="row";
          b.innerHTML="<strong>"+esc(s.title||s.name)+"</strong><small>"+(on?"已用于本对话":"未用")+"</small>";
          b.onclick=function(){
            if(threadId!==ownerThread){loadCompose(name);return}
            if(!threadId){setStatus("没有当前对话");return}
            api("/api/skills/toggle",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId,skill_name:s.name,on:!on})}).then(function(d){if(d.error||d.type==="error") throw new Error(d.error||"保存失败");loadCompose("skills")}).catch(function(e){setStatus(String(e&&e.message||e))});
          };
          box.appendChild(b);
        });
      }).catch(function(e){setStatus(String(e&&e.message||e))}).then(markEmpty);
    }
    if(name==="knowledge"){
      return Promise.all([api("/api/knowledge"), threadId?api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})}):Promise.resolve({})]).then(function(pair){
        var cur=pair[1].active_knowledge_ids||[];
        (pair[0].docs||[]).forEach(function(k){
          var id=k.name||k.id;
          var on=cur.indexOf(id)>=0;
          var b=document.createElement("button");
          b.className="row";
          b.innerHTML="<strong>"+esc(k.title||id)+"</strong><small>"+(on?"已挂到本对话":"点击挂上")+"</small>";
          b.onclick=function(){
            if(threadId!==ownerThread){loadCompose(name);return}
            if(!threadId){setStatus("没有当前对话");return}
            var next=on?cur.filter(function(x){return x!==id}):cur.concat([id]);
            api("/api/knowledge/active",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId,ids:next})}).then(function(d){if(d.error||d.type==="error") throw new Error(d.error||"保存失败");loadCompose("knowledge")}).catch(function(e){setStatus(String(e&&e.message||e))});
          };
          box.appendChild(b);
        });
      }).catch(function(e){setStatus(String(e&&e.message||e))}).then(markEmpty);
    }
    }
    return Promise.resolve(load()).then(function(){if(revision===composeRevision && sec===name && threadId===ownerThread){target.replaceChildren();while(box.firstChild)target.appendChild(box.firstChild)}});
  }
  document.querySelectorAll("#secs [data-sec]").forEach(function(b){
    b.onclick=function(){showSec(b.getAttribute("data-sec"))};
  });
  $("composeList").style.display="none";
  function releaseLease(){
    if(!threadId) return;
    try{
      var body=new Blob([JSON.stringify({thread_id:threadId})],{type:"application/json"});
      navigator.sendBeacon(url("/api/lease/release"), body);
    }catch(e){}
  }
  window.addEventListener("pagehide", function(){
    if(sttLive) stopStt(true);
    if(meetingId){
      try{
        var body=new Blob([JSON.stringify({id:meetingId})],{type:"application/json"});
        navigator.sendBeacon(url("/api/meeting/end"), body);
      }catch(e){}
    }
    releaseLease();
  });
  function statusFromEvent(d){
    if(!d||typeof d!=="object") return "出错了";
    var data=d.data&&typeof d.data==="object"?d.data:{};
    var raw=String(d.error_code||data.error_code||d.error||"");
    var code=raw.indexOf("OVERLAY_STANDBY")>=0?"OVERLAY_STANDBY": raw.indexOf("LEASE_REV_MISMATCH")>=0?"LEASE_REV_MISMATCH": raw;
    var labels={
      run_active:"本轮还在跑 · 回车纠偏或排队",
      queue_full:"排队已满（最多 8 条）",
      steer_queue_full:"纠偏队列已满",
      idle_enqueue:"空闲时直接发送，不必排队",
      OVERLAY_STANDBY:"侧栏占用了输入",
      LEASE_REV_MISMATCH:"侧栏占用了输入",
      LEASE_HOLDER_SURFACE_MISMATCH:"侧栏占用了输入",
      BROWSER_UNAVAILABLE:CHROME_DOWN.cdp,
      settings_hint:"点击右上角 ⋮ 设置快捷键"
    };
    if(code==="BROWSER_UNAVAILABLE"||String(raw).indexOf("BROWSER_UNAVAILABLE")>=0){
      showChromeCta("cdp");
      return CHROME_DOWN.cdp;
    }
    if(/model|binary/i.test(raw)) return STT_NEED_MODEL;
    return labels[code]||d.error||d.message||"出错了";
  }
  try{
    var es=new EventSource(url("/api/events"));
    es.onmessage=function(ev){
      var d; try{d=JSON.parse(ev.data)}catch(e){return}
      var t=d&&d.type;
      if(t==="shell.close"){
        try{window.close()}catch(e){}
        return;
      }
      if(t==="overlay.cruise"){
        var lab=typeof d.cruise_label==="string"?d.cruise_label.trim():"";
        var chip=$("cruiseChip");
        if(chip && lab){ chip.textContent=lab.slice(0,40); }
        return;
      }
      if(t==="error"||t==="chat.error"){
        if(d.thread_id&&threadId&&d.thread_id!==threadId) return;
        clearStreamMsg();
        setStatus(statusFromEvent(d));
        return;
      }
      if(t==="chat.token"){
        if(d.thread_id&&threadId&&d.thread_id!==threadId) return;
        var tok=typeof d.content==="string"?d.content:"";
        if(threadId&&tok) showStreamMsg(tok);
        return;
      }
      if(t==="chat.user"||t==="chat.steered"||t==="chat.enqueued"){
        $("text").value="";
        $("files").value="";
        setStatus(t==="chat.enqueued"?"已排队": t==="chat.steered"?"已纠偏":"已发送");
        busy=t!=="chat.enqueued"?true:busy;
        syncBusyUi();
        startPoll();
        return;
      }
      if(t==="voice.stt.partial"){
        if(meetingId){
          var pt=typeof d.text==="string"?d.text:"";
          var mp=$("meetingPartial");
          if(mp && pt) mp.textContent=pt;
        }
        return;
      }
      if(t==="voice.stt.result"){
        var sid=typeof d.sessionId==="string"?d.sessionId:"";
        var txt=typeof d.text==="string"?d.text.trim():"";
        if(txt && meetingId){
          var feat=sid&&sttFeatsBySid[sid];
          if(feat) meetingFeats.push(feat);
          else meetingFeats.push([0,0,0]);
          appendMeetingLive(txt, "");
          var mp2=$("meetingPartial");
          if(mp2) mp2.textContent="";
          api("/api/meeting/append",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:meetingId,text:txt})});
        } else if(txt && !meetingId){
          var cur=$("text").value;
          $("text").value=cur&&cur.trim()?cur.replace(/\\s*$/,"")+" "+txt:txt;
        }
        if(sttLive && (!sid || sttSid===sid)) stopStt(false);
        if(meetingId && !sttLive) startStt();
        return;
      }
      if(t==="meeting.diarized"){
        paintDiarized(d);
        return;
      }
      if(t==="voice.stt.error"){
        setStatus(sttUserCopy(d.code||d.error_code, d.message||d.error));
        if(sttLive) stopStt(true);
        return;
      }
      if(t==="meeting.error"){
        setStatus(sttUserCopy(d.code||d.error_code, d.message||d.error||"会议出错"));
        return;
      }
      if(t==="meeting.ended"){
        if(meetingId) lastMeetingId=meetingId;
        meetingId="";
        stopRecClock();
        setRecordingUi(false);
        if(sttLive) stopStt(false);
        var hint=$("meetingHint");
        if(hint) hint.textContent="已结束 · 可生成纪要";
        setStatus("录制已结束");
        return;
      }
      if(t==="meeting.minutes_result"){
        var md=(d&&d.minutes&&(d.minutes.raw_md||d.minutes.md))||d.raw_md||"";
        var box=$("meetingMinutes");
        if(!md){
          setStatus("纪要生成失败");
          return;
        }
        if(box && md){
          showMeetingDesk(true);
          box.hidden=false;
          box.innerHTML=renderMd(md);
        }
        setStatus("纪要已生成");
        return;
      }
      if(t==="mcp.confirm.pending"){
        setStatus(${JSON.stringify(SUMMONER_CONFIRM_NEED)});
        showConfirmCta();
        return;
      }
      if(t==="run_status"){
        if(d.thread_id&&threadId&&d.thread_id!==threadId) return;
        busy=d.status==="llm";
        syncBusyUi();
        if(!busy) stopPoll(); else startPoll();
      }
      if(t==="chat.done"||t==="chat.aborted"){
        if(d.thread_id&&threadId&&d.thread_id!==threadId) return;
        clearStreamMsg();
        busy=false;
        syncBusyUi();
        stopPoll();
      }
      if(threadId && (t==="chat.done"||t==="chat.user"||t==="file.uploaded")){
        api("/api/thread",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({thread_id:threadId})}).then(function(x){renderMsgs(x.messages||[])});
      }
    };
  }catch(e){}
  setExpanded(true);
  threadReady=refresh().then(function(){
    if(wanted) return selectThread(wanted);
    if(threads[0]) return selectThread(threads[0].id);
  }).catch(function(e){setStatus(String(e&&e.message||e))});
})();
}catch(e){try{var s=document.getElementById("status");if(s)s.textContent=String(e&&e.message||e)}catch(x){}}
</script>
</body>
</html>`

## companion/src/summoner/shell-open.ts
/**
 * C-thin P3: open the loopback HTML shell in a dedicated Chromium/Edge
 * `--app` window when a browser binary exists. Otherwise honest degrade to
 * the system URL handler (tab). Not Electron. Not a new Swift overlay.
 *
 * Native WKWebView / WebView2 / GTK remains a later host for the same HTML.
 */
import * as child_process from "child_process"
import * as fs from "fs"
import * as path from "path"

export type SummonerShellKind = "app-window" | "browser-tab"

export type SummonerShellPlan = {
  kind: SummonerShellKind
  command: string
  args: string[]
  shell?: boolean
}

export type SummonerShellOpenOpts = {
  platform: NodeJS.Platform
  browserPath?: string | null
  userDataDir?: string | null
  windowPosition?: { x: number; y: number }
}

/** Inner --app viewport. Outer adds ~28px title bar when centering. */
export const OVERLAY_WINDOW_SIZE = { w: 1040, h: 760 } as const
const OVERLAY_TITLEBAR_PX = 28

export function overlayWindowPosition(
  screenW: number,
  screenH: number,
  innerW: number = OVERLAY_WINDOW_SIZE.w,
  innerH: number = OVERLAY_WINDOW_SIZE.h,
): { x: number; y: number } {
  const outerH = innerH + OVERLAY_TITLEBAR_PX
  return {
    x: Math.max(0, Math.floor((screenW - innerW) / 2)),
    y: Math.max(0, Math.floor((screenH - outerH) / 2)),
  }
}

export function parseOverlayChromePids(psOutput: string, userDataDir: string): number[] {
  if (!userDataDir) return []
  const needle = `--user-data-dir=${userDataDir}`
  const pids: number[] = []
  for (const line of psOutput.split("\n")) {
    if (!line.includes(needle)) continue
    const pid = parseInt(line.trim(), 10)
    if (Number.isInteger(pid) && pid > 0 && pid !== process.pid) pids.push(pid)
  }
  return pids
}

export function readOverlayChromePids(userDataDir: string): number[] {
  try {
    const out = child_process.execFileSync("ps", ["-axo", "pid=,command="], {
      encoding: "utf8",
      timeout: 2000,
    })
    return parseOverlayChromePids(out, userDataDir)
  } catch {
    return []
  }
}

export function closeOverlayChrome(userDataDir: string): number {
  const pids = readOverlayChromePids(userDataDir)
  let n = 0
  for (const pid of pids) {
    try {
      process.kill(pid, "SIGTERM")
      n += 1
    } catch {
      /* already gone */
    }
  }
  return n
}

export function parseFinderDesktopBounds(raw: string): { w: number; h: number } | null {
  const parts = String(raw)
    .split(/[,\s]+/)
    .map((s) => Number(s.trim()))
    .filter((n) => Number.isFinite(n))
  if (parts.length < 4) return null
  const w = parts[2] - parts[0]
  const h = parts[3] - parts[1]
  if (!(w > 0) || !(h > 0)) return null
  return { w, h }
}

export function isSummonerLoopbackUrl(url: string): boolean {
  if (typeof url !== "string" || !url) return false
  try {
    const u = new URL(url)
    if (u.protocol !== "http:") return false
    const host = u.hostname.toLowerCase()
    if (host !== "127.0.0.1" && host !== "localhost") return false
    if (u.pathname !== "/" && u.pathname !== "/summoner") return false
    const keys = [...u.searchParams.keys()]
    const unique = [...new Set(keys)]
    if (keys.length !== unique.length) return false
    // Batch D D3: token must not appear in --app argv / query.
    if (unique.includes("token")) return false
    if (unique.length === 0) return true
    if (unique.length === 1 && unique[0] === "thread") {
      const thread = u.searchParams.get("thread") || ""
      return thread.length > 0
    }
    return false
  } catch {
    return false
  }
}

export function planSummonerShellOpen(
  url: string,
  opts: SummonerShellOpenOpts,
): SummonerShellPlan | { error: string } {
  if (!isSummonerLoopbackUrl(url)) {
    return { error: "summoner shell only opens loopback token URLs" }
  }
  const browserPath = typeof opts.browserPath === "string" ? opts.browserPath.trim() : ""
  if (browserPath) {
    const { w, h } = OVERLAY_WINDOW_SIZE
    const args = [`--app=${url}`, `--window-size=${w},${h}`, "--no-first-run", "--no-default-browser-check"]
    const dir = typeof opts.userDataDir === "string" ? opts.userDataDir.trim() : ""
    if (dir) args.push(`--user-data-dir=${dir}`)
    const pos = opts.windowPosition
    if (pos && Number.isFinite(pos.x) && Number.isFinite(pos.y)) {
      args.push(`--window-position=${Math.max(0, pos.x | 0)},${Math.max(0, pos.y | 0)}`)
    }
    return {
      kind: "app-window",
      command: browserPath,
      args,
    }
  }
  if (opts.platform === "darwin") {
    return { kind: "browser-tab", command: "open", args: [url] }
  }
  if (opts.platform === "linux") {
    return { kind: "browser-tab", command: "xdg-open", args: [url] }
  }
  if (opts.platform === "win32") {
    return { kind: "browser-tab", command: "cmd.exe", args: ["/c", "start", "", url] }
  }
  return { error: `unsupported platform: ${opts.platform}` }
}

const DARWIN_BINS = [
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
  "/Applications/Chromium.app/Contents/MacOS/Chromium",
  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
]

const WIN_BINS = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
]

const POSIX_NAMES = [
  "google-chrome",
  "google-chrome-stable",
  "chromium",
  "chromium-browser",
  "microsoft-edge",
  "microsoft-edge-stable",
  "brave-browser",
]

function whichFromPath(name: string, pathEnv: string, exists: (p: string) => boolean): string | null {
  const sep = process.platform === "win32" ? ";" : ":"
  for (const dir of pathEnv.split(sep)) {
    if (!dir) continue
    const candidate = path.join(dir, name)
    if (exists(candidate)) return candidate
    if (process.platform === "win32" && exists(candidate + ".exe")) return candidate + ".exe"
  }
  return null
}

export function resolveSummonerBrowserPath(
  platform: NodeJS.Platform,
  exists: (p: string) => boolean = (p) => {
    try {
      return fs.existsSync(p)
    } catch {
      return false
    }
  },
  pathEnv: string = process.env.PATH || "",
): string | null {
  const fixed = platform === "darwin" ? DARWIN_BINS : platform === "win32" ? WIN_BINS : []
  for (const p of fixed) {
    if (exists(p)) return p
  }
  for (const name of POSIX_NAMES) {
    const hit = whichFromPath(name, pathEnv, exists)
    if (hit) return hit
  }
  if (platform === "win32") {
    for (const name of ["chrome", "msedge", "chrome.exe", "msedge.exe"]) {
      const hit = whichFromPath(name, pathEnv, exists)
      if (hit) return hit
    }
  }
  return null
}

## companion/src/mcp/types.ts
// MCP (Model Context Protocol) client types — shared between config, manager, and frontend.

import type { McpDeclaredCapability } from "../security.js"

export type McpTransportKind = "stdio" | "http"

export type McpTrustLevel = "manual" | "first-use" | "trusted"

export interface McpRestartPolicy {
  max_restarts: number
  backoff_base_ms: number
  backoff_max_ms: number
}

interface McpBaseServerConfig {
  enabled: boolean
  trust_level: McpTrustLevel
  startup_timeout_ms?: number
  call_timeout_ms?: number
  restart_policy?: Partial<McpRestartPolicy>
  /** Optional MCP roots to advertise to the server. Filesystem servers use these as allowed directories. */
  roots?: Array<{ uri: string; name?: string }>
  /** §6.3 Phase 2-B (follow-up C): user-declared security capabilities for this
   *  server's namespaced tools. Used as the PRIMARY classification source by the
   *  capability gate (executeMcpTool); Phase 1's classifyMcpCall inference stays
   *  as defense-in-depth, merged via a fail-safe union (a declaration can only
   *  escalate, never suppress a positively-inferred critical capability). Omit
   *  to keep pure-inference behavior (Phase 1 default).
   *
   *  Valid values: file-read | file-write | exec | network-egress | db-read |
   *  db-mutate | read-only ("unknown" is not declarable). Unknown values are
   *  stripped with a warning at sanitize time, never dropping the server. */
  security_capabilities?: McpDeclaredCapability[]
}

export interface McpStdioServerConfig extends McpBaseServerConfig {
  transport: "stdio"
  command: string
  args?: string[]
  env?: Record<string, string>
  cwd?: string
}

export interface McpHttpServerConfig extends McpBaseServerConfig {
  transport: "http"
  url: string
  headers?: Record<string, string>
}

export type McpServerConfig = McpStdioServerConfig | McpHttpServerConfig

export interface McpConfig {
  enabled: boolean
  servers: Record<string, McpServerConfig>
}

export type McpConnectionStatus =
  | "disconnected"
  | "connecting"
  | "connected"
  | "error"
  | "dead"

export interface McpConnectionState {
  status: McpConnectionStatus
  last_error?: string
  restart_count: number
  last_connected_at?: string
  pid?: number
}

export interface McpCapabilities {
  tools: boolean
  resources: boolean
  prompts: boolean
}

export interface McpToolMeta {
  name: string
  namespacedName: string
  description: string
  inputSchema: Record<string, any>
}

export interface McpResourceMeta {
  uri: string
  name: string
  description?: string
  mimeType?: string
}

export interface McpPromptMeta {
  name: string
  description?: string
  arguments?: Array<{ name: string; description?: string; required?: boolean }>
}

export interface McpServerMeta {
  name: string
  transport: McpTransportKind
  enabled: boolean
  trust_level: McpTrustLevel
  connection: McpConnectionState
  capabilities: McpCapabilities
  server_info?: { name?: string; version?: string }
  tools: McpToolMeta[]
  resources: McpResourceMeta[]
  prompts: McpPromptMeta[]
  /** Raw config snapshot for the edit form. Sensitive values (env, headers) included
   *  since the user already configured them locally; api tokens are NOT a concern
   *  here (those are in trusted_domains, separate path). */
  config: McpServerConfig
}

export interface McpToolRoute {
  serverName: string
  toolName: string
}

export const DEFAULT_STARTUP_TIMEOUT_MS = 15000
export const DEFAULT_CALL_TIMEOUT_MS = 30000
export const DEFAULT_RESTART_POLICY: McpRestartPolicy = {
  max_restarts: 5,
  backoff_base_ms: 1000,
  backoff_max_ms: 30000,
}

export function resolveStartupTimeout(cfg: McpServerConfig): number {
  return cfg.startup_timeout_ms ?? DEFAULT_STARTUP_TIMEOUT_MS
}

export function resolveCallTimeout(cfg: McpServerConfig): number {
  return cfg.call_timeout_ms ?? DEFAULT_CALL_TIMEOUT_MS
}

export function resolveRestartPolicy(cfg: McpServerConfig): McpRestartPolicy {
  return { ...DEFAULT_RESTART_POLICY, ...(cfg.restart_policy || {}) }
}

// Fields whose change requires a transport restart (vs soft update via client.updateConfig).
const RESTART_FIELD_KEYS = [
  "transport",
  "command",
  "args",
  "env",
  "cwd",
  "url",
  "headers",
] as const

export function requiresRestart(prev: McpServerConfig, next: McpServerConfig): boolean {
  for (const key of RESTART_FIELD_KEYS) {
    const a = (prev as any)[key]
    const b = (next as any)[key]
    if (JSON.stringify(a) !== JSON.stringify(b)) return true
  }
  return false
}

## Test delta
diff --git a/companion/scripts/test-summoner-workspace-ui.py b/companion/scripts/test-summoner-workspace-ui.py
index 18498f05..21a7b843 100644
--- a/companion/scripts/test-summoner-workspace-ui.py
+++ b/companion/scripts/test-summoner-workspace-ui.py
@@ -11,12 +11,14 @@ with tempfile.TemporaryDirectory() as out:
  with sync_playwright() as p:
   b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':390,'height':740});page.set_default_timeout(6000)
   errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)))
-  page.add_init_script('window.EventSource=class {addEventListener(){} close(){}};window.resizeTo=()=>{};window.moveTo=()=>{};')
+  page.add_init_script('window.EventSource=class {constructor(){window.fixtureEvents=this} addEventListener(){} close(){}};window.resizeTo=()=>{};window.moveTo=()=>{};')
   def route(r):
    req=r.request;path=urlparse(req.url).path;requests.append((req.method,path))
    if path=='/':r.fulfill(content_type='text/html',body=html);return
    if path=='/api/threads':data={'thread':{'id':'fixture-1'}} if req.method=='POST' else {'threads':[{'id':'fixture-1','alias':'演示对话'}]}
    elif path=='/api/thread':data={'messages':[],'run_status':'idle'}
+   elif path=='/api/mcp':data={'servers':[]}
+   elif path=='/api/browser-status':data={'connected':False}
    else:data={'ok':True}
    r.fulfill(content_type='application/json',body=json.dumps(data))
   page.route('http://fixture.test/**',route);page.goto('http://fixture.test/')
@@ -26,16 +28,42 @@ with tempfile.TemporaryDirectory() as out:
   page.wait_for_function('document.querySelector("#empty strong")')
   assert page.locator('.mark').count()==0 and '山' not in page.locator('#empty').inner_text()
   assert ('POST','/api/threads') in requests
-  page.get_by_role('button',name='历史',exact=True).click();assert page.locator('.hud.history .list').is_visible()
+  page.get_by_role('button',name='导航',exact=True).click();assert page.locator('.hud.history .list').is_visible()
   page.get_by_role('button',name='完成',exact=True).click()
-  for width,height in [(320,420),(390,740),(1000,800)]:
+  for width,height in [(320,420),(360,420),(390,740),(760,740),(1000,800),(1440,900)]:
    page.set_viewport_size({'width':width,'height':height})
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
    assert page.locator('.composer-actions button:visible').evaluate_all('(els)=>els.map(el=>el.id)')==['attachFile','mic','sendGo']
-   assert page.get_by_role('button',name='新对话',exact=True).count()==1
+   assert page.get_by_role('button',name='新对话',exact=True).count()>=1
    field=text.bounding_box();send=page.get_by_role('button',name='发送',exact=True).bounding_box()
    assert field and send and field['y']+field['height']<=send['y']+1 and send['y']+send['height']<=height
    page.screenshot(path=str(shots/f'summoner-{width}.png'))
+  page.set_viewport_size({'width':1040,'height':760})
+  page.get_by_role('searchbox',name='搜索对话').fill('不存在')
+  assert page.locator('#threads .trow').count()==0
+  page.get_by_role('searchbox',name='搜索对话').fill('演示')
+  assert page.locator('#threads .trow').count()==1
+  page.get_by_role('button',name='MCP',exact=True).click()
+  page.get_by_text('尚未配置 MCP 服务',exact=True).wait_for()
+  assert not any(path=='/api/mcp/toggle' for method,path in requests)
+  page.get_by_role('button',name='浏览器',exact=True).click()
+  page.get_by_text('尚未连接 CMspark 扩展',exact=True).wait_for()
+  page.get_by_role('button',name='后台连接',exact=True).click()
+  assert ('POST','/api/attach') in requests
+  page.get_by_role('button',name='展示浏览器',exact=True).click()
+  page.get_by_role('button',name='对话',exact=True).click()
+  page.set_viewport_size({'width':320,'height':480})
+  page.get_by_role('button',name='导航',exact=True).click()
+  page.evaluate('window.fixtureEvents.onmessage({data:JSON.stringify({type:"run_status",thread_id:"fixture-1",status:"llm"})})')
+  for selector in ['#text','#sendGo','#stopGo']:
+   assert page.locator(selector).evaluate('(el)=>{const r=el.getBoundingClientRect();return r.bottom<=innerHeight && el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2))}')
+  page.get_by_role('button',name='停止',exact=True).click()
+  assert ('POST','/api/abort') in requests
+  page.evaluate('window.fixtureEvents.onmessage({data:JSON.stringify({type:"chat.aborted",thread_id:"fixture-1"})})')
+  assert not page.locator('#stopGo').is_visible()
+  page.keyboard.press('Escape')
+  assert not page.locator('#hud').evaluate('(el)=>el.classList.contains("history")')
+  page.screenshot(path=str(shots/'summoner-477-narrow.png'))
   with page.expect_file_chooser():page.get_by_role('button',name='添加附件',exact=True).click()
   text.fill('请整理变更材料');page.get_by_role('button',name='发送',exact=True).click()
   page.wait_for_timeout(200);assert ('POST','/api/chat') in requests
diff --git a/companion/tests/summoner-web.test.ts b/companion/tests/summoner-web.test.ts
index 677dab81..7588f9ca 100644
--- a/companion/tests/summoner-web.test.ts
+++ b/companion/tests/summoner-web.test.ts
@@ -162,7 +162,7 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     assert.match(r.body, /--indigo:#4f46e5/)
     assert.match(r.body, /class="rail-btn"/)
     assert.match(r.body, /data-sec="threads"[^>]*aria-current="true"/)
-    assert.match(r.body, /data-sec="mcp"[^>]*\bhidden\b/)
+    assert.doesNotMatch(r.body, /data-sec="mcp"[^>]*\bhidden\b/)
     assert.doesNotMatch(r.body, /＋ 添加 MCP|＋ 导入知识/)
     assert.match(r.body, /html,body\{height:100%;width:100%;overflow:hidden\}/)
     assert.match(r.body, /class="list-scroll"/)
@@ -171,7 +171,7 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     assert.match(r.body, /class="hud expanded"/)
     assert.match(r.body, /setExpanded\(true\)/)
     assert.doesNotMatch(r.body, /placeWindow\(false\);/)
-    assert.match(r.body, /var w=360,h=420/)
+    assert.match(r.body, /var w=1040,h=760/)
     assert.match(r.body, /id="empty"/)
     assert.doesNotMatch(r.body, /class="mark"/)
     assert.doesNotMatch(r.body, />山<\/div>/)
@@ -179,7 +179,7 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     assert.match(r.body, /#newThreadBar\{[^}]*display:none/)
     assert.match(r.body, /id="historyOpen"/)
     assert.match(r.body, /id="newChat"/)
-    assert.match(r.body, />历史</)
+    assert.match(r.body, />导航</)
     assert.match(r.body, /id="newChat">新对话/)
     assert.match(r.body, /id="historyClose"/)
     assert.match(r.body, /\.hud\.history \.list\{[^}]*display:flex/)
@@ -1083,6 +1083,20 @@ describe("summoner-web server", { concurrency: 1 }, () => {
     assert.deepEqual(attachCalls, [{ foreground: true }])
   })
 
+  test("#477 browser status requires authentication and follows the real peer predicate", async () => {
+    let connected = false
+    await startSummonerWebServer({ preferredPort: 23510,
+      dispatch: async () => ({ type: "ok" }), hasExtensionPeer: () => connected })
+    const denied = await request({ method: "GET", port, path: "/api/browser-status" })
+    assert.equal(denied.status, 403)
+    for (const value of [false, true, false]) {
+      connected = value
+      const r = await request({ method: "GET", port, path: `/api/browser-status?token=${token}` })
+      assert.equal(r.status, 200)
+      assert.deepEqual(JSON.parse(r.body), { connected: value })
+    }
+  })
+
   test("POST /api/operate no extension peer is 503 not ok", async () => {
     attachCalls.length = 0
     let opened = 0
@@ -1652,9 +1666,9 @@ test("HTML default expands the face (not 120px bar)", () => {
   assert.doesNotMatch(html, /placeWindow\(false\);/)
 })
 
-test("MCP rail stays hide-not-delete", () => {
+test("#477 MCP rail is visible and remains read-only", () => {
   const html = fs.readFileSync(srcFile("summoner-web.ts"), "utf8")
-  assert.match(html, /data-sec="mcp"[^>]*\bhidden\b|hidden[^>]*data-sec="mcp"/)
+  assert.doesNotMatch(html, /data-sec="mcp"[^>]*\bhidden\b|hidden[^>]*data-sec="mcp"/)
   assert.doesNotMatch(html, /mcp\.toggle_server/)
 })
 
