Independent follow-up review for Issue #490. Production code is unchanged from the full review packet. Only test-knowledge-graph-ui.py gained actual keyboard and trusted pointer-cancel regression coverage. Review this test-only delta and adjudicate the earlier DeepSeek claims using concrete evidence. Do not rubber-stamp the author's arguments; retain REJECT if an actual blocker remains. End VERDICT: APPROVE | APPROVE_WITH_NITS | REJECT.

Evidence to assess:
1. W3C Pointer Events3 section9.5 https://www.w3.org/TR/pointerevents3/#implicit-release-of-pointer-capture specifies that after pointerup OR pointercancel the browser clears capture and processes lostpointercapture. Thus cancel must not be treated as click completion. Actual Chrome CDP trusted touch events below confirm capture true→false and no residual drag or document/edge activation, with no production change.
2. Prior report calls lost-result timeout error one-way, but applySnap explicitly calls setRequestError("") for every accepted snapshot, including organizing:false. Full source below. Assess whether the P1-3 claim is supported.
3. Prior report speculates offline callback cannot detect companion-offline. Actual background immediately returns {ok:true,sent} where sent=wsClient?.send(frame)===true; false sends are detected. No claim is made that this UI detects every hung server after a successful send: rebuilding has bounded polling, organization has bounded waiting, ordinary cached reads retain usable snapshot. Treat broader hung-peer watchdog as separate robustness work, not a demonstrated send-layer failure.
4. Resize deliberately fits the new actual canvas area so shrinking/expanding list and mobile/desktop reflow preserve visibility; fit-on-reflow is an explicit UX decision. Localization is immediate and respects reduced-motion; animation is not a DoD requirement. Per-render string computation at <=200 nodes is a nonblocking future optimization with no measured frame defect.
5. The model report labels several conjectures P1 but finishes APPROVE_WITH_NITS, and includes self-refuted 'findings'. Please provide a coherent final severity/verdict, distinguishing verified issues, nonblocking observations and disproven claims.


### deepseek-review.md
## Independent Read-Only Review — CMspark Issue #490

### Scope and trajectory assessment

The change is a T2 panel-only knowledge graph usability repair. Base aada096a exhibits a concrete rendering failure — canvas 300×150, zero draw calls, zero opaque pixels despite 4 real snapshot nodes. The proposed diff fixes the mount lifecycle (`useEffect []` → `[showCanvas]`), adds a searchable list, camera controls, refresh recovery, and an honest `organizing` job-state flag. The backend lane fix (`buildKnowledgeGraph` gating stale LLM groups on `llmLane`) addresses a real cross-lane contamination bug where unlocked LLM groups leaked into the ≥20 TF lane without corresponding labels. The diff does not touch transport, trust, actions, permissions, or user data/config. The plan explicitly scopes out threshold/retrieval/content changes and preserves all existing AI naming, organizing, lock/unlock, and provenance capabilities.

The machine evidence is substantive: the baseline capture reproduces the dead canvas; the after-capture shows real pixel drawing at 1/4/20/200 nodes; the Python suite exercises delayed storage, stale-result race protection, error→refresh remount, responsive 320/760/1440, search/group intersection never dropping graph data, and the dashed AI/solid similarity distinction with pixel-level probes. Backend logs show 52→54 green tests with targeted red-green organize lifecycle evidence. The fixture harness reads the production `knowledgeGraphFrame` serializer from source rather than hand-copying wire keys — this materially strengthens the evidence quality.

### Findings

**P0**: None found. The canvas lifecycle fix is directly evidenced by the before/after capture against the stated base. The stale-storage guard (`receivedSnapshot`) prevents a legitimate race that would otherwise re-introduce the blank canvas under delayed `session.get` vs `onChanged`. No trust/ACL expansion; the only new wire field (`organizing`) is additive, optional, and parse-fail closed.

**P1-1: `onPointerCancel` behavior change — potential stuck drag state.**

The diff changes the cancel handler from:

```
onPointerCancel={(ev) => endDrag(ev)}
```

to:

```
onPointerCancel={() => { dragRef.current = null }}
```

Whereas the old code routed pointer cancel through the full `endDrag` (which would run the click-to-locate or edge-open path if `moved` was false), the new code just nulls the drag ref. This means a pointer cancel on a node or edge no longer triggers document selection or edge-reason opening. More importantly, if the browser fires `pointercancel` without a corresponding `pointerup`, `endDrag` never runs its `releasePointerCapture` cleanup. In practice Chrome generally fires `pointerup` after `pointercancel`, so the practical impact is likely minor, but the asymmetry is real. This is a P1 because pointer capture leaks or missed selection on OS-level gesture interrupts (e.g., trackpad accidental gestures, window focus loss during drag) would degrade the interaction the issue set out to improve. It is not a regression from the base’s drawing failure, but it is a newly introduced interactive defect within this diff.

Location: `KnowledgeGraphApp.tsx`, canvas `onPointerCancel`.

Recommendation: reproduce the `pointercancel` path in the fixture and either route through `endDrag` or explicitly call `releasePointerCapture` before nulling the ref.

**P1-2: `refresh` guard `res?.ok` on Chrome runtime callback response is too weak for the claimed error state.**

The new `refresh` callback checks `chrome.runtime.lastError || res?.ok === false || res?.sent === false`, but the baseline code path in the visible fixture (`window.chrome.runtime.sendMessage` in the test harness) only ever responds with `{ sent: !window.sendFailure }`. In the real extension background, `chrome.runtime.sendMessage` from the content side to the service worker does *not* produce a `chrome.runtime.lastError` merely because the companion is offline — if the service worker is alive, it may respond with an ACK or error only after its own round-trip. The UI then relies on `applySnap`/`onChanged` to eventually deliver a failure frame. The `requestError` path is thus only partially reachable: it catches send-time failure but cannot reliably distinguish “companion did not respond” from “companion responded with an error frame.” That weakens the claimed “offline/failed distinct recovery copy” DoD item, because a hung companion can leave the refresh promise pending indefinitely without UI signal. The backend tests cover error frames, but nothing in the evidence exercises the extension transport failure at the service-worker level (only the synthetic `sendFailure` injection). This is a scope-relevant, P1 confidence gap rather than a proven user-facing defect.

Recommendation: either add a bounded timeout to `chrome.runtime.sendMessage` responses and surface “no response” as a distinct state, or explicitly claim “disconnected transport at the send layer” in the DoD and leave companion-hang detection to a separate ticket. As written, the copy claims “请确认程序运行后刷新图谱” which may not fire in the hang case.

**P1-3: `organizing` state races when the organize response is lost.**

When `sendOrganize` is clicked, the UI sets `organizing = true` locally. It then relies on either (a) the `knowledge.graph` response carrying `organizing: true` (from `knowledgeGraphOrganizeRun !== null`), or (b) the later push with `organizing: false` to clear the busy state. If the extension’s transport to the companion succeeds but the completion push is lost (e.g., service worker kill during the async LLM settle, or the push fails silently because the panel tab was closed/reopened), the UI has a 35-second timer that falls back to clearing `organizing` and showing “尚未收到整理结果.” That is the honest fallback, but it doesn’t recover the actual job state — a subsequent manual “refresh” would still be required. This is acceptable for a T2 repair, but the 35s fallback is a fixed magic number that can show the “尚未收到” copy while the job actually completes successfully later (the push may arrive after the timeout and set `organizing: false`, but the previous error copy remains). The evidence tests the fixture-level `organizing` transition, not the lost-push window. P1 nit-grade: the state machine is one-way for the error message and may mislead the user during slow-but-successful organization.

Location: `KnowledgeGraphApp.tsx`, `sendOrganize`, the 35s `setTimeout`, and `onActionResponse`.

Recommendation: when a push with `organizing: false` arrives, also clear the `requestError` if it was the “尚未收到整理结果” message, to correct the stale state.

**P2-1: `refresh` is a dependency of the mounting `useEffect` but is recreated on each render.**

`refresh` is `useCallback`-wrapped with `[]` deps, so it is stable across renders. The mount `useEffect` lists `[applySnap, refresh]` — both stable. No churn. This is fine; not a finding.

**P2-2: `fitView` called from `ResizeObserver` may clobber camera during a user drag/zoom.**

In the `resize` handler, the code unconditionally calls `fitViewRef.current()` whenever the parent container’s size changes, even if `userCameraRef.current` is true. During a live resize (e.g., opening a devtools panel, window snap on Windows), the user’s deliberate pan/zoom is discarded. The responsive test suite asserts non-overlapping layout and correct bitmap dimensions, but it does not assert camera preservation across a resize while the user has a custom camera. This is a minor UX regression from the base (which also reset camera on effect, but didn’t have a resize observer). P2.

Recommendation: in `resize`, skip `fitViewRef.current()` when `userCameraRef.current` is true, or clamp the existing pan/scale to the new geometry.

**P2-3: `locateNode` sets `scaleRef.current = Math.max(1, scaleRef.current)` but doesn’t recompute pan after forcing scale up.**

If the user is zoomed out to 0.08× and clicks a list node, `scaleRef.current` jumps to 1 instantly, then `panRef` is set to `{ x: w/2 - n.x * scale, y: h/2 - n.y * scale }`. Since `scale` is now 1, the node is centered correctly on screen. But the visual jump is abrupt and may feel like a bug; the base had no list or locate, so this is new behavior, not a regression. The code doesn’t animate the transition, which may be acceptable for a T2 repair but conflicts with the “calm, precise” design language in DESIGN.md. Nil-grade.

**Nit-1: `relatedEdges` recomputed inline in render, bypassing `useMemo`.**

`relatedEdges` maps `payloadEdges` and `payloadRelations` through `knowledgeGraphPairKey` on every render to find the selected node’s relations. This is O(n) with string concatenation in a hot path that re-renders on every `hoverCaptionText` change (because `setHoverCaptionText` in `onPointerMove` triggers a state update per pointer event, which re-renders the component, which recomputes `relatedEdges`). With 200 nodes and up to 12 relations this is not a practical problem on modern hardware, but it’s unnecessary churn. The base didn’t have this compute at all. A `useMemo` keyed on `[selected, payloadEdges, payloadRelations]` would be cleaner and aligns with the existing `useMemo` discipline elsewhere in the component.

**Nit-2: `selected` depends on `payloadNodes.find(n => n.id === focusId)` but `focusId` can be set from an old snapshot’s `focus_id` before the new snapshot is applied.**

The mount/effect cleans up invalid `focusId` when `showCanvas` turns true, so the stale `focusId` from an error/rebuilding frame is dropped when the new snapshot mounts. This is correct, but only because `showCanvas` is `false` during error/rebuilding, so the cleanup effect (gated on `showCanvas`) won’t run until a real node set is available. If a snapshot had `focus_id` set to an id that exists in fewer than all documents (e.g., a doc outside the 200-doc truncation cap), the cleanup runs and clears selection — reasonable. No change needed; noted for re-review.

**Nit-3: `KnowledgeGraphApp` keeps `captionByIdRef` and `nodesByIdRef` on `useMemo`/`useEffect` boundaries, but `shortKnowledgeTitle` is computed inside the `requestAnimationFrame` draw loop for every node, every frame.**

`shortKnowledgeTitle` calls `Array.from(title.trim() || id)`, iterates, slices, and joins each frame for up to 200 nodes at ~60 fps. This is a measurable but likely sub-millisecond cost at 200 nodes; the base app did no title computation at all. Could be memoized per node in the `useEffect` that builds `nodesByIdRef`. Nit.

---

### Regression vs. existing issues

- **Base blank canvas**: regression of the base’s failure, fully addressed with direct before/after evidence at the same base commit. This is the core fix.
- **Stale unlocked LLM groups at >=20**: base bug, fixed in backend with targeted red-green tests including lock preservation and label completeness.
- **`onPointerCancel`**: newly introduced behavior change in this diff, cannot be attributed to base.
- **Refresh error detection**: pre-existing general limitation of `chrome.runtime.sendMessage` callback semantics, now surfaced more prominently by the new refresh UI but not caused by this diff.
- **Camera reset on resize**: new interaction introduced by the `ResizeObserver` and `fitView` call; base had no resize observer.

### Verdict

The diff successfully fixes the original blank-canvas regression at the stated base commit, preserves all existing capabilities, and adds the requested discoverability features without scope creep into trust/ACL/data. The backend `organizing` field is correctly optional and parse-fail closed. The evidence is genuine: the production serializer is sourced from the router, the baseline is captured at aada096a, and pixel assertions validate real drawing.

The P1 items are all within the new interaction surface rather than the core rendering repair, and none of them nullify the central fix. They are, however, concrete and reproducible in the source with plausible user-visible consequences.

**VERDICT: APPROVE_WITH_NITS**
### pointercancel.json
{
  "pointerId": 2,
  "captureAfterStart": true,
  "captureAfterCancel": false,
  "events": [
    {
      "type": "pointerdown",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "gotpointercapture",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "pointermove",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "pointercancel",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "lostpointercapture",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": false
    }
  ],
  "cameraAfterCancel": {
    "x": 599.7991769234495,
    "y": 245.94908814362964,
    "r": 8.00000011920929
  },
  "cameraAfterUnpressedMoves": {
    "x": 599.7991769234495,
    "y": 245.94908814362964,
    "r": 8.00000011920929
  }
}

### ui-pointercancel.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection
PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves
POINTERCANCEL EVIDENCE {"pointerId": 2, "captureAfterStart": true, "captureAfterCancel": false, "events": [{"type": "pointerdown", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "gotpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointermove", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointercancel", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "lostpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": false}], "cameraAfterCancel": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}, "cameraAfterUnpressedMoves": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}}
PASS production organized group filtering and readable AI relationship reason
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### ui-keyboard.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection
PASS production organized group filtering and readable AI relationship reason
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### Current full chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
```
// Full-page knowledge distribution graph.
// Spec: docs/superpowers/specs/2026-09-04-knowledge-graph-view-design.md
// Layout: reuse thread-graph force-layout; positions/edges are not persisted.

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type PointerEvent as ReactPointerEvent,
  type WheelEvent as ReactWheelEvent,
} from "react"
import { forceLayoutTick, seedLayoutNodes, type LayoutNode } from "../thread-graph/force-layout"
import { hexWithAlpha, lightenHex, UNTAGGED_COLOR } from "../thread-graph/tag-colors"
import { tokens } from "../sidepanel/ui/tokens"
import { filterKnowledgeNodes, fitKnowledgeCamera, shortKnowledgeTitle } from "./explorer"
import {
  KNOWLEDGE_GRAPH_SNAPSHOT_KEY,
  type KnowledgeGraphSnapshot,
} from "../background/knowledge-graph"
import {
  KnowledgeGraphColorSwitch,
  KnowledgeGraphGroupCard,
  KnowledgeGraphLlmSwitch,
  KnowledgeGraphLockDissolvedBanner,
  KnowledgeGraphNoRelationsNote,
  KnowledgeGraphOrganizeCta,
  KnowledgeGraphOrganizeErrorBar,
  KnowledgeGraphReorganizeButton,
  KnowledgeGraphStaleBadge,
  KnowledgeGraphStatusView,
  KnowledgeGraphTfSwitchBanner,
} from "./chrome"
import { hoverCaption, nodeColor, type ColorMode } from "./coloring"
import {
  KNOWLEDGE_GRAPH_AI_RELATION,
  KNOWLEDGE_GRAPH_ENTRY_LABEL,
  KNOWLEDGE_GRAPH_REASON_DISMISS,
  KNOWLEDGE_GRAPH_UNGROUPED_LABEL,
  knowledgeGraphBarMeta,
  shouldRenderGraphCanvas,
} from "./copy"
import {
  KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
  parseLlmLabelsPref,
  parseTfSwitchAck,
  writeLlmLabelsPref,
  writeTfSwitchAck,
  KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
} from "./llm-pref"
import {
  knowledgeGraphPairKey,
  knowledgeGraphViewModel,
  parseKnowledgeGraphPayload,
  type KnowledgeGraphNode,
  type KnowledgeGraphRelation,
} from "./wire"

type GraphDrawEdge = { a: string; b: string; score: number; dashed?: boolean; reason?: string }

const G = {
  canvas: tokens.darkBg,
  edgeSoft: "rgba(148, 163, 184, 0.22)",
  edgeHot: "rgba(165, 180, 252, 0.75)",
  edgeDim: "rgba(148, 163, 184, 0.06)",
  labelFocus: "rgba(248, 250, 252, 0.95)",
} as const

const HIT_PAD = 8
const REBUILD_POLL_MS = 2500
/** 重建轮询上限（复审 NIT-5）：40 × 2.5s = 100s 后停轮询，诚实提示手动刷新。 */
const REBUILD_POLL_MAX = 40
const EMPTY_NODES: KnowledgeGraphNode[] = []
const EMPTY_EDGES: NonNullable<KnowledgeGraphSnapshot["edges"]> = []
const EMPTY_LABELS: KnowledgeGraphSnapshot["labels"] = {}

function radiusForDegree(deg: number): number {
  return Math.min(10, 5 + Math.sqrt(deg) * 1.4)
}

export function KnowledgeGraphApp() {
  const [snap, setSnap] = useState<KnowledgeGraphSnapshot | null>(null)
  const [colorMode, setColorMode] = useState<ColorMode>("group")
  const [llmEnabled, setLlmEnabled] = useState(false)
  const llmEnabledRef = useRef(false)
  const [focusId, setFocusId] = useState<string | null>(null)
  const [hoverCaptionText, setHoverCaptionText] = useState("")
  const [panelOpen, setPanelOpen] = useState(true)
  const [query, setQuery] = useState("")
  const [groupFilter, setGroupFilter] = useState("")
  const [requestError, setRequestError] = useState("")

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nodesRef = useRef<LayoutNode[]>([])
  const edgesRef = useRef<GraphDrawEdge[]>([])
  const dragRef = useRef<{ id: string; ox: number; oy: number; moved: boolean } | null>(null)
  const [organizing, setOrganizing] = useState(false)
  const [relationOpen, setRelationOpen] = useState<KnowledgeGraphRelation | null>(null)
  const [tfAcked, setTfAcked] = useState(false)
  const [lockNotice, setLockNotice] = useState(false)
  const panRef = useRef({ x: 0, y: 0 })
  const scaleRef = useRef(1)
  const rafRef = useRef(0)
  const sizeRef = useRef({ w: 800, h: 600 })
  const simTicksRef = useRef(0)
  const hoverIdRef = useRef<string | null>(null)
  const focusIdRef = useRef<string | null>(null)
  const fittedRef = useRef(false)
  const userCameraRef = useRef(false)
  const colorByIdRef = useRef<Map<string, string>>(new Map())
  const nodesByIdRef = useRef<Map<string, KnowledgeGraphNode>>(new Map())
  const fitViewRef = useRef<() => void>(() => {})
  const captionByIdRef = useRef<Map<string, string>>(new Map())

  useEffect(() => {
    focusIdRef.current = focusId
  }, [focusId])

  const applySnap = useCallback((raw: unknown) => {
    const parsed = parseKnowledgeGraphPayload(raw)
    if (!parsed) return
    const rec = raw as Record<string, unknown>
    setSnap({
      ...parsed,
      ts: typeof rec.ts === "number" ? rec.ts : Date.now(),
      focus_id: typeof rec.focus_id === "string" ? rec.focus_id : null,
      llm_labels: rec.llm_labels === true,
    })
    if (typeof rec.focus_id === "string" && rec.focus_id) setFocusId(rec.focus_id)
    setOrganizing(parsed.organizing === true)
    setRequestError("")
  }, [])

  const refresh = useCallback(() => {
    // Preserve the existing user-authorized naming preference. Default reads
    // never enable naming or organization on the user's behalf.
    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", llm_labels: llmEnabledRef.current }, (res) => {
      if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
        setRequestError("无法连接 CMspark，请确认程序运行后刷新图谱。已有快照可继续浏览。")
      } else setRequestError("")
    })
  }, [])

  useEffect(() => {
    let cancelled = false
    let receivedSnapshot = false
    ;(async () => {
      try {
        const pref = await chrome.storage.local.get([
          KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
          KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
        ])
        if (!cancelled) {
          llmEnabledRef.current = parseLlmLabelsPref(pref[KNOWLEDGE_GRAPH_LLM_LABELS_KEY])
          setLlmEnabled(llmEnabledRef.current)
          setTfAcked(parseTfSwitchAck(pref[KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY]))
        }
      } catch {
        /* default off */
      }
      try {
        const res = await chrome.storage.session.get(KNOWLEDGE_GRAPH_SNAPSHOT_KEY)
        if (cancelled) return
        if (!receivedSnapshot) applySnap(res[KNOWLEDGE_GRAPH_SNAPSHOT_KEY])
      } catch {
        /* empty → rebuilding banner via null snap */
      }
      if (!cancelled) refresh()
    })()
    const onStorage = (
      changes: Record<string, chrome.storage.StorageChange>,
      area: string,
    ) => {
      if (area === "session" && changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY]) {
        receivedSnapshot = true
        applySnap(changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY].newValue)
      }
      if (area === "local" && changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]) {
        llmEnabledRef.current = parseLlmLabelsPref(changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY].newValue)
        setLlmEnabled(llmEnabledRef.current)
      }

    }
    chrome.storage.onChanged.addListener(onStorage)
    return () => {
      cancelled = true
      chrome.storage.onChanged.removeListener(onStorage)
    }
  }, [applySnap, refresh])

  const status = snap?.status ?? "rebuilding"
  const truncated = snap?.truncated === true
  const showCanvas = snap ? shouldRenderGraphCanvas(status) : false
  const [pollExhausted, setPollExhausted] = useState(false)

  useEffect(() => {
    if (status !== "rebuilding") {
      setPollExhausted(false)
      return
    }
    // 复审 NIT-5：轮询加上限（40 × 2.5s = 100s），打满停轮询并诚实提示手动刷新。
    let polls = 0
    const tick = () => {
      polls += 1
      if (polls > REBUILD_POLL_MAX) {
        setPollExhausted(true)
        clearInterval(id)
        return
      }
      refresh()
    }
    const id = setInterval(tick, REBUILD_POLL_MS)
    return () => clearInterval(id)
  }, [status, refresh])

  const payloadNodes = snap?.nodes ?? EMPTY_NODES
  const payloadEdges = snap?.edges ?? EMPTY_EDGES
  const labels = snap?.labels ?? EMPTY_LABELS
  const view = useMemo(() => knowledgeGraphViewModel(snap), [snap])
  const { llmLane, showOrganizeCta, showReorganize, showNoRelations, relationsToDraw } = view
  const payloadRelations = relationsToDraw
  const llmReady = snap?.llm_ready !== false
  const showTfBanner =
    (status === "ok" || status === "over_cap") &&
    payloadNodes.length >= 20 &&
    (snap?.tf_switch_notice === true || (snap?.tf_switch_notice !== false && !tfAcked))

  const groupKeys = useMemo(() => {
    const seen = new Set<string>()
    const keys: string[] = []
    for (const n of payloadNodes) {
      const k = n.group_key || "u:ungrouped"
      if (seen.has(k)) continue
      seen.add(k)
      keys.push(k)
    }
    return keys
  }, [payloadNodes])

  const visibleNodes = useMemo(() => filterKnowledgeNodes(payloadNodes, query, groupFilter), [payloadNodes, query, groupFilter])
  const selected = payloadNodes.find((n) => n.id === focusId)
  useEffect(() => {
    if (!showCanvas) return
    if (focusId && !payloadNodes.some((n) => n.id === focusId)) setFocusId(null)
    if (groupFilter && !groupKeys.includes(groupFilter)) setGroupFilter("")
  }, [payloadNodes, groupKeys, focusId, groupFilter, showCanvas])

  useEffect(() => {
    const degree = new Map<string, number>()
    for (const n of payloadNodes) degree.set(n.id, 0)
    for (const e of payloadEdges) {
      degree.set(e.a, (degree.get(e.a) || 0) + 1)
      degree.set(e.b, (degree.get(e.b) || 0) + 1)
    }
    for (const r of payloadRelations) {
      degree.set(r.a, (degree.get(r.a) || 0) + 1)
      degree.set(r.b, (degree.get(r.b) || 0) + 1)
    }
    const ids = payloadNodes.map((n) => n.id)
    const radiusById = new Map(ids.map((id) => [id, radiusForDegree(degree.get(id) || 0)]))
    const { w, h } = sizeRef.current
    const previous = new Map(nodesRef.current.map((n) => [n.id, n]))
    nodesRef.current = seedLayoutNodes(ids, w, h, radiusById).map((n) => {
      const old = previous.get(n.id)
      return old ? { ...old, r: n.r } : n
    })
    const tfKeys = new Set(payloadEdges.map((e) => knowledgeGraphPairKey(e.a, e.b)))
    const reasonByPair = new Map<string, string>()
    for (const r of payloadRelations) {
      reasonByPair.set(knowledgeGraphPairKey(r.a, r.b), r.reason)
    }
    const drawn: GraphDrawEdge[] = payloadEdges.map((e) => ({
      a: e.a,
      b: e.b,
      score: e.score,
      reason: reasonByPair.get(knowledgeGraphPairKey(e.a, e.b)),
    }))
    for (const r of payloadRelations) {
      const k = knowledgeGraphPairKey(r.a, r.b)
      if (tfKeys.has(k)) continue
      drawn.push({ a: r.a, b: r.b, score: Math.max(0.08, r.confidence), dashed: true, reason: r.reason })
    }
    edgesRef.current = drawn
    simTicksRef.current = 0
    fittedRef.current = false
    userCameraRef.current = false
  }, [payloadNodes, payloadEdges, payloadRelations])

  useEffect(() => {
    const byId = new Map(payloadNodes.map((n) => [n.id, n]))
    nodesByIdRef.current = byId
    const colors = new Map<string, string>()
    const captions = new Map<string, string>()
    for (const n of payloadNodes) {
      colors.set(n.id, nodeColor(n, colorMode))
      captions.set(n.id, hoverCaption(n, colorMode, labels))
    }
    colorByIdRef.current = colors
    captionByIdRef.current = captions
  }, [payloadNodes, colorMode, labels])

  const openDoc = useCallback((id: string) => {
    setFocusId(id)
    setPanelOpen(true)
    chrome.runtime.sendMessage({ type: "knowledge_graph.open_doc", id }, () => {
      void chrome.runtime.lastError
    })
  }, [])

  const onActionResponse = useCallback((res: { ok?: boolean; sent?: boolean } | undefined) => {
    if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
      setOrganizing(false)
      setRequestError("请求未发送，请确认 CMspark 运行后重试。")
    }
  }, [])

  useEffect(() => {
    if (!organizing) return
    const timer = setTimeout(() => {
      setOrganizing(false)
      setRequestError("尚未收到整理结果，请刷新查看当前状态后重试。")
    }, 35_000)
    return () => clearTimeout(timer)
  }, [organizing])

  const onLlmChange = useCallback((enabled: boolean) => {
    llmEnabledRef.current = enabled
    setLlmEnabled(enabled)
    void writeLlmLabelsPref(enabled)
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", llm_labels: enabled },
      onActionResponse,
    )
  }, [onActionResponse])

  const onRegenerate = useCallback(() => {
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", llm_labels: true, regenerate: true },
      onActionResponse,
    )
  }, [onActionResponse])

  const sendOrganize = useCallback(() => {
    setOrganizing(true)
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", organize: true, llm_labels: llmEnabled },
      onActionResponse,
    )
  }, [llmEnabled, onActionResponse])

  const sendLock = useCallback((groupKey: string, unlock: boolean) => {
    chrome.runtime.sendMessage(
      {
        type: "knowledge_graph.refresh",
        llm_labels: llmEnabled,
        ...(unlock ? { unlock_group: groupKey } : { lock_group: groupKey }),
      },
      onActionResponse,
    )
  }, [llmEnabled, onActionResponse])

  useEffect(() => {
    if (snap?.lock_dissolved === true) setLockNotice(true)
  }, [snap?.lock_dissolved])

  useEffect(() => {
    if (!showTfBanner) return
    // 本会话继续展示；落盘 ack 让关 tab 重开不再出现（AC-6）。
    void writeTfSwitchAck()
    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", ack_tf_switch: true, llm_labels: llmEnabledRef.current }, () => {
      void chrome.runtime.lastError
    })
  }, [showTfBanner])

  const fitView = useCallback(() => {
    const { w, h } = sizeRef.current
    const camera = fitKnowledgeCamera(nodesRef.current, w, h)
    scaleRef.current = camera.scale
    panRef.current = { x: camera.x, y: camera.y }
    fittedRef.current = true
  }, [])
  fitViewRef.current = fitView

  const locateNode = useCallback((id: string) => {
    const n = nodesRef.current.find((node) => node.id === id)
    if (!n) return
    setFocusId(id)
    setPanelOpen(true)
    simTicksRef.current = 999
    userCameraRef.current = true
    scaleRef.current = Math.max(1, scaleRef.current)
    panRef.current = { x: sizeRef.current.w / 2 - n.x * scaleRef.current, y: sizeRef.current.h / 2 - n.y * scaleRef.current }
  }, [])

  const zoom = useCallback((factor: number) => {
    const prev = scaleRef.current
    const next = Math.min(3.2, Math.max(0.08, prev * factor))
    const { w, h } = sizeRef.current
    panRef.current = { x: w / 2 - ((w / 2 - panRef.current.x) / prev) * next, y: h / 2 - ((h / 2 - panRef.current.y) / prev) * next }
    scaleRef.current = next
    userCameraRef.current = true
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const parent = canvas.parentElement
    if (!parent) return
    const resize = () => {
      const rect = parent.getBoundingClientRect()
      const dpr = window.devicePixelRatio || 1
      sizeRef.current = { w: rect.width, h: rect.height }
      canvas.width = Math.max(1, Math.floor(rect.width * dpr))
      canvas.height = Math.max(1, Math.floor(rect.height * dpr))
      canvas.style.width = `${rect.width}px`
      canvas.style.height = `${rect.height}px`
      const ctx = canvas.getContext("2d")
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      // Reflow changes the actual canvas area, not an overlay on the old area.
      fitViewRef.current()
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(parent)
    const draw = () => {
      const ctx = canvas.getContext("2d")
      if (!ctx) return
      const { w, h } = sizeRef.current
      const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
      for (let step = 0; step < (reduceMotion ? 320 : 6) && simTicksRef.current < 320 && nodesRef.current.length > 0; step++) {
        const e = forceLayoutTick(nodesRef.current, edgesRef.current, { width: w, height: h })
        simTicksRef.current++
        if ((e < 0.06 && simTicksRef.current > 50) || simTicksRef.current >= 320) {
          simTicksRef.current = 999
          if (!userCameraRef.current) fitViewRef.current()
        }
      }
      if (!fittedRef.current && !userCameraRef.current) fitViewRef.current()
      ctx.clearRect(0, 0, w, h)
      ctx.fillStyle = G.canvas
      ctx.fillRect(0, 0, w, h)
      ctx.save()
      ctx.translate(panRef.current.x, panRef.current.y)
      ctx.scale(scaleRef.current, scaleRef.current)
      const byId = new Map(nodesRef.current.map((n) => [n.id, n]))
      const active = hoverIdRef.current || focusIdRef.current
      let hot: Set<string> | null = null
      if (active) {
        hot = new Set([active])
        for (const e of edgesRef.current) {
          if (e.a === active) hot.add(e.b)
          if (e.b === active) hot.add(e.a)
        }
      }
      const scale = scaleRef.current
      for (const e of edgesRef.current) {
        const a = byId.get(e.a)
        const b = byId.get(e.b)
        if (!a || !b) continue
        const isHot = hot ? hot.has(e.a) && hot.has(e.b) : false
        ctx.beginPath()
        ctx.moveTo(a.x, a.y)
        ctx.lineTo(b.x, b.y)
        ctx.strokeStyle = hot != null && !isHot ? G.edgeDim : isHot ? G.edgeHot : G.edgeSoft
        ctx.lineWidth = Math.min(1.6, 0.4 + e.score * 0.5) / Math.max(0.6, scale)
        if (e.dashed) ctx.setLineDash([5 / Math.max(0.6, scale), 4 / Math.max(0.6, scale)])
        else ctx.setLineDash([])
        ctx.stroke()
        ctx.setLineDash([])
        if (e.dashed && (hot == null || isHot)) {
          const mx = (a.x + b.x) / 2
          const my = (a.y + b.y) / 2
          ctx.fillStyle = G.labelFocus
          ctx.font = `${9 / Math.max(0.75, Math.min(1.25, scale))}px ${tokens.font}`
          ctx.textAlign = "center"
          ctx.textBaseline = "bottom"
          ctx.fillText(KNOWLEDGE_GRAPH_AI_RELATION, mx, my - 2)
        }
      }
      const labelBoxes: { x: number; y: number; w: number; h: number }[] = []
      // Selected titles take priority; collisions only suppress canvas labels,
      // never the complete accessible knowledge list.
      const drawNodes = [...nodesRef.current].sort((a, b) => Number(b.id === active) - Number(a.id === active))
      for (const n of drawNodes) {
        const isFocus = n.id === focusIdRef.current
        const isHover = n.id === hoverIdRef.current
        const inHot = hot ? hot.has(n.id) : true
        const dimmed = hot != null && !inHot
        const baseColor = colorByIdRef.current.get(n.id) || UNTAGGED_COLOR
        if (isFocus || isHover) {
          ctx.beginPath()
          ctx.arc(n.x, n.y, n.r + 3.5, 0, Math.PI * 2)
          ctx.fillStyle = hexWithAlpha(baseColor, isFocus ? 0.28 : 0.18)
          ctx.fill()
        }
        ctx.beginPath()
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
        ctx.fillStyle = isFocus
          ? lightenHex(baseColor, 0.45)
          : isHover
            ? lightenHex(baseColor, 0.28)
            : dimmed
              ? hexWithAlpha(baseColor, 0.7)
              : baseColor
        ctx.globalAlpha = 1
        ctx.fill()
        ctx.globalAlpha = 1
        {
          ctx.fillStyle = dimmed ? tokens.darkMuted : G.labelFocus
          ctx.font = `${13 / scale}px ${tokens.font}`
          ctx.textAlign = "center"
          ctx.textBaseline = "top"
          const doc = nodesByIdRef.current.get(n.id)
          const cap = shortKnowledgeTitle(doc?.title || "", n.id, nodesRef.current.length <= 20 ? 18 : 12)
          const textWidth = ctx.measureText(cap).width * scale
          const sx = n.x * scale + panRef.current.x
          const sy = (n.y + n.r) * scale + panRef.current.y + 7
          const box = { x: sx - textWidth / 2, y: sy, w: textWidth, h: 17 }
          const overlaps = labelBoxes.some((b) => box.x < b.x + b.w + 8 && box.x + box.w + 8 > b.x && box.y < b.y + b.h + 4 && box.y + box.h + 4 > b.y)
          if ((isFocus || isHover || !overlaps) && box.x >= 2 && box.x + box.w <= w - 2 && sy + 17 < h) {
            labelBoxes.push(box)
            ctx.fillText(cap, n.x, n.y + n.r + 7 / scale)
          }
        }
      }
      ctx.restore()
      rafRef.current = requestAnimationFrame(draw)
    }
    rafRef.current = requestAnimationFrame(draw)
    return () => {
      ro.disconnect()
      cancelAnimationFrame(rafRef.current)
    }
  }, [showCanvas])

  const hitTest = (clientX: number, clientY: number): LayoutNode | null => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const rect = canvas.getBoundingClientRect()
    const scale = Math.max(0.001, scaleRef.current)
    const x = (clientX - rect.left - panRef.current.x) / scale
    const y = (clientY - rect.top - panRef.current.y) / scale
    const pad = HIT_PAD / scale
    let best: LayoutNode | null = null
    let bestD = Infinity
    for (const n of nodesRef.current) {
      const d = Math.hypot(n.x - x, n.y - y)
      if (d <= n.r + pad && d < bestD) {
        best = n
        bestD = d
      }
    }
    return best
  }

  const hitTestEdge = (clientX: number, clientY: number): GraphDrawEdge | null => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const rect = canvas.getBoundingClientRect()
    const scale = Math.max(0.001, scaleRef.current)
    const x = (clientX - rect.left - panRef.current.x) / scale
    const y = (clientY - rect.top - panRef.current.y) / scale
    const byId = new Map(nodesRef.current.map((n) => [n.id, n]))
    const thresh = 6 / scale
    let best: GraphDrawEdge | null = null
    let bestD = thresh
    for (const e of edgesRef.current) {
      if (!e.reason && !e.dashed) continue
      const a = byId.get(e.a)
      const b = byId.get(e.b)
      if (!a || !b) continue
      const dx = b.x - a.x
      const dy = b.y - a.y
      const len2 = dx * dx + dy * dy
      if (len2 < 1) continue
      let t = ((x - a.x) * dx + (y - a.y) * dy) / len2
      t = Math.max(0, Math.min(1, t))
      const px = a.x + t * dx
      const py = a.y + t * dy
      const d = Math.hypot(x - px, y - py)
      if (d < bestD) {
        best = e
        bestD = d
      }
    }
    return best
  }

  const endDrag = (ev?: ReactPointerEvent) => {
    const drag = dragRef.current
    if (drag && drag.id !== "__pan__" && !drag.moved) {
      locateNode(drag.id)
    }
    if (drag && drag.id === "__pan__" && !drag.moved && ev) {
      const edge = hitTestEdge(ev.clientX, ev.clientY)
      if (edge?.reason) {
        setPanelOpen(true)
        setRelationOpen({
          a: edge.a,
          b: edge.b,
          reason: edge.reason,
          confidence: edge.score,
          ai: true,
        })
      }
    }
    if (ev?.target && "releasePointerCapture" in (ev.target as Element)) {
      try {
        ;(ev.target as HTMLElement).releasePointerCapture?.(ev.pointerId)
      } catch {
        /* already released */
      }
    }
    dragRef.current = null
  }

  const onPointerDown = (ev: ReactPointerEvent) => {
    const n = hitTest(ev.clientX, ev.clientY)
    if (n) {
      dragRef.current = { id: n.id, ox: ev.clientX, oy: ev.clientY, moved: false }
      setFocusId(n.id)
      setPanelOpen(true)
      ;(ev.target as HTMLElement).setPointerCapture?.(ev.pointerId)
      return
    }
    setFocusId(null)
    dragRef.current = { id: "__pan__", ox: ev.clientX, oy: ev.clientY, moved: false }
    ;(ev.target as HTMLElement).setPointerCapture?.(ev.pointerId)
  }

  const onPointerMove = (ev: ReactPointerEvent) => {
    const drag = dragRef.current
    if (!drag) {
      const n = hitTest(ev.clientX, ev.clientY)
      hoverIdRef.current = n?.id ?? null
      if (n) {
        setHoverCaptionText(captionByIdRef.current.get(n.id) || "")
      } else {
        const edge = hitTestEdge(ev.clientX, ev.clientY)
        setHoverCaptionText(
          edge?.reason
            ? `${edge.dashed ? KNOWLEDGE_GRAPH_AI_RELATION + " · " : ""}${edge.reason}`
            : "",
        )
      }
      return
    }
    const dx = ev.clientX - drag.ox
    const dy = ev.clientY - drag.oy
    if (Math.abs(dx) + Math.abs(dy) > 2) {
      drag.moved = true
      if (drag.id === "__pan__") userCameraRef.current = true
    }
    drag.ox = ev.clientX
    drag.oy = ev.clientY
    if (drag.id === "__pan__") {
      panRef.current.x += dx
      panRef.current.y += dy
      return
    }
    const n = nodesRef.current.find((x) => x.id === drag.id)
    if (n) {
      n.x += dx / scaleRef.current
      n.y += dy / scaleRef.current
    }
  }

  const onWheel = (ev: ReactWheelEvent) => {
    ev.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const mx = ev.clientX - rect.left
    const my = ev.clientY - rect.top
    const prev = scaleRef.current
    const next = Math.min(3.2, Math.max(0.08, prev * (ev.deltaY > 0 ? 0.92 : 1.08)))
    panRef.current.x = mx - ((mx - panRef.current.x) / prev) * next
    panRef.current.y = my - ((my - panRef.current.y) / prev) * next
    scaleRef.current = next
    userCameraRef.current = true
  }

  const ungroupedKey = groupKeys.find((k) => k === "u:ungrouped" || k === "" || k === "ungrouped")
  const relatedEdges: GraphDrawEdge[] = selected ? [
    ...payloadEdges.map((e) => ({ ...e, reason: payloadRelations.find((r) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))?.reason })),
    ...payloadRelations.filter((r) => !payloadEdges.some((e) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))).map((r) => ({ ...r, score: r.confidence, dashed: true })),
  ].filter((e) => e.a === selected.id || e.b === selected.id) : []

  return (
    <div className="kg-page" style={styles.page}>
      <style>{graphStyles}</style>
      <header className="kg-toolbar" role="toolbar" aria-label={`${KNOWLEDGE_GRAPH_ENTRY_LABEL}工具栏`}>
        <div className="kg-heading"><strong>{KNOWLEDGE_GRAPH_ENTRY_LABEL}</strong><span>{showCanvas ? knowledgeGraphBarMeta(payloadNodes.length, payloadEdges.length, payloadRelations.length) : "浏览知识与关联"}</span></div>
        <KnowledgeGraphColorSwitch mode={colorMode} onChange={setColorMode} />
        <button type="button" onClick={refresh}>刷新图谱</button>
        <button type="button" aria-expanded={panelOpen} onClick={() => setPanelOpen((v) => !v)}>{panelOpen ? "收起列表" : "浏览知识"}</button>
        <details className="kg-ai-options">
          <summary>AI 与分组</summary>
          <div>
            <KnowledgeGraphLlmSwitch enabled={llmEnabled} onChange={onLlmChange} onRegenerate={onRegenerate} />
            {showReorganize ? <KnowledgeGraphReorganizeButton organizing={organizing} disabled={!llmReady} onClick={sendOrganize} /> : null}
            {snap?.stale === true && llmLane ? <KnowledgeGraphStaleBadge /> : null}
          </div>
        </details>
        <button type="button" onClick={() => window.close()} title="关闭此标签页">关闭</button>
      </header>
      <div className="kg-notices">
        {requestError ? <div className="kg-notice" role="alert">{requestError}</div> : null}
        {status !== "ok" ? <KnowledgeGraphStatusView status={status} truncated={truncated} pollExhausted={pollExhausted} error={snap?.error} /> : null}
        {status === "ok" && showOrganizeCta ? <KnowledgeGraphOrganizeCta n={payloadNodes.length} disabled={!llmReady} organizing={organizing} onOrganize={sendOrganize} /> : null}
        {status === "ok" && snap?.organize_error ? <KnowledgeGraphOrganizeErrorBar error={snap.organize_error} onRetry={sendOrganize} /> : null}
        {showTfBanner ? <KnowledgeGraphTfSwitchBanner /> : null}
        {lockNotice ? <div className="kg-notice"><KnowledgeGraphLockDissolvedBanner /><button onClick={() => setLockNotice(false)}>知道了</button></div> : null}
      </div>
      <div className={`kg-workspace ${panelOpen ? "" : "kg-workspace-wide"}`}>
        <section className="kg-map" aria-label="知识关系画布">
          <div className="kg-map-tools">
            <span>实线：内容相似 · 虚线：AI 关联</span>
            <div>
              <button type="button" disabled={!showCanvas} onClick={() => { userCameraRef.current = false; fitView() }}>适应画布</button>
              <button type="button" disabled={!showCanvas} aria-label="放大" onClick={() => zoom(1.25)}>＋</button>
              <button type="button" disabled={!showCanvas} aria-label="缩小" onClick={() => zoom(0.8)}>－</button>
            </div>
          </div>
          <main style={styles.main}>
            {showCanvas ? <canvas ref={canvasRef} data-testid="knowledge-graph-canvas" style={styles.canvas} role="img" tabIndex={0}
              aria-label="知识分布图谱。点击节点查看关联；也可在知识列表搜索并定位。方向键平移，加减号缩放，0 适应画布。"
              onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={(ev) => endDrag(ev)}
              onPointerLeave={() => { hoverIdRef.current = null; setHoverCaptionText("") }}
              onPointerCancel={() => { dragRef.current = null }}
              onWheel={onWheel}
              onKeyDown={(ev) => {
                if (ev.key === "0" || ev.key === "Home") { ev.preventDefault(); userCameraRef.current = false; fitView() }
                if (ev.key === "+" || ev.key === "=" || ev.key === "-") { ev.preventDefault(); zoom(ev.key === "-" ? 0.8 : 1.25) }
                const delta: Record<string, [number, number]> = { ArrowLeft: [40, 0], ArrowRight: [-40, 0], ArrowUp: [0, 40], ArrowDown: [0, -40] }
                if (delta[ev.key]) { ev.preventDefault(); userCameraRef.current = true; panRef.current.x += delta[ev.key][0]; panRef.current.y += delta[ev.key][1] }
                if (ev.key === "Escape") { setFocusId(null); setRelationOpen(null) }
              }}
            /> : <div className="kg-placeholder">知识文档和真实关联将在这里显示</div>}
          </main>
          <div className="kg-map-caption" role="status">
            {hoverCaptionText || (showCanvas && !payloadEdges.length && !payloadRelations.length ? "暂无明确关联，仍可浏览全部知识" : "拖动画布 · 滚轮缩放 · 点击知识查看关联")}
          </div>
        </section>
        {panelOpen ? (
          <aside className="kg-explorer" aria-label="知识浏览">
            <div className="kg-search">
              <label htmlFor="kg-search">浏览知识</label>
              <input id="kg-search" aria-label="搜索知识" placeholder="搜索标题、文件夹…" value={query} onChange={(ev) => setQuery(ev.target.value)} />
              <select aria-label="筛选分组" value={groupFilter} onChange={(ev) => setGroupFilter(ev.target.value)}>
                <option value="">全部分组</option>
                {groupKeys.map((k) => <option key={k} value={k}>{labels[k]?.name || (k === ungroupedKey ? KNOWLEDGE_GRAPH_UNGROUPED_LABEL : k)}</option>)}
              </select>
              <span role="status">{visibleNodes.length} / {payloadNodes.length} 篇知识</span>
            </div>
            {selected ? <section className="kg-selection" aria-label="选中知识">
              <div className="kg-selection-heading"><strong>{selected.title || selected.id}</strong><button aria-label="取消选中知识" onClick={() => setFocusId(null)}>取消</button></div>
              <p>{selected.folder || "未设置文件夹"}</p>
              <button type="button" onClick={() => openDoc(selected.id)}>在知识面板打开</button>
              <h3>相关知识 · {relatedEdges.length}</h3>
              {relatedEdges.length === 0 ? <p>暂无明确关联</p> : relatedEdges.map((edge) => {
                const id = edge.a === selected.id ? edge.b : edge.a
                const other = payloadNodes.find((node) => node.id === id)
                return <div key={id} className="kg-relation">
                  <button type="button" onClick={() => locateNode(id)}>{other?.title || id}</button>
                  <span>{edge.dashed ? "AI 关联" : "内容相似"}</span>
                  {edge.reason ? <p>AI 关联理由：{edge.reason}</p> : null}
                </div>
              })}
            </section> : null}
            {relationOpen ? <section className="kg-selection" aria-label="关联理由" data-testid="kg-relation-reason">
              <strong>{KNOWLEDGE_GRAPH_AI_RELATION}</strong><p>{relationOpen.reason}</p>
              <button type="button" onClick={() => setRelationOpen(null)}>{KNOWLEDGE_GRAPH_REASON_DISMISS}</button>
            </section> : null}
            <div className="kg-document-list" aria-label="知识列表">
              {visibleNodes.map((n) => <button type="button" key={n.id} data-node-id={n.id} aria-pressed={n.id === focusId} onClick={() => locateNode(n.id)}>
                <span className="kg-dot" style={{ background: nodeColor(n, colorMode) }} aria-hidden="true" />
                <span><strong>{n.title || n.id}</strong><small>{n.folder || labels[n.group_key]?.name || KNOWLEDGE_GRAPH_UNGROUPED_LABEL}</small></span>
              </button>)}
              {!visibleNodes.length ? <p>{payloadNodes.length ? "没有匹配的知识。可清空搜索或切换分组。" : "当前没有可浏览的知识。"}</p> : null}
              {(query || groupFilter) ? <button type="button" onClick={() => { setQuery(""); setGroupFilter("") }}>清除筛选</button> : null}
            </div>
            <details className="kg-groups" open={payloadNodes.length <= 19}>
              <summary>分组说明与管理 · {groupKeys.length}</summary>
              {showNoRelations ? <KnowledgeGraphNoRelationsNote /> : null}
              {groupKeys.map((k) => {
                const llmGroup = k.startsWith("l:")
                return <KnowledgeGraphGroupCard key={k} groupKey={k}
                  label={labels[k] || (k === ungroupedKey ? { name: KNOWLEDGE_GRAPH_UNGROUPED_LABEL, ai: false } : undefined)}
                  llmEnabled={llmEnabled} llmLaneGroup={llmGroup}
                  onLock={llmLane && llmGroup ? () => sendLock(k, false) : undefined}
                  onUnlock={llmGroup && labels[k]?.locked === true ? () => sendLock(k, true) : undefined} />
              })}
            </details>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

const styles: Record<string, CSSProperties> = {
  page: { minHeight: "100dvh", height: "100dvh", margin: 0, fontFamily: tokens.font, background: G.canvas, color: tokens.darkText, display: "flex", flexDirection: "column", overflow: "auto" },
  main: { position: "relative", flex: 1, minHeight: 280 },
  canvas: { width: "100%", height: "100%", position: "absolute", inset: 0, display: "block", cursor: "grab", touchAction: "none" },
}

const graphStyles = `
  .kg-page * { box-sizing: border-box; }
  .kg-page button, .kg-page input, .kg-page select, .kg-page summary { font: inherit; font-size: 13px; }
  .kg-page button { min-height: 32px; border: 1px solid ${tokens.darkBorder}; background: transparent; color: ${tokens.darkText}; border-radius: 8px; padding: 5px 10px; cursor: pointer; }
  .kg-page button:disabled { opacity: .45; cursor: not-allowed; }
  .kg-page button:hover:not(:disabled), .kg-page button[aria-pressed=true] { background: ${tokens.darkElevated}; }
  .kg-page :focus-visible { outline: 2px solid ${tokens.darkMuted}; outline-offset: 2px; }
  .kg-page summary { cursor: pointer; padding: 8px 0; }
  .kg-toolbar { padding: 16px 20px; border-bottom: 1px solid ${tokens.darkBorder}; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; flex-shrink: 0; }
  .kg-heading { display: flex; flex-direction: column; gap: 4px; margin-right: auto; }
  .kg-heading strong { font-size: 18px; }
  .kg-heading span, .kg-search>span { color: ${tokens.darkMuted}; font-size: 12px; }
  .kg-ai-options[open] { flex-basis: 100%; order: 2; }
  .kg-ai-options>div { display: flex; flex-wrap: wrap; gap: 12px; padding: 8px 0; }
  .kg-notices { flex-shrink: 0; max-height: 30dvh; overflow: auto; background: ${tokens.darkElevated}; }
  .kg-notice { padding: 12px 16px; font-size: 13px; }
  .kg-workspace { display: grid; grid-template-columns: minmax(0,1fr) 320px; flex: 1; min-height: 400px; }
  .kg-workspace-wide { grid-template-columns: minmax(0,1fr); }
  .kg-map { display: flex; flex-direction: column; min-width: 0; min-height: 360px; }
  .kg-map-tools { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px; padding: 12px 16px; }
  .kg-map-tools span, .kg-map-caption { color: ${tokens.darkMuted}; font-size: 12px; line-height: 1.5; }
  .kg-map-tools>div { display: flex; gap: 6px; }
  .kg-map-caption { padding: 8px 16px 12px; min-height: 38px; overflow-wrap: anywhere; }
  .kg-placeholder { height: 100%; display: grid; place-items: center; color: ${tokens.darkMuted}; padding: 24px; text-align: center; }
  .kg-explorer { overflow: auto; border-left: 1px solid ${tokens.darkBorder}; padding: 16px; min-width: 0; }
  .kg-search { display: grid; gap: 10px; margin-bottom: 16px; position: sticky; top: 0; z-index: 1; background: ${G.canvas}; padding-bottom: 8px; }
  .kg-search label { font-size: 14px; font-weight: 600; }
  .kg-search input, .kg-search select { width: 100%; min-width: 0; min-height: 36px; background: ${tokens.darkElevated}; color: ${tokens.darkText}; border: 1px solid ${tokens.darkBorder}; border-radius: 8px; padding: 8px; }
  .kg-document-list>button { width: 100%; display: flex; gap: 10px; align-items: center; text-align: left; border-color: transparent; padding: 10px 8px; }
  .kg-document-list strong { font-size: 13px; font-weight: 500; overflow-wrap: anywhere; }
  .kg-document-list small { display: block; color: ${tokens.darkMuted}; font-size: 12px; margin-top: 4px; overflow-wrap: anywhere; }
  .kg-document-list p, .kg-selection p { font-size: 13px; line-height: 1.6; color: ${tokens.darkMuted}; overflow-wrap: anywhere; }
  .kg-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
  .kg-selection { padding: 12px; border: 1px solid ${tokens.darkBorder}; border-radius: 10px; margin-bottom: 12px; }
  .kg-selection-heading { display: flex; align-items: start; gap: 8px; }
  .kg-selection-heading strong { flex: 1; min-width: 0; overflow-wrap: anywhere; font-size: 14px; }
  .kg-selection h3 { font-size: 13px; margin: 16px 0 8px; }
  .kg-relation { margin-top: 10px; }
  .kg-relation>button { display: block; text-align: left; overflow-wrap: anywhere; max-width: 100%; }
  .kg-relation>span { display: block; font-size: 12px; color: ${tokens.darkMuted}; margin-top: 4px; }
  .kg-groups { margin-top: 16px; border-top: 1px solid ${tokens.darkBorder}; }
  @media(max-width: 759px) {
    .kg-toolbar { padding: 12px; gap: 8px; }
    .kg-heading { flex-basis: 100%; }
    .kg-workspace, .kg-workspace-wide { display: flex; flex-direction: column; flex: none; min-height: 0; }
    .kg-map { height: 440px; flex-shrink: 0; }
    .kg-explorer { border-left: none; border-top: 1px solid ${tokens.darkBorder}; overflow: visible; }
  }
`

```

### Current full chrome-extension/scripts/test-knowledge-graph-ui.py
```
"""Real graph builder + KnowledgeGraphApp, delayed storage, isolated Chrome.

Run after nvm use 22:
  uv run --with playwright python scripts/test-knowledge-graph-ui.py
"""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', action='store_true', help='Capture the pre-fix failure without hiding its assertion')
parser.add_argument('--artifacts', type=Path, default=Path(__file__).resolve().parents[2] / '.omx/artifacts/knowledge-graph-490')
args = parser.parse_args()
args.artifacts.mkdir(parents=True, exist_ok=True)
project = Path(__file__).resolve().parent.parent

with tempfile.TemporaryDirectory(prefix='cmspark-knowledge-graph-') as directory:
    subprocess.run(['node', 'scripts/render-knowledge-graph-fixture.cjs', directory] + (['--baseline'] if args.baseline else []), cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 800})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        assert page.locator('canvas').count() == 0, 'Initial storage read must remain asynchronous'
        page.evaluate("window.graphFixture.release('4')")
        page.locator('canvas').wait_for()
        if args.baseline:
            page.wait_for_timeout(400)
            evidence = page.evaluate('''() => {
                const c=document.querySelector('canvas');
                return {storageReleased:window.storageReleased, snapshotNodes:window.graphFixture.readSnapshot().nodes.length,
                    canvasWidth:c.width,canvasHeight:c.height,cssWidth:c.getBoundingClientRect().width,
                    drawnArcs:window.drawProbe.arcs,drawnFrames:window.drawProbe.frames,
                    opaquePixels:[...c.getContext('2d').getImageData(0,0,c.width,c.height).data].filter((v,i)=>i%4===3&&v>0).length};
            }''')
            page.screenshot(path=str(args.artifacts / 'before.png'), full_page=True)
            (args.artifacts / 'before.json').write_text(json.dumps(evidence, indent=2) + '\n')
            print(json.dumps(evidence, indent=2), flush=True)
            assert evidence['drawnArcs'] >= 4 and evidence['opaquePixels'] > 0, 'Async snapshot mounted a Canvas but never started the drawing effect'
        def painted(count):
            pixels = page.wait_for_function('''(count) => {
                const c=document.querySelector('canvas');if(!c)return false;
                const ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];
                const arcs=window.drawProbe.latestArcs;
                const visible=arcs.filter(p=>p.x>=0&&p.x<c.width&&p.y>=0&&p.y<c.height);
                const colored=visible.filter(p=>{
                    const pixel=[...ctx.getImageData(Math.floor(p.x),Math.floor(p.y),1,1).data];
                    return pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]);
                });
                if(arcs.length<count||bg[3]!==255||!colored.length)return false;
                return {width:c.width,height:c.height,css:c.getBoundingClientRect().width,
                    dpr:devicePixelRatio,backgroundAlpha:bg[3],visible:visible.length,colored:colored.length};
            }''', arg=count).json_value()
            assert pixels['width'] == int(pixels['css'] * pixels['dpr']), pixels
            assert pixels['height'] >= 280, pixels
            assert pixels['backgroundAlpha'] == 255 and pixels['colored'] > 0, pixels
            return pixels

        def open_fixture(count):
            page.goto((Path(directory) / 'index.html').as_uri())
            page.wait_for_function('window.storageReads===1')
            assert page.locator('canvas').count() == 0
            page.evaluate('(count)=>window.graphFixture.release(String(count))', count)
            if count == 0:
                page.get_by_text('知识库暂无可展示的文档', exact=False).wait_for()
                return
            page.get_by_test_id('knowledge-graph-canvas').wait_for()
            painted(count)

        painted(4)
        summaries = []
        for count in [1, 4, 20, 200]:
            open_fixture(count)
            page.wait_for_function("window.drawProbe.latestText.some(text=>text.includes('SQLite'))")
            assert page.locator('button[data-node-id]').count() == count
            assert page.evaluate('window.graphFixture.readSnapshot().edges.length') == 0
            page.get_by_text('暂无明确关联，仍可浏览全部知识', exact=True).wait_for()
            assert not page.evaluate("window.sent.some(m=>m.organize||m.type==='knowledge_graph.open_doc')")
            summaries.append({'nodes': count, **painted(count)})
            page.screenshot(path=str(args.artifacts / f'after-{count}.png'), full_page=True)
        print('PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state')

        # Removing a Canvas must stop its loop; a later success creates a working
        # new Canvas, independently of the mount that originally saw null refs.
        page.evaluate("window.oldCanvas=document.querySelector('canvas');window.graphFixture.publish('error')")
        page.locator('canvas').wait_for(state='detached')
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        stopped_frames = page.evaluate('window.drawProbe.frames')
        page.wait_for_timeout(80)
        assert page.evaluate('window.drawProbe.frames') == stopped_frames
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.refresh')")
        page.evaluate("window.drawProbe.latestArcs=[];window.graphFixture.publish('4')")
        painted(4)
        assert page.evaluate("window.oldCanvas!==document.querySelector('canvas')")
        print('PASS ok → error stops drawing → refresh → ok remount draws real nodes')

        page.evaluate('window.sendFailure=true')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        page.get_by_text('无法连接 CMspark', exact=False).wait_for()
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        page.evaluate('window.sendFailure=false')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        print('PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI')

        search = page.get_by_role('textbox', name='搜索知识', exact=True)
        search.fill('不存在的知识')
        assert page.locator('button[data-node-id]').count() == 0
        assert page.locator('canvas').is_visible()
        search.fill('Telescope')
        assert page.locator('button[data-node-id]').count() == 1
        page.locator('button[data-node-id="fixture-003"]').click()
        assert not page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.open_doc')")
        page.get_by_role('button', name='在知识面板打开', exact=True).click()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').map(m=>m.id)") == ['fixture-003']
        search.fill('')
        radius = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='放大', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r>r', arg=radius)
        enlarged = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='缩小', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r<r', arg=enlarged)
        page.get_by_role('button', name='适应画布', exact=True).click()
        painted(4)
        page.get_by_role('button', name='收起列表', exact=True).click()
        assert page.get_by_role('complementary', name='知识浏览', exact=True).count() == 0
        page.get_by_role('button', name='浏览知识', exact=True).click()
        page.get_by_role('complementary', name='知识浏览', exact=True).wait_for()
        print('PASS search incl. empty results, local selection, explicit document open, camera and list controls')

        # Exercise actual keyboard events against the focused Canvas. Wait for
        # the physical simulation to settle so movement proves the key handler,
        # rather than merely observing an unrelated animation frame.
        canvas = page.get_by_test_id('knowledge-graph-canvas')
        canvas.focus()
        page.keyboard.press('Escape')
        page.wait_for_function('''() => {
            const arc=window.drawProbe.latestArcs[0];if(!arc)return false;
            const last=window.keyboardLastArc;
            window.keyboardStableFrames=last&&Math.abs(last.x-arc.x)<0.001&&Math.abs(last.y-arc.y)<0.001
                ? (window.keyboardStableFrames||0)+1 : 0;
            window.keyboardLastArc={x:arc.x,y:arc.y};
            return window.keyboardStableFrames>=6;
        }''')
        page.keyboard.press('0')
        page.wait_for_timeout(50)
        fitted_arc = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        page.keyboard.press('ArrowLeft')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x-40)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('Home')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('ArrowRight')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x+40)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('0')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('+')
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r*1.25)<0.01', arg=fitted_arc['r'])
        page.keyboard.press('-')
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r)<0.01', arg=fitted_arc['r'])
        keyboard_document = page.locator('button[data-node-id="fixture-002"]')
        keyboard_document.focus()
        page.keyboard.press('Enter')
        page.wait_for_function('document.querySelector("button[data-node-id=fixture-002]").getAttribute("aria-pressed")==="true"')
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Orchids 高山兰花', exact=True).wait_for()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length") == 1
        canvas.focus()
        page.keyboard.press('Escape')
        page.get_by_role('region', name='选中知识', exact=True).wait_for(state='detached')
        assert keyboard_document.get_attribute('aria-pressed') == 'false'
        print('PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection')

        # CDP injects real trusted touch input through Chrome's input pipeline.
        # DOM dispatchEvent cannot test the UA's implicit pointer-capture release.
        page.evaluate('''() => {
            window.touchEvidence=[];
            const c=document.querySelector('canvas');
            for(const type of ['pointerdown','pointermove','pointercancel','gotpointercapture','lostpointercapture']){
                c.addEventListener(type,event=>{
                    if(event.pointerType==='touch')window.touchEvidence.push({type:event.type,
                        pointerId:event.pointerId,isTrusted:event.isTrusted,
                        captureDuringEvent:c.hasPointerCapture(event.pointerId)});
                });
            }
        }''')
        cdp = page.context.new_cdp_session(page)
        cdp.send('Emulation.setTouchEmulationEnabled', {'enabled': True, 'maxTouchPoints': 1})
        canvas_box = canvas.bounding_box()
        assert canvas_box
        touch_x, touch_y = canvas_box['x'] + 25, canvas_box['y'] + 25
        before_touch = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        opened_before_touch = page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length")
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': touch_x, 'y': touch_y, 'id': 7}]})
        pointer_id = page.evaluate("window.touchEvidence.find(event=>event.type==='pointerdown').pointerId")
        capture_after_start = page.evaluate('(id)=>document.querySelector("canvas").hasPointerCapture(id)', pointer_id)
        assert capture_after_start is True
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': touch_x + 30, 'y': touch_y + 20, 'id': 7}]})
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x-30)<0.1', arg=before_touch['x'])
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchCancel', 'touchPoints': []})
        page.wait_for_function('''(id)=>window.touchEvidence.some(event=>event.type==='pointercancel'&&event.pointerId===id)
            && !document.querySelector('canvas').hasPointerCapture(id)''', arg=pointer_id)
        capture_after_cancel = page.evaluate('(id)=>document.querySelector("canvas").hasPointerCapture(id)', pointer_id)
        touch_events = page.evaluate('window.touchEvidence')
        assert all(event['isTrusted'] and event['pointerId'] == pointer_id for event in touch_events), touch_events
        assert any(event['type'] == 'lostpointercapture' for event in touch_events), touch_events
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length") == opened_before_touch
        assert page.get_by_role('region', name='关联理由', exact=True).count() == 0
        after_cancel = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        # A leftover dragRef would move the camera on subsequent pointermove,
        # even though no new press started a drag. These are real mouse events.
        page.mouse.move(touch_x + 70, touch_y + 55)
        page.mouse.move(touch_x + 110, touch_y + 85)
        page.wait_for_timeout(80)
        after_hover = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        assert abs(after_hover['x'] - after_cancel['x']) < 0.1 and abs(after_hover['y'] - after_cancel['y']) < 0.1, (after_cancel, after_hover)
        cdp.send('Emulation.setTouchEmulationEnabled', {'enabled': False})
        cdp.detach()
        touch_result = {'pointerId': pointer_id, 'captureAfterStart': capture_after_start,
                        'captureAfterCancel': capture_after_cancel, 'events': touch_events,
                        'cameraAfterCancel': after_cancel, 'cameraAfterUnpressedMoves': after_hover}
        (args.artifacts / 'pointercancel.json').write_text(json.dumps(touch_result, indent=2) + '\n')
        print('PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves')
        print('POINTERCANCEL EVIDENCE ' + json.dumps(touch_result))

        # Production builder emits the organized group and AI relation; its
        # serializer controls optional wire keys and no fixture invents nodes.
        page.evaluate("window.graphFixture.publish('organized')")
        group = page.get_by_role('combobox', name='筛选分组', exact=True)
        page.wait_for_function("[...document.querySelectorAll('select option')].some(o=>o.textContent.includes('开发主题'))")
        group_key = page.evaluate("Object.keys(window.graphFixture.readSnapshot().labels)[0]")
        group.select_option(group_key)
        assert page.locator('button[data-node-id]').count() == 2
        group.select_option('')
        page.locator('button[data-node-id="fixture-001"]').click()
        page.get_by_text('AI 关联理由：共同讨论开发实践', exact=True).wait_for()
        print('PASS production organized group filtering and readable AI relationship reason')

        def painted_line(dashed):
            page.wait_for_function('''(dashed)=>{
                const c=document.querySelector('canvas'),ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];if(bg[3]!==255)return false;
                return window.drawProbe.latestLines.filter(line=>line.dashed===dashed).some(line=>{
                    for(let step=2;step<19;step++)for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){
                        const x=Math.floor(line.a.x+(line.b.x-line.a.x)*step/20)+dx;
                        const y=Math.floor(line.a.y+(line.b.y-line.a.y)*step/20)+dy;
                        if(x<0||y<0||x>=c.width||y>=c.height)continue;
                        const pixel=[...ctx.getImageData(x,y,1,1).data];
                        if(pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]))return true;
                    }return false;
                });
            }''', arg=dashed)
        painted_line(True)
        groups = page.locator('details').filter(has=page.locator('summary').filter(has_text='分组说明与管理'))
        if groups.get_attribute('open') is None:
            groups.locator('summary').click()
        page.get_by_role('button', name='保留这版分组', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].lock_group') == group_key
        page.evaluate("window.graphFixture.publish('locked')")
        page.get_by_role('button', name='解锁', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].unlock_group') == group_key
        page.get_by_text('AI 与分组', exact=True).click()
        page.get_by_role('button', name='重新整理', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].organize') is True
        page.evaluate("window.graphFixture.publish('organizing')")
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.evaluate("window.graphFixture.publish('organized')")
        assert page.get_by_role('button', name='重新整理', exact=True).is_enabled()
        page.evaluate("window.graphFixture.publish('similar')")
        painted(4)
        painted_line(False)
        assert page.evaluate('window.graphFixture.readSnapshot().edges.length') > 0
        print('PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts')

        # A real viewport resize must resize the Canvas bitmap; responsive
        # layout must not leave its controls as opaque overlays on the graph.
        for width, height in [(1440, 900), (960, 720), (760, 740), (390, 844), (320, 480), (1280, 800)]:
            page.set_viewport_size({'width': width, 'height': height})
            page.get_by_role('button', name='适应画布', exact=True).click()
            page.wait_for_function('''() => {
                const c=document.querySelector('canvas');return c.width===Math.floor(c.getBoundingClientRect().width*devicePixelRatio);
            }''')
            painted(4)
            canvas_box = page.locator('canvas').bounding_box()
            aside_box = page.get_by_role('complementary', name='知识浏览', exact=True).bounding_box()
            assert canvas_box and aside_box
            overlap_w = min(canvas_box['x'] + canvas_box['width'], aside_box['x'] + aside_box['width']) - max(canvas_box['x'], aside_box['x'])
            overlap_h = min(canvas_box['y'] + canvas_box['height'], aside_box['y'] + aside_box['height']) - max(canvas_box['y'], aside_box['y'])
            assert overlap_w <= 1 or overlap_h <= 1, (canvas_box, aside_box)
            assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')
            page.screenshot(path=str(args.artifacts / f'after-width-{width}.png'), full_page=True)
        print('PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow')

        open_fixture(0)
        assert page.locator('canvas').count() == 0

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('error')")
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        print('PASS initially cached error snapshot can refresh and recover without closing the page')

        page.goto((Path(directory) / 'index.html').as_uri() + '?labels')
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('4')")
        painted(4)
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is True
        assert not page.evaluate('window.sent.some(m=>m.organize)')
        print('PASS refresh preserves a previously enabled AI naming preference without automatically organizing')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('rebuilding',{focus_id:'fixture-003'})")
        assert page.locator('canvas').count() == 0
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Telescope 天文观测', exact=True).wait_for()
        print('PASS a requested document remains selected across rebuilding → success with no new focus id')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.evaluate("window.graphFixture.release('error')")
        page.wait_for_timeout(50)
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        print('PASS a stale initial storage result cannot overwrite a newer successful storage event')
        assert not errors, errors
        (args.artifacts / 'after.json').write_text(json.dumps(summaries, indent=2) + '\n')
        assert not errors, errors
        browser.close()
print('PASS delayed storage → real Canvas node drawing')

```

### Actual background refresh route
```ts
      case "knowledge_graph.open":
      case "knowledge_graph.refresh": {
        const llmFromMsg = message.llm_labels === true
        const regenerate = message.regenerate === true
        const organize = message.organize === true
        const lockGroup = typeof message.lock_group === "string" ? message.lock_group : undefined
        const unlockGroup = typeof message.unlock_group === "string" ? message.unlock_group : undefined
        const ackTfSwitch = message.ack_tf_switch === true
        const focusId = message.focus_id || message.focusId || null
        const run = async () => {
          let llm = llmFromMsg
          if (message.type === "knowledge_graph.open" && message.llm_labels == null) {
            try {
              const pref = await chrome.storage.local.get(KNOWLEDGE_GRAPH_LLM_LABELS_KEY)
              llm = parseLlmLabelsPref(pref[KNOWLEDGE_GRAPH_LLM_LABELS_KEY])
            } catch {
              llm = false
            }
          }
          if (message.type === "knowledge_graph.open") {
            await writeKnowledgeGraphSnapshot(
              { status: "rebuilding", truncated: false, nodes: [], edges: [], labels: {} },
              { focus_id: focusId, llm_labels: llm },
            )
            await openOrFocusKnowledgeGraph(focusId)
          }
          // Wire 契约权威在服务端：强制重生成字段是 regen_labels（#316 复审 MAJOR-1）
          // #374: 请求带 id → companion 回带 → error 帧按 id 精确关联（替代文本 seam 为主）
          const reqId = `kg.${Date.now().toString(36)}.${(graphReqSeq += 1)}`
          const frame = buildKnowledgeGraphRequest({
            llmLabels: llm,
            regenerate,
            id: reqId,
            organize,
            lockGroup,
            unlockGroup,
            ackTfSwitch,
          })
          trackGraphRequest(reqId)
          const sent = wsClient?.send(frame) === true
          if (!sent) {
            // 未发出（未连/握手前）不会有响应——立即注销，避免悬挂在注册表里
            untrackGraphRequest(reqId)
          }
          if (!sent && message.type === "knowledge_graph.open") {
            // Companion 未连或尚未识别动词：保持 rebuilding，tab 会 refresh。
          }
          return { ok: true, sent }
        }
        run()
          .then((r) => sendResponse(r))
          .catch((e: any) => sendResponse({ ok: false, error: e?.message || String(e) }))
        return true
      }
      case "knowledge_graph.open_doc": {
```
