Independent read-only review for CMspark Issue #490. User: knowledge graph shows nothing; optimize visibility and intuitive clean UI without removing capabilities. Base aada096a. Evaluate outcomes, trajectory/scope, and component correctness. No tools, no edits. Give concrete P0/P1/P2 findings and nits with source evidence; distinguish existing issues from regressions. Do not approve based on prose length or test counts. Finish with VERDICT: APPROVE | APPROVE_WITH_NITS | REJECT.

Capability: T2; existing panel-only graph, same authenticated transport and trust. No new actions/permissions. Optional response organizing boolean reflects existing async job state. Refresh preserves existing saved AI naming preference (default off); search/locate do not invoke AI, organization still explicit. Existing AI naming/regeneration, group lock/unlock, similarity/AI provenance, preview all preserved. Backend >=20 ignores old unlocked LLM groups while explicit lock overlay persists. Cache write permission failure remains separately filed #491, not claimed fixed. No user data/config touched.

DoD: asynchronous snapshot starts real canvas; error/remount works; 1/4/20/200 nodes + default titles + full searchable list; search/group intersection never drops graph data; selection opens details locally, explicit preview opens existing panel; fit/zoom/keyboard and responsive 320-1440, short heights; empty/offline/failed states with recovery; actual organizing true initial/refresh vs false final success/error. Existing legacy servers lacking organizing retain compatibility but cannot provide reliable server job-state feedback.

Evidence: baseline real App at aada096a with 4 production-generated nodes had canvas 300x150 instead of1280 CSS width, 0 draw calls and 0 opaque pixels. Initial effect [] saw null ref and never retried; new [showCanvas] lifecycle is tested through actual DOM/canvas pixels. Machine results follow. Browser synthetic transport+non-user corpus; NOT real Windows UI or real user corpus.


### Evidence backend-validation.md
# Issue 490 backend lane regression evidence

Runtime: Node v22.23.2, selected with `nvm use 22` before each command.
Working directory: `/Users/huchen/Projects/cmspark/companion`.
Tests use the existing isolated temporary knowledge/config fixtures and production
`normalizeGraphOrganize` / `buildKnowledgeGraph` functions. No real user knowledge
or configuration was accessed for fixtures.

1. Before the production fix:
   `./node_modules/.bin/tsx --test --test-name-pattern='#490' tests/knowledge-graph.test.ts`
   Exit 1; 2 tests failed. Log: `backend-lane-red.log`.
2. After the production fix:
   `./node_modules/.bin/tsx --test tests/knowledge-graph.test.ts tests/knowledge-graph-organize.test.ts`
   Exit 0; 52 tests passed. Log: `backend-lane-green.log`.
3. `./node_modules/.bin/tsc -p tsconfig.test.json --noEmit`
   Exit 0. Log: `backend-typecheck.log` (empty on success).
4. `git diff --check -- companion/src/skills/knowledge-graph.ts companion/tests/knowledge-graph.test.ts`
   Exit 0, run from the repository root.

Production scope: only apply unlocked cached LLM groups in the LLM lane. The
existing explicit lock overlay remains after grouping and still applies at 20+
documents. Shared index cache persistence behavior is unchanged. No commit,
full suite, or merge approval performed by this implementation agent.

## Organize operation state follow-up

Added an additive boolean `organizing` to normal and rebuilding graph responses.
The existing single-flight controller remains the authority; its existing
`finally` clears the controller before the terminal push is serialized.

- Red: `./node_modules/.bin/tsx --test --test-name-pattern='#490 organize lifecycle' tests/knowledge-graph-organize.test.ts`
  exited 1, two failures; `backend-organizing-red.log`.
- Green: `CMSPARK_TEST_GRAPH_ARTIFACT_DIR="$PWD/../.omx/artifacts/knowledge-graph-490" ./node_modules/.bin/tsx --test tests/knowledge-graph.test.ts tests/knowledge-graph-organize.test.ts`
  exited 0, 54 tests passed; `backend-organizing-green.log`.
- `./node_modules/.bin/tsc -p tsconfig.test.json --noEmit` exited 0;
  `backend-organizing-typecheck.log`.
- Targeted `git diff --check` exited 0.

`organize-success-frames.json` and `organize-failure-frames.json` contain actual
`handleMessage` responses and `sendToExtension` pushes from the isolated deferred
LLM fixture. Each records initial ACK, intermediate refresh, rebuilding response,
final push and subsequent refresh. Busy is true until success/failure settles;
the failure case starts with an existing organized cache and preserves it.

### Evidence before.json
{
  "storageReleased": true,
  "snapshotNodes": 4,
  "canvasWidth": 300,
  "canvasHeight": 150,
  "cssWidth": 1280,
  "drawnArcs": 0,
  "drawnFrames": 0,
  "opaquePixels": 0
}

### Evidence after.json
[
  {
    "nodes": 1,
    "width": 960,
    "height": 627,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 1,
    "colored": 1
  },
  {
    "nodes": 4,
    "width": 960,
    "height": 571,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 4,
    "colored": 4
  },
  {
    "nodes": 20,
    "width": 960,
    "height": 627,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 20,
    "colored": 20
  },
  {
    "nodes": 200,
    "width": 960,
    "height": 627,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 191,
    "colored": 191
  }
]

### Evidence ui-green-3.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS production organized group filtering and readable AI relationship reason
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### extension-tests.log summary
# tests 1331
# pass 1331
# fail 0
# skipped 0
### extension-build.log summary
🟢 DONE   | Finished in 8735ms!
### companion-tests.log summary
# tests 5055
# pass 5032
# fail 0
# skipped 23
# tests 20
# pass 20
# fail 0
# skipped 0
### Tracked diff
```diff
diff --git a/CHANGELOG.md b/CHANGELOG.md
index 64b22d13..f686875f 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -4,6 +4,7 @@
 
 ## [Unreleased]
 
+- 知识图谱（#490）：修复异步快照到达后画布未绘制及跨 20 篇残留旧未锁 AI 分组；新增可搜索知识列表、节点定位、默认标题、缩放/适应画布与刷新恢复，保留分组和 AI 关联能力。
 - Windows 对话管理复审修复（#488）：全选遵循当前筛选，整理建议与列表选择分开；删除和恢复按 50 条分批并等待真实回执，保留失败项，清理空白改为应用内确认并在服务端复核内容。短窗口可滚动访问列表和操作，保留标签、人工/AI 分组、整理及图谱入口。
 - 会议关闭（#488）：收起、切换面板和打开设置先等待最后一段转写的相关写入回执及结束确认；失败保留草稿，可显式“保存转写”后重试。工作区统一连接图标，资源抽屉区分全局配置与对话使用范围。
 
diff --git a/DESIGN.md b/DESIGN.md
index 62df0b90..1d270e52 100644
--- a/DESIGN.md
+++ b/DESIGN.md
@@ -67,6 +67,19 @@ refresh before retry. Empty cleanup requires server-side content revalidation.
 The entire history panel scrolls on short screens; its list cannot collapse to zero.
 Meeting close and navigation wait for final transcript persistence and end receipt;
 failures retain the panel with a retry action.
+Knowledge graph (#490) has a real canvas lifecycle tied to asynchronous data,
+an always available searchable document list, explicit fit/zoom/refresh, and
+selected-document relations. The list and notices occupy layout space rather
+than covering the canvas. Canvas labels are readable by default; collision
+suppression never removes list entries. Selection explores in place; opening
+the existing knowledge panel is explicit. Isolated documents stay visible.
+Color is a grouping aid; solid similarity edges and dashed AI relations retain
+their provenance. Search never triggers AI; refresh preserves the user's existing
+naming preference (off by default, enabled preference permits existing on-demand
+label completion). Organization still requires an explicit action. Existing AI
+naming, organization, lock/unlock and relation reasons remain discoverable.
+Below 760px, graph and browser stack in a scrollable page; zero documents,
+disconnected transport and loading failures have distinct recovery copy.
 Existing resource panels use ContextPanelHost above the composer; summoner resource
 attachments retain their current surface until native management lands. Label
 “used in this conversation” separately from global configuration. Read-only lists
diff --git a/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx b/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
index eb09a6ef..863d23f9 100644
--- a/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
+++ b/chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
@@ -15,6 +15,7 @@ import {
 import { forceLayoutTick, seedLayoutNodes, type LayoutNode } from "../thread-graph/force-layout"
 import { hexWithAlpha, lightenHex, UNTAGGED_COLOR } from "../thread-graph/tag-colors"
 import { tokens } from "../sidepanel/ui/tokens"
+import { filterKnowledgeNodes, fitKnowledgeCamera, shortKnowledgeTitle } from "./explorer"
 import {
   KNOWLEDGE_GRAPH_SNAPSHOT_KEY,
   type KnowledgeGraphSnapshot,
@@ -71,22 +72,27 @@ const HIT_PAD = 8
 const REBUILD_POLL_MS = 2500
 /** 重建轮询上限（复审 NIT-5）：40 × 2.5s = 100s 后停轮询，诚实提示手动刷新。 */
 const REBUILD_POLL_MAX = 40
+const EMPTY_NODES: KnowledgeGraphNode[] = []
+const EMPTY_EDGES: NonNullable<KnowledgeGraphSnapshot["edges"]> = []
+const EMPTY_LABELS: KnowledgeGraphSnapshot["labels"] = {}
 
 function radiusForDegree(deg: number): number {
-  return Math.min(7.5, Math.max(2.8, 2.8 + Math.sqrt(deg) * 1.35))
+  return Math.min(10, 5 + Math.sqrt(deg) * 1.4)
 }
 
 export function KnowledgeGraphApp() {
   const [snap, setSnap] = useState<KnowledgeGraphSnapshot | null>(null)
   const [colorMode, setColorMode] = useState<ColorMode>("group")
   const [llmEnabled, setLlmEnabled] = useState(false)
+  const llmEnabledRef = useRef(false)
   const [focusId, setFocusId] = useState<string | null>(null)
   const [hoverCaptionText, setHoverCaptionText] = useState("")
-  const [barHeight, setBarHeight] = useState(48)
   const [panelOpen, setPanelOpen] = useState(true)
+  const [query, setQuery] = useState("")
+  const [groupFilter, setGroupFilter] = useState("")
+  const [requestError, setRequestError] = useState("")
 
   const canvasRef = useRef<HTMLCanvasElement>(null)
-  const barRef = useRef<HTMLDivElement>(null)
   const nodesRef = useRef<LayoutNode[]>([])
   const edgesRef = useRef<GraphDrawEdge[]>([])
   const dragRef = useRef<{ id: string; ox: number; oy: number; moved: boolean } | null>(null)
@@ -123,11 +129,23 @@ export function KnowledgeGraphApp() {
       llm_labels: rec.llm_labels === true,
     })
     if (typeof rec.focus_id === "string" && rec.focus_id) setFocusId(rec.focus_id)
-    setOrganizing(false)
+    setOrganizing(parsed.organizing === true)
+    setRequestError("")
+  }, [])
+
+  const refresh = useCallback(() => {
+    // Preserve the existing user-authorized naming preference. Default reads
+    // never enable naming or organization on the user's behalf.
+    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", llm_labels: llmEnabledRef.current }, (res) => {
+      if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
+        setRequestError("无法连接 CMspark，请确认程序运行后刷新图谱。已有快照可继续浏览。")
+      } else setRequestError("")
+    })
   }, [])
 
   useEffect(() => {
     let cancelled = false
+    let receivedSnapshot = false
     ;(async () => {
       try {
         const pref = await chrome.storage.local.get([
@@ -135,7 +153,8 @@ export function KnowledgeGraphApp() {
           KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
         ])
         if (!cancelled) {
-          setLlmEnabled(parseLlmLabelsPref(pref[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]))
+          llmEnabledRef.current = parseLlmLabelsPref(pref[KNOWLEDGE_GRAPH_LLM_LABELS_KEY])
+          setLlmEnabled(llmEnabledRef.current)
           setTfAcked(parseTfSwitchAck(pref[KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY]))
         }
       } catch {
@@ -144,20 +163,23 @@ export function KnowledgeGraphApp() {
       try {
         const res = await chrome.storage.session.get(KNOWLEDGE_GRAPH_SNAPSHOT_KEY)
         if (cancelled) return
-        applySnap(res[KNOWLEDGE_GRAPH_SNAPSHOT_KEY])
+        if (!receivedSnapshot) applySnap(res[KNOWLEDGE_GRAPH_SNAPSHOT_KEY])
       } catch {
         /* empty → rebuilding banner via null snap */
       }
+      if (!cancelled) refresh()
     })()
     const onStorage = (
       changes: Record<string, chrome.storage.StorageChange>,
       area: string,
     ) => {
       if (area === "session" && changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY]) {
+        receivedSnapshot = true
         applySnap(changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY].newValue)
       }
       if (area === "local" && changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]) {
-        setLlmEnabled(parseLlmLabelsPref(changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY].newValue))
+        llmEnabledRef.current = parseLlmLabelsPref(changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY].newValue)
+        setLlmEnabled(llmEnabledRef.current)
       }
 
     }
@@ -166,7 +188,7 @@ export function KnowledgeGraphApp() {
       cancelled = true
       chrome.storage.onChanged.removeListener(onStorage)
     }
-  }, [applySnap])
+  }, [applySnap, refresh])
 
   const status = snap?.status ?? "rebuilding"
   const truncated = snap?.truncated === true
@@ -187,19 +209,16 @@ export function KnowledgeGraphApp() {
         clearInterval(id)
         return
       }
-      chrome.runtime.sendMessage({ type: "knowledge_graph.refresh" }, () => {
-        void chrome.runtime.lastError
-      })
+      refresh()
     }
-    tick()
     const id = setInterval(tick, REBUILD_POLL_MS)
     return () => clearInterval(id)
-  }, [status, llmEnabled])
+  }, [status, refresh])
 
-  const payloadNodes = snap?.nodes ?? []
-  const payloadEdges = snap?.edges ?? []
-  const labels = snap?.labels ?? {}
-  const view = knowledgeGraphViewModel(snap)
+  const payloadNodes = snap?.nodes ?? EMPTY_NODES
+  const payloadEdges = snap?.edges ?? EMPTY_EDGES
+  const labels = snap?.labels ?? EMPTY_LABELS
+  const view = useMemo(() => knowledgeGraphViewModel(snap), [snap])
   const { llmLane, showOrganizeCta, showReorganize, showNoRelations, relationsToDraw } = view
   const payloadRelations = relationsToDraw
   const llmReady = snap?.llm_ready !== false
@@ -220,15 +239,13 @@ export function KnowledgeGraphApp() {
     return keys
   }, [payloadNodes])
 
+  const visibleNodes = useMemo(() => filterKnowledgeNodes(payloadNodes, query, groupFilter), [payloadNodes, query, groupFilter])
+  const selected = payloadNodes.find((n) => n.id === focusId)
   useEffect(() => {
-    const el = barRef.current
-    if (!el) return
-    const measure = () => setBarHeight(Math.max(40, Math.ceil(el.getBoundingClientRect().height)))
-    measure()
-    const ro = new ResizeObserver(measure)
-    ro.observe(el)
-    return () => ro.disconnect()
-  }, [status])
+    if (!showCanvas) return
+    if (focusId && !payloadNodes.some((n) => n.id === focusId)) setFocusId(null)
+    if (groupFilter && !groupKeys.includes(groupFilter)) setGroupFilter("")
+  }, [payloadNodes, groupKeys, focusId, groupFilter, showCanvas])
 
   useEffect(() => {
     const degree = new Map<string, number>()
@@ -244,7 +261,11 @@ export function KnowledgeGraphApp() {
     const ids = payloadNodes.map((n) => n.id)
     const radiusById = new Map(ids.map((id) => [id, radiusForDegree(degree.get(id) || 0)]))
     const { w, h } = sizeRef.current
-    nodesRef.current = seedLayoutNodes(ids, w, h, radiusById)
+    const previous = new Map(nodesRef.current.map((n) => [n.id, n]))
+    nodesRef.current = seedLayoutNodes(ids, w, h, radiusById).map((n) => {
+      const old = previous.get(n.id)
+      return old ? { ...old, r: n.r } : n
+    })
     const tfKeys = new Set(payloadEdges.map((e) => knowledgeGraphPairKey(e.a, e.b)))
     const reasonByPair = new Map<string, string>()
     for (const r of payloadRelations) {
@@ -265,6 +286,9 @@ export function KnowledgeGraphApp() {
     simTicksRef.current = 0
     fittedRef.current = false
     userCameraRef.current = false
+  }, [payloadNodes, payloadEdges, payloadRelations])
+
+  useEffect(() => {
     const byId = new Map(payloadNodes.map((n) => [n.id, n]))
     nodesByIdRef.current = byId
     const colors = new Map<string, string>()
@@ -275,7 +299,7 @@ export function KnowledgeGraphApp() {
     }
     colorByIdRef.current = colors
     captionByIdRef.current = captions
-  }, [payloadNodes, payloadEdges, payloadRelations, colorMode, labels])
+  }, [payloadNodes, colorMode, labels])
 
   const openDoc = useCallback((id: string) => {
     setFocusId(id)
@@ -285,35 +309,46 @@ export function KnowledgeGraphApp() {
     })
   }, [])
 
+  const onActionResponse = useCallback((res: { ok?: boolean; sent?: boolean } | undefined) => {
+    if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
+      setOrganizing(false)
+      setRequestError("请求未发送，请确认 CMspark 运行后重试。")
+    }
+  }, [])
+
+  useEffect(() => {
+    if (!organizing) return
+    const timer = setTimeout(() => {
+      setOrganizing(false)
+      setRequestError("尚未收到整理结果，请刷新查看当前状态后重试。")
+    }, 35_000)
+    return () => clearTimeout(timer)
+  }, [organizing])
+
   const onLlmChange = useCallback((enabled: boolean) => {
+    llmEnabledRef.current = enabled
     setLlmEnabled(enabled)
     void writeLlmLabelsPref(enabled)
     chrome.runtime.sendMessage(
       { type: "knowledge_graph.refresh", llm_labels: enabled },
-      () => {
-        void chrome.runtime.lastError
-      },
+      onActionResponse,
     )
-  }, [])
+  }, [onActionResponse])
 
   const onRegenerate = useCallback(() => {
     chrome.runtime.sendMessage(
       { type: "knowledge_graph.refresh", llm_labels: true, regenerate: true },
-      () => {
-        void chrome.runtime.lastError
-      },
+      onActionResponse,
     )
-  }, [])
+  }, [onActionResponse])
 
   const sendOrganize = useCallback(() => {
     setOrganizing(true)
     chrome.runtime.sendMessage(
       { type: "knowledge_graph.refresh", organize: true, llm_labels: llmEnabled },
-      () => {
-        void chrome.runtime.lastError
-      },
+      onActionResponse,
     )
-  }, [llmEnabled])
+  }, [llmEnabled, onActionResponse])
 
   const sendLock = useCallback((groupKey: string, unlock: boolean) => {
     chrome.runtime.sendMessage(
@@ -322,11 +357,9 @@ export function KnowledgeGraphApp() {
         llm_labels: llmEnabled,
         ...(unlock ? { unlock_group: groupKey } : { lock_group: groupKey }),
       },
-      () => {
-        void chrome.runtime.lastError
-      },
+      onActionResponse,
     )
-  }, [llmEnabled])
+  }, [llmEnabled, onActionResponse])
 
   useEffect(() => {
     if (snap?.lock_dissolved === true) setLockNotice(true)
@@ -336,38 +369,40 @@ export function KnowledgeGraphApp() {
     if (!showTfBanner) return
     // 本会话继续展示；落盘 ack 让关 tab 重开不再出现（AC-6）。
     void writeTfSwitchAck()
-    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", ack_tf_switch: true }, () => {
+    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", ack_tf_switch: true, llm_labels: llmEnabledRef.current }, () => {
       void chrome.runtime.lastError
     })
   }, [showTfBanner])
 
   const fitView = useCallback(() => {
-    const nodes = nodesRef.current
-    if (nodes.length === 0) return
     const { w, h } = sizeRef.current
-    let minX = Infinity
-    let minY = Infinity
-    let maxX = -Infinity
-    let maxY = -Infinity
-    for (const n of nodes) {
-      minX = Math.min(minX, n.x - n.r)
-      minY = Math.min(minY, n.y - n.r)
-      maxX = Math.max(maxX, n.x + n.r)
-      maxY = Math.max(maxY, n.y + n.r)
-    }
-    const gw = Math.max(40, maxX - minX)
-    const gh = Math.max(40, maxY - minY)
-    const pad = 56
-    const s = Math.min((w - pad * 2) / gw, (h - pad * 2) / gh, 1.35)
-    scaleRef.current = Math.max(0.45, Math.min(1.8, s * 0.92))
-    const cx = (minX + maxX) / 2
-    const cy = (minY + maxY) / 2
-    panRef.current.x = w / 2 - cx * scaleRef.current
-    panRef.current.y = h / 2 - cy * scaleRef.current
+    const camera = fitKnowledgeCamera(nodesRef.current, w, h)
+    scaleRef.current = camera.scale
+    panRef.current = { x: camera.x, y: camera.y }
     fittedRef.current = true
   }, [])
   fitViewRef.current = fitView
 
+  const locateNode = useCallback((id: string) => {
+    const n = nodesRef.current.find((node) => node.id === id)
+    if (!n) return
+    setFocusId(id)
+    setPanelOpen(true)
+    simTicksRef.current = 999
+    userCameraRef.current = true
+    scaleRef.current = Math.max(1, scaleRef.current)
+    panRef.current = { x: sizeRef.current.w / 2 - n.x * scaleRef.current, y: sizeRef.current.h / 2 - n.y * scaleRef.current }
+  }, [])
+
+  const zoom = useCallback((factor: number) => {
+    const prev = scaleRef.current
+    const next = Math.min(3.2, Math.max(0.08, prev * factor))
+    const { w, h } = sizeRef.current
+    panRef.current = { x: w / 2 - ((w / 2 - panRef.current.x) / prev) * next, y: h / 2 - ((h / 2 - panRef.current.y) / prev) * next }
+    scaleRef.current = next
+    userCameraRef.current = true
+  }, [])
+
   useEffect(() => {
     const canvas = canvasRef.current
     if (!canvas) return
@@ -383,6 +418,8 @@ export function KnowledgeGraphApp() {
       canvas.style.height = `${rect.height}px`
       const ctx = canvas.getContext("2d")
       if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
+      // Reflow changes the actual canvas area, not an overlay on the old area.
+      fitViewRef.current()
     }
     resize()
     const ro = new ResizeObserver(resize)
@@ -391,14 +428,16 @@ export function KnowledgeGraphApp() {
       const ctx = canvas.getContext("2d")
       if (!ctx) return
       const { w, h } = sizeRef.current
-      if (simTicksRef.current < 320 && nodesRef.current.length > 0) {
+      const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
+      for (let step = 0; step < (reduceMotion ? 320 : 6) && simTicksRef.current < 320 && nodesRef.current.length > 0; step++) {
         const e = forceLayoutTick(nodesRef.current, edgesRef.current, { width: w, height: h })
         simTicksRef.current++
         if ((e < 0.06 && simTicksRef.current > 50) || simTicksRef.current >= 320) {
           simTicksRef.current = 999
-          if (!fittedRef.current) fitViewRef.current()
+          if (!userCameraRef.current) fitViewRef.current()
         }
       }
+      if (!fittedRef.current && !userCameraRef.current) fitViewRef.current()
       ctx.clearRect(0, 0, w, h)
       ctx.fillStyle = G.canvas
       ctx.fillRect(0, 0, w, h)
@@ -440,7 +479,11 @@ export function KnowledgeGraphApp() {
           ctx.fillText(KNOWLEDGE_GRAPH_AI_RELATION, mx, my - 2)
         }
       }
-      for (const n of nodesRef.current) {
+      const labelBoxes: { x: number; y: number; w: number; h: number }[] = []
+      // Selected titles take priority; collisions only suppress canvas labels,
+      // never the complete accessible knowledge list.
+      const drawNodes = [...nodesRef.current].sort((a, b) => Number(b.id === active) - Number(a.id === active))
+      for (const n of drawNodes) {
         const isFocus = n.id === focusIdRef.current
         const isHover = n.id === hoverIdRef.current
         const inHot = hot ? hot.has(n.id) : true
@@ -459,18 +502,27 @@ export function KnowledgeGraphApp() {
           : isHover
             ? lightenHex(baseColor, 0.28)
             : dimmed
-              ? hexWithAlpha(baseColor, 0.28)
+              ? hexWithAlpha(baseColor, 0.7)
               : baseColor
-        ctx.globalAlpha = dimmed ? 0.5 : 1
+        ctx.globalAlpha = 1
         ctx.fill()
         ctx.globalAlpha = 1
-        if (isFocus || isHover) {
-          ctx.fillStyle = G.labelFocus
-          ctx.font = `${(isFocus ? 10.5 : 9) / Math.max(0.75, Math.min(1.25, scale))}px ${tokens.font}`
+        {
+          ctx.fillStyle = dimmed ? tokens.darkMuted : G.labelFocus
+          ctx.font = `${13 / scale}px ${tokens.font}`
           ctx.textAlign = "center"
           ctx.textBaseline = "top"
-          const cap = captionByIdRef.current.get(n.id) || n.id
-          ctx.fillText(cap, n.x, n.y + n.r + 2.5)
+          const doc = nodesByIdRef.current.get(n.id)
+          const cap = shortKnowledgeTitle(doc?.title || "", n.id, nodesRef.current.length <= 20 ? 18 : 12)
+          const textWidth = ctx.measureText(cap).width * scale
+          const sx = n.x * scale + panRef.current.x
+          const sy = (n.y + n.r) * scale + panRef.current.y + 7
+          const box = { x: sx - textWidth / 2, y: sy, w: textWidth, h: 17 }
+          const overlaps = labelBoxes.some((b) => box.x < b.x + b.w + 8 && box.x + box.w + 8 > b.x && box.y < b.y + b.h + 4 && box.y + box.h + 4 > b.y)
+          if ((isFocus || isHover || !overlaps) && box.x >= 2 && box.x + box.w <= w - 2 && sy + 17 < h) {
+            labelBoxes.push(box)
+            ctx.fillText(cap, n.x, n.y + n.r + 7 / scale)
+          }
         }
       }
       ctx.restore()
@@ -481,7 +533,7 @@ export function KnowledgeGraphApp() {
       ro.disconnect()
       cancelAnimationFrame(rafRef.current)
     }
-  }, [])
+  }, [showCanvas])
 
   const hitTest = (clientX: number, clientY: number): LayoutNode | null => {
     const canvas = canvasRef.current
@@ -539,11 +591,12 @@ export function KnowledgeGraphApp() {
   const endDrag = (ev?: ReactPointerEvent) => {
     const drag = dragRef.current
     if (drag && drag.id !== "__pan__" && !drag.moved) {
-      openDoc(drag.id)
+      locateNode(drag.id)
     }
     if (drag && drag.id === "__pan__" && !drag.moved && ev) {
       const edge = hitTestEdge(ev.clientX, ev.clientY)
       if (edge?.reason) {
+        setPanelOpen(true)
         setRelationOpen({
           a: edge.a,
           b: edge.b,
@@ -622,232 +675,184 @@ export function KnowledgeGraphApp() {
     const mx = ev.clientX - rect.left
     const my = ev.clientY - rect.top
     const prev = scaleRef.current
-    const next = Math.min(3.2, Math.max(0.28, prev * (ev.deltaY > 0 ? 0.92 : 1.08)))
+    const next = Math.min(3.2, Math.max(0.08, prev * (ev.deltaY > 0 ? 0.92 : 1.08)))
     panRef.current.x = mx - ((mx - panRef.current.x) / prev) * next
     panRef.current.y = my - ((my - panRef.current.y) / prev) * next
     scaleRef.current = next
     userCameraRef.current = true
   }
 
-  const chromeTop = barHeight + 20
   const ungroupedKey = groupKeys.find((k) => k === "u:ungrouped" || k === "" || k === "ungrouped")
+  const relatedEdges: GraphDrawEdge[] = selected ? [
+    ...payloadEdges.map((e) => ({ ...e, reason: payloadRelations.find((r) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))?.reason })),
+    ...payloadRelations.filter((r) => !payloadEdges.some((e) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))).map((r) => ({ ...r, score: r.confidence, dashed: true })),
+  ].filter((e) => e.a === selected.id || e.b === selected.id) : []
 
   return (
-    <div style={styles.page}>
-      <div ref={barRef} style={styles.floatBar} role="toolbar" aria-label={`${KNOWLEDGE_GRAPH_ENTRY_LABEL}工具栏`}>
-        <strong style={styles.barTitle}>{KNOWLEDGE_GRAPH_ENTRY_LABEL}</strong>
+    <div className="kg-page" style={styles.page}>
+      <style>{graphStyles}</style>
+      <header className="kg-toolbar" role="toolbar" aria-label={`${KNOWLEDGE_GRAPH_ENTRY_LABEL}工具栏`}>
+        <div className="kg-heading"><strong>{KNOWLEDGE_GRAPH_ENTRY_LABEL}</strong><span>{showCanvas ? knowledgeGraphBarMeta(payloadNodes.length, payloadEdges.length, payloadRelations.length) : "浏览知识与关联"}</span></div>
         <KnowledgeGraphColorSwitch mode={colorMode} onChange={setColorMode} />
-        <KnowledgeGraphLlmSwitch
-          enabled={llmEnabled}
-          onChange={onLlmChange}
-          onRegenerate={onRegenerate}
-        />
-        {showReorganize ? (
-          <KnowledgeGraphReorganizeButton
-            organizing={organizing}
-            disabled={!llmReady}
-            onClick={sendOrganize}
-          />
-        ) : null}
-        {snap?.stale === true && llmLane ? <KnowledgeGraphStaleBadge /> : null}
-        <span style={styles.barMeta}>
-          {showCanvas
-            ? knowledgeGraphBarMeta(payloadNodes.length, payloadEdges.length, payloadRelations.length)
-            : ""}
-        </span>
-        <button type="button" style={styles.barBtnGhost} onClick={() => setPanelOpen((v) => !v)}>
-          {panelOpen ? "收起面板" : "分组"}
-        </button>
-        <button type="button" style={styles.barBtnGhost} onClick={() => window.close()} title="关闭此标签页">
-          关闭
-        </button>
+        <button type="button" onClick={refresh}>刷新图谱</button>
+        <button type="button" aria-expanded={panelOpen} onClick={() => setPanelOpen((v) => !v)}>{panelOpen ? "收起列表" : "浏览知识"}</button>
+        <details className="kg-ai-options">
+          <summary>AI 与分组</summary>
+          <div>
+            <KnowledgeGraphLlmSwitch enabled={llmEnabled} onChange={onLlmChange} onRegenerate={onRegenerate} />
+            {showReorganize ? <KnowledgeGraphReorganizeButton organizing={organizing} disabled={!llmReady} onClick={sendOrganize} /> : null}
+            {snap?.stale === true && llmLane ? <KnowledgeGraphStaleBadge /> : null}
+          </div>
+        </details>
+        <button type="button" onClick={() => window.close()} title="关闭此标签页">关闭</button>
+      </header>
+      <div className="kg-notices">
+        {requestError ? <div className="kg-notice" role="alert">{requestError}</div> : null}
+        {status !== "ok" ? <KnowledgeGraphStatusView status={status} truncated={truncated} pollExhausted={pollExhausted} error={snap?.error} /> : null}
+        {status === "ok" && showOrganizeCta ? <KnowledgeGraphOrganizeCta n={payloadNodes.length} disabled={!llmReady} organizing={organizing} onOrganize={sendOrganize} /> : null}
+        {status === "ok" && snap?.organize_error ? <KnowledgeGraphOrganizeErrorBar error={snap.organize_error} onRetry={sendOrganize} /> : null}
+        {showTfBanner ? <KnowledgeGraphTfSwitchBanner /> : null}
+        {lockNotice ? <div className="kg-notice"><KnowledgeGraphLockDissolvedBanner /><button onClick={() => setLockNotice(false)}>知道了</button></div> : null}
       </div>
-
-      {status !== "ok" && (
-        <div style={{ ...styles.banner, top: chromeTop }}>
-          <KnowledgeGraphStatusView status={status} truncated={truncated} pollExhausted={pollExhausted} error={snap?.error} />
-        </div>
-      )}
-
-      {status === "ok" && showOrganizeCta ? (
-        <div style={{ ...styles.banner, top: chromeTop }}>
-          <KnowledgeGraphOrganizeCta
-            n={payloadNodes.length}
-            disabled={!llmReady}
-            organizing={organizing}
-            onOrganize={sendOrganize}
-          />
-        </div>
-      ) : null}
-
-      {status === "ok" && snap?.organize_error ? (
-        <div style={{ ...styles.banner, top: chromeTop + (showOrganizeCta ? 56 : 0) }}>
-          <KnowledgeGraphOrganizeErrorBar error={snap.organize_error} onRetry={sendOrganize} />
-        </div>
-      ) : null}
-
-      {showTfBanner ? (
-        <div style={{ ...styles.banner, top: chromeTop }}>
-          <KnowledgeGraphTfSwitchBanner />
-        </div>
-      ) : null}
-
-      {lockNotice ? (
-        <div style={{ ...styles.banner, top: chromeTop }}>
-          <KnowledgeGraphLockDissolvedBanner />
-        </div>
-      ) : null}
-
-      {hoverCaptionText ? (
-        <div style={{ ...styles.hoverChip, top: chromeTop }} role="status">
-          {hoverCaptionText}
-        </div>
-      ) : null}
-
-      {panelOpen && (
-        <aside style={{ ...styles.floatPanel, top: chromeTop }} aria-label="分组">
-          <div style={styles.asideTitle}>分组</div>
-          {showNoRelations ? <KnowledgeGraphNoRelationsNote /> : null}
-          {groupKeys.length === 0 ? (
-            <div style={{ fontSize: 11, color: tokens.darkMuted }}>
-              {status === "too_few" || status === "rebuilding" ? "" : KNOWLEDGE_GRAPH_UNGROUPED_LABEL}
+      <div className={`kg-workspace ${panelOpen ? "" : "kg-workspace-wide"}`}>
+        <section className="kg-map" aria-label="知识关系画布">
+          <div className="kg-map-tools">
+            <span>实线：内容相似 · 虚线：AI 关联</span>
+            <div>
+              <button type="button" disabled={!showCanvas} onClick={() => { userCameraRef.current = false; fitView() }}>适应画布</button>
+              <button type="button" disabled={!showCanvas} aria-label="放大" onClick={() => zoom(1.25)}>＋</button>
+              <button type="button" disabled={!showCanvas} aria-label="缩小" onClick={() => zoom(0.8)}>－</button>
+            </div>
+          </div>
+          <main style={styles.main}>
+            {showCanvas ? <canvas ref={canvasRef} data-testid="knowledge-graph-canvas" style={styles.canvas} role="img" tabIndex={0}
+              aria-label="知识分布图谱。点击节点查看关联；也可在知识列表搜索并定位。方向键平移，加减号缩放，0 适应画布。"
+              onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={(ev) => endDrag(ev)}
+              onPointerLeave={() => { hoverIdRef.current = null; setHoverCaptionText("") }}
+              onPointerCancel={() => { dragRef.current = null }}
+              onWheel={onWheel}
+              onKeyDown={(ev) => {
+                if (ev.key === "0" || ev.key === "Home") { ev.preventDefault(); userCameraRef.current = false; fitView() }
+                if (ev.key === "+" || ev.key === "=" || ev.key === "-") { ev.preventDefault(); zoom(ev.key === "-" ? 0.8 : 1.25) }
+                const delta: Record<string, [number, number]> = { ArrowLeft: [40, 0], ArrowRight: [-40, 0], ArrowUp: [0, 40], ArrowDown: [0, -40] }
+                if (delta[ev.key]) { ev.preventDefault(); userCameraRef.current = true; panRef.current.x += delta[ev.key][0]; panRef.current.y += delta[ev.key][1] }
+                if (ev.key === "Escape") { setFocusId(null); setRelationOpen(null) }
+              }}
+            /> : <div className="kg-placeholder">知识文档和真实关联将在这里显示</div>}
+          </main>
+          <div className="kg-map-caption" role="status">
+            {hoverCaptionText || (showCanvas && !payloadEdges.length && !payloadRelations.length ? "暂无明确关联，仍可浏览全部知识" : "拖动画布 · 滚轮缩放 · 点击知识查看关联")}
+          </div>
+        </section>
+        {panelOpen ? (
+          <aside className="kg-explorer" aria-label="知识浏览">
+            <div className="kg-search">
+              <label htmlFor="kg-search">浏览知识</label>
+              <input id="kg-search" aria-label="搜索知识" placeholder="搜索标题、文件夹…" value={query} onChange={(ev) => setQuery(ev.target.value)} />
+              <select aria-label="筛选分组" value={groupFilter} onChange={(ev) => setGroupFilter(ev.target.value)}>
+                <option value="">全部分组</option>
+                {groupKeys.map((k) => <option key={k} value={k}>{labels[k]?.name || (k === ungroupedKey ? KNOWLEDGE_GRAPH_UNGROUPED_LABEL : k)}</option>)}
+              </select>
+              <span role="status">{visibleNodes.length} / {payloadNodes.length} 篇知识</span>
             </div>
-          ) : (
-            groupKeys.map((k) => {
-              const llmGroup = k.startsWith("l:")
-              return (
-                <KnowledgeGraphGroupCard
-                  key={k}
-                  groupKey={k}
-                  label={
-                    labels[k] ||
-                    (k === ungroupedKey ? { name: KNOWLEDGE_GRAPH_UNGROUPED_LABEL, ai: false } : undefined)
-                  }
-                  llmEnabled={llmEnabled}
-                  llmLaneGroup={llmGroup}
+            {selected ? <section className="kg-selection" aria-label="选中知识">
+              <div className="kg-selection-heading"><strong>{selected.title || selected.id}</strong><button aria-label="取消选中知识" onClick={() => setFocusId(null)}>取消</button></div>
+              <p>{selected.folder || "未设置文件夹"}</p>
+              <button type="button" onClick={() => openDoc(selected.id)}>在知识面板打开</button>
+              <h3>相关知识 · {relatedEdges.length}</h3>
+              {relatedEdges.length === 0 ? <p>暂无明确关联</p> : relatedEdges.map((edge) => {
+                const id = edge.a === selected.id ? edge.b : edge.a
+                const other = payloadNodes.find((node) => node.id === id)
+                return <div key={id} className="kg-relation">
+                  <button type="button" onClick={() => locateNode(id)}>{other?.title || id}</button>
+                  <span>{edge.dashed ? "AI 关联" : "内容相似"}</span>
+                  {edge.reason ? <p>AI 关联理由：{edge.reason}</p> : null}
+                </div>
+              })}
+            </section> : null}
+            {relationOpen ? <section className="kg-selection" aria-label="关联理由" data-testid="kg-relation-reason">
+              <strong>{KNOWLEDGE_GRAPH_AI_RELATION}</strong><p>{relationOpen.reason}</p>
+              <button type="button" onClick={() => setRelationOpen(null)}>{KNOWLEDGE_GRAPH_REASON_DISMISS}</button>
+            </section> : null}
+            <div className="kg-document-list" aria-label="知识列表">
+              {visibleNodes.map((n) => <button type="button" key={n.id} data-node-id={n.id} aria-pressed={n.id === focusId} onClick={() => locateNode(n.id)}>
+                <span className="kg-dot" style={{ background: nodeColor(n, colorMode) }} aria-hidden="true" />
+                <span><strong>{n.title || n.id}</strong><small>{n.folder || labels[n.group_key]?.name || KNOWLEDGE_GRAPH_UNGROUPED_LABEL}</small></span>
+              </button>)}
+              {!visibleNodes.length ? <p>{payloadNodes.length ? "没有匹配的知识。可清空搜索或切换分组。" : "当前没有可浏览的知识。"}</p> : null}
+              {(query || groupFilter) ? <button type="button" onClick={() => { setQuery(""); setGroupFilter("") }}>清除筛选</button> : null}
+            </div>
+            <details className="kg-groups" open={payloadNodes.length <= 19}>
+              <summary>分组说明与管理 · {groupKeys.length}</summary>
+              {showNoRelations ? <KnowledgeGraphNoRelationsNote /> : null}
+              {groupKeys.map((k) => {
+                const llmGroup = k.startsWith("l:")
+                return <KnowledgeGraphGroupCard key={k} groupKey={k}
+                  label={labels[k] || (k === ungroupedKey ? { name: KNOWLEDGE_GRAPH_UNGROUPED_LABEL, ai: false } : undefined)}
+                  llmEnabled={llmEnabled} llmLaneGroup={llmGroup}
                   onLock={llmLane && llmGroup ? () => sendLock(k, false) : undefined}
-                  onUnlock={
-                    llmGroup && labels[k]?.locked === true ? () => sendLock(k, true) : undefined
-                  }
-                />
-              )
-            })
-          )}
-        </aside>
-      )}
-
-      {relationOpen ? (
-        <div
-          style={{ ...styles.hoverChip, top: chromeTop + 36, maxWidth: "70%" }}
-          role="dialog"
-          data-testid="kg-relation-reason"
-        >
-          <strong style={{ fontSize: 11 }}>{KNOWLEDGE_GRAPH_AI_RELATION}</strong>
-          <div style={{ marginTop: 4 }}>{relationOpen.reason}</div>
-          <button type="button" style={styles.barBtnGhost} onClick={() => setRelationOpen(null)}>
-            {KNOWLEDGE_GRAPH_REASON_DISMISS}
-          </button>
-        </div>
-      ) : null}
-
-      <main style={styles.main}>
-        {showCanvas && (
-          <canvas
-            ref={canvasRef}
-            style={styles.canvas}
-            role="img"
-            tabIndex={0}
-            aria-label="知识分布图谱。悬停显示标题与分组，点击节点在知识面板打开文档。"
-            onPointerDown={onPointerDown}
-            onPointerMove={onPointerMove}
-            onPointerUp={(ev) => endDrag(ev)}
-            onPointerLeave={() => {
-              hoverIdRef.current = null
-              setHoverCaptionText("")
-            }}
-            onPointerCancel={(ev) => endDrag(ev)}
-            onWheel={onWheel}
-          />
-        )}
-      </main>
+                  onUnlock={llmGroup && labels[k]?.locked === true ? () => sendLock(k, true) : undefined} />
+              })}
+            </details>
+          </aside>
+        ) : null}
+      </div>
     </div>
   )
 }
 
-const glass: CSSProperties = {
-  background: tokens.darkElevated,
-  border: `1px solid ${tokens.darkBorder}`,
-  boxShadow: "0 8px 28px rgba(0,0,0,0.35)",
-  // Solid surface keeps graph controls legible without translucent layering.
-}
-
 const styles: Record<string, CSSProperties> = {
-  page: {
-    position: "relative",
-    height: "100vh",
-    margin: 0,
-    fontFamily: tokens.font,
-    background: G.canvas,
-    color: tokens.darkText,
-    overflow: "hidden",
-  },
-  floatBar: {
-    ...glass,
-    position: "absolute",
-    zIndex: 10,
-    top: 12,
-    left: 12,
-    right: 12,
-    display: "flex",
-    flexWrap: "wrap",
-    alignItems: "center",
-    gap: 10,
-    padding: "8px 12px",
-    borderRadius: 12,
-  },
-  barTitle: { fontSize: 13, fontWeight: 650, letterSpacing: "0.02em" },
-  barMeta: { fontSize: 11, color: tokens.darkMuted, marginLeft: "auto" },
-  barBtnGhost: {
-    border: `1px solid ${tokens.darkBorder}`,
-    borderRadius: tokens.radiusMd,
-    background: "transparent",
-    color: tokens.darkMuted,
-    padding: "5px 10px",
-    fontSize: 11,
-    cursor: "pointer",
-    fontFamily: tokens.font,
-  },
-  banner: {
-    position: "absolute",
-    zIndex: 8,
-    left: 12,
-    right: 12,
-    ...glass,
-    borderRadius: 10,
-    color: tokens.darkText,
-  },
-  hoverChip: {
-    position: "absolute",
-    zIndex: 8,
-    left: 12,
-    ...glass,
-    borderRadius: 8,
-    padding: "4px 10px",
-    fontSize: 11,
-    maxWidth: "60%",
-  },
-  floatPanel: {
-    ...glass,
-    position: "absolute",
-    zIndex: 9,
-    right: 12,
-    width: 260,
-    maxHeight: "70vh",
-    overflow: "auto",
-    borderRadius: 12,
-    padding: 12,
-  },
-  asideTitle: { fontSize: 11, color: tokens.darkMuted, marginBottom: 8, fontWeight: 600 },
-  main: { position: "absolute", inset: 0 },
-  canvas: { width: "100%", height: "100%", display: "block", cursor: "grab", outline: "none" },
+  page: { minHeight: "100dvh", height: "100dvh", margin: 0, fontFamily: tokens.font, background: G.canvas, color: tokens.darkText, display: "flex", flexDirection: "column", overflow: "auto" },
+  main: { position: "relative", flex: 1, minHeight: 280 },
+  canvas: { width: "100%", height: "100%", position: "absolute", inset: 0, display: "block", cursor: "grab", touchAction: "none" },
 }
+
+const graphStyles = `
+  .kg-page * { box-sizing: border-box; }
+  .kg-page button, .kg-page input, .kg-page select, .kg-page summary { font: inherit; font-size: 13px; }
+  .kg-page button { min-height: 32px; border: 1px solid ${tokens.darkBorder}; background: transparent; color: ${tokens.darkText}; border-radius: 8px; padding: 5px 10px; cursor: pointer; }
+  .kg-page button:disabled { opacity: .45; cursor: not-allowed; }
+  .kg-page button:hover:not(:disabled), .kg-page button[aria-pressed=true] { background: ${tokens.darkElevated}; }
+  .kg-page :focus-visible { outline: 2px solid ${tokens.darkMuted}; outline-offset: 2px; }
+  .kg-page summary { cursor: pointer; padding: 8px 0; }
+  .kg-toolbar { padding: 16px 20px; border-bottom: 1px solid ${tokens.darkBorder}; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; flex-shrink: 0; }
+  .kg-heading { display: flex; flex-direction: column; gap: 4px; margin-right: auto; }
+  .kg-heading strong { font-size: 18px; }
+  .kg-heading span, .kg-search>span { color: ${tokens.darkMuted}; font-size: 12px; }
+  .kg-ai-options[open] { flex-basis: 100%; order: 2; }
+  .kg-ai-options>div { display: flex; flex-wrap: wrap; gap: 12px; padding: 8px 0; }
+  .kg-notices { flex-shrink: 0; max-height: 30dvh; overflow: auto; background: ${tokens.darkElevated}; }
+  .kg-notice { padding: 12px 16px; font-size: 13px; }
+  .kg-workspace { display: grid; grid-template-columns: minmax(0,1fr) 320px; flex: 1; min-height: 400px; }
+  .kg-workspace-wide { grid-template-columns: minmax(0,1fr); }
+  .kg-map { display: flex; flex-direction: column; min-width: 0; min-height: 360px; }
+  .kg-map-tools { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px; padding: 12px 16px; }
+  .kg-map-tools span, .kg-map-caption { color: ${tokens.darkMuted}; font-size: 12px; line-height: 1.5; }
+  .kg-map-tools>div { display: flex; gap: 6px; }
+  .kg-map-caption { padding: 8px 16px 12px; min-height: 38px; overflow-wrap: anywhere; }
+  .kg-placeholder { height: 100%; display: grid; place-items: center; color: ${tokens.darkMuted}; padding: 24px; text-align: center; }
+  .kg-explorer { overflow: auto; border-left: 1px solid ${tokens.darkBorder}; padding: 16px; min-width: 0; }
+  .kg-search { display: grid; gap: 10px; margin-bottom: 16px; position: sticky; top: 0; z-index: 1; background: ${G.canvas}; padding-bottom: 8px; }
+  .kg-search label { font-size: 14px; font-weight: 600; }
+  .kg-search input, .kg-search select { width: 100%; min-width: 0; min-height: 36px; background: ${tokens.darkElevated}; color: ${tokens.darkText}; border: 1px solid ${tokens.darkBorder}; border-radius: 8px; padding: 8px; }
+  .kg-document-list>button { width: 100%; display: flex; gap: 10px; align-items: center; text-align: left; border-color: transparent; padding: 10px 8px; }
+  .kg-document-list strong { font-size: 13px; font-weight: 500; overflow-wrap: anywhere; }
+  .kg-document-list small { display: block; color: ${tokens.darkMuted}; font-size: 12px; margin-top: 4px; overflow-wrap: anywhere; }
+  .kg-document-list p, .kg-selection p { font-size: 13px; line-height: 1.6; color: ${tokens.darkMuted}; overflow-wrap: anywhere; }
+  .kg-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
+  .kg-selection { padding: 12px; border: 1px solid ${tokens.darkBorder}; border-radius: 10px; margin-bottom: 12px; }
+  .kg-selection-heading { display: flex; align-items: start; gap: 8px; }
+  .kg-selection-heading strong { flex: 1; min-width: 0; overflow-wrap: anywhere; font-size: 14px; }
+  .kg-selection h3 { font-size: 13px; margin: 16px 0 8px; }
+  .kg-relation { margin-top: 10px; }
+  .kg-relation>button { display: block; text-align: left; overflow-wrap: anywhere; max-width: 100%; }
+  .kg-relation>span { display: block; font-size: 12px; color: ${tokens.darkMuted}; margin-top: 4px; }
+  .kg-groups { margin-top: 16px; border-top: 1px solid ${tokens.darkBorder}; }
+  @media(max-width: 759px) {
+    .kg-toolbar { padding: 12px; gap: 8px; }
+    .kg-heading { flex-basis: 100%; }
+    .kg-workspace, .kg-workspace-wide { display: flex; flex-direction: column; flex: none; min-height: 0; }
+    .kg-map { height: 440px; flex-shrink: 0; }
+    .kg-explorer { border-left: none; border-top: 1px solid ${tokens.darkBorder}; overflow: visible; }
+  }
+`
diff --git a/chrome-extension/src/knowledge-graph/copy.ts b/chrome-extension/src/knowledge-graph/copy.ts
index a802c0bb..cfdb4c85 100644
--- a/chrome-extension/src/knowledge-graph/copy.ts
+++ b/chrome-extension/src/knowledge-graph/copy.ts
@@ -2,13 +2,13 @@
 // 「图谱」仅限本视图；视图内分组用语只用「分组」。
 
 export const KNOWLEDGE_GRAPH_ENTRY_LABEL = "分布图谱"
-export const KNOWLEDGE_GRAPH_TOO_FEW_COPY = "知识不足 20 篇，暂无图谱"
+export const KNOWLEDGE_GRAPH_TOO_FEW_COPY = "知识库暂无可展示的文档，请先在知识面板导入或保存知识"
 export const KNOWLEDGE_GRAPH_OVER_CAP_COPY =
   "超过 200 篇，只画标题字典序前 200 篇；仅这 200 篇参与分组与着色"
 export const KNOWLEDGE_GRAPH_REBUILDING_COPY = "图谱索引重建中…"
 export const KNOWLEDGE_GRAPH_REBUILD_TIMEOUT_COPY = "索引重建超时，请手动刷新"
 /** #356: knowledge.graph 被门拒/出错映射的可见态（错误详情由调用方折叠展示）。 */
-export const KNOWLEDGE_GRAPH_ERROR_COPY = "图谱加载失败，可关闭后从知识面板重开"
+export const KNOWLEDGE_GRAPH_ERROR_COPY = "图谱加载失败，请重试刷新"
 /** #356: error 详情折叠开关文案（内部错误原文不直接铺开）。 */
 export const KNOWLEDGE_GRAPH_ERROR_DETAIL_LABEL = "技术详情"
 export const KNOWLEDGE_GRAPH_AI_BADGE = "AI 生成"
@@ -46,9 +46,9 @@ export function isKnowledgeGraphLlmLane(nodeCount: number): boolean {
 /** 工具栏边计数：有 AI 关联时拆 TF/AI，否则保持「N 点 · M 边」。 */
 export function knowledgeGraphBarMeta(nodeCount: number, tfEdges: number, aiRelations: number): string {
   if (aiRelations > 0) {
-    return `${nodeCount} 点 · TF ${tfEdges} 边 · AI ${aiRelations} 关联`
+    return `${nodeCount} 篇知识 · ${tfEdges} 条相似关联 · ${aiRelations} 条 AI 关联`
   }
-  return `${nodeCount} 点 · ${tfEdges} 边`
+  return `${nodeCount} 篇知识 · ${tfEdges} 条相似关联`
 }
 
 export type KnowledgeGraphStatus = "ok" | "too_few" | "over_cap" | "rebuilding" | "error"
diff --git a/chrome-extension/src/knowledge-graph/wire.ts b/chrome-extension/src/knowledge-graph/wire.ts
index 74316f0e..1e9523b0 100644
--- a/chrome-extension/src/knowledge-graph/wire.ts
+++ b/chrome-extension/src/knowledge-graph/wire.ts
@@ -57,6 +57,8 @@ export type KnowledgeGraphPayload = {
    * 无缓存帧省略或 false。
    */
   organized?: boolean
+  /** #490: actual server job state; initial graph response is not completion. */
+  organizing?: boolean
 }
 
 const STATUSES = new Set<KnowledgeGraphStatus>(["ok", "too_few", "over_cap", "rebuilding", "error"])
@@ -203,6 +205,7 @@ export function parseKnowledgeGraphPayload(raw: unknown): KnowledgeGraphPayload
     ...(typeof o.tf_switch_notice === "boolean" ? { tf_switch_notice: o.tf_switch_notice } : {}),
     ...(o.lock_dissolved === true ? { lock_dissolved: true } : {}),
     ...(o.organized === true ? { organized: true } : {}),
+    ...(typeof o.organizing === "boolean" ? { organizing: o.organizing } : {}),
   }
 }
 
@@ -227,6 +230,7 @@ export function mockKnowledgeGraphPayload(
       : {}),
     ...(partial.lock_dissolved === true ? { lock_dissolved: true } : {}),
     ...(partial.organized === true ? { organized: true } : {}),
+    ...(typeof partial.organizing === "boolean" ? { organizing: partial.organizing } : {}),
   }
 }
 
diff --git a/chrome-extension/tests/knowledge-graph-view.test.ts b/chrome-extension/tests/knowledge-graph-view.test.ts
index 08350e4e..1ee54149 100644
--- a/chrome-extension/tests/knowledge-graph-view.test.ts
+++ b/chrome-extension/tests/knowledge-graph-view.test.ts
@@ -88,7 +88,7 @@ function walkSource(dir: string): string[] {
 // --- 三态诚实文案（AC-3 / AC-5） ---
 
 test("copy pins: too_few / over_cap / rebuilding 逐字（AC-3/AC-5）", () => {
-  assert.equal(KNOWLEDGE_GRAPH_TOO_FEW_COPY, "知识不足 20 篇，暂无图谱")
+  assert.equal(KNOWLEDGE_GRAPH_TOO_FEW_COPY, "知识库暂无可展示的文档，请先在知识面板导入或保存知识")
   assert.equal(
     KNOWLEDGE_GRAPH_OVER_CAP_COPY,
     "超过 200 篇，只画标题字典序前 200 篇；仅这 200 篇参与分组与着色",
@@ -162,7 +162,7 @@ test("KnowledgeGraphStatusView 真渲染三态文案", () => {
   const tooFew = renderToStaticMarkup(
     createElement(KnowledgeGraphStatusView, { status: "too_few", truncated: false }),
   )
-  assert.ok(tooFew.includes("知识不足 20 篇，暂无图谱"), tooFew)
+  assert.ok(tooFew.includes("知识库暂无可展示的文档"), tooFew)
   assert.ok(!tooFew.includes("簇"), "视图内不得出现「簇」")
 
   const over = renderToStaticMarkup(
@@ -595,6 +595,6 @@ test("#427 App 层：CTA 只在 ok+2–19+无缓存；空结果无 CTA 有散点
 })
 
 test("#427 barMeta：有 AI 关联时拆 TF/AI", () => {
-  assert.equal(knowledgeGraphBarMeta(4, 3, 0), "4 点 · 3 边")
-  assert.equal(knowledgeGraphBarMeta(4, 3, 2), "4 点 · TF 3 边 · AI 2 关联")
+  assert.equal(knowledgeGraphBarMeta(4, 3, 0), "4 篇知识 · 3 条相似关联")
+  assert.equal(knowledgeGraphBarMeta(4, 3, 2), "4 篇知识 · 3 条相似关联 · 2 条 AI 关联")
 })
diff --git a/companion/src/message-router.ts b/companion/src/message-router.ts
index 97002302..45408fab 100644
--- a/companion/src/message-router.ts
+++ b/companion/src/message-router.ts
@@ -618,6 +618,8 @@ function knowledgeGraphFrame(
     edges: core.edges,
     labels: core.labels,
     llm_ready: knowledgeExtractLlmConfig() !== null,
+    // Initial ACK and intermediate refreshes must not look like organize completion.
+    organizing: knowledgeGraphOrganizeRun !== null,
   }
   if (core.llmLane) {
     // pi MAJOR-1（修复）：relations 在场 = graph_llm 缓存存在（空数组 = 组织过
@@ -3754,6 +3756,7 @@ export async function handleMessage(
           edges: [],
           labels: {},
           llm_ready: knowledgeExtractLlmConfig() !== null,
+          organizing: knowledgeGraphOrganizeRun !== null,
           ...(actionError ? { organize_error: actionError } : {}),
         }
       }
diff --git a/companion/src/skills/knowledge-graph.ts b/companion/src/skills/knowledge-graph.ts
index c862a8d1..719d9376 100644
--- a/companion/src/skills/knowledge-graph.ts
+++ b/companion/src/skills/knowledge-graph.ts
@@ -181,11 +181,14 @@ export function buildKnowledgeGraph(
   const byId = new Map(selected.map((d) => [d.id, d]))
   const groupOf = new Map<string, string>()
   for (const g of groups) for (const id of g.ids) groupOf.set(id, `c:${g.key}`)
-  for (const g of opts?.llm?.groups ?? []) {
-    // 同成员集合两组：先到先得（后组撞已占键自然被盖）
-    const key = lGroupKey(g.ids)
-    for (const id of g.ids) {
-      if (byId.has(id) && !groupOf.has(id)) groupOf.set(id, key)
+  // 跨 20 后旧 LLM 缓存仍保留，但只有显式锁组可覆盖 TF 分组。
+  if (llmLane) {
+    for (const g of opts?.llm?.groups ?? []) {
+      // 同成员集合两组：先到先得（后组撞已占键自然被盖）
+      const key = lGroupKey(g.ids)
+      for (const id of g.ids) {
+        if (byId.has(id) && !groupOf.has(id)) groupOf.set(id, key)
+      }
     }
   }
 
diff --git a/companion/tests/knowledge-graph-organize.test.ts b/companion/tests/knowledge-graph-organize.test.ts
index bb9567fe..3a078203 100644
--- a/companion/tests/knowledge-graph-organize.test.ts
+++ b/companion/tests/knowledge-graph-organize.test.ts
@@ -108,6 +108,7 @@ type OrganizeFrame = {
   llm_ready: boolean
   organize_error?: string
   organized?: boolean
+  organizing?: boolean
   stale?: boolean
   lock_dissolved?: boolean
   tf_switch_notice?: boolean
@@ -117,6 +118,70 @@ function readIndex(): import("../src/skills/knowledge-clusters").KnowledgeIndexF
   return clusters.readKnowledgeIndexFile(clusters.knowledgeIndexPath())
 }
 
+for (const outcome of ["success", "failure"] as const) {
+  test(`#490 organize lifecycle: initial/refresh/rebuilding busy, ${outcome} completion idle`, async () => {
+    resetKnowledgeState()
+    const se = new SkillEngine()
+    seedGroup(se, 3, `lifecycle-${outcome}`)
+    const docs = se.getKnowledgeDocsForOrganize()
+    const ids = docs.map((d) => d.id)
+    const rawResult = JSON.stringify({ groups: [{ name: "完成分组", ids }], relations: [] })
+    if (outcome === "failure") {
+      // Reorganizing an existing cache must remain busy even though organized is true.
+      const normalized = kg.normalizeGraphOrganize(kg.parseGraphOrganize(rawResult)!, new Set(ids), new Set())
+      se.setKnowledgeGraphLlmSection({
+        fingerprint: kg.computeGraphLlmFingerprint(docs),
+        groups: normalized.groups,
+        relations: normalized.relations,
+        stale: false,
+      })
+    }
+    let release!: (value: string) => void
+    let reject!: (error: Error) => void
+    const pending = new Promise<string>((resolve, fail) => { release = resolve; reject = fail })
+    __testSetKnowledgeGraphOrganizeImpl(() => pending)
+    let complete!: (frame: OrganizeFrame) => void
+    const completed = new Promise<OrganizeFrame>((resolve) => { complete = resolve })
+    const session = { surface: "panel", sendToExtension: complete } as never
+    const context = { skillEngine: se } as never
+    const initial = await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, context, session) as OrganizeFrame
+    const intermediate = await handleMessage({ type: "knowledge.graph" }, context, session) as OrganizeFrame
+    const getGraph = se.getKnowledgeGraph
+    let rebuilding: OrganizeFrame
+    try {
+      se.getKnowledgeGraph = () => null
+      rebuilding = await handleMessage({ type: "knowledge.graph" }, context, session) as OrganizeFrame
+    } finally {
+      se.getKnowledgeGraph = getGraph
+    }
+    if (outcome === "failure") reject(new Error("fixture organize failure"))
+    else release(rawResult)
+    const final = await completed
+    const after = await handleMessage({ type: "knowledge.graph" }, context, session) as OrganizeFrame
+    // Optional reusable fixture: serialize actual handler responses and push, never guessed wire fields.
+    const artifactDir = process.env.CMSPARK_TEST_GRAPH_ARTIFACT_DIR
+    if (artifactDir) {
+      fs.mkdirSync(artifactDir, { recursive: true })
+      fs.writeFileSync(path.join(artifactDir, `organize-${outcome}-frames.json`), JSON.stringify({ initial, intermediate, rebuilding, final, after }, null, 2) + "\n")
+    }
+    assert.equal(initial.organizing, true, "initial graph ACK does not complete the organize operation")
+    assert.equal(intermediate.organizing, true, "read-only refresh observes the in-flight operation")
+    assert.equal(rebuilding.status, "rebuilding")
+    assert.equal(rebuilding.organizing, true, "index unavailability must not clear the operation state")
+    assert.equal(final.organizing, false, "settled push clears busy state before serialization")
+    assert.equal(after.organizing, false)
+    assert.equal(final.status, "ok", "organize failure preserves the readable graph")
+    assert.equal(final.organized, true)
+    if (outcome === "failure") {
+      assert.equal(initial.organized, true)
+      assert.equal(final.organize_error, "AI 整理失败，请重试")
+    } else {
+      assert.equal(initial.organized, undefined)
+      assert.equal(final.organize_error, undefined)
+    }
+  })
+}
+
 test("#427 AC-1: organize happy path——首响应无产物，settle 推帧带 relations + l: 分组，缓存落盘", async () => {
   resetKnowledgeState()
   const se = new SkillEngine()
diff --git a/companion/tests/knowledge-graph.test.ts b/companion/tests/knowledge-graph.test.ts
index 12069af2..e034c0f5 100644
--- a/companion/tests/knowledge-graph.test.ts
+++ b/companion/tests/knowledge-graph.test.ts
@@ -628,6 +628,63 @@ test("#427 锁 overlay：改写 group_key + 注入 ai:true/locked:true labels；
   assert.deepEqual(r.relations, [], "无 graph_llm 缓存 → relations 恒空")
 })
 
+test("#490 19→20：旧未锁 AI 分组退出，节点与标签恢复 TF 结果", () => {
+  const docs = orthoDocs("transition", 20)
+  const smallDocs = docs.slice(0, 19)
+  // 复现：小语料整理后新增第 20 篇，graph_llm 缓存仍由引擎携带。
+  // 旧实现把未锁组带入 TF lane，却没有生成对应 labels（代码归责）。
+  // 使用生产归一化产物保护 lane 切换，不手造 wire 帧。
+  const llm = kg.normalizeGraphOrganize({
+    groups: [{ name: "旧 AI 分组", ids: [docs[0].id, docs[1].id] }],
+    relations: [{ a: docs[0].id, b: docs[1].id, reason: "同一主题", confidence: 0.8 }],
+  }, new Set(smallDocs.map((d) => d.id)), new Set())
+  const small = kg.buildKnowledgeGraph(smallDocs, undefined, { llm })
+  const key = kg.lGroupKey([docs[0].id, docs[1].id])
+  assert.equal(small.llmLane, true)
+  assert.equal(small.nodes.find((n) => n.id === docs[0].id)!.group_key, key)
+  assert.equal(small.labels[key].name, "旧 AI 分组")
+  assert.equal(small.relations.length, 1)
+
+  const grown = kg.buildKnowledgeGraph(docs, undefined, { llm })
+  const tf = kg.buildKnowledgeGraph(docs)
+  assert.equal(grown.llmLane, false)
+  assert.deepEqual(grown.nodes, tf.nodes, "未锁的旧 AI 分组不能改变 TF 节点归属")
+  assert.deepEqual(grown.labels, tf.labels)
+  assert.deepEqual(grown.edges, tf.edges)
+  assert.deepEqual(grown.relations, [])
+  assert.ok(grown.nodes.every((n) => grown.labels[n.group_key]), "每个节点分组都必须有标签")
+})
+
+test("#490 19→20：旧缓存退出时显式锁组仍保留", () => {
+  const docs = orthoDocs("locked-transition", 20)
+  const smallDocs = docs.slice(0, 19)
+  const llm = kg.normalizeGraphOrganize({
+    groups: [
+      { name: "未锁组", ids: [docs[0].id, docs[1].id] },
+      { name: "保留的组", ids: [docs[2].id, docs[3].id] },
+    ],
+    relations: [],
+  }, new Set(smallDocs.map((d) => d.id)), new Set())
+  const lockedGroup = llm.groups.find((g) => g.name === "保留的组")!
+  assert.ok(lockedGroup)
+  const lock = { groups: [lockedGroup] }
+  const key = kg.lGroupKey(lockedGroup.ids)
+  const small = kg.buildKnowledgeGraph(smallDocs, undefined, { llm, lock })
+  assert.equal(small.llmLane, true)
+  assert.equal(small.labels[key].locked, true)
+
+  const grown = kg.buildKnowledgeGraph(docs, undefined, { llm, lock })
+  const tfWithLock = kg.buildKnowledgeGraph(docs, undefined, { lock })
+  assert.equal(grown.llmLane, false)
+  assert.deepEqual(grown.nodes, tfWithLock.nodes, "仅显式锁组可跨越 lane")
+  assert.deepEqual(grown.labels, tfWithLock.labels)
+  assert.equal(grown.labels[key].name, "保留的组")
+  assert.equal(grown.labels[key].locked, true)
+  for (const id of lockedGroup.ids) {
+    assert.equal(grown.nodes.find((n) => n.id === id)!.group_key, key)
+  }
+})
+
 test("#427 锁跨活：≥20 帧锁 overlay 照常生效且 relations 永不上帧", () => {
   const groupA = [1, 2, 3, 4].map((i) => mkDoc(`a${i}`, { alpha: 0.8, [`pa${i}`]: 0.2 }, ["sharedalpha"], `A${i}`))
   const rest = orthoDocs("q", 16)

```

### FULL CHANGELOG.md
```
# Changelog

格式大致遵循 [Keep a Changelog](https://keepachangelog.com/)。版本号与 `companion/package.json` / `chrome-extension/package.json` 对齐。

## [Unreleased]

- 知识图谱（#490）：修复异步快照到达后画布未绘制及跨 20 篇残留旧未锁 AI 分组；新增可搜索知识列表、节点定位、默认标题、缩放/适应画布与刷新恢复，保留分组和 AI 关联能力。
- Windows 对话管理复审修复（#488）：全选遵循当前筛选，整理建议与列表选择分开；删除和恢复按 50 条分批并等待真实回执，保留失败项，清理空白改为应用内确认并在服务端复核内容。短窗口可滚动访问列表和操作，保留标签、人工/AI 分组、整理及图谱入口。
- 会议关闭（#488）：收起、切换面板和打开设置先等待最后一段转写的相关写入回执及结束确认；失败保留草稿，可显式“保存转写”后重试。工作区统一连接图标，资源抽屉区分全局配置与对话使用范围。

## [0.6.7] — 2026-09-08

S107 六路对抗 + Claude/Kimi dual AWN 关门：活文档与代码锁步，不把 0.7.0 企业双场景验收算进本切点（#230 仍冻，#228 禁扩默认 outbound）。

- **文档诚实**：README / PRODUCT / CLAUDE / GOAL / architecture / 召唤器与听写指南锁 **0.6.7**。Capture 默认 **1040×760**（`OVERLAY_WINDOW_SIZE`），360×420 为紧凑档。知识「全选」改为 TF-IDF top-k（auto 5 / all 8）+ 8000 字预算，不再写灌库。#258–#260 从余项拿掉（embedding 仍 experimental）。GOAL G19 不再把交互式 PTY 当非目标（#432 Darwin-only、默认关、Windows unsupported）。
- **会议 Host「收起」**：录音进行中文案改为「结束并收起」（unmount 仍 `meeting.end`，防 status=recording 卡住）。恢复路径「设置 → 听写」改为「设置 → 输入与语音」。
- **CLI**：`--version` / `-V` / `version` 打印一行并 exit 0；`status` / `stop` 不再撒谎，分别等同 `daemon status` / `daemon stop`。
- **持久化**：assistant `tool_calls[].function.arguments` 落盘前走与 tool-role 同一套 `redactToolPayloadForPersistence`；非法 JSON 不留原文。
- **版本锚**：companion / extension / NSIS fallback / ACP / outbound serverInfo / lockfile 齐 **0.6.7**（extension lockfile 此前仍写 0.6.3）。

以下条目此前写在 Unreleased、已在 main，随 0.6.7 归档（企业双场景仍非 0.7.0 GA）：

- 听写修复（#482）：召唤器遵循所选引擎，展示启动/识别状态并接收实际 HTTP 转写结果；音频块按序上传，切换对话及取消后丢弃旧结果。插件普通本机听写复用渐进预览，停止后保留完整推理等待，不再套用连续会议的短截止时间。
- 代码工作归属修复（#483）：按会话缓存、按对话展示代码运行；后台和迟到事件不打开新对话面板，操作携带所属对话并核对服务端会话，目录选择与 Git 状态回包也按归属隔离。
- 工作空间整理（#481）：召唤器补齐人工标签/手动分组及派生查看方式，使用共享校验和真实保存回执；两端对话优先、辅助入口收纳为“资料与工具”。完成整体 UI/UX 审计和独立项目层级方案；项目实体、原生完整工作台仍未交付。

- 召唤器工作空间首批（#477 / #476）：宽窗口与紧凑切换、文字资源导航、独立历史搜索、可见停止按钮和现有 Chrome 连接入口；MCP 保持只读，完整桌面管理与终端仍在 #476 跟踪。

- 扩展、应用与托盘采用清晰连接图标；托盘去掉重复状态标题，绿实心运行 / 红空心停止 / 黄未知，保留状态详情与可访问说明（#474）。Windows桌面/开始菜单、安装与卸载器同步使用新应用ICO，并在打包时检查图标资产。

- 对话管理入口与分类（#473）：窄栏顶栏常驻“+”，显式对话管理/AI提取/规则整理/图谱入口；新增独立人工标签、应用内手动分组编辑及按 AI 主标签派生的分组视图。匹配服务端确认后才显示保存成功，管理面板让出停止和待确认操作。

- 召唤器与设置重设计（#471）：删除召唤器所有装饰性“山”，统一聊天输入和操作布局；设置改为八类导航页面，保留草稿和深链，明确保存范围，补齐语音取消及许可证弹窗键盘隔离。

- 整体 UI/UX 工作区重设计（#469）：宽屏常驻导航与可读对话列，窄屏非遮罩导航，统一输入区、历史键盘操作、设置分类和上下文布局；终端、确认台、图谱、召唤窗口和独立设置页同步视觉语言。保持现有确认和执行策略。

- 代码审阅开发切片（#465/#466/#467）：从网页观察解析实际 unified diff，锁定仓库和完整 base/head；CMspark 网页评语与可选终端 Agent 报告分别保存，关联真实任务引用和材料版本。终端支持登录 shell、连接归属校验、显式确认回传及幂等回执；不自动执行 Agent。通用网页覆盖与业务关系仍待核实，真实企业双场景验收继续作为发布门槛。

- 升级验收工具（#457）：新增临时数据目录中的新旧源码往返演练与可复跑证据台账；验证旧版钥匙写入保留新字段、证据幂等和未知 schema 拒绝。两版共用当前依赖，不代表真实安装或企业场景验收。

- 企业上下文开发切片（#451/#452）：共享所选站点知识投影，绑定经过浏览器验证的目标；网页正文与导航来源同步采样，保留范围、覆盖和截断信息。
- 企业材料开发切片（#453）：新增 scope 内不可变证据、锁定试点契约、固定草稿核对与引用、revision/幂等回放及 Markdown/JSON 输出；缺失、未核实、冲突和过期不判材料齐备。
- 两个独立 Mission（#454/#455）：变更材料与研发追溯复用既有聊天执行链和工具白名单，不依赖 Codex/shell/CU。真实企业双场景验收仍是 0.7.0 发布前置条件，当前版本未升级。
- 可选 MCP 上下文出口（#456）：独立 `outbound_context_v1` 档案按精确 origin、所选知识和具体 grant/session 导出上下文；页面许可保持独立，异步返回前复核撤销与文档版本，失效会话不自动重试操作。提供设置/CLI 入口，default/interact 工具集合保持原有范围；会话拒绝与失效原因留审计，不记录会话句柄或 token。

## [0.6.6] — 2026-09-07

- **Qwen3-VL 坐标系修复（#423，多路对抗：grok 实证 / pi 官方考证 / claude spec + 复审收敛）**：评测门 0/10 全 MISS 的归因修复——L-QW-3「clamp-only」裁决的前提（模型输出绝对像素）被证伪：官方 cookbook + 本机 9 探针实证 Qwen3-VL **恒输出原图相对坐标 [0,1000]**（always-map mean err 11.9px vs 绝对像素假设 364px）。修复：`_normalize`/`normalizeQwenVlPoint` 恒映射 `v/1000·W·H` 后 clamp（clamp 降为 >1000/负值安全网）；解析层新增真 JSON 解码阶段，数组形态 `{"x":[x,y],"y":[y]}` 按裁决取 `(x[0], x[1])`（d9 反例钉死 y 冗余拷贝不可靠）。Python worker 与 TS（`gui-action-parse`/`qwen-vl-coords`）双端 lockstep，评测门 **0/10 → 6/10**；余 4 例 MISS 为 2B 模型感知误差（看错控件），非解析/坐标问题——#363 摘帽门（需 ≥0.85）仍未过，后续选项（few-shot prompt / bbox 输出 / 4B+ 变体）另议。决策留痕：`docs/decisions/ui-tars-absorption-multipath-2026-08-08.md` L-QW-3 修订注记。[#423](https://github.com/nehcuh/cmspark/issues/423)

## [0.6.5] — 2026-09-07

召唤器「五条需求」补齐波次（#433 P1/P2/P3 + #439，多 lane 并行 + 逐 PR 对抗复审）：召唤器从「命令面板壳」变成真正能读历史、控插件、跑后台任务的独立入口；AI 在任意对话里也能主动检索历史与知识。

- **召唤器接脱敏检索（#433 P1）**：命令面板数据层从本地标题匹配升级为真检索——输入即查（150ms 防抖 + 代际守卫防迟到回包盖新状态），结果带摘要 snippet；方向键选中线程 → 脱敏蒸馏预览；「引用进新任务」把该线程以摘要卡带进新对话（LLM 只见蒸馏，不见原文）。[#433](https://github.com/nehcuh/cmspark/issues/433)
- **召唤器控制面（#433 P2）**：`ui.command` 白名单推送帧五动词——打开侧栏 / 打开确认台 / 打开浏览器 / 面板新建对话 / 打开内嵌终端 tab（联动 #432）；档位从召唤器只可**降档**（收紧免确认），升档必须去面板确认台。[#433](https://github.com/nehcuh/cmspark/issues/433)
- **召唤器后台任务（#433 P3）**：命令面板新增「后台任务」动词——任务句 + user_gesture + 当前线程租约，三重闸全保留（plan 档拒、确认仍回确认台，overlay 零新确认 UI）；浏览器后台执行复用 loop/SITE_OP/CU 升级链零改动。[#433](https://github.com/nehcuh/cmspark/issues/433)
- **LLM 历史/知识检索工具（#439，70mj33 实证）**：catalog 新增 L1 只读 `search_threads` / `search_knowledge`——在召唤器或侧栏里问「我今天聊了什么」「有没有关于 X 的笔记」AI 真的能查了。复用脱敏检索内核（标题/摘要/tags，永不回消息原文），默认 5 条上限 10，plan 档可用；与 `thread_recall`（本线程旧轮次）分工写进 prompt。[#439](https://github.com/nehcuh/cmspark/issues/439)

## [0.6.4] — 2026-09-06

- **内嵌终端（#432，对标 Zed Terminal Threads）**：插件内真 PTY 终端——全页 tab 跑 xterm.js（canvas 渲染，MV3 安全），companion 用 @lydell/node-pty（prebuilt）托管真 shell；I/O 复用既有 WS（16KiB b64 帧 + write-ack 水位反压 + 25s keepalive）。权限面：默认关（设置「编程助手」里显式开）、每次开门 user_gesture + L2 确认（巡航/无人值守不豁免）、plan_readonly 线程拒开、同时最多 1 个会话、起始 cwd 约束、env 剥离 CMSPARK_*/密钥、审计不含击键流。P0 为裸 login shell；Mode C「内嵌 agent TUI」在 P1。[#432](https://github.com/nehcuh/cmspark/issues/432)
- **召唤器命令面板化 + UI 高级化（#433 P0+P1）**：召唤器从聊天框升级为 Raycast 式命令面板——三段式（动词 frecency / 历史·知识命中 / fallback「问 AI」），720 宽、行高 44、150/120ms 动效、NSTableView 虚拟化、CJK IME 修复、全屏 Space 可见。新增三条服务端脱敏检索（thread.search 只搜标题/摘要/标签不读正文、thread.peek 蒸馏预览 ≤2000 字、knowledge.search 复用派生索引），拼音首字母匹配。零新 L2 类；overlay 仍永不渲染确认；后台任务 arm 留 P3。[#433](https://github.com/nehcuh/cmspark/issues/433)

## [0.6.3] — 2026-09-06

- **内容风控 400 不再误杀对话（#430，4zi17x 实证）**：DeepSeek 等内容审核拒绝（`400 Content Exists Risk`）是确定性错误，原先被当瞬时故障——同一 payload 重发 5 次全部 <200ms 瞬挂，烧光熔断预算杀死对话。现在单列一类：首次命中隔离「最近的大型工具结果」（最可能触发源，内存 + 持久化历史同步替换，下次 run 不再重发）并重试一次；二次命中或无可隔离对象立即致命，给出中文可操作文案（新开对话/调整描述/换模型）。恢复全程不透英文 400 原文帧；`isContentRiskError` 钉 400 状态，5xx 网关含 content-filter 字样仍走原 recoverable 路径（零改动）。[#430](https://github.com/nehcuh/cmspark/issues/430)

## [0.6.2] — 2026-09-06

- **低语料知识图谱：AI 整理 lane（#427，用户实测 4 篇死面板）**：图谱画布闸与 #273 聚类闸解绑（`KNOWLEDGE_GRAPH_MIN_DOCS=1`）——2–19 篇不再只有「知识不足 20 篇」死文案：画布直接画节点 + TF 实线边（可能诚实散点）+ CTA「让 AI 整理现有 N 篇」。点击后一次批式 LLM（仅 title+tags+description，不进正文）出分组 + 命名/摘要 + 关联洞察（虚线 +「AI 关联」+ 可查 reason）；`organized` 信号区分「未整理」与「AI 判无结构」（后者散点 +「AI 未发现明确关联」，不再复发 CTA）。分组锁（「保留这版分组」）= 图谱着色 overlay，跨 20 篇切换 TF 着色后仍存活、不进聚类输入；防抖重建 carry-forward 不失效。指纹（id/title/description/tags）漂移只标 stale 不自动重跑；organize 失败走 ok 帧 + 中文错误条（不碰 #356 error 合同）。红线：`KNOWLEDGE_CLUSTER_MIN_DOCS` / `scoreRelatedKnowledge` / ≥20 TF 路径零改动；无自动 LLM 触发。[#427](https://github.com/nehcuh/cmspark/issues/427)
- **peek 拒执不吃熔断预算（#425，gbkq2q 实证）**：SITE_OP_BANNED / SITE_OP_ESCALATE（peek 拒执，工具未执行）不再递增同工具 recoverable 熔断计数——此前「1 次真实超时 + 2 次封禁提示」即误杀对话；origin 已升级时熔断解锁指引覆盖所有工具（不再限 osascript/host_computer）。第二道闸不变：L-3 路线引擎跨 run steer ×2 无视 → blocked。[#425](https://github.com/nehcuh/cmspark/issues/425)
- **全历史专家归纳打磨（#418）**：草稿恢复「AI 建议工具（不预勾）」展示（suggested_tools 透传）；候选池先按元数据截 cap 再读消息体（大库不再全量读）；扫描期间批次进度事件上屏（「全历史归纳中：批次 n/m」）；批内聚类/归并 prompt 经真实 LLM 三轮实证调优（超时 150s/240s、evidence 并集兜底、silent-zero 诚实 fallback）。[#418](https://github.com/nehcuh/cmspark/issues/418)

## [0.6.1] — 2026-09-06

0.6.0 发版当日的修复与能力波次（多 lane 并行开发 + 逐 PR 独立对抗复审）：**#404 测试污染事故闭环**（config 路径全 live 化）；**失败升级链修复**（#409，uokwyw 实证四断点）；**outbound MCP 三件**（Grok 兼容短名、双轨同名、interact 命名 profile）；**全历史专家抽取**（#411）。

### 事故修复：测试污染真实配置（#404 #405 #406 #412）

- **config.json 读写全 live 化（#404/#405）**：`settings-web-tokens.test.ts` 静态 import `settings-web` → `config.ts` 在 `before()` 设 `CMSPARK_DATA_DIR` 前冻结 `DATA_DIR` 为真实 home，测试夹具（sk-test/https://x/m/port 23491）覆写真实 `~/.cmspark-agent/config.json`，致 0.6.0 启动 model_probe 失败 + tray 硬编码 `WS_PORT=23401` 探测失败误报「已停止」。修复：9 处 config.json 路径 + initDataDir 内 3 处 + getLogDir 全部改走 live `getConfigDir()`。[#404](https://github.com/nehcuh/cmspark/issues/404)
- **残余冻结点清扫（#406/#412）**：`getPidFilePath()`、outbound-grants `GRANTS_PATH`、ws-auth secret/.paired、obsidian 三缓存路径全部 live 化；**tray 端口探测改读 `getConfig().port`**（`resolveWsPort()`，非法回退 23401），端口漂移时 `syncCompanionClientPort` 重定向两个持久 WS client——用户改端口后 tray 不再误报。残余：Tray.swift 显示串硬编码 :23401（需 Swift 重编译，另票）。[#406](https://github.com/nehcuh/cmspark/issues/406)

### 失败升级链（#409 #414）

- **uokwyw 四断点修复**：CDP 连败 origin 封禁后——(A) 未武装 CU 时升级文案不再撒谎说「MAY call host_computer」，改指 `loop_declare_blocked` + 解锁路径（linux 分支同步：CU 永不可用，`suggested_action` 恒 `declare_blocked`）；(B) `closeRouteRun` 只把**成功**的 host_computer/osascript 记为已换路，失败不再清 staleRuns——`r3-unarmed`「请打开坐标 CU」解锁合同能浮出；(C) `host_computer` zod schema 补 optional `trigger_reason`（对齐 catalog，第一次升级调用不再死于 `.strict()`）；(D) 熔断 chat.error 在 origin 已升级时附解锁指引（设置→坐标计算机使用 / 换任务）。loop 仍**永不**自动打开 coordinateEnabled。[#409](https://github.com/nehcuh/cmspark/issues/409)

### outbound MCP（#407 #408 #410 #419）

- **租手 stdio `tools/list` 短名（Grok `tool_count: 0`）**：Grok 把 MCP 工具写成 `server__tool` 且合格名只允许一个 `__`。旧 `mcp-outbound` 直接暴露 `cmspark__list_tabs`，Grok 再前缀成 `cmspark__cmspark__list_tabs` 后丢掉全部工具——`grok mcp doctor` 仍报 10 tools / healthy。`tools/list` 改为短名（`list_tabs`）；`CallTool` 短名与 `cmspark__*` 都收。HTTP invoke / 默认 profile 白名单不变，**不扩** outbound L1。
- **租手 HTTP invoke 与 stdio 双轨同名（#408）**：`companionInvokeOutbound` 入口套同一 `canonicalOutboundMcpName`，短名（`list_tabs`）与 `cmspark__*` 均可；短名 exfil 仍走 grant 门（`DISCLOSURE_NOT_GRANTED`）。非法格式 vs 真不在 profile 的 `PROFILE_FORBIDDEN` 文案分开；审计记 `tool`（canonical）+ `wire_name`（原始名）。**不扩**默认 outbound L1。[#408](https://github.com/nehcuh/cmspark/issues/408)
- **outbound `outbound_l1_interact` 命名 profile（#410，同层补全）**：默认 8 工具 + 2 meta **逐字节不变**；interact 档 = 默认 ∪ {scroll / get_element_info / press_key / select_option / hover / dblclick / fill_form / drag_and_drop / create_tab / get_page_html / analyze_image}，`outbound-grant issue --profile outbound_l1_interact` 显式索取。DOM/像素读（get_page_html / analyze_image）入 exfil 类，**复用** `allow_page_export` 门（不拆新旗）。HTTP 轨按钥匙 profile、stdio 轨按 caller live grant（同 exfil 双轨）；stdio `tools/list` 经认证 `/outbound-mcp/v1/profile` 按钥匙裁剪（fetch 失败降级默认集）。**豁免旗不溅射（收紧）**：auto_approve_dangerous / god-mode / auto_approved_domains 对 outbound 一律无效——auto-approved 域仍确认台、非 http(s) 仍硬拦；outbound 只认 grant per-key 旗 + 操作者 HITL。[#410](https://github.com/nehcuh/cmspark/issues/410)
- **interact 残余三项（#419）**：(1) stdio profile **懒重拉**——companion 晚于 mcp-outbound 启动时不再终身降级默认集：tools/list / CallTool 在降级态且距上次 fetch ≥30s 时重试（有界 ≤5 次），成功即升级广告集与本地门，失败仍默认集不拓宽；(2) 扩展设置页签发 grant 加 **profile 下拉**（outbound_l1_default / outbound_l1_interact，走既有 issue 通道 profile 字段）；(3) HTTP 形状预检 **allowlist 感知**（#413 复审 P2-1）——预检不再拒「任一已知 profile 上已授权」的工具（未来 camelCase 成员不会被 HTTP 轨误拒而 stdio 放行），非法格式 vs off-profile 的文案分层保留，HTTP/stdio 双轨对同一 wire name 同 allow/deny 判定。默认档语义与内容均不变。[#419](https://github.com/nehcuh/cmspark/issues/419)

### 专家模式（#411 #416）

- **全历史专家抽取（方案 A 两级聚类）**：专家段新增「📚 从全部历史归纳专家」——一次性确认弹窗（写明 N 条摘要发所配 LLM + 时间窗/关键词预排除，count_only 零 LLM）→ 候选池（沿用 #370 skip 规则，cap 200）→ 浅层画像（fresh digest 优先，否则首末 user preview，全 redact，不读全量正文进 LLM）→ 25/批出候选角色（companion 硬校验 ≥2 有效线程、伪造 id 丢弃）→ 按需深读 ≤20 条（既有 8k cap + 脱敏）→ 跨批归并 + 与已装专家去重（名字精确或工具面 Jaccard≥0.8 → conflicts_with「覆盖/另存」用户裁决）→ K≤5 份草稿进内存 pendingDrafts（不落盘、不自动保存、重启即丢），草稿队列「上一份/下一份」逐份进同一编辑器手动保存。无定时器、无后台扫描（watermark 增量另票）。LLM 调用数 = 批次数+1 归并，与线程数解耦。[#411](https://github.com/nehcuh/cmspark/issues/411)

## [0.6.0] — 2026-09-06

0.5.9 之后的大波次：**消费者级侧栏 UI 重构**（#321 系列——状态带合并、消息行降噪、空态/作曲同脸、Cockpit 抢焦点收敛）；**自主性三件套**成链——Composer 巡航档位选择器（#325）、plan_readonly 计划模式（#327）、L-1/L-3/L-5 无人值守 loop（#386–#391，默认仍 off）；**专家团队 v1**（#366–#371：`kind=expert`、七个预置角色、一张 L2 卡组队）；**CU 完整性链**（#359–#362：Qwen3-VL sha256 钉死 + held-out 评测门）；**跨平台诚实化**（darwin host follow-ups、CDP 失败升级建议、grant 审计）。L2/ACL 边界零扩张，execution_contract 仍 shadow（#328）。

### 自主性：巡航档位 / 计划模式 / loop（#325 #327 #386–#391）

- **L-1 完成谓词 + stall-classifier（#387，史诗 #386 首票，T1 零自动执行）**：`companion/src/loop/` 纯函数信号库——双层完成谓词（全 evidence-tick ∧ 收口轮无 tool_calls ∧ 无未决 confirm/nonce；claim⊆tick 交叉核验，被拒 steer 直指未勾项；四态 verdict：complete / claim-rejected / request-claim / incomplete）；受阻五分类（needs-human-confirm / needs-credential / external-wall / route-exhausted / model-noncompliance）+ 机器可读解锁契约（试过路线/败因/解锁条件，每类有完成通道）；progress ledger 连续 K=3 个 run Δ=0 → stalled 信号（干预归 #389）；stall 卡数据结构（渲染归 #390）。`complete` 仅机检信号，L-4 映射为 DONE 报告待用户终审，永不当「任务已完成」文案；click success tick ≠ 表单过关（残余风险，默认档用户终审兜底）。不改 run_progress 勾选语义；execution_contract 保持 shadow（#328）；不挂 adapter、不触发续跑（#388）。[#387](https://github.com/nehcuh/cmspark/issues/387)
- **L-3 换路引擎（#389）**：route-directive steer（originFails≥4 后连续 2 run 无替代路线且无 tick → 注入定向指令）+ `loop_declare_blocked` 受阻申报；steer 两次无视 → 项 `model-noncompliance` blocked。策略链 R1 CDP-DOM → R2 CDP 备选 → R3 host_computer → R4 osascript → R5 human；**R3 资格 = escalation ∧ `computer.coordinateEnabled`**，未武装则 blocked + 解锁契约（loop **永不**打开 CU）。换路预算：每项 cross-class ≤2、steer ≤2、总 steer ≤ runs/2。blocked 聚合为 IMPOSSIBLE 报告；匹配解锁动作后 checkpoint 恢复。只关门/指令/申报，不强制调工具；evaluate / spawn_worker / 开模块不进链；每跨类仍走既有 L2。复用 #357 originFails，不改计数器。[#389](https://github.com/nehcuh/cmspark/issues/389)
- **L-5 无人值守 loop + #326 叠加（#391，T2，loop 收官）**：值守 loop 下 NEVER 清单确认 45s 超时 deny → **该项 blocked**、其他项继续、终态出钥匙清单（**45s fail-closed 不改、不 auto-allow**）。focus lease 与 `llm-loop-gate` 分层：同一时刻仅一个 loop/worker 持有 CU 驱动权，后来者排队（`CU_FOCUS_LEASE_QUEUED`）；`COMPUTER_TASK_BUSY` 执行互斥零改。blocked 报告 tray 徽标 + Board intent 呈面，`steal_focus:false`（cockpit `loop_blocked` → stay_background）。值守终态文案 **「计划完成待复核」** + evidence digest 进 `capability-audit.jsonl`（无 claim / 无正文）。grant TTL 到期 → `paused`（可显式 re-arm 恢复，loop **不延长** grant TTL）。deny-storm ≥3 次 loop 主动 pause。用户回场触碰输入走既有 re-L2，loop 不死。值守默认仍 off。[#391](https://github.com/nehcuh/cmspark/issues/391)
- **L-5 round-2（#402 对抗 MAJOR）**：drain 门 TTL-pause 不再 `takeNextRun` 吞用户消息（只 drop loop source）；`CU_FOCUS_LEASE_QUEUED` 映射 `classifyError` recoverable，排队不再 `security_halt`；worker CU waiter 用 `source=user`，drain 不再饿死。[#391](https://github.com/nehcuh/cmspark/issues/391)
- **本线程 plan_readonly 计划模式**：`execution_policy: default | plan_readonly` 线程级执行帽，只收紧不放宽。pregate 硬拒绝白名单外一切工具（deny-by-default；MCP 全拒**无例外**——`mcp_list_resources` 曾以「只读本地缓存」放行，冷缓存实际 fall through 到 server RPC，例外已撤；`analyze_image` 因 IMAGE_FETCH 出网 phase 被拒——读像素走 `screenshot`）。与 run_progress_propose 正交，propose 不是豁免。写入只认新 WS 消息 `thread.execution_policy.set`（`user_gesture:true`；工人线程拒绝；spawn 仅在父 plan 时盖章，无章工人 gate 侧实时跟随父当前策略——中途 arm 罩住已 spawn 工人；召唤器 ACL 拒），落 `capability-audit.jsonl`。UI 另票。[#327](https://github.com/nehcuh/cmspark/issues/327)
- **Composer 巡航档位选择器**：发送键旁芯片，四槽每次确认/网页巡航/全自动巡航/全自动+协议（无值守）。显示值现场 `deriveAutopilotTier`，升档复用设置武装 sheet（短语+后果矩阵），降档一键 `disarmAllFlags`；arm/disarm 写入 `capability-audit.jsonl`。无新 config enum / TTL。[#325](https://github.com/nehcuh/cmspark/issues/325)
- **召唤器巡航档位只读镜像**：hydrate 下推派生 chip 文案（Swift/HTML 不解三 bool）；点击走既有「打开侧栏/确认台」深链。ACL / 确认方言 / #230 不动。[#324](https://github.com/nehcuh/cmspark/issues/324)

### 专家团队（#366–#371 #395）

- **Pack `kind: mission|expert` 字段（#367，I1）**：`pack.yaml` 新增可选 `kind`（缺省 mission，旧包兼容；validator 收录——未知 kind 值校验失败不静默丢）。**expert 为可调度的角色视图，仍非 runtime**：kind 只影响列表过滤/匹配/文案，apply/spawn 引擎对两种 kind 走同一装配路径。`pack.list` / `pack.get` 返回 kind；四个 builtin 包显式标 `kind: mission`（安装保持 force refresh）；ADR-014 加修订段、ADR-020 组合面表加 Expert view 行。禁项：pack.yaml 无 model 字段、无新顶层数据目录、Trust B 边界与 skill `sub_agent` 均未动。[#367](https://github.com/nehcuh/cmspark/issues/367)
- **七个 builtin 预置专家 Pack（#368，I2）**：`expert-product-manager`（产品经理）/ `expert-sre` / `expert-project-manager`（项目经理）/ `expert-ops`（运维）/ `expert-architect`（架构师）/ `expert-developer`（开发）/ `expert-qa` 七个 `kind: expert` 的 community builtin Pack——用户可在场景/专家列表直接组队或派活，persona 差异化（PM 用户价值 / SRE 事故与 SLO / 项目经理计划与风险 / 运维变更与回滚 / 架构师结构与权衡 / 开发实现与质量 / QA 验证与边界）。工具面全部 allowlist：只读基线 `list_tabs/get_page_text/screenshot/use_skill`，开发/QA 另加页面点按（navigate/click/scroll，无 evaluate），全员 deny shell/host_*/netsec/evaluate/spawn_worker/acp_*；`author: cmspark`（builtin 只读）；无 trust、无企业模块。预置角色 = 浏览器侧顾问，persona ≠ 权限，需主机操作走主对话 + 企业模块。[#368](https://github.com/nehcuh/cmspark/issues/368)
- **专家组队 v1 核心（#371，I5）**：`propose_expert_team`（只读匹配：任务简述 → ≤4 个已安装 `kind=expert` id + rationale；发明/停用 id 被滤）+ `spawn_expert_team` **一张** L2 确认卡（队员、HARD_DENY 后有效工具面、完整可见可编辑任务切片、将升 orchestrator / 开 Board；token 绑定 pack id 集合 + 切片指纹）。批准后循环既有 `spawnWorkerThread` + `applyPack(allowTrust:false)` + `tool_allow=pack.tools.allow`，每 worker 写入 brief 并 fire-and-forget `chat.create`（无 brief / 无 kick = 失败）。任一步失败删已建 worker 并 `restoreParentAfterFailedSpawn`（#292）。parent `board_mode=true`；>4 截断、总 worker ≤5。巡航跳过与 `spawn_worker` 完全一致，无新 waiver。NEVER：auto-spawn、N 次串行 L2 冒充组队、worker 互聊、突破 5、LLM 写 `base_url`。[#371](https://github.com/nehcuh/cmspark/issues/371)
- **#371 round-2：组队 kick 走 `tryAcquireMultiAgentLlmLoop`（Pi MAJOR）**：`spawn_expert_team` 不再裸调 `adapter.chatCreate` 绕过 `max_concurrent_multi_agent_llm_loops=5`。满员时 kick **入队**（brief 已落盘，worker 待命），slot 释放后 FIFO drain；第 6 个 kick 不回滚组队、不超跑。N-2：`tools.mode=unchanged` 不再把 `roleAllow=[]` 打成空白名单（与 spawn_worker 的 null→安全默认一致）。N-3：已满 5 worker 时 L2 预拒 `MAX_WORKERS`，不再弹 0 成员空卡。N-1 applyPack parent∩ / N-4 异步 LLM 失败不回滚 sibling / propose 审计 / catalog 描述：不改（pre-existing 或已声明 residual）。[#371](https://github.com/nehcuh/cmspark/issues/371) / [#395](https://github.com/nehcuh/cmspark/pull/395)

### CU 完整性链与本机模型（#359–#363）

- **Qwen3-VL 发版钉死 sha256（#359 / CU-A）**：`companion/assets/qwen-vl.manifest.json` 随 release 钉入 2b/4b/8b 每文件 name/size/sha256（权重取 HuggingFace tree `lfs.oid`；sidecar 取 huggingface.co/resolve/main 实测）。`probeQwenModelDir` 改为 config.json 存在 **且** 清单全量 size+流式 sha256（含全部 safetensors，无 stat-only 捷径）。缺文件 `model-file-missing`、哈希错 `sha256-mismatch` 拒 admission / worker load（load 前再验 TOCTOU）；失败时 `modelEnabled` 强制 false。HF / hf-mirror / ModelScope 只换 origin。2B ~4.26GB 哈希在设置/准入/load，不按点击重算。[#359](https://github.com/nehcuh/cmspark/issues/359)
- **本机定位 held-out 评测门（#362 / CU-D）**：`companion/scripts/cu-locate-eval.mjs` + `companion/tests/fixtures/cu-locate-eval/` 入仓（10 例合成 PNG：中文桌面 5 + OSR 5，确定性生成、`--check` 逐字节校验；与 #361 红队集样本不重叠，红队样本不进准确率）。候选：**文本层-缺陷对照器**（非测得 OCR——用 corpus 权威文本层 + 确定性删词档模拟 OCR 漏词，措辞如实降格，删词档属门定义）对照 Qwen3-VL-2B BF16 与 int4（int4 无官方可钉 sha256 源则记「无合规源」跳过，不用社区包；验证于 2026-09-06）。过门三条件：优于对照器（≥0.15，有效门槛 qwen ≥0.85 ≈ 9/10）且绝对下限 ≥0.7 且 desktop 地板 ≥0.65（全语料皆中文——该条件实为桌面 vs OSR 子集地板，非中文分隔）；golden 不进提示；过门 ≠ 摘 experimental（#363）。无 GPU 时模型跑分诚实标「待有模型机器执行」+ 命令，不编造数字。[#362](https://github.com/nehcuh/cmspark/issues/362)

### 侧栏 UI 重构与观感（#321 #323 #326 #342 #396）

- **一条 Now（状态带合并）**：SceneStatusBar / RunBusyChip / WorkerScopeBar 并入 FocusBand 槽位体系（worker_scope > run_busy > L1 > scene，场景可作次行搭车）；对话上方只剩 rail + FocusBand，≤80px 不变；`buildScopedRunBusyInput` 五处推导收敛为单 hook（`use-scoped-run-busy`）；弹出对话框按钮并入 rail。旧 data-testid 挂新节点。[#321](https://github.com/nehcuh/cmspark/issues/321)
- **消息行降噪（#321 PR-6）**：消息动作条（复制/编辑/分支/导出/</>接力）改 hover/focus-within 门控——隐藏态用 opacity+pointer-events（非 display:none），按钮留在 Tab 序、键盘聚焦即显整条；最后一条消息常驻。触屏/coarse pointer 每条消息保留一颗 ⋯（aria-expanded，展开同一动作组——硬验收）。四种紧凑横幅（shrink/unknown/prompt/compacted）与 ToolCallCard 内嵌指路/userHint 统一 `NoticeCard` primitive（warning token 家族；无折叠态）。ToolCallCard 纯视觉收口（radius/mono 栈进 token），cascade 逻辑零改动。红线：失败/安全披露（错误工具卡、warning userHint、SEC-C 桩提示）永不默认折叠；RunProgress 折叠语义不动。[#321](https://github.com/nehcuh/cmspark/issues/321)
- **空态与作曲同一张脸（#321 PR-4）**：CompanionMark 空态 92→48（仍是 #323 红色小牛）；招呼 22px；三条建议回到首屏折叠线以上；作曲胶囊 minHeight 72→52；用户气泡去满铺 indigo（canon 修订：浅底+细边为交付方案，左细 indigo 条为备选截图）；未武装发送 `sendDisabledBg`，武装才 indigo；L0 装配芯片降为弱样式（不删）。[#321](https://github.com/nehcuh/cmspark/issues/321)
- **Cockpit 抢焦点收敛**：非 nonce 轻量确认不再自动抢桌面焦点（侧栏 MinimalConfirm + macOS 托盘承担）；nonce/重预览级确认与 CU paused 仍自动开并聚焦；巡航/值守武装下 CU started 不再抢焦点。确认条数不变（forceConfirm 代数零 diff）。[#326](https://github.com/nehcuh/cmspark/issues/326)
- **MeetingPanel 双「收起」去重（#342）**：面板内按钮改名「结束并收起」（title/aria 同步）——它与 Host header 的「收起」语义不同（前者结束录制+收起，后者纯收起面板），不再同屏同文案。[#342](https://github.com/nehcuh/cmspark/issues/342)
- **settings-web 去 Material 硬编码，token 化（#396a）**：tray「设置」页内联 CSS 从 Material 暗色板（蓝/绿/红/黄/深蓝卡蓝输入蓝）改为 **CSS 变量单一来源**——`:root` 手工镜像 Side Panel tokens.ts dark 家族（bg/elevated/border/text/muted/accent/success/danger/warning + field-bg），同 SummonerTokens / summoner-web :root 的镜像模式并注单一映射来源。语义色全走 var：主色→darkAccent(indigo-400)、成功→darkSuccess、危险→darkDanger、警告→darkWarning；**字阶对齐侧栏 11/12/13/15 家族**（消灭 14px 中间档：输入/按钮/range 14→13，区块标题 14→15；页标题 20 保留）。hover/focus 对齐侧栏观感（focus 用 accent 边框）。**Material hex 源码零残留**（含注释）；渲染页 GET / 无 Material 值（服务端集成测试钉）。零行为改动——设置项逻辑/保存/CSRF/SSRF 面不动。[#396](https://github.com/nehcuh/cmspark/issues/396)

### 会议、平台韧性与审计（#69 #244 #347 #357）

- **浮窗会议台（#244）**：隐私「我已了解」后盖住 Capture 卡，实时转写滚动进会议台（不进草稿框）；结束 / 生成纪要 / 返回对话。`generate_minutes` 失败不写「已生成」。打开侧栏跳过 `--app` 浮窗，落普通 Chrome 窗口。**ACL 增量：零**——`append_transcript` / `generate_minutes` / list / get 等上涨发生在 [#246](https://github.com/nehcuh/cmspark/issues/246)，本票复用。本票收紧：overlay 剥 `auto_diarize`（#244 NEVER：仍扩展-only；浮窗撤「自动标说话人」）。`import_text` 仍扩展-only；overlay never Allow/Deny。[#244](https://github.com/nehcuh/cmspark/issues/244)
- **CDP 死磕升级建议（#357）**：同一 `(thread, origin)` 上 CDP 交互失败累计 ≥4 次（跨 locator / 工具名）后，后续 CDP 调用被 site-op-memory peek 拒执，`suggested_action=escalate_to_host_computer`，错误文本建议 `host_computer`（Chrome token，**仍走 L2 确认**）或 macOS `osascript_eval`。evaluate `success:true` 且 `result:null` 视为假成功（不重置失败计数、不消耗 DOM-script budget）。不改 `classifyError`，不自动跳过 CU 确认。Round-2：`origin:unknown`/非 http(s) 不计不拦；`justBanned` 只表示 locator 2 败；共享读面 `getOriginFailCount`（#358 rebase 对齐 `originFails`）；escalate 文案含 `list_tabs` 逃生门。[#357](https://github.com/nehcuh/cmspark/issues/357)
- **host_read max_chars 真透传（#69 Phase 2，审计 M8 完整修复）**：read-mail / list-mail 预编译 .scpt 转 handler 形态，cmspark-host 经 'ascr'/'psbr' 子程序 Apple Event（kASSubroutineEvent）把 `--max-chars`（1-5000，匹配 zod）/ `--limit`（1-500）传入 readMail/listMail handler——脚本侧硬编码 500/100 移除（max_chars>500 不再被 500 硬截）。非法 argv typed exit 7（不静默 clamp）；TS 层 slice 保留为纵深；list-notes/list-files 不变（仍固定 top-100）。[#69](https://github.com/nehcuh/cmspark/issues/69)
- **list-files CJK TargetId 有损（#69 F3）**：producer 不再用 `cid mod 256` percent-encode（U+4E00「一」与 U+4F00「伀」曾撞成 `%00`）；改为输出原始 UTF-8 文件名，由既有 M2 `encodeRawTargetId` base64url 在 list 边界编码。选这条而不是在 AppleScript 里重写 UTF-8 percent-encoding：少一层易错逻辑，notes/mail producer 已是 raw。M2 codec 行为不回退。Finder `readOne` 仍是 M1 NotImplemented（Mail-only）——回读是 decode 文件名后读 `~/Documents`。[#69](https://github.com/nehcuh/cmspark/issues/69)
- **值守 grant arm/disarm 入 capability-audit（#347）**：`security.unattended.armed` / `.disarmed` / `.expired` 三事件补全审计面板可见性——config.set 双向已记（#334），grant 路径（ADR-021 进程内存值守）此前只有 logger。armed/disarm 带来源 surface（panel/tray/summoner 归一，stampedSurface 派生），expired 记 `cruise_restored`；字段按构造 redact（无短语/token/命令文本）。bare disarm（无活跃 grant）不伪造审计行；审计写失败永不 gate 生命周期。不改 grant 语义 / TTL / 确认代数。[#347](https://github.com/nehcuh/cmspark/issues/347)

### Known residuals

- **#328 execution contract 仍 shadow 观测期**：L-1 完成谓词（#387）未消费 contract，shadow → enforce 的升级待观测数据；升级前 loop `complete` verdict 只当机检信号，L-4 出 DONE 报告待用户终审。
- **#363 待真实模型跑分**：#362 评测门与对照器已入仓，Qwen3-VL 实机跑分需有模型的机器执行（命令随 #362 入仓）；过门 ≠ 摘 experimental。
- **#372 / #373 / #364 deferred**：专家团队与 CU 链 follow-ups，本切点未含。
- **Linux 桌面层缺口**：见 README「Linux 功能缺口总表」（系统语音引擎 / host_computer / 召唤器原生 overlay 与全局热键 / 生物识别门）。
- **ADR 待补**：无人值守 loop（史诗 #386，L-1–L-5）与专家团队（史诗 #366，I1–I5）本切点尚无独立 ADR，决策记录散落于各 issue/PR；补 ADR 前以本 CHANGELOG 及 ADR-014/020/021 修订段为准。
- T1 已记分；[#228](https://github.com/nehcuh/cmspark/issues/228) 已关。**仍禁止**扩默认 outbound profile。

## [0.5.9] — 2026-09-04

0.5.8 工厂切点（512k / listen-first / zip node-first）之后的知识库波次：AI 草稿、检索/分布/开闸、多级文件夹、sha256 去重、PDF 导入修复；Windows launcher 后续。`[0.5.8]` 仍是 9-02 切点，不改历史。

### Added

- **知识 AI 草稿预填**：单篇导入两阶段 preview——先启发式草稿（含源文件 frontmatter tags），再 LLM 建议 description/tags（只填用户没改过的字段）。目录导入 / 库扫描零 LLM。[#272](https://github.com/nehcuh/cmspark/issues/272)
- **知识检索打分（Wave A）**：query-aware TF-IDF + top-k + 8000 字跨文档预算；智能匹配默认开，关掉走站点∪勾选。无 embedding / 图谱。[#273](https://github.com/nehcuh/cmspark/issues/273)
- **分布视图 + 可选簇路由（Wave B）**：自动分组 chips（「自动分组，不准就移到文件夹。」）；「按堆选文」默认关。[#273](https://github.com/nehcuh/cmspark/issues/273)
- **认证簇路由分支开闸**：eval 双列通过后工厂常量打开；用户开关仍默认关——开闸 ≠ 替用户打开。[#280](https://github.com/nehcuh/cmspark/issues/280)
- **多级文件夹**：最多 3 层，磁盘目录为 SoT（Obsidian 可读）；`knowledge.move` 保 pin。[#274](https://github.com/nehcuh/cmspark/issues/274)
- **完全重复导入**：正文 sha256（不是 MD5）；预览标 `duplicate_of`，目录导入跳过重复。[#281](https://github.com/nehcuh/cmspark/issues/281)
- **内置技能 `cmspark-macos-app-replace`**：DMG 换装 playbook（禁 `xattr -cr` / `pgrep -f` 坑）。

### Fixed

- **darwin host jsonEscape 覆盖全部 C0（#69 F1）**：`host.swift` runReadMessage 与 `read-mail.applescript` 的 jsonEscape handler 除补 `\b`（char id 8）/ `\f`（char id 12）分支外，新增逐字符白名单 pass——其余 C0（0x00-0x07 如 BEL、0x0B、0x0E-0x1F）统一 `\u00XX` 编码。此前含此类 C0 控制字符的邮件产生非法 JSON（TS `parseJsonSafe` fail-closed 致该邮件不可读）；现全 C0（0x00-0x1F）+ `"` `\\` 均可 JSON.parse 往返。两处 handler 保持逐字节等价（源码级 lockstep 测试钉死）。另修 host.swift 嵌入层 M3 潜伏转义 bug：换 `\"` 步骤 Swift 源层缺引号转义（会导致含引号邮件的 jsonEscape AppleScript 编译失败）——Swift 剥层后与 read-mail 逐行等价 + osascript 实跑对拍 IDENTICAL。
- **darwin host-bin resolver 路径数学（#69 F2）**：候选列表删除永不命中的 `dist/dist` 死路径（`../../dist`），dev-mode fallback 由 `__dirname/../../dist` 改为 `../../../dist`——host-bin.ts 恒在 companion root 下 3 层，该路径在编译与 dev-src 两态都正确解析到 `companion/dist/cmspark-host`。真实目录结构测试断言无死路径、dist 可达。
- **PDF 导入**：整文件 `readAsDataURL` 编码（与对话框附件同路），修 chunked `btoa` 导致 >32KiB PDF 损坏。[#282](https://github.com/nehcuh/cmspark/issues/282)
- **Windows launcher**：VBS 递归建 `logs` 目录（干净配置不再卡错误对话框）；`launch.bat` SEA echo 括号转义；无 bundled node 时探测系统 node 并给出诚实报错；CI `windows-latest` launcher smoke（S1–S9）。[#279](https://github.com/nehcuh/cmspark/issues/279)
- **知识预览失败可见**：解析失败不再永远「正在解析…」；可「跳过解析，手动填写」。（#270 / #271）
- **shrink 横幅三态**：旧 companion 省略 `shrunk` 时走 unknown 分支，不再谎称「仅提示/未压缩」。
- **LLM `complete()` recap**：对齐 `streamChat` 预算；overflow 半窗重试一次，避免原样重发。
- **依赖**：`npm audit fix` 清掉 fast-uri high advisory（CI 门禁恢复绿）。

### Known residuals

- T1 已记分；[#228](https://github.com/nehcuh/cmspark/issues/228) 已关。**仍禁止**扩默认 outbound profile。

## [0.5.8] — 2026-09-02

工厂默认 `context_window` 512000；过小磁盘运行时按 128000 且不写盘；官方 zip node-first；Companion listen 不再等 MCP start。[#268](https://github.com/nehcuh/cmspark/issues/268)

### Changed

- **`context_window` 工厂默认 512000**：新装 Agent 工作预算，不是供应商窗口承诺。磁盘过小（`< 16000` / 非正）本轮按 **128000** 做预算，**不写** `config.json`。shrink 不再切出半截 JSON（`{"succes…`）。设置页 Save 在 companion `config.updated` 水合前禁用。shrink-only 横幅不再谎称「仅提示未压缩」。512k 默认**不是**对已有 4000 磁盘文件的修复。
- **F1 文案诚实**：活切点不再保证聊天列总有「本轮步骤」清单——页面工具前必须 propose；成功后才挂卡；模型放弃 / 纯问答则无卡。
- **F2 官方 zip 启动器**：`launch.bat` / `launch-hidden.vbs` 优先 `node.exe`+`cmspark-agent.js`，leftover SEA `cmspark-agent.exe` 垫底。
- **F3 listen-first**：23401 不再等 MCP start；本轮未提供的 `mcp__*` 拒执行（`tool_not_offered`）。

### Known residuals

- `createToolExecutor` 未串 offered-catalog（LLM 路径已由 adapter 包一层）；tray settings-web 无三档过小窗口文案；Windows `0o600` 测试在 NTFS 上失败（预置）。

## [0.5.7] — 2026-09-01

当轮活计划：侧栏本则消息里页面工具前必须 `run_progress_propose`；shell allowlist W1e fail-closed；`run_progress` sticky-clear。文档活切点与包装 lockstep。

### Added

- **当轮活计划**：页面工具前必须 `run_progress_propose`；成功后才挂「本轮步骤」卡（不必等 H1）。模型放弃 / 纯问答则无卡。[#265](https://github.com/nehcuh/cmspark/issues/265) / [#266](https://github.com/nehcuh/cmspark/pull/266)

### Security

- **shell allowlist W1e（quote/join fail-closed）**：0.5.4 闭合的是执行旗标 *变体*（pwsh 前缀、`/c`、`=`、`.exe`、node `-p` 等），不是「判定 tokenizer ≠ `spawn({shell:true})` 引号语法」。本次：POSIX 相邻引号拼接（`"-"c` → `-c`）；旗标比对前去掉空引号并认 unquoted `\`；`tokenizeSimpleArgv` 失败改为 deny（删除空白 fallback 放行）。`policy=allowlist` + 裸解释器条目下，`bash '-c' … '*'`、`bash -""c`、`bash "-"c … X=1` 不再匹配。默认 `confirm_per_command` + L2 不变（非社区默认 RCE）。含 `*`/`?` 的 allowlist 命令（即便在引号内）改为 matcher deny；词中未闭合撇号（`echo don't`）同样 tokenize-null deny——需要 glob/query/撇号字面量的操作者用 `confirm_per_command`。

### Fixed

- **`run_progress` adapter 三态**：显式 `null`（sticky clear）不再被 tool_result 成功路径 `!th.run_progress` 当成未播种而重新 seed。抽出 `nextRunProgressAfterToolSuccess`；toggle 对 `null` 不再 `?? { items: [] }` 写成空对象。无生产写入方（潜伏契约）。
- **语音回退横幅 CTA**：本机模型未就绪改用浏览器听写时，横幅带「去设置」（`local_fallback`，不复用 fail-closed 的 `model_missing`）；听写结束后仍保留直到关掉或下次开始。
- **Whisper 下载失败**：`get_state` 带回 `lastDownloadError`；打开设置不再先清空错误位；文案指向模型下载源（hf-mirror）。
- **会议自动 K**：`meeting.diarized` 回显 `K=N`，下拉同步 2–4。

### Known residuals

- 位置参数 `bash evil.sh` / GTFOBins；`$VAR` + 残留 `shell:true`；win32 `cmd.exe` 引号语法；cwd 依赖的 `bash -[c]` pathname glob；macOS bashism `-{c,}`。

## [0.5.6] — 2026-08-31

召唤器 HTML 流式出字、本机 Whisper 自动激活 / 可见回退 / HF 镜像、会议说话人「自动」档。文档活切点与包装 lockstep。

### Added

- **召唤器 HTML 卡流式出字**：Windows HTML shell 跟 `chat.token` 累积快照逐 token 渲染（此前只在 assistant 轮末整表 refetch）。Swift overlay 本已流式，未改。
- **本机 Whisper 下载完成自动激活** `localModelId`（不改 `sttEngine`）；`get_state` 自动修正失效的 active 模型。
- **本机模型不可用时当次会话回退浏览器听写**：`voice.autoFallbackToBrowser`（默认 true）显示可见横幅（含云残留），非静默、不改配置。ADR-023 L13 2026-08-31 修订为禁止**静默**回落。
- **模型下载源镜像**：`voice.modelDownloadEndpoint` / `CMSPARK_HF_ENDPOINT`（仅重写 huggingface.co 主机，https fail-closed；sha256/size pin 不变）。
- **会议说话人人数「自动」档**：silhouette 选 K（`meanSilhouette` / `selectBestK`）；UI 默认「自动」。仍是 3 维特征近似，experimental。

### Documented

- **补记**：`cmspark-agent outbound-grant` 对未知 flag 失败且不签发（[#235](https://github.com/nehcuh/cmspark/issues/235)）。0.5.3 Honesty 段仍描述当时切点，不改历史。

### Known residuals

- 语音 UX Hex 式 [#258](https://github.com/nehcuh/cmspark/issues/258) · Windows SAPI 兜底 [#259](https://github.com/nehcuh/cmspark/issues/259) · speaker embedding diarize [#260](https://github.com/nehcuh/cmspark/issues/260)。
- [#230](https://github.com/nehcuh/cmspark/issues/230) 仍冻 F-S-10 / overlay-acl；grant-cli 未知 flag 与 H1 `{text,tool}` 精确勾已不在该冻清单。
- T1 已记分（CMspark 臂 Y / Playwright `ERR_EMPTY_RESPONSE`）；[#228](https://github.com/nehcuh/cmspark/issues/228) 已关。**仍禁止**扩默认 outbound profile。

## [0.5.5] — 2026-08-29

侧栏对落盘脱敏桩的友好渲染（SEC-C 脱敏的 UX 补缺；两路对抗评审 + grok 复核 SHIPPABLE）。

### Fixed

- **重载对话后工具结果不再显示原始桩 JSON**：敏感工具（evaluate/shell/host_*/workspace_*/部分 MCP）落盘脱敏桩（`{redacted:true,len,sha256}`）改渲染友好提示——「出于安全未持久化：原始长度 · sha256。实时轮次中内容对模型与界面可见（超长会截断），重新加载后不再保留」；失败桩追加「该调用当时已失败」。
- 同步门控三个会露出占位符的分支：shell 命令条（`<redacted:hash=…>`）、host_computer 空任务卡（「?/? 步」）、tool 消息气泡正文（桩 JSON markdown）。
- 判定下沉为纯函数（`redacted-stub-utils.ts`：`extractRedactedStub` / `isRedactedStubContent`），13 用例钉住 A/B 形状、失败桩、len 边界、误伤面。
- 版本字面量补齐 lockstep：index.ts 横幅 / ACP clientInfo / outbound serverInfo 三处硬编码版本（0.5.3 bump 时的历史遗漏）纳入 `version-lockstep` 测试。

### Known residuals（下轮，grok 复核记录）

- 复制 / `</>` 编程接力仍输出桩 JSON；generic/MCP 深键嵌套叶桩仍在 JSON 预览中原样显示；plainError（INTERRUPTED）shell 行的命令条占位符未门控；脱敏范围讨论见 [#255](https://github.com/nehcuh/cmspark/issues/255)。

## [0.5.4] — 2026-08-29

四路独立对抗评审 + grok 多路验证驱动的修复批次（spec/plan：`docs/superpowers/specs|plans/2026-08-29-post-review-adversarial-fixes.md`）。全部为已有行为 bugfix，无新需求。

### Security

- **shell allowlist 回归闭环**：裸 shell 家族条目（`sh/bash/zsh/pwsh/powershell/deno/bun/cmd`）的执行旗标恢复拒绝——`-c`/`-Command`/`-EncodedCommand`/`eval`/`-p`/`--print`/`-r` 等，含 PowerShell 唯一前缀（`-com`/`-enc`）、斜杠形式（`/c`）、`=` 粘连、`.exe` 基名归一、大小写变体；tokenized 与 fallback 统一复用同一判定函数。`grep -c`、`bash -e/-eu`（errexit）、`ruby -r` 等合法形态不误伤。位置参数与 GTFOBins 类在代码注释声明为设计边界（旗标 deny 是纵深，L2 确认才是门）。
- **外泄授权 per-key**：HTTP 轨按认证 grant 自身 `allow_page_export` 判定，同 caller 的 sibling 带旗钥匙不再放行无旗 token（`grantAllowsPageExportById`）；stdio 轨保持 caller 级并注释文档化双轨。与 grant-cli「这把钥匙」承诺及 TROUBLESHOOTING 对齐。
- **打开侧栏结果帧**：仅 panel/extension 来源可裁决（origin 绑定），settle 单漏斗先到先赢。
- **外发 HITL 断连**：操作员批准时调用方已断连则不再执行工具，审计记 `CALLER_DISCONNECTED`（与已执行明确区分）。

### Fixed

- **「打开侧栏」假成功**：`sidePanel.open()` 在无手势上下文必失败却回报成功。改为真结果回传（关联 id broadcast + 结果帧 validator + 6s 超时），失败/超时 overlay 如实显示「请点工具栏」。
- overlay 附件发送成功后清空 file input，旧附件不再随后续消息重复发送。
- **SSE 瞬断不再即杀会议/听写**：最后 SSE 断开改 8s 重连宽限（重连取消）；热键关窗不再同步释放 composer 租约（关窗后 1s 短宽限 + 8s 硬兜底）；Windows 关窗保存 spawn PID 直接 `process.kill`（原 `ps` 路径 win32 恒 no-op，窗口假活撞 `OVERLAY_STANDBY`）。
- `run_progress` 显式清除（null）持久生效：仅 `undefined` 才从 handoff 初始播种，`get()` 读路径同修；无关 update 不再重播种。
- `thread.updated` 双发去除（broadcast 已覆盖扩展端）；`llmLoopOwnerPanel` 在 chat.create/file.upload/regenerate 三路所有出口对称清理。
- Swift overlay `confirmPending` 六处复位（hydrate-attach / token 恢复 / done / 新线程 / 换线程 / 终态错误），HUD CTA 不再永远粘在「需要确认」。

### Tests

- #252 握手 terminate、#250 WS fanout 改行为级集成测试（替代源码 grep 假防线）；`ui.open_sidepanel` 双端 lockstep 测试。

### Known residuals（下轮）

- `stopSummonerWebServer` 丢 PID 不杀进程；overlay SSE 收不到 slash-pin 的 `thread.updated`；hydrate-detached 换线程 CTA；win32 不扫进程树；`chat.aborted` 不在 summoner 映射；`thread.digest_updated` 同款双发（`message-router.ts:678`）。
- 协议版本未 bump（MIN=MAX=1 期间语义变更靠同步发版，#252 起）；`mcp.toggle_server` WS ACL 残留属 #230。

## [0.5.3] — 2026-08-27

0.5.2（Windows 官方 NSIS）之上的产品切点：**知识 CRUD 诚实** + **形态切片 1–3 / 5 / 6**。这不是召唤器或租手「做完」的里程碑——T1 真人 bake-off 仍待（[#228](https://github.com/nehcuh/cmspark/issues/228)）。

### Added

- **知识诚实（#222 / #223 / #226）**：Side Panel 可点开正文、确认后保存、下载 `.md`、related≤3 芯片。图谱 / 双链 / Project / 默认 embedding 本季不做。
- **租手钥匙 + L8（切片 1–2，#226）**：`cmspark-agent outbound-grant` 签发 `cmg_`（不打开侧栏设置）；空 grant 默认 `GRANT_REQUIRED`；首次外泄走确认台 / Mac 托盘。`require_grant` 仍默认 true。overlay **永不** Allow/Deny。
- **召唤器诚实文案（切片 3，#226）**：默认收起条；「展开对话 / 打开浏览器 / 打开确认台」；MCP 轨藏而不删。禁止「展开工作台」「去侧栏批准」。
- **侧栏空态看山（切片 5）**：CompanionMark + 22px 招呼 + 句子邀请 + 作曲区。
- **匹配诚实 + 本轮步骤（切片 6，#227）**：技能匹配补 IDF（仅 skills；knowledge related 与 Obsidian 仍 TF）；聊天列 L0「本轮步骤」种子来自 H1 handoff todos。**v1 勾选基本只能点**（seed 行常无 `tool`，见 [#230](https://github.com/nehcuh/cmspark/issues/230)）。

### Changed

- 产品句锁定：家 = **已登录 Chrome + 硬闸**（[PRODUCT.md](PRODUCT.md) / [GOAL.md](docs/GOAL.md)）。侧栏是 Operate 面之一，不是家。
- **需求设计 Issue-first**：新需求必须先建 GitHub Issue，再写 spec/plan。模板：[`.github/ISSUE_TEMPLATE/design.md`](.github/ISSUE_TEMPLATE/design.md)。本季余项：[#228](https://github.com/nehcuh/cmspark/issues/228) T1 · [#229](https://github.com/nehcuh/cmspark/issues/229) 召唤器 P2 · [#230](https://github.com/nehcuh/cmspark/issues/230) 残留。

### Fixed

- Windows：`launch-hidden.vbs` 设 `NODE_PATH`，打包后 systray2 能解析（#224）。
- Overlay：合并冲掉的 paper HUD / I1/I2 恢复（#225）。

### Honesty / not in this cut

- T1 真人 bake-off **未跑**；不得扩默认 outbound profile，不得对外声称护城河。
- F-S-10（trusted/cruise 下 `mcp__*` 可能不弹确认）本季不修完；禁止用 overlay 管 MCP 掩盖。
- `outbound-grant` 对未知 flag 仍静默忽略。

## [0.5.2] — 2026-08-20

### Packaging

- **Windows 官方安装器**：GitHub Release 在 `cmspark-v*-windows-x64.zip` 之外增加 `CMspark-Setup-v*.exe`（NSIS）。安装器包装与 zip **同一份** `package.sh` staging（`node.exe` + `cmspark-agent.js` + 扩展），每用户装到 `%LOCALAPPDATA%\CMspark`，HKCU 开机自启 + ARP 卸载。CI 钉 Chocolatey `nsis` **3.12.0**，`CMSPARK_REQUIRE_NSIS=1`：缺 makensis **失败**，不静默只发 zip。SEA（`build-windows-exe.ps1`）不再产出官方同名 Setup.exe。产物未 Authenticode 签名（REL-1），SmartScreen 会警告。见 [#204](https://github.com/nehcuh/cmspark/pull/204)。

## [0.5.1] — 2026-08-18

### Added

- **对话框用户附图**：Side Panel 可粘贴 / 点选 / 拖入 PNG·JPEG·GIF·WebP。线程生效主模型 `likelyMultimodal` 时原生看图，否则走视觉轨；工具截图 / PDF 内嵌图仍走视觉轨。
- 附件芯片、48px 对话缩略图、首次发送目的地主机提示；sidecar 落盘（0o600/0o700 + realpath）；WS 帧 10MiB−256KiB 拒发。

### Security / Trust (already on main since 0.5.0; recorded at 0.5.1 cut)

- **C1** 无人值守 dual-write：武装前快照三旗；解除/TTL 过期**始终**恢复快照（不再仅 `clear_cruise`）
- **C2/C3** 急停 ≠ 解除：值守仍开 banner；确认台空桌面常驻「值守中：桌面确认已静默」
- **C4** 后果矩阵拆分 evaluate vs 导航；默认值守不 waive evaluate forceConfirm
- **C5** Pack Trust `skip_l2`/三旗需 Settings 同款短语 step-up（服务端拒绝 + PacksPanel）
- **C6** Worker `WORKER_HARD_DENY` 运行时 `isToolAllowed` 再强制；`thread.update` 不可开全表面
- **C7/C8** shell cwd / netsec ports L2 bind 与 execute 预规范化一致
- **C12** security-gates 去掉 `force_confirm` 假绿断言
- **C9** CI lockstep：`ws-router-validator-lockstep` 测试
- **C11** UI `SURFACE_BY_TOOL` 表（含 shell_exec / netsec / scroll_to / upload_file）
- **C13–C16** SoT/文档诚实：SUPERSEDED Aug-02 设计；mcp.md `require_grant` 默认 true；CU Apps 坐标开关 0.5.0；ADR-021 residual windowLevel hard

### Also on tip since 0.5.0 (recorded at 0.5.1 cut)

- **#160** 无人值守 re-L2 静默（ADR-021 2026-08-09 修订）
- **#161** Windows voice/shell closeout（shell/netsec token binding 对齐）
- 会议用户指南：STT `resource_conflict` 恢复说明 + 纪要模板用法（§3.5–3.6）
- 会议 **P1 近实时**（默认渐进假设 + ~8s 定稿）与 **P2 长会**（直播/上传硬上限 3h、软提示 2h；纪要输入 20 万字）

### Fixed

- Windows：外部编程 Agent（ACP）启动不再命中 npm 的 Unix shebang 垫片（`spawn ENOENT`），也不再对 `.cmd` 直接 CreateProcess（`EINVAL`）。发现优先 `.exe`/`.cmd`，并把 Claude/Pi 等 shim 解包为 PE / `node script.js`。
- Windows Mode C / wrapViaCmd 共识 R1–R5：禁止 WindowsApps `wt.exe` 假 L1；`auto` 先 `start` 失败可 L0；`cmd /c` 剥离 `-p`/prompt；cmd-host 只走 L0；粘贴行带 `Get-Content` 任务文件。
- Windows ACP P2（R6–R14）：临时文件 `wx`+延迟删除；`start` 全 token 引号；`System32\taskkill.exe`；拒绝用 companion PE 当 node；unwrap `%~dp0`；`joinDp0` 反斜杠；spawn 接线锁；设置补 WT/cmd；空列表说明 shebang 垫片。
- Windows Mode C post-#191：`start` 走 `cmd /d /s /c` extra-quote + `windowsVerbatimArguments`（不再被 CRT 改写成 `\"`）；真 PE `wt.exe` 的 exit 0 视为 CLI 交班成功；`cmd`/`powershell` 钉 System32；成功时间线用实际打开的 app，不用 config pref。

### Packaging

- `run-esbuild-bundle.mjs` 直接 spawn esbuild 原生二进制（避免 node 解析 Mach-O）

## [0.5.0] — 2026-08-08

### 稳定切点

听写 / 会议 / 本机 STT 产品线合入并文档化；Computer Use 实验定位仅保留 **Qwen3-VL**；macOS DMG 可打包安装。

### Added

- **听写+ D2**：按住热键；设置中 **按键盘录制** 组合键；文字/语音改设置命令条  
- **实时出字**：浏览器 Web Speech interim；本机 Whisper **M2 渐进假设流**（PCM 流式 + `voice.stt.partial_request`，约 8s 窗定稿）  
- **会议**：装配 › 场景 › 会议 工作台入口；Mtg0–3（粘贴/本机录/上传/实验发言人N）  
- ADR-023 / ADR-024 与用户指南 [meeting-and-dictation-user-guide](docs/meeting-and-dictation-user-guide.md)

### Removed

- **TinyClick / Florence-2 ONNX** 全栈与 `onnxruntime-node`、CI vendor 校验（PR #151）  
- 实验桌面定位统一为 **Qwen3-VL**

### Changed

- 产品版本 **0.4.0 → 0.5.0**
- 文档导航、GOAL G22、architecture §9 与 README 能力表同步  

### Security / Trust

- 本机 STT 仍走 chrome-extension origin fence；partial 失败 soft-skip 不杀 live 会话  
- Pack 仍不得写 voice / hotkey / ack  

## [0.4.0] — 2026-08

### Added / shipped under 0.4.x

- Multi-agent · Mission Board · Pack / 企业模块  
- Computer Use / Host / Apps · Confirm Center · Outbound MCP 骨架  
- Qwen3-VL 实验定位层  
- 听写 M1 + Path B 本机 STT 初版 · Dictation+ D1 · 会议 Mtg 初版（后续并入 0.5.0 文档）  

## [0.3.0] — 2026-07

- MCP · Mission Pack · Computer Use / Host 主路径 · Multi-agent P0  

---

链接：

- [docs/README.md](docs/README.md)  
- [GOAL.md](docs/GOAL.md)  

```

### FULL DESIGN.md
```
# Design

## Source of truth
Active · 2026-09-09 · GitHub [#481](https://github.com/nehcuh/cmspark/issues/481), [#488](https://github.com/nehcuh/cmspark/issues/488).
This is the current UI/UX contract for the extension workspace, summoner, settings,
code panel, terminal, confirmation cockpit, meetings, graphs and tray. It consolidates
#469 / #471 / #473 / #474 / #476 / #477 instead of appending competing layout rules.
`docs/DESIGN.md` retains capability/safety contracts; its older mascot-first,
tiny-chrome and narrow-only presentation is superseded.

Evidence: [workspace audit](docs/audit/2026-09-08-workspace-ux-audit.md).
Scope and proposal: [current repairs and projects](docs/superpowers/plans/2026-09-08-workspace-projects-ux.md).
Native prerequisites: [#476 plan](docs/superpowers/plans/2026-09-08-desktop-workbench.md).
The user prefers Codex's quiet hierarchy. No current Codex screenshot was inspected
for this revision; this is not a pixel-matching or feature-parity claim.

## Brand
Calm, precise, capable. Neutral paper/ink, restrained indigo links/focus, semantic
risk colors. Avoid gradients, decorative counters, dense icon ribbons and large
mascots. Do not reintroduce the decorative 山 mark in summoner empty states.
The static app/extension mark is owned by `scripts/lib/brand-icon.mjs`. The tray
alone represents Companion process state: green solid center running, red hollow
stopped, amber unknown. No tray title or redundant menu header; tooltip and native
accessibility retain words. WebSocket connectivity is separate. Keep macOS,
Windows and extension assets aligned.

## Product goals
Make conversation, prior work and the next action easy to find. Input, recording
feedback, stop and pending confirmation remain reachable. A coding run belongs to
its originating conversation; changing views does not transfer ownership.
The complete #476 desktop workbench supports work without Codex, with optional
programming agents and existing Chrome for web tasks. This is a product goal;
the current Chromium summoner is transitional, not that complete native product.

Current #481 delivery: voice reliability/feedback (#482), coding-session scope
(#483), summoner manual tags/groups using existing metadata, and conversation-first
navigation. Project entities/defaults, a global activity center, merged code/terminal
workspace and native management are future work. No copied Codex assets, mandatory
external agent, blanket permission or automatic live-configuration migration.

## Personas and jobs
Change managers assemble sourced requirements, versions, artifacts, architecture,
runtime, code and test evidence. Developers continue across conversations and
repositories with optional programming agents. Others read websites, dictate a
message or record meetings. Ordinary conversations require no repository or project.

## Information architecture
Current navigation order: new conversation; search/recent conversations with
visible management; supporting resources; settings where actually available.
Use the same order on both surfaces. Preserve existing capability entries.
Name browser tabs “浏览器标签页”; conversation categories remain “标签 / 分组”.
Wide screens have left navigation and one main conversation. Narrow navigation is
a text-triggered, nonmodal, in-flow disclosure. StatusRail is the single header:
title, narrow navigation/new-conversation controls, existing popout/management/
status/more. FocusBand owns priority feedback; its coding slot shows only the
current conversation's session. A background event cannot open another thread's panel.

ThreadList owns extension history, time/tags/manual/AI views, trash and bulk actions.
Recent navigation projects the same store. Summoner uses persisted `user_tags` and
`topic_folder`, not a second grouping store. AI grouping derives from extracted tags
and never rewrites manual grouping. Keep AI extraction, cleanup and graph entries.
Full selection uses the current search/tag/trash view and excludes busy threads.
Cleanup suggestions own a separate selection. An empty selection never expands
into a delete-all action. Confirmations show actual targets; only server-confirmed
results update the list. Partial failures stay visible and unknown outcomes require
refresh before retry. Empty cleanup requires server-side content revalidation.
The entire history panel scrolls on short screens; its list cannot collapse to zero.
Meeting close and navigation wait for final transcript persistence and end receipt;
failures retain the panel with a retry action.
Knowledge graph (#490) has a real canvas lifecycle tied to asynchronous data,
an always available searchable document list, explicit fit/zoom/refresh, and
selected-document relations. The list and notices occupy layout space rather
than covering the canvas. Canvas labels are readable by default; collision
suppression never removes list entries. Selection explores in place; opening
the existing knowledge panel is explicit. Isolated documents stay visible.
Color is a grouping aid; solid similarity edges and dashed AI relations retain
their provenance. Search never triggers AI; refresh preserves the user's existing
naming preference (off by default, enabled preference permits existing on-demand
label completion). Organization still requires an explicit action. Existing AI
naming, organization, lock/unlock and relation reasons remain discoverable.
Below 760px, graph and browser stack in a scrollable page; zero documents,
disconnected transport and loading failures have distinct recovery copy.
Existing resource panels use ContextPanelHost above the composer; summoner resource
attachments retain their current surface until native management lands. Label
“used in this conversation” separately from global configuration. Read-only lists
must not imply edit/install/connect capability. Settings uses one named dialog,
category pages (wide rail/narrow select), stable deep links and mounted forms that
preserve drafts. Pairing/elevated trust remains visible; independent saves stay explicit.

Future proposal: optional Project → Conversation → Execution records. Project is
a durable context with an optional local repository, not a renamed manual folder.
Conversations may remain outside projects. No project UI ships before its real model.

## Design principles
One dominant action per area; supporting controls on demand. Preserve existing
data/execution/confirmation owners. Fix state scope before adding task controls.
Keep completed code results reachable in their conversation; an old run cannot seize
a new conversation's header. Current scope repair does not delete results to simplify UI.
Layout does not grant trust. Confirmation handlers, order/roles, initial focus,
timeout, whitelist, auto-approve defaults and critical evidence retain their contracts.
FocusBand's confirmation/stop priority is authoritative. Cockpit confirmation
DOM/handlers are outside this visual batch. Resizing never grants desktop privileges.

## Visual language
`chrome-extension/src/sidepanel/ui/tokens.ts` owns new React colors; Companion HTML
mirrors the palette without a new bundler. Neutral surfaces, subtle borders,
readable secondary text, charcoal primary composer action and indigo focus.
System sans; body 14–15px, chrome 12–13px, headings 15–24px. Spacing 4/8/12/16/24/32px;
radii 8px controls, 12px cards, 20px composer. Quiet user bubbles, unboxed assistant
prose, shadows only for floating surfaces. Existing SVG icons; no network/font assets.
Terminal uses existing dark tokens. Respect reduced motion.

## Components
Reuse WorkspaceFrame/WorkspaceNavigation, StatusRail, ThreadList/metadata editor,
Modal/tokens, ChatView, ComposerDock, ContextPanelHost and settings pages. Session
selection belongs in shared typed selectors/reducers, not divergent component filters.
Voice state explains preparing/listening/processing/failure next to the mic.
Use explicit scoped classes, not arbitrary inline-style selectors. Share navigation,
copy and data projections with transport adapters when practical; no forced full
React/native rewrite, duplicated thread cache, Agent or confirmation manager.

## Accessibility
Target WCAG 2.2 AA practices: new ordinary text contrast at least 4.5:1, visible
focus, semantic buttons, text alongside risk colors, Enter/Space, Escape and focus
return, no nested interactive elements. Essential controls at least 32px, primary
36px. Preserve live status/destructive copy. Voice animation supplements text and
respects reduced motion. Automated checks are not a conformance certification.

## Responsive behavior
320–759px: full-width conversation, no fixed wide columns; nonmodal navigation
bounded to 36dvh (28dvh below 560px height), independently scrollable. At 760px+:
persistent 220px navigation; conversation reading width up to 780px. ContextPanelHost
is bounded to min(36dvh, 360px), or 28dvh at short height, and yields to confirmation.
Wide settings use a bounded centered dialog. Only message/supporting content shrinks;
composer/stop remain reachable. Long titles wrap/truncate without hiding actions.
Verify 320/390/759/760/1040/1440px widths, 420/480px heights and 200% equivalent reflow.
Summoner default 1040×760, explicit compact 360×420; clamp and retain user resizing.

## Interaction states
Empty suggestions fill, never send. Loading shows the pending action at its source,
never a silent mic. Listening begins only when capture is ready; partial recognition
is distinct from final text. Processing stays visible after stop; failure keeps drafts.
Do not promise hardware-independent transcription latency: record cold/warm setup,
first partial and finalization separately. Save success requires matching persisted
fields/identity, not transport ACK. Switching threads cannot redirect an in-flight
save, transcript, report, approval or session event. Offline offers recovery without
invented completion. Process exit, report import and review approval are distinct.

## Content voice
Chinese product chrome, clear verbs, short labels. Use 对话, 项目 (real entity only),
标签, 分组, 浏览器标签页, 知识, 场景, 设置. Code work may become “代码与终端”;
ACP/PTY details belong inside technical disclosure. Errors point to current settings
labels (“输入与语音”), not stale “设置 → 听写” navigation.

## Implementation constraints
React 18/Plasmo, existing styles/tokens; no new production dependency for this batch.
#481 narrowly expands the authenticated overlay's payload ACL for existing
`thread.update`: only alias/user_tags/topic_folder, using the shared HTTP/WS metadata
patch validator. Unknown fields (including alias plus config) reject the whole patch.
This is an ACL change and a T3 review focus, not an unchanged-policy claim. It
supersedes only #476's scheduling of these low-risk metadata fields; workspace,
trust/config, MCP writes, terminal, install/import and approval remain denied.
Native identity and native confirmation remain prerequisites for privileged #476
work. Current Chrome actions connect/open the existing browser; they are not a
per-operation background guarantee. No profile copying or silent foreground fallback.
Issue-first, owning machine/contract tests, real-render synthetic UI checks, build
and actual independent Grok + DeepSeek gates. Native host behavior, signatures,
microphone performance and Windows runtime need separate evidence. Reports distinguish
current delivery, reviewed design and future capabilities.

## Open questions
- [ ] Project proposal: maintainers to validate optional single-directory defaults,
  migration and storage in a subsequent implementation Issue; no shipped schema here.
- [ ] Native #476 management, Windows host visuals and task-level Chrome visibility
  remain owned by their slices; current repairs cannot close them.
- [ ] Voice #482: measure installed engine/model cold/warm timing before claiming
  the user's performance issue resolved.
- [ ] Resource/settings/meeting/graph improvements in the audit need separately
  tracked changes and surface-specific acceptance; an audit is not implementation.

```

### FULL chrome-extension/scripts/render-knowledge-graph-fixture.cjs
```
// Real KnowledgeGraphApp and graph builder; only Chrome storage/runtime are fake.
// Never reads a user knowledge index or starts a Companion connection.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const out = process.argv[2];
if (!out) throw new Error('output directory required');
const esbuild = require(path.join(root, 'node_modules/esbuild'));

async function main() {
  fs.mkdirSync(out, { recursive: true });
  // The serializer is private in a large router with live configuration imports.
  // Execute its exact source with only that configuration boundary replaced;
  // do not hand-copy the wire keys into a fixture and assume they are correct.
  const router = fs.readFileSync(path.join(root, '../companion/src/message-router.ts'), 'utf8');
  const serializer = router.match(/\nfunction knowledgeGraphFrame\([\s\S]*?\n}\n/)?.[0];
  if (!serializer) throw new Error('production knowledgeGraphFrame definition not found');
  const rebuilding = router.slice(router.indexOf('const graph = skillEngine.getKnowledgeGraph'))
    .match(/if \(!graph\) \{[\s\S]*?return (\{[\s\S]*?\n        \})\n/)?.[1];
  if (!rebuilding) throw new Error('production rebuilding frame definition not found');
  const built = await esbuild.build({
    stdin: { contents: `export {buildKnowledgeGraph} from '../companion/src/skills/knowledge-graph';
      const knowledgeExtractLlmConfig=()=>({provider:'fixture'});
      let knowledgeGraphOrganizeRun=null;export function setOrganizing(value){knowledgeGraphOrganizeRun=value?{}:null;}
      ${serializer}\nexport {knowledgeGraphFrame};
      export function rebuildingFrame(){const actionError=undefined;return ${rebuilding};}`, resolveDir: root, loader: 'ts' },
    bundle: true, platform: 'node', format: 'cjs', write: false,
  });
  const production = new Module(path.join(out, 'graph-builder.cjs'), module);
  production._compile(built.outputFiles[0].text, path.join(out, 'graph-builder.cjs'));
  const { buildKnowledgeGraph, knowledgeGraphFrame, rebuildingFrame, setOrganizing } = production.exports;
  const graphs = { rebuilding: rebuildingFrame() };
  for (const count of [0, 1, 4, 20, 200]) {
    const docs = Array.from({ length: count }, (_, i) => ({
      id: `fixture-${String(i + 1).padStart(3, '0')}`,
      name: `fixture-${i + 1}`, title: ['SQLite 离线检索', 'Orchids 高山兰花', 'Telescope 天文观测', 'Sourdough 面包发酵'][i] || `Knowledge${String(i + 1).padStart(3, '0')}`,
      tags: [], folder: i % 2 ? '旅行' : '开发', bucket: 'global',
      // Deliberately orthogonal: zero TF edges is a real production result.
      vec: { [`unique-${i}`]: 1 }, description: '',
    }));
    graphs[count] = knowledgeGraphFrame(buildKnowledgeGraph(docs));
    if (count === 4) {
      const llm = {
        groups: [{ ids: [docs[0].id, docs[2].id], name: '开发主题', summary: '两篇开发笔记' }],
        relations: [{ a: docs[0].id, b: docs[2].id, reason: '共同讨论开发实践', confidence: 0.9 }],
      };
      graphs.organized = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm }));
      setOrganizing(true);
      graphs.organizing = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm }));
      setOrganizing(false);
      graphs.locked = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm, lock: { groups: llm.groups } }));
      graphs.similar = knowledgeGraphFrame(buildKnowledgeGraph(docs.map((doc, i) => ({ ...doc, description: i < 2 ? 'shared retrieval database indexing' : '' }))));
    }
  }
  fs.writeFileSync(path.join(out, 'builder-output.json'), JSON.stringify(graphs, null, 2));
  const source = `
import React from 'react';
import {createRoot} from 'react-dom/client';
import {KnowledgeGraphApp} from './src/knowledge-graph/KnowledgeGraphApp';
import {parseKnowledgeGraphPayload} from './src/knowledge-graph/wire';
import {KNOWLEDGE_GRAPH_SNAPSHOT_KEY as KEY,writeKnowledgeGraphSnapshot,knowledgeGraphErrorPayload} from './src/background/knowledge-graph';
import {KNOWLEDGE_GRAPH_LLM_LABELS_KEY} from './src/knowledge-graph/llm-pref';
const graphs=${JSON.stringify(graphs)};
const listeners=new Set(); const session={}; const local=new URLSearchParams(location.search).has('labels')?{[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]:true}:{};
window.sent=[];window.storageReads=0;window.storageReleased=false;window.sendFailure=false;
let suppressStorageEvent=false;
let release;const initialRead=new Promise(resolve=>release=resolve);
const emit=(changes,area)=>{for(const fn of [...listeners])fn(changes,area)};
window.chrome={runtime:{lastError:undefined,sendMessage:(message,callback)=>{window.sent.push(message);const response={sent:!window.sendFailure};callback?.(response);return Promise.resolve(response)}},storage:{
session:{get:async()=>{window.storageReads++;await initialRead;return {...session}},set:async values=>{Object.assign(session,values);if(!suppressStorageEvent)emit(Object.fromEntries(Object.entries(values).map(([key,newValue])=>[key,{newValue}])), 'session')}},
local:{get:async()=>({...local}),set:async values=>{Object.assign(local,values);emit(Object.fromEntries(Object.entries(values).map(([key,newValue])=>[key,{newValue}])), 'local')}},
onChanged:{addListener:fn=>listeners.add(fn),removeListener:fn=>listeners.delete(fn)}}};
window.graphFixture={graphs,
async publish(key,extra){const payload=key==='error'?knowledgeGraphErrorPayload({type:'error',error:'knowledge.graph fixture failure'}):parseKnowledgeGraphPayload(graphs[key]);if(!payload)throw new Error('invalid production payload');await writeKnowledgeGraphSnapshot(payload,extra);},
async release(key='4',extra){suppressStorageEvent=true;await this.publish(key,extra);suppressStorageEvent=false;window.storageReleased=true;release();},
readSnapshot:()=>session[KEY]};
// Observe real drawing and preserve every native call. Counters alone cannot
// pass the regression: Python also checks native Canvas pixels and dimensions.
window.drawProbe={arcs:0,text:[],frames:0,latestArcs:[],latestText:[],latestLines:[],path:[]};
for(const name of ['arc','fillText','clearRect','beginPath','moveTo','lineTo','stroke']){const native=CanvasRenderingContext2D.prototype[name];CanvasRenderingContext2D.prototype[name]=function(...args){const p=window.drawProbe;if(name==='clearRect'){p.frames++;p.latestArcs=[];p.latestText=[];p.latestLines=[]}if(name==='beginPath')p.path=[];if(name==='moveTo'||name==='lineTo'){const t=this.getTransform();p.path.push({x:t.a*args[0]+t.c*args[1]+t.e,y:t.b*args[0]+t.d*args[1]+t.f})}if(name==='stroke'&&p.path.length===2)p.latestLines.push({a:p.path[0],b:p.path[1],dashed:this.getLineDash().length>0});if(name==='arc'){p.arcs++;const t=this.getTransform();p.latestArcs.push({x:t.a*args[0]+t.c*args[1]+t.e,y:t.b*args[0]+t.d*args[1]+t.f,r:args[2]*t.a})}if(name==='fillText'){p.text.push(String(args[0]));p.latestText.push(String(args[0]));if(p.text.length>2000)p.text.splice(0,1000)}return native.apply(this,args)}};
createRoot(document.getElementById('root')).render(<KnowledgeGraphApp/>);
`;
  const baseline = process.argv.includes('--baseline');
  const plugins = baseline ? [{ name: 'baseline-app', setup(build) {
    build.onLoad({ filter: /KnowledgeGraphApp\.tsx$/ }, () => ({
      contents: execFileSync('git', ['show', 'aada096a:chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx'], { cwd: root, encoding: 'utf8' }),
      loader: 'tsx', resolveDir: path.join(root, 'src/knowledge-graph'),
    }));
  } }] : [];
  await esbuild.build({ stdin: { contents: source, resolveDir: root, loader: 'tsx' }, bundle: true, outfile: path.join(out, 'app.js'), jsx: 'automatic', plugins });
  fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body,#root{margin:0;width:100%;height:100%}*{box-sizing:border-box}</style><body><div id="root"></div><script src="app.js"></script></body></html>');
}
main().catch(error => { console.error(error); process.exitCode = 1; });

```

### FULL chrome-extension/scripts/test-knowledge-graph-ui.py
```
"""Real graph builder + KnowledgeGraphApp, delayed storage, isolated Chrome.

Run after nvm use 22:
  uv run --with playwright python scripts/test-knowledge-graph-ui.py
"""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', action='store_true', help='Capture the pre-fix failure without hiding its assertion')
parser.add_argument('--artifacts', type=Path, default=Path(__file__).resolve().parents[2] / '.omx/artifacts/knowledge-graph-490')
args = parser.parse_args()
args.artifacts.mkdir(parents=True, exist_ok=True)
project = Path(__file__).resolve().parent.parent

with tempfile.TemporaryDirectory(prefix='cmspark-knowledge-graph-') as directory:
    subprocess.run(['node', 'scripts/render-knowledge-graph-fixture.cjs', directory] + (['--baseline'] if args.baseline else []), cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 800})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        assert page.locator('canvas').count() == 0, 'Initial storage read must remain asynchronous'
        page.evaluate("window.graphFixture.release('4')")
        page.locator('canvas').wait_for()
        if args.baseline:
            page.wait_for_timeout(400)
            evidence = page.evaluate('''() => {
                const c=document.querySelector('canvas');
                return {storageReleased:window.storageReleased, snapshotNodes:window.graphFixture.readSnapshot().nodes.length,
                    canvasWidth:c.width,canvasHeight:c.height,cssWidth:c.getBoundingClientRect().width,
                    drawnArcs:window.drawProbe.arcs,drawnFrames:window.drawProbe.frames,
                    opaquePixels:[...c.getContext('2d').getImageData(0,0,c.width,c.height).data].filter((v,i)=>i%4===3&&v>0).length};
            }''')
            page.screenshot(path=str(args.artifacts / 'before.png'), full_page=True)
            (args.artifacts / 'before.json').write_text(json.dumps(evidence, indent=2) + '\n')
            print(json.dumps(evidence, indent=2), flush=True)
            assert evidence['drawnArcs'] >= 4 and evidence['opaquePixels'] > 0, 'Async snapshot mounted a Canvas but never started the drawing effect'
        def painted(count):
            pixels = page.wait_for_function('''(count) => {
                const c=document.querySelector('canvas');if(!c)return false;
                const ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];
                const arcs=window.drawProbe.latestArcs;
                const visible=arcs.filter(p=>p.x>=0&&p.x<c.width&&p.y>=0&&p.y<c.height);
                const colored=visible.filter(p=>{
                    const pixel=[...ctx.getImageData(Math.floor(p.x),Math.floor(p.y),1,1).data];
                    return pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]);
                });
                if(arcs.length<count||bg[3]!==255||!colored.length)return false;
                return {width:c.width,height:c.height,css:c.getBoundingClientRect().width,
                    dpr:devicePixelRatio,backgroundAlpha:bg[3],visible:visible.length,colored:colored.length};
            }''', arg=count).json_value()
            assert pixels['width'] == int(pixels['css'] * pixels['dpr']), pixels
            assert pixels['height'] >= 280, pixels
            assert pixels['backgroundAlpha'] == 255 and pixels['colored'] > 0, pixels
            return pixels

        def open_fixture(count):
            page.goto((Path(directory) / 'index.html').as_uri())
            page.wait_for_function('window.storageReads===1')
            assert page.locator('canvas').count() == 0
            page.evaluate('(count)=>window.graphFixture.release(String(count))', count)
            if count == 0:
                page.get_by_text('知识库暂无可展示的文档', exact=False).wait_for()
                return
            page.get_by_test_id('knowledge-graph-canvas').wait_for()
            painted(count)

        painted(4)
        summaries = []
        for count in [1, 4, 20, 200]:
            open_fixture(count)
            page.wait_for_function("window.drawProbe.latestText.some(text=>text.includes('SQLite'))")
            assert page.locator('button[data-node-id]').count() == count
            assert page.evaluate('window.graphFixture.readSnapshot().edges.length') == 0
            page.get_by_text('暂无明确关联，仍可浏览全部知识', exact=True).wait_for()
            assert not page.evaluate("window.sent.some(m=>m.organize||m.type==='knowledge_graph.open_doc')")
            summaries.append({'nodes': count, **painted(count)})
            page.screenshot(path=str(args.artifacts / f'after-{count}.png'), full_page=True)
        print('PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state')

        # Removing a Canvas must stop its loop; a later success creates a working
        # new Canvas, independently of the mount that originally saw null refs.
        page.evaluate("window.oldCanvas=document.querySelector('canvas');window.graphFixture.publish('error')")
        page.locator('canvas').wait_for(state='detached')
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        stopped_frames = page.evaluate('window.drawProbe.frames')
        page.wait_for_timeout(80)
        assert page.evaluate('window.drawProbe.frames') == stopped_frames
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.refresh')")
        page.evaluate("window.drawProbe.latestArcs=[];window.graphFixture.publish('4')")
        painted(4)
        assert page.evaluate("window.oldCanvas!==document.querySelector('canvas')")
        print('PASS ok → error stops drawing → refresh → ok remount draws real nodes')

        page.evaluate('window.sendFailure=true')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        page.get_by_text('无法连接 CMspark', exact=False).wait_for()
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        page.evaluate('window.sendFailure=false')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        print('PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI')

        search = page.get_by_role('textbox', name='搜索知识', exact=True)
        search.fill('不存在的知识')
        assert page.locator('button[data-node-id]').count() == 0
        assert page.locator('canvas').is_visible()
        search.fill('Telescope')
        assert page.locator('button[data-node-id]').count() == 1
        page.locator('button[data-node-id="fixture-003"]').click()
        assert not page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.open_doc')")
        page.get_by_role('button', name='在知识面板打开', exact=True).click()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').map(m=>m.id)") == ['fixture-003']
        search.fill('')
        radius = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='放大', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r>r', arg=radius)
        enlarged = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='缩小', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r<r', arg=enlarged)
        page.get_by_role('button', name='适应画布', exact=True).click()
        painted(4)
        page.get_by_role('button', name='收起列表', exact=True).click()
        assert page.get_by_role('complementary', name='知识浏览', exact=True).count() == 0
        page.get_by_role('button', name='浏览知识', exact=True).click()
        page.get_by_role('complementary', name='知识浏览', exact=True).wait_for()
        print('PASS search incl. empty results, local selection, explicit document open, camera and list controls')

        # Production builder emits the organized group and AI relation; its
        # serializer controls optional wire keys and no fixture invents nodes.
        page.evaluate("window.graphFixture.publish('organized')")
        group = page.get_by_role('combobox', name='筛选分组', exact=True)
        page.wait_for_function("[...document.querySelectorAll('select option')].some(o=>o.textContent.includes('开发主题'))")
        group_key = page.evaluate("Object.keys(window.graphFixture.readSnapshot().labels)[0]")
        group.select_option(group_key)
        assert page.locator('button[data-node-id]').count() == 2
        group.select_option('')
        page.locator('button[data-node-id="fixture-001"]').click()
        page.get_by_text('AI 关联理由：共同讨论开发实践', exact=True).wait_for()
        print('PASS production organized group filtering and readable AI relationship reason')

        def painted_line(dashed):
            page.wait_for_function('''(dashed)=>{
                const c=document.querySelector('canvas'),ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];if(bg[3]!==255)return false;
                return window.drawProbe.latestLines.filter(line=>line.dashed===dashed).some(line=>{
                    for(let step=2;step<19;step++)for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){
                        const x=Math.floor(line.a.x+(line.b.x-line.a.x)*step/20)+dx;
                        const y=Math.floor(line.a.y+(line.b.y-line.a.y)*step/20)+dy;
                        if(x<0||y<0||x>=c.width||y>=c.height)continue;
                        const pixel=[...ctx.getImageData(x,y,1,1).data];
                        if(pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]))return true;
                    }return false;
                });
            }''', arg=dashed)
        painted_line(True)
        groups = page.locator('details').filter(has=page.locator('summary').filter(has_text='分组说明与管理'))
        if groups.get_attribute('open') is None:
            groups.locator('summary').click()
        page.get_by_role('button', name='保留这版分组', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].lock_group') == group_key
        page.evaluate("window.graphFixture.publish('locked')")
        page.get_by_role('button', name='解锁', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].unlock_group') == group_key
        page.get_by_text('AI 与分组', exact=True).click()
        page.get_by_role('button', name='重新整理', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].organize') is True
        page.evaluate("window.graphFixture.publish('organizing')")
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.evaluate("window.graphFixture.publish('organized')")
        assert page.get_by_role('button', name='重新整理', exact=True).is_enabled()
        page.evaluate("window.graphFixture.publish('similar')")
        painted(4)
        painted_line(False)
        assert page.evaluate('window.graphFixture.readSnapshot().edges.length') > 0
        print('PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts')

        # A real viewport resize must resize the Canvas bitmap; responsive
        # layout must not leave its controls as opaque overlays on the graph.
        for width, height in [(1440, 900), (960, 720), (760, 740), (390, 844), (320, 480), (1280, 800)]:
            page.set_viewport_size({'width': width, 'height': height})
            page.get_by_role('button', name='适应画布', exact=True).click()
            page.wait_for_function('''() => {
                const c=document.querySelector('canvas');return c.width===Math.floor(c.getBoundingClientRect().width*devicePixelRatio);
            }''')
            painted(4)
            canvas_box = page.locator('canvas').bounding_box()
            aside_box = page.get_by_role('complementary', name='知识浏览', exact=True).bounding_box()
            assert canvas_box and aside_box
            overlap_w = min(canvas_box['x'] + canvas_box['width'], aside_box['x'] + aside_box['width']) - max(canvas_box['x'], aside_box['x'])
            overlap_h = min(canvas_box['y'] + canvas_box['height'], aside_box['y'] + aside_box['height']) - max(canvas_box['y'], aside_box['y'])
            assert overlap_w <= 1 or overlap_h <= 1, (canvas_box, aside_box)
            assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')
            page.screenshot(path=str(args.artifacts / f'after-width-{width}.png'), full_page=True)
        print('PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow')

        open_fixture(0)
        assert page.locator('canvas').count() == 0

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('error')")
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        print('PASS initially cached error snapshot can refresh and recover without closing the page')

        page.goto((Path(directory) / 'index.html').as_uri() + '?labels')
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('4')")
        painted(4)
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is True
        assert not page.evaluate('window.sent.some(m=>m.organize)')
        print('PASS refresh preserves a previously enabled AI naming preference without automatically organizing')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('rebuilding',{focus_id:'fixture-003'})")
        assert page.locator('canvas').count() == 0
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Telescope 天文观测', exact=True).wait_for()
        print('PASS a requested document remains selected across rebuilding → success with no new focus id')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.evaluate("window.graphFixture.release('error')")
        page.wait_for_timeout(50)
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        print('PASS a stale initial storage result cannot overwrite a newer successful storage event')
        assert not errors, errors
        (args.artifacts / 'after.json').write_text(json.dumps(summaries, indent=2) + '\n')
        assert not errors, errors
        browser.close()
print('PASS delayed storage → real Canvas node drawing')

```

### FULL chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
```
// Full-page knowledge distribution graph.
// Spec: docs/superpowers/specs/2026-09-04-knowledge-graph-view-design.md
// Layout: reuse thread-graph force-layout; positions/edges are not persisted.

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type PointerEvent as ReactPointerEvent,
  type WheelEvent as ReactWheelEvent,
} from "react"
import { forceLayoutTick, seedLayoutNodes, type LayoutNode } from "../thread-graph/force-layout"
import { hexWithAlpha, lightenHex, UNTAGGED_COLOR } from "../thread-graph/tag-colors"
import { tokens } from "../sidepanel/ui/tokens"
import { filterKnowledgeNodes, fitKnowledgeCamera, shortKnowledgeTitle } from "./explorer"
import {
  KNOWLEDGE_GRAPH_SNAPSHOT_KEY,
  type KnowledgeGraphSnapshot,
} from "../background/knowledge-graph"
import {
  KnowledgeGraphColorSwitch,
  KnowledgeGraphGroupCard,
  KnowledgeGraphLlmSwitch,
  KnowledgeGraphLockDissolvedBanner,
  KnowledgeGraphNoRelationsNote,
  KnowledgeGraphOrganizeCta,
  KnowledgeGraphOrganizeErrorBar,
  KnowledgeGraphReorganizeButton,
  KnowledgeGraphStaleBadge,
  KnowledgeGraphStatusView,
  KnowledgeGraphTfSwitchBanner,
} from "./chrome"
import { hoverCaption, nodeColor, type ColorMode } from "./coloring"
import {
  KNOWLEDGE_GRAPH_AI_RELATION,
  KNOWLEDGE_GRAPH_ENTRY_LABEL,
  KNOWLEDGE_GRAPH_REASON_DISMISS,
  KNOWLEDGE_GRAPH_UNGROUPED_LABEL,
  knowledgeGraphBarMeta,
  shouldRenderGraphCanvas,
} from "./copy"
import {
  KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
  parseLlmLabelsPref,
  parseTfSwitchAck,
  writeLlmLabelsPref,
  writeTfSwitchAck,
  KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
} from "./llm-pref"
import {
  knowledgeGraphPairKey,
  knowledgeGraphViewModel,
  parseKnowledgeGraphPayload,
  type KnowledgeGraphNode,
  type KnowledgeGraphRelation,
} from "./wire"

type GraphDrawEdge = { a: string; b: string; score: number; dashed?: boolean; reason?: string }

const G = {
  canvas: tokens.darkBg,
  edgeSoft: "rgba(148, 163, 184, 0.22)",
  edgeHot: "rgba(165, 180, 252, 0.75)",
  edgeDim: "rgba(148, 163, 184, 0.06)",
  labelFocus: "rgba(248, 250, 252, 0.95)",
} as const

const HIT_PAD = 8
const REBUILD_POLL_MS = 2500
/** 重建轮询上限（复审 NIT-5）：40 × 2.5s = 100s 后停轮询，诚实提示手动刷新。 */
const REBUILD_POLL_MAX = 40
const EMPTY_NODES: KnowledgeGraphNode[] = []
const EMPTY_EDGES: NonNullable<KnowledgeGraphSnapshot["edges"]> = []
const EMPTY_LABELS: KnowledgeGraphSnapshot["labels"] = {}

function radiusForDegree(deg: number): number {
  return Math.min(10, 5 + Math.sqrt(deg) * 1.4)
}

export function KnowledgeGraphApp() {
  const [snap, setSnap] = useState<KnowledgeGraphSnapshot | null>(null)
  const [colorMode, setColorMode] = useState<ColorMode>("group")
  const [llmEnabled, setLlmEnabled] = useState(false)
  const llmEnabledRef = useRef(false)
  const [focusId, setFocusId] = useState<string | null>(null)
  const [hoverCaptionText, setHoverCaptionText] = useState("")
  const [panelOpen, setPanelOpen] = useState(true)
  const [query, setQuery] = useState("")
  const [groupFilter, setGroupFilter] = useState("")
  const [requestError, setRequestError] = useState("")

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nodesRef = useRef<LayoutNode[]>([])
  const edgesRef = useRef<GraphDrawEdge[]>([])
  const dragRef = useRef<{ id: string; ox: number; oy: number; moved: boolean } | null>(null)
  const [organizing, setOrganizing] = useState(false)
  const [relationOpen, setRelationOpen] = useState<KnowledgeGraphRelation | null>(null)
  const [tfAcked, setTfAcked] = useState(false)
  const [lockNotice, setLockNotice] = useState(false)
  const panRef = useRef({ x: 0, y: 0 })
  const scaleRef = useRef(1)
  const rafRef = useRef(0)
  const sizeRef = useRef({ w: 800, h: 600 })
  const simTicksRef = useRef(0)
  const hoverIdRef = useRef<string | null>(null)
  const focusIdRef = useRef<string | null>(null)
  const fittedRef = useRef(false)
  const userCameraRef = useRef(false)
  const colorByIdRef = useRef<Map<string, string>>(new Map())
  const nodesByIdRef = useRef<Map<string, KnowledgeGraphNode>>(new Map())
  const fitViewRef = useRef<() => void>(() => {})
  const captionByIdRef = useRef<Map<string, string>>(new Map())

  useEffect(() => {
    focusIdRef.current = focusId
  }, [focusId])

  const applySnap = useCallback((raw: unknown) => {
    const parsed = parseKnowledgeGraphPayload(raw)
    if (!parsed) return
    const rec = raw as Record<string, unknown>
    setSnap({
      ...parsed,
      ts: typeof rec.ts === "number" ? rec.ts : Date.now(),
      focus_id: typeof rec.focus_id === "string" ? rec.focus_id : null,
      llm_labels: rec.llm_labels === true,
    })
    if (typeof rec.focus_id === "string" && rec.focus_id) setFocusId(rec.focus_id)
    setOrganizing(parsed.organizing === true)
    setRequestError("")
  }, [])

  const refresh = useCallback(() => {
    // Preserve the existing user-authorized naming preference. Default reads
    // never enable naming or organization on the user's behalf.
    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", llm_labels: llmEnabledRef.current }, (res) => {
      if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
        setRequestError("无法连接 CMspark，请确认程序运行后刷新图谱。已有快照可继续浏览。")
      } else setRequestError("")
    })
  }, [])

  useEffect(() => {
    let cancelled = false
    let receivedSnapshot = false
    ;(async () => {
      try {
        const pref = await chrome.storage.local.get([
          KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
          KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
        ])
        if (!cancelled) {
          llmEnabledRef.current = parseLlmLabelsPref(pref[KNOWLEDGE_GRAPH_LLM_LABELS_KEY])
          setLlmEnabled(llmEnabledRef.current)
          setTfAcked(parseTfSwitchAck(pref[KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY]))
        }
      } catch {
        /* default off */
      }
      try {
        const res = await chrome.storage.session.get(KNOWLEDGE_GRAPH_SNAPSHOT_KEY)
        if (cancelled) return
        if (!receivedSnapshot) applySnap(res[KNOWLEDGE_GRAPH_SNAPSHOT_KEY])
      } catch {
        /* empty → rebuilding banner via null snap */
      }
      if (!cancelled) refresh()
    })()
    const onStorage = (
      changes: Record<string, chrome.storage.StorageChange>,
      area: string,
    ) => {
      if (area === "session" && changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY]) {
        receivedSnapshot = true
        applySnap(changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY].newValue)
      }
      if (area === "local" && changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]) {
        llmEnabledRef.current = parseLlmLabelsPref(changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY].newValue)
        setLlmEnabled(llmEnabledRef.current)
      }

    }
    chrome.storage.onChanged.addListener(onStorage)
    return () => {
      cancelled = true
      chrome.storage.onChanged.removeListener(onStorage)
    }
  }, [applySnap, refresh])

  const status = snap?.status ?? "rebuilding"
  const truncated = snap?.truncated === true
  const showCanvas = snap ? shouldRenderGraphCanvas(status) : false
  const [pollExhausted, setPollExhausted] = useState(false)

  useEffect(() => {
    if (status !== "rebuilding") {
      setPollExhausted(false)
      return
    }
    // 复审 NIT-5：轮询加上限（40 × 2.5s = 100s），打满停轮询并诚实提示手动刷新。
    let polls = 0
    const tick = () => {
      polls += 1
      if (polls > REBUILD_POLL_MAX) {
        setPollExhausted(true)
        clearInterval(id)
        return
      }
      refresh()
    }
    const id = setInterval(tick, REBUILD_POLL_MS)
    return () => clearInterval(id)
  }, [status, refresh])

  const payloadNodes = snap?.nodes ?? EMPTY_NODES
  const payloadEdges = snap?.edges ?? EMPTY_EDGES
  const labels = snap?.labels ?? EMPTY_LABELS
  const view = useMemo(() => knowledgeGraphViewModel(snap), [snap])
  const { llmLane, showOrganizeCta, showReorganize, showNoRelations, relationsToDraw } = view
  const payloadRelations = relationsToDraw
  const llmReady = snap?.llm_ready !== false
  const showTfBanner =
    (status === "ok" || status === "over_cap") &&
    payloadNodes.length >= 20 &&
    (snap?.tf_switch_notice === true || (snap?.tf_switch_notice !== false && !tfAcked))

  const groupKeys = useMemo(() => {
    const seen = new Set<string>()
    const keys: string[] = []
    for (const n of payloadNodes) {
      const k = n.group_key || "u:ungrouped"
      if (seen.has(k)) continue
      seen.add(k)
      keys.push(k)
    }
    return keys
  }, [payloadNodes])

  const visibleNodes = useMemo(() => filterKnowledgeNodes(payloadNodes, query, groupFilter), [payloadNodes, query, groupFilter])
  const selected = payloadNodes.find((n) => n.id === focusId)
  useEffect(() => {
    if (!showCanvas) return
    if (focusId && !payloadNodes.some((n) => n.id === focusId)) setFocusId(null)
    if (groupFilter && !groupKeys.includes(groupFilter)) setGroupFilter("")
  }, [payloadNodes, groupKeys, focusId, groupFilter, showCanvas])

  useEffect(() => {
    const degree = new Map<string, number>()
    for (const n of payloadNodes) degree.set(n.id, 0)
    for (const e of payloadEdges) {
      degree.set(e.a, (degree.get(e.a) || 0) + 1)
      degree.set(e.b, (degree.get(e.b) || 0) + 1)
    }
    for (const r of payloadRelations) {
      degree.set(r.a, (degree.get(r.a) || 0) + 1)
      degree.set(r.b, (degree.get(r.b) || 0) + 1)
    }
    const ids = payloadNodes.map((n) => n.id)
    const radiusById = new Map(ids.map((id) => [id, radiusForDegree(degree.get(id) || 0)]))
    const { w, h } = sizeRef.current
    const previous = new Map(nodesRef.current.map((n) => [n.id, n]))
    nodesRef.current = seedLayoutNodes(ids, w, h, radiusById).map((n) => {
      const old = previous.get(n.id)
      return old ? { ...old, r: n.r } : n
    })
    const tfKeys = new Set(payloadEdges.map((e) => knowledgeGraphPairKey(e.a, e.b)))
    const reasonByPair = new Map<string, string>()
    for (const r of payloadRelations) {
      reasonByPair.set(knowledgeGraphPairKey(r.a, r.b), r.reason)
    }
    const drawn: GraphDrawEdge[] = payloadEdges.map((e) => ({
      a: e.a,
      b: e.b,
      score: e.score,
      reason: reasonByPair.get(knowledgeGraphPairKey(e.a, e.b)),
    }))
    for (const r of payloadRelations) {
      const k = knowledgeGraphPairKey(r.a, r.b)
      if (tfKeys.has(k)) continue
      drawn.push({ a: r.a, b: r.b, score: Math.max(0.08, r.confidence), dashed: true, reason: r.reason })
    }
    edgesRef.current = drawn
    simTicksRef.current = 0
    fittedRef.current = false
    userCameraRef.current = false
  }, [payloadNodes, payloadEdges, payloadRelations])

  useEffect(() => {
    const byId = new Map(payloadNodes.map((n) => [n.id, n]))
    nodesByIdRef.current = byId
    const colors = new Map<string, string>()
    const captions = new Map<string, string>()
    for (const n of payloadNodes) {
      colors.set(n.id, nodeColor(n, colorMode))
      captions.set(n.id, hoverCaption(n, colorMode, labels))
    }
    colorByIdRef.current = colors
    captionByIdRef.current = captions
  }, [payloadNodes, colorMode, labels])

  const openDoc = useCallback((id: string) => {
    setFocusId(id)
    setPanelOpen(true)
    chrome.runtime.sendMessage({ type: "knowledge_graph.open_doc", id }, () => {
      void chrome.runtime.lastError
    })
  }, [])

  const onActionResponse = useCallback((res: { ok?: boolean; sent?: boolean } | undefined) => {
    if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
      setOrganizing(false)
      setRequestError("请求未发送，请确认 CMspark 运行后重试。")
    }
  }, [])

  useEffect(() => {
    if (!organizing) return
    const timer = setTimeout(() => {
      setOrganizing(false)
      setRequestError("尚未收到整理结果，请刷新查看当前状态后重试。")
    }, 35_000)
    return () => clearTimeout(timer)
  }, [organizing])

  const onLlmChange = useCallback((enabled: boolean) => {
    llmEnabledRef.current = enabled
    setLlmEnabled(enabled)
    void writeLlmLabelsPref(enabled)
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", llm_labels: enabled },
      onActionResponse,
    )
  }, [onActionResponse])

  const onRegenerate = useCallback(() => {
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", llm_labels: true, regenerate: true },
      onActionResponse,
    )
  }, [onActionResponse])

  const sendOrganize = useCallback(() => {
    setOrganizing(true)
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", organize: true, llm_labels: llmEnabled },
      onActionResponse,
    )
  }, [llmEnabled, onActionResponse])

  const sendLock = useCallback((groupKey: string, unlock: boolean) => {
    chrome.runtime.sendMessage(
      {
        type: "knowledge_graph.refresh",
        llm_labels: llmEnabled,
        ...(unlock ? { unlock_group: groupKey } : { lock_group: groupKey }),
      },
      onActionResponse,
    )
  }, [llmEnabled, onActionResponse])

  useEffect(() => {
    if (snap?.lock_dissolved === true) setLockNotice(true)
  }, [snap?.lock_dissolved])

  useEffect(() => {
    if (!showTfBanner) return
    // 本会话继续展示；落盘 ack 让关 tab 重开不再出现（AC-6）。
    void writeTfSwitchAck()
    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", ack_tf_switch: true, llm_labels: llmEnabledRef.current }, () => {
      void chrome.runtime.lastError
    })
  }, [showTfBanner])

  const fitView = useCallback(() => {
    const { w, h } = sizeRef.current
    const camera = fitKnowledgeCamera(nodesRef.current, w, h)
    scaleRef.current = camera.scale
    panRef.current = { x: camera.x, y: camera.y }
    fittedRef.current = true
  }, [])
  fitViewRef.current = fitView

  const locateNode = useCallback((id: string) => {
    const n = nodesRef.current.find((node) => node.id === id)
    if (!n) return
    setFocusId(id)
    setPanelOpen(true)
    simTicksRef.current = 999
    userCameraRef.current = true
    scaleRef.current = Math.max(1, scaleRef.current)
    panRef.current = { x: sizeRef.current.w / 2 - n.x * scaleRef.current, y: sizeRef.current.h / 2 - n.y * scaleRef.current }
  }, [])

  const zoom = useCallback((factor: number) => {
    const prev = scaleRef.current
    const next = Math.min(3.2, Math.max(0.08, prev * factor))
    const { w, h } = sizeRef.current
    panRef.current = { x: w / 2 - ((w / 2 - panRef.current.x) / prev) * next, y: h / 2 - ((h / 2 - panRef.current.y) / prev) * next }
    scaleRef.current = next
    userCameraRef.current = true
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const parent = canvas.parentElement
    if (!parent) return
    const resize = () => {
      const rect = parent.getBoundingClientRect()
      const dpr = window.devicePixelRatio || 1
      sizeRef.current = { w: rect.width, h: rect.height }
      canvas.width = Math.max(1, Math.floor(rect.width * dpr))
      canvas.height = Math.max(1, Math.floor(rect.height * dpr))
      canvas.style.width = `${rect.width}px`
      canvas.style.height = `${rect.height}px`
      const ctx = canvas.getContext("2d")
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      // Reflow changes the actual canvas area, not an overlay on the old area.
      fitViewRef.current()
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(parent)
    const draw = () => {
      const ctx = canvas.getContext("2d")
      if (!ctx) return
      const { w, h } = sizeRef.current
      const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
      for (let step = 0; step < (reduceMotion ? 320 : 6) && simTicksRef.current < 320 && nodesRef.current.length > 0; step++) {
        const e = forceLayoutTick(nodesRef.current, edgesRef.current, { width: w, height: h })
        simTicksRef.current++
        if ((e < 0.06 && simTicksRef.current > 50) || simTicksRef.current >= 320) {
          simTicksRef.current = 999
          if (!userCameraRef.current) fitViewRef.current()
        }
      }
      if (!fittedRef.current && !userCameraRef.current) fitViewRef.current()
      ctx.clearRect(0, 0, w, h)
      ctx.fillStyle = G.canvas
      ctx.fillRect(0, 0, w, h)
      ctx.save()
      ctx.translate(panRef.current.x, panRef.current.y)
      ctx.scale(scaleRef.current, scaleRef.current)
      const byId = new Map(nodesRef.current.map((n) => [n.id, n]))
      const active = hoverIdRef.current || focusIdRef.current
      let hot: Set<string> | null = null
      if (active) {
        hot = new Set([active])
        for (const e of edgesRef.current) {
          if (e.a === active) hot.add(e.b)
          if (e.b === active) hot.add(e.a)
        }
      }
      const scale = scaleRef.current
      for (const e of edgesRef.current) {
        const a = byId.get(e.a)
        const b = byId.get(e.b)
        if (!a || !b) continue
        const isHot = hot ? hot.has(e.a) && hot.has(e.b) : false
        ctx.beginPath()
        ctx.moveTo(a.x, a.y)
        ctx.lineTo(b.x, b.y)
        ctx.strokeStyle = hot != null && !isHot ? G.edgeDim : isHot ? G.edgeHot : G.edgeSoft
        ctx.lineWidth = Math.min(1.6, 0.4 + e.score * 0.5) / Math.max(0.6, scale)
        if (e.dashed) ctx.setLineDash([5 / Math.max(0.6, scale), 4 / Math.max(0.6, scale)])
        else ctx.setLineDash([])
        ctx.stroke()
        ctx.setLineDash([])
        if (e.dashed && (hot == null || isHot)) {
          const mx = (a.x + b.x) / 2
          const my = (a.y + b.y) / 2
          ctx.fillStyle = G.labelFocus
          ctx.font = `${9 / Math.max(0.75, Math.min(1.25, scale))}px ${tokens.font}`
          ctx.textAlign = "center"
          ctx.textBaseline = "bottom"
          ctx.fillText(KNOWLEDGE_GRAPH_AI_RELATION, mx, my - 2)
        }
      }
      const labelBoxes: { x: number; y: number; w: number; h: number }[] = []
      // Selected titles take priority; collisions only suppress canvas labels,
      // never the complete accessible knowledge list.
      const drawNodes = [...nodesRef.current].sort((a, b) => Number(b.id === active) - Number(a.id === active))
      for (const n of drawNodes) {
        const isFocus = n.id === focusIdRef.current
        const isHover = n.id === hoverIdRef.current
        const inHot = hot ? hot.has(n.id) : true
        const dimmed = hot != null && !inHot
        const baseColor = colorByIdRef.current.get(n.id) || UNTAGGED_COLOR
        if (isFocus || isHover) {
          ctx.beginPath()
          ctx.arc(n.x, n.y, n.r + 3.5, 0, Math.PI * 2)
          ctx.fillStyle = hexWithAlpha(baseColor, isFocus ? 0.28 : 0.18)
          ctx.fill()
        }
        ctx.beginPath()
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
        ctx.fillStyle = isFocus
          ? lightenHex(baseColor, 0.45)
          : isHover
            ? lightenHex(baseColor, 0.28)
            : dimmed
              ? hexWithAlpha(baseColor, 0.7)
              : baseColor
        ctx.globalAlpha = 1
        ctx.fill()
        ctx.globalAlpha = 1
        {
          ctx.fillStyle = dimmed ? tokens.darkMuted : G.labelFocus
          ctx.font = `${13 / scale}px ${tokens.font}`
          ctx.textAlign = "center"
          ctx.textBaseline = "top"
          const doc = nodesByIdRef.current.get(n.id)
          const cap = shortKnowledgeTitle(doc?.title || "", n.id, nodesRef.current.length <= 20 ? 18 : 12)
          const textWidth = ctx.measureText(cap).width * scale
          const sx = n.x * scale + panRef.current.x
          const sy = (n.y + n.r) * scale + panRef.current.y + 7
          const box = { x: sx - textWidth / 2, y: sy, w: textWidth, h: 17 }
          const overlaps = labelBoxes.some((b) => box.x < b.x + b.w + 8 && box.x + box.w + 8 > b.x && box.y < b.y + b.h + 4 && box.y + box.h + 4 > b.y)
          if ((isFocus || isHover || !overlaps) && box.x >= 2 && box.x + box.w <= w - 2 && sy + 17 < h) {
            labelBoxes.push(box)
            ctx.fillText(cap, n.x, n.y + n.r + 7 / scale)
          }
        }
      }
      ctx.restore()
      rafRef.current = requestAnimationFrame(draw)
    }
    rafRef.current = requestAnimationFrame(draw)
    return () => {
      ro.disconnect()
      cancelAnimationFrame(rafRef.current)
    }
  }, [showCanvas])

  const hitTest = (clientX: number, clientY: number): LayoutNode | null => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const rect = canvas.getBoundingClientRect()
    const scale = Math.max(0.001, scaleRef.current)
    const x = (clientX - rect.left - panRef.current.x) / scale
    const y = (clientY - rect.top - panRef.current.y) / scale
    const pad = HIT_PAD / scale
    let best: LayoutNode | null = null
    let bestD = Infinity
    for (const n of nodesRef.current) {
      const d = Math.hypot(n.x - x, n.y - y)
      if (d <= n.r + pad && d < bestD) {
        best = n
        bestD = d
      }
    }
    return best
  }

  const hitTestEdge = (clientX: number, clientY: number): GraphDrawEdge | null => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const rect = canvas.getBoundingClientRect()
    const scale = Math.max(0.001, scaleRef.current)
    const x = (clientX - rect.left - panRef.current.x) / scale
    const y = (clientY - rect.top - panRef.current.y) / scale
    const byId = new Map(nodesRef.current.map((n) => [n.id, n]))
    const thresh = 6 / scale
    let best: GraphDrawEdge | null = null
    let bestD = thresh
    for (const e of edgesRef.current) {
      if (!e.reason && !e.dashed) continue
      const a = byId.get(e.a)
      const b = byId.get(e.b)
      if (!a || !b) continue
      const dx = b.x - a.x
      const dy = b.y - a.y
      const len2 = dx * dx + dy * dy
      if (len2 < 1) continue
      let t = ((x - a.x) * dx + (y - a.y) * dy) / len2
      t = Math.max(0, Math.min(1, t))
      const px = a.x + t * dx
      const py = a.y + t * dy
      const d = Math.hypot(x - px, y - py)
      if (d < bestD) {
        best = e
        bestD = d
      }
    }
    return best
  }

  const endDrag = (ev?: ReactPointerEvent) => {
    const drag = dragRef.current
    if (drag && drag.id !== "__pan__" && !drag.moved) {
      locateNode(drag.id)
    }
    if (drag && drag.id === "__pan__" && !drag.moved && ev) {
      const edge = hitTestEdge(ev.clientX, ev.clientY)
      if (edge?.reason) {
        setPanelOpen(true)
        setRelationOpen({
          a: edge.a,
          b: edge.b,
          reason: edge.reason,
          confidence: edge.score,
          ai: true,
        })
      }
    }
    if (ev?.target && "releasePointerCapture" in (ev.target as Element)) {
      try {
        ;(ev.target as HTMLElement).releasePointerCapture?.(ev.pointerId)
      } catch {
        /* already released */
      }
    }
    dragRef.current = null
  }

  const onPointerDown = (ev: ReactPointerEvent) => {
    const n = hitTest(ev.clientX, ev.clientY)
    if (n) {
      dragRef.current = { id: n.id, ox: ev.clientX, oy: ev.clientY, moved: false }
      setFocusId(n.id)
      setPanelOpen(true)
      ;(ev.target as HTMLElement).setPointerCapture?.(ev.pointerId)
      return
    }
    setFocusId(null)
    dragRef.current = { id: "__pan__", ox: ev.clientX, oy: ev.clientY, moved: false }
    ;(ev.target as HTMLElement).setPointerCapture?.(ev.pointerId)
  }

  const onPointerMove = (ev: ReactPointerEvent) => {
    const drag = dragRef.current
    if (!drag) {
      const n = hitTest(ev.clientX, ev.clientY)
      hoverIdRef.current = n?.id ?? null
      if (n) {
        setHoverCaptionText(captionByIdRef.current.get(n.id) || "")
      } else {
        const edge = hitTestEdge(ev.clientX, ev.clientY)
        setHoverCaptionText(
          edge?.reason
            ? `${edge.dashed ? KNOWLEDGE_GRAPH_AI_RELATION + " · " : ""}${edge.reason}`
            : "",
        )
      }
      return
    }
    const dx = ev.clientX - drag.ox
    const dy = ev.clientY - drag.oy
    if (Math.abs(dx) + Math.abs(dy) > 2) {
      drag.moved = true
      if (drag.id === "__pan__") userCameraRef.current = true
    }
    drag.ox = ev.clientX
    drag.oy = ev.clientY
    if (drag.id === "__pan__") {
      panRef.current.x += dx
      panRef.current.y += dy
      return
    }
    const n = nodesRef.current.find((x) => x.id === drag.id)
    if (n) {
      n.x += dx / scaleRef.current
      n.y += dy / scaleRef.current
    }
  }

  const onWheel = (ev: ReactWheelEvent) => {
    ev.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const mx = ev.clientX - rect.left
    const my = ev.clientY - rect.top
    const prev = scaleRef.current
    const next = Math.min(3.2, Math.max(0.08, prev * (ev.deltaY > 0 ? 0.92 : 1.08)))
    panRef.current.x = mx - ((mx - panRef.current.x) / prev) * next
    panRef.current.y = my - ((my - panRef.current.y) / prev) * next
    scaleRef.current = next
    userCameraRef.current = true
  }

  const ungroupedKey = groupKeys.find((k) => k === "u:ungrouped" || k === "" || k === "ungrouped")
  const relatedEdges: GraphDrawEdge[] = selected ? [
    ...payloadEdges.map((e) => ({ ...e, reason: payloadRelations.find((r) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))?.reason })),
    ...payloadRelations.filter((r) => !payloadEdges.some((e) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))).map((r) => ({ ...r, score: r.confidence, dashed: true })),
  ].filter((e) => e.a === selected.id || e.b === selected.id) : []

  return (
    <div className="kg-page" style={styles.page}>
      <style>{graphStyles}</style>
      <header className="kg-toolbar" role="toolbar" aria-label={`${KNOWLEDGE_GRAPH_ENTRY_LABEL}工具栏`}>
        <div className="kg-heading"><strong>{KNOWLEDGE_GRAPH_ENTRY_LABEL}</strong><span>{showCanvas ? knowledgeGraphBarMeta(payloadNodes.length, payloadEdges.length, payloadRelations.length) : "浏览知识与关联"}</span></div>
        <KnowledgeGraphColorSwitch mode={colorMode} onChange={setColorMode} />
        <button type="button" onClick={refresh}>刷新图谱</button>
        <button type="button" aria-expanded={panelOpen} onClick={() => setPanelOpen((v) => !v)}>{panelOpen ? "收起列表" : "浏览知识"}</button>
        <details className="kg-ai-options">
          <summary>AI 与分组</summary>
          <div>
            <KnowledgeGraphLlmSwitch enabled={llmEnabled} onChange={onLlmChange} onRegenerate={onRegenerate} />
            {showReorganize ? <KnowledgeGraphReorganizeButton organizing={organizing} disabled={!llmReady} onClick={sendOrganize} /> : null}
            {snap?.stale === true && llmLane ? <KnowledgeGraphStaleBadge /> : null}
          </div>
        </details>
        <button type="button" onClick={() => window.close()} title="关闭此标签页">关闭</button>
      </header>
      <div className="kg-notices">
        {requestError ? <div className="kg-notice" role="alert">{requestError}</div> : null}
        {status !== "ok" ? <KnowledgeGraphStatusView status={status} truncated={truncated} pollExhausted={pollExhausted} error={snap?.error} /> : null}
        {status === "ok" && showOrganizeCta ? <KnowledgeGraphOrganizeCta n={payloadNodes.length} disabled={!llmReady} organizing={organizing} onOrganize={sendOrganize} /> : null}
        {status === "ok" && snap?.organize_error ? <KnowledgeGraphOrganizeErrorBar error={snap.organize_error} onRetry={sendOrganize} /> : null}
        {showTfBanner ? <KnowledgeGraphTfSwitchBanner /> : null}
        {lockNotice ? <div className="kg-notice"><KnowledgeGraphLockDissolvedBanner /><button onClick={() => setLockNotice(false)}>知道了</button></div> : null}
      </div>
      <div className={`kg-workspace ${panelOpen ? "" : "kg-workspace-wide"}`}>
        <section className="kg-map" aria-label="知识关系画布">
          <div className="kg-map-tools">
            <span>实线：内容相似 · 虚线：AI 关联</span>
            <div>
              <button type="button" disabled={!showCanvas} onClick={() => { userCameraRef.current = false; fitView() }}>适应画布</button>
              <button type="button" disabled={!showCanvas} aria-label="放大" onClick={() => zoom(1.25)}>＋</button>
              <button type="button" disabled={!showCanvas} aria-label="缩小" onClick={() => zoom(0.8)}>－</button>
            </div>
          </div>
          <main style={styles.main}>
            {showCanvas ? <canvas ref={canvasRef} data-testid="knowledge-graph-canvas" style={styles.canvas} role="img" tabIndex={0}
              aria-label="知识分布图谱。点击节点查看关联；也可在知识列表搜索并定位。方向键平移，加减号缩放，0 适应画布。"
              onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={(ev) => endDrag(ev)}
              onPointerLeave={() => { hoverIdRef.current = null; setHoverCaptionText("") }}
              onPointerCancel={() => { dragRef.current = null }}
              onWheel={onWheel}
              onKeyDown={(ev) => {
                if (ev.key === "0" || ev.key === "Home") { ev.preventDefault(); userCameraRef.current = false; fitView() }
                if (ev.key === "+" || ev.key === "=" || ev.key === "-") { ev.preventDefault(); zoom(ev.key === "-" ? 0.8 : 1.25) }
                const delta: Record<string, [number, number]> = { ArrowLeft: [40, 0], ArrowRight: [-40, 0], ArrowUp: [0, 40], ArrowDown: [0, -40] }
                if (delta[ev.key]) { ev.preventDefault(); userCameraRef.current = true; panRef.current.x += delta[ev.key][0]; panRef.current.y += delta[ev.key][1] }
                if (ev.key === "Escape") { setFocusId(null); setRelationOpen(null) }
              }}
            /> : <div className="kg-placeholder">知识文档和真实关联将在这里显示</div>}
          </main>
          <div className="kg-map-caption" role="status">
            {hoverCaptionText || (showCanvas && !payloadEdges.length && !payloadRelations.length ? "暂无明确关联，仍可浏览全部知识" : "拖动画布 · 滚轮缩放 · 点击知识查看关联")}
          </div>
        </section>
        {panelOpen ? (
          <aside className="kg-explorer" aria-label="知识浏览">
            <div className="kg-search">
              <label htmlFor="kg-search">浏览知识</label>
              <input id="kg-search" aria-label="搜索知识" placeholder="搜索标题、文件夹…" value={query} onChange={(ev) => setQuery(ev.target.value)} />
              <select aria-label="筛选分组" value={groupFilter} onChange={(ev) => setGroupFilter(ev.target.value)}>
                <option value="">全部分组</option>
                {groupKeys.map((k) => <option key={k} value={k}>{labels[k]?.name || (k === ungroupedKey ? KNOWLEDGE_GRAPH_UNGROUPED_LABEL : k)}</option>)}
              </select>
              <span role="status">{visibleNodes.length} / {payloadNodes.length} 篇知识</span>
            </div>
            {selected ? <section className="kg-selection" aria-label="选中知识">
              <div className="kg-selection-heading"><strong>{selected.title || selected.id}</strong><button aria-label="取消选中知识" onClick={() => setFocusId(null)}>取消</button></div>
              <p>{selected.folder || "未设置文件夹"}</p>
              <button type="button" onClick={() => openDoc(selected.id)}>在知识面板打开</button>
              <h3>相关知识 · {relatedEdges.length}</h3>
              {relatedEdges.length === 0 ? <p>暂无明确关联</p> : relatedEdges.map((edge) => {
                const id = edge.a === selected.id ? edge.b : edge.a
                const other = payloadNodes.find((node) => node.id === id)
                return <div key={id} className="kg-relation">
                  <button type="button" onClick={() => locateNode(id)}>{other?.title || id}</button>
                  <span>{edge.dashed ? "AI 关联" : "内容相似"}</span>
                  {edge.reason ? <p>AI 关联理由：{edge.reason}</p> : null}
                </div>
              })}
            </section> : null}
            {relationOpen ? <section className="kg-selection" aria-label="关联理由" data-testid="kg-relation-reason">
              <strong>{KNOWLEDGE_GRAPH_AI_RELATION}</strong><p>{relationOpen.reason}</p>
              <button type="button" onClick={() => setRelationOpen(null)}>{KNOWLEDGE_GRAPH_REASON_DISMISS}</button>
            </section> : null}
            <div className="kg-document-list" aria-label="知识列表">
              {visibleNodes.map((n) => <button type="button" key={n.id} data-node-id={n.id} aria-pressed={n.id === focusId} onClick={() => locateNode(n.id)}>
                <span className="kg-dot" style={{ background: nodeColor(n, colorMode) }} aria-hidden="true" />
                <span><strong>{n.title || n.id}</strong><small>{n.folder || labels[n.group_key]?.name || KNOWLEDGE_GRAPH_UNGROUPED_LABEL}</small></span>
              </button>)}
              {!visibleNodes.length ? <p>{payloadNodes.length ? "没有匹配的知识。可清空搜索或切换分组。" : "当前没有可浏览的知识。"}</p> : null}
              {(query || groupFilter) ? <button type="button" onClick={() => { setQuery(""); setGroupFilter("") }}>清除筛选</button> : null}
            </div>
            <details className="kg-groups" open={payloadNodes.length <= 19}>
              <summary>分组说明与管理 · {groupKeys.length}</summary>
              {showNoRelations ? <KnowledgeGraphNoRelationsNote /> : null}
              {groupKeys.map((k) => {
                const llmGroup = k.startsWith("l:")
                return <KnowledgeGraphGroupCard key={k} groupKey={k}
                  label={labels[k] || (k === ungroupedKey ? { name: KNOWLEDGE_GRAPH_UNGROUPED_LABEL, ai: false } : undefined)}
                  llmEnabled={llmEnabled} llmLaneGroup={llmGroup}
                  onLock={llmLane && llmGroup ? () => sendLock(k, false) : undefined}
                  onUnlock={llmGroup && labels[k]?.locked === true ? () => sendLock(k, true) : undefined} />
              })}
            </details>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

const styles: Record<string, CSSProperties> = {
  page: { minHeight: "100dvh", height: "100dvh", margin: 0, fontFamily: tokens.font, background: G.canvas, color: tokens.darkText, display: "flex", flexDirection: "column", overflow: "auto" },
  main: { position: "relative", flex: 1, minHeight: 280 },
  canvas: { width: "100%", height: "100%", position: "absolute", inset: 0, display: "block", cursor: "grab", touchAction: "none" },
}

const graphStyles = `
  .kg-page * { box-sizing: border-box; }
  .kg-page button, .kg-page input, .kg-page select, .kg-page summary { font: inherit; font-size: 13px; }
  .kg-page button { min-height: 32px; border: 1px solid ${tokens.darkBorder}; background: transparent; color: ${tokens.darkText}; border-radius: 8px; padding: 5px 10px; cursor: pointer; }
  .kg-page button:disabled { opacity: .45; cursor: not-allowed; }
  .kg-page button:hover:not(:disabled), .kg-page button[aria-pressed=true] { background: ${tokens.darkElevated}; }
  .kg-page :focus-visible { outline: 2px solid ${tokens.darkMuted}; outline-offset: 2px; }
  .kg-page summary { cursor: pointer; padding: 8px 0; }
  .kg-toolbar { padding: 16px 20px; border-bottom: 1px solid ${tokens.darkBorder}; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; flex-shrink: 0; }
  .kg-heading { display: flex; flex-direction: column; gap: 4px; margin-right: auto; }
  .kg-heading strong { font-size: 18px; }
  .kg-heading span, .kg-search>span { color: ${tokens.darkMuted}; font-size: 12px; }
  .kg-ai-options[open] { flex-basis: 100%; order: 2; }
  .kg-ai-options>div { display: flex; flex-wrap: wrap; gap: 12px; padding: 8px 0; }
  .kg-notices { flex-shrink: 0; max-height: 30dvh; overflow: auto; background: ${tokens.darkElevated}; }
  .kg-notice { padding: 12px 16px; font-size: 13px; }
  .kg-workspace { display: grid; grid-template-columns: minmax(0,1fr) 320px; flex: 1; min-height: 400px; }
  .kg-workspace-wide { grid-template-columns: minmax(0,1fr); }
  .kg-map { display: flex; flex-direction: column; min-width: 0; min-height: 360px; }
  .kg-map-tools { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px; padding: 12px 16px; }
  .kg-map-tools span, .kg-map-caption { color: ${tokens.darkMuted}; font-size: 12px; line-height: 1.5; }
  .kg-map-tools>div { display: flex; gap: 6px; }
  .kg-map-caption { padding: 8px 16px 12px; min-height: 38px; overflow-wrap: anywhere; }
  .kg-placeholder { height: 100%; display: grid; place-items: center; color: ${tokens.darkMuted}; padding: 24px; text-align: center; }
  .kg-explorer { overflow: auto; border-left: 1px solid ${tokens.darkBorder}; padding: 16px; min-width: 0; }
  .kg-search { display: grid; gap: 10px; margin-bottom: 16px; position: sticky; top: 0; z-index: 1; background: ${G.canvas}; padding-bottom: 8px; }
  .kg-search label { font-size: 14px; font-weight: 600; }
  .kg-search input, .kg-search select { width: 100%; min-width: 0; min-height: 36px; background: ${tokens.darkElevated}; color: ${tokens.darkText}; border: 1px solid ${tokens.darkBorder}; border-radius: 8px; padding: 8px; }
  .kg-document-list>button { width: 100%; display: flex; gap: 10px; align-items: center; text-align: left; border-color: transparent; padding: 10px 8px; }
  .kg-document-list strong { font-size: 13px; font-weight: 500; overflow-wrap: anywhere; }
  .kg-document-list small { display: block; color: ${tokens.darkMuted}; font-size: 12px; margin-top: 4px; overflow-wrap: anywhere; }
  .kg-document-list p, .kg-selection p { font-size: 13px; line-height: 1.6; color: ${tokens.darkMuted}; overflow-wrap: anywhere; }
  .kg-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
  .kg-selection { padding: 12px; border: 1px solid ${tokens.darkBorder}; border-radius: 10px; margin-bottom: 12px; }
  .kg-selection-heading { display: flex; align-items: start; gap: 8px; }
  .kg-selection-heading strong { flex: 1; min-width: 0; overflow-wrap: anywhere; font-size: 14px; }
  .kg-selection h3 { font-size: 13px; margin: 16px 0 8px; }
  .kg-relation { margin-top: 10px; }
  .kg-relation>button { display: block; text-align: left; overflow-wrap: anywhere; max-width: 100%; }
  .kg-relation>span { display: block; font-size: 12px; color: ${tokens.darkMuted}; margin-top: 4px; }
  .kg-groups { margin-top: 16px; border-top: 1px solid ${tokens.darkBorder}; }
  @media(max-width: 759px) {
    .kg-toolbar { padding: 12px; gap: 8px; }
    .kg-heading { flex-basis: 100%; }
    .kg-workspace, .kg-workspace-wide { display: flex; flex-direction: column; flex: none; min-height: 0; }
    .kg-map { height: 440px; flex-shrink: 0; }
    .kg-explorer { border-left: none; border-top: 1px solid ${tokens.darkBorder}; overflow: visible; }
  }
`

```

### FULL chrome-extension/src/knowledge-graph/copy.ts
```
// #296 知识分布图谱 — 用户可见文案常量（spec AC-3/AC-5 / §7 名词）。
// 「图谱」仅限本视图；视图内分组用语只用「分组」。

export const KNOWLEDGE_GRAPH_ENTRY_LABEL = "分布图谱"
export const KNOWLEDGE_GRAPH_TOO_FEW_COPY = "知识库暂无可展示的文档，请先在知识面板导入或保存知识"
export const KNOWLEDGE_GRAPH_OVER_CAP_COPY =
  "超过 200 篇，只画标题字典序前 200 篇；仅这 200 篇参与分组与着色"
export const KNOWLEDGE_GRAPH_REBUILDING_COPY = "图谱索引重建中…"
export const KNOWLEDGE_GRAPH_REBUILD_TIMEOUT_COPY = "索引重建超时，请手动刷新"
/** #356: knowledge.graph 被门拒/出错映射的可见态（错误详情由调用方折叠展示）。 */
export const KNOWLEDGE_GRAPH_ERROR_COPY = "图谱加载失败，请重试刷新"
/** #356: error 详情折叠开关文案（内部错误原文不直接铺开）。 */
export const KNOWLEDGE_GRAPH_ERROR_DETAIL_LABEL = "技术详情"
export const KNOWLEDGE_GRAPH_AI_BADGE = "AI 生成"
export const KNOWLEDGE_GRAPH_UNGROUPED_LABEL = "未分组"
export const KNOWLEDGE_GRAPH_COLOR_GROUP = "按分组"
export const KNOWLEDGE_GRAPH_COLOR_FOLDER = "按文件夹"
export const KNOWLEDGE_GRAPH_LLM_TOGGLE = "AI 分组命名"
export const KNOWLEDGE_GRAPH_REGENERATE = "重新生成"

/** #427：LLM 整理 lane 上界（= KNOWLEDGE_CLUSTER_MIN_DOCS−1；画布闸已解绑）。 */
export const KNOWLEDGE_GRAPH_LLM_LANE_MAX = 19
export const KNOWLEDGE_GRAPH_REORGANIZE = "重新整理"
export const KNOWLEDGE_GRAPH_ORGANIZING = "整理中…"
export const KNOWLEDGE_GRAPH_STALE_BADGE = "语料已变化 · 可重新整理"
export const KNOWLEDGE_GRAPH_NO_RELATIONS = "AI 未发现明确关联"
export const KNOWLEDGE_GRAPH_TF_SWITCH_BANNER = "知识已满 20 篇，分组改按统计聚类（更稳定）"
export const KNOWLEDGE_GRAPH_LOCK_DISSOLVED = "不足两篇的锁定分组已解散"
export const KNOWLEDGE_GRAPH_ORGANIZE_RETRY = "重试"
export const KNOWLEDGE_GRAPH_AI_RELATION = "AI 关联"
export const KNOWLEDGE_GRAPH_LOCK_GROUP = "保留这版分组"
export const KNOWLEDGE_GRAPH_UNLOCK_GROUP = "解锁"
export const KNOWLEDGE_GRAPH_REASON_DISMISS = "关闭"
/** 与 distill 同源：无 LLM 配置时 CTA 禁用 tooltip。 */
export const KNOWLEDGE_GRAPH_LLM_NOT_CONFIGURED = "未配置 LLM"

export function knowledgeGraphOrganizeCta(n: number): string {
  return `让 AI 整理现有 ${n} 篇`
}

/** 2–19 且 status ok → LLM 整理 lane（CTA / 重新整理）。 */
export function isKnowledgeGraphLlmLane(nodeCount: number): boolean {
  return nodeCount >= 2 && nodeCount <= KNOWLEDGE_GRAPH_LLM_LANE_MAX
}

/** 工具栏边计数：有 AI 关联时拆 TF/AI，否则保持「N 点 · M 边」。 */
export function knowledgeGraphBarMeta(nodeCount: number, tfEdges: number, aiRelations: number): string {
  if (aiRelations > 0) {
    return `${nodeCount} 篇知识 · ${tfEdges} 条相似关联 · ${aiRelations} 条 AI 关联`
  }
  return `${nodeCount} 篇知识 · ${tfEdges} 条相似关联`
}

export type KnowledgeGraphStatus = "ok" | "too_few" | "over_cap" | "rebuilding" | "error"

/** Banner copy for the honest states; ok → no banner. */
export function graphBannerCopy(
  status: KnowledgeGraphStatus,
  _truncated?: boolean,
): string | null {
  if (status === "too_few") return KNOWLEDGE_GRAPH_TOO_FEW_COPY
  if (status === "rebuilding") return KNOWLEDGE_GRAPH_REBUILDING_COPY
  if (status === "over_cap") return KNOWLEDGE_GRAPH_OVER_CAP_COPY
  if (status === "error") return KNOWLEDGE_GRAPH_ERROR_COPY
  return null
}

/** too_few / rebuilding / error must not paint an empty graph pretending structure. */
export function shouldRenderGraphCanvas(status: KnowledgeGraphStatus): boolean {
  return status === "ok" || status === "over_cap"
}

```

### FULL chrome-extension/src/knowledge-graph/explorer.ts
```
import type { LayoutNode } from "../thread-graph/force-layout"
import type { KnowledgeGraphNode } from "./wire"

/** List filters never remove data from the graph or change its relationships. */
export function filterKnowledgeNodes(nodes: KnowledgeGraphNode[], query: string, group: string): KnowledgeGraphNode[] {
  const term = query.trim().toLocaleLowerCase()
  return nodes.filter((node) =>
    (!group || (node.group_key || "u:ungrouped") === group) &&
    (!term || `${node.title}\n${node.folder}\n${node.id}`.toLocaleLowerCase().includes(term)),
  )
}

/** Fit the actual canvas, including room for labels; tiny viewports may zoom out. */
export function fitKnowledgeCamera(nodes: Pick<LayoutNode, "x" | "y" | "r">[], w: number, h: number) {
  if (!nodes.length || w <= 0 || h <= 0) return { scale: 1, x: 0, y: 0 }
  const minX = Math.min(...nodes.map((n) => n.x - n.r))
  const maxX = Math.max(...nodes.map((n) => n.x + n.r))
  const minY = Math.min(...nodes.map((n) => n.y - n.r))
  const maxY = Math.max(...nodes.map((n) => n.y + n.r))
  const scale = Math.min(1.6, Math.max(1, w - 96) / Math.max(40, maxX - minX), Math.max(1, h - 88) / Math.max(40, maxY - minY))
  return { scale, x: w / 2 - ((minX + maxX) / 2) * scale, y: h / 2 - ((minY + maxY) / 2) * scale }
}

export function shortKnowledgeTitle(title: string, id: string, limit = 18): string {
  const chars = Array.from(title.trim() || id)
  return chars.length > limit ? `${chars.slice(0, limit).join("")}…` : chars.join("")
}

```

### FULL chrome-extension/src/knowledge-graph/wire.ts
```
// #296 knowledge.graph wire contract (spec §5). UI-only: parse + request builder.
// Server lane owns computation; this module is fail-closed on unknown shapes.

import { isKnowledgeGraphLlmLane, type KnowledgeGraphStatus } from "./copy"

export type KnowledgeGraphNode = {
  id: string
  title: string
  group_key: string
  folder: string
}

export type KnowledgeGraphEdge = {
  a: string
  b: string
  score: number
}

export type KnowledgeGraphLabel = {
  name: string
  summary?: string
  ai: boolean
  /** #427：锁 overlay 成员（可选；旧帧无此字段）。 */
  locked?: boolean
}

export type KnowledgeGraphRelation = {
  a: string
  b: string
  reason: string
  confidence: number
  ai: true
}

export type KnowledgeGraphPayload = {
  status: KnowledgeGraphStatus
  truncated: boolean
  nodes: KnowledgeGraphNode[]
  edges: KnowledgeGraphEdge[]
  labels: Record<string, KnowledgeGraphLabel>
  /** #356: error 态的服务端错误说明（可选；展示用，不进 parse 硬门）。 */
  error?: string
  /** #427：LLM 洞察边（仅 2–19 lane；旧帧/≥20 无此字段）。 */
  relations?: KnowledgeGraphRelation[]
  /** #427：无 LLM 配置时为 false；缺省视为 true（旧 companion 不砖 CTA）。 */
  llm_ready?: boolean
  /** #427：organize 失败文案；status 仍 ok，画布保留。 */
  organize_error?: string
  /** #427：graph_llm 指纹已漂。 */
  stale?: boolean
  /** #427：跨 20 一次性 banner。 */
  tf_switch_notice?: boolean
  /** #427：锁组缩到 <2 解散。 */
  lock_dissolved?: boolean
  /**
   * #427 pi MAJOR-1：graph_llm 区存在即为 true（空组+空关联也算整理过）。
   * 无缓存帧省略或 false。
   */
  organized?: boolean
  /** #490: actual server job state; initial graph response is not completion. */
  organizing?: boolean
}

const STATUSES = new Set<KnowledgeGraphStatus>(["ok", "too_few", "over_cap", "rebuilding", "error"])

function asString(v: unknown): string {
  return typeof v === "string" ? v : ""
}

function parseNode(raw: unknown): KnowledgeGraphNode | null {
  if (!raw || typeof raw !== "object") return null
  const n = raw as Record<string, unknown>
  const id = asString(n.id)
  if (!id) return null
  return {
    id,
    title: asString(n.title),
    group_key: asString(n.group_key),
    folder: asString(n.folder),
  }
}

function parseEdge(raw: unknown): KnowledgeGraphEdge | null {
  if (!raw || typeof raw !== "object") return null
  const e = raw as Record<string, unknown>
  const a = asString(e.a)
  const b = asString(e.b)
  if (!a || !b) return null
  const score = typeof e.score === "number" && Number.isFinite(e.score) ? e.score : 0
  return { a, b, score }
}

function parseLabel(raw: unknown): KnowledgeGraphLabel | null {
  if (!raw || typeof raw !== "object") return null
  const l = raw as Record<string, unknown>
  const name = asString(l.name)
  if (!name) return null
  const out: KnowledgeGraphLabel = { name, ai: l.ai === true }
  if (typeof l.summary === "string" && l.summary) out.summary = l.summary
  if (l.locked === true) out.locked = true
  return out
}

function parseRelation(raw: unknown): KnowledgeGraphRelation | null {
  if (!raw || typeof raw !== "object") return null
  const r = raw as Record<string, unknown>
  const a = asString(r.a)
  const b = asString(r.b)
  const reason = asString(r.reason).trim()
  if (!a || !b || a === b || !reason) return null
  const confidence =
    typeof r.confidence === "number" && Number.isFinite(r.confidence)
      ? Math.min(1, Math.max(0, r.confidence))
      : 0
  return { a, b, reason, confidence, ai: true }
}

/** 无向对键，TF 边与 relation 对齐用。 */
export function knowledgeGraphPairKey(a: string, b: string): string {
  return a < b ? `${a}\0${b}` : `${b}\0${a}`
}

/** 已整理过（含合法空结果）→ 不再出 CTA。 */
export function hasKnowledgeGraphLlmCache(p: KnowledgeGraphPayload): boolean {
  if (p.organized === true) return true
  if ((p.relations?.length ?? 0) > 0) return true
  return p.nodes.some((n) => (n.group_key || "").startsWith("l:"))
}

/** App 层 CTA/散点/虚线门（pi NIT-2：可测组合，不挂 chrome）。 */
export function knowledgeGraphViewModel(p: KnowledgeGraphPayload | null | undefined): {
  llmLane: boolean
  hasCache: boolean
  showOrganizeCta: boolean
  showReorganize: boolean
  showNoRelations: boolean
  relationsToDraw: KnowledgeGraphRelation[]
} {
  if (!p) {
    return {
      llmLane: false,
      hasCache: false,
      showOrganizeCta: false,
      showReorganize: false,
      showNoRelations: false,
      relationsToDraw: [],
    }
  }
  const llmLane = p.status === "ok" && isKnowledgeGraphLlmLane(p.nodes.length)
  const hasCache = hasKnowledgeGraphLlmCache(p)
  const rel = llmLane && Array.isArray(p.relations) ? p.relations : []
  return {
    llmLane,
    hasCache,
    showOrganizeCta: llmLane && !hasCache,
    showReorganize: llmLane && hasCache,
    showNoRelations: llmLane && hasCache && rel.length === 0,
    relationsToDraw: rel,
  }
}

export function parseKnowledgeGraphPayload(raw: unknown): KnowledgeGraphPayload | null {
  if (!raw || typeof raw !== "object") return null
  const o = raw as Record<string, unknown>
  if (typeof o.status !== "string" || !STATUSES.has(o.status as KnowledgeGraphStatus)) return null
  const nodesIn = Array.isArray(o.nodes) ? o.nodes : []
  const edgesIn = Array.isArray(o.edges) ? o.edges : []
  const labelsIn = o.labels && typeof o.labels === "object" ? (o.labels as Record<string, unknown>) : {}
  const nodes: KnowledgeGraphNode[] = []
  for (const n of nodesIn) {
    const p = parseNode(n)
    if (p) nodes.push(p)
  }
  const edges: KnowledgeGraphEdge[] = []
  for (const e of edgesIn) {
    const p = parseEdge(e)
    if (p) edges.push(p)
  }
  const labels: Record<string, KnowledgeGraphLabel> = {}
  for (const [k, v] of Object.entries(labelsIn)) {
    const p = parseLabel(v)
    if (p) labels[k] = p
  }
  const relationsIn = Array.isArray(o.relations) ? o.relations : null
  const relations: KnowledgeGraphRelation[] = []
  if (relationsIn) {
    for (const r of relationsIn) {
      const p = parseRelation(r)
      if (p) relations.push(p)
    }
  }
  return {
    status: o.status as KnowledgeGraphStatus,
    truncated: o.truncated === true,
    nodes,
    edges,
    labels,
    ...(typeof o.error === "string" && o.error ? { error: o.error } : {}),
    ...(relationsIn ? { relations } : {}),
    ...(typeof o.llm_ready === "boolean" ? { llm_ready: o.llm_ready } : {}),
    ...(typeof o.organize_error === "string" && o.organize_error
      ? { organize_error: o.organize_error }
      : {}),
    ...(o.stale === true ? { stale: true } : {}),
    ...(typeof o.tf_switch_notice === "boolean" ? { tf_switch_notice: o.tf_switch_notice } : {}),
    ...(o.lock_dissolved === true ? { lock_dissolved: true } : {}),
    ...(o.organized === true ? { organized: true } : {}),
    ...(typeof o.organizing === "boolean" ? { organizing: o.organizing } : {}),
  }
}

export function mockKnowledgeGraphPayload(
  partial: Partial<KnowledgeGraphPayload> & Pick<KnowledgeGraphPayload, "status">,
): KnowledgeGraphPayload {
  return {
    status: partial.status,
    truncated: partial.truncated === true,
    nodes: partial.nodes ? [...partial.nodes] : [],
    edges: partial.edges ? [...partial.edges] : [],
    labels: partial.labels ? { ...partial.labels } : {},
    ...(typeof partial.error === "string" && partial.error ? { error: partial.error } : {}),
    ...(partial.relations ? { relations: [...partial.relations] } : {}),
    ...(typeof partial.llm_ready === "boolean" ? { llm_ready: partial.llm_ready } : {}),
    ...(typeof partial.organize_error === "string" && partial.organize_error
      ? { organize_error: partial.organize_error }
      : {}),
    ...(partial.stale === true ? { stale: true } : {}),
    ...(typeof partial.tf_switch_notice === "boolean"
      ? { tf_switch_notice: partial.tf_switch_notice }
      : {}),
    ...(partial.lock_dissolved === true ? { lock_dissolved: true } : {}),
    ...(partial.organized === true ? { organized: true } : {}),
    ...(typeof partial.organizing === "boolean" ? { organizing: partial.organizing } : {}),
  }
}

export type KnowledgeGraphRequest = {
  type: "knowledge.graph"
  llm_labels?: true
  regen_labels?: true
  id?: string
  organize?: true
  user_gesture?: true
  lock_group?: string
  unlock_group?: string
  ack_tf_switch?: true
}

export function buildKnowledgeGraphRequest(opts: {
  llmLabels: boolean
  regenerate?: boolean
  /** #374: 请求 id（companion 对响应回带 id，error 帧据此精确关联）。可选，缺省不带。 */
  id?: string
  /** #427：手动整理。与 user_gesture 成对。 */
  organize?: boolean
  lockGroup?: string
  unlockGroup?: string
  ackTfSwitch?: boolean
}): KnowledgeGraphRequest {
  // Wire 契约权威在服务端（#296 server lane）：强制重生成字段是 regen_labels。
  const req: KnowledgeGraphRequest = { type: "knowledge.graph" }
  if (opts.id) req.id = opts.id
  if (opts.llmLabels) req.llm_labels = true
  if (opts.regenerate) req.regen_labels = true
  if (opts.organize) {
    req.organize = true
    req.user_gesture = true
  }
  if (opts.lockGroup) {
    req.lock_group = opts.lockGroup
    req.user_gesture = true
  }
  if (opts.unlockGroup) {
    req.unlock_group = opts.unlockGroup
    req.user_gesture = true
  }
  if (opts.ackTfSwitch) {
    req.ack_tf_switch = true
    req.user_gesture = true
  }
  return req
}

```

### FULL chrome-extension/tests/knowledge-graph-explorer.test.ts
```
import test from "node:test"
import assert from "node:assert/strict"
import { filterKnowledgeNodes, fitKnowledgeCamera, shortKnowledgeTitle } from "../src/knowledge-graph/explorer"
import { parseKnowledgeGraphPayload } from "../src/knowledge-graph/wire"

test("knowledge search intersects group and preserves original graph data", () => {
  const nodes = [
    { id: "one", title: "发布流程", folder: "DevOps", group_key: "c:release" },
    { id: "two", title: "运行手册", folder: "DevOps", group_key: "" },
  ]
  assert.deepEqual(filterKnowledgeNodes(nodes, " devops ", "c:release"), [nodes[0]])
  assert.deepEqual(filterKnowledgeNodes(nodes, "", "u:ungrouped"), [nodes[1]])
  assert.deepEqual(filterKnowledgeNodes(nodes, "不存在", ""), [])
  assert.equal(nodes.length, 2)
  assert.deepEqual(filterKnowledgeNodes([], "", ""), [])
})

test("camera fits sparse extremes on narrow and wide canvases without an artificial minimum zoom", () => {
  const nodes = [{ x: -1200, y: -700, r: 8 }, { x: 2400, y: 1800, r: 10 }]
  for (const [w, h] of [[320, 280], [1000, 800]]) {
    const camera = fitKnowledgeCamera(nodes, w, h)
    for (const n of nodes) {
      assert.ok((n.x - n.r) * camera.scale + camera.x >= 0)
      assert.ok((n.x + n.r) * camera.scale + camera.x <= w)
      assert.ok((n.y - n.r) * camera.scale + camera.y >= 0)
      assert.ok((n.y + n.r) * camera.scale + camera.y <= h)
    }
  }
  assert.deepEqual(fitKnowledgeCamera([], 320, 280), { scale: 1, x: 0, y: 0 })
  const one = fitKnowledgeCamera([{ x: 800, y: 600, r: 5 }], 320, 280)
  assert.equal(800 * one.scale + one.x, 160)
  assert.equal(600 * one.scale + one.y, 140)
})

test("canvas titles truncate whole Unicode code points and fall back to document identity", () => {
  assert.equal(shortKnowledgeTitle(" 😀知识流程 ", "id", 3), "😀知识…")
  assert.equal(shortKnowledgeTitle("", "knowledge-id"), "knowledge-id")
  assert.equal(shortKnowledgeTitle("发布流程", "id"), "发布流程")
})

test("job state is optional for old servers and false survives parsing", () => {
  const payload = { status: "ok", nodes: [], edges: [], labels: {}, truncated: false }
  assert.equal(parseKnowledgeGraphPayload(payload)?.organizing, undefined)
  assert.equal(parseKnowledgeGraphPayload({ ...payload, organizing: true })?.organizing, true)
  assert.equal(parseKnowledgeGraphPayload({ ...payload, organizing: false })?.organizing, false)
  assert.equal(parseKnowledgeGraphPayload({ ...payload, organizing: "false" })?.organizing, undefined)
})

```

### FULL chrome-extension/tests/knowledge-graph-view.test.ts
```
import test from "node:test"
import assert from "node:assert/strict"
import { createElement } from "react"
import { renderToStaticMarkup } from "react-dom/server"
import { readdirSync, readFileSync, statSync } from "node:fs"
import { join } from "node:path"

// #296 知识分布图谱视图 — 扩展清单（spec §8）
// Spec: docs/superpowers/specs/2026-09-04-knowledge-graph-view-design.md

import {
  KNOWLEDGE_GRAPH_AI_BADGE,
  KNOWLEDGE_GRAPH_COLOR_FOLDER,
  KNOWLEDGE_GRAPH_COLOR_GROUP,
  KNOWLEDGE_GRAPH_ENTRY_LABEL,
  KNOWLEDGE_GRAPH_ERROR_COPY,
  KNOWLEDGE_GRAPH_ERROR_DETAIL_LABEL,
  KNOWLEDGE_GRAPH_OVER_CAP_COPY,
  KNOWLEDGE_GRAPH_REBUILDING_COPY,
  KNOWLEDGE_GRAPH_REGENERATE,
  KNOWLEDGE_GRAPH_TOO_FEW_COPY,
  KNOWLEDGE_GRAPH_UNGROUPED_LABEL,
  KNOWLEDGE_GRAPH_AI_RELATION,
  KNOWLEDGE_GRAPH_LLM_LANE_MAX,
  KNOWLEDGE_GRAPH_LLM_NOT_CONFIGURED,
  KNOWLEDGE_GRAPH_LOCK_DISSOLVED,
  KNOWLEDGE_GRAPH_LOCK_GROUP,
  KNOWLEDGE_GRAPH_NO_RELATIONS,
  KNOWLEDGE_GRAPH_ORGANIZE_RETRY,
  KNOWLEDGE_GRAPH_REORGANIZE,
  KNOWLEDGE_GRAPH_STALE_BADGE,
  KNOWLEDGE_GRAPH_TF_SWITCH_BANNER,
  KNOWLEDGE_GRAPH_UNLOCK_GROUP,
  graphBannerCopy,
  isKnowledgeGraphLlmLane,
  knowledgeGraphBarMeta,
  knowledgeGraphOrganizeCta,
  shouldRenderGraphCanvas,
} from "../src/knowledge-graph/copy"
import {
  buildKnowledgeGraphRequest,
  hasKnowledgeGraphLlmCache,
  knowledgeGraphPairKey,
  knowledgeGraphViewModel,
  mockKnowledgeGraphPayload,
  parseKnowledgeGraphPayload,
  type KnowledgeGraphPayload,
} from "../src/knowledge-graph/wire"
import {
  hoverCaption,
  isUngroupedKey,
  nodeColor,
  nodeColorKey,
} from "../src/knowledge-graph/coloring"
import { UNTAGGED_COLOR } from "../src/thread-graph/tag-colors"
import {
  KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
  parseLlmLabelsPref,
} from "../src/knowledge-graph/llm-pref"
import { groupCardModel } from "../src/knowledge-graph/labels"
import {
  KnowledgeGraphColorSwitch,
  KnowledgeGraphEntryButton,
  KnowledgeGraphGroupCard,
  KnowledgeGraphLlmSwitch,
  KnowledgeGraphLockDissolvedBanner,
  KnowledgeGraphNoRelationsNote,
  KnowledgeGraphOrganizeCta,
  KnowledgeGraphOrganizeErrorBar,
  KnowledgeGraphReorganizeButton,
  KnowledgeGraphStaleBadge,
  KnowledgeGraphStatusView,
  KnowledgeGraphTfSwitchBanner,
} from "../src/knowledge-graph/chrome"

const SRC_ROOT = join(process.cwd(), "src")

function walkSource(dir: string): string[] {
  const out: string[] = []
  for (const name of readdirSync(dir)) {
    const full = join(dir, name)
    if (statSync(full).isDirectory()) out.push(...walkSource(full))
    else if (/\.(ts|tsx)$/.test(name)) out.push(full)
  }
  return out
}

// --- 三态诚实文案（AC-3 / AC-5） ---

test("copy pins: too_few / over_cap / rebuilding 逐字（AC-3/AC-5）", () => {
  assert.equal(KNOWLEDGE_GRAPH_TOO_FEW_COPY, "知识库暂无可展示的文档，请先在知识面板导入或保存知识")
  assert.equal(
    KNOWLEDGE_GRAPH_OVER_CAP_COPY,
    "超过 200 篇，只画标题字典序前 200 篇；仅这 200 篇参与分组与着色",
  )
  assert.equal(KNOWLEDGE_GRAPH_REBUILDING_COPY, "图谱索引重建中…")
  assert.equal(KNOWLEDGE_GRAPH_ENTRY_LABEL, "分布图谱")
})

test("graphBannerCopy + shouldRenderGraphCanvas: 三态诚实，不渲染空图假装有结构", () => {
  assert.equal(graphBannerCopy("too_few"), KNOWLEDGE_GRAPH_TOO_FEW_COPY)
  assert.equal(shouldRenderGraphCanvas("too_few"), false)

  assert.equal(graphBannerCopy("rebuilding"), KNOWLEDGE_GRAPH_REBUILDING_COPY)
  assert.equal(shouldRenderGraphCanvas("rebuilding"), false)

  assert.equal(graphBannerCopy("over_cap"), KNOWLEDGE_GRAPH_OVER_CAP_COPY)
  assert.equal(graphBannerCopy("over_cap", true), KNOWLEDGE_GRAPH_OVER_CAP_COPY)
  assert.equal(shouldRenderGraphCanvas("over_cap"), true)

  assert.equal(graphBannerCopy("ok"), null)
  assert.equal(shouldRenderGraphCanvas("ok"), true)
})

// --- #356: error 帧映射为可见态（不再无限「图谱索引重建中…」） ---

test("#356: error 态有 banner 且不渲染画布", () => {
  assert.equal(graphBannerCopy("error"), KNOWLEDGE_GRAPH_ERROR_COPY)
  assert.equal(shouldRenderGraphCanvas("error"), false)
})

test("#356: wire 解析 error 态快照（fail-closed 名单含 error；error 文本可选透传）", () => {
  const parsed = parseKnowledgeGraphPayload({
    status: "error",
    truncated: false,
    nodes: [],
    edges: [],
    labels: {},
    error: "knowledge.graph is panel-only (Side Panel knowledge panel)",
  })
  assert.ok(parsed, "error 是合法 status")
  assert.equal(parsed!.status, "error")
  assert.equal(parsed!.error, "knowledge.graph is panel-only (Side Panel knowledge panel)")
  // 无 error 字段也可解析（旧 companion / 手写快照）
  const bare = parseKnowledgeGraphPayload(mockKnowledgeGraphPayload({ status: "error" }))
  assert.ok(bare && bare.status === "error" && bare.error === undefined)
})

test("#356: StatusView error 态渲染通用 banner，内部错误原文折叠进详情不铺开", () => {
  const html = renderToStaticMarkup(
    createElement(KnowledgeGraphStatusView, {
      status: "error",
      truncated: false,
      error: "knowledge.graph is panel-only",
    }),
  )
  assert.ok(html.includes(KNOWLEDGE_GRAPH_ERROR_COPY), html)
  // 通用文案直出；内部英文原文只在 <details> 折叠内（不 inline 铺开）
  assert.ok(html.includes("<details"), "错误详情折叠")
  assert.ok(html.includes(KNOWLEDGE_GRAPH_ERROR_DETAIL_LABEL), "折叠开关文案")
  const inline = html.split("<details")[0]
  assert.ok(!inline.includes("knowledge.graph is panel-only"), "详情原文不得 inline 铺开")
  // 无详情时只渲染 banner（无折叠块）
  const bare = renderToStaticMarkup(
    createElement(KnowledgeGraphStatusView, { status: "error", truncated: false }),
  )
  assert.ok(bare.includes(KNOWLEDGE_GRAPH_ERROR_COPY), bare)
  assert.ok(!bare.includes("<details"), "无详情不渲染折叠块")
})

test("KnowledgeGraphStatusView 真渲染三态文案", () => {
  const tooFew = renderToStaticMarkup(
    createElement(KnowledgeGraphStatusView, { status: "too_few", truncated: false }),
  )
  assert.ok(tooFew.includes("知识库暂无可展示的文档"), tooFew)
  assert.ok(!tooFew.includes("簇"), "视图内不得出现「簇」")

  const over = renderToStaticMarkup(
    createElement(KnowledgeGraphStatusView, { status: "over_cap", truncated: true }),
  )
  assert.ok(over.includes("超过 200 篇，只画标题字典序前 200 篇"), over)
  assert.ok(over.includes("仅这 200 篇参与分组与着色"), over)

  const rebuilding = renderToStaticMarkup(
    createElement(KnowledgeGraphStatusView, { status: "rebuilding", truncated: false }),
  )
  assert.ok(rebuilding.includes("图谱索引重建中…"), rebuilding)

  const ok = renderToStaticMarkup(
    createElement(KnowledgeGraphStatusView, { status: "ok", truncated: false }),
  )
  assert.equal(ok, "")
})

// --- 着色模式（AC-2） ---

test("着色：未分组灰色；按分组 / 按文件夹切 key", () => {
  assert.equal(isUngroupedKey(""), true)
  assert.equal(isUngroupedKey("u:ungrouped"), true)
  assert.equal(isUngroupedKey("ungrouped"), true)
  assert.equal(isUngroupedKey("c:abc"), false)

  const grouped = { id: "d1", title: "退款政策", group_key: "c:g1", folder: "政策/2025" }
  const lone = { id: "d2", title: "杂记", group_key: "u:ungrouped", folder: "" }

  assert.equal(nodeColorKey(grouped, "group"), "c:g1")
  assert.equal(nodeColorKey(grouped, "folder"), "政策/2025")
  assert.equal(nodeColorKey(lone, "group"), null)
  assert.equal(nodeColorKey(lone, "folder"), null)

  assert.equal(nodeColor(lone, "group"), UNTAGGED_COLOR)
  assert.equal(nodeColor(lone, "folder"), UNTAGGED_COLOR)
  assert.notStrictEqual(nodeColor(grouped, "group"), UNTAGGED_COLOR)
  assert.equal(nodeColor(grouped, "group"), nodeColor(grouped, "group"), "同组同色")
})

test("hover：title + 分组名（或文件夹名）；未分组用「未分组」", () => {
  const labels = { "c:g1": { name: "退款", ai: false } }
  const grouped = { id: "d1", title: "退款政策", group_key: "c:g1", folder: "政策/2025" }
  const lone = { id: "d2", title: "杂记", group_key: "u:ungrouped", folder: "" }
  assert.equal(hoverCaption(grouped, "group", labels), "退款政策 · 退款")
  assert.equal(hoverCaption(grouped, "folder", labels), "退款政策 · 政策/2025")
  assert.equal(hoverCaption(lone, "group", labels), `杂记 · ${KNOWLEDGE_GRAPH_UNGROUPED_LABEL}`)
  assert.equal(hoverCaption(lone, "folder", labels), `杂记 · ${KNOWLEDGE_GRAPH_UNGROUPED_LABEL}`)
})

test("KnowledgeGraphColorSwitch 默认按分组，可切到按文件夹", () => {
  const group = renderToStaticMarkup(
    createElement(KnowledgeGraphColorSwitch, { mode: "group", onChange: () => {} }),
  )
  assert.ok(group.includes(KNOWLEDGE_GRAPH_COLOR_GROUP))
  assert.ok(group.includes(KNOWLEDGE_GRAPH_COLOR_FOLDER))
  assert.ok(group.includes('aria-pressed="true"'))
  assert.ok(!group.includes("簇"))

  const folder = renderToStaticMarkup(
    createElement(KnowledgeGraphColorSwitch, { mode: "folder", onChange: () => {} }),
  )
  assert.ok(folder.includes(KNOWLEDGE_GRAPH_COLOR_FOLDER))
})

// --- LLM 开关默认关 + storage key（AC-4） ---

test("LLM 开关默认关；storage key 钉死 knowledge_graph_llm_labels", () => {
  assert.equal(KNOWLEDGE_GRAPH_LLM_LABELS_KEY, "knowledge_graph_llm_labels")
  assert.equal(parseLlmLabelsPref(undefined), false)
  assert.equal(parseLlmLabelsPref(null), false)
  assert.equal(parseLlmLabelsPref(false), false)
  assert.equal(parseLlmLabelsPref("false"), false)
  assert.equal(parseLlmLabelsPref(0), false)
  assert.equal(parseLlmLabelsPref(true), true)
})

test("buildKnowledgeGraphRequest: 默认不带 llm_labels；开时 llm_labels:true", () => {
  assert.deepEqual(buildKnowledgeGraphRequest({ llmLabels: false }), { type: "knowledge.graph" })
  assert.deepEqual(buildKnowledgeGraphRequest({ llmLabels: true }), {
    type: "knowledge.graph",
    llm_labels: true,
  })
  assert.deepEqual(buildKnowledgeGraphRequest({ llmLabels: true, regenerate: true }), {
    type: "knowledge.graph",
    llm_labels: true,
    regen_labels: true,
  })
  // #374: 可选 id 透传（companion 回带用于 error 帧精确关联）
  assert.deepEqual(buildKnowledgeGraphRequest({ llmLabels: false, id: "kg.1" }), {
    type: "knowledge.graph",
    id: "kg.1",
  })
})

test("KnowledgeGraphLlmSwitch 默认关，重新生成仅在开启时出现", () => {
  const off = renderToStaticMarkup(
    createElement(KnowledgeGraphLlmSwitch, {
      enabled: false,
      onChange: () => {},
      onRegenerate: () => {},
    }),
  )
  assert.ok(off.includes('aria-pressed="false"') || off.includes("aria-checked=\"false\""), off)
  assert.ok(!off.includes(KNOWLEDGE_GRAPH_REGENERATE), "关时不展示重新生成")

  const on = renderToStaticMarkup(
    createElement(KnowledgeGraphLlmSwitch, {
      enabled: true,
      onChange: () => {},
      onRegenerate: () => {},
    }),
  )
  assert.ok(on.includes(KNOWLEDGE_GRAPH_REGENERATE), on)
})

// --- AI 标识（AC-4） ---

test("groupCardModel: ai:true 才带「AI 生成」；关开关无摘要", () => {
  const ai = groupCardModel({ name: "退款政策组", summary: "处理退款与售后。", ai: true }, true)
  assert.equal(ai.name, "退款政策组")
  assert.equal(ai.summary, "处理退款与售后。")
  assert.equal(ai.showAiBadge, true)

  const fallback = groupCardModel({ name: "退款", summary: "不该显示", ai: false }, true)
  assert.equal(fallback.name, "退款")
  assert.equal(fallback.summary, null)
  assert.equal(fallback.showAiBadge, false)

  const off = groupCardModel({ name: "退款政策组", summary: "处理退款与售后。", ai: true }, false)
  assert.equal(off.summary, null)
  assert.equal(off.showAiBadge, false)
})

test("KnowledgeGraphGroupCard 真渲染 AI 标识 tooltip", () => {
  const html = renderToStaticMarkup(
    createElement(KnowledgeGraphGroupCard, {
      groupKey: "c:g1",
      label: { name: "退款政策组", summary: "处理退款与售后。", ai: true },
      llmEnabled: true,
    }),
  )
  assert.ok(html.includes("退款政策组"), html)
  assert.ok(html.includes("处理退款与售后。"), html)
  assert.ok(html.includes(KNOWLEDGE_GRAPH_AI_BADGE), html)
  assert.ok(html.includes('title="AI 生成"') || html.includes("title='AI 生成'"), html)
  assert.ok(!html.includes("簇"), html)
})

// --- wire 形状 ---

test("parseKnowledgeGraphPayload: 契约形状；未知 status 丢弃", () => {
  const ok: KnowledgeGraphPayload = mockKnowledgeGraphPayload({
    status: "ok",
    truncated: false,
    nodes: [{ id: "a", title: "A", group_key: "c:g1", folder: "f" }],
    edges: [{ a: "a", b: "b", score: 0.4 }],
    labels: { "c:g1": { name: "组", ai: false } },
  })
  const parsed = parseKnowledgeGraphPayload({
    type: "knowledge.graph",
    ...ok,
    extra: "drop",
  })
  assert.ok(parsed)
  assert.equal(parsed!.status, "ok")
  assert.equal(parsed!.nodes[0].id, "a")
  assert.equal((parsed as { extra?: unknown }).extra, undefined)
  assert.equal(parseKnowledgeGraphPayload({ status: "nope", nodes: [] }), null)
  assert.equal(parseKnowledgeGraphPayload(null), null)
})

// --- 入口按钮（AC-1） ---

test("KnowledgeGraphEntryButton 文案是「分布图谱」且不含「簇」", () => {
  const html = renderToStaticMarkup(
    createElement(KnowledgeGraphEntryButton, { onClick: () => {} }),
  )
  assert.ok(html.includes("分布图谱"), html)
  assert.ok(!html.includes("簇"))
  assert.ok(html.includes("button"))
})

// --- 名词纪律（spec §7） ---

test("名词：视图源码可用「图谱」，禁用「簇」", () => {
  const viewRoot = join(SRC_ROOT, "knowledge-graph")
  const tab = join(SRC_ROOT, "tabs/knowledge-graph.tsx")
  const files = [...walkSource(viewRoot), tab]
  for (const file of files) {
    const text = readFileSync(file, "utf8")
    assert.ok(!text.includes("簇"), `${file} 视图内不得出现「簇」`)
  }
})

// --- #427 低语料整理 lane ---

test("#427 copy: CTA 插值 N；lane 2–19；新文案走常量", () => {
  assert.equal(knowledgeGraphOrganizeCta(4), "让 AI 整理现有 4 篇")
  assert.equal(knowledgeGraphOrganizeCta(19), "让 AI 整理现有 19 篇")
  assert.equal(KNOWLEDGE_GRAPH_LLM_LANE_MAX, 19)
  assert.equal(isKnowledgeGraphLlmLane(1), false)
  assert.equal(isKnowledgeGraphLlmLane(2), true)
  assert.equal(isKnowledgeGraphLlmLane(19), true)
  assert.equal(isKnowledgeGraphLlmLane(20), false)
  assert.equal(KNOWLEDGE_GRAPH_REORGANIZE, "重新整理")
  assert.equal(KNOWLEDGE_GRAPH_STALE_BADGE, "语料已变化 · 可重新整理")
  assert.equal(KNOWLEDGE_GRAPH_NO_RELATIONS, "AI 未发现明确关联")
  assert.equal(KNOWLEDGE_GRAPH_TF_SWITCH_BANNER, "知识已满 20 篇，分组改按统计聚类（更稳定）")
  assert.equal(KNOWLEDGE_GRAPH_LOCK_DISSOLVED, "不足两篇的锁定分组已解散")
  assert.equal(KNOWLEDGE_GRAPH_AI_RELATION, "AI 关联")
  assert.equal(KNOWLEDGE_GRAPH_LOCK_GROUP, "保留这版分组")
  assert.equal(KNOWLEDGE_GRAPH_UNLOCK_GROUP, "解锁")
  assert.equal(KNOWLEDGE_GRAPH_ORGANIZE_RETRY, "重试")
  assert.equal(KNOWLEDGE_GRAPH_LLM_NOT_CONFIGURED, "未配置 LLM")
})

test("#427 shouldRenderGraphCanvas 仍只放行 ok|over_cap（不新增 status）", () => {
  assert.equal(shouldRenderGraphCanvas("ok"), true)
  assert.equal(shouldRenderGraphCanvas("over_cap"), true)
  assert.equal(shouldRenderGraphCanvas("too_few"), false)
  assert.equal(shouldRenderGraphCanvas("error"), false)
  assert.equal(shouldRenderGraphCanvas("rebuilding"), false)
})

test("#427 parseKnowledgeGraphPayload: 旧帧无新字段照常；relations/llm_ready/organize_error 可选", () => {
  const old = parseKnowledgeGraphPayload({
    status: "ok",
    truncated: false,
    nodes: [{ id: "a", title: "A", group_key: "u:ungrouped", folder: "" }],
    edges: [{ a: "a", b: "b", score: 0.2 }],
    labels: {},
  })
  assert.ok(old)
  assert.equal(old!.relations, undefined)
  assert.equal(old!.llm_ready, undefined)
  assert.equal(old!.organize_error, undefined)
  assert.equal(old!.stale, undefined)

  const full = parseKnowledgeGraphPayload({
    status: "ok",
    nodes: [
      { id: "a", title: "A", group_key: "l:abc", folder: "" },
      { id: "b", title: "B", group_key: "l:abc", folder: "" },
    ],
    edges: [{ a: "a", b: "b", score: 0.3 }],
    labels: { "l:abc": { name: "组", summary: "摘要", ai: true, locked: true } },
    relations: [
      { a: "a", b: "b", reason: "同主题", confidence: 0.8, ai: true },
      { a: "a", b: "a", reason: "自环", confidence: 1 },
      { a: "a", b: "c", reason: "" },
    ],
    llm_ready: false,
    organize_error: "timeout",
    stale: true,
    tf_switch_notice: true,
    lock_dissolved: true,
  })
  assert.ok(full)
  assert.equal(full!.llm_ready, false)
  assert.equal(full!.organize_error, "timeout")
  assert.equal(full!.stale, true)
  assert.equal(full!.tf_switch_notice, true)
  assert.equal(full!.lock_dissolved, true)
  assert.equal(full!.labels["l:abc"]!.locked, true)
  assert.equal(full!.relations!.length, 1)
  assert.equal(full!.relations![0].reason, "同主题")
  assert.equal(full!.relations![0].ai, true)
  assert.equal(hasKnowledgeGraphLlmCache(full!), true)
  assert.equal(hasKnowledgeGraphLlmCache(old!), false)

  const emptyOk = parseKnowledgeGraphPayload({
    status: "ok",
    nodes: [
      { id: "a", title: "A", group_key: "u:ungrouped", folder: "" },
      { id: "b", title: "B", group_key: "u:ungrouped", folder: "" },
      { id: "c", title: "C", group_key: "u:ungrouped", folder: "" },
      { id: "d", title: "D", group_key: "u:ungrouped", folder: "" },
    ],
    edges: [],
    labels: {},
    relations: [],
    organized: true,
  })
  assert.ok(emptyOk)
  assert.equal(emptyOk!.organized, true)
  assert.equal(hasKnowledgeGraphLlmCache(emptyOk!), true, "合法空结果仍算已整理")
})

test("#427 buildKnowledgeGraphRequest: organize + user_gesture 成对", () => {
  assert.deepEqual(buildKnowledgeGraphRequest({ llmLabels: false, organize: true }), {
    type: "knowledge.graph",
    organize: true,
    user_gesture: true,
  })
  const lock = buildKnowledgeGraphRequest({ llmLabels: false, lockGroup: "l:abc" })
  assert.equal(lock.lock_group, "l:abc")
  assert.equal(lock.user_gesture, true)
})

test("#427 pair key 无向", () => {
  assert.equal(knowledgeGraphPairKey("b", "a"), knowledgeGraphPairKey("a", "b"))
})

test("#427 OrganizeCta 插值 + llm_ready 禁用；error 条带重试", () => {
  const cta = renderToStaticMarkup(
    createElement(KnowledgeGraphOrganizeCta, {
      n: 4,
      disabled: true,
      organizing: false,
      onOrganize: () => {},
    }),
  )
  assert.ok(cta.includes("让 AI 整理现有 4 篇"), cta)
  assert.ok(cta.includes("disabled") || cta.includes('disabled=""') || cta.includes("not-allowed"), cta)
  assert.ok(cta.includes(KNOWLEDGE_GRAPH_LLM_NOT_CONFIGURED), cta)

  const err = renderToStaticMarkup(
    createElement(KnowledgeGraphOrganizeErrorBar, { error: "timeout", onRetry: () => {} }),
  )
  assert.ok(err.includes("timeout"), err)
  assert.ok(err.includes(KNOWLEDGE_GRAPH_ORGANIZE_RETRY), err)

  const stale = renderToStaticMarkup(createElement(KnowledgeGraphStaleBadge))
  assert.ok(stale.includes(KNOWLEDGE_GRAPH_STALE_BADGE), stale)
  const tf = renderToStaticMarkup(createElement(KnowledgeGraphTfSwitchBanner))
  assert.ok(tf.includes(KNOWLEDGE_GRAPH_TF_SWITCH_BANNER), tf)
  const diss = renderToStaticMarkup(createElement(KnowledgeGraphLockDissolvedBanner))
  assert.ok(diss.includes(KNOWLEDGE_GRAPH_LOCK_DISSOLVED), diss)
  const none = renderToStaticMarkup(createElement(KnowledgeGraphNoRelationsNote))
  assert.ok(none.includes(KNOWLEDGE_GRAPH_NO_RELATIONS), none)
  const re = renderToStaticMarkup(
    createElement(KnowledgeGraphReorganizeButton, {
      organizing: false,
      disabled: false,
      onClick: () => {},
    }),
  )
  assert.ok(re.includes(KNOWLEDGE_GRAPH_REORGANIZE), re)
})

test("#427 groupCard: l: 分组关命名开关仍带 AI 标；锁按钮", () => {
  const off = groupCardModel({ name: "投研", summary: "摘要", ai: true }, false, { llmLaneGroup: true })
  assert.equal(off.showAiBadge, true)
  assert.equal(off.summary, "摘要")
  const html = renderToStaticMarkup(
    createElement(KnowledgeGraphGroupCard, {
      groupKey: "l:abc",
      label: { name: "投研", summary: "摘要", ai: true },
      llmEnabled: false,
      llmLaneGroup: true,
      onLock: () => {},
    }),
  )
  assert.ok(html.includes(KNOWLEDGE_GRAPH_AI_BADGE), html)
  assert.ok(html.includes(KNOWLEDGE_GRAPH_LOCK_GROUP), html)
  const locked = renderToStaticMarkup(
    createElement(KnowledgeGraphGroupCard, {
      groupKey: "l:abc",
      label: { name: "投研", ai: true, locked: true },
      llmEnabled: false,
      llmLaneGroup: true,
      onUnlock: () => {},
    }),
  )
  assert.ok(locked.includes(KNOWLEDGE_GRAPH_UNLOCK_GROUP), locked)
})

test("#427 App 源码：CTA 发 organize+user_gesture；不内联新文案", () => {
  const app = readFileSync(join(SRC_ROOT, "knowledge-graph/KnowledgeGraphApp.tsx"), "utf8")
  assert.ok(app.includes("organize: true"), "CTA 走 organize")
  const bg = readFileSync(join(SRC_ROOT, "background/index.ts"), "utf8")
  assert.ok(bg.includes("organize"), "SW 透传 organize")
  assert.ok(bg.includes("lock_group") && bg.includes("unlock_group"), "SW 透传锁")
  assert.ok(!app.includes("让 AI 整理现有"), "CTA 文案不得内联")
  assert.ok(!app.includes("语料已变化"), "stale 文案不得内联")
  assert.ok(app.includes("labels[k]?.locked === true"), "≥20 锁组仍可解锁（不限 llmLane）")
  assert.ok(app.includes("knowledgeGraphViewModel"), "CTA 门走可测 view model")
  assert.ok(app.includes("knowledgeGraphBarMeta"), "边计数走常量函数")
})

test("#427 App 层：CTA 只在 ok+2–19+无缓存；空结果无 CTA 有散点 note", () => {
  const ungrouped4 = mockKnowledgeGraphPayload({
    status: "ok",
    nodes: ["a", "b", "c", "d"].map((id) => ({ id, title: id, group_key: "u:ungrouped", folder: "" })),
  })
  const cta = knowledgeGraphViewModel(ungrouped4)
  assert.equal(cta.showOrganizeCta, true)
  assert.equal(cta.showNoRelations, false)
  assert.equal(cta.relationsToDraw.length, 0)

  const emptyOrg = mockKnowledgeGraphPayload({
    status: "ok",
    nodes: ungrouped4.nodes,
    relations: [],
    organized: true,
  })
  const empty = knowledgeGraphViewModel(emptyOrg)
  assert.equal(empty.showOrganizeCta, false, "合法空结果不再出 CTA")
  assert.equal(empty.showNoRelations, true)
  assert.equal(empty.showReorganize, true)

  assert.equal(knowledgeGraphViewModel(mockKnowledgeGraphPayload({ status: "too_few" })).showOrganizeCta, false)
  assert.equal(knowledgeGraphViewModel(mockKnowledgeGraphPayload({ status: "error" })).showOrganizeCta, false)
  assert.equal(
    knowledgeGraphViewModel(
      mockKnowledgeGraphPayload({
        status: "ok",
        nodes: [{ id: "only", title: "x", group_key: "u:ungrouped", folder: "" }],
      }),
    ).showOrganizeCta,
    false,
    "n=1 无 CTA",
  )
  const twenty = knowledgeGraphViewModel(
    mockKnowledgeGraphPayload({
      status: "ok",
      nodes: Array.from({ length: 20 }, (_, i) => ({
        id: `n${i}`,
        title: `n${i}`,
        group_key: "c:g",
        folder: "",
      })),
      relations: [{ a: "n0", b: "n1", reason: "leak", confidence: 1, ai: true }],
    }),
  )
  assert.equal(twenty.showOrganizeCta, false)
  assert.equal(twenty.relationsToDraw.length, 0, "≥20 不画 AI 虚线（双保险）")
})

test("#427 barMeta：有 AI 关联时拆 TF/AI", () => {
  assert.equal(knowledgeGraphBarMeta(4, 3, 0), "4 篇知识 · 3 条相似关联")
  assert.equal(knowledgeGraphBarMeta(4, 3, 2), "4 篇知识 · 3 条相似关联 · 2 条 AI 关联")
})

```

### CHANGED GRAPH FUNCTIONS/ROUTE CONTEXT companion/src/message-router.ts
```
export function __testSetFolderSuggestImpl(impl?: FolderSuggestImpl): void {
  folderSuggestImpl = impl || defaultFolderSuggestImpl
}

// --- #296: knowledge graph LLM 分组标签（opt-in，display 派生缓存） ---
//
// Spec §3.2：面板开关随请求传入（llm_labels:true）——纯 UI 偏好，不进
// companion config.json 的 L2/trust 面；regen_labels:true 覆盖缓存强制重生成。
// 非阻塞：本次响应先回高频词标签，异步生成写回 display 后，下次请求拿到
// AI 版。失败/超时回退高频词且无摘要，不报错不阻塞。隐私（#274 先例）：
// 标注输入只有成员标题 + 标签单行，从不进正文。产物不进检索/路由/导出。

type KnowledgeGraphLabelImpl = (params: {
  lines: string[]
  signal?: AbortSignal
}) => Promise<Record<string, { name: string; summary?: string }>>

const KNOWLEDGE_GRAPH_LABEL_TIMEOUT_MS = 30_000

const defaultKnowledgeGraphLabelImpl: KnowledgeGraphLabelImpl = async ({ lines, signal }) => {
  const config = knowledgeExtractLlmConfig()
  if (!config) throw new Error("companion_llm_not_configured")
  const prompt = buildGraphLabelPrompt(lines)
  const raw = await llmExtract({ ...prompt, config, timeout: KNOWLEDGE_GRAPH_LABEL_TIMEOUT_MS, signal })
  const parsed = parseGraphLabels(raw)
  if (!parsed) throw new Error("graph_label_parse_failed")
  return parsed
}

let knowledgeGraphLabelImpl: KnowledgeGraphLabelImpl = defaultKnowledgeGraphLabelImpl

/** Test hook — swap the graph-label impl (spy / failure injection). */
export function __testSetKnowledgeGraphLabelImpl(impl?: KnowledgeGraphLabelImpl): void {
  knowledgeGraphLabelImpl = impl || defaultKnowledgeGraphLabelImpl
}

/**
 * #427：knowledge.graph wire 帧统一构造（响应帧与推帧同形）。
 * - `llm_ready` 每帧必带（CTA 禁用依据，spec §3.1）；
 * - `relations` / `stale` 只在 LLM lane（2–19）上帧，≥20 帧永不携带（spec §4）；
 *   `relations` 进一步只在缓存帧在场（空数组 = 合法空整理），无缓存帧整体省略，
 *   `organized` 同源（pi MAJOR-1：空结果 ≠ 无缓存）；
 * - `organize_error` 帧级错误条（§4 错误合同：不修订 #356，error status 仍只表示
 *   图谱加载失败；organize / 锁 / gesture 动作失败推 ok 帧 + 本字段，画布保留——
 *   grok M-1：走红 error 会被 ext #356/#374 缝把在途请求打成死面板）；
 * - `lock_dissolved`（boolean）/ `tf_switch_notice`（显式 boolean，落 ack 后 false
 *   抑制 ext 本地回退）——ext wire 合同对齐（kg-427-impl-ext-done.md 偏差节）。
 */
function knowledgeGraphFrame(
  core: KnowledgeGraphCore,
  extra?: { organizeError?: string },
): Record<string, unknown> {
  const frame: Record<string, unknown> = {
    type: "knowledge.graph",
    status: core.status,
    truncated: core.truncated,
    nodes: core.nodes,
    edges: core.edges,
    labels: core.labels,
    llm_ready: knowledgeExtractLlmConfig() !== null,
    // Initial ACK and intermediate refreshes must not look like organize completion.
    organizing: knowledgeGraphOrganizeRun !== null,
  }
  if (core.llmLane) {
    // pi MAJOR-1（修复）：relations 在场 = graph_llm 缓存存在（空数组 = 组织过
    // 但无关联的合法结果）；无缓存帧整体省略（缺字段 ≠ 空数组），organized 同源。
    if (core.organized === true) {
      frame.organized = true
      frame.relations = core.relations
    }
    if (core.llmStale === true) frame.stale = true
  } else if (core.status === "ok" || core.status === "over_cap") {
    // ≥20 lane：notice 持续 true 直到 ext 发 ack_tf_switch（权威 ack 在动词落盘）
    frame.tf_switch_notice = core.tfSwitchBanner === true
  }
  if (core.lockDissolved && core.lockDissolved.length > 0) frame.lock_dissolved = true
  if (extra?.organizeError) frame.organize_error = extra.organizeError
  return frame
}

/** Single-flight：同刻至多一个标注 run；regen 打断旧 run。 */
let knowledgeGraphLabelRun: AbortController | null = null

function maybeStartKnowledgeGraphLabels(
  skillEngine: SkillEngine,
  graph: KnowledgeGraphCore,
  force: boolean,
  session?: SessionCallbacks,
): void {
  const targets = graph.labelTargets.filter((t) => force || !t.cached)
  if (targets.length === 0) return
  if (!knowledgeExtractLlmConfig()) return
  if (knowledgeGraphLabelRun) {
    if (!force) return
    knowledgeGraphLabelRun.abort()
  }
  const ac = new AbortController()
  knowledgeGraphLabelRun = ac
  const lines = targets.flatMap((t) => t.lines)
  // NOTE (F5)：impl 必须异步 settle（生产走网络）——响应帧先带回退标签返回。
  void (async () => {
    try {
      const parsed = await knowledgeGraphLabelImpl({ lines, signal: ac.signal })
      if (ac.signal.aborted) return
      const entries: Record<string, KnowledgeGraphLabelEntry> = {}
      for (const [key, v] of Object.entries(parsed)) {
        const clamped = clampKnowledgeGraphLabelEntry(v)
        if (clamped) entries[key] = clamped
      }
      if (Object.keys(entries).length > 0) {
        skillEngine.setKnowledgeGraphDisplay(entries)
        // AC-4：异步标注落地后主动推一帧更新图谱（labels 带 AI 版），否则
        // 当次会话永远只看到回退标签。sendToExtension 只回发起面板，
        // 不 broadcast（图谱是 panel-only，summoner/overlay 不得收到）。
        try {
          const updated = skillEngine.getKnowledgeGraph({ llmLabels: true })
          if (updated && session?.sendToExtension) {
            session.sendToExtension(knowledgeGraphFrame(updated))
          }
        } catch {
          /* best-effort push; 下次请求仍会拿到 AI 标签 */
        }
      }
    } catch {
      // 回退规则：失败/超时静默回退（下次请求仍是高频词标签）
    } finally {
      if (knowledgeGraphLabelRun === ac) knowledgeGraphLabelRun = null
    }
  })()
}

// --- #427: 低语料图谱 LLM 整理 lane（organize；spec §3.1/§3.2/§4） ---
//
// 手动唯一（organize:true + user_gesture:true 双闸，与 distill-all 同纪律）、
// panel-only（surface 闸在 handler）。single-flight + AbortController 复用 label
// 驱动模式，但**不得静默 catch**：失败也推帧（status:"ok" + organize_error，
// 画布保留 + 旧缓存不丢）。settle 时按当前索引重校 ids；指纹已漂 → 写入即标
// stale（不渲染过期结构假装新鲜）。

type KnowledgeGraphOrganizeImpl = (params: {
  systemPrompt: string
  userContent: string
  signal?: AbortSignal
}) => Promise<string>

const defaultKnowledgeGraphOrganizeImpl: KnowledgeGraphOrganizeImpl = async ({
  systemPrompt,
  userContent,
  signal,
}) => {
  const config = knowledgeExtractLlmConfig()
  if (!config) throw new Error("companion_llm_not_configured")
  return llmExtract({
    systemPrompt,
    userContent,
    config,
    timeout: KNOWLEDGE_GRAPH_ORGANIZE_TIMEOUT_MS,
    signal,
  })
}

let knowledgeGraphOrganizeImpl: KnowledgeGraphOrganizeImpl = defaultKnowledgeGraphOrganizeImpl

/** Test hook — swap the organize impl (spy / failure injection)。 */
export function __testSetKnowledgeGraphOrganizeImpl(impl?: KnowledgeGraphOrganizeImpl): void {
  knowledgeGraphOrganizeImpl = impl || defaultKnowledgeGraphOrganizeImpl
}

/** single-flight：同刻至多一个 organize run（在飞时新请求直接忽略）。 */
let knowledgeGraphOrganizeRun: AbortController | null = null

/** #427 缺 user_gesture 的拒因（帧级错误条文案；raw 语义词保留便于排查）。 */
const KNOWLEDGE_GRAPH_GESTURE_ERROR = "操作被拒绝：缺少用户手势（user_gesture）"

/**
 * organize 失败的用户可见文案（grok NIT-9）：raw 错误（"llm down" /
 * "graph_organize_parse_failed" 等）只进日志不上帧——错误条是给用户看的。
 */
function organizeErrorText(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e)
  if (msg === "companion_llm_not_configured") return "AI 未配置，无法整理"
  if (msg === "graph_organize_parse_failed") return "AI 整理返回无法解析，请重试"
  if (/timeout|timed?\s?out|abort/i.test(msg)) return "AI 整理超时，请重试"
  return "AI 整理失败，请重试"
}

function maybeStartKnowledgeGraphOrganize(skillEngine: SkillEngine, session?: SessionCallbacks): void {
  if (knowledgeGraphOrganizeRun) return
  const ac = new AbortController()
  knowledgeGraphOrganizeRun = ac
  // 快照在先：指纹记 LLM 实际看到的输入；settle 再对当前索引重校
  const startDocs = skillEngine.getKnowledgeDocsForOrganize()
  const inputFingerprint = computeGraphLlmFingerprint(startDocs)
  const lock = skillEngine.getKnowledgeGraphSections().lock
  const prompt = buildGraphOrganizePrompt(startDocs, lock)
  void (async () => {
    let organizeError: string | undefined
    try {
      const raw = await knowledgeGraphOrganizeImpl({ ...prompt, signal: ac.signal })
      if (ac.signal.aborted) return
      const parsed = parseGraphOrganize(raw)
      if (!parsed) throw new Error("graph_organize_parse_failed")
      // settle：按当前索引重校（在飞期间可能已重建/增删）
      const currentDocs = skillEngine.getKnowledgeDocsForOrganize()
      const liveIds = new Set(currentDocs.map((d) => d.id))
      const lockedIds = new Set(
        (skillEngine.getKnowledgeGraphSections().lock?.groups ?? []).flatMap((g) => g.ids),
      )
      const normalized = normalizeGraphOrganize(parsed, liveIds, lockedIds)
      const currentFingerprint = computeGraphLlmFingerprint(currentDocs)
      skillEngine.setKnowledgeGraphLlmSection({
        fingerprint: inputFingerprint,
        groups: normalized.groups,
        relations: normalized.relations,
        stale: inputFingerprint !== currentFingerprint,
      })
    } catch (e) {
      // #427 §4 + grok NIT-9：不静默——错误进帧（organize_error），旧缓存原样
      // 保留；raw 错误进日志，帧上只给用户可读的中文文案
      organizeError = organizeErrorText(e)
      logger.warn("knowledge.graph organize failed", {
        error: e instanceof Error ? e.message : String(e),
      })
    } finally {
      if (knowledgeGraphOrganizeRun === ac) knowledgeGraphOrganizeRun = null
    }
    try {
      const updated = skillEngine.getKnowledgeGraph()
      if (updated && session?.sendToExtension) {
        session.sendToExtension(
          knowledgeGraphFrame(updated, organizeError ? { organizeError } : undefined),
        )
      }
    } catch {
      /* best-effort push; 下次请求仍会拿到新缓存/错误条不丢（organize_error 例外） */
    }
  })()
}

/**
 * #427 lock_group / unlock_group（ext wire 合同：键 = 当前帧渲染 group_key）。
 * `l:` 渲染键由锁条目**现存**成员现算——缩容后键跟着变，unlock 仍命中条目
 * （锁的身份是条目而非 hash，pi 终验注意 2）。锁成员取当前帧 nodes（渲染
 * 真值），name/summary 取 labels；`u:ungrouped` 不是分组，拒绝锁定。
 * 返回 null = 成功（unlock 幂等：未命中即已散/无锁，no-op）。
 */
function applyKnowledgeGraphLock(
  skillEngine: SkillEngine,
  key: string,
  mode: "lock" | "unlock",
): string | null {
  const sections = skillEngine.getKnowledgeGraphSections()
  const current = sections.lock?.groups ?? []
  if (mode === "unlock") {
    const kept = current.filter((g) => lGroupKey(g.ids) !== key)
    if (kept.length !== current.length) skillEngine.setKnowledgeGraphLockSection({ groups: kept })
    return null
  }
  if (!key || key === KNOWLEDGE_UNGROUPED_KEY) {
    // grok NIT-9 同款纪律：错误文案上帧给用户看，用中文（raw 键不进文案）
    return "「未分组」不是分组，无法锁定"
  }
  const graph = skillEngine.getKnowledgeGraph()
  if (!graph) return "知识索引暂不可用（重建中），请稍后重试"
  const label = graph.labels[key]
  const ids = graph.nodes.filter((n) => n.group_key === key).map((n) => n.id)
  if (!label || ids.length < 2) {
    return "分组不存在或成员已不足 2 篇，请刷新图谱后重试"
  }
  // 同渲染键再锁 = 换名字/摘要（条目整体替换）；跨锁条目互不相干
  const kept = current.filter((g) => lGroupKey(g.ids) !== key)
  skillEngine.setKnowledgeGraphLockSection({
    groups: [
      ...kept,
      { ids, name: label.name, ...(label.summary !== undefined ? { summary: label.summary } : {}) },
    ],
  })
  return null
}

// ... unrelated routes omitted ...
          docs: knowledgeListDocs(skillEngine, stampedSurface),
          // #274: folder rows (withheld on summoner — field absent there)
          ...(stampedSurface === "summoner" ? {} : { folders: knowledgeListFolders(skillEngine, stampedSurface) }),
        },
        skillEngine,
        session,
      )
    case "knowledge.search": {
      // #433 P1 读路径：搜派生索引 title/description/tags（零副作用，不触检索路由）。
      const query = normalizeSearchQuery(rest.query)
      if (!query) {
        return { type: "error", error: "knowledge.search requires a non-empty query", code: "invalid" }
      }
      const limit = clampSearchLimit(rest.limit)
      const docs = knowledgeListDocs(skillEngine, stampedSurface)
      const hits = knowledgeSearchRows(docs, query, limit)
      return { type: "knowledge.search_result", query, hits }
    }
    case "knowledge.graph": {
      // #296 图谱视图（按需拉取）。panel-only 门与 distribution 同款：
      // 谓词看 handshake 的 session.surface（stamp 词汇表只有 summoner|tray，
      // 看 stamp 永远不放行）；summoner ACL 是另一层（默认拒，不在 allowlist）。
      const surface = (session as { surface?: unknown } | undefined)?.surface
      if (surface !== "panel") {
        return { type: "error", error: "knowledge.graph is panel-only (Side Panel knowledge panel)" }
      }
      // #427 跨 20 banner ack / 锁（ext wire 合同对齐）：ack_tf_switch 权威落
      // 盘；lock_group/unlock_group 收渲染 group_key。三个动词均 user_gesture
      // 门（与 organize 同纪律——每个 LLM/写动作可溯源到一次点击）。
      // grok M-1（修复）：动作失败/缺 gesture 不走红 error——ext 的
      // knowledgeGraphErrorById 会把在途 graph 请求打成 #356 死面板；统一降级为
      // ok 帧 + organize_error 帧字段（与 organize 失败同通道），画布照常渲染。
      let actionError: string | undefined
      if (rest.ack_tf_switch === true) {
        if (rest.user_gesture !== true) {
          actionError = KNOWLEDGE_GRAPH_GESTURE_ERROR
        } else {
          skillEngine.ackKnowledgeGraphTfSwitch()
        }
      }
      const lockMode =
        typeof rest.lock_group === "string" ? "lock" : typeof rest.unlock_group === "string" ? "unlock" : null
      if (lockMode) {
        if (rest.user_gesture !== true) {
          actionError = actionError ?? KNOWLEDGE_GRAPH_GESTURE_ERROR
        } else {
          const key = (lockMode === "lock" ? rest.lock_group : rest.unlock_group) as string
          const lockError = applyKnowledgeGraphLock(skillEngine, key, lockMode)
          if (lockError) actionError = lockError
        }
      }
      // #427 organize（手动唯一）：user_gesture 双闸 + 仅 2–19 lane；n≥20 服务端
      // no-op（AC-7：客户端漏藏按钮也偷渡不进 TF lane），n<2 无结构可言也不启动。
      if (rest.organize === true) {
        if (rest.user_gesture !== true) {
          actionError = actionError ?? KNOWLEDGE_GRAPH_GESTURE_ERROR
        } else {
          const docsForLane = skillEngine.getKnowledgeDocsForOrganize()
          if (docsForLane.length >= 2 && docsForLane.length <= KNOWLEDGE_GRAPH_LLM_LANE_MAX) {
            if (!knowledgeExtractLlmConfig()) {
              actionError = actionError ?? "AI 未配置，无法整理"
            } else {
              maybeStartKnowledgeGraphOrganize(skillEngine, session)
            }
          }
        }
      }
      const graph = skillEngine.getKnowledgeGraph({ llmLabels: rest.llm_labels === true })
      if (!graph) {
        // 索引缺失/损坏/重建中：诚实态，不假装结构（AC-5）
        return {
          type: "knowledge.graph",
          status: "rebuilding",
          truncated: false,
          nodes: [],
          edges: [],
          labels: {},
          llm_ready: knowledgeExtractLlmConfig() !== null,
          organizing: knowledgeGraphOrganizeRun !== null,
          ...(actionError ? { organize_error: actionError } : {}),
        }
      }
      if (rest.llm_labels === true || rest.regen_labels === true) {
        maybeStartKnowledgeGraphLabels(skillEngine, graph, rest.regen_labels === true, session)
      }
      // labelTargets 不上 wire（服务端内部异步标注驱动）
      return knowledgeGraphFrame(graph, actionError ? { organizeError: actionError } : undefined)
    }
    case "knowledge.set_active": {
      if (!rest.thread_id) return { type: "error", error: "thread_id required" }
      const overlayThreadErr = gateOverlayCurrentThread(rest.thread_id, stampedSurface)
      if (overlayThreadErr) return overlayThreadErr
      const thread = threadManager.get(rest.thread_id)
      if (!thread) return { type: "error", error: `Thread not found: ${rest.thread_id}` }
      const ids = Array.isArray(rest.ids)
        ? rest.ids.filter((id: unknown) => typeof id === "string" && id.trim()).slice(0, 32)
        : []
      const known = new Set<string>()
      for (const d of skillEngine.listKnowledge()) {
        if (d.id) known.add(d.id)
```

### FULL companion/src/skills/knowledge-graph.ts
```
// Knowledge graph view computation (#296, spec §3.1/§5/§6; #427 spec §2–§6).
// Spec: docs/superpowers/specs/2026-09-04-knowledge-graph-view-design.md
//       docs/superpowers/specs/2026-09-06-knowledge-graph-small-corpus-design.md
// ADR: docs/adr/028-knowledge-graph-view-exemption-extension.md
//
// 纯派生、只读、可丢可重建（spec §2）：节点/边每次从派生索引现算，边不落盘。
// 聚类与分组键复用 knowledge-clusters（唯一算法点）；相关度复用
// knowledge-related 的 scoreRelatedKnowledge（唯一计算点，只放宽取边参数）。
// #427：图谱画布闸与聚类闸解绑（MIN_DOCS=1）；2–19 走 LLM lane（organize
// 产物 + 锁 overlay），≥20 TF 路径零改动；MIN_DOCS/scoreRelatedKnowledge 不动。

import { createHash } from "node:crypto"
import {
  KNOWLEDGE_CLUSTER_DOC_CAP,
  KNOWLEDGE_CLUSTER_MIN_DOCS,
  KNOWLEDGE_UNGROUPED_KEY,
  buildKnowledgeDistribution,
  clusterKnowledgeDocs,
  compareCodepoint,
  type KnowledgeCluster,
  type KnowledgeGraphGroupEntry,
  type KnowledgeGraphLabelEntry,
  type KnowledgeGraphLlmSection,
  type KnowledgeGraphLockSection,
  type KnowledgeIndexDoc,
} from "./knowledge-clusters"
import { scoreRelatedKnowledge } from "./knowledge-related"
import { redactSecrets } from "../threads/distill"

// --- 常数表（spec §6 / #427 spec §8；可测可调，不要藏） ---

/** 每节点出边上限（spec §3.1：top-5，无合成分地板）。 */
export const KNOWLEDGE_GRAPH_EDGE_TOPK = 5
/** 节点上限：复用 KNOWLEDGE_CLUSTER_DOC_CAP，不另设。 */
export const KNOWLEDGE_GRAPH_DOC_CAP = KNOWLEDGE_CLUSTER_DOC_CAP
/**
 * 图谱画布下限（#427 spec §2）：与聚类闸解绑，n≥1 即画布（散点是诚实结构）。
 * too_few 只剩 n=0。KNOWLEDGE_CLUSTER_MIN_DOCS（分布 chips / 簇路由闸）不动。
 */
export const KNOWLEDGE_GRAPH_MIN_DOCS = 1
/** LLM lane 上界（#427 spec §2：= 聚类闸 -1，同源不另造数）。 */
export const KNOWLEDGE_GRAPH_LLM_LANE_MAX = KNOWLEDGE_CLUSTER_MIN_DOCS - 1
/** 全图 LLM 关联上限（两段式第二刀）。 */
export const KNOWLEDGE_GRAPH_RELATIONS_CAP = 12
/** 单端点 LLM 关联度数上限（两段式第一刀）。 */
export const KNOWLEDGE_GRAPH_RELATIONS_PER_NODE = 3
/** reason 钳制（码点切片，不劈代理对）。 */
export const KNOWLEDGE_GRAPH_RELATION_REASON_MAX = 80
/** organize 单次 LLM 调用超时（#427 spec §3.1：label 档，慢就诚实失败）。 */
export const KNOWLEDGE_GRAPH_ORGANIZE_TIMEOUT_MS = 30_000
/** 池丢弃率回退阈（#427 spec §3.2：分池判定，超阈该池整体回退）。 */
export const KNOWLEDGE_GRAPH_POOL_DISCARD_FALLBACK = 0.5
/** LLM 分组名称长度上限（字）。 */
export const KNOWLEDGE_GRAPH_LABEL_NAME_MAX = 20
/** LLM 分组摘要长度上限（字）。 */
export const KNOWLEDGE_GRAPH_LABEL_SUMMARY_MAX = 280
/** display 缓存条目上限：超出整体丢弃（可丢缓存的软界）。 */
export const KNOWLEDGE_GRAPH_DISPLAY_MAX_ENTRIES = 1000

// --- wire 形状（spec §5 / #427 spec §4） ---

export type KnowledgeGraphNode = { id: string; title: string; group_key: string; folder: string }
export type KnowledgeGraphEdge = { a: string; b: string; score: number }
export type KnowledgeGraphLabel = {
  name: string
  summary?: string
  ai: boolean
  /** #427：锁 overlay 分组（ext wire 合同：labels[].locked，缺省无此字段）。 */
  locked?: true
}
export type KnowledgeGraphLabelTarget = { key: string; lines: string[]; cached: boolean }
/** #427：LLM 关联（纯覆盖层，不进 edges[].score；只在 2–19 帧上 wire）。 */
export type KnowledgeGraphRelation = { a: string; b: string; reason: string; confidence: number; ai: true }
/** #427：graph_llm 缓存里的关联条目形状（KnowledgeGraphLlmSection 的元素）。 */
export type KnowledgeGraphRelationEntry = KnowledgeGraphLlmSection["relations"][number]

/** 服务端内部形状：labelTargets 供异步 LLM 标注驱动，不上 wire。 */
export type KnowledgeGraphCore = {
  status: "ok" | "too_few" | "over_cap"
  truncated: boolean
  nodes: KnowledgeGraphNode[]
  edges: KnowledgeGraphEdge[]
  labels: Record<string, KnowledgeGraphLabel>
  labelTargets: KnowledgeGraphLabelTarget[]
  /** #427：LLM 关联——仅 LLM lane（2–19）非空；≥20 帧永不携带。 */
  relations: KnowledgeGraphRelation[]
  /**
   * #427（pi MAJOR-1 修复）：graph_llm 缓存区存在即 true——合法空整理
   * （groups:[] + relations:[]）与「无缓存」在 wire 上必须可区分（后者省略
   * organized 与 relations 两个字段，前者两字段都在场）。
   */
  organized?: boolean
  /** #427：本帧来自 LLM lane（handler 据此决定 relations/stale 是否上 wire）。 */
  llmLane: boolean
  /** #427：graph_llm 缓存指纹已漂（UI「语料已变化」badge）。 */
  llmStale?: boolean
  /** #427：锁组缩容到 <2 解散的一次性名单（引擎写回剪枝锁后不再重现）。 */
  lockDissolved?: string[]
  /** #427：≥20 切换一次性 banner（引擎落 graph_tf_switch_ack 后不再置位）。 */
  tfSwitchBanner?: boolean
}

/**
 * `l:<hash>` 分组键（#427 spec §2：服务端派生——sha256(排序后成员 id).slice(0,12)，
 * 同成员集合同键；LLM 永不产出键）。缩容后键随成员集变化，**锁的身份是
 * graph_lock 条目本身而非 hash**（pi 终验注意 2）。
 */
export function lGroupKey(ids: string[]): string {
  const sorted = [...ids].sort(compareCodepoint)
  return "l:" + createHash("sha256").update(JSON.stringify(sorted), "utf8").digest("hex").slice(0, 12)
}

/**
 * graph_llm 缓存指纹（#427 spec §3.3）：全部参与文档 (id, title, description,
 * tags) 的聚合散列——tags 必须在内（tags 是 LLM 输入，只改 tags 也得标 stale）。
 */
export function computeGraphLlmFingerprint(docs: KnowledgeIndexDoc[]): string {
  // \u0001 分字段、\u0002 分文档：防串接碰撞（id/title 边界可造）
  const parts = docs
    .map((d) =>
      [d.id, d.title, d.description || "", [...d.tags].sort(compareCodepoint).join(",")].join("\u0001"),
    )
    .sort(compareCodepoint)
  return createHash("sha256").update(parts.join("\u0002"), "utf8").digest("hex")
}

/**
 * 从派生索引现算图谱（#427 spec §2 状态映射表）。
 * n=0 → too_few（不假装结构）；n=1 → 单节点不分组不调 LLM；2–19 → LLM lane
 * （缓存产物 + 锁 overlay，无缓存 = 全未分组 + TF 边照算）；n≥20 → 既有 TF
 * 路径零改动（n>200 → 标题字典序截取前 200 并对截取集重跑聚类）。
 * 同输入 → 同输出（确定性三钉沿用聚类层）。
 */
export function buildKnowledgeGraph(
  docs: KnowledgeIndexDoc[],
  display?: Record<string, KnowledgeGraphLabelEntry>,
  opts?: {
    llmLabels?: boolean
    /** #427 LLM lane 缓存产物（引擎侧已按现存 docs 剪枝）。 */
    llm?: { groups: KnowledgeGraphGroupEntry[]; relations: KnowledgeGraphRelationEntry[] }
    llmStale?: boolean
    /** #427 锁 overlay（引擎侧已剪枝，组 ≥2 现存成员）。 */
    lock?: KnowledgeGraphLockSection
  },
): KnowledgeGraphCore {
  if (docs.length < KNOWLEDGE_GRAPH_MIN_DOCS) {
    return {
      status: "too_few",
      truncated: false,
      nodes: [],
      edges: [],
      labels: {},
      labelTargets: [],
      relations: [],
      llmLane: false,
    }
  }

  const llmLane = docs.length < KNOWLEDGE_CLUSTER_MIN_DOCS
  let selected: KnowledgeIndexDoc[]
  let status: "ok" | "over_cap"
  let groups: KnowledgeCluster[]
  if (docs.length > KNOWLEDGE_GRAPH_DOC_CAP) {
    selected = [...docs]
      .sort((x, y) => compareCodepoint(x.title, y.title) || compareCodepoint(x.id, y.id))
      .slice(0, KNOWLEDGE_GRAPH_DOC_CAP)
    groups = clusterKnowledgeDocs(selected).groups
    status = "over_cap"
  } else if (llmLane) {
    // #427：2–19 LLM lane——TF 聚类不参与图谱（分布视图/簇路由仍走各自 20 闸）
    selected = docs
    groups = []
    status = "ok"
  } else {
    selected = docs
    const dist = buildKnowledgeDistribution(docs)
    groups = dist.status === "ok" ? dist.groups : []
    status = "ok"
  }

  const byId = new Map(selected.map((d) => [d.id, d]))
  const groupOf = new Map<string, string>()
  for (const g of groups) for (const id of g.ids) groupOf.set(id, `c:${g.key}`)
  // 跨 20 后旧 LLM 缓存仍保留，但只有显式锁组可覆盖 TF 分组。
  if (llmLane) {
    for (const g of opts?.llm?.groups ?? []) {
      // 同成员集合两组：先到先得（后组撞已占键自然被盖）
      const key = lGroupKey(g.ids)
      for (const id of g.ids) {
        if (byId.has(id) && !groupOf.has(id)) groupOf.set(id, key)
      }
    }
  }

  const nodes = [...selected]
    .sort((x, y) => compareCodepoint(x.id, y.id))
    .map((d) => ({
      id: d.id,
      title: d.title,
      group_key: groupOf.get(d.id) ?? KNOWLEDGE_UNGROUPED_KEY,
      folder: d.folder,
    }))

  const edges = buildKnowledgeGraphEdges(selected)

  const labels: Record<string, KnowledgeGraphLabel> = {}
  const labelTargets: KnowledgeGraphLabelTarget[] = []
  if (llmLane) {
    // #427 LLM lane：分组/命名/摘要直接来自 organize 产物（全 ai:true）；
    // labelTargets 恒空（label 通道只服务 TF lane 的高频词→AI 命名缝）
    const presentKeys = new Set(nodes.map((n) => n.group_key))
    for (const g of opts?.llm?.groups ?? []) {
      const key = lGroupKey(g.ids)
      if (!presentKeys.has(key)) continue
      labels[key] = { name: g.name, ...(g.summary !== undefined ? { summary: g.summary } : {}), ai: true }
    }
  } else {
    const presentKeys = new Set(nodes.map((n) => n.group_key))
    for (const g of groups) {
      const key = `c:${g.key}`
      if (!presentKeys.has(key)) continue
      // spec AC-4：开关关（llmLabels !== true）时一律高频词回退标签——display
      // 里的 AI 缓存不得上 wire（否则 UI 关开关后仍显示 AI 名，假完成）。
      const clamped =
        opts?.llmLabels === true && display?.[key] ? clampKnowledgeGraphLabelEntry(display[key]) : null
      if (clamped) {
        labels[key] = { name: clamped.name, ...(clamped.summary !== undefined ? { summary: clamped.summary } : {}), ai: true }
        labelTargets.push({ key, lines: groupLabelLines(key, g, byId), cached: true })
      } else {
        labels[key] = { name: g.label, ai: false }
        labelTargets.push({ key, lines: groupLabelLines(key, g, byId), cached: false })
      }
    }
  }

  // #427 §5：锁 overlay 最后套（锁着色以锁为准；锁不进 TF 聚类输入）
  const nodeById = new Map(nodes.map((n) => [n.id, n]))
  for (const lg of opts?.lock?.groups ?? []) {
    const live = lg.ids.filter((id) => nodeById.has(id))
    if (live.length < 2) continue // 引擎侧已解散；防御
    const key = lGroupKey(live)
    for (const id of live) {
      const n = nodeById.get(id)
      if (n) n.group_key = key
    }
    labels[key] = {
      name: lg.name,
      ...(lg.summary !== undefined ? { summary: lg.summary } : {}),
      ai: true,
      locked: true,
    }
  }
  // 「未分组」label 以 overlay 后的实际归属为准（锁收编全部散点时不残留）
  if (nodes.some((n) => n.group_key === KNOWLEDGE_UNGROUPED_KEY)) {
    labels[KNOWLEDGE_UNGROUPED_KEY] = { name: "未分组", ai: false }
  } else {
    delete labels[KNOWLEDGE_UNGROUPED_KEY]
  }

  // #427 §4：relations 纯覆盖层——只在 LLM lane 存在，端点按现存 docs 过滤、
  // (a,b) 字典序归一（确定性）；≥20 / over_cap 帧恒空数组
  const relations: KnowledgeGraphRelation[] = llmLane
    ? (opts?.llm?.relations ?? [])
        .filter((r) => byId.has(r.a) && byId.has(r.b))
        .map((r) => {
          const flip = compareCodepoint(r.a, r.b) < 0
          return {
            a: flip ? r.a : r.b,
            b: flip ? r.b : r.a,
            reason: r.reason,
            confidence: r.confidence,
            ai: true as const,
          }
        })
    : []

  return {
    status,
    truncated: docs.length > KNOWLEDGE_GRAPH_DOC_CAP,
    nodes,
    edges,
    labels,
    labelTargets,
    relations,
    llmLane,
    ...(opts?.llm ? { organized: true } : {}),
    ...(llmLane && opts?.llmStale === true ? { llmStale: true } : {}),
  }
}

/**
 * 边现算（spec §5）：对每节点跑 scoreRelatedKnowledge，score>0 者按分降序、
 * 平局 id 字典序取 top-K；无向对称去重（a<b 字典序只留一条）；输出按 (a,b) 排序。
 * 权重/语料不改（改动会触发 wikilinks 同源评测重证，spec §6）。
 * #427：n≥2 即算（它本无篇数门槛，只是被旧 too_few 闸挡在门外）。
 */
function buildKnowledgeGraphEdges(docs: KnowledgeIndexDoc[]): KnowledgeGraphEdge[] {
  const ordered = [...docs].sort((x, y) => compareCodepoint(x.id, y.id))
  const best = new Map<string, { a: string; b: string; score: number }>()
  for (const seed of ordered) {
    const hits: Array<{ id: string; score: number }> = []
    for (const other of ordered) {
      if (other.id === seed.id) continue
      const hit = scoreRelatedKnowledge(seed, other)
      if (hit.score > 0) hits.push({ id: other.id, score: hit.score })
    }
    hits.sort((x, y) => y.score - x.score || compareCodepoint(x.id, y.id))
    for (const h of hits.slice(0, KNOWLEDGE_GRAPH_EDGE_TOPK)) {
      const flip = compareCodepoint(seed.id, h.id) < 0
      const a = flip ? seed.id : h.id
      const b = flip ? h.id : seed.id
      const k = JSON.stringify([a, b])
      const prev = best.get(k)
      if (prev === undefined || h.score > prev.score) {
        best.set(k, { a, b, score: h.score })
      }
    }
  }
  return [...best.values()].sort(
    (x, y) => compareCodepoint(x.a, y.a) || compareCodepoint(x.b, y.b),
  )
}

// --- LLM 分组标签（spec §3.2：命名 ≤20 字 + 摘要 ≤280 字，#272 llm-extract 通道） ---

/** 标签单行净化：剥控制字符（保留 \t \n）+ redactSecrets（信任边界，LLM 输出与缓存读取都过）。 */
function sanitizeLabelLine(s: string): string {
  return redactSecrets(s.replace(/[\x00-\x08\x0b-\x1f\x7f]+/g, " ")).text
}

/** LLM 输出/缓存条目钳制：name ≤ NAME_MAX、summary ≤ SUMMARY_MAX；name 为空 → null。 */
export function clampKnowledgeGraphLabelEntry(entry: {
  name: unknown
  summary?: unknown
}): { name: string; summary?: string } | null {
  if (typeof entry.name !== "string") return null
  const name = sanitizeLabelLine(entry.name).slice(0, KNOWLEDGE_GRAPH_LABEL_NAME_MAX).trim()
  if (!name) return null
  const out: { name: string; summary?: string } = { name }
  if (typeof entry.summary === "string") {
    const summary = sanitizeLabelLine(entry.summary).slice(0, KNOWLEDGE_GRAPH_LABEL_SUMMARY_MAX).trim()
    if (summary) out.summary = summary
  }
  return out
}

/**
 * 标注输入（#274 folder_suggest 同款隐私边界）：只有成员标题 + 标签单行
 * （每组 ≤30 行），从不进正文。行首 `GROUP <key> <n> 篇` 供批式解析定位键。
 */
function groupLabelLines(key: string, g: KnowledgeCluster, byId: Map<string, KnowledgeIndexDoc>): string[] {
  const lines = [`GROUP ${key} ${g.ids.length} 篇`]
  for (const id of g.ids.slice(0, 30)) {
    const d = byId.get(id)
    if (!d) continue
    const tags = d.tags.slice(0, 3).filter(Boolean).join(",")
    lines.push(`- ${d.title}${tags ? ` [${tags}]` : ""}`)
  }
  return lines
}

/** 标注 prompt（批式一次调用覆盖全部分组；输出严格 JSON）。 */
export function buildGraphLabelPrompt(lines: string[]): { systemPrompt: string; userContent: string } {
  const systemPrompt = [
    "你在为知识库的自动分组写展示名与一句话摘要。",
    "只依据输入中的成员标题与标签，不要编造成员不存在的内容。",
    '输出严格 JSON 对象：{"<分组键>": {"name": "...", "summary": "..."}}，',
    `name 不超过 ${KNOWLEDGE_GRAPH_LABEL_NAME_MAX} 字，summary 不超过 ${KNOWLEDGE_GRAPH_LABEL_SUMMARY_MAX} 字，summary 可省略。`,
    "除 JSON 外不要输出任何文字。",
  ].join("\n")
  const userContent = sanitizeLabelLine(lines.join("\n"))
  return { systemPrompt, userContent }
}

/** 解析 LLM 标注输出：容忍前后噪声文本；任何条目形状不符 → null（整体回退）。 */
export function parseGraphLabels(raw: string): Record<string, { name: string; summary?: string }> | null {
  if (!raw) return null
  const start = raw.indexOf("{")
  const end = raw.lastIndexOf("}")
  if (start < 0 || end <= start) return null
  let parsed: unknown
  try {
    parsed = JSON.parse(raw.slice(start, end + 1))
  } catch {
    return null
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null
  const out: Record<string, { name: string; summary?: string }> = {}
  for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
    if (!k || !v || typeof v !== "object" || Array.isArray(v)) return null
    const entry = v as { name?: unknown; summary?: unknown }
    if (typeof entry.name !== "string" || !entry.name.trim()) return null
    if (entry.summary !== undefined && typeof entry.summary !== "string") return null
    out[k] = { name: entry.name, ...(entry.summary !== undefined ? { summary: entry.summary } : {}) }
  }
  return Object.keys(out).length > 0 ? out : null
}

// --- #427 LLM 整理 lane：prompt / 解析 / 校验归一化 / 剪枝（spec §3.2/§3.3/§5） ---

/**
 * organize 输入（#427 spec §3.2 隐私边界）：每篇 title + tags(≤3) + description
 * （均已在派生索引，description 是 frontmatter 字段而非正文），从不进 .md 正文。
 * 锁组名单作为禁区进 prompt（§5：锁成员不得出现在分组输出里）。
 */
export function buildGraphOrganizePrompt(
  docs: KnowledgeIndexDoc[],
  lock?: KnowledgeGraphLockSection,
): { systemPrompt: string; userContent: string } {
  const lines: string[] = []
  for (const d of docs) {
    const tags = d.tags.slice(0, 3).filter(Boolean).join(",")
    lines.push(
      `DOC ${d.id} | ${d.title}${tags ? ` | tags: ${tags}` : ""}${d.description ? ` | ${d.description}` : ""}`,
    )
  }
  if (lock && lock.groups.length > 0) {
    lines.push("")
    lines.push("已锁定分组（禁区：其成员不得出现在你的分组输出里）：")
    for (const g of lock.groups) lines.push(`- ${g.name}: ${g.ids.join(", ")}`)
  }
  const systemPrompt = [
    "你在为一个小型知识库做整理：把明显同主题的文档分组，并指出文档两两之间的关联。",
    "只能使用输入中 DOC 行第一列的 id，不得编造 id；一篇文档至多属于一个分组；只有一篇的分组不要输出。",
    "没有把握就不要输出——不分组、不编关联，诚实优于编造。",
    "已锁定分组的成员是禁区，不得出现在你的分组输出里。",
    '输出严格 JSON：{"groups": [{"name": "…", "summary": "…", "ids": ["…"]}], "relations": [{"a": "…", "b": "…", "reason": "…", "confidence": 0.0}]}',
    `name 不超过 ${KNOWLEDGE_GRAPH_LABEL_NAME_MAX} 字；summary 不超过 ${KNOWLEDGE_GRAPH_LABEL_SUMMARY_MAX} 字，可省略；`,
    `reason 不超过 ${KNOWLEDGE_GRAPH_RELATION_REASON_MAX} 字且必填；confidence 取 0 到 1；两个数组都要输出（可为空数组）。`,
    "除 JSON 外不要输出任何文字。",
  ].join("\n")
  return { systemPrompt, userContent: sanitizeLabelLine(lines.join("\n")) }
}

/** organize LLM 输出的解析形状（语义校验在 normalize；此处只管形状零容忍）。 */
export type GraphOrganizeParsed = {
  groups: Array<{ name: string; summary?: string; ids: string[] }>
  relations: Array<{ a: string; b: string; reason: string; confidence: number }>
}

/**
 * 解析 organize 输出（#427 spec §3.2）：容忍前后噪声文本，形状零容忍
 * （parseGraphLabels 同款纪律）——groups/relations 缺一或任何条目形状不符 → null。
 * confidence 此处只要求 typeof number（NaN/Infinity 留给 normalize 按池丢弃）。
 */
export function parseGraphOrganize(raw: string): GraphOrganizeParsed | null {
  if (!raw) return null
  const start = raw.indexOf("{")
  const end = raw.lastIndexOf("}")
  if (start < 0 || end <= start) return null
  let parsed: unknown
  try {
    parsed = JSON.parse(raw.slice(start, end + 1))
  } catch {
    return null
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null
  const obj = parsed as { groups?: unknown; relations?: unknown }
  if (!Array.isArray(obj.groups) || !Array.isArray(obj.relations)) return null
  const groups: GraphOrganizeParsed["groups"] = []
  for (const g of obj.groups) {
    if (!g || typeof g !== "object" || Array.isArray(g)) return null
    const e = g as { name?: unknown; summary?: unknown; ids?: unknown }
    if (typeof e.name !== "string" || !e.name.trim()) return null
    if (!Array.isArray(e.ids) || e.ids.length === 0) return null
    for (const id of e.ids) if (typeof id !== "string" || !id) return null
    if (e.summary !== undefined && typeof e.summary !== "string") return null
    groups.push({ name: e.name, ...(e.summary !== undefined ? { summary: e.summary } : {}), ids: [...e.ids] })
  }
  const relations: GraphOrganizeParsed["relations"] = []
  for (const r of obj.relations) {
    if (!r || typeof r !== "object" || Array.isArray(r)) return null
    const e = r as { a?: unknown; b?: unknown; reason?: unknown; confidence?: unknown }
    if (typeof e.a !== "string" || !e.a || typeof e.b !== "string" || !e.b) return null
    if (typeof e.reason !== "string") return null
    if (typeof e.confidence !== "number") return null
    relations.push({ a: e.a, b: e.b, reason: e.reason, confidence: e.confidence })
  }
  return { groups, relations }
}

/** organize 归一化结果（分池回退标志供测试与诊断；产物直接可入 graph_llm 缓存）。 */
export type GraphOrganizeNormalized = {
  groups: KnowledgeGraphGroupEntry[]
  relations: KnowledgeGraphRelationEntry[]
  groupPoolFallback: boolean
  relationPoolFallback: boolean
}

/**
 * 校验与归一化（#427 spec §3.2 逐字）：
 * - 组：clamp 同款钳制；ids 必须现存（任一亡 id → 整条结构性无效）；每篇至多
 *   属一组（重复归属后出现的整条作废）；锁成员剥离；剥离/原本后 <2 篇 → 进
 *   未分组（预期归一化，**不计入丢弃分子**）。
 * - 关联：a/b 现存且不等；reason 必填（净化后按码点切 ≤80 字，空同罪）；
 *   confidence 钳 [0,1]（非有限数值 = 结构性无效）；无序对去重留高分。
 * - 截断两段式（顺序钉死）：先每端点度数 confidence 降序 ≤3，再全图
 *   confidence 降序 ≤ min(12, 3×n)。
 * - 丢弃率分池判定：分子 = 结构性无效条目 / 分母 = LLM 原始输出条数；
 *   任一池 >50% → 该池整体回退，不连坐另一池。
 */
export function normalizeGraphOrganize(
  parsed: GraphOrganizeParsed,
  liveIds: Set<string>,
  lockedIds: Set<string>,
): GraphOrganizeNormalized {
  const groupDenominator = parsed.groups.length
  let groupInvalid = 0
  const groups: KnowledgeGraphGroupEntry[] = []
  const assigned = new Set<string>()
  for (const g of parsed.groups) {
    const clamped = clampKnowledgeGraphLabelEntry(g)
    if (!clamped) {
      groupInvalid += 1
      continue
    }
    const ids: string[] = []
    let dead = false
    for (const id of g.ids) {
      if (!liveIds.has(id)) {
        dead = true
        break
      }
      if (!ids.includes(id)) ids.push(id)
    }
    if (dead) {
      groupInvalid += 1
      continue
    }
    if (ids.some((id) => assigned.has(id))) {
      groupInvalid += 1
      continue
    }
    const free = ids.filter((id) => !lockedIds.has(id))
    if (free.length < 2) continue // 单成员组进未分组——预期归一化，不计分子
    for (const id of free) assigned.add(id)
    groups.push({
      ids: free,
      name: clamped.name,
      ...(clamped.summary !== undefined ? { summary: clamped.summary } : {}),
    })
  }
  const groupPoolFallback =
    groupDenominator > 0 && groupInvalid / groupDenominator > KNOWLEDGE_GRAPH_POOL_DISCARD_FALLBACK

  const relDenominator = parsed.relations.length
  let relInvalid = 0
  const valid: Array<{ a: string; b: string; reason: string; confidence: number }> = []
  for (const r of parsed.relations) {
    if (!liveIds.has(r.a) || !liveIds.has(r.b) || r.a === r.b || !Number.isFinite(r.confidence)) {
      relInvalid += 1
      continue
    }
    const reason = Array.from(sanitizeLabelLine(r.reason))
      .slice(0, KNOWLEDGE_GRAPH_RELATION_REASON_MAX)
      .join("")
      .trim()
    if (!reason) {
      relInvalid += 1
      continue
    }
    const flip = compareCodepoint(r.a, r.b) < 0
    valid.push({
      a: flip ? r.a : r.b,
      b: flip ? r.b : r.a,
      reason,
      confidence: Math.min(1, Math.max(0, r.confidence)),
    })
  }
  const relationPoolFallback =
    relDenominator > 0 && relInvalid / relDenominator > KNOWLEDGE_GRAPH_POOL_DISCARD_FALLBACK

  let relations: KnowledgeGraphRelationEntry[] = []
  if (!relationPoolFallback) {
    valid.sort(
      (x, y) => y.confidence - x.confidence || compareCodepoint(x.a, y.a) || compareCodepoint(x.b, y.b),
    )
    const seen = new Set<string>()
    const deduped: typeof valid = []
    for (const r of valid) {
      const k = `${r.a}|${r.b}`
      if (seen.has(k)) continue
      seen.add(k)
      deduped.push(r)
    }
    const degree = new Map<string, number>()
    const perNode: typeof valid = []
    for (const r of deduped) {
      const da = degree.get(r.a) || 0
      const db = degree.get(r.b) || 0
      if (da >= KNOWLEDGE_GRAPH_RELATIONS_PER_NODE || db >= KNOWLEDGE_GRAPH_RELATIONS_PER_NODE) continue
      degree.set(r.a, da + 1)
      degree.set(r.b, db + 1)
      perNode.push(r)
    }
    relations = perNode.slice(0, Math.min(KNOWLEDGE_GRAPH_RELATIONS_CAP, 3 * liveIds.size))
  }

  return {
    groups: groupPoolFallback ? [] : groups,
    relations,
    groupPoolFallback,
    relationPoolFallback,
  }
}

/**
 * 渲染前剪枝 graph_llm 缓存（#427 spec §3.3）：亡 id 剔除、组缩到 <2 解散。
 * 只影响当帧渲染，不落盘（缓存由下一次 organize 整体替换）。
 */
export function pruneGraphLlmSection(
  section: KnowledgeGraphLlmSection,
  liveIds: Set<string>,
): KnowledgeGraphLlmSection {
  return {
    fingerprint: section.fingerprint,
    stale: section.stale,
    groups: section.groups
      .map((g) => ({ ...g, ids: g.ids.filter((id) => liveIds.has(id)) }))
      .filter((g) => g.ids.length >= 2),
    relations: section.relations.filter((r) => liveIds.has(r.a) && liveIds.has(r.b)),
  }
}

/**
 * 锁剪枝（#427 spec §5）：成员只减不增；<2 篇 → 解散（dissolved 带组名，
 * 引擎写回剪枝后的锁 → 一次性提示不重现）。
 */
export function pruneGraphLock(
  lock: KnowledgeGraphLockSection,
  liveIds: Set<string>,
): { lock: KnowledgeGraphLockSection; dissolved: string[] } {
  const groups: KnowledgeGraphGroupEntry[] = []
  const dissolved: string[] = []
  for (const g of lock.groups) {
    const ids = g.ids.filter((id) => liveIds.has(id))
    if (ids.length < 2) {
      dissolved.push(g.name)
      continue
    }
    groups.push({ ...g, ids })
  }
  return { lock: { groups }, dissolved }
}

```

### FULL companion/tests/knowledge-graph-organize.test.ts
```
// #427: 低语料图谱 LLM 整理 lane E2E（spec §3.1/§3.2/§3.3/§4/§5/§6 服务端半边）
// 覆盖：organize happy path + 缓存落盘、缓存命中 0 调用、语料漂移 stale、
// 失败不静默（organize_error + 旧缓存保留）、parse 失败、未配置 LLM、
// user_gesture 双闸、summoner 拒绝、n≥20 no-op、lock/unlock round-trip、
// 锁缩容/解散（pi 终验 2）、ack_tf_switch、重启+漂移区携带、single-flight。

import test, { after, before } from "node:test"
import assert from "node:assert/strict"
import * as fs from "fs"
import * as os from "os"
import * as path from "path"

const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "cmspark-k-org-"))
process.env.HOME = tempHome
process.env.CMSPARK_DATA_DIR = path.join(tempHome, ".cmspark-agent")
delete process.env.DEEPSEEK_API_KEY

let initDataDir: typeof import("../src/config").initDataDir
let DATA_DIR: string
let saveConfig: (c: Record<string, unknown>) => unknown
let getConfigDir: typeof import("../src/config").getConfigDir
let SkillEngine: typeof import("../src/skills/skill-engine").SkillEngine
let clusters: typeof import("../src/skills/knowledge-clusters")
let kg: typeof import("../src/skills/knowledge-graph")
let handleMessage: typeof import("../src/message-router").handleMessage
let __testSetKnowledgeGraphOrganizeImpl: typeof import("../src/message-router").__testSetKnowledgeGraphOrganizeImpl

before(async () => {
  const configMod = await import("../src/config")
  initDataDir = configMod.initDataDir
  DATA_DIR = configMod.DATA_DIR
  saveConfig = configMod.saveConfig as never
  getConfigDir = configMod.getConfigDir
  SkillEngine = (await import("../src/skills/skill-engine")).SkillEngine
  clusters = await import("../src/skills/knowledge-clusters")
  kg = await import("../src/skills/knowledge-graph")
  const mr = await import("../src/message-router")
  handleMessage = mr.handleMessage
  __testSetKnowledgeGraphOrganizeImpl = mr.__testSetKnowledgeGraphOrganizeImpl
  await initDataDir()
  saveConfig({ llm: { api_key: "sk-test-org", base_url: "http://127.0.0.1:9/v1", model_name: "test-model" } })
})

after(() => {
  __testSetKnowledgeGraphOrganizeImpl()
  fs.rmSync(tempHome, { recursive: true, force: true })
})

const panel = { surface: "panel", sendToExtension: () => {} } as never

function mdDoc(name: string, tags: string[], body: string, description = ""): string {
  return `---\nname: ${name}\ndescription: ${description}\ntags: [${tags.join(", ")}]\ntype: domain_knowledge\n---\n${body}\n`
}

/** n 篇同主题（共享 tag + 正文词 + description），body 带 SECRETBODYTOKEN 供隐私断言。 */
function seedGroup(se: InstanceType<typeof SkillEngine>, n: number, prefix = "doc"): string[] {
  const names: string[] = []
  for (let i = 0; i < n; i++) {
    const name = `${prefix}-${String(i).padStart(3, "0")}`
    names.push(name)
    se.importKnowledge(
      mdDoc(name, ["主题A", `t${i}`], `主题A shared body words SECRETBODYTOKEN9999 unique${i} more text`, `第${i}篇描述`),
    )
  }
  return names
}

function seedOrthogonal(se: InstanceType<typeof SkillEngine>, n: number, prefix: string): string[] {
  const names: string[] = []
  for (let i = 0; i < n; i++) {
    const name = `${prefix}-${String(i).padStart(3, "0")}`
    names.push(name)
    se.importKnowledge(mdDoc(name, [`${prefix}t${i}`], `${prefix} lone body unique${prefix}${i}`, `${prefix}描述${i}`))
  }
  return names
}

function resetKnowledgeState(): void {
  fs.rmSync(path.join(DATA_DIR, "knowledge"), { recursive: true, force: true })
  fs.rmSync(clusters.knowledgeIndexPath(), { force: true })
}

async function settle(ms = 10): Promise<void> {
  await new Promise((r) => setTimeout(r, ms))
}

let configMtimeSeed = Date.now()
/** saveConfig 拒清 api_key —— 直写 config.json + utimes 让 getConfig 重载（诚实模拟未配置）。 */
function setLlmConfigured(configured: boolean): void {
  if (configured) {
    saveConfig({ llm: { api_key: "sk-test-org", base_url: "http://127.0.0.1:9/v1", model_name: "test-model" } })
    return
  }
  const configPath = path.join(getConfigDir(), "config.json")
  const cur = fs.existsSync(configPath) ? JSON.parse(fs.readFileSync(configPath, "utf-8")) : {}
  cur.llm = { ...(cur.llm || {}), api_key: "" }
  fs.writeFileSync(configPath, JSON.stringify(cur, null, 2))
  configMtimeSeed += 1000
  fs.utimesSync(configPath, new Date(configMtimeSeed), new Date(configMtimeSeed))
}

type OrganizeFrame = {
  type: string
  status: string
  relations?: Array<{ a: string; b: string; reason: string; confidence: number; ai: true }>
  labels: Record<string, { name: string; summary?: string; ai: boolean; locked?: true }>
  nodes: Array<{ id: string; group_key: string }>
  llm_ready: boolean
  organize_error?: string
  organized?: boolean
  organizing?: boolean
  stale?: boolean
  lock_dissolved?: boolean
  tf_switch_notice?: boolean
}

function readIndex(): import("../src/skills/knowledge-clusters").KnowledgeIndexFile | null {
  return clusters.readKnowledgeIndexFile(clusters.knowledgeIndexPath())
}

for (const outcome of ["success", "failure"] as const) {
  test(`#490 organize lifecycle: initial/refresh/rebuilding busy, ${outcome} completion idle`, async () => {
    resetKnowledgeState()
    const se = new SkillEngine()
    seedGroup(se, 3, `lifecycle-${outcome}`)
    const docs = se.getKnowledgeDocsForOrganize()
    const ids = docs.map((d) => d.id)
    const rawResult = JSON.stringify({ groups: [{ name: "完成分组", ids }], relations: [] })
    if (outcome === "failure") {
      // Reorganizing an existing cache must remain busy even though organized is true.
      const normalized = kg.normalizeGraphOrganize(kg.parseGraphOrganize(rawResult)!, new Set(ids), new Set())
      se.setKnowledgeGraphLlmSection({
        fingerprint: kg.computeGraphLlmFingerprint(docs),
        groups: normalized.groups,
        relations: normalized.relations,
        stale: false,
      })
    }
    let release!: (value: string) => void
    let reject!: (error: Error) => void
    const pending = new Promise<string>((resolve, fail) => { release = resolve; reject = fail })
    __testSetKnowledgeGraphOrganizeImpl(() => pending)
    let complete!: (frame: OrganizeFrame) => void
    const completed = new Promise<OrganizeFrame>((resolve) => { complete = resolve })
    const session = { surface: "panel", sendToExtension: complete } as never
    const context = { skillEngine: se } as never
    const initial = await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, context, session) as OrganizeFrame
    const intermediate = await handleMessage({ type: "knowledge.graph" }, context, session) as OrganizeFrame
    const getGraph = se.getKnowledgeGraph
    let rebuilding: OrganizeFrame
    try {
      se.getKnowledgeGraph = () => null
      rebuilding = await handleMessage({ type: "knowledge.graph" }, context, session) as OrganizeFrame
    } finally {
      se.getKnowledgeGraph = getGraph
    }
    if (outcome === "failure") reject(new Error("fixture organize failure"))
    else release(rawResult)
    const final = await completed
    const after = await handleMessage({ type: "knowledge.graph" }, context, session) as OrganizeFrame
    // Optional reusable fixture: serialize actual handler responses and push, never guessed wire fields.
    const artifactDir = process.env.CMSPARK_TEST_GRAPH_ARTIFACT_DIR
    if (artifactDir) {
      fs.mkdirSync(artifactDir, { recursive: true })
      fs.writeFileSync(path.join(artifactDir, `organize-${outcome}-frames.json`), JSON.stringify({ initial, intermediate, rebuilding, final, after }, null, 2) + "\n")
    }
    assert.equal(initial.organizing, true, "initial graph ACK does not complete the organize operation")
    assert.equal(intermediate.organizing, true, "read-only refresh observes the in-flight operation")
    assert.equal(rebuilding.status, "rebuilding")
    assert.equal(rebuilding.organizing, true, "index unavailability must not clear the operation state")
    assert.equal(final.organizing, false, "settled push clears busy state before serialization")
    assert.equal(after.organizing, false)
    assert.equal(final.status, "ok", "organize failure preserves the readable graph")
    assert.equal(final.organized, true)
    if (outcome === "failure") {
      assert.equal(initial.organized, true)
      assert.equal(final.organize_error, "AI 整理失败，请重试")
    } else {
      assert.equal(initial.organized, undefined)
      assert.equal(final.organize_error, undefined)
    }
  })
}

test("#427 AC-1: organize happy path——首响应无产物，settle 推帧带 relations + l: 分组，缓存落盘", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 4)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id).sort()
  assert.equal(ids.length, 4)

  let calls = 0
  let userContent = ""
  const sent: OrganizeFrame[] = []
  __testSetKnowledgeGraphOrganizeImpl(async ({ userContent: uc }) => {
    calls += 1
    userContent = uc
    return JSON.stringify({
      groups: [{ name: "主题A 组", summary: "四篇同主题", ids }],
      relations: [{ a: ids[0], b: ids[1], reason: "同主题互证", confidence: 0.9 }],
    })
  })
  const sess = { surface: "panel", sendToExtension: (d: OrganizeFrame) => sent.push(d) } as never
  const first = (await handleMessage(
    { type: "knowledge.graph", organize: true, user_gesture: true },
    { skillEngine: se } as never,
    sess,
  )) as OrganizeFrame
  assert.equal(first.status, "ok")
  assert.equal(first.llm_ready, true)
  assert.equal(first.relations, undefined, "首响应无缓存：relations 整体省略（缺字段 ≠ 空数组，pi MAJOR-1）")
  assert.equal(first.organized, undefined)
  assert.equal(first.organize_error, undefined)

  // 隐私（§3.2）：prompt 只有 title/tags/description，正文绝不进
  await settle()
  assert.equal(calls, 1)
  assert.ok(userContent.includes(`DOC ${ids[0]} |`))
  assert.ok(userContent.includes("第0篇描述"), "description 进 prompt（frontmatter 字段非正文）")
  assert.equal(userContent.includes("SECRETBODYTOKEN9999"), false, "doc bodies must not leak into the organize prompt")

  const pushes = sent.filter((m) => m.type === "knowledge.graph")
  assert.ok(pushes.length > 0, "organize 完成必须推帧")
  const last = pushes[pushes.length - 1]
  assert.equal(last.status, "ok")
  assert.equal(last.organize_error, undefined)
  assert.equal(last.organized, true, "缓存落盘后 organized:true")
  assert.equal(last.relations!.length, 1)
  assert.equal(last.relations![0].ai, true)
  assert.equal(last.relations![0].reason, "同主题互证")
  assert.equal(last.relations![0].confidence, 0.9)
  const lKey = kg.lGroupKey(ids)
  assert.equal(last.labels[lKey].name, "主题A 组")
  assert.equal(last.labels[lKey].ai, true)
  assert.equal(last.labels[lKey].locked, undefined, "organize 产物不是锁")
  assert.ok(last.nodes.every((n) => n.group_key === lKey))

  // 缓存落盘：graph_llm 区，fingerprint = 当前 docs 聚合，stale false
  const idx = readIndex()
  assert.ok(idx?.graph_llm)
  assert.equal(idx!.graph_llm!.groups.length, 1)
  assert.deepEqual([...idx!.graph_llm!.groups[0].ids].sort(), ids)
  assert.equal(idx!.graph_llm!.stale, false)
  assert.equal(idx!.graph_llm!.fingerprint, kg.computeGraphLlmFingerprint(se.getKnowledgeDocsForOrganize()))
})

test("#427 AC-2: 缓存命中 0 次 LLM；语料变化 → stale 仍渲染旧缓存且不自动重跑", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 4)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id)
  let calls = 0
  __testSetKnowledgeGraphOrganizeImpl(async () => {
    calls += 1
    return JSON.stringify({ groups: [{ name: "组", ids }], relations: [{ a: ids[0], b: ids[1], reason: "r", confidence: 0.5 }] })
  })
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, panel)
  await settle()
  assert.equal(calls, 1)

  // 缓存命中：不再调 LLM
  const second = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(second.relations!.length, 1)
  assert.equal(calls, 1)

  // 语料变化（新增一篇）→ stale badge + 旧缓存照渲染 + 不自动重跑（手动唯一）
  se.importKnowledge(mdDoc("extra-doc", ["新tag"], "unrelated body words", "新描述"))
  const third = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(third.stale, true)
  assert.equal(third.relations!.length, 1, "stale 仍渲染旧缓存（不假装新鲜也不丢弃）")
  assert.equal(third.llm_ready, true)
  assert.equal(calls, 1)
  const idx = readIndex()
  assert.equal(idx!.graph_llm!.stale, false, "落盘缓存本身不写 stale（渲染时按指纹现算）")
})

test("#427 pi MAJOR-1: 合法空整理（groups:[]+relations:[]）→ organized:true + relations 在场空数组；无缓存帧两字段皆省略", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  // 4 篇互不相关：LLM 最可能合法判「无结构」——spec §4「诚实散点」主场景
  seedOrthogonal(se, 4, "orth")
  __testSetKnowledgeGraphOrganizeImpl(async () => JSON.stringify({ groups: [], relations: [] }))
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, panel)
  await settle()

  const idx = readIndex()
  assert.ok(idx?.graph_llm, "合法空结果也是成功的 organize，必须写缓存（否则 CTA 复发、AC-2 破功）")
  const frame = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(frame.status, "ok")
  assert.equal(frame.organized, true, "graph_llm 区存在即 true——空内容也是组织过")
  assert.ok(Array.isArray(frame.relations), "缓存帧 relations 在场（空数组 = 组织过但无关联）")
  assert.equal(frame.relations!.length, 0)
  assert.ok(frame.nodes.every((n) => n.group_key === "u:ungrouped"), "无结构 → 全未分组散点")

  // 无缓存对照帧：organized 与 relations 都不得在场（在场即会被 ext 误判有缓存）
  resetKnowledgeState()
  const se2 = new SkillEngine()
  seedOrthogonal(se2, 4, "orth")
  const bare = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se2 } as never, panel)) as OrganizeFrame
  assert.equal(bare.organized, undefined, "无缓存帧省略 organized")
  assert.equal(bare.relations, undefined, "无缓存帧整体省略 relations（不是空数组）")
})

test("#427 §4: organize 失败不静默——推 ok 帧 + organize_error，旧缓存原样保留", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id)
  const sent: OrganizeFrame[] = []
  const sess = { surface: "panel", sendToExtension: (d: OrganizeFrame) => sent.push(d) } as never
  let fail = false
  __testSetKnowledgeGraphOrganizeImpl(async () => {
    if (fail) throw new Error("llm down")
    return JSON.stringify({ groups: [{ name: "组", ids }], relations: [] })
  })
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, sess)
  await settle()
  const cached = readIndex()!.graph_llm!
  assert.equal(cached.groups.length, 1)

  // 再整理失败：错误进帧（不是 status:error），缓存不丢；文案中文（grok NIT-9）
  fail = true
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, sess)
  await settle()
  const pushes = sent.filter((m) => m.type === "knowledge.graph")
  const last = pushes[pushes.length - 1]
  assert.equal(last.status, "ok", "organize 失败 ≠ 图谱加载失败（#356 error 帧合同不修订）")
  assert.equal(last.organize_error, "AI 整理失败，请重试", "raw 错误（llm down）只进日志不上帧")
  assert.equal(last.lock_dissolved, undefined)
  const after = readIndex()!.graph_llm!
  assert.deepEqual(after, cached, "失败不得抹掉有效缓存")

  // 下次请求：旧缓存照常服务，错误条不残留
  const next = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(next.organize_error, undefined)
  assert.ok(next.nodes.some((n) => n.group_key.startsWith("l:")), "旧分组仍着色")
})

test("#427 §3.2: parse 失败 → organize_error 中文文案，无缓存写入", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  const sent: OrganizeFrame[] = []
  const sess = { surface: "panel", sendToExtension: (d: OrganizeFrame) => sent.push(d) } as never
  __testSetKnowledgeGraphOrganizeImpl(async () => "前置垃圾 not json 后置")
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, sess)
  await settle()
  const last = sent.filter((m) => m.type === "knowledge.graph").pop()!
  assert.equal(last.organize_error, "AI 整理返回无法解析，请重试", "graph_organize_parse_failed 原文不上帧")
  assert.equal(readIndex()?.graph_llm, undefined, "parse 失败不落缓存")
})

test("#427 §3.1: 未配置 LLM → llm_ready:false + organize_error，impl 不被调", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  let calls = 0
  __testSetKnowledgeGraphOrganizeImpl(async () => {
    calls += 1
    return "{}"
  })
  setLlmConfigured(false)
  try {
    const resp = (await handleMessage(
      { type: "knowledge.graph", organize: true, user_gesture: true },
      { skillEngine: se } as never,
      panel,
    )) as OrganizeFrame
    assert.equal(resp.status, "ok")
    assert.equal(resp.llm_ready, false, "llm_ready 缺省为 true 是 ext 侧约定；companion 必须显式 false")
    assert.equal(resp.organize_error, "AI 未配置，无法整理")
    await settle()
    assert.equal(calls, 0)
  } finally {
    setLlmConfigured(true)
  }
})

test("#427 双闸（grok M-1 修复）：缺 user_gesture 全拒，但不走红 error——ok 帧 + organize_error，画布不死者", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  const verbs: Array<Record<string, unknown>> = [
    { type: "knowledge.graph", organize: true },
    { type: "knowledge.graph", lock_group: "l:x" },
    { type: "knowledge.graph", unlock_group: "l:x" },
    { type: "knowledge.graph", ack_tf_switch: true },
  ]
  for (const msg of verbs) {
    const resp = (await handleMessage(msg, { skillEngine: se } as never, panel)) as OrganizeFrame
    // M-1 回归核心：ext knowledgeGraphErrorById 会把在途请求的 type:error 打成
    // #356 死面板——动作拒绝必须是 knowledge.graph ok 帧 + 帧级错误条
    assert.notEqual(resp.type, "error", "动作拒绝不得走红 error（#356 死面板缝）")
    assert.equal(resp.type, "knowledge.graph")
    assert.equal(resp.status, "ok")
    assert.ok(resp.nodes.length > 0, "画布照常渲染（节点在）")
    assert.match(String(resp.organize_error), /user_gesture/)
  }
  // 拒绝 = 动作不执行：无缓存写入、无锁条目、无 ack 落盘
  const idx = readIndex()
  assert.equal(idx?.graph_llm, undefined)
  assert.equal(idx?.graph_lock, undefined)
  assert.notEqual(idx?.graph_tf_switch_ack, true)
})

test("#427 surface 门：summoner 连 organize/lock 一起拒", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  for (const msg of [
    { type: "knowledge.graph", organize: true, user_gesture: true },
    { type: "knowledge.graph", lock_group: "l:x", user_gesture: true },
    { type: "knowledge.graph", ack_tf_switch: true, user_gesture: true },
  ]) {
    const resp = await handleMessage(msg, { skillEngine: se } as never, { surface: "summoner", sendToExtension: () => {} } as never)
    assert.equal(resp.type, "error")
    assert.match(String(resp.error), /panel/)
  }
})

test("#427 AC-7: n≥20 organize no-op——impl 不调，relations 字段不上帧", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 20)
  let calls = 0
  __testSetKnowledgeGraphOrganizeImpl(async () => {
    calls += 1
    return "{}"
  })
  const resp = (await handleMessage(
    { type: "knowledge.graph", organize: true, user_gesture: true },
    { skillEngine: se } as never,
    panel,
  )) as OrganizeFrame
  assert.equal(resp.status, "ok")
  assert.equal(resp.relations, undefined, "≥20 帧永不携带 relations（客户端漏藏按钮也偷渡不进）")
  assert.equal(resp.organize_error, undefined)
  await settle()
  assert.equal(calls, 0)
  assert.equal(resp.tf_switch_notice, false, "无 LLM 历史 → 无跨 20 notice")
})

test("#427 §5: lock_group/unlock_group round-trip——locked 标、graph_lock 落盘、幂等", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 4)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id).sort()
  __testSetKnowledgeGraphOrganizeImpl(async () => JSON.stringify({ groups: [{ name: "主题A 组", summary: "摘要", ids }], relations: [] }))
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, panel)
  await settle()
  const lKey = kg.lGroupKey(ids)

  const locked = (await handleMessage(
    { type: "knowledge.graph", lock_group: lKey, user_gesture: true },
    { skillEngine: se } as never,
    panel,
  )) as OrganizeFrame
  assert.equal(locked.status, "ok")
  assert.ok(locked.nodes.every((n) => n.group_key === lKey))
  assert.equal(locked.labels[lKey].locked, true)
  assert.equal(locked.labels[lKey].ai, true)
  assert.equal(locked.labels[lKey].name, "主题A 组")
  const lockOnDisk = readIndex()!.graph_lock
  assert.ok(lockOnDisk)
  assert.deepEqual(lockOnDisk!.groups[0].ids, ids, "成员快照 = 锁时刻的渲染真值")
  assert.equal(lockOnDisk!.groups[0].summary, "摘要")

  // 解锁：锁区清空；分组本身还在（organize 缓存仍是结构）
  const unlocked = (await handleMessage(
    { type: "knowledge.graph", unlock_group: lKey, user_gesture: true },
    { skillEngine: se } as never,
    panel,
  )) as OrganizeFrame
  assert.equal(unlocked.labels[lKey].locked, undefined)
  assert.equal(unlocked.labels[lKey].ai, true, "解锁后回到 LLM 分组着色")
  assert.equal(readIndex()?.graph_lock, undefined)
  // 幂等：再解一次 no-op 成功
  const again = await handleMessage({ type: "knowledge.graph", unlock_group: lKey, user_gesture: true }, { skillEngine: se } as never, panel)
  assert.equal(again.status, "ok")
})

test("#427 §5 + grok M-1: lock_group 拒未分组堆/未知键——ok 帧 + 中文 organize_error，画布不死者", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  const ungrouped = (await handleMessage(
    { type: "knowledge.graph", lock_group: "u:ungrouped", user_gesture: true },
    { skillEngine: se } as never,
    panel,
  )) as OrganizeFrame
  assert.notEqual(ungrouped.type, "error", "锁失败不得走红 error（#356 死面板缝）")
  assert.equal(ungrouped.status, "ok")
  assert.ok(ungrouped.nodes.length > 0, "画布照常渲染")
  assert.match(String(ungrouped.organize_error), /未分组/)

  const unknown = (await handleMessage(
    { type: "knowledge.graph", lock_group: "l:deadbeef", user_gesture: true },
    { skillEngine: se } as never,
    panel,
  )) as OrganizeFrame
  assert.notEqual(unknown.type, "error")
  assert.equal(unknown.status, "ok")
  assert.ok(unknown.nodes.length > 0)
  assert.match(String(unknown.organize_error), /不存在|不足/)

  // 拒绝 = 不落锁条目
  assert.equal(readIndex()?.graph_lock, undefined)
})

test("#427 §5 + pi 终验 2: 锁缩容——同锁条目跨删除仍生效（键随成员变），<2 解散一次性提示", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 4)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id).sort()
  __testSetKnowledgeGraphOrganizeImpl(async () => JSON.stringify({ groups: [{ name: "锁源组", ids }], relations: [] }))
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, panel)
  await settle()
  const lKey4 = kg.lGroupKey(ids)
  await handleMessage({ type: "knowledge.graph", lock_group: lKey4, user_gesture: true }, { skillEngine: se } as never, panel)

  // 删 1 篇：锁缩到 3，仍生效——渲染键随成员集变化，同一条目
  se.deleteKnowledge(ids[3])
  const g3 = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  const lKey3 = kg.lGroupKey([ids[0], ids[1], ids[2]])
  assert.notEqual(lKey3, lKey4, "缩容后 l:hash 已变")
  assert.ok(g3.nodes.filter((n) => n.id !== undefined && [ids[0], ids[1], ids[2]].includes(n.id)).every((n) => n.group_key === lKey3), "同一锁仍把剩余成员锁成一组")
  assert.equal(g3.labels[lKey3].locked, true)
  assert.equal(g3.labels[lKey3].name, "锁源组", "锁的身份是条目：名字/摘要随条目存活")
  assert.equal(g3.lock_dissolved, undefined)
  assert.deepEqual(readIndex()!.graph_lock!.groups[0].ids.sort(), [ids[0], ids[1], ids[2]], "落盘锁条目已剪枝（键无关）")

  // 删到只剩 1 篇成员：解散——lock_dissolved 一次性 boolean
  se.deleteKnowledge(ids[2])
  se.deleteKnowledge(ids[1])
  const g1 = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(g1.lock_dissolved, true, "ext wire 合同：boolean（组名不上 wire）")
  assert.equal(readIndex()?.graph_lock, undefined, "解散锁已清（提示不重现）")
  const g1b = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(g1b.lock_dissolved, undefined)
})

test("#427 §6: 跨 20——notice 持续 true 直到显式 ack_tf_switch，之后 false", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 4)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id)
  __testSetKnowledgeGraphOrganizeImpl(async () => JSON.stringify({ groups: [{ name: "组", ids }], relations: [] }))
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, panel)
  await settle()

  // 语料长到 21：TF lane + graph_llm 历史在 → notice
  seedOrthogonal(se, 17, "zeta")
  const grown = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(grown.nodes.length, 21)
  assert.equal(grown.relations, undefined, "≥20 帧无 relations")
  assert.equal(grown.tf_switch_notice, true)
  const again = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(again.tf_switch_notice, true, "未 ack 前每帧都带（读路径不自动落 ack）")

  const acked = (await handleMessage(
    { type: "knowledge.graph", ack_tf_switch: true, user_gesture: true },
    { skillEngine: se } as never,
    panel,
  )) as OrganizeFrame
  assert.equal(acked.tf_switch_notice, false, "显式 false 抑制 ext 本地回退")
  assert.equal(readIndex()?.graph_tf_switch_ack, true)

  // 再长也不重现
  seedOrthogonal(se, 1, "eta")
  const post = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panel)) as OrganizeFrame
  assert.equal(post.tf_switch_notice, false)
})

test("#427 §3.3: 重启 + 磁盘漂移——graph_llm/graph_lock/ack 区携带到重建后的新索引", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 4)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id).sort()
  __testSetKnowledgeGraphOrganizeImpl(async () => JSON.stringify({ groups: [{ name: "组", ids }], relations: [{ a: ids[0], b: ids[1], reason: "r", confidence: 0.5 }] }))
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, panel)
  await settle()
  await handleMessage({ type: "knowledge.graph", lock_group: kg.lGroupKey(ids), user_gesture: true }, { skillEngine: se } as never, panel)
  await handleMessage({ type: "knowledge.graph", ack_tf_switch: true, user_gesture: true }, { skillEngine: se } as never, panel)

  // 绕过引擎直写磁盘（新 .md）：磁盘索引指纹 stale，重启后 ensure 必须重建
  fs.writeFileSync(
    path.join(DATA_DIR, "knowledge", "global", "raw-extra.md"),
    mdDoc("raw-extra", ["rawtag"], "raw lone body", "直写描述"),
    { mode: 0o600 },
  )

  const se2 = new SkillEngine()
  const resp = (await handleMessage({ type: "knowledge.graph" }, { skillEngine: se2 } as never, panel)) as OrganizeFrame
  assert.equal(resp.nodes.length, 5, "重建捕获直写文档")
  assert.equal(resp.relations!.length, 1, "graph_llm 区在重启+漂移重建后存活")
  assert.equal(resp.stale, true, "指纹已漂 → stale")
  const lKey = kg.lGroupKey(ids)
  assert.equal(resp.labels[lKey].locked, true, "graph_lock 区同样携带")
  const idx = readIndex()
  assert.equal(idx!.graph_tf_switch_ack, true, "ack 区携带")
})

test("#427 single-flight：在飞的 organize 不被并发请求复制", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedGroup(se, 3)
  const ids = se.getKnowledgeDocsForOrganize().map((d) => d.id)
  let calls = 0
  let release!: () => void
  const gate = new Promise<void>((r) => (release = r))
  __testSetKnowledgeGraphOrganizeImpl(async () => {
    calls += 1
    await gate
    return JSON.stringify({ groups: [{ name: "组", ids }], relations: [] })
  })
  const sess = { surface: "panel", sendToExtension: () => {} } as never
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, sess)
  await handleMessage({ type: "knowledge.graph", organize: true, user_gesture: true }, { skillEngine: se } as never, sess)
  release()
  await settle()
  assert.equal(calls, 1)
})

```

### FULL companion/tests/knowledge-graph.test.ts
```
// #296: knowledge.graph 服务端半边（spec §5 wire / §6 常数表 / §8 服务端测试清单）
// 覆盖：状态机（too_few / ok / over_cap / rebuilding）、over_cap 截取确定性 +
// 重跑分组 + truncated、边 top-5 + 对称去重 + 确定性、display round-trip 与
// 缺失容忍、surface 门（panel-only）、LLM 失败回退 + 长度钳制 + 重生成。

import test, { after, before } from "node:test"
import assert from "node:assert/strict"
import * as fs from "fs"
import * as os from "os"
import * as path from "path"

const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "cmspark-k-graph-"))
process.env.HOME = tempHome
process.env.CMSPARK_DATA_DIR = path.join(tempHome, ".cmspark-agent")
delete process.env.DEEPSEEK_API_KEY

let initDataDir: typeof import("../src/config").initDataDir
let DATA_DIR: string
let saveConfig: (c: Record<string, unknown>) => unknown
let SkillEngine: typeof import("../src/skills/skill-engine").SkillEngine
let kg: typeof import("../src/skills/knowledge-graph")
let clusters: typeof import("../src/skills/knowledge-clusters")
let handleMessage: typeof import("../src/message-router").handleMessage
let __testSetKnowledgeGraphLabelImpl: typeof import("../src/message-router").__testSetKnowledgeGraphLabelImpl
let validateWsMessage: typeof import("../src/ws/validate").validateWsMessage

before(async () => {
  const configMod = await import("../src/config")
  initDataDir = configMod.initDataDir
  DATA_DIR = configMod.DATA_DIR
  saveConfig = configMod.saveConfig as never
  SkillEngine = (await import("../src/skills/skill-engine")).SkillEngine
  kg = await import("../src/skills/knowledge-graph")
  clusters = await import("../src/skills/knowledge-clusters")
  const mr = await import("../src/message-router")
  handleMessage = mr.handleMessage
  __testSetKnowledgeGraphLabelImpl = mr.__testSetKnowledgeGraphLabelImpl
  validateWsMessage = (await import("../src/ws/validate")).validateWsMessage
  await initDataDir()
  // 过 knowledgeExtractLlmConfig 闸（impl 已被测试钩子替换，不走网络）
  saveConfig({ llm: { api_key: "sk-test-graph", base_url: "http://127.0.0.1:9/v1", model_name: "test-model" } })
})

after(() => {
  __testSetKnowledgeGraphLabelImpl()
  fs.rmSync(tempHome, { recursive: true, force: true })
})

type IndexDoc = import("../src/skills/knowledge-clusters").KnowledgeIndexDoc

function mkDoc(id: string, vec: Record<string, number>, tags: string[] = [], title = id): IndexDoc {
  return { id, name: id, title, tags, folder: "", bucket: "", vec }
}

function orthoDocs(prefix: string, n: number, titlePrefix = prefix): IndexDoc[] {
  const out: IndexDoc[] = []
  for (let i = 0; i < n; i++) {
    out.push(mkDoc(`${prefix}${String(i).padStart(3, "0")}`, { [`tok${prefix}${i}`]: 1 }, [], `${titlePrefix}${String(i).padStart(3, "0")}`))
  }
  return out
}

const panelSession = { surface: "panel", sendToExtension: () => {} } as never

function mdDoc(name: string, tags: string[], body: string, description = ""): string {
  return `---\nname: ${name}\ndescription: ${description}\ntags: [${tags.join(", ")}]\ntype: domain_knowledge\n---\n${body}\n`
}

/** 25 篇、5 个主题组（每组 5 篇共享 tag + 正文词）→ 聚类成 5 组。 */
function seedThemed(se: InstanceType<typeof SkillEngine>, n = 25, secretBody = false): void {
  const themes = ["alpha", "beta", "gamma", "delta", "epsilon"]
  for (let i = 0; i < n; i++) {
    const theme = themes[i % themes.length]
    const secret = secretBody && i === 0 ? " SECRETBODYTOKEN9999 " : " "
    se.importKnowledge(
      mdDoc(`doc-${String(i).padStart(3, "0")}`, [theme, `t${i}`], `${theme} shared body words ${theme} again and unique${i}${secret}more text`),
    )
  }
}

async function settle(ms = 10): Promise<void> {
  await new Promise((r) => setTimeout(r, ms))
}

/** 测试间共享 tempHome：每测前清知识目录 + 派生索引，引擎各自从零起步。 */
function resetKnowledgeState(): void {
  fs.rmSync(path.join(DATA_DIR, "knowledge"), { recursive: true, force: true })
  fs.rmSync(clusters.knowledgeIndexPath(), { force: true })
}

// --- 纯函数：状态机 + 着色来源 ---

test("#427 pure: n=0 → too_few；n=1 → 单节点 ok；2–19 → LLM lane ok 全未分组", () => {
  const zero = kg.buildKnowledgeGraph([])
  assert.equal(zero.status, "too_few")
  assert.equal(zero.truncated, false)
  assert.equal(zero.nodes.length, 0)
  assert.equal(zero.relations.length, 0)
  assert.equal(zero.llmLane, false)

  const single = kg.buildKnowledgeGraph([mkDoc("solo", { x: 1 })])
  assert.equal(single.status, "ok")
  assert.equal(single.nodes.length, 1)
  assert.equal(single.nodes[0].group_key, "u:ungrouped")
  assert.equal(single.labels["u:ungrouped"].name, "未分组")
  assert.equal(single.edges.length, 0)

  // 2–19 无缓存：散点是诚实结构（LLM lane，全部未分组，TF 边照算）
  const docs = orthoDocs("d", 19)
  const r = kg.buildKnowledgeGraph(docs)
  assert.equal(r.status, "ok")
  assert.equal(r.truncated, false)
  assert.equal(r.llmLane, true)
  assert.equal(r.nodes.length, 19)
  assert.ok(r.nodes.every((n) => n.group_key === "u:ungrouped"), "no cache → all ungrouped")
  assert.equal(Object.keys(r.labels).length, 1)
  assert.equal(r.labels["u:ungrouped"].name, "未分组")
  assert.equal(r.labels["u:ungrouped"].ai, false)
  assert.deepEqual(r.relations, [])
  assert.equal(r.organized, undefined, "无 graph_llm 缓存 → organized 缺席")
  assert.equal(r.labelTargets.length, 0, "LLM lane has no label targets (label 通道只服务 TF lane)")

  // pi MAJOR-1：缓存区存在（哪怕内容全空）→ organized:true——空结果 ≠ 无缓存
  const empty = kg.buildKnowledgeGraph(orthoDocs("e", 4), undefined, {
    llm: { groups: [], relations: [] },
  })
  assert.equal(empty.llmLane, true)
  assert.equal(empty.organized, true, "graph_llm 区存在即 true（合法空整理）")
  assert.deepEqual(empty.relations, [])
})

test("#296 pure: n≤200 group_key = 分布视图同一 key（同源聚类）", () => {
  const groupA = [1, 2, 3, 4].map((i) => mkDoc(`a${i}`, { alpha: 0.8, [`pa${i}`]: 0.2 }, ["sharedalpha"], `Alpha note ${i}`))
  const groupB = [1, 2, 3, 4].map((i) => mkDoc(`b${i}`, { gamma: 0.8, [`pb${i}`]: 0.2 }, ["sharedgamma"], `Gamma note ${i}`))
  const rest = orthoDocs("q", 14)
  const docs = [...groupA, ...groupB, ...rest]
  assert.equal(docs.length, 22)

  const r = kg.buildKnowledgeGraph(docs)
  assert.equal(r.status, "ok")
  assert.equal(r.truncated, false)
  assert.equal(r.nodes.length, 22)

  const dist = clusters.toDistributionChannel(clusters.buildKnowledgeDistribution(docs))
  if (!dist.groups.length) throw new Error("expected distribution groups")
  const distKeys = new Set(dist.groups.map((g) => g.key))
  const distKeyOf = new Map<string, string>()
  for (const g of dist.groups) for (const id of g.ids) distKeyOf.set(id, g.key)

  for (const node of r.nodes) {
    assert.ok(distKeys.has(node.group_key), `node ${node.id} group_key ${node.group_key} must be a distribution key`)
    const dk = distKeyOf.get(node.id)
    if (dk) assert.equal(node.group_key, dk, `node ${node.id} must sit in the same group as the distribution view`)
  }
  // a1 与 a2 同组
  const byId = new Map(r.nodes.map((n) => [n.id, n]))
  if (!byId.get("a1") || !byId.get("a2")) throw new Error("missing a1/a2")
  assert.equal(byId.get("a1")!.group_key, byId.get("a2")!.group_key)
  assert.notEqual(byId.get("a1")!.group_key, byId.get("b1")!.group_key)
  // 离群 → u:ungrouped
  assert.equal(byId.get("q000")!.group_key, "u:ungrouped")
  assert.equal(r.labels["u:ungrouped"].name, "未分组")
})

test("#296 pure: n≤200 ungrouped nodes get u:ungrouped + 未分组 label", () => {
  const groupA = [1, 2, 3].map((i) => mkDoc(`a${i}`, { alpha: 0.9, [`pa${i}`]: 0.1 }, ["sharedalpha"]))
  const rest = orthoDocs("q", 18)
  const r = kg.buildKnowledgeGraph([...groupA, ...rest])
  const ungrouped = r.nodes.filter((n) => n.group_key === "u:ungrouped")
  assert.equal(ungrouped.length, 18)
  assert.equal(r.labels["u:ungrouped"].name, "未分组")
  assert.equal(r.labels["u:ungrouped"].ai, false)
})

// --- 纯函数：边 ---

test("#296 pure: edges top-5 cap, score>0, symmetric dedup a<b, determinism", () => {
  // 星型：hub 与 8 个卫星共享 tag star；卫星彼此只有弱 jaccard
  const hub = mkDoc("hub1", { star: 1, hub: 1 }, ["star"], "Hub doc")
  const sats = Array.from({ length: 8 }, (_, i) =>
    mkDoc(`s${i}`, { star: 1, [`sat${i}`]: 1 }, ["star"], `Sat ${i}`),
  )
  const filler = orthoDocs("f", 11)
  const docs = [hub, ...sats, ...filler]
  assert.equal(docs.length, 20)

  const r1 = kg.buildKnowledgeGraph(docs)
  const r2 = kg.buildKnowledgeGraph([...docs].reverse())

  assert.equal(JSON.stringify(r2), JSON.stringify(r1), "same input (shuffled) → identical output")

  assert.equal(r1.status, "ok")
  assert.ok(r1.edges.length > 0, "star edges must exist")

  // hub 度 ≤ TOPK（8 个 >0 候选被截到 5）
  const hubDegree = r1.edges.filter((e) => e.a === "hub1" || e.b === "hub1").length
  assert.ok(hubDegree <= kg.KNOWLEDGE_GRAPH_EDGE_TOPK, `hub degree ${hubDegree} ≤ ${kg.KNOWLEDGE_GRAPH_EDGE_TOPK}`)

  const seen = new Set<string>()
  for (const e of r1.edges) {
    assert.ok(e.a < e.b, `edge must be normalized a<b: ${e.a} ${e.b}`)
    const k = `${e.a}|${e.b}`
    assert.ok(!seen.has(k), `duplicate undirected edge ${k}`)
    seen.add(k)
    assert.ok(e.score > 0, "edge score must be > 0")
  }
  // 排序确定性
  for (let i = 1; i < r1.edges.length; i++) {
    const p = r1.edges[i - 1]
    const c = r1.edges[i]
    assert.ok(p.a < c.a || (p.a === c.a && p.b < c.b), "edges sorted by (a,b)")
  }
})

// --- 纯函数：over_cap ---

test("#296 pure: n>200 → over_cap, title-lex first 200, recluster on truncated set, truncated:true, determinism", () => {
  const keepers = orthoDocs("k", 200, "k") // titles k000..k199
  // 组成员：k000,k001,k002 在截取集内；z901,z902 在集外（标题字典序更大）
  keepers[0] = mkDoc("k000", { grp: 0.9, u0: 0.1 }, ["grp"], "k000")
  keepers[1] = mkDoc("k001", { grp: 0.9, u1: 0.1 }, ["grp"], "k001")
  keepers[2] = mkDoc("k002", { grp: 0.9, u2: 0.1 }, ["grp"], "k002")
  const outsiders = [
    mkDoc("z901", { grp: 0.9, u3: 0.1 }, ["grp"], "z901"),
    mkDoc("z902", { grp: 0.9, u4: 0.1 }, ["grp"], "z902"),
    ...orthoDocs("z", 3, "z"),
  ]
  const docs = [...keepers, ...outsiders]
  assert.equal(docs.length, 205)

  const r1 = kg.buildKnowledgeGraph(docs)
  const r2 = kg.buildKnowledgeGraph([...docs].reverse())
  assert.equal(JSON.stringify(r2), JSON.stringify(r1), "over_cap truncation must be deterministic")

  assert.equal(r1.status, "over_cap")
  assert.equal(r1.truncated, true)
  assert.equal(r1.nodes.length, 200)
  const ids = new Set(r1.nodes.map((n) => n.id))
  assert.ok(ids.has("k000") && ids.has("k199"), "keepers in")
  assert.ok(!ids.has("z901") && !ids.has("z904"), "title-lex outsiders out")

  // 截取集重跑聚类：k000-k002 成组（成员恰为集内 3 篇，集外 2 篇不掺入）
  const gkey = r1.nodes.find((n) => n.id === "k000")
  if (!gkey) throw new Error("missing k000")
  assert.ok(gkey.group_key.startsWith("c:"), `in-set group expected, got ${gkey.group_key}`)
  const same = r1.nodes.filter((n) => n.group_key === gkey.group_key).map((n) => n.id).sort()
  assert.deepEqual(same, ["k000", "k001", "k002"])
  assert.ok(r1.labels[gkey.group_key], "in-set group has a fallback label")
  assert.equal(r1.labels[gkey.group_key].ai, false)
})

test("#296/#427 pure: constants per spec §6 / #427 §8", () => {
  assert.equal(kg.KNOWLEDGE_GRAPH_EDGE_TOPK, 5)
  assert.equal(kg.KNOWLEDGE_GRAPH_DOC_CAP, clusters.KNOWLEDGE_CLUSTER_DOC_CAP)
  assert.equal(kg.KNOWLEDGE_GRAPH_MIN_DOCS, 1)
  assert.equal(kg.KNOWLEDGE_GRAPH_LLM_LANE_MAX, clusters.KNOWLEDGE_CLUSTER_MIN_DOCS - 1)
  assert.equal(kg.KNOWLEDGE_GRAPH_LLM_LANE_MAX, 19)
  assert.equal(kg.KNOWLEDGE_GRAPH_RELATIONS_CAP, 12)
  assert.equal(kg.KNOWLEDGE_GRAPH_RELATIONS_PER_NODE, 3)
  assert.equal(kg.KNOWLEDGE_GRAPH_RELATION_REASON_MAX, 80)
  assert.equal(kg.KNOWLEDGE_GRAPH_ORGANIZE_TIMEOUT_MS, 30_000)
  assert.equal(kg.KNOWLEDGE_GRAPH_LABEL_NAME_MAX, 20)
  assert.equal(kg.KNOWLEDGE_GRAPH_LABEL_SUMMARY_MAX, 280)
})

// --- 解析 / 钳制 ---

test("#296 parseGraphLabels: strict-ish JSON with surrounding noise; malformed → null", () => {
  const ok = kg.parseGraphLabels('前置说明 {"c:k1": {"name": "退款组", "summary": "s"}, "c:k2": {"name": "n2"}} 后置')
  if (!ok) throw new Error("expected parse")
  assert.equal(ok["c:k1"].name, "退款组")
  assert.equal(ok["c:k2"].summary, undefined)
  assert.equal(kg.parseGraphLabels("not json at all"), null)
  assert.equal(kg.parseGraphLabels('{"c:k1": "not-an-object"}'), null)
})

test("#296 clamp: name ≤20 / summary ≤280 on LLM output", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  let captured: string[][] = []
  __testSetKnowledgeGraphLabelImpl(async ({ lines }) => {
    captured.push(lines)
    const out: Record<string, { name: string; summary?: string }> = {}
    for (const l of lines) {
      const m = /^GROUP (\S+)/.exec(l)
      if (m) out[m[1]] = { name: "名".repeat(50), summary: "摘".repeat(500) }
    }
    return out
  })
  const first = await handleMessage(
    { type: "knowledge.graph", llm_labels: true },
    { skillEngine: se } as never,
    panelSession,
  )
  assert.equal(first.type, "knowledge.graph")
  assert.equal(first.status, "ok")
  // 非阻塞：第一响应全是回退标签
  for (const l of Object.values(first.labels) as Array<{ ai: boolean }>) assert.equal(l.ai, false)
  assert.ok(captured.length > 0, "label impl must have been called")

  await settle()
  const second = await handleMessage(
    { type: "knowledge.graph", llm_labels: true },
    { skillEngine: se } as never,
    panelSession,
  )
  const aiLabels = Object.entries(second.labels as Record<string, { name: string; summary?: string; ai: boolean }>).filter(([, v]) => v.ai)
  assert.ok(aiLabels.length > 0, "second request must see AI labels")
  for (const [, v] of aiLabels) {
    assert.ok(v.name.length <= 20, `name clamped: ${v.name.length}`)
    assert.ok((v.summary || "").length <= 280, `summary clamped: ${(v.summary || "").length}`)
  }
})

// --- handler：surface 门 / 状态机 / 回退 ---

test("#296 surface gate: non-panel sessions rejected, panel served", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)

  const summoner = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, { surface: "summoner", sendToExtension: () => {} } as never)
  assert.equal(summoner.type, "error")
  assert.match(String(summoner.error), /panel/)

  const tray = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, { surface: "tray", sendToExtension: () => {} } as never)
  assert.equal(tray.type, "error")

  const missing = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, undefined)
  assert.equal(missing.type, "error")

  const panel = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panelSession)
  assert.equal(panel.type, "knowledge.graph")
  assert.equal(panel.status, "ok")
  assert.equal(panel.nodes.length, 25)
  assert.equal(panel.truncated, false)
  assert.ok(Array.isArray(panel.edges) && panel.edges.length > 0)
})

test("#427 handler: 2–19 无缓存 → ok + 全未分组 + llm_ready；relations/organized 整体省略", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 7)
  const resp = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panelSession)
  assert.equal(resp.type, "knowledge.graph")
  assert.equal(resp.status, "ok")
  assert.equal(resp.nodes.length, 7)
  const labels = resp.labels as Record<string, { name: string; ai: boolean }>
  assert.deepEqual(Object.keys(labels), ["u:ungrouped"])
  assert.equal(resp.llm_ready, true)
  assert.equal(resp.relations, undefined, "无缓存帧整体省略 relations（缺字段 ≠ 空数组，pi MAJOR-1）")
  assert.equal(resp.organized, undefined)
  assert.equal(resp.stale, undefined)
  assert.equal(resp.tf_switch_notice, undefined, "LLM lane 帧不带跨 20 notice")
})

test("#296 handler: index unavailable → rebuilding (honest, no fake graph)", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  // 破坏 cache 路径：把 cache 变成普通文件 → 重建写盘失败 → 索引不可用
  const cachePath = path.join(DATA_DIR, "cache")
  fs.rmSync(cachePath, { recursive: true, force: true })
  fs.writeFileSync(cachePath, "not a dir")
  se.importKnowledge(mdDoc("extra-doc", ["alpha"], "alpha shared body words")) // 指纹漂移触发重建

  const resp = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panelSession)
  assert.equal(resp.type, "knowledge.graph")
  assert.equal(resp.status, "rebuilding")
  assert.equal(resp.nodes.length, 0)

  // 恢复路径后续测试可用
  fs.rmSync(cachePath, { recursive: true, force: true })
  fs.mkdirSync(cachePath, { recursive: true })
})

test("#296 LLM failure → fallback labels, no display write, no error frame", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  __testSetKnowledgeGraphLabelImpl(async () => {
    throw new Error("llm down")
  })
  const resp = await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  assert.equal(resp.type, "knowledge.graph")
  assert.equal(resp.status, "ok")
  const labels = resp.labels as Record<string, { name: string; ai: boolean }>
  assert.ok(Object.keys(labels).length > 0)
  for (const v of Object.values(labels)) {
    assert.equal(v.ai, false)
    assert.ok(v.name.length > 0)
  }
  await settle()
  const second = await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  for (const v of Object.values(second.labels as Record<string, { ai: boolean }>)) assert.equal(v.ai, false)
})

test("#296 LLM prompt privacy: member titles/tags only, never doc bodies (#274 precedent)", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25, true) // doc-000 body carries SECRETBODYTOKEN9999
  let userLines: string[] = []
  __testSetKnowledgeGraphLabelImpl(async ({ lines }) => {
    userLines = lines
    return {}
  })
  await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  await settle()
  assert.ok(userLines.length > 0)
  const joined = userLines.join("\n")
  assert.equal(joined.includes("SECRETBODYTOKEN9999"), false, "doc bodies must not leak into the label prompt")
  assert.ok(joined.includes("doc-"), "titles expected in prompt lines")
})

test("#296 regen_labels: forces regeneration over cache", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  let version = 0
  __testSetKnowledgeGraphLabelImpl(async ({ lines }) => {
    version += 1
    const out: Record<string, { name: string }> = {}
    for (const l of lines) {
      const m = /^GROUP (\S+)/.exec(l)
      if (m) out[m[1]] = { name: `AI 名 v${version}` }
    }
    return out
  })
  await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  await settle()
  const second = await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  const aiSecond = Object.values(second.labels as Record<string, { name: string; ai: boolean }>).filter((v) => v.ai)
  assert.ok(aiSecond.length > 0)
  for (const v of aiSecond) assert.equal(v.name, "AI 名 v1")

  await handleMessage({ type: "knowledge.graph", regen_labels: true }, { skillEngine: se } as never, panelSession)
  await settle()
  const third = await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  const aiThird = Object.values(third.labels as Record<string, { name: string; ai: boolean }>).filter((v) => v.ai)
  assert.ok(aiThird.length > 0)
  for (const v of aiThird) assert.equal(v.name, "AI 名 v2")
})

test("#296 no llm_labels → no LLM call at all (default off)", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  let called = 0
  __testSetKnowledgeGraphLabelImpl(async () => {
    called += 1
    return {}
  })
  const resp = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panelSession)
  assert.equal(resp.status, "ok")
  await settle()
  assert.equal(called, 0)
})

// --- display round-trip / 容忍 ---

test("#296 display round-trip via engine + file (0o600)", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  __testSetKnowledgeGraphLabelImpl(async ({ lines }) => {
    const out: Record<string, { name: string; summary?: string }> = {}
    for (const l of lines) {
      const m = /^GROUP (\S+)/.exec(l)
      if (m) out[m[1]] = { name: "AI 名", summary: "AI 摘要" }
    }
    return out
  })
  await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  await settle()

  const p = clusters.knowledgeIndexPath()
  const idx = clusters.readKnowledgeIndexFile(p)
  if (!idx) throw new Error("index file missing")
  const display = (idx as { display?: Record<string, { name: string; summary?: string }> }).display
  if (!display) throw new Error("display missing on disk")
  const keys = Object.keys(display)
  assert.ok(keys.length > 0)
  assert.ok(keys.every((k) => k.startsWith("c:")))
  for (const v of Object.values(display)) {
    assert.equal(v.name, "AI 名")
    assert.equal(v.summary, "AI 摘要")
  }
  const st = fs.statSync(p)
  assert.equal(st.mode & 0o777, 0o600)
})

test("#296 readKnowledgeIndexFile tolerates missing / malformed display", () => {
  const p = path.join(DATA_DIR, "cache", "kg-tolerance-test.json")
  const base: import("../src/skills/knowledge-clusters").KnowledgeIndexFile = { version: 1, built_at: new Date().toISOString(), fingerprint: "fp", docs: [{ id: "a", name: "a", title: "a", tags: [], folder: "", bucket: "global", vec: { x: 1 } }] }
  clusters.writeKnowledgeIndexFile(p, base)
  const noDisplay = clusters.readKnowledgeIndexFile(p)
  if (!noDisplay) throw new Error("missing display must be tolerated")
  assert.equal((noDisplay as { display?: unknown }).display, undefined)

  fs.writeFileSync(p, JSON.stringify({ ...base, display: "not-an-object" }))
  const badDisplay = clusters.readKnowledgeIndexFile(p)
  if (!badDisplay) throw new Error("malformed display must not kill the file")
  assert.equal((badDisplay as { display?: unknown }).display, undefined)
})

// --- validator ---

test("#296/#427 validator: knowledge.graph optional fields strict shapes", () => {
  assert.equal(validateWsMessage({ type: "knowledge.graph" }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", llm_labels: true }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", regen_labels: true }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", llm_labels: "yes" }).valid, false)
  assert.equal(validateWsMessage({ type: "knowledge.graph", regen_labels: 1 }).valid, false)
  // #427（ext wire 合同）：organize/user_gesture 可选布尔；lock/unlock 字符串；ack 仅 true
  assert.equal(validateWsMessage({ type: "knowledge.graph", organize: true, user_gesture: true }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", organize: "yes" }).valid, false)
  assert.equal(validateWsMessage({ type: "knowledge.graph", user_gesture: 1 }).valid, false)
  assert.equal(validateWsMessage({ type: "knowledge.graph", lock_group: "l:abc", user_gesture: true }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", lock_group: 7 }).valid, false)
  assert.equal(validateWsMessage({ type: "knowledge.graph", unlock_group: "l:abc", user_gesture: true }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", unlock_group: [] }).valid, false)
  assert.equal(validateWsMessage({ type: "knowledge.graph", ack_tf_switch: true, user_gesture: true }).valid, true)
  assert.equal(validateWsMessage({ type: "knowledge.graph", ack_tf_switch: false }).valid, false)
})

// --- round-2 收敛：AC-4 开关门 + 完成推送 ---

test("#296 llm_labels off → cached AI labels never reach the wire (AC-4 gate)", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  __testSetKnowledgeGraphLabelImpl(async ({ lines }) => {
    const out: Record<string, { name: string }> = {}
    for (const l of lines) {
      const m = /^GROUP (\S+)/.exec(l)
      if (m) out[m[1]] = { name: "AI 缓存名" }
    }
    return out
  })
  // 开关开：生成并缓存 AI 标签
  await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  await settle()
  const on = await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, panelSession)
  const aiOn = Object.values(on.labels as Record<string, { ai: boolean }>).filter((v) => v.ai)
  assert.ok(aiOn.length > 0, "sanity: AI labels visible while the toggle is on")

  // 开关关：display 缓存存在，但 wire 必须全部是高频词回退
  const off = await handleMessage({ type: "knowledge.graph" }, { skillEngine: se } as never, panelSession)
  const offLabels = off.labels as Record<string, { name: string; ai: boolean }>
  assert.ok(Object.keys(offLabels).length > 0)
  for (const v of Object.values(offLabels)) {
    assert.equal(v.ai, false, "toggle off must never serve cached AI labels")
    assert.notEqual(v.name, "AI 缓存名")
  }
})

test("#296 labels completion pushes an updated knowledge.graph frame to the panel", async () => {
  resetKnowledgeState()
  const se = new SkillEngine()
  seedThemed(se, 25)
  __testSetKnowledgeGraphLabelImpl(async ({ lines }) => {
    const out: Record<string, { name: string; summary?: string }> = {}
    for (const l of lines) {
      const m = /^GROUP (\S+)/.exec(l)
      if (m) out[m[1]] = { name: "AI 推送名", summary: "推送摘要" }
    }
    return out
  })
  const sent: any[] = []
  const sess = { surface: "panel", sendToExtension: (d: any) => sent.push(d) } as never
  const resp = await handleMessage({ type: "knowledge.graph", llm_labels: true }, { skillEngine: se } as never, sess)
  assert.equal(resp.status, "ok")
  // 首次响应是回退标签（非阻塞）；异步标注完成后必须推一帧 AI 版
  await settle()
  const pushes = sent.filter((m) => m.type === "knowledge.graph")
  assert.ok(pushes.length > 0, "completion push expected — otherwise the toggle-on session never sees AI labels")
  const lastPush = pushes[pushes.length - 1]
  const aiPushed = Object.values(lastPush.labels as Record<string, { name: string; ai: boolean; summary?: string }>).filter((v) => v.ai)
  assert.ok(aiPushed.length > 0, "pushed frame carries AI labels")
  for (const v of aiPushed) {
    assert.equal(v.name, "AI 推送名")
    assert.equal(v.summary, "推送摘要")
  }
})

// --- #427：l: 键 / 指纹 / 锁 overlay / organize 解析与归一化 / 剪枝 ---

test("#427 lGroupKey: 服务端派生、成员集决定键、顺序无关", () => {
  const k1 = kg.lGroupKey(["b", "a", "c"])
  assert.equal(k1, kg.lGroupKey(["c", "b", "a"]))
  assert.match(k1, /^l:[0-9a-f]{12}$/)
  assert.notEqual(k1, kg.lGroupKey(["a", "b"]))
})

test("#427 fingerprint: id/title/description/tags 任一变动都漂移；顺序无关", () => {
  const base = [
    { ...mkDoc("a", { x: 1 }, ["t1"], "A"), description: "描述A" },
    { ...mkDoc("b", { y: 1 }, ["t2"], "B"), description: "描述B" },
  ]
  const fp = kg.computeGraphLlmFingerprint(base)
  assert.equal(fp, kg.computeGraphLlmFingerprint([...base].reverse()))
  assert.notEqual(fp, kg.computeGraphLlmFingerprint([
    { ...base[0], description: "描述A2" }, base[1],
  ]), "description 变动必须漂移（prompt 输入同源）")
  assert.notEqual(fp, kg.computeGraphLlmFingerprint([
    { ...base[0], tags: ["t1", "extra"] }, base[1],
  ]), "tags 变动必须漂移（AC-2）")
  assert.notEqual(fp, kg.computeGraphLlmFingerprint([
    { ...base[0], title: "A!" }, base[1],
  ]), "title 变动必须漂移")
})

test("#427 锁 overlay：改写 group_key + 注入 ai:true/locked:true labels；未分组 label 重算", () => {
  const groupA = [1, 2, 3].map((i) => mkDoc(`a${i}`, { alpha: 0.9 }, ["sharedalpha"], `A${i}`))
  const docs = [...groupA, ...orthoDocs("q", 15)] // 18 篇 → LLM lane
  const lock = { groups: [{ ids: ["a1", "a2", "a3", "q000"], name: "用户锁组", summary: "用户认可" }] }
  const r = kg.buildKnowledgeGraph(docs, undefined, { lock })
  const key = kg.lGroupKey(["a1", "a2", "a3", "q000"])
  for (const id of ["a1", "a2", "a3", "q000"]) {
    assert.equal(r.nodes.find((n) => n.id === id)!.group_key, key)
  }
  assert.equal(r.labels[key].name, "用户锁组")
  assert.equal(r.labels[key].summary, "用户认可")
  assert.equal(r.labels[key].ai, true)
  assert.equal(r.labels[key].locked, true, "ext wire 合同：labels[].locked")
  assert.ok(r.labels["u:ungrouped"], "剩余散点仍带未分组 label")
  assert.deepEqual(r.relations, [], "无 graph_llm 缓存 → relations 恒空")
})

test("#490 19→20：旧未锁 AI 分组退出，节点与标签恢复 TF 结果", () => {
  const docs = orthoDocs("transition", 20)
  const smallDocs = docs.slice(0, 19)
  // 复现：小语料整理后新增第 20 篇，graph_llm 缓存仍由引擎携带。
  // 旧实现把未锁组带入 TF lane，却没有生成对应 labels（代码归责）。
  // 使用生产归一化产物保护 lane 切换，不手造 wire 帧。
  const llm = kg.normalizeGraphOrganize({
    groups: [{ name: "旧 AI 分组", ids: [docs[0].id, docs[1].id] }],
    relations: [{ a: docs[0].id, b: docs[1].id, reason: "同一主题", confidence: 0.8 }],
  }, new Set(smallDocs.map((d) => d.id)), new Set())
  const small = kg.buildKnowledgeGraph(smallDocs, undefined, { llm })
  const key = kg.lGroupKey([docs[0].id, docs[1].id])
  assert.equal(small.llmLane, true)
  assert.equal(small.nodes.find((n) => n.id === docs[0].id)!.group_key, key)
  assert.equal(small.labels[key].name, "旧 AI 分组")
  assert.equal(small.relations.length, 1)

  const grown = kg.buildKnowledgeGraph(docs, undefined, { llm })
  const tf = kg.buildKnowledgeGraph(docs)
  assert.equal(grown.llmLane, false)
  assert.deepEqual(grown.nodes, tf.nodes, "未锁的旧 AI 分组不能改变 TF 节点归属")
  assert.deepEqual(grown.labels, tf.labels)
  assert.deepEqual(grown.edges, tf.edges)
  assert.deepEqual(grown.relations, [])
  assert.ok(grown.nodes.every((n) => grown.labels[n.group_key]), "每个节点分组都必须有标签")
})

test("#490 19→20：旧缓存退出时显式锁组仍保留", () => {
  const docs = orthoDocs("locked-transition", 20)
  const smallDocs = docs.slice(0, 19)
  const llm = kg.normalizeGraphOrganize({
    groups: [
      { name: "未锁组", ids: [docs[0].id, docs[1].id] },
      { name: "保留的组", ids: [docs[2].id, docs[3].id] },
    ],
    relations: [],
  }, new Set(smallDocs.map((d) => d.id)), new Set())
  const lockedGroup = llm.groups.find((g) => g.name === "保留的组")!
  assert.ok(lockedGroup)
  const lock = { groups: [lockedGroup] }
  const key = kg.lGroupKey(lockedGroup.ids)
  const small = kg.buildKnowledgeGraph(smallDocs, undefined, { llm, lock })
  assert.equal(small.llmLane, true)
  assert.equal(small.labels[key].locked, true)

  const grown = kg.buildKnowledgeGraph(docs, undefined, { llm, lock })
  const tfWithLock = kg.buildKnowledgeGraph(docs, undefined, { lock })
  assert.equal(grown.llmLane, false)
  assert.deepEqual(grown.nodes, tfWithLock.nodes, "仅显式锁组可跨越 lane")
  assert.deepEqual(grown.labels, tfWithLock.labels)
  assert.equal(grown.labels[key].name, "保留的组")
  assert.equal(grown.labels[key].locked, true)
  for (const id of lockedGroup.ids) {
    assert.equal(grown.nodes.find((n) => n.id === id)!.group_key, key)
  }
})

test("#427 锁跨活：≥20 帧锁 overlay 照常生效且 relations 永不上帧", () => {
  const groupA = [1, 2, 3, 4].map((i) => mkDoc(`a${i}`, { alpha: 0.8, [`pa${i}`]: 0.2 }, ["sharedalpha"], `A${i}`))
  const rest = orthoDocs("q", 16)
  const docs = [...groupA, ...rest] // 20 篇 → TF lane
  const lock = { groups: [{ ids: ["a1", "a2", "a3"], name: "锁" }] }
  const r = kg.buildKnowledgeGraph(docs, undefined, { lock })
  assert.equal(r.llmLane, false)
  assert.equal(r.status, "ok")
  assert.deepEqual(r.relations, [])
  assert.equal(r.relations.length, 0)
  const key = kg.lGroupKey(["a1", "a2", "a3"])
  for (const id of ["a1", "a2", "a3"]) {
    assert.equal(r.nodes.find((n) => n.id === id)!.group_key, key, "锁着色以锁为准，不被 TF 聚类收编")
  }
  assert.equal(r.labels[key].locked, true)
})

test("#427 organize prompt：只有 title/tags/description，不进正文；锁禁区行", () => {
  const docs = [{ ...mkDoc("d1", { x: 1 }, ["t1"], "标题一"), description: "描述一" }]
  const prompt = kg.buildGraphOrganizePrompt(docs, { groups: [{ ids: ["d1", "d2"], name: "禁区组" }] })
  assert.ok(prompt.userContent.includes("DOC d1 | 标题一 | tags: t1 | 描述一"))
  assert.ok(prompt.userContent.includes("已锁定分组"))
  assert.ok(prompt.userContent.includes("禁区组"))
  assert.ok(!prompt.userContent.includes("正文"), "正文绝不进 prompt")
  assert.ok(prompt.systemPrompt.includes("严格 JSON"))
})

type Parsed = import("../src/skills/knowledge-graph").GraphOrganizeParsed
function grp(name: string, ids: string[], summary?: string): { name: string; ids: string[]; summary?: string } {
  return summary === undefined ? { name, ids } : { name, ids, summary }
}
function rel(a: string, b: string, reason = "同主题", confidence = 0.8) {
  return { a, b, reason, confidence }
}

test("#427 parseGraphOrganize：容忍前后噪声；形状零容忍", () => {
  const ok = kg.parseGraphOrganize(
    '前置说明 {"groups": [{"name": "g", "ids": ["a", "b"]}], "relations": [{"a": "a", "b": "b", "reason": "r", "confidence": 0.5}]} 后置',
  )
  if (!ok) throw new Error("expected parse")
  assert.equal(ok.groups.length, 1)
  assert.equal(ok.relations[0].confidence, 0.5)
  assert.equal(kg.parseGraphOrganize('{"groups": []}'), null, "relations 缺失 → null")
  assert.equal(kg.parseGraphOrganize('{"relations": []}'), null, "groups 缺失 → null")
  assert.equal(kg.parseGraphOrganize('{"groups": [{}], "relations": []}'), null, "name 缺失 → null")
  assert.equal(kg.parseGraphOrganize('{"groups": [{"name": "g", "ids": []}], "relations": []}'), null)
  assert.equal(kg.parseGraphOrganize('{"groups": [], "relations": [{"a": "a", "b": "b", "reason": "r"}]}'), null, "confidence 缺失 → null")
  assert.equal(kg.parseGraphOrganize("not json"), null)
})

test("#427 normalize：幸福路径 + 锁成员剥离 + 单成员组归一化不计分子", () => {
  const live = new Set(["a", "b", "c", "d", "e"])
  const norm = kg.normalizeGraphOrganize(
    {
      groups: [grp("G1", ["a", "b"], "摘要"), grp("G2", ["c"]), grp("G3", ["d", "e"])],
      relations: [rel("a", "b")],
    },
    live,
    new Set(["e"]),
  )
  assert.equal(norm.groupPoolFallback, false)
  assert.equal(norm.groups.length, 1, "G2 单成员归未分组；G3 剥离锁成员 e 后剩 1 → 未分组")
  assert.deepEqual(norm.groups[0].ids, ["a", "b"])
  assert.equal(norm.groups[0].name, "G1")
  assert.equal(norm.groups[0].summary, "摘要")
  assert.equal(norm.relationPoolFallback, false)
  assert.equal(norm.relations.length, 1)
  assert.deepEqual([norm.relations[0].a, norm.relations[0].b], ["a", "b"])
})

test("#427 normalize：亡 id / 重复归属后现条整条作废；恰好 50% 不触发回退", () => {
  const live = new Set(["a", "b", "c", "d"])
  const norm = kg.normalizeGraphOrganize(
    {
      groups: [grp("G1", ["a", "ghost"]), grp("G2", ["b"]), grp("G3", ["a", "c"]), grp("G4", ["c", "d"])],
      relations: [],
    },
    live,
    new Set(),
  )
  // G1 亡 id 无效；G2 单成员归一化（不计分子）；G3 有效；G4 撞 G3 的 c → 后现整条作废
  assert.equal(norm.groupPoolFallback, false, "2/4 = 50%，不 > 50% → 不回退")
  assert.equal(norm.groups.length, 1)
  assert.deepEqual(norm.groups[0].ids, ["a", "c"])
})

test("#427 normalize：组池 >50% 回退且不连坐关系池（分池独立）", () => {
  const live = new Set(["a", "b", "c"])
  const norm = kg.normalizeGraphOrganize(
    {
      groups: [grp("G1", ["a", "ghost1"]), grp("G2", ["b", "ghost2"]), grp("G3", ["a", "b"])],
      relations: [rel("a", "b")],
    },
    live,
    new Set(),
  )
  assert.equal(norm.groupPoolFallback, true)
  assert.deepEqual(norm.groups, [])
  assert.equal(norm.relationPoolFallback, false)
  assert.equal(norm.relations.length, 1, "关系池不被组池连坐")
})

test("#427 normalize relations：reason 空/非有限 confidence/亡 id/自环计分子；恰好 50% 不回退；钳制；无序对去重留高分", () => {
  const live = new Set(["a", "b", "c", "d", "e", "f"])
  const norm = kg.normalizeGraphOrganize(
    {
      groups: [],
      relations: [
        rel("a", "b"),
        rel("c", "d"),
        rel("e", "f"),
        { a: "e", b: "f", reason: "", confidence: 0.5 },
        { a: "a", b: "b", reason: "r", confidence: Number.NaN },
        { a: "ghost", b: "a", reason: "r", confidence: 0.5 },
        { a: "c", b: "c", reason: "自环", confidence: 0.5 },
        { a: "c", b: "d", reason: "重复对", confidence: 0.1 },
      ],
    },
    live,
    new Set(),
  )
  assert.equal(norm.relationPoolFallback, false, "4/8 = 50%，不 > 50% → 保留池")
  // 有效对 {a,b} {c,d} {e,f}；{c,d} 重复对被去重留 0.8 高分
  assert.equal(norm.relations.length, 3)
  assert.deepEqual(
    norm.relations.map((r) => [r.a, r.b]).sort(),
    [["a", "b"], ["c", "d"], ["e", "f"]],
  )

  const clampHi = kg.normalizeGraphOrganize({ groups: [], relations: [rel("a", "b", "r", 1.7)] }, new Set(["a", "b"]), new Set())
  assert.equal(clampHi.relations[0].confidence, 1)
  const clampLo = kg.normalizeGraphOrganize({ groups: [], relations: [rel("a", "b", "r", -0.2)] }, new Set(["a", "b"]), new Set())
  assert.equal(clampLo.relations[0].confidence, 0)

  const dedup = kg.normalizeGraphOrganize(
    { groups: [], relations: [rel("a", "b", "r1", 0.9), rel("b", "a", "r2", 0.5)] },
    new Set(["a", "b"]),
    new Set(),
  )
  assert.equal(dedup.relations.length, 1)
  assert.equal(dedup.relations[0].reason, "r1", "同无序对留高分")
  assert.equal(dedup.relations[0].a, "a", "a<b 字典序归一")
})

test("#427 normalize：两段式截断——先每端点 ≤3，再全图 ≤ min(12, 3n)", () => {
  const live = new Set(["hub", "s1", "s2", "s3", "s4", "s5", "x", "y"])
  const star = kg.normalizeGraphOrganize(
    {
      groups: [],
      relations: [rel("hub", "s1"), rel("hub", "s2"), rel("hub", "s3"), rel("hub", "s4"), rel("hub", "s5")],
    },
    live,
    new Set(),
  )
  const hubDeg = star.relations.filter((r) => r.a === "hub" || r.b === "hub").length
  assert.equal(hubDeg, 3, "第一刀：单端点度数 ≤3（同分贪心按序保留）")

  // 10 节点全连（45 对同分）：第一刀后 13 条 > 12 → 第二刀全图 cap 生效
  const ids = Array.from({ length: 10 }, (_, i) => `n${i}`)
  const all: Parsed = { groups: [], relations: [] }
  for (let i = 0; i < ids.length; i++) {
    for (let j = i + 1; j < ids.length; j++) all.relations.push(rel(ids[i], ids[j], "r", 0.5))
  }
  const capped = kg.normalizeGraphOrganize(all, new Set(ids), new Set())
  assert.equal(capped.relations.length, 12)
  const deg = new Map<string, number>()
  for (const r of capped.relations) {
    deg.set(r.a, (deg.get(r.a) || 0) + 1)
    deg.set(r.b, (deg.get(r.b) || 0) + 1)
  }
  for (const d of deg.values()) assert.ok(d <= 3)
})

test("#427 normalize：reason 按码点切 ≤80，不劈代理对", () => {
  const emoji = "😀".repeat(90) // 90 码点 / 180 UTF-16 单元
  const norm = kg.normalizeGraphOrganize(
    { groups: [], relations: [rel("a", "b", emoji, 0.5)] },
    new Set(["a", "b"]),
    new Set(),
  )
  const r = norm.relations[0].reason
  assert.equal(Array.from(r).length, 80)
  assert.equal(Buffer.from(r, "utf8").toString("utf8"), r, "无 lone surrogate（UTF-8 round-trip）")
})

test("#427 pruneGraphLlmSection：亡 id 剔除、组缩 <2 解散、指纹/stale 保留", () => {
  const section = {
    fingerprint: "fp",
    stale: false,
    groups: [
      { ids: ["a", "b", "gone"], name: "G1" },
      { ids: ["c", "gone2"], name: "G2" },
    ],
    relations: [
      { a: "a", b: "gone", reason: "r", confidence: 0.5 },
      { a: "a", b: "b", reason: "r", confidence: 0.5 },
    ],
  }
  const pruned = kg.pruneGraphLlmSection(section, new Set(["a", "b", "c"]))
  assert.deepEqual(pruned.groups.map((g) => g.ids), [["a", "b"]], "G2 缩到 1 → 解散")
  assert.equal(pruned.relations.length, 1)
  assert.equal(pruned.fingerprint, "fp")
  assert.equal(pruned.stale, false)
})

test("#427 pruneGraphLock：成员只减不增；<2 解散带组名（pi 终验 2：缩容后同一锁仍生效）", () => {
  const lock = {
    groups: [
      { ids: ["a", "b", "gone"], name: "锁组", summary: "s" },
      { ids: ["x", "gone2"], name: "将散" },
    ],
  }
  const { lock: pruned, dissolved } = kg.pruneGraphLock(lock, new Set(["a", "b", "x"]))
  assert.equal(pruned.groups.length, 1)
  assert.deepEqual(pruned.groups[0].ids, ["a", "b"])
  assert.equal(pruned.groups[0].name, "锁组", "锁的身份是条目：同一条目缩容后在")
  assert.deepEqual(dissolved, ["将散"])

  // 缩容后渲染：新 l: 键 ≠ 旧键，但同一锁条目仍把成员锁成一组
  const docs = [mkDoc("a", { x: 1 }), mkDoc("b", { y: 1 }), mkDoc("x", { z: 1 })]
  const rendered = kg.buildKnowledgeGraph(docs, undefined, { lock: pruned })
  const newKey = kg.lGroupKey(["a", "b"])
  assert.notEqual(newKey, kg.lGroupKey(["a", "b", "gone"]), "缩容后键已变")
  assert.equal(rendered.nodes.find((n) => n.id === "a")!.group_key, newKey)
  assert.equal(rendered.nodes.find((n) => n.id === "b")!.group_key, newKey)
  assert.equal(rendered.labels[newKey].locked, true)
  assert.equal(rendered.labels[newKey].name, "锁组")
})

test("#427 readKnowledgeIndexFile：旧索引 docs 无 description 容忍；graph 区形状不符整区丢弃不连累", () => {
  const p = path.join(DATA_DIR, "cache", "kg-427-tolerance.json")
  const base = {
    version: 1,
    built_at: new Date().toISOString(),
    fingerprint: "fp",
    // 旧格式：#273 时代的 docs 没有 description 字段
    docs: [{ id: "a", name: "a", title: "a", tags: [], folder: "", bucket: "global", vec: { x: 1 } }],
  }
  clusters.writeKnowledgeIndexFile(p, base as never)
  const legacy = clusters.readKnowledgeIndexFile(p)
  if (!legacy) throw new Error("legacy docs without description must be tolerated")
  assert.equal(legacy.docs[0].description, undefined)

  fs.writeFileSync(p, JSON.stringify({ ...base, graph_llm: { fingerprint: 1, groups: [], relations: [], stale: false } }))
  const badLlm = clusters.readKnowledgeIndexFile(p)
  if (!badLlm) throw new Error("malformed graph_llm must not kill the file")
  assert.equal((badLlm as { graph_llm?: unknown }).graph_llm, undefined, "fingerprint 非字符串 → 整区丢弃")
  assert.equal(badLlm.docs.length, 1, "docs 存活")

  fs.writeFileSync(p, JSON.stringify({ ...base, graph_lock: { groups: "not-array" } }))
  const badLock = clusters.readKnowledgeIndexFile(p)
  if (!badLock) throw new Error("malformed graph_lock must not kill the file")
  assert.equal((badLock as { graph_lock?: unknown }).graph_lock, undefined)

  fs.writeFileSync(p, JSON.stringify({ ...base, graph_tf_switch_ack: "yes" }))
  const badAck = clusters.readKnowledgeIndexFile(p)
  if (!badAck) throw new Error("malformed ack must not kill the file")
  assert.equal((badAck as { graph_tf_switch_ack?: unknown }).graph_tf_switch_ack, undefined)

  // 合法 graph_lock / ack 原样保留
  fs.writeFileSync(
    p,
    JSON.stringify({ ...base, graph_lock: { groups: [{ ids: ["a", "b"], name: "L" }] }, graph_tf_switch_ack: true }),
  )
  const kept = clusters.readKnowledgeIndexFile(p)
  if (!kept) throw new Error("valid sections must survive")
  assert.equal(kept.graph_lock?.groups.length, 1)
  assert.equal(kept.graph_tf_switch_ack, true)
})

```

### FULL docs/superpowers/plans/2026-09-09-knowledge-graph-usability.md
```
# 知识图谱可见性与探索体验

GitHub: #490 · Base: aada096a · 2026-09-09

## 诊断与目标

用户反馈“啥都看不到”。重点检查异步快照到达前后 canvas 生命周期，而非先修改聚类算法。
既有视图只在悬停显示标题、浮层覆盖图谱，缺少可检索的知识目录和显式恢复视角操作。
遵循根 DESIGN.md 的清晰层级、能力完整、诚实状态、可访问性与响应式合同。

## 实现范围

1. 用真实 KnowledgeGraphApp 加异步 storage 边界复现绘制缺失；绑定实际画布挂载/卸载，覆盖错误恢复。
2. 工具栏、状态提示、画布和知识浏览区域采用正常布局，避免提示/分组遮挡；小屏纵向滚动。
3. 可读节点和默认标题，搜索/分组筛选的完整知识列表；选择节点定位并展示实际关系。
4. 显式适应画布、缩放、刷新、文档打开入口；空库与无关联分别解释，不捏造关系。
5. 保留着色、AI 命名/重新生成、AI 整理、锁定/解锁、陈旧提示、AI 关联理由和知识面板预览。
6. 检查 backend→WS→storage 的可观察失败路径，修复已复现的相关缺陷；不修改真实用户数据。

## 能力边界与验收

T2。Surface 为已有 extension graph tab，L2 / Trust / Channel 不变。
Compose 复用既有知识预览；Autonomy 不变，搜索/定位不调用 LLM，刷新默认不启用 AI，
已保存的 AI 命名开启偏好延续既有按需补全语义；AI 整理仍须显式点击。
不修改检索阈值、知识原文、live 配置；显示关系始终来自已有 TF / AI 数据。

机器验收：异步加载与状态切换后实际像素/绘制，1/4/20/200 节点；搜索与键盘选择、视角恢复、
响应式 320/390/760/1440 与短屏；分组和关联理由、无关系、空库/加载/错误/离线；既有能力保留。
测试基于隔离 Chrome、合成非用户语料和真实生产组件，不宣称实机知识/Windows UX 验收。
最终采用用户指定的 Grok 4.6 + DeepSeek V4 Pro 独立复审（替代通用技能 Kimi/Pi 组合），
当前提交 CI 全绿后合并。复现、修复、机核、裁决分别留痕。

```
