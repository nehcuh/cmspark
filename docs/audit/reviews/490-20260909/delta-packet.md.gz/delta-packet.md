Independent final delta review of CMspark #490, base aada096a. Full source review previously received Grok APPROVE_WITH_NITS and DeepSeek APPROVE after factual correction. Do not inherit their conclusions blindly. Evaluate the actual small follow-up delta below for outcomes/trajectory/component correctness. No tools/edits. Finish VERDICT: APPROVE | APPROVE_WITH_NITS | REJECT.

Production delta since first full review: (1) during automatic layout fit every frame until stable so all200 node centers stay visible; user pan/zoom/selection stops simulation; (2) ResizeObserver preserves custom scale and world point at center by adding half size delta to pan; otherwise fit; (3) unrelated action send failures do not clear ongoing organize state; failed organize restores last confirmed server state; (4) title strings precomputed, related-edge view useMemo, matchMedia object created once per canvas mount; (5) type=button on notice and stale code comment/Design #490 header corrected. No backend changes after previously reviewed boolean organizing/19→20 fix. New test-only delta: actual keyboard tests, trusted Chrome CDP touch cancellation, details persistence at4/20 including unlock at20, camera behavior and busy-state failure proof.

Disposition to assess: Grok controlled details claim disproven in real React: unchanged open prop is not repatched on unrelated renders; hand collapse at4/expand at20 both persist through search/hover and a locked20 snapshot, unlock reachable. DeepSeek pointercancel leakage disproven via trusted events showing implicit capture release and no residual drag; W3C https://www.w3.org/TR/pointerevents3/#implicit-release-of-pointer-capture agrees. applySnap already clears requestError on new valid snapshots; its alleged one-way error was refuted. Arbitrary hung-companion reads are not a universal watchdog claim; send-layer offline and bounded rebuilding/organize waiting are the claimed scope. Old servers missing organizing cannot provide authoritative busy feedback; updated companion required. #491 cache permission issue remains separately tracked.

Capability: T2, same panel-only surface, no new verbs/trust/config changes. Default AI naming off; existing saved on preference retained, organize explicit. Labels collision pruning never removes knowledge list or creates relations. Tests are synthetic boundary data + actual production React/canvas/frame functions, not Windows or real user corpus.


### grok-review.md
# Independent review — CMspark #490

**Base:** `aada096a`  
**Claim:** blank graph → real canvas lifecycle + searchable explorer; ≥20 drops unlocked LLM groups; lock overlay stays; additive `organizing`; no new trust/actions.  
**Evidence class:** companion/extension unit+handler tests `[executed by implementer]`; Playwright on **synthetic** Chrome + production `KnowledgeGraphApp` / `knowledgeGraphFrame` `[executed, not Windows/user corpus]`; this review is **static** on the provided sources `[inspected]`.

Do **not** treat 1331 / 5055 passing tests or DESIGN/CHANGELOG length as proof.

---

## Outcomes vs DoD

| DoD | Result | Evidence |
|---|---|---|
| Async snapshot actually paints | **Met** | Baseline `before.json`: CSS 1280, bitmap **300×150**, **0** arcs, **0** opaque pixels. After: 1/4/20/200 paint with `backgroundAlpha=255` and colored pixels; remount after error uses a **new** canvas. Root cause was `useEffect(..., [])` while `canvasRef` was null; new effect is `[showCanvas]`. |
| Search/group never drop graph data | **Met** | `filterKnowledgeNodes` only feeds `visibleNodes` (list). Layout/draw still use full `payloadNodes` / `edgesRef`. |
| Select locally; explicit preview | **Met** | Click → `locateNode` (no `open_doc`). `在知识面板打开` → `knowledge_graph.open_doc`. UI test asserts both. |
| 1/4/20/200 + titles + full list | **Mostly met** | List count = N. Canvas titles wait for `'SQLite'`. **200-node probe: 191/200 centers in-bounds** (`after.json`). List still has 200. |
| Fit/zoom/keyboard, 320–1440 | **Met for the scripted path** | Resize cases assert bitmap = CSS×dpr, no sidebar overlap, no horizontal overflow. Keyboard handlers exist on the canvas. |
| Empty / offline / failed + recovery | **Met in synthetic UI** | `too_few` copy, connection error keeps snapshot, error→refresh→paint. |
| `organizing` true until settle | **Met on companion** | Handler test: ACK/refresh/rebuilding `true`; `finally` clears controller **before** push; success/failure `false`. Failure keeps `status:"ok"` + cache. |
| Legacy servers without `organizing` | **As declared** | Parse omits non-boolean; `setOrganizing(parsed.organizing === true)` ⇒ missing field looks idle. Local 35s timer is the only busy fallback. |
| Search/refresh do not auto-organize; naming pref preserved | **Met in mock transport** | Default refresh `llm_labels === false`; `?labels` keeps `true` and no `organize`. |
| #491 cache write | **Not claimed** | Honest. |

Capabilities (color, AI naming/regenerate, organize, lock/unlock, dashed vs solid, reasons) are still in the tree; several moved under `<details>`. Click-to-open becoming explicit preview is **spec**, not a silent removal.

---

## Trajectory / scope

Plan `docs/superpowers/plans/2026-09-09-knowledge-graph-usability.md` already bundled canvas lifecycle, layout (notices/list not overlaying), search, fit/zoom, honest empty/zero-edge, and keep-all-AI-verbs. Backend 19→20 unlabeled `l:` groups is a real related correctness bug (group_key applied in TF lane, labels only in LLM lane). Additive `organizing` is justified: old `applySnap` did `setOrganizing(false)` on the **first ACK**, which is exactly “initial graph response is not completion.”

T2 / panel-only / no new verbs: **holds** on this diff. `organizing` is optional on the existing frame. No user data path.

This is a large UI rewrite for a visibility bug. That is allowed by the plan, but it is also where the new defects are.

---

## Findings

### P0
None. The reported blank canvas is fixed with pixel evidence; trust surface is unchanged.

### P1
None that break the #490 contract on the provided evidence.

The 200-node 191-in-view probe is **not** a P1 by itself: the test only required `arcs.length >= 200` and `colored > 0`, and the full list is present. Treat as P2 camera/layout, below.

### P2 — new in this change

**P2-1. `<details open={payloadNodes.length <= 19}>` is fully controlled with no `onToggle`.**  
`KnowledgeGraphApp.tsx` groups block: `open={payloadNodes.length <= 19}`. React will reset native open/close on every parent render (`setHoverCaptionText` on canvas hover, color mode, snapshot, query, …).

- n≤19: user cannot keep groups collapsed.  
- n≥20: expand will not **stay** open while the mouse crosses the canvas (hover `setState`). Unlock for a lock overlay that **this ticket keeps across 20** lives in that block (`onUnlock` is intentionally not gated on `llmLane`). Transport is still tested at 4 nodes (details already open). **≥20 group management UX is untested and structurally flaky.**

**P2-2. `ResizeObserver` always `fitView()`, ignoring `userCameraRef`.**  
New resize path:

```ts
fitViewRef.current()
```

Old resize only updated the bitmap; fit ran when the simulation **finished**. New layout reflows the canvas often (list toggle, AI `<details>` `flex-basis:100%`, notices). Any of those wipes pan/zoom. Fit/zoom are “explicit” in DESIGN; this makes fit implicit and aggressive. UI tests click 适应画布 after resizes and never assert camera survival across 收起列表.

**P2-3. Camera is fitted before layout has settled; 200-node snapshot left 9 nodes off-canvas.**  
Draw loop fits as soon as `!fittedRef && !userCameraRef` (and resize fits on mount). Layout then ticks (6/frame, up to 320). Completion does re-fit if `!userCameraRef`, but `after.json` recorded `visible: 191` at assertion time. Combined with P2-2, “isolated documents stay visible” is true for the **list**, not reliably for the canvas frustum.

**P2-4. Client busy timeout vs server field (legacy / missed push).**  
35s `setOrganizing(false)` + “尚未收到整理结果” is local fiction. Server organize timeout is 30s; new frames are honest. Old companions never send `organizing: true`, so `applySnap` clears busy on the first snapshot — **same lie as pre-#490**, now documented. Acceptable residual; do not describe it as “job state always matches server.”

**P2-5. `onActionResponse` failure clears `organizing` for lock/LLM toggle too.**  
A failed lock/refresh while an organize is in flight will drop the spinner even if `knowledgeGraphOrganizeRun` is still set. Narrow race.

### Nits

- `知道了` on the lock-dissolved notice has no `type="button"` (every other control does).
- `knowledgeGraphBarMeta` still comments 「N 点 · M 边」; copy is now 「N 篇知识 · M 条相似关联」, including **0 条相似关联** when the honest state is “暂无明确关联”.
- `DESIGN.md` header still cites #481/#488 only; #490 body was added.
- `graphStyles` is a new `<style>` string every render; `matchMedia` is queried every rAF.
- 200-row document list is unvirtualized (cap is 200; OK, not elegant).
- `fitKnowledgeCamera` pads for radii, not for the title line under the node; draw already **drops** labels that would clip (`sy + 17 < h`) — another reason the list, not the canvas, is the a11y SoT.

---

## Existing / out of scope (not regressions)

- **#491** cache write permission — explicitly not fixed.
- **`ack_tf_switch` / organize `user_gesture`:** App still sends `knowledge_graph.refresh`; SW mapping is not in this diff. Same pattern as #427. UI tests mock `sendMessage` and only assert `organize: true`, not `user_gesture`. Backend tests call `handleMessage` with `user_gesture: true` directly. **Not re-proven end-to-end in this packet.**
- Panel-only / summoner deny — unchanged.
- ≥20 never ships `relations` — #427 contract; this change only stops unlocked **groups** leaking into TF `group_key`.
- Playwright is **headless Chrome + fake `chrome.storage` / `runtime`**, fixture vecs orthogonal (0 TF edges is real production, not a user’s library). Packet already says: not Windows UI, not real corpus.

---

## Component correctness

**Canvas lifecycle — correct.** `[showCanvas]` + rAF cleanup on unmount is the actual fix. Stale session `get` vs later `onChanged` (`receivedSnapshot`) is tested. Error unmount stops frames.

**Explorer — correct and small.** Filter is list-only; `shortKnowledgeTitle` is code-point safe; `fitKnowledgeCamera` removes the old **0.45 min zoom** that could leave sparse graphs off-screen (unit-tested).

**Click vs preview — correct per DESIGN.** Regression only if someone still expects click → knowledge panel; the ticket inverted that on purpose.

**Backend `llmLane` gate — correct.** Unlocked `opts.llm.groups` no longer rewrite TF membership; lock overlay still runs after. Tests compare `grown` to `tf` / `tfWithLock` using **production** `normalizeGraphOrganize`, not hand-built frames.

**`organizing` wire — correct on new servers.** Always a boolean on `knowledgeGraphFrame` and the rebuilding object; `finally` nulls the controller before `sendToExtension`. Parse is fail-closed (`typeof === "boolean"`).

**Copy `too_few` — correct, not a #427 regression.** After MIN_DOCS=1, `too_few` is **n=0**. “知识不足 20 篇，暂无图谱” was already a lie; empty-library copy matches the status. 20-doc messaging remains `KNOWLEDGE_GRAPH_TF_SWITCH_BANNER`.

**AI verbs — present, more hidden.** Organize CTA for 2–19 uncached stays in `kg-notices` (good). Reorganize / LLM switch / stale sit in **uncontrolled** `kg-ai-options` (OK). Lock/unlock sit in the **controlled** groups `<details>` (P2-1).

**Trust — OK.** No new message types, no auto `organize`, refresh default `llm_labels` from existing pref, search is local.

---

## What would make me reject

- Shipping with the canvas effect still `[]` / no remount path. **Not the case.**
- Dropping lock overlay at ≥20 or auto-firing organize/search→LLM. **Not the case.**
- Claiming #491 or real Windows/user-corpus UX. **Not claimed.**
- Controlled groups `<details>` if lock/unlock at ≥20 were the primary AC and unusable. They are secondary; still P2.

---

VERDICT: APPROVE_WITH_NITS

### deepseek-final.md
## Independent Read-Only Review — CMspark Issue #490 (Test-Only Delta)

### Scope

This follow-up reviews the test-only delta in `test-knowledge-graph-ui.py`: actual keyboard event coverage and trusted CDP pointer-cancel regression coverage. Production `KnowledgeGraphApp.tsx` is unchanged from the prior review packet. I also adjudicate the prior DeepSeek claims against the new evidence and the full source provided.

### Adjudication of prior claims

**P1-1 (`onPointerCancel` stuck drag / pointer capture leak): DISPROVEN.**

The production handler remains `onPointerCancel={() => { dragRef.current = null }}`. The prior review speculated that this skips `endDrag` cleanup, causing capture leaks or missed selection. The new trusted CDP touch test directly exercises the browser's actual input pipeline:

- `pointerdown` (trusted, `captureDuringEvent: true`)
- `gotpointercapture` (trusted, `captureDuringEvent: true`)
- `pointermove` (trusted)
- `pointercancel` (trusted, `captureDuringEvent: true` — note capture is still held during the cancel event itself)
- `lostpointercapture` (trusted, `captureDuringEvent: false`)

This matches W3C Pointer Events §9.5 exactly: the user agent releases implicit capture automatically after `pointercancel` and fires `lostpointercapture`. The test then verifies:

- No document open was sent (`knowledge_graph.open_doc` count unchanged)
- No relation/reason panel opened
- Camera position unchanged after `touchCancel` followed by unpressed mouse moves at different coordinates (`after_hover` matches `after_cancel` within 0.1px)

The "no document/reason opening on cancel" behavior is intentional: the production code's `endDrag` only runs the click-completion path on `pointerup`. On `pointercancel`, the UA has already invalidated the stream; treating cancel as click would be semantically wrong. The test's mouse-move-after-cancel check proves no residual drag ref retains capture or continues panning. This is direct, trusted, reproducible evidence. **Not a defect.**

**P1-2 (refresh error detection / offline hang): NOT SUPPORTED as a P1.**

The background route shown in evidence is:

```ts
const sent = wsClient?.send(frame) === true
if (!sent) { untrackGraphRequest(reqId) }
return { ok: true, sent }
```

The UI checks `chrome.runtime.lastError || res?.ok === false || res?.sent === false`. The `sent` return value is a concrete send-layer failure signal from the service worker. The prior review claimed the callback couldn't reliably distinguish companion-hung from companion-responded-with-error. That is true for a *hung companion after a successful send* — but the production code never claims to detect that in this single response path. The UI has separate recovery paths for that scenario:

- `applySnap` clears `requestError` on every accepted snapshot (including `organizing: false`), so any later push corrects the visible state.
- The rebuilding state has bounded polling (`REBUILD_POLL_MAX = 40` at 2.5s intervals = 100s), after which `pollExhausted` produces an honest manual-refresh prompt.
- `sendOrganize` has a 35s fallback for a lost organize completion.

The test suite explicitly passes the failed-send path (`window.sendFailure=true` → connection error → usable snapshot preserved). That is the scope of the DoD claim. Treating "hung companion after acknowledged send" as a send-layer failure is an overreach. Broad hung-peer watchdog is legitimately separate robustness work, not a blocker for this T2 panel repair. **Downgrade to nonblocking observation.**

**P1-3 (organizing lost-response one-way error): DISPROVEN as a committed-actual-defect.**

The prior review claimed the error message is one-way and may persist misleadingly. The full source shows `applySnap` calls `setRequestError("")` unconditionally after a successful parse — including when `parsed.organizing === false`. So if the 35s fallback fires ("尚未收到整理结果"), and the completion push later arrives with `organizing: false`, `applySnap` clears the stale error. The only residual edge is if the push arrives *while* the requestError shows and the push has `organizing: true` (unlikely mid-completion) — but then the organize is genuinely still running. The state machine is two-way on acknowledge. **Not a defect.**

**P2-2 (resize clobbers user camera): EXPLICIT UX DECISION, not a defect.**

The resize handler unconditionally calls `fitViewRef.current()`. The production source comments: "Reflow changes the actual canvas area, not an overlay on the old area. `fitViewRef.current()`." This is deliberate: when the canvas bitmap changes size, the prior camera coordinates are in a different physical space. Fitting on reflow preserves visibility. The responsive test suite (320/390/760/960/1440) verifies real canvas sizes, painted nodes, no overlap, no horizontal overflow. The prior review itself noted the base had no resize observer, so this is new intended behavior, not a regression. **Downgrade to nonblocking observation at most.**

**P2-3 / Nit-1 / Nit-3 (per-render compute, missing animation): NONBLOCKING.**

`relatedEdges` is computed inline in render and `shortKnowledgeTitle` in the draw loop. At ≤200 nodes with 12 relations max and a single panel page, this is sub-millisecond and below actionable threshold. No frame defect is measured in the test evidence. The test suite's painted-probe assertions confirm real drawing at 1/4/20/200 nodes. **Not a blocker.**

### Keyboard coverage assessment

The new actual-keyboard test section exercises real `page.keyboard.press()` against a focused Canvas, with pre-settlement stabilization (6 consecutive stable frames) before assertions. Verified:

- `ArrowLeft` and `ArrowRight` change native Canvas arc positions by exactly the expected 40px (within 0.1px)
- `Home` and `0` restore fitted position
- `+` and `-` change native radii by exactly 1.25× and 0.8× (within 0.01px)
- List Enter on a focused document button selects the correct document (aria-pressed=true, correct title, no spurious open_doc) and Canvas Escape clears selection

The `Escape`-before-snapshot-camera-stability trick is sound: it makes clear the measured position changes are keyboard events, not the force-layout animation. The assertions against `drawProbe.latestArcs[0]` are race-free because they wait on exact expectations, not timeouts.

### Test evidence quality

The `pointercancel.json` artifact is generated directly from real CDP `Input.dispatchTouchEvent` with touch emulation enabled. All events are `isTrusted: true`. The sequence `pointerdown → gotpointercapture → pointermove → pointercancel → lostpointercapture` with capture true→false is exactly the §9.5 contract. The camera-before/after comparison uses a stable settled frame baseline, and the unpressed-move check uses real mouse moves to prove no leftover drag state.

The `ui-keyboard.log` and `ui-pointercancel.log` both show the full suite passing consistently, including the pointercancel-specific PASS line with the complete trusted event evidence.

### Verdict

The prior reviewer's three P1 findings are addressed:

- **P1-1**: Disproven by trusted CDP evidence.
- **P1-2**: Not supported; send-layer detection is implemented and tested; hung-companion watchdog is out of scope.
- **P1-3**: Disproven; `applySnap` clears requestError on every accepted snapshot.

The P2/nit-level observations (resize camera fit, per-render compute, missing locate animation) are explicit UX decisions or sub-actionable performance notes, not blockers.

The test-only delta adds concrete, trusted, reproducible regression coverage for the exact interaction the prior review flagged as untested. Production source remains coherent with the test's assertions.

**VERDICT: APPROVE**
### ui-camera-details.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection
PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves
POINTERCANCEL EVIDENCE {"pointerId": 2, "captureAfterStart": true, "captureAfterCancel": false, "events": [{"type": "pointerdown", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "gotpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointermove", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointercancel", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "lostpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": false}], "cameraAfterCancel": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}, "cameraAfterUnpressedMoves": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}}
PASS production organized group filtering and readable AI relationship reason
PASS failed lock/naming requests preserve confirmed organizing busy state; a failed new organize request restores the confirmed idle state
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS native details: manually collapsed 4-node and expanded 20-node groups survive query/hover re-renders; 20-node locked group has a reachable working unlock button
PASS custom native scale and world center remain unchanged when toggling the list or resizing desktop/mobile viewports; all 200 node centers were visible in every initial recorded frame
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### initial-200-frames.json
[
  {
    "frame": 1,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 2,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 3,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 4,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 5,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 6,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 7,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 8,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 9,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 10,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 11,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 12,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 13,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 14,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 15,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 16,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 17,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 18,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 19,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  },
  {
    "frame": 20,
    "width": 960,
    "height": 627,
    "nodes": 200,
    "visible": 200
  }
]

### camera-preservation.json
[
  {
    "action": "custom zoom and pan",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 960,
    "height": 571
  },
  {
    "action": "close list",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 960,
    "height": 571
  },
  {
    "action": "open list",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 1280,
    "height": 571
  },
  {
    "action": "resize 1440x900",
    "radius": 10,
    "xFromCenter": 196.98388423894426,
    "yFromCenter": -34.448362204402315,
    "width": 1120,
    "height": 671
  },
  {
    "action": "resize 960x720",
    "radius": 10,
    "xFromCenter": 356.98388423894426,
    "yFromCenter": 105.55163779559768,
    "width": 640,
    "height": 491
  },
  {
    "action": "resize 390x844",
    "radius": 10,
    "xFromCenter": 241.98388423894426,
    "yFromCenter": 88.05163779559768,
    "width": 390,
    "height": 346
  },
  {
    "action": "resize 1280x800",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 960,
    "height": 571
  }
]

### ui-details.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection
PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves
POINTERCANCEL EVIDENCE {"pointerId": 2, "captureAfterStart": true, "captureAfterCancel": false, "events": [{"type": "pointerdown", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "gotpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointermove", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointercancel", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "lostpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": false}], "cameraAfterCancel": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}, "cameraAfterUnpressedMoves": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}}
PASS production organized group filtering and readable AI relationship reason
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS native details: manually collapsed 4-node and expanded 20-node groups survive query/hover re-renders; 20-node locked group has a reachable working unlock button
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### details-toggle.json
[
  {
    "nodes": 4,
    "defaultOpen": true,
    "manualOpenAfterQueryAndHover": false,
    "unlockReachable": false
  },
  {
    "nodes": 20,
    "defaultOpen": false,
    "manualOpenAfterQueryAndHover": true,
    "unlockReachable": true
  }
]

### pointercancel.json
{
  "pointerId": 2,
  "captureAfterStart": true,
  "captureAfterCancel": false,
  "events": [
    {
      "type": "pointerdown",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "gotpointercapture",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "pointermove",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "pointercancel",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": true
    },
    {
      "type": "lostpointercapture",
      "pointerId": 2,
      "isTrusted": true,
      "captureDuringEvent": false
    }
  ],
  "cameraAfterCancel": {
    "x": 599.7991769234495,
    "y": 245.94908814362964,
    "r": 8.00000011920929
  },
  "cameraAfterUnpressedMoves": {
    "x": 599.7991769234495,
    "y": 245.94908814362964,
    "r": 8.00000011920929
  }
}

### ui-keyboard.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection
PASS production organized group filtering and readable AI relationship reason
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### after.json
[
  {
    "nodes": 1,
    "width": 960,
    "height": 627,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 1,
    "colored": 1
  },
  {
    "nodes": 4,
    "width": 960,
    "height": 571,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 4,
    "colored": 4
  },
  {
    "nodes": 20,
    "width": 960,
    "height": 627,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 20,
    "colored": 20
  },
  {
    "nodes": 200,
    "width": 960,
    "height": 627,
    "css": 960,
    "dpr": 1,
    "backgroundAlpha": 255,
    "visible": 200,
    "colored": 200
  }
]

### extension-tests.log summary
# tests 1331
# pass 1331
# fail 0
# skipped 0
### extension-build.log summary
🟢 DONE   | Finished in 8942ms!
### companion-tests-final.log summary
# tests 5057
# pass 5034
# fail 0
# skipped 23
# tests 20
# pass 20
# fail 0
# skipped 0
### FULL CURRENT chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx
```
// Full-page knowledge distribution graph.
// Spec: docs/superpowers/specs/2026-09-04-knowledge-graph-view-design.md
// Layout: reuse thread-graph force-layout; positions/edges are not persisted.

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type PointerEvent as ReactPointerEvent,
  type WheelEvent as ReactWheelEvent,
} from "react"
import { forceLayoutTick, seedLayoutNodes, type LayoutNode } from "../thread-graph/force-layout"
import { hexWithAlpha, lightenHex, UNTAGGED_COLOR } from "../thread-graph/tag-colors"
import { tokens } from "../sidepanel/ui/tokens"
import { filterKnowledgeNodes, fitKnowledgeCamera, shortKnowledgeTitle } from "./explorer"
import {
  KNOWLEDGE_GRAPH_SNAPSHOT_KEY,
  type KnowledgeGraphSnapshot,
} from "../background/knowledge-graph"
import {
  KnowledgeGraphColorSwitch,
  KnowledgeGraphGroupCard,
  KnowledgeGraphLlmSwitch,
  KnowledgeGraphLockDissolvedBanner,
  KnowledgeGraphNoRelationsNote,
  KnowledgeGraphOrganizeCta,
  KnowledgeGraphOrganizeErrorBar,
  KnowledgeGraphReorganizeButton,
  KnowledgeGraphStaleBadge,
  KnowledgeGraphStatusView,
  KnowledgeGraphTfSwitchBanner,
} from "./chrome"
import { hoverCaption, nodeColor, type ColorMode } from "./coloring"
import {
  KNOWLEDGE_GRAPH_AI_RELATION,
  KNOWLEDGE_GRAPH_ENTRY_LABEL,
  KNOWLEDGE_GRAPH_REASON_DISMISS,
  KNOWLEDGE_GRAPH_UNGROUPED_LABEL,
  knowledgeGraphBarMeta,
  shouldRenderGraphCanvas,
} from "./copy"
import {
  KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
  parseLlmLabelsPref,
  parseTfSwitchAck,
  writeLlmLabelsPref,
  writeTfSwitchAck,
  KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
} from "./llm-pref"
import {
  knowledgeGraphPairKey,
  knowledgeGraphViewModel,
  parseKnowledgeGraphPayload,
  type KnowledgeGraphNode,
  type KnowledgeGraphRelation,
} from "./wire"

type GraphDrawEdge = { a: string; b: string; score: number; dashed?: boolean; reason?: string }

const G = {
  canvas: tokens.darkBg,
  edgeSoft: "rgba(148, 163, 184, 0.22)",
  edgeHot: "rgba(165, 180, 252, 0.75)",
  edgeDim: "rgba(148, 163, 184, 0.06)",
  labelFocus: "rgba(248, 250, 252, 0.95)",
} as const

const HIT_PAD = 8
const REBUILD_POLL_MS = 2500
/** 重建轮询上限（复审 NIT-5）：40 × 2.5s = 100s 后停轮询，诚实提示手动刷新。 */
const REBUILD_POLL_MAX = 40
const EMPTY_NODES: KnowledgeGraphNode[] = []
const EMPTY_EDGES: NonNullable<KnowledgeGraphSnapshot["edges"]> = []
const EMPTY_LABELS: KnowledgeGraphSnapshot["labels"] = {}

function radiusForDegree(deg: number): number {
  return Math.min(10, 5 + Math.sqrt(deg) * 1.4)
}

export function KnowledgeGraphApp() {
  const [snap, setSnap] = useState<KnowledgeGraphSnapshot | null>(null)
  const [colorMode, setColorMode] = useState<ColorMode>("group")
  const [llmEnabled, setLlmEnabled] = useState(false)
  const llmEnabledRef = useRef(false)
  const [focusId, setFocusId] = useState<string | null>(null)
  const [hoverCaptionText, setHoverCaptionText] = useState("")
  const [panelOpen, setPanelOpen] = useState(true)
  const [query, setQuery] = useState("")
  const [groupFilter, setGroupFilter] = useState("")
  const [requestError, setRequestError] = useState("")

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nodesRef = useRef<LayoutNode[]>([])
  const edgesRef = useRef<GraphDrawEdge[]>([])
  const dragRef = useRef<{ id: string; ox: number; oy: number; moved: boolean } | null>(null)
  const [organizing, setOrganizing] = useState(false)
  const confirmedOrganizingRef = useRef(false)
  const [relationOpen, setRelationOpen] = useState<KnowledgeGraphRelation | null>(null)
  const [tfAcked, setTfAcked] = useState(false)
  const [lockNotice, setLockNotice] = useState(false)
  const panRef = useRef({ x: 0, y: 0 })
  const scaleRef = useRef(1)
  const rafRef = useRef(0)
  const sizeRef = useRef({ w: 800, h: 600 })
  const simTicksRef = useRef(0)
  const hoverIdRef = useRef<string | null>(null)
  const focusIdRef = useRef<string | null>(null)
  const fittedRef = useRef(false)
  const userCameraRef = useRef(false)
  const colorByIdRef = useRef<Map<string, string>>(new Map())
  const fitViewRef = useRef<() => void>(() => {})
  const captionByIdRef = useRef<Map<string, string>>(new Map())
  const titleByIdRef = useRef<Map<string, string>>(new Map())

  useEffect(() => {
    focusIdRef.current = focusId
  }, [focusId])

  const applySnap = useCallback((raw: unknown) => {
    const parsed = parseKnowledgeGraphPayload(raw)
    if (!parsed) return
    const rec = raw as Record<string, unknown>
    setSnap({
      ...parsed,
      ts: typeof rec.ts === "number" ? rec.ts : Date.now(),
      focus_id: typeof rec.focus_id === "string" ? rec.focus_id : null,
      llm_labels: rec.llm_labels === true,
    })
    if (typeof rec.focus_id === "string" && rec.focus_id) setFocusId(rec.focus_id)
    confirmedOrganizingRef.current = parsed.organizing === true
    setOrganizing(confirmedOrganizingRef.current)
    setRequestError("")
  }, [])

  const refresh = useCallback(() => {
    // Preserve the existing user-authorized naming preference. Default reads
    // never enable naming or organization on the user's behalf.
    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", llm_labels: llmEnabledRef.current }, (res) => {
      if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
        setRequestError("无法连接 CMspark，请确认程序运行后刷新图谱。已有快照可继续浏览。")
      } else setRequestError("")
    })
  }, [])

  useEffect(() => {
    let cancelled = false
    let receivedSnapshot = false
    ;(async () => {
      try {
        const pref = await chrome.storage.local.get([
          KNOWLEDGE_GRAPH_LLM_LABELS_KEY,
          KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY,
        ])
        if (!cancelled) {
          llmEnabledRef.current = parseLlmLabelsPref(pref[KNOWLEDGE_GRAPH_LLM_LABELS_KEY])
          setLlmEnabled(llmEnabledRef.current)
          setTfAcked(parseTfSwitchAck(pref[KNOWLEDGE_GRAPH_TF_SWITCH_ACK_KEY]))
        }
      } catch {
        /* default off */
      }
      try {
        const res = await chrome.storage.session.get(KNOWLEDGE_GRAPH_SNAPSHOT_KEY)
        if (cancelled) return
        if (!receivedSnapshot) applySnap(res[KNOWLEDGE_GRAPH_SNAPSHOT_KEY])
      } catch {
        /* empty → rebuilding banner via null snap */
      }
      if (!cancelled) refresh()
    })()
    const onStorage = (
      changes: Record<string, chrome.storage.StorageChange>,
      area: string,
    ) => {
      if (area === "session" && changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY]) {
        receivedSnapshot = true
        applySnap(changes[KNOWLEDGE_GRAPH_SNAPSHOT_KEY].newValue)
      }
      if (area === "local" && changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]) {
        llmEnabledRef.current = parseLlmLabelsPref(changes[KNOWLEDGE_GRAPH_LLM_LABELS_KEY].newValue)
        setLlmEnabled(llmEnabledRef.current)
      }

    }
    chrome.storage.onChanged.addListener(onStorage)
    return () => {
      cancelled = true
      chrome.storage.onChanged.removeListener(onStorage)
    }
  }, [applySnap, refresh])

  const status = snap?.status ?? "rebuilding"
  const truncated = snap?.truncated === true
  const showCanvas = snap ? shouldRenderGraphCanvas(status) : false
  const [pollExhausted, setPollExhausted] = useState(false)

  useEffect(() => {
    if (status !== "rebuilding") {
      setPollExhausted(false)
      return
    }
    // 复审 NIT-5：轮询加上限（40 × 2.5s = 100s），打满停轮询并诚实提示手动刷新。
    let polls = 0
    const tick = () => {
      polls += 1
      if (polls > REBUILD_POLL_MAX) {
        setPollExhausted(true)
        clearInterval(id)
        return
      }
      refresh()
    }
    const id = setInterval(tick, REBUILD_POLL_MS)
    return () => clearInterval(id)
  }, [status, refresh])

  const payloadNodes = snap?.nodes ?? EMPTY_NODES
  const payloadEdges = snap?.edges ?? EMPTY_EDGES
  const labels = snap?.labels ?? EMPTY_LABELS
  const view = useMemo(() => knowledgeGraphViewModel(snap), [snap])
  const { llmLane, showOrganizeCta, showReorganize, showNoRelations, relationsToDraw } = view
  const payloadRelations = relationsToDraw
  const llmReady = snap?.llm_ready !== false
  const showTfBanner =
    (status === "ok" || status === "over_cap") &&
    payloadNodes.length >= 20 &&
    (snap?.tf_switch_notice === true || (snap?.tf_switch_notice !== false && !tfAcked))

  const groupKeys = useMemo(() => {
    const seen = new Set<string>()
    const keys: string[] = []
    for (const n of payloadNodes) {
      const k = n.group_key || "u:ungrouped"
      if (seen.has(k)) continue
      seen.add(k)
      keys.push(k)
    }
    return keys
  }, [payloadNodes])

  const visibleNodes = useMemo(() => filterKnowledgeNodes(payloadNodes, query, groupFilter), [payloadNodes, query, groupFilter])
  const selected = payloadNodes.find((n) => n.id === focusId)
  useEffect(() => {
    if (!showCanvas) return
    if (focusId && !payloadNodes.some((n) => n.id === focusId)) setFocusId(null)
    if (groupFilter && !groupKeys.includes(groupFilter)) setGroupFilter("")
  }, [payloadNodes, groupKeys, focusId, groupFilter, showCanvas])

  useEffect(() => {
    const degree = new Map<string, number>()
    for (const n of payloadNodes) degree.set(n.id, 0)
    for (const e of payloadEdges) {
      degree.set(e.a, (degree.get(e.a) || 0) + 1)
      degree.set(e.b, (degree.get(e.b) || 0) + 1)
    }
    for (const r of payloadRelations) {
      degree.set(r.a, (degree.get(r.a) || 0) + 1)
      degree.set(r.b, (degree.get(r.b) || 0) + 1)
    }
    const ids = payloadNodes.map((n) => n.id)
    const radiusById = new Map(ids.map((id) => [id, radiusForDegree(degree.get(id) || 0)]))
    const { w, h } = sizeRef.current
    const previous = new Map(nodesRef.current.map((n) => [n.id, n]))
    nodesRef.current = seedLayoutNodes(ids, w, h, radiusById).map((n) => {
      const old = previous.get(n.id)
      return old ? { ...old, r: n.r } : n
    })
    const tfKeys = new Set(payloadEdges.map((e) => knowledgeGraphPairKey(e.a, e.b)))
    const reasonByPair = new Map<string, string>()
    for (const r of payloadRelations) {
      reasonByPair.set(knowledgeGraphPairKey(r.a, r.b), r.reason)
    }
    const drawn: GraphDrawEdge[] = payloadEdges.map((e) => ({
      a: e.a,
      b: e.b,
      score: e.score,
      reason: reasonByPair.get(knowledgeGraphPairKey(e.a, e.b)),
    }))
    for (const r of payloadRelations) {
      const k = knowledgeGraphPairKey(r.a, r.b)
      if (tfKeys.has(k)) continue
      drawn.push({ a: r.a, b: r.b, score: Math.max(0.08, r.confidence), dashed: true, reason: r.reason })
    }
    edgesRef.current = drawn
    simTicksRef.current = 0
    fittedRef.current = false
    userCameraRef.current = false
  }, [payloadNodes, payloadEdges, payloadRelations])

  useEffect(() => {
    const colors = new Map<string, string>()
    const captions = new Map<string, string>()
    for (const n of payloadNodes) {
      colors.set(n.id, nodeColor(n, colorMode))
      captions.set(n.id, hoverCaption(n, colorMode, labels))
    }
    colorByIdRef.current = colors
    captionByIdRef.current = captions
    titleByIdRef.current = new Map(payloadNodes.map((n) => [n.id, shortKnowledgeTitle(n.title, n.id, payloadNodes.length <= 20 ? 18 : 12)]))
  }, [payloadNodes, colorMode, labels])

  const openDoc = useCallback((id: string) => {
    setFocusId(id)
    setPanelOpen(true)
    chrome.runtime.sendMessage({ type: "knowledge_graph.open_doc", id }, () => {
      void chrome.runtime.lastError
    })
  }, [])

  const onActionResponse = useCallback((res: { ok?: boolean; sent?: boolean } | undefined) => {
    if (chrome.runtime.lastError || res?.ok === false || res?.sent === false) {
      setRequestError("请求未发送，请确认 CMspark 运行后重试。")
      return false
    }
    return true
  }, [])

  useEffect(() => {
    if (!organizing) return
    const timer = setTimeout(() => {
      setOrganizing(false)
      setRequestError("尚未收到整理结果，请刷新查看当前状态后重试。")
    }, 35_000)
    return () => clearTimeout(timer)
  }, [organizing])

  const onLlmChange = useCallback((enabled: boolean) => {
    llmEnabledRef.current = enabled
    setLlmEnabled(enabled)
    void writeLlmLabelsPref(enabled)
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", llm_labels: enabled },
      onActionResponse,
    )
  }, [onActionResponse])

  const onRegenerate = useCallback(() => {
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", llm_labels: true, regenerate: true },
      onActionResponse,
    )
  }, [onActionResponse])

  const sendOrganize = useCallback(() => {
    setOrganizing(true)
    chrome.runtime.sendMessage(
      { type: "knowledge_graph.refresh", organize: true, llm_labels: llmEnabled },
      (res) => { if (!onActionResponse(res)) setOrganizing(confirmedOrganizingRef.current) },
    )
  }, [llmEnabled, onActionResponse])

  const sendLock = useCallback((groupKey: string, unlock: boolean) => {
    chrome.runtime.sendMessage(
      {
        type: "knowledge_graph.refresh",
        llm_labels: llmEnabled,
        ...(unlock ? { unlock_group: groupKey } : { lock_group: groupKey }),
      },
      onActionResponse,
    )
  }, [llmEnabled, onActionResponse])

  useEffect(() => {
    if (snap?.lock_dissolved === true) setLockNotice(true)
  }, [snap?.lock_dissolved])

  useEffect(() => {
    if (!showTfBanner) return
    // 本会话继续展示；落盘 ack 让关 tab 重开不再出现（AC-6）。
    void writeTfSwitchAck()
    chrome.runtime.sendMessage({ type: "knowledge_graph.refresh", ack_tf_switch: true, llm_labels: llmEnabledRef.current }, () => {
      void chrome.runtime.lastError
    })
  }, [showTfBanner])

  const fitView = useCallback(() => {
    const { w, h } = sizeRef.current
    const camera = fitKnowledgeCamera(nodesRef.current, w, h)
    scaleRef.current = camera.scale
    panRef.current = { x: camera.x, y: camera.y }
    fittedRef.current = true
  }, [])
  fitViewRef.current = fitView

  const locateNode = useCallback((id: string) => {
    const n = nodesRef.current.find((node) => node.id === id)
    if (!n) return
    setFocusId(id)
    setPanelOpen(true)
    simTicksRef.current = 999
    userCameraRef.current = true
    scaleRef.current = Math.max(1, scaleRef.current)
    panRef.current = { x: sizeRef.current.w / 2 - n.x * scaleRef.current, y: sizeRef.current.h / 2 - n.y * scaleRef.current }
  }, [])

  const zoom = useCallback((factor: number) => {
    simTicksRef.current = 999
    const prev = scaleRef.current
    const next = Math.min(3.2, Math.max(0.08, prev * factor))
    const { w, h } = sizeRef.current
    panRef.current = { x: w / 2 - ((w / 2 - panRef.current.x) / prev) * next, y: h / 2 - ((h / 2 - panRef.current.y) / prev) * next }
    scaleRef.current = next
    userCameraRef.current = true
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const parent = canvas.parentElement
    if (!parent) return
    const motionPreference = window.matchMedia("(prefers-reduced-motion: reduce)")
    const resize = () => {
      const rect = parent.getBoundingClientRect()
      const dpr = window.devicePixelRatio || 1
      const previousSize = sizeRef.current
      sizeRef.current = { w: rect.width, h: rect.height }
      canvas.width = Math.max(1, Math.floor(rect.width * dpr))
      canvas.height = Math.max(1, Math.floor(rect.height * dpr))
      canvas.style.width = `${rect.width}px`
      canvas.style.height = `${rect.height}px`
      const ctx = canvas.getContext("2d")
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      if (userCameraRef.current) {
        // Preserve scale and the world point at the center during reflow.
        panRef.current.x += (rect.width - previousSize.w) / 2
        panRef.current.y += (rect.height - previousSize.h) / 2
      } else fitViewRef.current()
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(parent)
    const draw = () => {
      const ctx = canvas.getContext("2d")
      if (!ctx) return
      const { w, h } = sizeRef.current
      const reduceMotion = motionPreference.matches
      for (let step = 0; step < (reduceMotion ? 320 : 6) && simTicksRef.current < 320 && nodesRef.current.length > 0; step++) {
        const e = forceLayoutTick(nodesRef.current, edgesRef.current, { width: w, height: h })
        simTicksRef.current++
        if ((e < 0.06 && simTicksRef.current > 50) || simTicksRef.current >= 320) {
          simTicksRef.current = 999
          if (!userCameraRef.current) fitViewRef.current()
        }
      }
      if (!userCameraRef.current && (!fittedRef.current || simTicksRef.current < 320)) fitViewRef.current()
      ctx.clearRect(0, 0, w, h)
      ctx.fillStyle = G.canvas
      ctx.fillRect(0, 0, w, h)
      ctx.save()
      ctx.translate(panRef.current.x, panRef.current.y)
      ctx.scale(scaleRef.current, scaleRef.current)
      const byId = new Map(nodesRef.current.map((n) => [n.id, n]))
      const active = hoverIdRef.current || focusIdRef.current
      let hot: Set<string> | null = null
      if (active) {
        hot = new Set([active])
        for (const e of edgesRef.current) {
          if (e.a === active) hot.add(e.b)
          if (e.b === active) hot.add(e.a)
        }
      }
      const scale = scaleRef.current
      for (const e of edgesRef.current) {
        const a = byId.get(e.a)
        const b = byId.get(e.b)
        if (!a || !b) continue
        const isHot = hot ? hot.has(e.a) && hot.has(e.b) : false
        ctx.beginPath()
        ctx.moveTo(a.x, a.y)
        ctx.lineTo(b.x, b.y)
        ctx.strokeStyle = hot != null && !isHot ? G.edgeDim : isHot ? G.edgeHot : G.edgeSoft
        ctx.lineWidth = Math.min(1.6, 0.4 + e.score * 0.5) / Math.max(0.6, scale)
        if (e.dashed) ctx.setLineDash([5 / Math.max(0.6, scale), 4 / Math.max(0.6, scale)])
        else ctx.setLineDash([])
        ctx.stroke()
        ctx.setLineDash([])
        if (e.dashed && (hot == null || isHot)) {
          const mx = (a.x + b.x) / 2
          const my = (a.y + b.y) / 2
          ctx.fillStyle = G.labelFocus
          ctx.font = `${9 / Math.max(0.75, Math.min(1.25, scale))}px ${tokens.font}`
          ctx.textAlign = "center"
          ctx.textBaseline = "bottom"
          ctx.fillText(KNOWLEDGE_GRAPH_AI_RELATION, mx, my - 2)
        }
      }
      const labelBoxes: { x: number; y: number; w: number; h: number }[] = []
      // Selected titles take priority; collisions only suppress canvas labels,
      // never the complete accessible knowledge list.
      const drawNodes = [...nodesRef.current].sort((a, b) => Number(b.id === active) - Number(a.id === active))
      for (const n of drawNodes) {
        const isFocus = n.id === focusIdRef.current
        const isHover = n.id === hoverIdRef.current
        const inHot = hot ? hot.has(n.id) : true
        const dimmed = hot != null && !inHot
        const baseColor = colorByIdRef.current.get(n.id) || UNTAGGED_COLOR
        if (isFocus || isHover) {
          ctx.beginPath()
          ctx.arc(n.x, n.y, n.r + 3.5, 0, Math.PI * 2)
          ctx.fillStyle = hexWithAlpha(baseColor, isFocus ? 0.28 : 0.18)
          ctx.fill()
        }
        ctx.beginPath()
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
        ctx.fillStyle = isFocus
          ? lightenHex(baseColor, 0.45)
          : isHover
            ? lightenHex(baseColor, 0.28)
            : dimmed
              ? hexWithAlpha(baseColor, 0.7)
              : baseColor
        ctx.globalAlpha = 1
        ctx.fill()
        ctx.globalAlpha = 1
        {
          ctx.fillStyle = dimmed ? tokens.darkMuted : G.labelFocus
          ctx.font = `${13 / scale}px ${tokens.font}`
          ctx.textAlign = "center"
          ctx.textBaseline = "top"
          const cap = titleByIdRef.current.get(n.id) || n.id
          const textWidth = ctx.measureText(cap).width * scale
          const sx = n.x * scale + panRef.current.x
          const sy = (n.y + n.r) * scale + panRef.current.y + 7
          const box = { x: sx - textWidth / 2, y: sy, w: textWidth, h: 17 }
          const overlaps = labelBoxes.some((b) => box.x < b.x + b.w + 8 && box.x + box.w + 8 > b.x && box.y < b.y + b.h + 4 && box.y + box.h + 4 > b.y)
          if ((isFocus || isHover || !overlaps) && box.x >= 2 && box.x + box.w <= w - 2 && sy + 17 < h) {
            labelBoxes.push(box)
            ctx.fillText(cap, n.x, n.y + n.r + 7 / scale)
          }
        }
      }
      ctx.restore()
      rafRef.current = requestAnimationFrame(draw)
    }
    rafRef.current = requestAnimationFrame(draw)
    return () => {
      ro.disconnect()
      cancelAnimationFrame(rafRef.current)
    }
  }, [showCanvas])

  const hitTest = (clientX: number, clientY: number): LayoutNode | null => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const rect = canvas.getBoundingClientRect()
    const scale = Math.max(0.001, scaleRef.current)
    const x = (clientX - rect.left - panRef.current.x) / scale
    const y = (clientY - rect.top - panRef.current.y) / scale
    const pad = HIT_PAD / scale
    let best: LayoutNode | null = null
    let bestD = Infinity
    for (const n of nodesRef.current) {
      const d = Math.hypot(n.x - x, n.y - y)
      if (d <= n.r + pad && d < bestD) {
        best = n
        bestD = d
      }
    }
    return best
  }

  const hitTestEdge = (clientX: number, clientY: number): GraphDrawEdge | null => {
    const canvas = canvasRef.current
    if (!canvas) return null
    const rect = canvas.getBoundingClientRect()
    const scale = Math.max(0.001, scaleRef.current)
    const x = (clientX - rect.left - panRef.current.x) / scale
    const y = (clientY - rect.top - panRef.current.y) / scale
    const byId = new Map(nodesRef.current.map((n) => [n.id, n]))
    const thresh = 6 / scale
    let best: GraphDrawEdge | null = null
    let bestD = thresh
    for (const e of edgesRef.current) {
      if (!e.reason && !e.dashed) continue
      const a = byId.get(e.a)
      const b = byId.get(e.b)
      if (!a || !b) continue
      const dx = b.x - a.x
      const dy = b.y - a.y
      const len2 = dx * dx + dy * dy
      if (len2 < 1) continue
      let t = ((x - a.x) * dx + (y - a.y) * dy) / len2
      t = Math.max(0, Math.min(1, t))
      const px = a.x + t * dx
      const py = a.y + t * dy
      const d = Math.hypot(x - px, y - py)
      if (d < bestD) {
        best = e
        bestD = d
      }
    }
    return best
  }

  const endDrag = (ev?: ReactPointerEvent) => {
    const drag = dragRef.current
    if (drag && drag.id !== "__pan__" && !drag.moved) {
      locateNode(drag.id)
    }
    if (drag && drag.id === "__pan__" && !drag.moved && ev) {
      const edge = hitTestEdge(ev.clientX, ev.clientY)
      if (edge?.reason) {
        setPanelOpen(true)
        setRelationOpen({
          a: edge.a,
          b: edge.b,
          reason: edge.reason,
          confidence: edge.score,
          ai: true,
        })
      }
    }
    if (ev?.target && "releasePointerCapture" in (ev.target as Element)) {
      try {
        ;(ev.target as HTMLElement).releasePointerCapture?.(ev.pointerId)
      } catch {
        /* already released */
      }
    }
    dragRef.current = null
  }

  const onPointerDown = (ev: ReactPointerEvent) => {
    simTicksRef.current = 999
    const n = hitTest(ev.clientX, ev.clientY)
    if (n) {
      dragRef.current = { id: n.id, ox: ev.clientX, oy: ev.clientY, moved: false }
      setFocusId(n.id)
      setPanelOpen(true)
      ;(ev.target as HTMLElement).setPointerCapture?.(ev.pointerId)
      return
    }
    setFocusId(null)
    dragRef.current = { id: "__pan__", ox: ev.clientX, oy: ev.clientY, moved: false }
    ;(ev.target as HTMLElement).setPointerCapture?.(ev.pointerId)
  }

  const onPointerMove = (ev: ReactPointerEvent) => {
    const drag = dragRef.current
    if (!drag) {
      const n = hitTest(ev.clientX, ev.clientY)
      hoverIdRef.current = n?.id ?? null
      if (n) {
        setHoverCaptionText(captionByIdRef.current.get(n.id) || "")
      } else {
        const edge = hitTestEdge(ev.clientX, ev.clientY)
        setHoverCaptionText(
          edge?.reason
            ? `${edge.dashed ? KNOWLEDGE_GRAPH_AI_RELATION + " · " : ""}${edge.reason}`
            : "",
        )
      }
      return
    }
    const dx = ev.clientX - drag.ox
    const dy = ev.clientY - drag.oy
    if (Math.abs(dx) + Math.abs(dy) > 2) {
      drag.moved = true
      if (drag.id === "__pan__") userCameraRef.current = true
    }
    drag.ox = ev.clientX
    drag.oy = ev.clientY
    if (drag.id === "__pan__") {
      panRef.current.x += dx
      panRef.current.y += dy
      return
    }
    const n = nodesRef.current.find((x) => x.id === drag.id)
    if (n) {
      n.x += dx / scaleRef.current
      n.y += dy / scaleRef.current
    }
  }

  const onWheel = (ev: ReactWheelEvent) => {
    simTicksRef.current = 999
    ev.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const mx = ev.clientX - rect.left
    const my = ev.clientY - rect.top
    const prev = scaleRef.current
    const next = Math.min(3.2, Math.max(0.08, prev * (ev.deltaY > 0 ? 0.92 : 1.08)))
    panRef.current.x = mx - ((mx - panRef.current.x) / prev) * next
    panRef.current.y = my - ((my - panRef.current.y) / prev) * next
    scaleRef.current = next
    userCameraRef.current = true
  }

  const ungroupedKey = groupKeys.find((k) => k === "u:ungrouped" || k === "" || k === "ungrouped")
  const relatedEdges = useMemo<GraphDrawEdge[]>(() => selected ? [
    ...payloadEdges.map((e) => ({ ...e, reason: payloadRelations.find((r) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))?.reason })),
    ...payloadRelations.filter((r) => !payloadEdges.some((e) => knowledgeGraphPairKey(r.a, r.b) === knowledgeGraphPairKey(e.a, e.b))).map((r) => ({ ...r, score: r.confidence, dashed: true })),
  ].filter((e) => e.a === selected.id || e.b === selected.id) : [], [selected, payloadEdges, payloadRelations])

  return (
    <div className="kg-page" style={styles.page}>
      <style>{graphStyles}</style>
      <header className="kg-toolbar" role="toolbar" aria-label={`${KNOWLEDGE_GRAPH_ENTRY_LABEL}工具栏`}>
        <div className="kg-heading"><strong>{KNOWLEDGE_GRAPH_ENTRY_LABEL}</strong><span>{showCanvas ? knowledgeGraphBarMeta(payloadNodes.length, payloadEdges.length, payloadRelations.length) : "浏览知识与关联"}</span></div>
        <KnowledgeGraphColorSwitch mode={colorMode} onChange={setColorMode} />
        <button type="button" onClick={refresh}>刷新图谱</button>
        <button type="button" aria-expanded={panelOpen} onClick={() => setPanelOpen((v) => !v)}>{panelOpen ? "收起列表" : "浏览知识"}</button>
        <details className="kg-ai-options">
          <summary>AI 与分组</summary>
          <div>
            <KnowledgeGraphLlmSwitch enabled={llmEnabled} onChange={onLlmChange} onRegenerate={onRegenerate} />
            {showReorganize ? <KnowledgeGraphReorganizeButton organizing={organizing} disabled={!llmReady} onClick={sendOrganize} /> : null}
            {snap?.stale === true && llmLane ? <KnowledgeGraphStaleBadge /> : null}
          </div>
        </details>
        <button type="button" onClick={() => window.close()} title="关闭此标签页">关闭</button>
      </header>
      <div className="kg-notices">
        {requestError ? <div className="kg-notice" role="alert">{requestError}</div> : null}
        {status !== "ok" ? <KnowledgeGraphStatusView status={status} truncated={truncated} pollExhausted={pollExhausted} error={snap?.error} /> : null}
        {status === "ok" && showOrganizeCta ? <KnowledgeGraphOrganizeCta n={payloadNodes.length} disabled={!llmReady} organizing={organizing} onOrganize={sendOrganize} /> : null}
        {status === "ok" && snap?.organize_error ? <KnowledgeGraphOrganizeErrorBar error={snap.organize_error} onRetry={sendOrganize} /> : null}
        {showTfBanner ? <KnowledgeGraphTfSwitchBanner /> : null}
        {lockNotice ? <div className="kg-notice"><KnowledgeGraphLockDissolvedBanner /><button type="button" onClick={() => setLockNotice(false)}>知道了</button></div> : null}
      </div>
      <div className={`kg-workspace ${panelOpen ? "" : "kg-workspace-wide"}`}>
        <section className="kg-map" aria-label="知识关系画布">
          <div className="kg-map-tools">
            <span>实线：内容相似 · 虚线：AI 关联</span>
            <div>
              <button type="button" disabled={!showCanvas} onClick={() => { userCameraRef.current = false; fitView() }}>适应画布</button>
              <button type="button" disabled={!showCanvas} aria-label="放大" onClick={() => zoom(1.25)}>＋</button>
              <button type="button" disabled={!showCanvas} aria-label="缩小" onClick={() => zoom(0.8)}>－</button>
            </div>
          </div>
          <main style={styles.main}>
            {showCanvas ? <canvas ref={canvasRef} data-testid="knowledge-graph-canvas" style={styles.canvas} role="img" tabIndex={0}
              aria-label="知识分布图谱。点击节点查看关联；也可在知识列表搜索并定位。方向键平移，加减号缩放，0 适应画布。"
              onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={(ev) => endDrag(ev)}
              onPointerLeave={() => { hoverIdRef.current = null; setHoverCaptionText("") }}
              onPointerCancel={() => { dragRef.current = null }}
              onWheel={onWheel}
              onKeyDown={(ev) => {
                if (ev.key === "0" || ev.key === "Home") { ev.preventDefault(); userCameraRef.current = false; fitView() }
                if (ev.key === "+" || ev.key === "=" || ev.key === "-") { ev.preventDefault(); zoom(ev.key === "-" ? 0.8 : 1.25) }
                const delta: Record<string, [number, number]> = { ArrowLeft: [40, 0], ArrowRight: [-40, 0], ArrowUp: [0, 40], ArrowDown: [0, -40] }
                if (delta[ev.key]) { ev.preventDefault(); simTicksRef.current = 999; userCameraRef.current = true; panRef.current.x += delta[ev.key][0]; panRef.current.y += delta[ev.key][1] }
                if (ev.key === "Escape") { setFocusId(null); setRelationOpen(null) }
              }}
            /> : <div className="kg-placeholder">知识文档和真实关联将在这里显示</div>}
          </main>
          <div className="kg-map-caption" role="status">
            {hoverCaptionText || (showCanvas && !payloadEdges.length && !payloadRelations.length ? "暂无明确关联，仍可浏览全部知识" : "拖动画布 · 滚轮缩放 · 点击知识查看关联")}
          </div>
        </section>
        {panelOpen ? (
          <aside className="kg-explorer" aria-label="知识浏览">
            <div className="kg-search">
              <label htmlFor="kg-search">浏览知识</label>
              <input id="kg-search" aria-label="搜索知识" placeholder="搜索标题、文件夹…" value={query} onChange={(ev) => setQuery(ev.target.value)} />
              <select aria-label="筛选分组" value={groupFilter} onChange={(ev) => setGroupFilter(ev.target.value)}>
                <option value="">全部分组</option>
                {groupKeys.map((k) => <option key={k} value={k}>{labels[k]?.name || (k === ungroupedKey ? KNOWLEDGE_GRAPH_UNGROUPED_LABEL : k)}</option>)}
              </select>
              <span role="status">{visibleNodes.length} / {payloadNodes.length} 篇知识</span>
            </div>
            {selected ? <section className="kg-selection" aria-label="选中知识">
              <div className="kg-selection-heading"><strong>{selected.title || selected.id}</strong><button aria-label="取消选中知识" onClick={() => setFocusId(null)}>取消</button></div>
              <p>{selected.folder || "未设置文件夹"}</p>
              <button type="button" onClick={() => openDoc(selected.id)}>在知识面板打开</button>
              <h3>相关知识 · {relatedEdges.length}</h3>
              {relatedEdges.length === 0 ? <p>暂无明确关联</p> : relatedEdges.map((edge) => {
                const id = edge.a === selected.id ? edge.b : edge.a
                const other = payloadNodes.find((node) => node.id === id)
                return <div key={id} className="kg-relation">
                  <button type="button" onClick={() => locateNode(id)}>{other?.title || id}</button>
                  <span>{edge.dashed ? "AI 关联" : "内容相似"}</span>
                  {edge.reason ? <p>AI 关联理由：{edge.reason}</p> : null}
                </div>
              })}
            </section> : null}
            {relationOpen ? <section className="kg-selection" aria-label="关联理由" data-testid="kg-relation-reason">
              <strong>{KNOWLEDGE_GRAPH_AI_RELATION}</strong><p>{relationOpen.reason}</p>
              <button type="button" onClick={() => setRelationOpen(null)}>{KNOWLEDGE_GRAPH_REASON_DISMISS}</button>
            </section> : null}
            <div className="kg-document-list" aria-label="知识列表">
              {visibleNodes.map((n) => <button type="button" key={n.id} data-node-id={n.id} aria-pressed={n.id === focusId} onClick={() => locateNode(n.id)}>
                <span className="kg-dot" style={{ background: nodeColor(n, colorMode) }} aria-hidden="true" />
                <span><strong>{n.title || n.id}</strong><small>{n.folder || labels[n.group_key]?.name || KNOWLEDGE_GRAPH_UNGROUPED_LABEL}</small></span>
              </button>)}
              {!visibleNodes.length ? <p>{payloadNodes.length ? "没有匹配的知识。可清空搜索或切换分组。" : "当前没有可浏览的知识。"}</p> : null}
              {(query || groupFilter) ? <button type="button" onClick={() => { setQuery(""); setGroupFilter("") }}>清除筛选</button> : null}
            </div>
            <details className="kg-groups" open={payloadNodes.length <= 19}>
              <summary>分组说明与管理 · {groupKeys.length}</summary>
              {showNoRelations ? <KnowledgeGraphNoRelationsNote /> : null}
              {groupKeys.map((k) => {
                const llmGroup = k.startsWith("l:")
                return <KnowledgeGraphGroupCard key={k} groupKey={k}
                  label={labels[k] || (k === ungroupedKey ? { name: KNOWLEDGE_GRAPH_UNGROUPED_LABEL, ai: false } : undefined)}
                  llmEnabled={llmEnabled} llmLaneGroup={llmGroup}
                  onLock={llmLane && llmGroup ? () => sendLock(k, false) : undefined}
                  onUnlock={llmGroup && labels[k]?.locked === true ? () => sendLock(k, true) : undefined} />
              })}
            </details>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

const styles: Record<string, CSSProperties> = {
  page: { minHeight: "100dvh", height: "100dvh", margin: 0, fontFamily: tokens.font, background: G.canvas, color: tokens.darkText, display: "flex", flexDirection: "column", overflow: "auto" },
  main: { position: "relative", flex: 1, minHeight: 280 },
  canvas: { width: "100%", height: "100%", position: "absolute", inset: 0, display: "block", cursor: "grab", touchAction: "none" },
}

const graphStyles = `
  .kg-page * { box-sizing: border-box; }
  .kg-page button, .kg-page input, .kg-page select, .kg-page summary { font: inherit; font-size: 13px; }
  .kg-page button { min-height: 32px; border: 1px solid ${tokens.darkBorder}; background: transparent; color: ${tokens.darkText}; border-radius: 8px; padding: 5px 10px; cursor: pointer; }
  .kg-page button:disabled { opacity: .45; cursor: not-allowed; }
  .kg-page button:hover:not(:disabled), .kg-page button[aria-pressed=true] { background: ${tokens.darkElevated}; }
  .kg-page :focus-visible { outline: 2px solid ${tokens.darkMuted}; outline-offset: 2px; }
  .kg-page summary { cursor: pointer; padding: 8px 0; }
  .kg-toolbar { padding: 16px 20px; border-bottom: 1px solid ${tokens.darkBorder}; display: flex; flex-wrap: wrap; gap: 10px; align-items: center; flex-shrink: 0; }
  .kg-heading { display: flex; flex-direction: column; gap: 4px; margin-right: auto; }
  .kg-heading strong { font-size: 18px; }
  .kg-heading span, .kg-search>span { color: ${tokens.darkMuted}; font-size: 12px; }
  .kg-ai-options[open] { flex-basis: 100%; order: 2; }
  .kg-ai-options>div { display: flex; flex-wrap: wrap; gap: 12px; padding: 8px 0; }
  .kg-notices { flex-shrink: 0; max-height: 30dvh; overflow: auto; background: ${tokens.darkElevated}; }
  .kg-notice { padding: 12px 16px; font-size: 13px; }
  .kg-workspace { display: grid; grid-template-columns: minmax(0,1fr) 320px; flex: 1; min-height: 400px; }
  .kg-workspace-wide { grid-template-columns: minmax(0,1fr); }
  .kg-map { display: flex; flex-direction: column; min-width: 0; min-height: 360px; }
  .kg-map-tools { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 8px; padding: 12px 16px; }
  .kg-map-tools span, .kg-map-caption { color: ${tokens.darkMuted}; font-size: 12px; line-height: 1.5; }
  .kg-map-tools>div { display: flex; gap: 6px; }
  .kg-map-caption { padding: 8px 16px 12px; min-height: 38px; overflow-wrap: anywhere; }
  .kg-placeholder { height: 100%; display: grid; place-items: center; color: ${tokens.darkMuted}; padding: 24px; text-align: center; }
  .kg-explorer { overflow: auto; border-left: 1px solid ${tokens.darkBorder}; padding: 16px; min-width: 0; }
  .kg-search { display: grid; gap: 10px; margin-bottom: 16px; position: sticky; top: 0; z-index: 1; background: ${G.canvas}; padding-bottom: 8px; }
  .kg-search label { font-size: 14px; font-weight: 600; }
  .kg-search input, .kg-search select { width: 100%; min-width: 0; min-height: 36px; background: ${tokens.darkElevated}; color: ${tokens.darkText}; border: 1px solid ${tokens.darkBorder}; border-radius: 8px; padding: 8px; }
  .kg-document-list>button { width: 100%; display: flex; gap: 10px; align-items: center; text-align: left; border-color: transparent; padding: 10px 8px; }
  .kg-document-list strong { font-size: 13px; font-weight: 500; overflow-wrap: anywhere; }
  .kg-document-list small { display: block; color: ${tokens.darkMuted}; font-size: 12px; margin-top: 4px; overflow-wrap: anywhere; }
  .kg-document-list p, .kg-selection p { font-size: 13px; line-height: 1.6; color: ${tokens.darkMuted}; overflow-wrap: anywhere; }
  .kg-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
  .kg-selection { padding: 12px; border: 1px solid ${tokens.darkBorder}; border-radius: 10px; margin-bottom: 12px; }
  .kg-selection-heading { display: flex; align-items: start; gap: 8px; }
  .kg-selection-heading strong { flex: 1; min-width: 0; overflow-wrap: anywhere; font-size: 14px; }
  .kg-selection h3 { font-size: 13px; margin: 16px 0 8px; }
  .kg-relation { margin-top: 10px; }
  .kg-relation>button { display: block; text-align: left; overflow-wrap: anywhere; max-width: 100%; }
  .kg-relation>span { display: block; font-size: 12px; color: ${tokens.darkMuted}; margin-top: 4px; }
  .kg-groups { margin-top: 16px; border-top: 1px solid ${tokens.darkBorder}; }
  @media(max-width: 759px) {
    .kg-toolbar { padding: 12px; gap: 8px; }
    .kg-heading { flex-basis: 100%; }
    .kg-workspace, .kg-workspace-wide { display: flex; flex-direction: column; flex: none; min-height: 0; }
    .kg-map { height: 440px; flex-shrink: 0; }
    .kg-explorer { border-left: none; border-top: 1px solid ${tokens.darkBorder}; overflow: visible; }
  }
`

```

### FULL CURRENT chrome-extension/src/knowledge-graph/explorer.ts
```
import type { LayoutNode } from "../thread-graph/force-layout"
import type { KnowledgeGraphNode } from "./wire"

/** List filters never remove data from the graph or change its relationships. */
export function filterKnowledgeNodes(nodes: KnowledgeGraphNode[], query: string, group: string): KnowledgeGraphNode[] {
  const term = query.trim().toLocaleLowerCase()
  return nodes.filter((node) =>
    (!group || (node.group_key || "u:ungrouped") === group) &&
    (!term || `${node.title}\n${node.folder}\n${node.id}`.toLocaleLowerCase().includes(term)),
  )
}

/** Fit the actual canvas, including room for labels; tiny viewports may zoom out. */
export function fitKnowledgeCamera(nodes: Pick<LayoutNode, "x" | "y" | "r">[], w: number, h: number) {
  if (!nodes.length || w <= 0 || h <= 0) return { scale: 1, x: 0, y: 0 }
  const minX = Math.min(...nodes.map((n) => n.x - n.r))
  const maxX = Math.max(...nodes.map((n) => n.x + n.r))
  const minY = Math.min(...nodes.map((n) => n.y - n.r))
  const maxY = Math.max(...nodes.map((n) => n.y + n.r))
  const scale = Math.min(1.6, Math.max(1, w - 96) / Math.max(40, maxX - minX), Math.max(1, h - 88) / Math.max(40, maxY - minY))
  return { scale, x: w / 2 - ((minX + maxX) / 2) * scale, y: h / 2 - ((minY + maxY) / 2) * scale }
}

export function shortKnowledgeTitle(title: string, id: string, limit = 18): string {
  const chars = Array.from(title.trim() || id)
  return chars.length > limit ? `${chars.slice(0, limit).join("")}…` : chars.join("")
}

```

### FULL CURRENT chrome-extension/scripts/test-knowledge-graph-ui.py
```
"""Real graph builder + KnowledgeGraphApp, delayed storage, isolated Chrome.

Run after nvm use 22:
  uv run --with playwright python scripts/test-knowledge-graph-ui.py
"""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', action='store_true', help='Capture the pre-fix failure without hiding its assertion')
parser.add_argument('--artifacts', type=Path, default=Path(__file__).resolve().parents[2] / '.omx/artifacts/knowledge-graph-490')
args = parser.parse_args()
args.artifacts.mkdir(parents=True, exist_ok=True)
project = Path(__file__).resolve().parent.parent

with tempfile.TemporaryDirectory(prefix='cmspark-knowledge-graph-') as directory:
    subprocess.run(['node', 'scripts/render-knowledge-graph-fixture.cjs', directory] + (['--baseline'] if args.baseline else []), cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 800})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        assert page.locator('canvas').count() == 0, 'Initial storage read must remain asynchronous'
        page.evaluate("window.graphFixture.release('4')")
        page.locator('canvas').wait_for()
        if args.baseline:
            page.wait_for_timeout(400)
            evidence = page.evaluate('''() => {
                const c=document.querySelector('canvas');
                return {storageReleased:window.storageReleased, snapshotNodes:window.graphFixture.readSnapshot().nodes.length,
                    canvasWidth:c.width,canvasHeight:c.height,cssWidth:c.getBoundingClientRect().width,
                    drawnArcs:window.drawProbe.arcs,drawnFrames:window.drawProbe.frames,
                    opaquePixels:[...c.getContext('2d').getImageData(0,0,c.width,c.height).data].filter((v,i)=>i%4===3&&v>0).length};
            }''')
            page.screenshot(path=str(args.artifacts / 'before.png'), full_page=True)
            (args.artifacts / 'before.json').write_text(json.dumps(evidence, indent=2) + '\n')
            print(json.dumps(evidence, indent=2), flush=True)
            assert evidence['drawnArcs'] >= 4 and evidence['opaquePixels'] > 0, 'Async snapshot mounted a Canvas but never started the drawing effect'
        def painted(count):
            pixels = page.wait_for_function('''(count) => {
                const c=document.querySelector('canvas');if(!c)return false;
                const ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];
                const arcs=window.drawProbe.latestArcs;
                const visible=arcs.filter(p=>p.x>=0&&p.x<c.width&&p.y>=0&&p.y<c.height);
                const colored=visible.filter(p=>{
                    const pixel=[...ctx.getImageData(Math.floor(p.x),Math.floor(p.y),1,1).data];
                    return pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]);
                });
                if(arcs.length<count||bg[3]!==255||!colored.length)return false;
                return {width:c.width,height:c.height,css:c.getBoundingClientRect().width,
                    dpr:devicePixelRatio,backgroundAlpha:bg[3],visible:visible.length,colored:colored.length};
            }''', arg=count).json_value()
            assert pixels['width'] == int(pixels['css'] * pixels['dpr']), pixels
            assert pixels['height'] >= 280, pixels
            assert pixels['backgroundAlpha'] == 255 and pixels['colored'] > 0, pixels
            return pixels

        def open_fixture(count):
            page.goto((Path(directory) / 'index.html').as_uri())
            page.wait_for_function('window.storageReads===1')
            assert page.locator('canvas').count() == 0
            page.evaluate('(count)=>window.graphFixture.release(String(count))', count)
            if count == 0:
                page.get_by_text('知识库暂无可展示的文档', exact=False).wait_for()
                return
            page.get_by_test_id('knowledge-graph-canvas').wait_for()
            painted(count)

        painted(4)
        summaries = []
        for count in [1, 4, 20, 200]:
            open_fixture(count)
            page.wait_for_function("window.drawProbe.latestText.some(text=>text.includes('SQLite'))")
            assert page.locator('button[data-node-id]').count() == count
            assert page.evaluate('window.graphFixture.readSnapshot().edges.length') == 0
            page.get_by_text('暂无明确关联，仍可浏览全部知识', exact=True).wait_for()
            assert not page.evaluate("window.sent.some(m=>m.organize||m.type==='knowledge_graph.open_doc')")
            if count == 200:
                page.wait_for_function('window.drawProbe.frameHistory.length>=20')
                initial_frames = page.evaluate('window.drawProbe.frameHistory.slice(0,20)')
                assert all(frame['nodes'] == 200 and frame['visible'] == 200 for frame in initial_frames), initial_frames
                (args.artifacts / 'initial-200-frames.json').write_text(json.dumps(initial_frames, indent=2) + '\n')
            summaries.append({'nodes': count, **painted(count)})
            page.screenshot(path=str(args.artifacts / f'after-{count}.png'), full_page=True)
        print('PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state')

        # Removing a Canvas must stop its loop; a later success creates a working
        # new Canvas, independently of the mount that originally saw null refs.
        page.evaluate("window.oldCanvas=document.querySelector('canvas');window.graphFixture.publish('error')")
        page.locator('canvas').wait_for(state='detached')
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        stopped_frames = page.evaluate('window.drawProbe.frames')
        page.wait_for_timeout(80)
        assert page.evaluate('window.drawProbe.frames') == stopped_frames
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.refresh')")
        page.evaluate("window.drawProbe.latestArcs=[];window.graphFixture.publish('4')")
        painted(4)
        assert page.evaluate("window.oldCanvas!==document.querySelector('canvas')")
        print('PASS ok → error stops drawing → refresh → ok remount draws real nodes')

        page.evaluate('window.sendFailure=true')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        page.get_by_text('无法连接 CMspark', exact=False).wait_for()
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        page.evaluate('window.sendFailure=false')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        print('PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI')

        search = page.get_by_role('textbox', name='搜索知识', exact=True)
        search.fill('不存在的知识')
        assert page.locator('button[data-node-id]').count() == 0
        assert page.locator('canvas').is_visible()
        search.fill('Telescope')
        assert page.locator('button[data-node-id]').count() == 1
        page.locator('button[data-node-id="fixture-003"]').click()
        assert not page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.open_doc')")
        page.get_by_role('button', name='在知识面板打开', exact=True).click()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').map(m=>m.id)") == ['fixture-003']
        search.fill('')
        radius = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='放大', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r>r', arg=radius)
        enlarged = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='缩小', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r<r', arg=enlarged)
        page.get_by_role('button', name='适应画布', exact=True).click()
        painted(4)
        page.get_by_role('button', name='收起列表', exact=True).click()
        assert page.get_by_role('complementary', name='知识浏览', exact=True).count() == 0
        page.get_by_role('button', name='浏览知识', exact=True).click()
        page.get_by_role('complementary', name='知识浏览', exact=True).wait_for()
        print('PASS search incl. empty results, local selection, explicit document open, camera and list controls')

        # Exercise actual keyboard events against the focused Canvas. Wait for
        # the physical simulation to settle so movement proves the key handler,
        # rather than merely observing an unrelated animation frame.
        canvas = page.get_by_test_id('knowledge-graph-canvas')
        canvas.focus()
        page.keyboard.press('Escape')
        page.wait_for_function('''() => {
            const arc=window.drawProbe.latestArcs[0];if(!arc)return false;
            const last=window.keyboardLastArc;
            window.keyboardStableFrames=last&&Math.abs(last.x-arc.x)<0.001&&Math.abs(last.y-arc.y)<0.001
                ? (window.keyboardStableFrames||0)+1 : 0;
            window.keyboardLastArc={x:arc.x,y:arc.y};
            return window.keyboardStableFrames>=6;
        }''')
        page.keyboard.press('0')
        page.wait_for_timeout(50)
        fitted_arc = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        page.keyboard.press('ArrowLeft')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x-40)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('Home')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('ArrowRight')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x+40)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('0')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('+')
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r*1.25)<0.01', arg=fitted_arc['r'])
        page.keyboard.press('-')
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r)<0.01', arg=fitted_arc['r'])
        keyboard_document = page.locator('button[data-node-id="fixture-002"]')
        keyboard_document.focus()
        page.keyboard.press('Enter')
        page.wait_for_function('document.querySelector("button[data-node-id=fixture-002]").getAttribute("aria-pressed")==="true"')
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Orchids 高山兰花', exact=True).wait_for()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length") == 1
        canvas.focus()
        page.keyboard.press('Escape')
        page.get_by_role('region', name='选中知识', exact=True).wait_for(state='detached')
        assert keyboard_document.get_attribute('aria-pressed') == 'false'
        print('PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection')

        # CDP injects real trusted touch input through Chrome's input pipeline.
        # DOM dispatchEvent cannot test the UA's implicit pointer-capture release.
        page.evaluate('''() => {
            window.touchEvidence=[];
            const c=document.querySelector('canvas');
            for(const type of ['pointerdown','pointermove','pointercancel','gotpointercapture','lostpointercapture']){
                c.addEventListener(type,event=>{
                    if(event.pointerType==='touch')window.touchEvidence.push({type:event.type,
                        pointerId:event.pointerId,isTrusted:event.isTrusted,
                        captureDuringEvent:c.hasPointerCapture(event.pointerId)});
                });
            }
        }''')
        cdp = page.context.new_cdp_session(page)
        cdp.send('Emulation.setTouchEmulationEnabled', {'enabled': True, 'maxTouchPoints': 1})
        canvas_box = canvas.bounding_box()
        assert canvas_box
        touch_x, touch_y = canvas_box['x'] + 25, canvas_box['y'] + 25
        before_touch = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        opened_before_touch = page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length")
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': touch_x, 'y': touch_y, 'id': 7}]})
        pointer_id = page.evaluate("window.touchEvidence.find(event=>event.type==='pointerdown').pointerId")
        capture_after_start = page.evaluate('(id)=>document.querySelector("canvas").hasPointerCapture(id)', pointer_id)
        assert capture_after_start is True
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': touch_x + 30, 'y': touch_y + 20, 'id': 7}]})
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x-30)<0.1', arg=before_touch['x'])
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchCancel', 'touchPoints': []})
        page.wait_for_function('''(id)=>window.touchEvidence.some(event=>event.type==='pointercancel'&&event.pointerId===id)
            && !document.querySelector('canvas').hasPointerCapture(id)''', arg=pointer_id)
        capture_after_cancel = page.evaluate('(id)=>document.querySelector("canvas").hasPointerCapture(id)', pointer_id)
        touch_events = page.evaluate('window.touchEvidence')
        assert all(event['isTrusted'] and event['pointerId'] == pointer_id for event in touch_events), touch_events
        assert any(event['type'] == 'lostpointercapture' for event in touch_events), touch_events
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length") == opened_before_touch
        assert page.get_by_role('region', name='关联理由', exact=True).count() == 0
        after_cancel = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        # A leftover dragRef would move the camera on subsequent pointermove,
        # even though no new press started a drag. These are real mouse events.
        page.mouse.move(touch_x + 70, touch_y + 55)
        page.mouse.move(touch_x + 110, touch_y + 85)
        page.wait_for_timeout(80)
        after_hover = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        assert abs(after_hover['x'] - after_cancel['x']) < 0.1 and abs(after_hover['y'] - after_cancel['y']) < 0.1, (after_cancel, after_hover)
        cdp.send('Emulation.setTouchEmulationEnabled', {'enabled': False})
        cdp.detach()
        touch_result = {'pointerId': pointer_id, 'captureAfterStart': capture_after_start,
                        'captureAfterCancel': capture_after_cancel, 'events': touch_events,
                        'cameraAfterCancel': after_cancel, 'cameraAfterUnpressedMoves': after_hover}
        (args.artifacts / 'pointercancel.json').write_text(json.dumps(touch_result, indent=2) + '\n')
        print('PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves')
        print('POINTERCANCEL EVIDENCE ' + json.dumps(touch_result))

        # Production builder emits the organized group and AI relation; its
        # serializer controls optional wire keys and no fixture invents nodes.
        page.evaluate("window.graphFixture.publish('organized')")
        group = page.get_by_role('combobox', name='筛选分组', exact=True)
        page.wait_for_function("[...document.querySelectorAll('select option')].some(o=>o.textContent.includes('开发主题'))")
        group_key = page.evaluate("Object.keys(window.graphFixture.readSnapshot().labels)[0]")
        group.select_option(group_key)
        assert page.locator('button[data-node-id]').count() == 2
        group.select_option('')
        page.locator('button[data-node-id="fixture-001"]').click()
        page.get_by_text('AI 关联理由：共同讨论开发实践', exact=True).wait_for()
        print('PASS production organized group filtering and readable AI relationship reason')

        def painted_line(dashed):
            page.wait_for_function('''(dashed)=>{
                const c=document.querySelector('canvas'),ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];if(bg[3]!==255)return false;
                return window.drawProbe.latestLines.filter(line=>line.dashed===dashed).some(line=>{
                    for(let step=2;step<19;step++)for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){
                        const x=Math.floor(line.a.x+(line.b.x-line.a.x)*step/20)+dx;
                        const y=Math.floor(line.a.y+(line.b.y-line.a.y)*step/20)+dy;
                        if(x<0||y<0||x>=c.width||y>=c.height)continue;
                        const pixel=[...ctx.getImageData(x,y,1,1).data];
                        if(pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]))return true;
                    }return false;
                });
            }''', arg=dashed)
        painted_line(True)
        groups = page.locator('details').filter(has=page.locator('summary').filter(has_text='分组说明与管理'))
        if groups.get_attribute('open') is None:
            groups.locator('summary').click()
        page.get_by_role('button', name='保留这版分组', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].lock_group') == group_key
        page.evaluate("window.graphFixture.publish('locked')")
        page.get_by_role('button', name='解锁', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].unlock_group') == group_key
        page.get_by_text('AI 与分组', exact=True).click()
        page.get_by_role('button', name='重新整理', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].organize') is True
        page.evaluate("window.graphFixture.publish('organizing')")
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.evaluate('window.sendFailure=true')
        groups.get_by_role('button', name='保留这版分组', exact=True).click()
        page.get_by_text('请求未发送', exact=False).wait_for()
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.get_by_role('switch', name='AI 分组命名', exact=True).click()
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.get_by_role('switch', name='AI 分组命名', exact=True).click()
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.evaluate('window.sendFailure=false')
        page.evaluate("window.graphFixture.publish('organized')")
        assert page.get_by_role('button', name='重新整理', exact=True).is_enabled()
        page.evaluate('window.sendFailure=true')
        page.get_by_role('button', name='重新整理', exact=True).click()
        assert page.get_by_role('button', name='重新整理', exact=True).is_enabled()
        page.evaluate('window.sendFailure=false')
        print('PASS failed lock/naming requests preserve confirmed organizing busy state; a failed new organize request restores the confirmed idle state')
        page.evaluate("window.graphFixture.publish('similar')")
        painted(4)
        painted_line(False)
        assert page.evaluate('window.graphFixture.readSnapshot().edges.length') > 0
        print('PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts')

        # A real viewport resize must resize the Canvas bitmap; responsive
        # layout must not leave its controls as opaque overlays on the graph.
        for width, height in [(1440, 900), (960, 720), (760, 740), (390, 844), (320, 480), (1280, 800)]:
            page.set_viewport_size({'width': width, 'height': height})
            page.get_by_role('button', name='适应画布', exact=True).click()
            page.wait_for_function('''() => {
                const c=document.querySelector('canvas');return c.width===Math.floor(c.getBoundingClientRect().width*devicePixelRatio);
            }''')
            painted(4)
            canvas_box = page.locator('canvas').bounding_box()
            aside_box = page.get_by_role('complementary', name='知识浏览', exact=True).bounding_box()
            assert canvas_box and aside_box
            overlap_w = min(canvas_box['x'] + canvas_box['width'], aside_box['x'] + aside_box['width']) - max(canvas_box['x'], aside_box['x'])
            overlap_h = min(canvas_box['y'] + canvas_box['height'], aside_box['y'] + aside_box['height']) - max(canvas_box['y'], aside_box['y'])
            assert overlap_w <= 1 or overlap_h <= 1, (canvas_box, aside_box)
            assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')
            page.screenshot(path=str(args.artifacts / f'after-width-{width}.png'), full_page=True)
        print('PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow')

        # A native details element keeps a user's toggle when React re-renders
        # with an unchanged open prop. Exercise both default-open and default-
        # closed lanes via actual query and hover updates, not DOM mutation.
        details_evidence = []
        for count in [4, 20]:
            open_fixture(count)
            groups = page.locator('details').filter(has=page.locator('summary').filter(has_text='分组说明与管理'))
            expected_default = count <= 19
            assert (groups.get_attribute('open') is not None) is expected_default
            groups.locator('summary').click()
            expected_open = not expected_default
            assert (groups.get_attribute('open') is not None) is expected_open
            page.get_by_role('textbox', name='搜索知识', exact=True).fill('SQLite')
            assert page.locator('button[data-node-id]').count() == 1
            assert (groups.get_attribute('open') is not None) is expected_open
            canvas.scroll_into_view_if_needed()
            hovered = page.evaluate('''() => {
                const c=document.querySelector('canvas'),box=c.getBoundingClientRect(),arc=window.drawProbe.latestArcs[0];
                return {x:box.x+arc.x/devicePixelRatio,y:box.y+arc.y/devicePixelRatio};
            }''')
            page.mouse.move(hovered['x'], hovered['y'])
            page.get_by_role('status').filter(has_text='SQLite 离线检索').wait_for()
            assert (groups.get_attribute('open') is not None) is expected_open
            if count == 20:
                page.evaluate("window.graphFixture.publish('locked20')")
                assert (groups.get_attribute('open') is not None) is True
                unlock = groups.get_by_role('button', name='解锁', exact=True)
                unlock.wait_for()
                unlock.click()
                lock_key = page.evaluate("Object.keys(window.graphFixture.readSnapshot().labels).find(key=>window.graphFixture.readSnapshot().labels[key].locked)")
                assert page.evaluate('window.sent[window.sent.length-1].unlock_group') == lock_key
            details_evidence.append({'nodes': count, 'defaultOpen': expected_default,
                                     'manualOpenAfterQueryAndHover': expected_open, 'unlockReachable': count == 20})
        (args.artifacts / 'details-toggle.json').write_text(json.dumps(details_evidence, indent=2) + '\n')
        print('PASS native details: manually collapsed 4-node and expanded 20-node groups survive query/hover re-renders; 20-node locked group has a reachable working unlock button')

        open_fixture(4)
        start_radius = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='放大', exact=True).click()
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r*1.25)<0.01', arg=start_radius)
        canvas.focus()
        page.keyboard.press('ArrowLeft')
        page.wait_for_timeout(50)
        def camera_sample():
            return page.evaluate('''() => {
                const c=document.querySelector('canvas'),n=window.drawProbe.latestArcs[0];
                return {radius:n.r,xFromCenter:n.x-c.width/2,yFromCenter:n.y-c.height/2,width:c.width,height:c.height};
            }''')
        custom_camera = camera_sample()
        camera_evidence = [{'action': 'custom zoom and pan', **custom_camera}]
        def preserved_camera(action):
            page.wait_for_function('''(previous) => {
                const c=document.querySelector('canvas'),n=window.drawProbe.latestArcs[0];
                return c.width===Math.floor(c.getBoundingClientRect().width*devicePixelRatio)
                    && Math.abs(n.r-previous.radius)<0.01
                    && Math.abs(n.x-c.width/2-previous.xFromCenter)<0.1
                    && Math.abs(n.y-c.height/2-previous.yFromCenter)<0.1;
            }''', arg=custom_camera)
            camera_evidence.append({'action': action, **camera_sample()})
        page.get_by_role('button', name='收起列表', exact=True).click()
        preserved_camera('close list')
        page.get_by_role('button', name='浏览知识', exact=True).click()
        preserved_camera('open list')
        for width, height in [(1440, 900), (960, 720), (390, 844), (1280, 800)]:
            page.set_viewport_size({'width': width, 'height': height})
            preserved_camera(f'resize {width}x{height}')
        (args.artifacts / 'camera-preservation.json').write_text(json.dumps(camera_evidence, indent=2) + '\n')
        print('PASS custom native scale and world center remain unchanged when toggling the list or resizing desktop/mobile viewports; all 200 node centers were visible in every initial recorded frame')

        open_fixture(0)
        assert page.locator('canvas').count() == 0

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('error')")
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        print('PASS initially cached error snapshot can refresh and recover without closing the page')

        page.goto((Path(directory) / 'index.html').as_uri() + '?labels')
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('4')")
        painted(4)
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is True
        assert not page.evaluate('window.sent.some(m=>m.organize)')
        print('PASS refresh preserves a previously enabled AI naming preference without automatically organizing')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('rebuilding',{focus_id:'fixture-003'})")
        assert page.locator('canvas').count() == 0
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Telescope 天文观测', exact=True).wait_for()
        print('PASS a requested document remains selected across rebuilding → success with no new focus id')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.evaluate("window.graphFixture.release('error')")
        page.wait_for_timeout(50)
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        print('PASS a stale initial storage result cannot overwrite a newer successful storage event')
        assert not errors, errors
        (args.artifacts / 'after.json').write_text(json.dumps(summaries, indent=2) + '\n')
        assert not errors, errors
        browser.close()
print('PASS delayed storage → real Canvas node drawing')

```

### FULL CURRENT chrome-extension/scripts/render-knowledge-graph-fixture.cjs
```
// Real KnowledgeGraphApp and graph builder; only Chrome storage/runtime are fake.
// Never reads a user knowledge index or starts a Companion connection.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const out = process.argv[2];
if (!out) throw new Error('output directory required');
const esbuild = require(path.join(root, 'node_modules/esbuild'));

async function main() {
  fs.mkdirSync(out, { recursive: true });
  // The serializer is private in a large router with live configuration imports.
  // Execute its exact source with only that configuration boundary replaced;
  // do not hand-copy the wire keys into a fixture and assume they are correct.
  const router = fs.readFileSync(path.join(root, '../companion/src/message-router.ts'), 'utf8');
  const serializer = router.match(/\nfunction knowledgeGraphFrame\([\s\S]*?\n}\n/)?.[0];
  if (!serializer) throw new Error('production knowledgeGraphFrame definition not found');
  const rebuilding = router.slice(router.indexOf('const graph = skillEngine.getKnowledgeGraph'))
    .match(/if \(!graph\) \{[\s\S]*?return (\{[\s\S]*?\n        \})\n/)?.[1];
  if (!rebuilding) throw new Error('production rebuilding frame definition not found');
  const built = await esbuild.build({
    stdin: { contents: `export {buildKnowledgeGraph} from '../companion/src/skills/knowledge-graph';
      const knowledgeExtractLlmConfig=()=>({provider:'fixture'});
      let knowledgeGraphOrganizeRun=null;export function setOrganizing(value){knowledgeGraphOrganizeRun=value?{}:null;}
      ${serializer}\nexport {knowledgeGraphFrame};
      export function rebuildingFrame(){const actionError=undefined;return ${rebuilding};}`, resolveDir: root, loader: 'ts' },
    bundle: true, platform: 'node', format: 'cjs', write: false,
  });
  const production = new Module(path.join(out, 'graph-builder.cjs'), module);
  production._compile(built.outputFiles[0].text, path.join(out, 'graph-builder.cjs'));
  const { buildKnowledgeGraph, knowledgeGraphFrame, rebuildingFrame, setOrganizing } = production.exports;
  const graphs = { rebuilding: rebuildingFrame() };
  for (const count of [0, 1, 4, 20, 200]) {
    const docs = Array.from({ length: count }, (_, i) => ({
      id: `fixture-${String(i + 1).padStart(3, '0')}`,
      name: `fixture-${i + 1}`, title: ['SQLite 离线检索', 'Orchids 高山兰花', 'Telescope 天文观测', 'Sourdough 面包发酵'][i] || `Knowledge${String(i + 1).padStart(3, '0')}`,
      tags: [], folder: i % 2 ? '旅行' : '开发', bucket: 'global',
      // Deliberately orthogonal: zero TF edges is a real production result.
      vec: { [`unique-${i}`]: 1 }, description: '',
    }));
    graphs[count] = knowledgeGraphFrame(buildKnowledgeGraph(docs));
    if (count === 20) {
      graphs.locked20 = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { lock: { groups: [
        { ids: [docs[0].id, docs[2].id], name: '保留的研究主题', summary: '来自小语料阶段的锁定分组' },
      ] } }));
    }
    if (count === 4) {
      const llm = {
        groups: [{ ids: [docs[0].id, docs[2].id], name: '开发主题', summary: '两篇开发笔记' }],
        relations: [{ a: docs[0].id, b: docs[2].id, reason: '共同讨论开发实践', confidence: 0.9 }],
      };
      graphs.organized = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm }));
      setOrganizing(true);
      graphs.organizing = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm }));
      setOrganizing(false);
      graphs.locked = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm, lock: { groups: llm.groups } }));
      graphs.similar = knowledgeGraphFrame(buildKnowledgeGraph(docs.map((doc, i) => ({ ...doc, description: i < 2 ? 'shared retrieval database indexing' : '' }))));
    }
  }
  fs.writeFileSync(path.join(out, 'builder-output.json'), JSON.stringify(graphs, null, 2));
  const source = `
import React from 'react';
import {createRoot} from 'react-dom/client';
import {KnowledgeGraphApp} from './src/knowledge-graph/KnowledgeGraphApp';
import {parseKnowledgeGraphPayload} from './src/knowledge-graph/wire';
import {KNOWLEDGE_GRAPH_SNAPSHOT_KEY as KEY,writeKnowledgeGraphSnapshot,knowledgeGraphErrorPayload} from './src/background/knowledge-graph';
import {KNOWLEDGE_GRAPH_LLM_LABELS_KEY} from './src/knowledge-graph/llm-pref';
const graphs=${JSON.stringify(graphs)};
const listeners=new Set(); const session={}; const local=new URLSearchParams(location.search).has('labels')?{[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]:true}:{};
window.sent=[];window.storageReads=0;window.storageReleased=false;window.sendFailure=false;
let suppressStorageEvent=false;
let release;const initialRead=new Promise(resolve=>release=resolve);
const emit=(changes,area)=>{for(const fn of [...listeners])fn(changes,area)};
window.chrome={runtime:{lastError:undefined,sendMessage:(message,callback)=>{window.sent.push(message);const response={sent:!window.sendFailure};callback?.(response);return Promise.resolve(response)}},storage:{
session:{get:async()=>{window.storageReads++;await initialRead;return {...session}},set:async values=>{Object.assign(session,values);if(!suppressStorageEvent)emit(Object.fromEntries(Object.entries(values).map(([key,newValue])=>[key,{newValue}])), 'session')}},
local:{get:async()=>({...local}),set:async values=>{Object.assign(local,values);emit(Object.fromEntries(Object.entries(values).map(([key,newValue])=>[key,{newValue}])), 'local')}},
onChanged:{addListener:fn=>listeners.add(fn),removeListener:fn=>listeners.delete(fn)}}};
window.graphFixture={graphs,
async publish(key,extra){const payload=key==='error'?knowledgeGraphErrorPayload({type:'error',error:'knowledge.graph fixture failure'}):parseKnowledgeGraphPayload(graphs[key]);if(!payload)throw new Error('invalid production payload');await writeKnowledgeGraphSnapshot(payload,extra);},
async release(key='4',extra){suppressStorageEvent=true;await this.publish(key,extra);suppressStorageEvent=false;window.storageReleased=true;release();},
readSnapshot:()=>session[KEY]};
// Observe real drawing and preserve every native call. Counters alone cannot
// pass the regression: Python also checks native Canvas pixels and dimensions.
window.drawProbe={arcs:0,text:[],frames:0,latestArcs:[],latestText:[],latestLines:[],path:[],frameHistory:[]};
for(const name of ['arc','fillText','clearRect','beginPath','moveTo','lineTo','stroke']){const native=CanvasRenderingContext2D.prototype[name];CanvasRenderingContext2D.prototype[name]=function(...args){const p=window.drawProbe;if(name==='clearRect'){p.frames++;p.latestArcs=[];p.latestText=[];p.latestLines=[]}if(name==='beginPath')p.path=[];if(name==='moveTo'||name==='lineTo'){const t=this.getTransform();p.path.push({x:t.a*args[0]+t.c*args[1]+t.e,y:t.b*args[0]+t.d*args[1]+t.f})}if(name==='stroke'&&p.path.length===2)p.latestLines.push({a:p.path[0],b:p.path[1],dashed:this.getLineDash().length>0});if(name==='arc'){p.arcs++;const t=this.getTransform();p.latestArcs.push({x:t.a*args[0]+t.c*args[1]+t.e,y:t.b*args[0]+t.d*args[1]+t.f,r:args[2]*t.a})}if(name==='fillText'){p.text.push(String(args[0]));p.latestText.push(String(args[0]));if(p.text.length>2000)p.text.splice(0,1000)}return native.apply(this,args)}};
const clearFrame=CanvasRenderingContext2D.prototype.clearRect;
CanvasRenderingContext2D.prototype.clearRect=function(...args){
  const p=window.drawProbe;
  if(p.latestArcs.length&&p.frameHistory.length<120)p.frameHistory.push({frame:p.frames,width:p.frameWidth,height:p.frameHeight,
    nodes:p.latestArcs.length,visible:p.latestArcs.filter(n=>n.x>=0&&n.y>=0&&n.x<p.frameWidth&&n.y<p.frameHeight).length});
  p.frameWidth=this.canvas.width;p.frameHeight=this.canvas.height;
  return clearFrame.apply(this,args);
};
createRoot(document.getElementById('root')).render(<KnowledgeGraphApp/>);
`;
  const baseline = process.argv.includes('--baseline');
  const plugins = baseline ? [{ name: 'baseline-app', setup(build) {
    build.onLoad({ filter: /KnowledgeGraphApp\.tsx$/ }, () => ({
      contents: execFileSync('git', ['show', 'aada096a:chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx'], { cwd: root, encoding: 'utf8' }),
      loader: 'tsx', resolveDir: path.join(root, 'src/knowledge-graph'),
    }));
  } }] : [];
  await esbuild.build({ stdin: { contents: source, resolveDir: root, loader: 'tsx' }, bundle: true, outfile: path.join(out, 'app.js'), jsx: 'automatic', plugins });
  fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body,#root{margin:0;width:100%;height:100%}*{box-sizing:border-box}</style><body><div id="root"></div><script src="app.js"></script></body></html>');
}
main().catch(error => { console.error(error); process.exitCode = 1; });

```
