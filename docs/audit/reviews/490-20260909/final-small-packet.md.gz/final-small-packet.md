Final small follow-up review for CMspark #490. Prior full and camera delta reviews were independently approved by Grok and DeepSeek. Review ONLY the final tiny change and tightened test evidence below, do not invent a new scope. Production delta: add html,body{margin:0;background:existing dark canvas token} to the existing dedicated graph tab's style string (actual Plasmo HTML has no reset); add type=button to selected-document cancel. No logic/backend/model/permission change. Fixture's extra page reset was removed so tests rely on product styles. Camera test previously could observe pre-ResizeObserver data; now atomically verifies new CSS+bitmap+latest rendered frame geometry and returns the same frame's camera sample. All UI/browser/build checks pass. Inspect for real regressions, give concise concrete findings and final VERDICT: APPROVE | APPROVE_WITH_NITS | REJECT.


### grok-delta.md
# Independent delta review — CMspark #490

**Base:** `aada096a`  
**Surface:** T2 panel-only follow-up (production UI + tests). No backend after the already-reviewed `organizing` boolean / 19→20 gate.  
**Evidence class:** static read of the provided `KnowledgeGraphApp.tsx`, `explorer.ts`, UI harness, and artifacts `[inspected]`. PASS logs and JSON are treated as implementer-executed, synthetic Chrome — not Windows / real corpus.

Prior Grok `APPROVE_WITH_NITS` and DeepSeek `APPROVE` are not inherited.

---

## Prior findings vs this delta

| Prior claim | This packet | Result |
|---|---|---|
| P2-1 controlled `<details open={n<=19}>` resets on hover/search | `details-toggle.json` + UI test: collapse@4 and expand@20 survive query+hover; `locked20` keeps open and unlock sends `unlock_group` | **Disproven** on this React/Chrome. Unchanged boolean `open` is not re-forced. Crossing 19 still flips the prop (new snapshot — acceptable). |
| P2-2 resize always `fitView()` | `userCameraRef` → pan `+= Δsize/2`; else fit | **Fixed in source.** Math keeps world-point-at-center and scale. |
| P2-3 fit once before layout; 191/200 | Fit every frame while `!userCamera && simTicks < 320`; pan/zoom/select set `simTicks=999` | **Fixed.** `initial-200-frames.json` + `after.json`: 200/200 centers, 20 frames. |
| P2-5 failed lock/LLM clears organize busy | `onActionResponse` only sets error; `sendOrganize` restores `confirmedOrganizingRef` | **Fixed.** UI log: lock/naming failure keeps 「整理中…」; failed new organize returns to idle. |
| P1 pointercancel capture leak | Trusted CDP: down→gotcapture→move→cancel→lostcapture; later unpressed moves do not pan | **Disproven.** Matches Pointer Events implicit release. Cancel ≠ click is correct. |
| One-way `requestError` | `applySnap` always `setRequestError("")` on parse | **Disproven.** |
| Hung companion as P1 | UI checks `lastError \|\| ok===false \|\| sent===false`; rebuild poll 40×2.5s; organize 35s | **Out of claimed scope.** Send-layer + bounded waits only. |
| matchMedia / titles / relatedEdges / `type=button` / DESIGN header | matchMedia once per canvas mount; `titleByIdRef`; `relatedEdges` `useMemo`; 「知道了」 is `type="button"` | **Addressed.** `graphStyles` is **module-scope**, not per-render alloc (old nit was wrong). |

P2-4 (legacy companion with no `organizing`; 35s local busy) is still true and **declared**. Old servers cannot authoritatively busy-signal. Not a new regression.

---

## Outcomes vs DoD (this delta)

| Claim | Result |
|---|---|
| 1/4/20/200 paint, full list, honest zero-edge | Met (`after.json` visible=N, list count=N, 「暂无明确关联」) |
| Auto-fit until stable; all 200 centers on-canvas | Met (frames 1–20 visible=200) |
| User pan/zoom/selection stops sim | Met in source (`simTicks=999`, `userCameraRef`) |
| Custom camera survives list toggle / resize | **Source correct.** Test PASS claimed; see NIT on artifact. |
| Unrelated send fail ≠ clear organize; failed organize rolls back | Met |
| Keyboard / pointercancel | Met with real keys + trusted touch |
| Details persist; unlock@20 reachable | Met |
| No auto-organize; naming pref retained; no new verbs | Met |
| #491 | Not claimed |

Trajectory still T2: same `knowledge_graph.refresh` / `open_doc` / `ack_tf_switch`. Default `llm_labels` off. Collision pruning is canvas labels only.

---

## Findings

### P0 / P1
None.

### P2
None that break #490 on this evidence.

### Nits

**NIT-1. Camera artifact vs invariant.**  
Production resize path is the right formula (`pan += Δ/2` iff `userCameraRef`). `camera-preservation.json` still shows `xFromCenter`/`yFromCenter` moving with bitmap size on 1440/960/390 (e.g. 116.98 → 196.98 at 1120×671, which is exactly *no* pan adjust from 960). The wait only checks “current offset equals the original,” **not** that CSS/bitmap size has changed, so it can pass on a pre-RO frame. List-toggle row at width 1280 with the original offset is the one sample that actually looks like the new path. Tighten: wait until `c.width` matches the expected post-reflow size in the same evaluate, then assert offset. Do not treat this JSON as proof of viewport preservation.

**NIT-2. Residual busy fiction.** 35s client timer can still lie if a completion push is lost; `applySnap` heals when a snapshot arrives. Legacy companions remain idle-looking. Documented; do not advertise “job state always matches server.”

**NIT-3. Fit pads radii, not title line.** `sy+17 < h` still drops canvas labels. List remains a11y SoT; centers are the 200-node contract.

**NIT-4.** 「取消选中知识」 still has no `type="button"` (no form — cosmetic). 200-row list still unvirtualized (cap 200).

---

## Component correctness

- **Canvas lifecycle:** `[showCanvas]` + RO/rAF cleanup; error unmount stops frames; remount paints. Unchanged and still the blank-canvas fix.
- **Explorer:** `filterKnowledgeNodes` list-only; layout/draw use full payload. Holds.
- **Camera:** auto path refits until settle; user path freezes sim and (in source) preserves center on reflow. `fitKnowledgeCamera` can zoom out (`(w-96)/extent`), which is why 200 centers fit.
- **Busy:** `confirmedOrganizingRef` is the last parsed `organizing === true`; fail-closed parse. Correct for the send-layer contract.
- **Trust:** no new message types, no search→organize, refresh default-off unless saved pref.

Out of scope unchanged: #491, `user_gesture` e2e, summoner deny, ≥20 TF `group_key` (backend already reviewed).

---

VERDICT: APPROVE_WITH_NITS

### deepseek-delta.md
## Independent Final Delta Review — CMspark #490

### Scope

This review examines the production delta relative to the previously reviewed sources, plus the new test-only evidence. I do not inherit Grok or DeepSeek verdicts. I assessed the supplied current sources (`KnowledgeGraphApp.tsx`, `explorer.ts`, both test scripts) and the claim summary.

### Production delta findings

**Delta (1) — fit every frame until stable; stop simulation on user pan/zoom/selection.**

Current code:

```ts
for (let step = 0; step < ...; step++) {
  const e = forceLayoutTick(...)
  simTicksRef.current++
  if ((e < 0.06 && simTicksRef.current > 50) || simTicksRef.current >= 320) {
    simTicksRef.current = 999
    if (!userCameraRef.current) fitViewRef.current()
  }
}
if (!userCameraRef.current && (!fittedRef.current || simTicksRef.current < 320)) fitViewRef.current()
```

This means every frame until settled re-fits. `initial-200-frames.json` records 200/200 visible in each of the first 20 frames. Settlement still ends at ≤320 ticks or energy<0.06 with >50 ticks, and `if (!userCameraRef.current) fitViewRef.current()` runs until `simTicksRef.current >= 320`. The early-fit loop doesn't leave nodes off-canvas because the draw loop re-fits each frame during layout. No defect found.

**Delta (2) — ResizeObserver preserves custom camera.**

Current resize handler:

```ts
if (userCameraRef.current) {
  panRef.current.x += (rect.width - previousSize.w) / 2
  panRef.current.y += (rect.height - previousSize.h) / 2
} else fitViewRef.current()
```

`camera-preservation.json` demonstrates custom scale/pan preserved across list toggle and 4 viewport resizes, with center-offset math validating the half-delta pan. This is consistent and correct.

**Delta (3) — unrelated send failures do not clear organize state.**

`sendLock` and `onLlmChange` use `onActionResponse` alone, which only mutates `requestError`. `sendOrganize` uniquely restores `confirmedOrganizingRef.current` on failed send. The UI test exercises exactly this: failed lock and failed LLM toggle during `organizing` keep the button disabled; failed new organize restores enabled state. Correct.

**Delta (4) — precomputed titles, related-edge memo, singleton matchMedia.**

Title map is built in a `useEffect` dependent on `payloadNodes`, `colorMode`, `labels`. `relatedEdges` is now `useMemo`. `motionPreference` is created inside the mount effect, so once per canvas mount. These match the delta description.

**Delta (5) — `type="button"` on lock-dissolved notice.**

Confirmed in source. Design header not inspected in this packet, but this was a stated nit from prior review and appears addressed in the notice control.

### Adjudication of prior reviewer disagreements

**Grok P2-1: controlled `<details>` resets on unrelated renders.**

Current React reconciliation does *not* repatch the DOM `open` attribute on renders where the prop value is unchanged. A native `<details>` remains user-toggled. The claimed test evidence is `details-toggle.json`, showing manual collapse at 4 and expansion at 20 surviving query/hover. However, this test also performs a fixture republish for the 20-node case (`locked20`), which changes `payloadNodes` and therefore changes the `open` prop. But the sequence shows the manual `open` state surviving the query and hover. The unlock at 20 being reachable is verified. The static claim alone cannot outweigh the real browser behavior. No P1/P2.

**DeepSeek P1-1 pointercancel capture leak.**

The production `onPointerCancel` only nulls `dragRef`. The trusted CDP evidence shows implicit capture release by the UA after `pointercancel`, with `lostpointercapture` delivered. Subsequent unpressed mouse moves do not pan. W3C Pointer Events §5.2.2 and §9.5 confirm implicit capture release on pointercancel. No defect.

**DeepSeek P1-2 offline hang.**

The service worker send path returns `{ok: true, sent: true/false}`. The UI checks `ok === false || sent === false` and renders an explicit connection error. `applySnap` clears `requestError` when a valid snapshot arrives (including `organizing: false`), so stale error clears on next push. Rebuild polling is bounded at 40×2.5s. This is a narrow, honest transport-failure scope; a universal hung-companion watchdog is not claimed. No P1.

**DeepSeek P1-3 one-way organizing error.**

`applySnap` unconditionally calls `setRequestError("")` after successful parse. A completion push (`organizing: false`) clears the 35s fallback message. Not one-way. No defect.

### Residual observations

- `graphStyles` is still a new template string every render, inline `<style>` node, but the claim did not include styling memoization. Nonblocking.
- `titleByIdRef` recomputed when colorMode changes even though titles don't depend on colorMode; negligible.
- The 200-node test records only first 20 frames and `after.json` shows painted counts. The prior 191/200 discrepancy is resolved by the new per-frame fit; `initial-200-frames.json` is 200/200 for 20 frames. No P2 remains.
- The backend boolean `organizing` fix and 19→20 group gating are unchanged from prior review and remain correct in the provided source.
- #491 remains not addressed, and is explicitly not part of this delta.

### Verdict

The production delta addresses the substantive defects from the prior round: camera stability and user gesture preservation, organize-state isolation from unrelated send failures, and performance hygiene. The test-only delta adds direct browser evidence resolving the two contested claims (details persistence, pointercancel capture release). No new P0/P1/P2 defects are present in the reviewed sources.

VERDICT: APPROVE
### ui-camera-final.log
PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state
PASS ok → error stops drawing → refresh → ok remount draws real nodes
PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI
PASS search incl. empty results, local selection, explicit document open, camera and list controls
PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection
PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves
POINTERCANCEL EVIDENCE {"pointerId": 2, "captureAfterStart": true, "captureAfterCancel": false, "events": [{"type": "pointerdown", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "gotpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointermove", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "pointercancel", "pointerId": 2, "isTrusted": true, "captureDuringEvent": true}, {"type": "lostpointercapture", "pointerId": 2, "isTrusted": true, "captureDuringEvent": false}], "cameraAfterCancel": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}, "cameraAfterUnpressedMoves": {"x": 599.7991769234495, "y": 245.94908814362964, "r": 8.00000011920929}}
PASS production organized group filtering and readable AI relationship reason
PASS failed lock/naming requests preserve confirmed organizing busy state; a failed new organize request restores the confirmed idle state
PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts
PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow
PASS native details: manually collapsed 4-node and expanded 20-node groups survive query/hover re-renders; 20-node locked group has a reachable working unlock button
PASS custom native scale and world center remain unchanged when toggling the list or resizing desktop/mobile viewports; all 200 node centers were visible in every initial recorded frame
PASS initially cached error snapshot can refresh and recover without closing the page
PASS refresh preserves a previously enabled AI naming preference without automatically organizing
PASS a requested document remains selected across rebuilding → success with no new focus id
PASS a stale initial storage result cannot overwrite a newer successful storage event
PASS delayed storage → real Canvas node drawing

### camera-preservation.json
[
  {
    "action": "custom zoom and pan",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 960,
    "height": 571,
    "cssWidth": 960,
    "cssHeight": 571,
    "dpr": 1,
    "beforeFrame": 5,
    "drawnFrame": 6,
    "drawnFrameWidth": 960,
    "drawnFrameHeight": 571,
    "viewportWidth": 1280,
    "viewportHeight": 800
  },
  {
    "action": "close list",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 1280,
    "height": 571,
    "cssWidth": 1280,
    "cssHeight": 571,
    "dpr": 1,
    "beforeFrame": 6,
    "drawnFrame": 10,
    "drawnFrameWidth": 1280,
    "drawnFrameHeight": 571,
    "viewportWidth": 1280,
    "viewportHeight": 800
  },
  {
    "action": "open list",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 960,
    "height": 571,
    "cssWidth": 960,
    "cssHeight": 571,
    "dpr": 1,
    "beforeFrame": 10,
    "drawnFrame": 14,
    "drawnFrameWidth": 960,
    "drawnFrameHeight": 571,
    "viewportWidth": 1280,
    "viewportHeight": 800
  },
  {
    "action": "resize 1440x900",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 1120,
    "height": 671,
    "cssWidth": 1120,
    "cssHeight": 671,
    "dpr": 1,
    "beforeFrame": 14,
    "drawnFrame": 16,
    "drawnFrameWidth": 1120,
    "drawnFrameHeight": 671,
    "viewportWidth": 1440,
    "viewportHeight": 900
  },
  {
    "action": "resize 960x720",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 640,
    "height": 491,
    "cssWidth": 640,
    "cssHeight": 491,
    "dpr": 1,
    "beforeFrame": 16,
    "drawnFrame": 18,
    "drawnFrameWidth": 640,
    "drawnFrameHeight": 491,
    "viewportWidth": 960,
    "viewportHeight": 720
  },
  {
    "action": "resize 390x844",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 390,
    "height": 346,
    "cssWidth": 390,
    "cssHeight": 346,
    "dpr": 1,
    "beforeFrame": 18,
    "drawnFrame": 20,
    "drawnFrameWidth": 390,
    "drawnFrameHeight": 346,
    "viewportWidth": 390,
    "viewportHeight": 844
  },
  {
    "action": "resize 1280x800",
    "radius": 10,
    "xFromCenter": 116.98388423894426,
    "yFromCenter": 15.551637795597685,
    "width": 960,
    "height": 571,
    "cssWidth": 960,
    "cssHeight": 571,
    "dpr": 1,
    "beforeFrame": 20,
    "drawnFrame": 22,
    "drawnFrameWidth": 960,
    "drawnFrameHeight": 571,
    "viewportWidth": 1280,
    "viewportHeight": 800
  }
]

### built-smoke.log
PASS actual Plasmo HTML and JS 1440 {'bodyMargin': '0px', 'htmlMargin': '0px', 'overflow': False, 'width': 1120, 'height': 671, 'colored': 4014}
PASS actual Plasmo HTML and JS 390 {'bodyMargin': '0px', 'htmlMargin': '0px', 'overflow': False, 'width': 390, 'height': 346, 'colored': 3962}

### Production changed context
```tsx
      <style>{graphStyles}</style>
              <div className="kg-selection-heading"><strong>{selected.title || selected.id}</strong><button type="button" aria-label="取消选中知识" onClick={() => setFocusId(null)}>取消</button></div>
const graphStyles = `
  html, body { margin: 0; background: ${G.canvas}; }
  .kg-selection-heading { display: flex; align-items: start; gap: 8px; }
  .kg-selection-heading strong { flex: 1; min-width: 0; overflow-wrap: anywhere; font-size: 14px; }
```

### Current chrome-extension/scripts/test-knowledge-graph-ui.py
```
"""Real graph builder + KnowledgeGraphApp, delayed storage, isolated Chrome.

Run after nvm use 22:
  uv run --with playwright python scripts/test-knowledge-graph-ui.py
"""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', action='store_true', help='Capture the pre-fix failure without hiding its assertion')
parser.add_argument('--artifacts', type=Path, default=Path(__file__).resolve().parents[2] / '.omx/artifacts/knowledge-graph-490')
args = parser.parse_args()
args.artifacts.mkdir(parents=True, exist_ok=True)
project = Path(__file__).resolve().parent.parent

with tempfile.TemporaryDirectory(prefix='cmspark-knowledge-graph-') as directory:
    subprocess.run(['node', 'scripts/render-knowledge-graph-fixture.cjs', directory] + (['--baseline'] if args.baseline else []), cwd=project, check=True)
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(channel='chrome', headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 800})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        assert page.locator('canvas').count() == 0, 'Initial storage read must remain asynchronous'
        page.evaluate("window.graphFixture.release('4')")
        page.locator('canvas').wait_for()
        if args.baseline:
            page.wait_for_timeout(400)
            evidence = page.evaluate('''() => {
                const c=document.querySelector('canvas');
                return {storageReleased:window.storageReleased, snapshotNodes:window.graphFixture.readSnapshot().nodes.length,
                    canvasWidth:c.width,canvasHeight:c.height,cssWidth:c.getBoundingClientRect().width,
                    drawnArcs:window.drawProbe.arcs,drawnFrames:window.drawProbe.frames,
                    opaquePixels:[...c.getContext('2d').getImageData(0,0,c.width,c.height).data].filter((v,i)=>i%4===3&&v>0).length};
            }''')
            page.screenshot(path=str(args.artifacts / 'before.png'), full_page=True)
            (args.artifacts / 'before.json').write_text(json.dumps(evidence, indent=2) + '\n')
            print(json.dumps(evidence, indent=2), flush=True)
            assert evidence['drawnArcs'] >= 4 and evidence['opaquePixels'] > 0, 'Async snapshot mounted a Canvas but never started the drawing effect'
        def painted(count):
            pixels = page.wait_for_function('''(count) => {
                const c=document.querySelector('canvas');if(!c)return false;
                const ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];
                const arcs=window.drawProbe.latestArcs;
                const visible=arcs.filter(p=>p.x>=0&&p.x<c.width&&p.y>=0&&p.y<c.height);
                const colored=visible.filter(p=>{
                    const pixel=[...ctx.getImageData(Math.floor(p.x),Math.floor(p.y),1,1).data];
                    return pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]);
                });
                if(arcs.length<count||bg[3]!==255||!colored.length)return false;
                return {width:c.width,height:c.height,css:c.getBoundingClientRect().width,
                    dpr:devicePixelRatio,backgroundAlpha:bg[3],visible:visible.length,colored:colored.length};
            }''', arg=count).json_value()
            assert pixels['width'] == int(pixels['css'] * pixels['dpr']), pixels
            assert pixels['height'] >= 280, pixels
            assert pixels['backgroundAlpha'] == 255 and pixels['colored'] > 0, pixels
            return pixels

        def open_fixture(count):
            page.goto((Path(directory) / 'index.html').as_uri())
            page.wait_for_function('window.storageReads===1')
            assert page.locator('canvas').count() == 0
            page.evaluate('(count)=>window.graphFixture.release(String(count))', count)
            if count == 0:
                page.get_by_text('知识库暂无可展示的文档', exact=False).wait_for()
                return
            page.get_by_test_id('knowledge-graph-canvas').wait_for()
            painted(count)

        painted(4)
        summaries = []
        for count in [1, 4, 20, 200]:
            open_fixture(count)
            page.wait_for_function("window.drawProbe.latestText.some(text=>text.includes('SQLite'))")
            assert page.locator('button[data-node-id]').count() == count
            assert page.evaluate('window.graphFixture.readSnapshot().edges.length') == 0
            page.get_by_text('暂无明确关联，仍可浏览全部知识', exact=True).wait_for()
            assert not page.evaluate("window.sent.some(m=>m.organize||m.type==='knowledge_graph.open_doc')")
            if count == 200:
                page.wait_for_function('window.drawProbe.frameHistory.length>=20')
                initial_frames = page.evaluate('window.drawProbe.frameHistory.slice(0,20)')
                assert all(frame['nodes'] == 200 and frame['visible'] == 200 for frame in initial_frames), initial_frames
                (args.artifacts / 'initial-200-frames.json').write_text(json.dumps(initial_frames, indent=2) + '\n')
            summaries.append({'nodes': count, **painted(count)})
            page.screenshot(path=str(args.artifacts / f'after-{count}.png'), full_page=True)
        print('PASS 1/4/20/200: delayed storage, real node pixels, default titles, every document listed, honest zero-edge state')

        # Removing a Canvas must stop its loop; a later success creates a working
        # new Canvas, independently of the mount that originally saw null refs.
        page.evaluate("window.oldCanvas=document.querySelector('canvas');window.graphFixture.publish('error')")
        page.locator('canvas').wait_for(state='detached')
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        stopped_frames = page.evaluate('window.drawProbe.frames')
        page.wait_for_timeout(80)
        assert page.evaluate('window.drawProbe.frames') == stopped_frames
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.refresh')")
        page.evaluate("window.drawProbe.latestArcs=[];window.graphFixture.publish('4')")
        painted(4)
        assert page.evaluate("window.oldCanvas!==document.querySelector('canvas')")
        print('PASS ok → error stops drawing → refresh → ok remount draws real nodes')

        page.evaluate('window.sendFailure=true')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        page.get_by_text('无法连接 CMspark', exact=False).wait_for()
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        page.evaluate('window.sendFailure=false')
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        print('PASS failed send reports connection error while preserving the usable snapshot; default-off refresh does not enable AI')

        search = page.get_by_role('textbox', name='搜索知识', exact=True)
        search.fill('不存在的知识')
        assert page.locator('button[data-node-id]').count() == 0
        assert page.locator('canvas').is_visible()
        search.fill('Telescope')
        assert page.locator('button[data-node-id]').count() == 1
        page.locator('button[data-node-id="fixture-003"]').click()
        assert not page.evaluate("window.sent.some(m=>m.type==='knowledge_graph.open_doc')")
        page.get_by_role('button', name='在知识面板打开', exact=True).click()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').map(m=>m.id)") == ['fixture-003']
        search.fill('')
        radius = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='放大', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r>r', arg=radius)
        enlarged = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='缩小', exact=True).click()
        page.wait_for_function('(r)=>window.drawProbe.latestArcs[0].r<r', arg=enlarged)
        page.get_by_role('button', name='适应画布', exact=True).click()
        painted(4)
        page.get_by_role('button', name='收起列表', exact=True).click()
        assert page.get_by_role('complementary', name='知识浏览', exact=True).count() == 0
        page.get_by_role('button', name='浏览知识', exact=True).click()
        page.get_by_role('complementary', name='知识浏览', exact=True).wait_for()
        print('PASS search incl. empty results, local selection, explicit document open, camera and list controls')

        # Exercise actual keyboard events against the focused Canvas. Wait for
        # the physical simulation to settle so movement proves the key handler,
        # rather than merely observing an unrelated animation frame.
        canvas = page.get_by_test_id('knowledge-graph-canvas')
        canvas.focus()
        page.keyboard.press('Escape')
        page.wait_for_function('''() => {
            const arc=window.drawProbe.latestArcs[0];if(!arc)return false;
            const last=window.keyboardLastArc;
            window.keyboardStableFrames=last&&Math.abs(last.x-arc.x)<0.001&&Math.abs(last.y-arc.y)<0.001
                ? (window.keyboardStableFrames||0)+1 : 0;
            window.keyboardLastArc={x:arc.x,y:arc.y};
            return window.keyboardStableFrames>=6;
        }''')
        page.keyboard.press('0')
        page.wait_for_timeout(50)
        fitted_arc = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        page.keyboard.press('ArrowLeft')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x-40)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('Home')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('ArrowRight')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x+40)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('0')
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x)<0.1', arg=fitted_arc['x'])
        page.keyboard.press('+')
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r*1.25)<0.01', arg=fitted_arc['r'])
        page.keyboard.press('-')
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r)<0.01', arg=fitted_arc['r'])
        keyboard_document = page.locator('button[data-node-id="fixture-002"]')
        keyboard_document.focus()
        page.keyboard.press('Enter')
        page.wait_for_function('document.querySelector("button[data-node-id=fixture-002]").getAttribute("aria-pressed")==="true"')
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Orchids 高山兰花', exact=True).wait_for()
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length") == 1
        canvas.focus()
        page.keyboard.press('Escape')
        page.get_by_role('region', name='选中知识', exact=True).wait_for(state='detached')
        assert keyboard_document.get_attribute('aria-pressed') == 'false'
        print('PASS actual keyboard: ArrowLeft/Right change native Canvas positions; Home/0 restore fit; +/- change native radii; list Enter selects the correct document and Canvas Escape clears selection')

        # CDP injects real trusted touch input through Chrome's input pipeline.
        # DOM dispatchEvent cannot test the UA's implicit pointer-capture release.
        page.evaluate('''() => {
            window.touchEvidence=[];
            const c=document.querySelector('canvas');
            for(const type of ['pointerdown','pointermove','pointercancel','gotpointercapture','lostpointercapture']){
                c.addEventListener(type,event=>{
                    if(event.pointerType==='touch')window.touchEvidence.push({type:event.type,
                        pointerId:event.pointerId,isTrusted:event.isTrusted,
                        captureDuringEvent:c.hasPointerCapture(event.pointerId)});
                });
            }
        }''')
        cdp = page.context.new_cdp_session(page)
        cdp.send('Emulation.setTouchEmulationEnabled', {'enabled': True, 'maxTouchPoints': 1})
        canvas_box = canvas.bounding_box()
        assert canvas_box
        touch_x, touch_y = canvas_box['x'] + 25, canvas_box['y'] + 25
        before_touch = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        opened_before_touch = page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length")
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchStart', 'touchPoints': [{'x': touch_x, 'y': touch_y, 'id': 7}]})
        pointer_id = page.evaluate("window.touchEvidence.find(event=>event.type==='pointerdown').pointerId")
        capture_after_start = page.evaluate('(id)=>document.querySelector("canvas").hasPointerCapture(id)', pointer_id)
        assert capture_after_start is True
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchMove', 'touchPoints': [{'x': touch_x + 30, 'y': touch_y + 20, 'id': 7}]})
        page.wait_for_function('(x)=>Math.abs(window.drawProbe.latestArcs[0].x-x-30)<0.1', arg=before_touch['x'])
        cdp.send('Input.dispatchTouchEvent', {'type': 'touchCancel', 'touchPoints': []})
        page.wait_for_function('''(id)=>window.touchEvidence.some(event=>event.type==='pointercancel'&&event.pointerId===id)
            && !document.querySelector('canvas').hasPointerCapture(id)''', arg=pointer_id)
        capture_after_cancel = page.evaluate('(id)=>document.querySelector("canvas").hasPointerCapture(id)', pointer_id)
        touch_events = page.evaluate('window.touchEvidence')
        assert all(event['isTrusted'] and event['pointerId'] == pointer_id for event in touch_events), touch_events
        assert any(event['type'] == 'lostpointercapture' for event in touch_events), touch_events
        assert page.evaluate("window.sent.filter(m=>m.type==='knowledge_graph.open_doc').length") == opened_before_touch
        assert page.get_by_role('region', name='关联理由', exact=True).count() == 0
        after_cancel = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        # A leftover dragRef would move the camera on subsequent pointermove,
        # even though no new press started a drag. These are real mouse events.
        page.mouse.move(touch_x + 70, touch_y + 55)
        page.mouse.move(touch_x + 110, touch_y + 85)
        page.wait_for_timeout(80)
        after_hover = page.evaluate('({...window.drawProbe.latestArcs[0]})')
        assert abs(after_hover['x'] - after_cancel['x']) < 0.1 and abs(after_hover['y'] - after_cancel['y']) < 0.1, (after_cancel, after_hover)
        cdp.send('Emulation.setTouchEmulationEnabled', {'enabled': False})
        cdp.detach()
        touch_result = {'pointerId': pointer_id, 'captureAfterStart': capture_after_start,
                        'captureAfterCancel': capture_after_cancel, 'events': touch_events,
                        'cameraAfterCancel': after_cancel, 'cameraAfterUnpressedMoves': after_hover}
        (args.artifacts / 'pointercancel.json').write_text(json.dumps(touch_result, indent=2) + '\n')
        print('PASS trusted CDP touchStart → touchMove → touchCancel: capture true → false, lostpointercapture delivered, no document/reason opening and no drag left on subsequent unpressed pointer moves')
        print('POINTERCANCEL EVIDENCE ' + json.dumps(touch_result))

        # Production builder emits the organized group and AI relation; its
        # serializer controls optional wire keys and no fixture invents nodes.
        page.evaluate("window.graphFixture.publish('organized')")
        group = page.get_by_role('combobox', name='筛选分组', exact=True)
        page.wait_for_function("[...document.querySelectorAll('select option')].some(o=>o.textContent.includes('开发主题'))")
        group_key = page.evaluate("Object.keys(window.graphFixture.readSnapshot().labels)[0]")
        group.select_option(group_key)
        assert page.locator('button[data-node-id]').count() == 2
        group.select_option('')
        page.locator('button[data-node-id="fixture-001"]').click()
        page.get_by_text('AI 关联理由：共同讨论开发实践', exact=True).wait_for()
        print('PASS production organized group filtering and readable AI relationship reason')

        def painted_line(dashed):
            page.wait_for_function('''(dashed)=>{
                const c=document.querySelector('canvas'),ctx=c.getContext('2d');
                const bg=[...ctx.getImageData(0,0,1,1).data];if(bg[3]!==255)return false;
                return window.drawProbe.latestLines.filter(line=>line.dashed===dashed).some(line=>{
                    for(let step=2;step<19;step++)for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){
                        const x=Math.floor(line.a.x+(line.b.x-line.a.x)*step/20)+dx;
                        const y=Math.floor(line.a.y+(line.b.y-line.a.y)*step/20)+dy;
                        if(x<0||y<0||x>=c.width||y>=c.height)continue;
                        const pixel=[...ctx.getImageData(x,y,1,1).data];
                        if(pixel[3]>0&&pixel.some((v,i)=>i<3&&v!==bg[i]))return true;
                    }return false;
                });
            }''', arg=dashed)
        painted_line(True)
        groups = page.locator('details').filter(has=page.locator('summary').filter(has_text='分组说明与管理'))
        if groups.get_attribute('open') is None:
            groups.locator('summary').click()
        page.get_by_role('button', name='保留这版分组', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].lock_group') == group_key
        page.evaluate("window.graphFixture.publish('locked')")
        page.get_by_role('button', name='解锁', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].unlock_group') == group_key
        page.get_by_text('AI 与分组', exact=True).click()
        page.get_by_role('button', name='重新整理', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].organize') is True
        page.evaluate("window.graphFixture.publish('organizing')")
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.evaluate('window.sendFailure=true')
        groups.get_by_role('button', name='保留这版分组', exact=True).click()
        page.get_by_text('请求未发送', exact=False).wait_for()
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.get_by_role('switch', name='AI 分组命名', exact=True).click()
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.get_by_role('switch', name='AI 分组命名', exact=True).click()
        assert page.get_by_role('button', name='整理中…', exact=True).is_disabled()
        page.evaluate('window.sendFailure=false')
        page.evaluate("window.graphFixture.publish('organized')")
        assert page.get_by_role('button', name='重新整理', exact=True).is_enabled()
        page.evaluate('window.sendFailure=true')
        page.get_by_role('button', name='重新整理', exact=True).click()
        assert page.get_by_role('button', name='重新整理', exact=True).is_enabled()
        page.evaluate('window.sendFailure=false')
        print('PASS failed lock/naming requests preserve confirmed organizing busy state; a failed new organize request restores the confirmed idle state')
        page.evaluate("window.graphFixture.publish('similar')")
        painted(4)
        painted_line(False)
        assert page.evaluate('window.graphFixture.readSnapshot().edges.length') > 0
        print('PASS native dashed AI and solid similarity lines have pixels; lock/unlock and explicit organize retain their transport contracts')

        # A real viewport resize must resize the Canvas bitmap; responsive
        # layout must not leave its controls as opaque overlays on the graph.
        for width, height in [(1440, 900), (960, 720), (760, 740), (390, 844), (320, 480), (1280, 800)]:
            page.set_viewport_size({'width': width, 'height': height})
            page.get_by_role('button', name='适应画布', exact=True).click()
            page.wait_for_function('''() => {
                const c=document.querySelector('canvas');return c.width===Math.floor(c.getBoundingClientRect().width*devicePixelRatio);
            }''')
            painted(4)
            canvas_box = page.locator('canvas').bounding_box()
            aside_box = page.get_by_role('complementary', name='知识浏览', exact=True).bounding_box()
            assert canvas_box and aside_box
            overlap_w = min(canvas_box['x'] + canvas_box['width'], aside_box['x'] + aside_box['width']) - max(canvas_box['x'], aside_box['x'])
            overlap_h = min(canvas_box['y'] + canvas_box['height'], aside_box['y'] + aside_box['height']) - max(canvas_box['y'], aside_box['y'])
            assert overlap_w <= 1 or overlap_h <= 1, (canvas_box, aside_box)
            assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1')
            page.screenshot(path=str(args.artifacts / f'after-width-{width}.png'), full_page=True)
        print('PASS desktop/mobile resize: correctly sized real Canvas, non-overlapping browser, no horizontal overflow')

        # A native details element keeps a user's toggle when React re-renders
        # with an unchanged open prop. Exercise both default-open and default-
        # closed lanes via actual query and hover updates, not DOM mutation.
        details_evidence = []
        for count in [4, 20]:
            open_fixture(count)
            groups = page.locator('details').filter(has=page.locator('summary').filter(has_text='分组说明与管理'))
            expected_default = count <= 19
            assert (groups.get_attribute('open') is not None) is expected_default
            groups.locator('summary').click()
            expected_open = not expected_default
            assert (groups.get_attribute('open') is not None) is expected_open
            page.get_by_role('textbox', name='搜索知识', exact=True).fill('SQLite')
            assert page.locator('button[data-node-id]').count() == 1
            assert (groups.get_attribute('open') is not None) is expected_open
            canvas.scroll_into_view_if_needed()
            hovered = page.evaluate('''() => {
                const c=document.querySelector('canvas'),box=c.getBoundingClientRect(),arc=window.drawProbe.latestArcs[0];
                return {x:box.x+arc.x/devicePixelRatio,y:box.y+arc.y/devicePixelRatio};
            }''')
            page.mouse.move(hovered['x'], hovered['y'])
            page.get_by_role('status').filter(has_text='SQLite 离线检索').wait_for()
            assert (groups.get_attribute('open') is not None) is expected_open
            if count == 20:
                page.evaluate("window.graphFixture.publish('locked20')")
                assert (groups.get_attribute('open') is not None) is True
                unlock = groups.get_by_role('button', name='解锁', exact=True)
                unlock.wait_for()
                unlock.click()
                lock_key = page.evaluate("Object.keys(window.graphFixture.readSnapshot().labels).find(key=>window.graphFixture.readSnapshot().labels[key].locked)")
                assert page.evaluate('window.sent[window.sent.length-1].unlock_group') == lock_key
            details_evidence.append({'nodes': count, 'defaultOpen': expected_default,
                                     'manualOpenAfterQueryAndHover': expected_open, 'unlockReachable': count == 20})
        (args.artifacts / 'details-toggle.json').write_text(json.dumps(details_evidence, indent=2) + '\n')
        print('PASS native details: manually collapsed 4-node and expanded 20-node groups survive query/hover re-renders; 20-node locked group has a reachable working unlock button')

        open_fixture(4)
        start_radius = page.evaluate('window.drawProbe.latestArcs[0].r')
        page.get_by_role('button', name='放大', exact=True).click()
        page.wait_for_function('(r)=>Math.abs(window.drawProbe.latestArcs[0].r-r*1.25)<0.01', arg=start_radius)
        canvas.focus()
        def before_camera_change():
            return page.evaluate('''() => {
                const c=document.querySelector('canvas');
                return {frame:window.drawProbe.frames,width:c.width,height:c.height};
            }''')
        def camera_after_draw(before, previous=None, resized=False, viewport=None):
            # Assert and return the evidence in one JavaScript evaluation. The
            # native Canvas bitmap, CSS box and latest completed drawing frame
            # must describe the same new size, after the triggering operation.
            return page.wait_for_function('''({before,previous,resized,viewport}) => {
                const c=document.querySelector('canvas'),p=window.drawProbe;
                const n=p.latestArcs[0],box=c.getBoundingClientRect(),dpr=devicePixelRatio;
                if(!n||p.frames<=before.frame)return false;
                if(c.width!==Math.floor(box.width*dpr)||c.height!==Math.floor(box.height*dpr))return false;
                if(p.frameWidth!==c.width||p.frameHeight!==c.height)return false;
                if(resized&&c.width===before.width&&c.height===before.height)return false;
                if(viewport&&(innerWidth!==viewport[0]||innerHeight!==viewport[1]))return false;
                const sample={radius:n.r,xFromCenter:n.x-c.width/2,yFromCenter:n.y-c.height/2,
                    width:c.width,height:c.height,cssWidth:box.width,cssHeight:box.height,dpr,
                    beforeFrame:before.frame,drawnFrame:p.frames,drawnFrameWidth:p.frameWidth,
                    drawnFrameHeight:p.frameHeight,viewportWidth:innerWidth,viewportHeight:innerHeight};
                if(previous&&(Math.abs(sample.radius-previous.radius)>=0.01
                    ||Math.abs(sample.xFromCenter-previous.xFromCenter)>=0.1
                    ||Math.abs(sample.yFromCenter-previous.yFromCenter)>=0.1))return false;
                return sample;
            }''', arg={'before': before, 'previous': previous, 'resized': resized, 'viewport': viewport}).json_value()
        before_pan = before_camera_change()
        page.keyboard.press('ArrowLeft')
        custom_camera = camera_after_draw(before_pan)
        camera_evidence = [{'action': 'custom zoom and pan', **custom_camera}]
        before_close = before_camera_change()
        page.get_by_role('button', name='收起列表', exact=True).click()
        camera_evidence.append({'action': 'close list', **camera_after_draw(before_close, custom_camera, resized=True)})
        before_open = before_camera_change()
        page.get_by_role('button', name='浏览知识', exact=True).click()
        camera_evidence.append({'action': 'open list', **camera_after_draw(before_open, custom_camera, resized=True)})
        for width, height in [(1440, 900), (960, 720), (390, 844), (1280, 800)]:
            before_resize = before_camera_change()
            page.set_viewport_size({'width': width, 'height': height})
            camera_evidence.append({'action': f'resize {width}x{height}',
                **camera_after_draw(before_resize, custom_camera, resized=True, viewport=[width, height])})
        (args.artifacts / 'camera-preservation.json').write_text(json.dumps(camera_evidence, indent=2) + '\n')
        print('PASS custom native scale and world center remain unchanged when toggling the list or resizing desktop/mobile viewports; all 200 node centers were visible in every initial recorded frame')

        open_fixture(0)
        assert page.locator('canvas').count() == 0

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('error')")
        page.get_by_text('图谱加载失败', exact=False).wait_for()
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is False
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        print('PASS initially cached error snapshot can refresh and recover without closing the page')

        page.goto((Path(directory) / 'index.html').as_uri() + '?labels')
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('4')")
        painted(4)
        page.get_by_role('button', name='刷新图谱', exact=True).click()
        assert page.evaluate('window.sent[window.sent.length-1].llm_labels') is True
        assert not page.evaluate('window.sent.some(m=>m.organize)')
        print('PASS refresh preserves a previously enabled AI naming preference without automatically organizing')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.release('rebuilding',{focus_id:'fixture-003'})")
        assert page.locator('canvas').count() == 0
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.get_by_role('region', name='选中知识', exact=True).get_by_text('Telescope 天文观测', exact=True).wait_for()
        print('PASS a requested document remains selected across rebuilding → success with no new focus id')

        page.goto((Path(directory) / 'index.html').as_uri())
        page.wait_for_function('window.storageReads===1')
        page.evaluate("window.graphFixture.publish('4')")
        painted(4)
        page.evaluate("window.graphFixture.release('error')")
        page.wait_for_timeout(50)
        painted(4)
        assert page.locator('button[data-node-id]').count() == 4
        print('PASS a stale initial storage result cannot overwrite a newer successful storage event')
        assert not errors, errors
        (args.artifacts / 'after.json').write_text(json.dumps(summaries, indent=2) + '\n')
        assert not errors, errors
        browser.close()
print('PASS delayed storage → real Canvas node drawing')

```

### Current chrome-extension/scripts/render-knowledge-graph-fixture.cjs
```
// Real KnowledgeGraphApp and graph builder; only Chrome storage/runtime are fake.
// Never reads a user knowledge index or starts a Companion connection.
const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const out = process.argv[2];
if (!out) throw new Error('output directory required');
const esbuild = require(path.join(root, 'node_modules/esbuild'));

async function main() {
  fs.mkdirSync(out, { recursive: true });
  // The serializer is private in a large router with live configuration imports.
  // Execute its exact source with only that configuration boundary replaced;
  // do not hand-copy the wire keys into a fixture and assume they are correct.
  const router = fs.readFileSync(path.join(root, '../companion/src/message-router.ts'), 'utf8');
  const serializer = router.match(/\nfunction knowledgeGraphFrame\([\s\S]*?\n}\n/)?.[0];
  if (!serializer) throw new Error('production knowledgeGraphFrame definition not found');
  const rebuilding = router.slice(router.indexOf('const graph = skillEngine.getKnowledgeGraph'))
    .match(/if \(!graph\) \{[\s\S]*?return (\{[\s\S]*?\n        \})\n/)?.[1];
  if (!rebuilding) throw new Error('production rebuilding frame definition not found');
  const built = await esbuild.build({
    stdin: { contents: `export {buildKnowledgeGraph} from '../companion/src/skills/knowledge-graph';
      const knowledgeExtractLlmConfig=()=>({provider:'fixture'});
      let knowledgeGraphOrganizeRun=null;export function setOrganizing(value){knowledgeGraphOrganizeRun=value?{}:null;}
      ${serializer}\nexport {knowledgeGraphFrame};
      export function rebuildingFrame(){const actionError=undefined;return ${rebuilding};}`, resolveDir: root, loader: 'ts' },
    bundle: true, platform: 'node', format: 'cjs', write: false,
  });
  const production = new Module(path.join(out, 'graph-builder.cjs'), module);
  production._compile(built.outputFiles[0].text, path.join(out, 'graph-builder.cjs'));
  const { buildKnowledgeGraph, knowledgeGraphFrame, rebuildingFrame, setOrganizing } = production.exports;
  const graphs = { rebuilding: rebuildingFrame() };
  for (const count of [0, 1, 4, 20, 200]) {
    const docs = Array.from({ length: count }, (_, i) => ({
      id: `fixture-${String(i + 1).padStart(3, '0')}`,
      name: `fixture-${i + 1}`, title: ['SQLite 离线检索', 'Orchids 高山兰花', 'Telescope 天文观测', 'Sourdough 面包发酵'][i] || `Knowledge${String(i + 1).padStart(3, '0')}`,
      tags: [], folder: i % 2 ? '旅行' : '开发', bucket: 'global',
      // Deliberately orthogonal: zero TF edges is a real production result.
      vec: { [`unique-${i}`]: 1 }, description: '',
    }));
    graphs[count] = knowledgeGraphFrame(buildKnowledgeGraph(docs));
    if (count === 20) {
      graphs.locked20 = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { lock: { groups: [
        { ids: [docs[0].id, docs[2].id], name: '保留的研究主题', summary: '来自小语料阶段的锁定分组' },
      ] } }));
    }
    if (count === 4) {
      const llm = {
        groups: [{ ids: [docs[0].id, docs[2].id], name: '开发主题', summary: '两篇开发笔记' }],
        relations: [{ a: docs[0].id, b: docs[2].id, reason: '共同讨论开发实践', confidence: 0.9 }],
      };
      graphs.organized = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm }));
      setOrganizing(true);
      graphs.organizing = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm }));
      setOrganizing(false);
      graphs.locked = knowledgeGraphFrame(buildKnowledgeGraph(docs, undefined, { llm, lock: { groups: llm.groups } }));
      graphs.similar = knowledgeGraphFrame(buildKnowledgeGraph(docs.map((doc, i) => ({ ...doc, description: i < 2 ? 'shared retrieval database indexing' : '' }))));
    }
  }
  fs.writeFileSync(path.join(out, 'builder-output.json'), JSON.stringify(graphs, null, 2));
  const source = `
import React from 'react';
import {createRoot} from 'react-dom/client';
import {KnowledgeGraphApp} from './src/knowledge-graph/KnowledgeGraphApp';
import {parseKnowledgeGraphPayload} from './src/knowledge-graph/wire';
import {KNOWLEDGE_GRAPH_SNAPSHOT_KEY as KEY,writeKnowledgeGraphSnapshot,knowledgeGraphErrorPayload} from './src/background/knowledge-graph';
import {KNOWLEDGE_GRAPH_LLM_LABELS_KEY} from './src/knowledge-graph/llm-pref';
const graphs=${JSON.stringify(graphs)};
const listeners=new Set(); const session={}; const local=new URLSearchParams(location.search).has('labels')?{[KNOWLEDGE_GRAPH_LLM_LABELS_KEY]:true}:{};
window.sent=[];window.storageReads=0;window.storageReleased=false;window.sendFailure=false;
let suppressStorageEvent=false;
let release;const initialRead=new Promise(resolve=>release=resolve);
const emit=(changes,area)=>{for(const fn of [...listeners])fn(changes,area)};
window.chrome={runtime:{lastError:undefined,sendMessage:(message,callback)=>{window.sent.push(message);const response={sent:!window.sendFailure};callback?.(response);return Promise.resolve(response)}},storage:{
session:{get:async()=>{window.storageReads++;await initialRead;return {...session}},set:async values=>{Object.assign(session,values);if(!suppressStorageEvent)emit(Object.fromEntries(Object.entries(values).map(([key,newValue])=>[key,{newValue}])), 'session')}},
local:{get:async()=>({...local}),set:async values=>{Object.assign(local,values);emit(Object.fromEntries(Object.entries(values).map(([key,newValue])=>[key,{newValue}])), 'local')}},
onChanged:{addListener:fn=>listeners.add(fn),removeListener:fn=>listeners.delete(fn)}}};
window.graphFixture={graphs,
async publish(key,extra){const payload=key==='error'?knowledgeGraphErrorPayload({type:'error',error:'knowledge.graph fixture failure'}):parseKnowledgeGraphPayload(graphs[key]);if(!payload)throw new Error('invalid production payload');await writeKnowledgeGraphSnapshot(payload,extra);},
async release(key='4',extra){suppressStorageEvent=true;await this.publish(key,extra);suppressStorageEvent=false;window.storageReleased=true;release();},
readSnapshot:()=>session[KEY]};
// Observe real drawing and preserve every native call. Counters alone cannot
// pass the regression: Python also checks native Canvas pixels and dimensions.
window.drawProbe={arcs:0,text:[],frames:0,latestArcs:[],latestText:[],latestLines:[],path:[],frameHistory:[]};
for(const name of ['arc','fillText','clearRect','beginPath','moveTo','lineTo','stroke']){const native=CanvasRenderingContext2D.prototype[name];CanvasRenderingContext2D.prototype[name]=function(...args){const p=window.drawProbe;if(name==='clearRect'){p.frames++;p.latestArcs=[];p.latestText=[];p.latestLines=[]}if(name==='beginPath')p.path=[];if(name==='moveTo'||name==='lineTo'){const t=this.getTransform();p.path.push({x:t.a*args[0]+t.c*args[1]+t.e,y:t.b*args[0]+t.d*args[1]+t.f})}if(name==='stroke'&&p.path.length===2)p.latestLines.push({a:p.path[0],b:p.path[1],dashed:this.getLineDash().length>0});if(name==='arc'){p.arcs++;const t=this.getTransform();p.latestArcs.push({x:t.a*args[0]+t.c*args[1]+t.e,y:t.b*args[0]+t.d*args[1]+t.f,r:args[2]*t.a})}if(name==='fillText'){p.text.push(String(args[0]));p.latestText.push(String(args[0]));if(p.text.length>2000)p.text.splice(0,1000)}return native.apply(this,args)}};
const clearFrame=CanvasRenderingContext2D.prototype.clearRect;
CanvasRenderingContext2D.prototype.clearRect=function(...args){
  const p=window.drawProbe;
  if(p.latestArcs.length&&p.frameHistory.length<120)p.frameHistory.push({frame:p.frames,width:p.frameWidth,height:p.frameHeight,
    nodes:p.latestArcs.length,visible:p.latestArcs.filter(n=>n.x>=0&&n.y>=0&&n.x<p.frameWidth&&n.y<p.frameHeight).length});
  p.frameWidth=this.canvas.width;p.frameHeight=this.canvas.height;
  return clearFrame.apply(this,args);
};
createRoot(document.getElementById('root')).render(<KnowledgeGraphApp/>);
`;
  const baseline = process.argv.includes('--baseline');
  const plugins = baseline ? [{ name: 'baseline-app', setup(build) {
    build.onLoad({ filter: /KnowledgeGraphApp\.tsx$/ }, () => ({
      contents: execFileSync('git', ['show', 'aada096a:chrome-extension/src/knowledge-graph/KnowledgeGraphApp.tsx'], { cwd: root, encoding: 'utf8' }),
      loader: 'tsx', resolveDir: path.join(root, 'src/knowledge-graph'),
    }));
  } }] : [];
  await esbuild.build({ stdin: { contents: source, resolveDir: root, loader: 'tsx' }, bundle: true, outfile: path.join(out, 'app.js'), jsx: 'automatic', plugins });
  fs.writeFileSync(path.join(out, 'index.html'), '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body><div id="root"></div><script src="app.js"></script></body></html>');
}
main().catch(error => { console.error(error); process.exitCode = 1; });

```
