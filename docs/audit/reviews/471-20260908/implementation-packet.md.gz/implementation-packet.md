Independent READ-ONLY implementation review #471. Base4fd4919b, uncommitted frozen changes. User rejects prior superficial summoner/settings styling; requires chat consistency, no 山, logical settings. Evaluate outcome/trajectory/components, correctness/a11y/safety. Do not award length. Report precise P0/P1/MAJOR/NIT findings with evidence and VERDICT APPROVE/APPROVE_WITH_NITS/REJECT. Only supplied scope; no edits or other reviewer reports. All moved code is same component owner, stable hooks, hidden page wrappers preserve mounted children. Attached TypeScript AST event-handler multiset proves 134→130: only8 old category/accordion handlers removed and4 new category navigation handlers added; every configuration/permission/form handler retained exactly modulo whitespace. This does not itself certify layout; actual browser checks supplied.
MACHINE before review: extension productionbuild+1281pass0fail; companionproductionbuild+fulltests green (23 platform/fixture skips); actual React settings 320/390/800/1440 all8categories, model draft preservation, deep links/focus, cross-page safety badge, no implicit config.set/license/terminal sends PASS; existingworkspaceconfirmation/navigation regression PASS. Actual summoner HTML script, synthetic HTTP/SSE: initial+newthread no山, history, attachfilechooser, send, input/actions vertical ordering at320x420/390x740/1000x800 PASS. No live config, installedapp or account used. Design re-review underway after first-round completeness comments; do not treat implementation verdict as final design approval.
Scope: T3 presentation intersects existing trust. No permission defaults/protocols/Agent execution changed. True license Modal moved OUTSIDE hidden page; handlers/buttonorder preserved. Basic form labels clarified. Current CSS mirrored to standalone HTML (not exported runtime dependency). Native Swift has no 山 literal; user's offending mark found only in3HTML locations; no native-platform UX certification claimed.

# 召唤器与设置重设计

GitHub: #471 · Base:4fd4919b · 2026-09-08

召唤器与主聊天保持同一套浅色、文字层级、圆角输入区和底部操作排布。删除页头、初始及动态空态的“山”，不替换成其他大图标。空态以一句提示开始；历史/新对话保留；附件、听写、发送在输入框下，会议/打开浏览器为次要动作。保留全部 id、协议、状态及确认边界。独立设置网页也改浅色配置表面。

设置改为命名分类导航与单个当前内容页，宽屏左导航、窄屏紧凑分类选择。分类：模型与推理、输入与语音、文件与知识、连接与配对、安全与信任、本机与工具、密钥与环境、实验功能。模型页仅含模型/视觉/推理预算；语音与快捷键独立；上传、笔记导出与会话索引集中到文件与知识；既有权限/集成控件保留并加清楚子标题。

稳定设置 id 保持：model/connection/security/integrations/secrets/experimental；export 显示为文件与知识，新增 voice。旧深链继续可用；语音入口指向 voice。各配置页保持挂载，仅隐藏非当前页，保证未保存输入、权限确认短语和下载状态不因切页丢失。原有控件保存时机保持：全局保存仍统一保存，立即生效项目保留原语义和说明。配对/高权限状态跨分类可见且可定位。保存/测试只一处常驻，键盘 DOM 顺序与视觉一致，废除 CSS order 排列。

验证：实际 React 页320/390/800/1440与短屏，无横向溢出；每类可达；字段草稿切页保留；旧深链/voice深链；安全标识与原确认控件；真实召唤HTML脚本在隔离传输下新建对话/输入/历史，山不会恢复；生产构建及相关全量套件。Grok4.6 + DeepSeekV4Pro设计/实现独立复审，最终CI全绿后合并；无发布安装。

## 设计门禁补充（首轮意见逐项落实）

### 公共状态与确认可达性

设置标题下、分类/内容区外常驻状态行（320与1440同一DOM，窄屏换行；无状态不占位）。文案：检测中“正在检测连接”；未配对“尚未配对 · 前往连接设置”；已有高权限“有高权限开关已开启 · 查看安全设置”。原生按钮分别切到connection/security并聚焦标题；容器role=status/aria-live=polite，状态更新不抢焦点。高权限沿用isElevatedTrust，不引入新的权限判断。正在编辑的安全确认短语保留在security页，用户可用公共安全入口返回；真正的模态许可确认提升到公共内容区外，保持原按钮/顺序/处理器和焦点陷阱，避免被隐藏页遮蔽。

### 保存范围（“一处”指公共配置栏，不删除独立表单按钮）

| 类别 | 保存与测试 | 切页时未保存内容 |
|---|---|---|
| config模型/视觉/上下文/文件/会话索引 | 公共“保存全部配置”调用原handleSave一次，保存完整state.config；公共“测试模型连接”调用原handleTest，测当前草稿模型/视觉参数，与所在页无关 | 留在同一store，切页不保存 |
| 语音/快捷键等本机偏好 | 原即时处理器，页说明标明即时生效；下载/启用各自按钮保留 | React本地草稿保持挂载，不自动提交 |
| UserEnv/MCP/网络/编程开关 | 原独立保存/确认按钮保留，各页说明其独立语义 | 不纳入虚假的“保存所有独立表单”；组件保持挂载 |
| 许可/授权短语 | 原确认流程，公共保存不替代 | 切页不批准；Modal不埋在hidden树 |

公共栏始终展示“保存全部配置”“测试模型连接”，不使用“取消全部更改”承诺。页说明明确独立保存与即时生效，原config hydration门禁不动。

### 完整移动清单与稳定标识

| id（旧入口仍兼容） | 展示名 | 原控件归属 |
|---|---|---|
| model | 模型与推理 | 原model中协议/端点/key/预设/模型/主模型看图/温度 + Context Window/压缩/思考 + 完整视觉模型块；删除语音/文件块 |
| voice（新增） | 输入与语音 | 原model中“发送快捷键”起，到“Context Window”前的完整语音块（浏览器/本机/系统引擎、隐私、refiner、热键、下载/说话人模型） |
| export | 文件与知识 | 原model的File Upload Settings整个块 + 原experimental的Thread History IA session index块 + 原export所有笔记导出字段 |
| connection | 连接与配对 | 原connection完整块 |
| security | 安全与信任 | 原security完整块，所有arm/disarm/短语/警告/白名单不变 |
| integrations | 本机与工具 | 原integrations完整CapabilityProfile/NetSec/OutboundMcp/CodingHandoff及全部props；“下方自主度”改明确指向安全分类 |
| secrets | 密钥与环境 | 完整UserEnvSection |
| experimental | 实验功能 | 原实验本地视觉模型/许可证/下载管理；会话索引移出 |

useComposerVoice的原model深链改voice；所有设置自然语言的语音intent选voice，open_meeting/open_scene继续离开设置。其余model/integrations/export旧深链仍选同id页。旧折叠偏好不删除，新的单页布局不再消费它；会话首次默认model，未知/未配对回调在用户尚未选页时选connection；明确深链/人工选页不被迟到配对回调覆盖。分类选择在当前设置组件会话内保留。

### 导航与视觉规格

>=760：172px浅灰左侧nav，原生button（Tab/Enter/Space），aria-current=page；激活聚焦内容h3 tabindex=-1并将内容滚动归零。<760：有可见“设置分类”标签的原生select（系统键盘行为），选择后保留select焦点，内容标题同步；非当前页hidden，仍挂载且不进入Tab。对话框高度88dvh（窄屏94dvh），中间内容独立滚动，底部配置栏常驻。标题20px（窄屏18）、正文13–14、说明12、控件>=36px；浅色表面、8px控件圆角、16px外框、24/16px边距，沿用tokens。

召唤HTML以CSS变量镜像chat：paper #fff、canvas #f7f7f5、text #171717、secondary #666、focus #4f46e5、send #242424、user bubble #f3f3f1；系统字体14px/1.7，输入圆角20px、操作36px。页头纯文字CMspark+历史/新对话/既有档位，空态沿用CHAT_SHELL_TITLE_NONE，副行“回车发送。附件和听写不用开浏览器。”。输入textarea在前，附件→听写→发送按真实DOM排列；会议/打开浏览器留在输入区下方描边次按钮。不藏进菜单。山全源搜索：只在页头、初始空态、renderMsgs空态三个位置，无其他loading/error图标路径；三处全部删除。

独立settings-web是只配置全局模型的备用网页，不伪造扩展八类能力；沿用浅色表面、中文页名和表单层级，原端点/权限范围不扩展。

diff --git a/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx b/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
index 067d999c..eb8b4fd0 100644
--- a/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
+++ b/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
@@ -7,25 +7,19 @@ import { tokens } from "../ui/tokens"
 import { UserEnvSection } from "./UserEnvSection"
 import { NetSecSettingsSection } from "./NetSecSettingsSection"
 import { CapabilityProfileSection } from "./CapabilityProfileSection"
 import { OutboundMcpSettingsSection } from "./OutboundMcpSettingsSection"
 import { CodingHandoffSettingsSection } from "./CodingHandoffSettingsSection"
-import { SettingsSection } from "./SettingsSection"
+import { SettingsPage, SETTINGS_PAGES } from "./SettingsPage"
 import { SettingsIntentBar } from "./SettingsIntentBar"
 import { HotkeyCaptureField } from "./HotkeyCaptureField"
 import { useContextPanelHostOptional } from "./ContextPanelHost"
 import type { SettingsIntent } from "../utils/settings-intent"
 import { DICTATION_HOTKEY_DEFAULT_CHORD } from "../voice/hotkey-chord"
 import {
-  defaultUserOpenSections,
   isElevatedTrust,
-  isSectionEffectivelyOpen,
-  LS_SETTINGS_EXPAND,
-  parseSettingsExpand,
-  serializeSettingsExpand,
   SETTINGS_SECTION_IDS,
-  toggleSectionOpen,
   type SettingsSectionId,
 } from "../utils/settings-sections"
 import {
   contextWindowHelpText,
   settingsSaveDisabled,
@@ -179,52 +173,29 @@ export function SettingsSlideout() {
   const [voicePendingDownload, setVoicePendingDownload] = useState<string | null>(null)
   const voicePendingDownloadRef = useRef<string | null>(null)
   voicePendingDownloadRef.current = voicePendingDownload
   /** 模型下载源输入草稿；null = 未编辑，跟随 voiceModel 镜像。 */
   const [voiceEndpointDraft, setVoiceEndpointDraft] = useState<string | null>(null)
-  // W1 accordion: user open preferences (force rules applied in isSectionOpen).
-  const [userOpenSections, setUserOpenSections] = useState<Set<SettingsSectionId>>(() => {
-    try {
-      const parsed = parseSettingsExpand(localStorage.getItem(LS_SETTINGS_EXPAND))
-      if (parsed) return parsed
-    } catch {
-      /* ignore */
-    }
-    return defaultUserOpenSections(null)
-  })
+  const [activeSettingsPage, setActiveSettingsPage] = useState<SettingsSectionId>("model")
+  const settingsPageChosen = useRef(false)
+  const selectSettingsPage = useCallback((id: SettingsSectionId, focus = false) => {
+    settingsPageChosen.current = true
+    setActiveSettingsPage(id)
+    requestAnimationFrame(() => {
+      const body = document.querySelector<HTMLElement>(".cm-settings-body")
+      if (body) body.scrollTop = 0
+      if (focus) document.querySelector<HTMLElement>(`[data-settings-page="${id}"] h3`)?.focus()
+    })
+  }, [])
 
   const elevatedTrust = isElevatedTrust({
     auto_approve_dangerous: state.config.auto_approve_dangerous,
     auto_approve_enterprise_tools: state.config.auto_approve_enterprise_tools,
     allow_all_schemes: state.config.allow_all_schemes,
     unattendedArmed: state.unattended?.armed === true,
   })
 
-  const isSectionOpen = useCallback(
-    (id: SettingsSectionId) =>
-      isSectionEffectivelyOpen(id, {
-        userOpen: userOpenSections,
-        wsPaired,
-        elevatedTrust,
-      }),
-    [userOpenSections, wsPaired, elevatedTrust],
-  )
-
-  const handleToggleSection = useCallback((id: SettingsSectionId) => {
-    // Unpaired connection stays force-open via isSectionEffectivelyOpen; security
-    // is freely collapsible even under elevated trust (armed badge remains on header).
-    setUserOpenSections((prev) => {
-      const next = toggleSectionOpen(id, prev)
-      try {
-        localStorage.setItem(LS_SETTINGS_EXPAND, serializeSettingsExpand(next))
-      } catch {
-        /* ignore */
-      }
-      return next
-    })
-  }, [])
-
   // P0-2B: check on open whether a WS pairing secret is already stored, so the
   // status badge reflects the real pairing state (not just connection state).
   useEffect(() => {
     if (!state.settingsOpen) return
     // Reset stale pairing feedback + re-check stored-secret presence each open.
@@ -270,20 +241,11 @@ export function SettingsSlideout() {
     // #259: Windows SAPI probe (win32 → helper/System.Speech rows; other → no-op).
     chrome.runtime.sendMessage({ type: "voice.system.state" })
     chrome.runtime.sendMessage({ type: "ws.getPairingStatus" }, (resp: { paired?: boolean } | undefined) => {
       const paired = !!resp?.paired
       setWsPaired(paired)
-      // First open without LS: seed defaults from pairing (F-UX3).
-      try {
-        if (localStorage.getItem(LS_SETTINGS_EXPAND) == null) {
-          const seed = defaultUserOpenSections(paired)
-          setUserOpenSections(seed)
-          localStorage.setItem(LS_SETTINGS_EXPAND, serializeSettingsExpand(seed))
-        }
-      } catch {
-        /* ignore */
-      }
+      if (!settingsPageChosen.current) setActiveSettingsPage(paired ? "model" : "connection")
     })
     // Coding agents: list even when acp.enabled=false (discovery ≠ feature gate)
     chrome.runtime.sendMessage({ type: "acp.list" }, () => {
       void chrome.runtime.lastError
     })
@@ -373,30 +335,21 @@ export function SettingsSlideout() {
     const id = state.settingsFocusSection as SettingsSectionId
     if (!(SETTINGS_SECTION_IDS as readonly string[]).includes(id)) {
       dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
       return
     }
-    setUserOpenSections((prev) => {
-      if (prev.has(id)) return prev
-      const next = new Set(prev)
-      next.add(id)
-      try {
-        localStorage.setItem(LS_SETTINGS_EXPAND, serializeSettingsExpand(next))
-      } catch {
-        /* ignore */
-      }
-      return next
-    })
+    selectSettingsPage(id, true)
     dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
-  }, [state.settingsOpen, state.settingsFocusSection, dispatch])
+  }, [state.settingsOpen, state.settingsFocusSection, dispatch, selectSettingsPage])
 
   /**
    * Text / voice commands for configuring this extension (D2+ UX).
    * MUST stay above the settingsOpen early-return — React #310 if hooks run only when open.
    */
   const applySettingsIntent = useCallback(
     (intent: SettingsIntent): string => {
+      if (intent.type.startsWith("set_") || intent.type === "enable_hotkey_default") selectSettingsPage("voice")
       switch (intent.type) {
         case "set_dictation_mode":
           dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: intent.mode })
           return intent.mode === "continuous"
             ? "已开启连续听写"
@@ -429,11 +382,11 @@ export function SettingsSlideout() {
             }
             setEngineDraft("browser")
             return "已切换为浏览器听写（支持字级实时）"
           }
           setEngineDraft("local")
-          return "请在下方「听写方式」下载模型后点「启用本机转写」"
+          return "请在「输入与语音 → 听写方式」下载模型后点「启用本机转写」"
         case "enable_hotkey_default":
           dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: true })
           dispatch({
             type: "SET_DICTATION_HOTKEY_CHORD",
             chord: DICTATION_HOTKEY_DEFAULT_CHORD,
@@ -450,11 +403,11 @@ export function SettingsSlideout() {
         case "unknown":
         default:
           return "未识别。试试：开启连续听写 / 开启实时出字 / 打开会议 / 浏览器听写"
       }
     },
-    [dispatch, host],
+    [dispatch, host, selectSettingsPage],
   )
 
   if (!state.settingsOpen) return null
 
   const config = state.config
@@ -852,35 +805,28 @@ export function SettingsSlideout() {
         <div className="cm-settings-header" style={styles.header}>
           <h3 style={{ margin: 0, fontSize: 15 }}>设置</h3>
           <button type="button" aria-label="关闭设置" className="cm-icon-button" style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
         </div>
 
-        <nav aria-label="设置分类" className="cm-settings-categories">
-          {[
-            ["model", "模型与推理"], ["connection", "连接与配对"], ["security", "安全与信任"],
-            ["secrets", "密钥与环境"], ["integrations", "本机与集成"], ["export", "导出与集成"], ["experimental", "实验功能"],
-          ].map(([id, label]) => <button key={id} type="button" onClick={() => {
-            dispatch({ type: "OPEN_SETTINGS_SECTION", section: id })
-            requestAnimationFrame(() => requestAnimationFrame(() => {
-              const heading = document.querySelector<HTMLElement>(`[data-settings-section="${label}"] > button`)
-              heading?.focus(); heading?.scrollIntoView({ block: "start" })
-            }))
-          }}>{label}</button>)}
-        </nav>
-        <div className="cm-settings-body" style={{ ...styles.body, display: "flex", flexDirection: "column" }}>
-          {/* D2+ : configure CMspark itself via text or voice */}
-          <div style={{ order: 0 }}>
-            <SettingsIntentBar onIntent={applySettingsIntent} />
-          </div>
-
-          {/* IA order via flex order (settings-thread-compact W1) */}
-
-          <div style={{ order: 1 }}>
-            <SettingsSection
+        <div className="cm-settings-status" role="status" aria-live="polite">
+          {wsPaired !== true && <button type="button" onClick={() => selectSettingsPage("connection", true)}>{wsPaired === null ? "正在检测连接" : "尚未配对 · 前往连接设置"}</button>}
+          {elevatedTrust && <button type="button" onClick={() => selectSettingsPage("security", true)}>有高权限开关已开启 · 查看安全设置</button>}
+        </div>
+        <div className="cm-settings-layout">
+          <nav aria-label="设置分类" className="cm-settings-nav">
+            {SETTINGS_PAGES.map(page => <button type="button" key={page.id} aria-current={activeSettingsPage === page.id ? "page" : undefined} onClick={() => selectSettingsPage(page.id, true)}>{page.title}</button>)}
+          </nav>
+          <label className="cm-settings-mobile-category">设置分类
+            <select aria-label="设置分类" value={activeSettingsPage} onChange={event => selectSettingsPage(event.target.value as SettingsSectionId)}>{SETTINGS_PAGES.map(page => <option value={page.id} key={page.id}>{page.title}</option>)}</select>
+          </label>
+          <div className="cm-settings-body" style={styles.body}>
+            <details className="cm-settings-assistant"><summary>用一句话调整设置</summary><SettingsIntentBar onIntent={applySettingsIntent} /></details>
+
+          <div data-settings-page="connection" hidden={activeSettingsPage !== "connection"}>
+            <SettingsPage
               title="连接与配对"
-              open={isSectionOpen("connection")}
-              onToggle={() => handleToggleSection("connection")}
+              id="connection"
               badge={wsPaired === false ? (
                 <span style={{
                   fontSize: 10,
                   fontWeight: 600,
                   padding: "1px 6px",
@@ -935,21 +881,20 @@ export function SettingsSlideout() {
               </div>
             )}
           </div>
 
           
-            </SettingsSection>
+            </SettingsPage>
           </div>
 
-          <div style={{ order: 2 }}>
-            <SettingsSection
+          <div data-settings-page="model" hidden={activeSettingsPage !== "model"}>
+            <SettingsPage
               title="模型与推理"
-              open={isSectionOpen("model")}
-              onToggle={() => handleToggleSection("model")}
+              id="model"
             >
           {/* --- LLM Settings --- */}
-          <div style={styles.sectionTitle}>LLM 配置</div>
+          <div style={styles.sectionTitle}>对话模型</div>
 
           <div style={styles.field}>
             <label style={styles.label}>API 协议</label>
             <select
               style={styles.input}
@@ -975,11 +920,11 @@ export function SettingsSlideout() {
                 : "默认 OpenAI Chat Completions（DeepSeek / 多数中继）。"}
             </div>
           </div>
 
           <div style={styles.field}>
-            <label style={styles.label}>Base URL</label>
+            <label style={styles.label}>服务地址（Base URL）</label>
             <input
               style={styles.input}
               type="text"
               value={config.base_url}
               onChange={e => dispatch({ type: "SET_CONFIG", config: { base_url: e.target.value } })}
@@ -1107,11 +1052,11 @@ export function SettingsSlideout() {
               </button>
             </div>
           </div>
 
           <div style={styles.field}>
-            <label style={styles.label}>Model</label>
+            <label style={styles.label}>模型名称</label>
             <input
               style={styles.input}
               list="model-options"
               type="text"
               value={config.model_name}
@@ -1128,11 +1073,11 @@ export function SettingsSlideout() {
               <option value="claude-sonnet-4-6" />
               <option value="claude-opus-4-7" />
             </datalist>
             {!config.model_name && state.companionConfig?.model_name && (
               <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
-                Using Companion global config: {state.companionConfig.model_name}
+                当前使用 Companion 全局配置： {state.companionConfig.model_name}
               </div>
             )}
           </div>
 
           <div style={styles.field}>
@@ -1161,11 +1106,11 @@ export function SettingsSlideout() {
                   : " 尚未探测。"}
             </div>
           </div>
 
           <div style={styles.field}>
-            <label style={styles.label}>Temperature: {(config.temperature ?? 0.7).toFixed(1)}</label>
+            <label style={styles.label}>温度： {(config.temperature ?? 0.7).toFixed(1)}</label>
             <input
               style={{ width: "100%" }}
               type="range"
               min={0}
               max={2}
@@ -1174,467 +1119,836 @@ export function SettingsSlideout() {
               onChange={e => dispatch({ type: "SET_CONFIG", config: { temperature: parseFloat(e.target.value) } })}
             />
           </div>
 
           <div style={styles.field}>
-            <label style={styles.label}>发送快捷键</label>
+            <label style={styles.label}>上下文窗口（Token）</label>
+            <input
+              style={styles.input}
+              type="number"
+              value={config.context_window}
+              onChange={e => dispatch({ type: "SET_CONFIG", config: { context_window: parseInt(e.target.value) || 512000 } })}
+              min={1024}
+              max={1000000}
+              step={1024}
+            />
+            <div style={styles.helpText}>
+              {contextWindowHelpText(config.context_window)}
+            </div>
+          </div>
+
+          <div style={styles.field}>
+            <label style={styles.label}>长对话上下文预算</label>
             <select
-              style={styles.select}
-              value={state.sendShortcut || "Enter"}
-              onChange={handleShortcutChange}
+              style={styles.select || styles.input}
+              value={config.context_compaction ?? "auto"}
+              onChange={e => {
+                const v = e.target.value
+                if (v !== "auto" && v !== "prompt" && v !== "off") return
+                if (v === "auto") {
+                  const ok = window.confirm(
+                    "自动压缩会让模型看不到较早轮次，即使聊天区仍显示全文。确定启用？",
+                  )
+                  if (!ok) return
+                }
+                dispatch({ type: "SET_CONFIG", config: { context_compaction: v } })
+              }}
             >
-              <option value="Enter">Enter</option>
-              <option value="Cmd+Enter">Cmd+Enter</option>
-              <option value="Ctrl+Enter">Ctrl+Enter</option>
+              <option value="auto">自动压缩（超预算时）</option>
+              <option value="prompt">仅提示（不压缩）</option>
+              <option value="off">关闭</option>
             </select>
+            <div style={styles.helpText}>
+              仅影响发给模型的请求；磁盘与界面消息仍完整。仅提示 = 超预算时警告，需改回「自动」才压缩。
+            </div>
           </div>
 
+          {(config.context_compaction ?? "auto") === "auto" && (
+            <div style={styles.field}>
+              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
+                <input
+                  type="checkbox"
+                  checked={config.context_compaction_m2 !== false}
+                  onChange={e =>
+                    dispatch({
+                      type: "SET_CONFIG",
+                      config: { context_compaction_m2: e.target.checked },
+                    })
+                  }
+                />
+                结构化工作记忆（H1）/ 滚动摘要
+              </label>
+              <div style={styles.helpText}>
+                默认开启：丢弃轮次较多时，优先生成脱敏的结构化工作记忆（目标/决策/约束/待办/产物），
+                失败则退回散文摘要；可在聊天顶栏「查看摘要」。仅在本轮开始时跑（tool 中途只做截断占位）。
+              </div>
+            </div>
+          )}
+
           <div style={styles.field}>
-            <label style={styles.label}>语音输入</label>
-            <label
-              style={{
-                display: "flex",
-                alignItems: "center",
-                gap: 8,
-                cursor: "pointer",
-                fontSize: 13,
+            <label style={styles.label}>思考过程展示</label>
+            <select
+              style={styles.input}
+              value={state.showReasoningMode || "auto_live"}
+              onChange={(e) => {
+                const v = e.target.value
+                if (v === "always_collapsed" || v === "auto_live" || v === "always_open") {
+                  dispatch({ type: "SET_SHOW_REASONING_MODE", mode: v })
+                }
               }}
             >
+              <option value="auto_live">仅推理时展开（默认）</option>
+              <option value="always_collapsed">默认折叠</option>
+              <option value="always_open">始终展开</option>
+            </select>
+            <div style={styles.helpText}>
+              仅影响 Side Panel 显示。历史消息不会把思考回灌给模型（省 token / 兼容 Anthropic）。
+            </div>
+          </div>
+
+          <div style={styles.field}>
+            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
               <input
                 type="checkbox"
-                checked={state.voiceInputEnabled !== false}
+                checked={state.exportIncludeReasoning === true}
                 onChange={(e) =>
-                  dispatch({ type: "SET_VOICE_INPUT_ENABLED", enabled: e.target.checked })
+                  dispatch({ type: "SET_EXPORT_INCLUDE_REASONING", enabled: e.target.checked })
                 }
               />
-              在输入框显示麦克风（听写进草稿，不自动发送）
+              导出 Markdown 时包含思考过程
             </label>
+            <div style={styles.helpText}>
+              默认关闭。开启后以折叠块写入笔记；请注意思考可能含中间假设，勿默认分享。
+            </div>
+          </div>
 
-            <div style={{ marginTop: 10, fontSize: 12, color: tokens.textSecondary }}>
-              <label
-                style={{
-                  display: "flex",
-                  alignItems: "flex-start",
-                  gap: 8,
-                  marginBottom: 10,
-                  cursor: "pointer",
-                  fontSize: 12,
-                  lineHeight: 1.4,
-                }}
-              >
-                <input
-                  type="checkbox"
-                  style={{ marginTop: 2 }}
-                  checked={state.voiceRealtimeStreaming !== false}
-                  onChange={(e) =>
-                    dispatch({
-                      type: "SET_VOICE_REALTIME_STREAMING",
-                      enabled: e.target.checked,
-                      preferContinuous: e.target.checked,
-                    })
-                  }
-                />
-                <span>
-                  <strong>实时出字</strong>
-                  （字级 / 近实时）
-                  <br />
-                  <span style={{ color: tokens.textMuted, fontSize: 11 }}>
-                    浏览器听写：Web Speech 字级 interim。本机 Whisper（连续 + 本开关）：PCM
-                    流式上传 + 约 8s 窗口内渐进重解码假设（poll 按上次推断耗时自适应）；窗口结束定稿；非
-                    decoder token 流。开启时会切到连续听写。
-                  </span>
-                </span>
-              </label>
-              {state.voiceRealtimeStreaming !== false &&
-                state.voiceModel?.sttEngine === "local" && (
-                  <div
-                    style={{
-                      marginBottom: 10,
-                      padding: "6px 8px",
-                      fontSize: 11,
-                      lineHeight: 1.4,
-                      background: tokens.successSoft,
-                      border: `1px solid ${tokens.success}`,
-                      borderRadius: 6,
-                      color: tokens.success,
-                    }}
-                  >
-                    本机渐进假设流已开：说话中显示临时字，约每 8s
-                    定稿一段；poll 随模型耗时自适应（medium 可能更慢）。更丝滑可改用浏览器听写。
-                  </div>
-                )}
-              <div style={{ marginBottom: 4, fontWeight: 500 }}>听写形态</div>
-              <label style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4, cursor: "pointer" }}>
-                <input
-                  type="radio"
-                  name="voiceDictationMode"
-                  checked={(state.voiceDictationMode || "classic") === "classic"}
-                  onChange={() =>
-                    dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: "classic" })
+                    {/* --- Vision Model Settings --- */}
+          <div style={styles.sectionTitle}>视觉模型（看图描述）</div>
+
+          <div style={styles.field}>
+            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
+              <input
+                type="checkbox"
+                checked={config.vision_enabled || false}
+                onChange={e => {
+                  const on = e.target.checked
+                  dispatch({ type: "SET_CONFIG", config: { vision_enabled: on } })
+                  setVisionReuseHint(null)
+                  if (!on) {
+                    setVisionReuseBanner(false)
+                    return
                   }
-                />
-                经典短听（默认 · 最长约 45 秒）
-              </label>
-              <label style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
-                <input
-                  type="radio"
-                  name="voiceDictationMode"
-                  checked={state.voiceDictationMode === "continuous"}
-                  onChange={() =>
-                    dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: "continuous" })
+                  // Banner only on false→true; never auto-copy credentials (S-V5)
+                  if (
+                    !visionReuseBannerDismissed &&
+                    shouldOfferVisionReuse({
+                      model_name: config.model_name,
+                      base_url: config.base_url,
+                      api_key: config.api_key,
+                      protocol: config.protocol,
+                    })
+                  ) {
+                    setVisionReuseBanner(true)
+                  } else {
+                    setVisionReuseBanner(false)
                   }
-                />
-                连续听写（可选 · 最长默认 15 分钟）
-              </label>
-              <div style={{ marginTop: 4, fontSize: 11, color: tokens.textMuted, lineHeight: 1.4 }}>
-                浏览器：自动续听 + 字级 interim；本机：实时出字开时约 8 秒一段，否则约 45
-                秒一段。仅进草稿、不自动发送。首次连续听写需隐私 v3。
-              </div>
-              <label
-                style={{
-                  display: "flex",
-                  alignItems: "flex-start",
-                  gap: 8,
-                  marginTop: 10,
-                  cursor: "pointer",
-                  fontSize: 12,
-                  lineHeight: 1.4,
                 }}
-              >
-                <input
-                  type="checkbox"
-                  style={{ marginTop: 2 }}
-                  checked={state.asrRefinerEnabled === true}
-                  onChange={(e) =>
-                    dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: e.target.checked })
-                  }
-                />
-                <span>
-                  <strong>ASR 纠错</strong>
-                  （停后可选；默认关）
-                  <br />
-                  <span style={{ color: tokens.textMuted, fontSize: 11 }}>
-                    将把<strong>转写文本</strong>发给当前 Companion 模型做极保守纠错（不润色、不自动发送）；需已配置
-                    LLM。首次听写前若未确认隐私 v3 将弹出说明。当前模型：
-                    {state.companionConfig?.model_name || "（未连接/未配置）"}
-                  </span>
-                </span>
-              </label>
-
-              <div style={{ marginTop: 12, fontSize: 12, color: tokens.textSecondary }}>
-                <div style={{ marginBottom: 4, fontWeight: 500 }}>按住热键听写（D2 · 默认关）</div>
-                <label
-                  style={{
+              />
+              启用截图视觉分析
+            </label>
+            <div style={styles.helpText}>{VISION_COPY.sectionHelp}</div>
+            <div style={{ ...styles.helpText, marginTop: 4 }}>{VISION_COPY.railDifferentiator}</div>
+          </div>
+
+          {config.vision_enabled && (config.protocol === "anthropic") && (
+            <div style={{
+              ...styles.field,
+              padding: "8px 10px",
+              borderRadius: 8,
+              background: tokens.warningSoft,
+              border: `1px solid ${tokens.warning}`,
+              fontSize: 12,
+              color: tokens.text,
+            }}>
+              {VISION_COPY.anthropicBlocked}
+            </div>
+          )}
+
+          {config.vision_enabled && visionReuseBanner && (
+            <div style={{
+              ...styles.field,
+              padding: "10px 12px",
+              borderRadius: 8,
+              background: tokens.accentSoft,
+              border: `1px solid ${tokens.border}`,
+            }}>
+              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{VISION_COPY.bannerTitle}</div>
+              <div style={{ fontSize: 12, color: tokens.textSecondary, marginBottom: 8, lineHeight: 1.45 }}>
+                {bannerBodyForHost(extractHostname(config.base_url))}
+              </div>
+              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
+                <button
+                  type="button"
+                  style={styles.testBtn}
+                  onClick={() => {
+                    const main = {
+                      model_name: config.model_name,
+                      base_url: config.base_url,
+                      api_key: config.api_key,
+                      protocol: config.protocol,
+                    }
+                    if (isCustomVisionConfig(main, config)) {
+                      if (!window.confirm(VISION_COPY.overwriteConfirm)) return
+                    }
+                    const result = applyVisionReuseFromMain(main)
+                    dispatch({ type: "SET_CONFIG", config: result.patch })
+                    setVisionReuseBanner(false)
+                    setVisionReuseBannerDismissed(true)
+                    setVisionAdvancedOpen(false)
+                    setVisionReuseHint(
+                      (result.needsKeyPaste ? VISION_COPY.needsKeyPaste + " " : "") +
+                        VISION_COPY.postReuseTestHint,
+                    )
+                  }}
+                >
+                  {VISION_COPY.useMain}
+                </button>
+                <button
+                  type="button"
+                  style={styles.toggleBtn}
+                  onClick={() => {
+                    setVisionReuseBanner(false)
+                    setVisionReuseBannerDismissed(true)
+                    setVisionAdvancedOpen(true)
+                  }}
+                >
+                  {VISION_COPY.keepSeparate}
+                </button>
+              </div>
+            </div>
+          )}
+
+          {config.vision_enabled && visionReuseHint && (
+            <div style={{ ...styles.helpText, color: tokens.success, marginBottom: 8 }}>
+              {visionReuseHint}
+            </div>
+          )}
+
+          {config.vision_enabled && (() => {
+            const reusing = isVisionReusingMain(
+              { model_name: config.model_name, base_url: config.base_url },
+              config,
+            )
+            const showFields = !reusing || visionAdvancedOpen
+            return (
+              <>
+                {reusing && (
+                  <div style={{
                     display: "flex",
-                    alignItems: "flex-start",
+                    alignItems: "center",
                     gap: 8,
-                    cursor: "pointer",
+                    flexWrap: "wrap",
+                    marginBottom: 8,
                     fontSize: 12,
-                    lineHeight: 1.4,
-                  }}
-                >
-                  <input
-                    type="checkbox"
-                    style={{ marginTop: 2 }}
-                    checked={state.dictationHotkeyEnabled === true}
-                    onChange={(e) =>
-                      dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: e.target.checked })
-                    }
-                  />
-                  <span>
-                    启用按住说话
-                    <br />
-                    <span style={{ color: tokens.textMuted, fontSize: 11 }}>
-                      按住 ≥300ms 松手转写；短按静默丢弃。300ms 内连按两次进入锁定（再按或 Esc 结束）。仅进草稿、不自动发送。需 Side Panel
-                      打开；页面可编辑框内同一热键会插入到该框。禁止 bare Fn / Win+V。会议录音中不可用。默认关。
+                  }}>
+                    <span style={{
+                      padding: "2px 8px",
+                      borderRadius: 8,
+                      background: tokens.successSoft,
+                      color: tokens.success,
+                      fontWeight: 500,
+                    }}>
+                      {VISION_COPY.reusedChip} · {extractHostname(config.vision_base_url || config.base_url)}
                     </span>
-                  </span>
+                    <button
+                      type="button"
+                      style={styles.toggleBtn}
+                      onClick={() => setVisionAdvancedOpen(v => !v)}
+                    >
+                      {visionAdvancedOpen ? VISION_COPY.collapseAdvanced : VISION_COPY.expandAdvanced}
+                    </button>
+                  </div>
+                )}
+
+                {showFields && (
+                  <>
+              <div style={styles.field}>
+                <label style={styles.label}>
+                  API Key{" "}
+                  {!config.vision_api_key && state.companionConfig?.vision_api_key_set && (
+                    <span style={{
+                      fontSize: 10, fontWeight: 500, marginLeft: 6,
+                      padding: "1px 6px", borderRadius: 8,
+                      color: tokens.success, background: tokens.successSoft,
+                    }}>
+                      ✓ 已配置
+                    </span>
+                  )}
                 </label>
-                <div style={{ marginTop: 8, fontSize: 11, color: tokens.textSecondary }}>
-                  <div style={{ marginBottom: 2 }}>组合键（按键盘录制或点预设）</div>
-                  <HotkeyCaptureField
-                    value={state.dictationHotkeyChord || DICTATION_HOTKEY_DEFAULT_CHORD}
-                    disabled={!state.dictationHotkeyEnabled}
-                    onChange={(chord) =>
-                      dispatch({ type: "SET_DICTATION_HOTKEY_CHORD", chord })
-                    }
-                  />
-                </div>
-                <label style={{ display: "flex", gap: 8, marginTop: 8, fontSize: 12, cursor: "pointer" }}>
+                <div style={{ display: "flex", gap: 6 }}>
                   <input
-                    type="checkbox"
-                    checked={state.voiceSoundEffects !== false}
-                    onChange={(e) =>
-                      dispatch({ type: "SET_VOICE_SOUND_EFFECTS", enabled: e.target.checked })
+                    style={{ ...styles.input, flex: 1 }}
+                    type={showKey ? "text" : "password"}
+                    value={config.vision_api_key || ""}
+                    onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_api_key: e.target.value } })}
+                    placeholder={
+                      state.companionConfig?.vision_api_key_set
+                        ? "（已配置，留空保持不变；输入新值覆盖）"
+                        : "本地 Ollama 可留空；云端需填写（或与主模型相同后保存继承）"
                     }
                   />
-                  听写状态音效（开始/停止/完成；误触静默）
-                </label>
+                </div>
+                <div style={styles.helpText}>
+                  本地 loopback 可留空；非本机端点需真实 Key。与主模型 URL/Model 相同时，保存会继承主 Key。
+                </div>
               </div>
-            </div>
 
-            {/* Path B M0: 听写方式 progressive disclosure (UI draft until ready + enable) */}
-            {(() => {
-              const voiceModel = state.voiceModel
-              const progress = state.voiceModelProgress
-              const committedLocal = voiceModel?.sttEngine === "local"
-              const committedSystem = voiceModel?.sttEngine === "system"
-              const showLocalPanel = engineDraft === "local"
-              // #259: system option only exists on win32 with the probe mirror.
-              const systemStateMirror = state.voiceSystemState
-              const systemProbeWin32 = systemStateMirror?.platform === "win32"
-              const systemProbeGreen =
-                systemProbeWin32 &&
-                systemStateMirror?.helper?.ok === true &&
-                systemStateMirror?.systemSpeech?.available === true
-              const showSystemPanel = engineDraft === "system"
-              const clearVoiceErr = () =>
-                dispatch({ type: "SET_VOICE_MODEL_ERROR", error: null })
-              /** settings → SW → WS; always surface SW refusals into voiceModelError. */
-              const sendVoice = (
-                msg: Record<string, unknown>,
-                opts?: { onOk?: () => void; onFail?: () => void },
-              ) => {
-                try {
-                  chrome.runtime.sendMessage({ ...msg, source: "settings" }, (resp: unknown) => {
-                    const lastErr =
-                      typeof chrome.runtime.lastError?.message === "string"
-                        ? chrome.runtime.lastError.message
-                        : null
-                    const parsed = parseVoiceSettingsSendResponse(resp, lastErr)
-                    if (parsed.ok === false) {
-                      opts?.onFail?.()
-                      dispatch({ type: "SET_VOICE_MODEL_ERROR", error: parsed.error })
-                      return
-                    }
-                    opts?.onOk?.()
-                  })
-                } catch (e: unknown) {
-                  opts?.onFail?.()
-                  const msgText = e instanceof Error ? e.message : String(e)
-                  dispatch({
-                    type: "SET_VOICE_MODEL_ERROR",
-                    error: msgText || VOICE_ERR_STATE_TIMEOUT,
-                  })
-                }
-              }
-              const recommendedId = RECOMMENDED_WHISPER_MODEL_ID
-              const activeId = voiceModel?.localModelId || recommendedId
-              const recEntry = voiceModel?.models?.[recommendedId]
-              const recReady = recEntry?.status === "ready"
-              const activeReady = voiceModel?.models?.[activeId]?.status === "ready"
-              const canEnableLocal = recReady || activeReady
-              const privacyEngine: "browser" | "local" | "system" =
-                engineDraft === "local" || committedLocal
-                  ? "local"
-                  : engineDraft === "system" || committedSystem
-                    ? "system"
-                    : "browser"
+              <div style={styles.field}>
+                <label style={styles.label}>服务地址（Base URL）</label>
+                <input
+                  style={styles.input}
+                  type="text"
+                  value={config.vision_base_url || "http://localhost:11434/v1"}
+                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_base_url: e.target.value } })}
+                  placeholder="http://localhost:11434/v1 或云端 OpenAI 兼容端点"
+                />
+              </div>
 
-              /** Persist 模型下载源 via voice.model.set_prefs; store mirror re-drives input on ok. */
-              const saveVoiceEndpoint = () => {
-                const value = (voiceEndpointDraft ?? "").trim()
-                clearVoiceErr()
-                sendVoice(
-                  { type: "voice.model.set_prefs", modelDownloadEndpoint: value },
-                  { onOk: () => setVoiceEndpointDraft(null) },
-                )
-              }
+              <div style={styles.field}>
+                <label style={styles.label}>模型名称</label>
+                <input
+                  style={styles.input}
+                  list="vision-model-options"
+                  type="text"
+                  value={config.vision_model_name || ""}
+                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_model_name: e.target.value } })}
+                  placeholder="输入模型名称或从列表选择"
+                />
+                <datalist id="vision-model-options">
+                  <option value="llava:7b" />
+                  <option value="llava:13b" />
+                  <option value="minicpm-v" />
+                  <option value="qwen2.5vl:3b" />
+                  <option value="moondream2" />
+                  <option value="gpt-4o" />
+                  <option value="glm-4.6v" />
+                </datalist>
+              </div>
 
-              const renderModelRow = (modelId: WhisperSettingsModelId, isRecommended: boolean) => {
-                const entry = voiceModel?.models?.[modelId]
-                const status = entry?.status || "absent"
-                const pendingStart = voicePendingDownload === modelId
-                const downloading =
-                  status === "downloading" ||
-                  pendingStart ||
-                  (progress?.modelId === modelId && status !== "ready")
-                const pct = pendingStart
-                  ? 0
-                  : downloading && progress?.modelId === modelId
-                    ? progressPercent(progress.receivedBytes, progress.totalBytes)
-                    : null
-                const isActive = committedLocal && activeId === modelId
-                return (
+              <div style={styles.field}>
+                <label style={styles.label}>
+                  超时时间: {Math.round((config.vision_timeout_ms || 30000) / 1000)}s
+                </label>
+                <input
+                  style={{ width: "100%" }}
+                  type="range"
+                  min={10000}
+                  max={60000}
+                  step={5000}
+                  value={config.vision_timeout_ms || 30000}
+                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_timeout_ms: parseInt(e.target.value) } })}
+                />
+              </div>
+
+              <div style={styles.field}>
+                <label style={styles.label}>降级策略</label>
+                <select
+                  style={styles.select}
+                  value={config.vision_fallback || "metadata"}
+                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_fallback: e.target.value as "metadata" | "passthrough" | "error" } })}
+                >
+                  <option value="metadata">{VISION_COPY.fallbackMetadata}</option>
+                  <option value="passthrough">{VISION_COPY.fallbackPassthrough}</option>
+                  <option value="error">{VISION_COPY.fallbackError}</option>
+                </select>
+                <div style={styles.helpText}>
+                  视觉模型不可用时的处理方式：仅元数据 = 发送页面标题和尺寸信息
+                </div>
+              </div>
+                  </>
+                )}
+
+              <div style={styles.field}>
+                <button style={styles.testBtn} onClick={() => {
+                  dispatch({ type: "SET_TEST_RESULT", result: "测试视觉模型连接中...（请先保存配置）" })
+                  chrome.runtime.sendMessage({ type: "config.testVision" })
+                }}>
+                  测试视觉模型连接
+                </button>
+              </div>
+              </>
+            )
+          })()}
+
+              <div style={styles.field}>
+                <div style={styles.helpText}>
+                  上下文窗口过大时，长对话压缩会来不及触发（新默认 512000 是 Agent 工作预算）。建议按模型真实上限设置。
+                </div>
+              </div>
+            </SettingsPage>
+          </div>
+
+          <div data-settings-page="voice" hidden={activeSettingsPage !== "voice"}>
+            <SettingsPage id="voice" title="输入与语音">
+          <div style={styles.field}>
+            <label style={styles.label}>发送快捷键</label>
+            <select
+              style={styles.select}
+              value={state.sendShortcut || "Enter"}
+              onChange={handleShortcutChange}
+            >
+              <option value="Enter">Enter</option>
+              <option value="Cmd+Enter">Cmd+Enter</option>
+              <option value="Ctrl+Enter">Ctrl+Enter</option>
+            </select>
+          </div>
+
+          <div style={styles.field}>
+            <label style={styles.label}>语音输入</label>
+            <label
+              style={{
+                display: "flex",
+                alignItems: "center",
+                gap: 8,
+                cursor: "pointer",
+                fontSize: 13,
+              }}
+            >
+              <input
+                type="checkbox"
+                checked={state.voiceInputEnabled !== false}
+                onChange={(e) =>
+                  dispatch({ type: "SET_VOICE_INPUT_ENABLED", enabled: e.target.checked })
+                }
+              />
+              在输入框显示麦克风（听写进草稿，不自动发送）
+            </label>
+
+            <div style={{ marginTop: 10, fontSize: 12, color: tokens.textSecondary }}>
+              <label
+                style={{
+                  display: "flex",
+                  alignItems: "flex-start",
+                  gap: 8,
+                  marginBottom: 10,
+                  cursor: "pointer",
+                  fontSize: 12,
+                  lineHeight: 1.4,
+                }}
+              >
+                <input
+                  type="checkbox"
+                  style={{ marginTop: 2 }}
+                  checked={state.voiceRealtimeStreaming !== false}
+                  onChange={(e) =>
+                    dispatch({
+                      type: "SET_VOICE_REALTIME_STREAMING",
+                      enabled: e.target.checked,
+                      preferContinuous: e.target.checked,
+                    })
+                  }
+                />
+                <span>
+                  <strong>实时出字</strong>
+                  （字级 / 近实时）
+                  <br />
+                  <span style={{ color: tokens.textMuted, fontSize: 11 }}>
+                    浏览器听写：Web Speech 字级 interim。本机 Whisper（连续 + 本开关）：PCM
+                    流式上传 + 约 8s 窗口内渐进重解码假设（poll 按上次推断耗时自适应）；窗口结束定稿；非
+                    decoder token 流。开启时会切到连续听写。
+                  </span>
+                </span>
+              </label>
+              {state.voiceRealtimeStreaming !== false &&
+                state.voiceModel?.sttEngine === "local" && (
                   <div
-                    key={modelId}
                     style={{
-                      marginTop: isRecommended ? 8 : 6,
-                      padding: "8px 8px 6px",
+                      marginBottom: 10,
+                      padding: "6px 8px",
+                      fontSize: 11,
+                      lineHeight: 1.4,
+                      background: tokens.successSoft,
+                      border: `1px solid ${tokens.success}`,
                       borderRadius: 6,
-                      border: `1px solid ${tokens.border}`,
-                      background: isRecommended ? tokens.bgMuted : tokens.bgElevated,
+                      color: tokens.success,
                     }}
                   >
-                    <div
-                      style={{
-                        display: "flex",
-                        flexWrap: "wrap" as const,
-                        alignItems: "center",
-                        gap: 6,
-                        fontSize: 12,
-                      }}
-                    >
-                      <span style={{ fontWeight: isRecommended ? 600 : 500, color: tokens.text }}>
-                        {isRecommended ? `${RECOMMENDED_ROW_PREFIX}: ${modelId}` : modelId}
-                        {modelId === "large-v3-turbo" ? (
-                          <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
-                            仅终稿识别（无实时出字）；可能较慢，推荐先用 medium
-                          </div>
-                        ) : null}
-                        {isActive ? " · 活动" : ""}
-                      </span>
-                      <span style={{ width: "100%", fontSize: 10, color: tokens.textMuted }}>
-                        {whisperModelMetaLine(modelId)}
-                        {voiceModel?.modelPrewarm &&
-                        voiceModel.prewarmStatus === "fail" &&
-                        isActive
-                          ? " · 预热失败"
-                          : ""}
-                      </span>
-                      <span style={{ color: tokens.textMuted, fontSize: 11 }}>
-                        {pendingStart
-                          ? VOICE_STATUS_STARTING_DOWNLOAD
-                          : modelStatusLabel(status)}
-                        {typeof entry?.bytesOnDisk === "number" && entry.bytesOnDisk > 0
-                          ? ` · ${(entry.bytesOnDisk / (1024 * 1024)).toFixed(0)} MB`
-                          : ""}
-                      </span>
-                      <span style={{ flex: 1 }} />
-                      {downloading ? (
-                        <button
-                          type="button"
-                          style={styles.secondaryBtn}
-                          disabled={pendingStart}
-                          onClick={() => {
-                            clearVoiceErr()
-                            setVoicePendingDownload(null)
-                            sendVoice({ type: "voice.model.cancel", modelId })
-                          }}
-                        >
-                          {BTN_CANCEL}
-                        </button>
-                      ) : status === "ready" ? (
-                        <>
-                          {!isActive && (
-                            <button
-                              type="button"
-                              style={styles.secondaryBtn}
-                              onClick={() => {
-                                clearVoiceErr()
-                                sendVoice({ type: "voice.model.set_active", modelId })
-                              }}
-                            >
-                              {BTN_SET_ACTIVE}
-                            </button>
-                          )}
-                          <button
-                            type="button"
-                            style={styles.secondaryBtn}
-                            onClick={() => {
-                              clearVoiceErr()
-                              sendVoice({ type: "voice.model.delete", modelId })
-                            }}
-                          >
-                            {BTN_DELETE}
-                          </button>
-                        </>
-                      ) : (
-                        <button
-                          type="button"
-                          style={styles.secondaryBtn}
-                          onClick={() => {
-                            clearVoiceErr()
-                            setVoicePendingDownload(modelId)
-                            // Indeterminate bar until companion progress arrives.
-                            dispatch({
-                              type: "SET_VOICE_MODEL_PROGRESS",
-                              progress: {
-                                modelId,
-                                file: "",
-                                receivedBytes: 0,
-                                totalBytes: 0,
-                              },
-                            })
-                            sendVoice(
-                              { type: "voice.model.download", modelId },
-                              {
-                                onFail: () => {
-                                  setVoicePendingDownload(null)
-                                  dispatch({ type: "SET_VOICE_MODEL_PROGRESS", progress: null })
-                                },
-                              },
-                            )
-                          }}
-                        >
-                          {BTN_DOWNLOAD}
-                        </button>
-                      )}
-                    </div>
-                    {(pct !== null || pendingStart) && (
-                      <div style={{ marginTop: 6 }}>
-                        <div
-                          style={{
-                            height: 6,
-                            borderRadius: 3,
-                            background: tokens.border,
-                            overflow: "hidden",
-                          }}
-                        >
-                          <div
-                            style={{
-                              height: "100%",
-                              width: pendingStart
-                                ? "18%"
-                                : `${pct ?? 0}%`,
-                              background: tokens.accent,
-                              transition: "width 0.2s ease",
-                              // Soft pulse while waiting for first progress bytes.
-                              opacity: pendingStart ? 0.65 : 1,
-                            }}
-                          />
-                        </div>
-                        <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
-                          {pendingStart
-                            ? VOICE_STATUS_STARTING_DOWNLOAD
-                            : `${progress?.file ? `${progress.file} · ` : ""}${pct ?? 0}%`}
-                        </div>
-                      </div>
-                    )}
-                    {entry?.error && (
-                      <div style={{ fontSize: 11, color: tokens.danger, marginTop: 4 }}>
-                        {modelProbeErrorLabel(entry.error) || entry.error}
-                      </div>
-                    )}
+                    本机渐进假设流已开：说话中显示临时字，约每 8s
+                    定稿一段；poll 随模型耗时自适应（medium 可能更慢）。更丝滑可改用浏览器听写。
                   </div>
+                )}
+              <div style={{ marginBottom: 4, fontWeight: 500 }}>听写形态</div>
+              <label style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4, cursor: "pointer" }}>
+                <input
+                  type="radio"
+                  name="voiceDictationMode"
+                  checked={(state.voiceDictationMode || "classic") === "classic"}
+                  onChange={() =>
+                    dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: "classic" })
+                  }
+                />
+                经典短听（默认 · 最长约 45 秒）
+              </label>
+              <label style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
+                <input
+                  type="radio"
+                  name="voiceDictationMode"
+                  checked={state.voiceDictationMode === "continuous"}
+                  onChange={() =>
+                    dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: "continuous" })
+                  }
+                />
+                连续听写（可选 · 最长默认 15 分钟）
+              </label>
+              <div style={{ marginTop: 4, fontSize: 11, color: tokens.textMuted, lineHeight: 1.4 }}>
+                浏览器：自动续听 + 字级 interim；本机：实时出字开时约 8 秒一段，否则约 45
+                秒一段。仅进草稿、不自动发送。首次连续听写需隐私 v3。
+              </div>
+              <label
+                style={{
+                  display: "flex",
+                  alignItems: "flex-start",
+                  gap: 8,
+                  marginTop: 10,
+                  cursor: "pointer",
+                  fontSize: 12,
+                  lineHeight: 1.4,
+                }}
+              >
+                <input
+                  type="checkbox"
+                  style={{ marginTop: 2 }}
+                  checked={state.asrRefinerEnabled === true}
+                  onChange={(e) =>
+                    dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: e.target.checked })
+                  }
+                />
+                <span>
+                  <strong>ASR 纠错</strong>
+                  （停后可选；默认关）
+                  <br />
+                  <span style={{ color: tokens.textMuted, fontSize: 11 }}>
+                    将把<strong>转写文本</strong>发给当前 Companion 模型做极保守纠错（不润色、不自动发送）；需已配置
+                    LLM。首次听写前若未确认隐私 v3 将弹出说明。当前模型：
+                    {state.companionConfig?.model_name || "（未连接/未配置）"}
+                  </span>
+                </span>
+              </label>
+
+              <div style={{ marginTop: 12, fontSize: 12, color: tokens.textSecondary }}>
+                <div style={{ marginBottom: 4, fontWeight: 500 }}>按住热键听写（D2 · 默认关）</div>
+                <label
+                  style={{
+                    display: "flex",
+                    alignItems: "flex-start",
+                    gap: 8,
+                    cursor: "pointer",
+                    fontSize: 12,
+                    lineHeight: 1.4,
+                  }}
+                >
+                  <input
+                    type="checkbox"
+                    style={{ marginTop: 2 }}
+                    checked={state.dictationHotkeyEnabled === true}
+                    onChange={(e) =>
+                      dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: e.target.checked })
+                    }
+                  />
+                  <span>
+                    启用按住说话
+                    <br />
+                    <span style={{ color: tokens.textMuted, fontSize: 11 }}>
+                      按住 ≥300ms 松手转写；短按静默丢弃。300ms 内连按两次进入锁定（再按或 Esc 结束）。仅进草稿、不自动发送。需 Side Panel
+                      打开；页面可编辑框内同一热键会插入到该框。禁止 bare Fn / Win+V。会议录音中不可用。默认关。
+                    </span>
+                  </span>
+                </label>
+                <div style={{ marginTop: 8, fontSize: 11, color: tokens.textSecondary }}>
+                  <div style={{ marginBottom: 2 }}>组合键（按键盘录制或点预设）</div>
+                  <HotkeyCaptureField
+                    value={state.dictationHotkeyChord || DICTATION_HOTKEY_DEFAULT_CHORD}
+                    disabled={!state.dictationHotkeyEnabled}
+                    onChange={(chord) =>
+                      dispatch({ type: "SET_DICTATION_HOTKEY_CHORD", chord })
+                    }
+                  />
+                </div>
+                <label style={{ display: "flex", gap: 8, marginTop: 8, fontSize: 12, cursor: "pointer" }}>
+                  <input
+                    type="checkbox"
+                    checked={state.voiceSoundEffects !== false}
+                    onChange={(e) =>
+                      dispatch({ type: "SET_VOICE_SOUND_EFFECTS", enabled: e.target.checked })
+                    }
+                  />
+                  听写状态音效（开始/停止/完成；误触静默）
+                </label>
+              </div>
+            </div>
+
+            {/* Path B M0: 听写方式 progressive disclosure (UI draft until ready + enable) */}
+            {(() => {
+              const voiceModel = state.voiceModel
+              const progress = state.voiceModelProgress
+              const committedLocal = voiceModel?.sttEngine === "local"
+              const committedSystem = voiceModel?.sttEngine === "system"
+              const showLocalPanel = engineDraft === "local"
+              // #259: system option only exists on win32 with the probe mirror.
+              const systemStateMirror = state.voiceSystemState
+              const systemProbeWin32 = systemStateMirror?.platform === "win32"
+              const systemProbeGreen =
+                systemProbeWin32 &&
+                systemStateMirror?.helper?.ok === true &&
+                systemStateMirror?.systemSpeech?.available === true
+              const showSystemPanel = engineDraft === "system"
+              const clearVoiceErr = () =>
+                dispatch({ type: "SET_VOICE_MODEL_ERROR", error: null })
+              /** settings → SW → WS; always surface SW refusals into voiceModelError. */
+              const sendVoice = (
+                msg: Record<string, unknown>,
+                opts?: { onOk?: () => void; onFail?: () => void },
+              ) => {
+                try {
+                  chrome.runtime.sendMessage({ ...msg, source: "settings" }, (resp: unknown) => {
+                    const lastErr =
+                      typeof chrome.runtime.lastError?.message === "string"
+                        ? chrome.runtime.lastError.message
+                        : null
+                    const parsed = parseVoiceSettingsSendResponse(resp, lastErr)
+                    if (parsed.ok === false) {
+                      opts?.onFail?.()
+                      dispatch({ type: "SET_VOICE_MODEL_ERROR", error: parsed.error })
+                      return
+                    }
+                    opts?.onOk?.()
+                  })
+                } catch (e: unknown) {
+                  opts?.onFail?.()
+                  const msgText = e instanceof Error ? e.message : String(e)
+                  dispatch({
+                    type: "SET_VOICE_MODEL_ERROR",
+                    error: msgText || VOICE_ERR_STATE_TIMEOUT,
+                  })
+                }
+              }
+              const recommendedId = RECOMMENDED_WHISPER_MODEL_ID
+              const activeId = voiceModel?.localModelId || recommendedId
+              const recEntry = voiceModel?.models?.[recommendedId]
+              const recReady = recEntry?.status === "ready"
+              const activeReady = voiceModel?.models?.[activeId]?.status === "ready"
+              const canEnableLocal = recReady || activeReady
+              const privacyEngine: "browser" | "local" | "system" =
+                engineDraft === "local" || committedLocal
+                  ? "local"
+                  : engineDraft === "system" || committedSystem
+                    ? "system"
+                    : "browser"
+
+              /** Persist 模型下载源 via voice.model.set_prefs; store mirror re-drives input on ok. */
+              const saveVoiceEndpoint = () => {
+                const value = (voiceEndpointDraft ?? "").trim()
+                clearVoiceErr()
+                sendVoice(
+                  { type: "voice.model.set_prefs", modelDownloadEndpoint: value },
+                  { onOk: () => setVoiceEndpointDraft(null) },
                 )
               }
 
-              return (
-                <>
-                  <div style={{ marginTop: 12 }}>
-                    <div style={{ ...styles.label, marginBottom: 6 }}>{ENGINE_SECTION_LABEL}</div>
-                    <label
-                      style={{
-                        display: "flex",
-                        alignItems: "flex-start",
-                        gap: 8,
-                        cursor: "pointer",
-                        fontSize: 13,
-                        marginBottom: 6,
-                      }}
-                    >
-                      <input
-                        type="radio"
-                        name="voice-stt-engine"
-                        checked={engineDraft === "browser"}
-                        onChange={() => {
-                          setEngineDraft("browser")
-                          if (committedLocal || committedSystem) {
-                            clearVoiceErr()
-                            sendVoice({ type: "voice.model.set_engine", engine: "browser" })
-                          }
+              const renderModelRow = (modelId: WhisperSettingsModelId, isRecommended: boolean) => {
+                const entry = voiceModel?.models?.[modelId]
+                const status = entry?.status || "absent"
+                const pendingStart = voicePendingDownload === modelId
+                const downloading =
+                  status === "downloading" ||
+                  pendingStart ||
+                  (progress?.modelId === modelId && status !== "ready")
+                const pct = pendingStart
+                  ? 0
+                  : downloading && progress?.modelId === modelId
+                    ? progressPercent(progress.receivedBytes, progress.totalBytes)
+                    : null
+                const isActive = committedLocal && activeId === modelId
+                return (
+                  <div
+                    key={modelId}
+                    style={{
+                      marginTop: isRecommended ? 8 : 6,
+                      padding: "8px 8px 6px",
+                      borderRadius: 6,
+                      border: `1px solid ${tokens.border}`,
+                      background: isRecommended ? tokens.bgMuted : tokens.bgElevated,
+                    }}
+                  >
+                    <div
+                      style={{
+                        display: "flex",
+                        flexWrap: "wrap" as const,
+                        alignItems: "center",
+                        gap: 6,
+                        fontSize: 12,
+                      }}
+                    >
+                      <span style={{ fontWeight: isRecommended ? 600 : 500, color: tokens.text }}>
+                        {isRecommended ? `${RECOMMENDED_ROW_PREFIX}: ${modelId}` : modelId}
+                        {modelId === "large-v3-turbo" ? (
+                          <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
+                            仅终稿识别（无实时出字）；可能较慢，推荐先用 medium
+                          </div>
+                        ) : null}
+                        {isActive ? " · 活动" : ""}
+                      </span>
+                      <span style={{ width: "100%", fontSize: 10, color: tokens.textMuted }}>
+                        {whisperModelMetaLine(modelId)}
+                        {voiceModel?.modelPrewarm &&
+                        voiceModel.prewarmStatus === "fail" &&
+                        isActive
+                          ? " · 预热失败"
+                          : ""}
+                      </span>
+                      <span style={{ color: tokens.textMuted, fontSize: 11 }}>
+                        {pendingStart
+                          ? VOICE_STATUS_STARTING_DOWNLOAD
+                          : modelStatusLabel(status)}
+                        {typeof entry?.bytesOnDisk === "number" && entry.bytesOnDisk > 0
+                          ? ` · ${(entry.bytesOnDisk / (1024 * 1024)).toFixed(0)} MB`
+                          : ""}
+                      </span>
+                      <span style={{ flex: 1 }} />
+                      {downloading ? (
+                        <button
+                          type="button"
+                          style={styles.secondaryBtn}
+                          disabled={pendingStart}
+                          onClick={() => {
+                            clearVoiceErr()
+                            setVoicePendingDownload(null)
+                            sendVoice({ type: "voice.model.cancel", modelId })
+                          }}
+                        >
+                          {BTN_CANCEL}
+                        </button>
+                      ) : status === "ready" ? (
+                        <>
+                          {!isActive && (
+                            <button
+                              type="button"
+                              style={styles.secondaryBtn}
+                              onClick={() => {
+                                clearVoiceErr()
+                                sendVoice({ type: "voice.model.set_active", modelId })
+                              }}
+                            >
+                              {BTN_SET_ACTIVE}
+                            </button>
+                          )}
+                          <button
+                            type="button"
+                            style={styles.secondaryBtn}
+                            onClick={() => {
+                              clearVoiceErr()
+                              sendVoice({ type: "voice.model.delete", modelId })
+                            }}
+                          >
+                            {BTN_DELETE}
+                          </button>
+                        </>
+                      ) : (
+                        <button
+                          type="button"
+                          style={styles.secondaryBtn}
+                          onClick={() => {
+                            clearVoiceErr()
+                            setVoicePendingDownload(modelId)
+                            // Indeterminate bar until companion progress arrives.
+                            dispatch({
+                              type: "SET_VOICE_MODEL_PROGRESS",
+                              progress: {
+                                modelId,
+                                file: "",
+                                receivedBytes: 0,
+                                totalBytes: 0,
+                              },
+                            })
+                            sendVoice(
+                              { type: "voice.model.download", modelId },
+                              {
+                                onFail: () => {
+                                  setVoicePendingDownload(null)
+                                  dispatch({ type: "SET_VOICE_MODEL_PROGRESS", progress: null })
+                                },
+                              },
+                            )
+                          }}
+                        >
+                          {BTN_DOWNLOAD}
+                        </button>
+                      )}
+                    </div>
+                    {(pct !== null || pendingStart) && (
+                      <div style={{ marginTop: 6 }}>
+                        <div
+                          style={{
+                            height: 6,
+                            borderRadius: 3,
+                            background: tokens.border,
+                            overflow: "hidden",
+                          }}
+                        >
+                          <div
+                            style={{
+                              height: "100%",
+                              width: pendingStart
+                                ? "18%"
+                                : `${pct ?? 0}%`,
+                              background: tokens.accent,
+                              transition: "width 0.2s ease",
+                              // Soft pulse while waiting for first progress bytes.
+                              opacity: pendingStart ? 0.65 : 1,
+                            }}
+                          />
+                        </div>
+                        <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
+                          {pendingStart
+                            ? VOICE_STATUS_STARTING_DOWNLOAD
+                            : `${progress?.file ? `${progress.file} · ` : ""}${pct ?? 0}%`}
+                        </div>
+                      </div>
+                    )}
+                    {entry?.error && (
+                      <div style={{ fontSize: 11, color: tokens.danger, marginTop: 4 }}>
+                        {modelProbeErrorLabel(entry.error) || entry.error}
+                      </div>
+                    )}
+                  </div>
+                )
+              }
+
+              return (
+                <>
+                  <div style={{ marginTop: 12 }}>
+                    <div style={{ ...styles.label, marginBottom: 6 }}>{ENGINE_SECTION_LABEL}</div>
+                    <label
+                      style={{
+                        display: "flex",
+                        alignItems: "flex-start",
+                        gap: 8,
+                        cursor: "pointer",
+                        fontSize: 13,
+                        marginBottom: 6,
+                      }}
+                    >
+                      <input
+                        type="radio"
+                        name="voice-stt-engine"
+                        checked={engineDraft === "browser"}
+                        onChange={() => {
+                          setEngineDraft("browser")
+                          if (committedLocal || committedSystem) {
+                            clearVoiceErr()
+                            sendVoice({ type: "voice.model.set_engine", engine: "browser" })
+                          }
                         }}
                         style={{ marginTop: 2 }}
                       />
                       <span>
                         <span style={{ fontWeight: 500 }}>{ENGINE_BROWSER_LABEL}</span>
@@ -2143,515 +2457,100 @@ export function SettingsSlideout() {
                               {BTN_DOWNLOAD}
                             </button>
                           )}
                         </div>
                         {(pct !== null || diarizePending) && (
-                          <div style={{ marginTop: 6 }}>
-                            <div
-                              style={{
-                                height: 6,
-                                borderRadius: 3,
-                                background: tokens.border,
-                                overflow: "hidden",
-                              }}
-                            >
-                              <div
-                                style={{
-                                  height: "100%",
-                                  width: diarizePending ? "18%" : `${pct ?? 0}%`,
-                                  background: tokens.accent,
-                                  transition: "width 0.2s ease",
-                                  opacity: diarizePending ? 0.65 : 1,
-                                }}
-                              />
-                            </div>
-                            <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
-                              {diarizePending
-                                ? VOICE_STATUS_STARTING_DOWNLOAD
-                                : `${progress?.file ? `${progress.file} · ` : ""}${pct ?? 0}%`}
-                            </div>
-                          </div>
-                        )}
-                        {entry?.error && (
-                          <div style={{ fontSize: 11, color: tokens.danger, marginTop: 4 }}>
-                            {modelProbeErrorLabel(entry.error) || entry.error}
-                          </div>
-                        )}
-                        <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 4, lineHeight: 1.45 }}>
-                          会议「自动标说话人」用：本机 ONNX 说话人嵌入聚类，音频不出本机；只标「发言人N」，非身份识别。与转写模型共享磁盘预算；下载后无需切换引擎。
-                        </div>
-                      </div>
-                    )
-                  })()}
-
-                  <p style={{ fontSize: 11, color: tokens.textMuted, margin: "8px 0 0", lineHeight: 1.45 }}>
-                    {privacyCopyForEngine(privacyEngine)}
-                  </p>
-
-                  {state.voiceModelError && (
-                    <div style={{ ...styles.helpText, color: tokens.danger, marginTop: 4 }}>
-                      {modelProbeErrorLabel(state.voiceModelError) || state.voiceModelError}
-                    </div>
-                  )}
-                </>
-              )
-            })()}
-
-            {state.voicePrivacyAckV1 && (
-              <button
-                type="button"
-                style={{
-                  marginTop: 6,
-                  fontSize: 11,
-                  border: "none",
-                  background: "transparent",
-                  color: tokens.textMuted,
-                  cursor: "pointer",
-                  padding: 0,
-                  textDecoration: "underline",
-                }}
-                onClick={() => dispatch({ type: "SET_VOICE_PRIVACY_ACK_V1", ack: false })}
-              >
-                重置隐私确认（下次听写将再次提示）
-              </button>
-            )}
-          </div>
-
-          <div style={styles.field}>
-            <label style={styles.label}>Context Window</label>
-            <input
-              style={styles.input}
-              type="number"
-              value={config.context_window}
-              onChange={e => dispatch({ type: "SET_CONFIG", config: { context_window: parseInt(e.target.value) || 512000 } })}
-              min={1024}
-              max={1000000}
-              step={1024}
-            />
-            <div style={styles.helpText}>
-              {contextWindowHelpText(config.context_window)}
-            </div>
-          </div>
-
-          <div style={styles.field}>
-            <label style={styles.label}>长对话上下文预算</label>
-            <select
-              style={styles.select || styles.input}
-              value={config.context_compaction ?? "auto"}
-              onChange={e => {
-                const v = e.target.value
-                if (v !== "auto" && v !== "prompt" && v !== "off") return
-                if (v === "auto") {
-                  const ok = window.confirm(
-                    "自动压缩会让模型看不到较早轮次，即使聊天区仍显示全文。确定启用？",
-                  )
-                  if (!ok) return
-                }
-                dispatch({ type: "SET_CONFIG", config: { context_compaction: v } })
-              }}
-            >
-              <option value="auto">自动压缩（超预算时）</option>
-              <option value="prompt">仅提示（不压缩）</option>
-              <option value="off">关闭</option>
-            </select>
-            <div style={styles.helpText}>
-              仅影响发给模型的请求；磁盘与界面消息仍完整。仅提示 = 超预算时警告，需改回「自动」才压缩。
-            </div>
-          </div>
-
-          {(config.context_compaction ?? "auto") === "auto" && (
-            <div style={styles.field}>
-              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
-                <input
-                  type="checkbox"
-                  checked={config.context_compaction_m2 !== false}
-                  onChange={e =>
-                    dispatch({
-                      type: "SET_CONFIG",
-                      config: { context_compaction_m2: e.target.checked },
-                    })
-                  }
-                />
-                结构化工作记忆（H1）/ 滚动摘要
-              </label>
-              <div style={styles.helpText}>
-                默认开启：丢弃轮次较多时，优先生成脱敏的结构化工作记忆（目标/决策/约束/待办/产物），
-                失败则退回散文摘要；可在聊天顶栏「查看摘要」。仅在本轮开始时跑（tool 中途只做截断占位）。
-              </div>
-            </div>
-          )}
-
-          <div style={styles.field}>
-            <label style={styles.label}>思考过程展示</label>
-            <select
-              style={styles.input}
-              value={state.showReasoningMode || "auto_live"}
-              onChange={(e) => {
-                const v = e.target.value
-                if (v === "always_collapsed" || v === "auto_live" || v === "always_open") {
-                  dispatch({ type: "SET_SHOW_REASONING_MODE", mode: v })
-                }
-              }}
-            >
-              <option value="auto_live">仅推理时展开（默认）</option>
-              <option value="always_collapsed">默认折叠</option>
-              <option value="always_open">始终展开</option>
-            </select>
-            <div style={styles.helpText}>
-              仅影响 Side Panel 显示。历史消息不会把思考回灌给模型（省 token / 兼容 Anthropic）。
-            </div>
-          </div>
-
-          <div style={styles.field}>
-            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
-              <input
-                type="checkbox"
-                checked={state.exportIncludeReasoning === true}
-                onChange={(e) =>
-                  dispatch({ type: "SET_EXPORT_INCLUDE_REASONING", enabled: e.target.checked })
-                }
-              />
-              导出 Markdown 时包含思考过程
-            </label>
-            <div style={styles.helpText}>
-              默认关闭。开启后以折叠块写入笔记；请注意思考可能含中间假设，勿默认分享。
-            </div>
-          </div>
-
-                    {/* --- Vision Model Settings --- */}
-          <div style={styles.sectionTitle}>视觉模型（看图描述）</div>
-
-          <div style={styles.field}>
-            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
-              <input
-                type="checkbox"
-                checked={config.vision_enabled || false}
-                onChange={e => {
-                  const on = e.target.checked
-                  dispatch({ type: "SET_CONFIG", config: { vision_enabled: on } })
-                  setVisionReuseHint(null)
-                  if (!on) {
-                    setVisionReuseBanner(false)
-                    return
-                  }
-                  // Banner only on false→true; never auto-copy credentials (S-V5)
-                  if (
-                    !visionReuseBannerDismissed &&
-                    shouldOfferVisionReuse({
-                      model_name: config.model_name,
-                      base_url: config.base_url,
-                      api_key: config.api_key,
-                      protocol: config.protocol,
-                    })
-                  ) {
-                    setVisionReuseBanner(true)
-                  } else {
-                    setVisionReuseBanner(false)
-                  }
-                }}
-              />
-              启用截图视觉分析
-            </label>
-            <div style={styles.helpText}>{VISION_COPY.sectionHelp}</div>
-            <div style={{ ...styles.helpText, marginTop: 4 }}>{VISION_COPY.railDifferentiator}</div>
-          </div>
-
-          {config.vision_enabled && (config.protocol === "anthropic") && (
-            <div style={{
-              ...styles.field,
-              padding: "8px 10px",
-              borderRadius: 8,
-              background: tokens.warningSoft,
-              border: `1px solid ${tokens.warning}`,
-              fontSize: 12,
-              color: tokens.text,
-            }}>
-              {VISION_COPY.anthropicBlocked}
-            </div>
-          )}
-
-          {config.vision_enabled && visionReuseBanner && (
-            <div style={{
-              ...styles.field,
-              padding: "10px 12px",
-              borderRadius: 8,
-              background: tokens.accentSoft,
-              border: `1px solid ${tokens.border}`,
-            }}>
-              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{VISION_COPY.bannerTitle}</div>
-              <div style={{ fontSize: 12, color: tokens.textSecondary, marginBottom: 8, lineHeight: 1.45 }}>
-                {bannerBodyForHost(extractHostname(config.base_url))}
-              </div>
-              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
-                <button
-                  type="button"
-                  style={styles.testBtn}
-                  onClick={() => {
-                    const main = {
-                      model_name: config.model_name,
-                      base_url: config.base_url,
-                      api_key: config.api_key,
-                      protocol: config.protocol,
-                    }
-                    if (isCustomVisionConfig(main, config)) {
-                      if (!window.confirm(VISION_COPY.overwriteConfirm)) return
-                    }
-                    const result = applyVisionReuseFromMain(main)
-                    dispatch({ type: "SET_CONFIG", config: result.patch })
-                    setVisionReuseBanner(false)
-                    setVisionReuseBannerDismissed(true)
-                    setVisionAdvancedOpen(false)
-                    setVisionReuseHint(
-                      (result.needsKeyPaste ? VISION_COPY.needsKeyPaste + " " : "") +
-                        VISION_COPY.postReuseTestHint,
-                    )
-                  }}
-                >
-                  {VISION_COPY.useMain}
-                </button>
-                <button
-                  type="button"
-                  style={styles.toggleBtn}
-                  onClick={() => {
-                    setVisionReuseBanner(false)
-                    setVisionReuseBannerDismissed(true)
-                    setVisionAdvancedOpen(true)
-                  }}
-                >
-                  {VISION_COPY.keepSeparate}
-                </button>
-              </div>
-            </div>
-          )}
-
-          {config.vision_enabled && visionReuseHint && (
-            <div style={{ ...styles.helpText, color: tokens.success, marginBottom: 8 }}>
-              {visionReuseHint}
-            </div>
-          )}
-
-          {config.vision_enabled && (() => {
-            const reusing = isVisionReusingMain(
-              { model_name: config.model_name, base_url: config.base_url },
-              config,
-            )
-            const showFields = !reusing || visionAdvancedOpen
-            return (
-              <>
-                {reusing && (
-                  <div style={{
-                    display: "flex",
-                    alignItems: "center",
-                    gap: 8,
-                    flexWrap: "wrap",
-                    marginBottom: 8,
-                    fontSize: 12,
-                  }}>
-                    <span style={{
-                      padding: "2px 8px",
-                      borderRadius: 8,
-                      background: tokens.successSoft,
-                      color: tokens.success,
-                      fontWeight: 500,
-                    }}>
-                      {VISION_COPY.reusedChip} · {extractHostname(config.vision_base_url || config.base_url)}
-                    </span>
-                    <button
-                      type="button"
-                      style={styles.toggleBtn}
-                      onClick={() => setVisionAdvancedOpen(v => !v)}
-                    >
-                      {visionAdvancedOpen ? VISION_COPY.collapseAdvanced : VISION_COPY.expandAdvanced}
-                    </button>
-                  </div>
-                )}
-
-                {showFields && (
-                  <>
-              <div style={styles.field}>
-                <label style={styles.label}>
-                  API Key{" "}
-                  {!config.vision_api_key && state.companionConfig?.vision_api_key_set && (
-                    <span style={{
-                      fontSize: 10, fontWeight: 500, marginLeft: 6,
-                      padding: "1px 6px", borderRadius: 8,
-                      color: tokens.success, background: tokens.successSoft,
-                    }}>
-                      ✓ 已配置
-                    </span>
-                  )}
-                </label>
-                <div style={{ display: "flex", gap: 6 }}>
-                  <input
-                    style={{ ...styles.input, flex: 1 }}
-                    type={showKey ? "text" : "password"}
-                    value={config.vision_api_key || ""}
-                    onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_api_key: e.target.value } })}
-                    placeholder={
-                      state.companionConfig?.vision_api_key_set
-                        ? "（已配置，留空保持不变；输入新值覆盖）"
-                        : "本地 Ollama 可留空；云端需填写（或与主模型相同后保存继承）"
-                    }
-                  />
-                </div>
-                <div style={styles.helpText}>
-                  本地 loopback 可留空；非本机端点需真实 Key。与主模型 URL/Model 相同时，保存会继承主 Key。
-                </div>
-              </div>
-
-              <div style={styles.field}>
-                <label style={styles.label}>Base URL</label>
-                <input
-                  style={styles.input}
-                  type="text"
-                  value={config.vision_base_url || "http://localhost:11434/v1"}
-                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_base_url: e.target.value } })}
-                  placeholder="http://localhost:11434/v1 或云端 OpenAI 兼容端点"
-                />
-              </div>
-
-              <div style={styles.field}>
-                <label style={styles.label}>Model</label>
-                <input
-                  style={styles.input}
-                  list="vision-model-options"
-                  type="text"
-                  value={config.vision_model_name || ""}
-                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_model_name: e.target.value } })}
-                  placeholder="输入模型名称或从列表选择"
-                />
-                <datalist id="vision-model-options">
-                  <option value="llava:7b" />
-                  <option value="llava:13b" />
-                  <option value="minicpm-v" />
-                  <option value="qwen2.5vl:3b" />
-                  <option value="moondream2" />
-                  <option value="gpt-4o" />
-                  <option value="glm-4.6v" />
-                </datalist>
-              </div>
-
-              <div style={styles.field}>
-                <label style={styles.label}>
-                  超时时间: {Math.round((config.vision_timeout_ms || 30000) / 1000)}s
-                </label>
-                <input
-                  style={{ width: "100%" }}
-                  type="range"
-                  min={10000}
-                  max={60000}
-                  step={5000}
-                  value={config.vision_timeout_ms || 30000}
-                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_timeout_ms: parseInt(e.target.value) } })}
-                />
-              </div>
-
-              <div style={styles.field}>
-                <label style={styles.label}>降级策略</label>
-                <select
-                  style={styles.select}
-                  value={config.vision_fallback || "metadata"}
-                  onChange={e => dispatch({ type: "SET_CONFIG", config: { vision_fallback: e.target.value as "metadata" | "passthrough" | "error" } })}
-                >
-                  <option value="metadata">{VISION_COPY.fallbackMetadata}</option>
-                  <option value="passthrough">{VISION_COPY.fallbackPassthrough}</option>
-                  <option value="error">{VISION_COPY.fallbackError}</option>
-                </select>
-                <div style={styles.helpText}>
-                  视觉模型不可用时的处理方式：仅元数据 = 发送页面标题和尺寸信息
-                </div>
-              </div>
-                  </>
-                )}
-
-              <div style={styles.field}>
-                <button style={styles.testBtn} onClick={() => {
-                  dispatch({ type: "SET_TEST_RESULT", result: "测试视觉模型连接中...（请先保存配置）" })
-                  chrome.runtime.sendMessage({ type: "config.testVision" })
-                }}>
-                  测试视觉模型连接
-                </button>
-              </div>
-              </>
-            )
-          })()}
-
-                    {/* --- File Upload Settings --- */}
-          <div style={styles.sectionTitle}>文件上传</div>
+                          <div style={{ marginTop: 6 }}>
+                            <div
+                              style={{
+                                height: 6,
+                                borderRadius: 3,
+                                background: tokens.border,
+                                overflow: "hidden",
+                              }}
+                            >
+                              <div
+                                style={{
+                                  height: "100%",
+                                  width: diarizePending ? "18%" : `${pct ?? 0}%`,
+                                  background: tokens.accent,
+                                  transition: "width 0.2s ease",
+                                  opacity: diarizePending ? 0.65 : 1,
+                                }}
+                              />
+                            </div>
+                            <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 2 }}>
+                              {diarizePending
+                                ? VOICE_STATUS_STARTING_DOWNLOAD
+                                : `${progress?.file ? `${progress.file} · ` : ""}${pct ?? 0}%`}
+                            </div>
+                          </div>
+                        )}
+                        {entry?.error && (
+                          <div style={{ fontSize: 11, color: tokens.danger, marginTop: 4 }}>
+                            {modelProbeErrorLabel(entry.error) || entry.error}
+                          </div>
+                        )}
+                        <div style={{ fontSize: 10, color: tokens.textMuted, marginTop: 4, lineHeight: 1.45 }}>
+                          会议「自动标说话人」用：本机 ONNX 说话人嵌入聚类，音频不出本机；只标「发言人N」，非身份识别。与转写模型共享磁盘预算；下载后无需切换引擎。
+                        </div>
+                      </div>
+                    )
+                  })()}
 
-          <div style={styles.field}>
-            <label style={styles.label}>最大文件大小: {((config.file_upload_max_size ?? 10485760) / (1024 * 1024)).toFixed(0)} MB</label>
-            <input
-              style={{ width: "100%" }}
-              type="range"
-              min={1}
-              max={100}
-              step={1}
-              value={(config.file_upload_max_size ?? 10485760) / (1024 * 1024)}
-              onChange={e => dispatch({ type: "SET_CONFIG", config: { file_upload_max_size: parseInt(e.target.value) * 1024 * 1024 } })}
-            />
-            <div style={styles.helpText}>
-              上传文件的大小上限，范围 1–100 MB。此上限不提高图片预算（压缩后单张 ≤4MB，合计 ≤6MB）。
-            </div>
-          </div>
+                  <p style={{ fontSize: 11, color: tokens.textMuted, margin: "8px 0 0", lineHeight: 1.45 }}>
+                    {privacyCopyForEngine(privacyEngine)}
+                  </p>
 
-          <div style={styles.field}>
-            <label style={styles.label}>最大 Token 数</label>
-            <input
-              style={styles.input}
-              type="number"
-              value={config.file_upload_max_tokens ?? 50000}
-              onChange={e => dispatch({ type: "SET_CONFIG", config: { file_upload_max_tokens: parseInt(e.target.value) || 50000 } })}
-              min={1000}
-              max={200000}
-              step={1000}
-            />
-            <div style={styles.helpText}>
-              文件内容截断阈值，范围 1000–200000
-            </div>
-          </div>
+                  {state.voiceModelError && (
+                    <div style={{ ...styles.helpText, color: tokens.danger, marginTop: 4 }}>
+                      {modelProbeErrorLabel(state.voiceModelError) || state.voiceModelError}
+                    </div>
+                  )}
+                </>
+              )
+            })()}
 
-          <div style={styles.field}>
-            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
-              <input
-                type="checkbox"
-                checked={config.file_upload_vision ?? true}
-                onChange={e => dispatch({ type: "SET_CONFIG", config: { file_upload_vision: e.target.checked } })}
-              />
-              启用文件视觉分析
-            </label>
-            <div style={styles.helpText}>
-              仅当主模型不能看图时，用户附图才走视觉轨。主模型能看图时此开关不影响粘贴/选/拖。
-            </div>
+            {state.voicePrivacyAckV1 && (
+              <button
+                type="button"
+                style={{
+                  marginTop: 6,
+                  fontSize: 11,
+                  border: "none",
+                  background: "transparent",
+                  color: tokens.textMuted,
+                  cursor: "pointer",
+                  padding: 0,
+                  textDecoration: "underline",
+                }}
+                onClick={() => dispatch({ type: "SET_VOICE_PRIVACY_ACK_V1", ack: false })}
+              >
+                重置隐私确认（下次听写将再次提示）
+              </button>
+            )}
           </div>
 
-              <div style={styles.field}>
-                <div style={styles.helpText}>
-                  上下文窗口过大时，长对话压缩会来不及触发（新默认 512000 是 Agent 工作预算）。建议按模型真实上限设置。
-                </div>
-              </div>
-            </SettingsSection>
+            </SettingsPage>
           </div>
 
-          <div style={{ order: 3 }}>
-            <SettingsSection
+          <div data-settings-page="secrets" hidden={activeSettingsPage !== "secrets"}>
+            <SettingsPage
               title="密钥与环境"
-              open={isSectionOpen("secrets")}
-              onToggle={() => handleToggleSection("secrets")}
+              id="secrets"
             >
           {/* --- User env / Secrets (ADR-019) — independent of bottom config Save --- */}
           <UserEnvSection />
 
           
-            </SettingsSection>
+            </SettingsPage>
           </div>
 
-          <div style={{ order: 4 }}>
-            <SettingsSection
+          <div data-settings-page="security" hidden={activeSettingsPage !== "security"}>
+            <SettingsPage
               title="安全与信任"
-              open={isSectionOpen("security")}
-              onToggle={() => handleToggleSection("security")}
+              id="security"
               badge={elevatedTrust ? (
                 <span style={{
                   fontSize: 10,
                   fontWeight: 600,
                   padding: "1px 6px",
@@ -3262,18 +3161,17 @@ export function SettingsSlideout() {
               </button>
             )}
           </div>
 
           
-            </SettingsSection>
+            </SettingsPage>
           </div>
 
-          <div style={{ order: 5 }}>
-            <SettingsSection
-              title="本机与集成"
-              open={isSectionOpen("integrations")}
-              onToggle={() => handleToggleSection("integrations")}
+          <div data-settings-page="integrations" hidden={activeSettingsPage !== "integrations"}>
+            <SettingsPage
+              title="本机与工具"
+              id="integrations"
             >
           {/* --- How permissions work --- */}
           <div style={styles.field}>
             <div style={styles.helpText}>三道门互不替代，请勿混淆：</div>
             <ul
@@ -3290,11 +3188,11 @@ export function SettingsSlideout() {
               </li>
               <li>
                 <strong>本机能力</strong>（场景页）：工作区 / 扫描 / 命令等电源是否启用。
               </li>
               <li>
-                <strong>运行自主度</strong>（下方）：危险操作要不要每次确认；
+                <strong>运行自主度</strong>（「安全与信任」）：危险操作要不要每次确认；
                 <em>不会</em>放开场景已关掉的工具，也<strong>不能</strong>代替选工作区。
               </li>
             </ul>
             <div style={{ ...styles.helpText, marginTop: 8 }}>
               若工具提示「需要先绑定工作区」，请去场景页选文件夹，而不是开协议解锁或巡航。
@@ -3407,75 +3305,67 @@ export function SettingsSlideout() {
               })
             }}
           />
 
           
-            </SettingsSection>
+            </SettingsPage>
           </div>
 
-          <div style={{ order: 6 }}>
-            <SettingsSection
-              title="导出与集成"
-              open={isSectionOpen("export")}
-              onToggle={() => handleToggleSection("export")}
+          <div data-settings-page="export" hidden={activeSettingsPage !== "export"}>
+            <SettingsPage
+              title="文件与知识"
+              id="export"
             >
-          {/* --- Markdown export (optional note-folder conventions) --- */}
+                    {/* --- File Upload Settings --- */}
+          <div style={styles.sectionTitle}>文件上传</div>
+
           <div style={styles.field}>
-            <label style={styles.label}>笔记库路径（可选）</label>
+            <label style={styles.label}>最大文件大小: {((config.file_upload_max_size ?? 10485760) / (1024 * 1024)).toFixed(0)} MB</label>
+            <input
+              style={{ width: "100%" }}
+              type="range"
+              min={1}
+              max={100}
+              step={1}
+              value={(config.file_upload_max_size ?? 10485760) / (1024 * 1024)}
+              onChange={e => dispatch({ type: "SET_CONFIG", config: { file_upload_max_size: parseInt(e.target.value) * 1024 * 1024 } })}
+            />
+            <div style={styles.helpText}>
+              上传文件的大小上限，范围 1–100 MB。此上限不提高图片预算（压缩后单张 ≤4MB，合计 ≤6MB）。
+            </div>
+          </div>
+
+          <div style={styles.field}>
+            <label style={styles.label}>最大 Token 数</label>
             <input
               style={styles.input}
-              value={config.obsidian_vault_path || ""}
-              onChange={e => dispatch({ type: "SET_CONFIG", config: { obsidian_vault_path: e.target.value } })}
-              placeholder="/path/to/your/notes"
+              type="number"
+              value={config.file_upload_max_tokens ?? 50000}
+              onChange={e => dispatch({ type: "SET_CONFIG", config: { file_upload_max_tokens: parseInt(e.target.value) || 50000 } })}
+              min={1000}
+              max={200000}
+              step={1000}
             />
-            <button
-              style={{ ...styles.secondaryBtn, marginTop: 6 }}
-              disabled={state.vaultPicker.picking}
-              onClick={() => {
-                // Ask the companion to open the OS native folder-picker (extensions can't
-                // read real folder paths). The response sets config.obsidian_vault_path.
-                dispatch({ type: "SET_VAULT_PICKER", picking: true, error: null })
-                chrome.runtime.sendMessage({ type: "obsidian.pick_vault_folder" })
-              }}
-            >
-              {state.vaultPicker.picking ? "选择中…" : "📂 选择文件夹"}
-            </button>
-            {state.vaultPicker.error && (
-              <div style={{ ...styles.helpText, color: tokens.danger, marginTop: 4 }}>
-                {state.vaultPicker.error}
-              </div>
-            )}
             <div style={styles.helpText}>
-              对话导出为 Markdown 文件下载，不写进该文件夹。若填写笔记库路径，会抽样约 200 篇笔记的 frontmatter 与正文前 200 字，提取命名 / tag 约定并建立索引；之后导出自动套用 frontmatter、相关笔记 [[wikilinks]] 与模板骨架。
+              文件内容截断阈值，范围 1000–200000
             </div>
-            <button
-              style={styles.secondaryBtn}
-              onClick={() => {
-                const vp = config.obsidian_vault_path?.trim()
-                if (!vp) return
-                dispatch({ type: "SET_OBSIDIAN_PROFILE_STATUS", status: { ok: true, message: "分析中…" } })
-                chrome.runtime.sendMessage({ type: "obsidian.refresh_profile", vault_path: vp })
-              }}
-            >
-              刷新笔记库档案
-            </button>
-            {state.obsidianProfileStatus && (
-              <div style={{ ...styles.helpText, color: state.obsidianProfileStatus.ok ? tokens.success : tokens.danger, marginTop: 6 }}>
-                {state.obsidianProfileStatus.message}
-              </div>
-            )}
           </div>
 
-            </SettingsSection>
+          <div style={styles.field}>
+            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
+              <input
+                type="checkbox"
+                checked={config.file_upload_vision ?? true}
+                onChange={e => dispatch({ type: "SET_CONFIG", config: { file_upload_vision: e.target.checked } })}
+              />
+              启用文件视觉分析
+            </label>
+            <div style={styles.helpText}>
+              仅当主模型不能看图时，用户附图才走视觉轨。主模型能看图时此开关不影响粘贴/选/拖。
+            </div>
           </div>
 
-          <div style={{ order: 7 }}>
-            <SettingsSection
-              title="实验功能"
-              open={isSectionOpen("experimental")}
-              onToggle={() => handleToggleSection("experimental")}
-            >
           {/* Thread History IA Wave B — session index (thread-list IA, not export) */}
           <div style={styles.sectionTitle}>会话索引（标签 / 要点）</div>
           <div style={styles.field}>
             <label style={styles.label}>打开列表时惰性提取要点</label>
             <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
@@ -3548,10 +3438,65 @@ export function SettingsSlideout() {
             </div>
           </div>
 
           <div style={styles.divider} />
 
+          {/* --- Markdown export (optional note-folder conventions) --- */}
+          <div style={styles.field}>
+            <label style={styles.label}>笔记库路径（可选）</label>
+            <input
+              style={styles.input}
+              value={config.obsidian_vault_path || ""}
+              onChange={e => dispatch({ type: "SET_CONFIG", config: { obsidian_vault_path: e.target.value } })}
+              placeholder="/path/to/your/notes"
+            />
+            <button
+              style={{ ...styles.secondaryBtn, marginTop: 6 }}
+              disabled={state.vaultPicker.picking}
+              onClick={() => {
+                // Ask the companion to open the OS native folder-picker (extensions can't
+                // read real folder paths). The response sets config.obsidian_vault_path.
+                dispatch({ type: "SET_VAULT_PICKER", picking: true, error: null })
+                chrome.runtime.sendMessage({ type: "obsidian.pick_vault_folder" })
+              }}
+            >
+              {state.vaultPicker.picking ? "选择中…" : "📂 选择文件夹"}
+            </button>
+            {state.vaultPicker.error && (
+              <div style={{ ...styles.helpText, color: tokens.danger, marginTop: 4 }}>
+                {state.vaultPicker.error}
+              </div>
+            )}
+            <div style={styles.helpText}>
+              对话导出为 Markdown 文件下载，不写进该文件夹。若填写笔记库路径，会抽样约 200 篇笔记的 frontmatter 与正文前 200 字，提取命名 / tag 约定并建立索引；之后导出自动套用 frontmatter、相关笔记 [[wikilinks]] 与模板骨架。
+            </div>
+            <button
+              style={styles.secondaryBtn}
+              onClick={() => {
+                const vp = config.obsidian_vault_path?.trim()
+                if (!vp) return
+                dispatch({ type: "SET_OBSIDIAN_PROFILE_STATUS", status: { ok: true, message: "分析中…" } })
+                chrome.runtime.sendMessage({ type: "obsidian.refresh_profile", vault_path: vp })
+              }}
+            >
+              刷新笔记库档案
+            </button>
+            {state.obsidianProfileStatus && (
+              <div style={{ ...styles.helpText, color: state.obsidianProfileStatus.ok ? tokens.success : tokens.danger, marginTop: 6 }}>
+                {state.obsidianProfileStatus.message}
+              </div>
+            )}
+          </div>
+
+            </SettingsPage>
+          </div>
+
+          <div data-settings-page="experimental" hidden={activeSettingsPage !== "experimental"}>
+            <SettingsPage
+              title="实验功能"
+              id="experimental"
+            >
           {/* --- WP5-I4 实验功能(Qwen3-VL 本地模型定位层) --- */}
           <div style={styles.sectionTitle}>实验功能</div>
           {(() => {
             // 纯渲染:一切文案/判定来自 logic 纯函数;发送固定 source:"settings";
             // 无乐观更新——UI 态由 companion state 广播/应答驱动。
@@ -4181,10 +4126,17 @@ export function SettingsSlideout() {
                 <div style={styles.helpText}>{MODEL_SWITCH_COPY.licenseDoorHint}</div>
               </div>
             )
           })()}
 
+            </SettingsPage>
+          </div>
+
+        </div>
+
+        </div>
+
           {/* 许可证门:渲染 license_required 载荷原文(LICENSE_DOOR_TEXT 单一真源
               在 companion model-license.ts,扩展不复制不私编) */}
           {licenseDoorShouldOpen(state.computerModelLicenseDoor) && (
             <Modal
               open={true}
@@ -4224,16 +4176,11 @@ export function SettingsSlideout() {
               </div>
             </Modal>
           )}
 
           
-            </SettingsSection>
-          </div>
-
-        </div>
-
-        <div style={styles.footer}>
+        <div className="cm-settings-footer" style={styles.footer}>
           <div style={{ display: "flex", flexDirection: "column", gap: 2, marginRight: "auto", textAlign: "left" }}>
             {state.testResult && (
               <span style={{
                 fontSize: 12,
                 color: state.testResult.includes("成功") ? tokens.success : tokens.danger,
@@ -4245,11 +4192,11 @@ export function SettingsSlideout() {
                 color: state.testVisionResult.includes("成功") ? tokens.success : tokens.danger,
               }}>{state.testVisionResult}</span>
             )}
           </div>
           <button style={styles.testBtn} onClick={handleTest}>
-            {config.vision_enabled ? "测试连接（含视觉）" : "测试连接"}
+            {config.vision_enabled ? "测试模型连接（含视觉）" : "测试模型连接"}
           </button>
           <button
             style={{
               ...styles.saveBtn,
               ...(settingsSaveDisabled(state.configHydratedFromCompanion)
@@ -4257,11 +4204,11 @@ export function SettingsSlideout() {
                 : {}),
             }}
             onClick={handleSave}
             disabled={settingsSaveDisabled(state.configHydratedFromCompanion)}
             title={settingsSaveDisabledTitle(state.configHydratedFromCompanion)}
-          >保存</button>
+          >保存全部配置</button>
         </div>
 
         {state.companionConfig && (
           <div style={{
             fontSize: 11,
@@ -4329,11 +4276,11 @@ const styles: Record<string, React.CSSProperties> = {
     width: "100%",
     padding: "6px 10px",
     border: `1px solid ${tokens.borderStrong}`,
     borderRadius: 6,
     fontSize: 13,
-    fontFamily: "monospace",
+    fontFamily: tokens.font,
     outline: "none",
     boxSizing: "border-box" as const,
   },
   toggleBtn: {
     padding: "4px 10px",
@@ -4348,20 +4295,20 @@ const styles: Record<string, React.CSSProperties> = {
     width: "100%",
     padding: "6px 10px",
     border: `1px solid ${tokens.borderStrong}`,
     borderRadius: 6,
     fontSize: 13,
-    fontFamily: "monospace",
+    fontFamily: tokens.font,
     outline: "none",
     boxSizing: "border-box" as const,
     background: tokens.bgElevated,
   },
   helpText: {
     marginTop: 6,
-    fontSize: 11,
+    fontSize: 12,
     color: tokens.textSecondary,
-    lineHeight: 1.4,
+    lineHeight: 1.6,
   },
   footer: {
     display: "flex",
     justifyContent: "flex-end",
     alignItems: "center",
diff --git a/chrome-extension/src/sidepanel/hooks/useComposerVoice.ts b/chrome-extension/src/sidepanel/hooks/useComposerVoice.ts
index aac0825b..9da3e1e9 100644
--- a/chrome-extension/src/sidepanel/hooks/useComposerVoice.ts
+++ b/chrome-extension/src/sidepanel/hooks/useComposerVoice.ts
@@ -480,11 +480,11 @@ export function useComposerVoice({
 
   const handleOpenVoiceSettings = useCallback(() => {
     voice.dismissBanner()
     setComposeOpen(false)
     closePanel()
-    dispatch({ type: "OPEN_SETTINGS_SECTION", section: "model" })
+    dispatch({ type: "OPEN_SETTINGS_SECTION", section: "voice" })
   }, [closePanel, dispatch, voice])
 
   return {
     voice,
     voiceLevel,
diff --git a/chrome-extension/src/sidepanel/ui/workspace-styles.ts b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
index 8cb55371..314418be 100644
--- a/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ b/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -43,6 +43,29 @@ export const workspaceCSS = `
 .cm-history-panel button:focus-visible,.cm-history-panel [role="button"]:focus-visible{outline:2px solid ${tokens.accent};outline-offset:-2px}
 @media(min-width:760px){.cm-navigation-toggle{display:none!important}.cm-status-rail{padding:12px 24px!important;border-bottom:1px solid ${tokens.border}!important}.cm-chat-scroll{padding:28px 32px!important}.cm-composer-dock{padding-bottom:24px!important}}
 @media(max-width:759px){.cm-workspace{flex-direction:column}.cm-navigation-disclosure{flex-shrink:0;max-height:28dvh;overflow:auto;border-bottom:1px solid ${tokens.border}}.cm-navigation-disclosure .cm-navigation{height:auto;width:100%}.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-panel{align-self:flex-end;width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-categories{padding:8px 16px;max-height:100px;overflow:auto}.cm-settings-body{padding:8px 16px 16px!important}}
 @media(max-height:560px){.cm-context-panel{max-height:28dvh!important}.cm-composer-dock{padding-top:4px!important;padding-bottom:6px!important}.cm-navigation{padding-top:10px}.cm-nav-brand{padding-bottom:8px}.cm-nav-resources{margin-bottom:4px}.cm-nav-new{margin-bottom:2px}}
 @media(prefers-reduced-motion:reduce){.cm-workspace *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
+
+.cm-settings-panel{width:min(980px,100vw - 32px)!important;height:88dvh;max-height:88dvh!important}
+.cm-settings-layout{display:flex;flex:1;min-height:0;overflow:hidden}
+.cm-settings-nav{box-sizing:border-box;width:172px;flex-shrink:0;padding:16px 10px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};overflow-y:auto}
+.cm-settings-nav button{display:block;width:100%;min-height:40px;padding:10px 12px;margin:2px 0;border:0;border-radius:8px;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:13px;text-align:left;cursor:pointer}
+.cm-settings-nav button[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:600}
+.cm-settings-nav button:hover{background:${tokens.bgHover}}
+.cm-settings-layout .cm-settings-body{flex:1;min-width:0;padding:20px 28px 28px!important;overflow:auto}
+.cm-settings-page-heading{padding:0 0 20px;margin-bottom:16px;border-bottom:1px solid ${tokens.border}}
+.cm-settings-page-heading h3{font-size:20px;font-weight:600;letter-spacing:-.03em;margin:0 0 8px}
+.cm-settings-page-heading p{font-size:12px;line-height:1.7;color:${tokens.textSecondary};margin:8px 0 0}
+.cm-settings-status{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 8px}
+.cm-settings-status:empty{display:none}
+.cm-settings-status button{background:${tokens.warningSoft};color:${tokens.text};border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;min-height:32px;font:inherit;font-size:12px;cursor:pointer}
+.cm-settings-assistant{margin-bottom:20px;font-size:12px;color:${tokens.textSecondary}}
+.cm-settings-assistant summary{cursor:pointer;min-height:28px}
+.cm-settings-mobile-category{display:none}
+.cm-settings-footer{flex-wrap:wrap;padding:12px 24px!important;gap:8px!important}
+.cm-settings-footer button{min-height:36px}
+.cm-settings-footer button:last-child{background:${tokens.actionPrimary}!important}
+.cm-settings-body input,.cm-settings-body select,.cm-settings-body textarea{max-width:100%;box-sizing:border-box}
+@media(max-width:759px){.cm-settings-panel{height:94dvh;max-height:94dvh!important;width:100%!important}.cm-settings-layout{flex-direction:column}.cm-settings-nav{display:none}.cm-settings-mobile-category{display:flex;align-items:center;gap:12px;padding:10px 16px;background:${tokens.bgMuted};border-bottom:1px solid ${tokens.border};font-size:12px;color:${tokens.textSecondary}}.cm-settings-mobile-category select{flex:1;min-width:0;min-height:36px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;background:${tokens.bg};color:${tokens.text};font:inherit}.cm-settings-layout .cm-settings-body{padding:16px!important}.cm-settings-status{padding:0 16px 8px}.cm-settings-page-heading h3{font-size:18px}.cm-settings-footer{padding:10px 16px!important}}
+.cm-settings-body input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),.cm-settings-body select{min-height:36px}
 `
diff --git a/chrome-extension/src/sidepanel/utils/settings-sections.ts b/chrome-extension/src/sidepanel/utils/settings-sections.ts
index 04419c97..e6fe998b 100644
--- a/chrome-extension/src/sidepanel/utils/settings-sections.ts
+++ b/chrome-extension/src/sidepanel/utils/settings-sections.ts
@@ -5,10 +5,11 @@ export const LS_SETTINGS_EXPAND = "cmspark.settings.expandSections"
 
 /** Canonical section ids (order = IA). */
 export const SETTINGS_SECTION_IDS = [
   "connection",
   "model",
+  "voice",
   "secrets",
   "security",
   "integrations",
   "export",
   "experimental",
diff --git a/companion/src/settings-web.ts b/companion/src/settings-web.ts
index 8bf684d6..3b8e41ea 100644
--- a/companion/src/settings-web.ts
+++ b/companion/src/settings-web.ts
@@ -524,32 +524,16 @@ export const SETTINGS_HTML = `<!DOCTYPE html>
  * ~1157; it mirrors the light family, this surface mirrors the dark family).
  * NEVER reintroduce Material palette hexes here (tokens.ts:185 bans them on
  * the side panel; same rule now applies to this surface).
  */
 :root{
-  --bg:#171717;            /* tokens.darkBg */
-  --elevated:#222222;      /* tokens.darkElevated */
-  --border:rgba(255,255,255,0.08);  /* tokens.darkBorder */
-  --border-strong:rgba(255,255,255,0.16);
-  --text:#f1f5f9;          /* tokens.darkText */
-  --muted:#94a3b8;         /* tokens.darkMuted */
-  --faint:#94a3b8;         /* muted-2 级（hint/env 弱文本） */
-  --accent:#818cf8;        /* tokens.darkAccent (indigo-400) */
-  --on-accent:#fff;
-  --success:#34d399;       /* tokens.darkSuccess */
-  --success-soft:rgba(52,211,153,0.12);
-  --danger:#f87171;        /* tokens.darkDanger */
-  --danger-soft:rgba(248,113,113,0.12);
-  --warning:#fbbf24;       /* tokens.darkWarning */
-  --warning-soft:rgba(251,191,36,0.12);
-  --success-border:rgba(52,211,153,0.3);
-  --danger-border:rgba(248,113,113,0.3);
-  --warning-border:rgba(251,191,36,0.25);
-  --field-bg:#2a2a2a;      /* input 底：darkElevated 上加一层（替代原 Material 输入蓝） */
-  --field-border:rgba(255,255,255,0.12);
-  --radius:12px;--radius-sm:8px;
-  --font-ui:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
+  --bg:#f7f7f5;--elevated:#fff;--border:rgba(23,23,23,.08);--border-strong:rgba(23,23,23,.16);
+  --text:#171717;--muted:#666;--faint:#767676;--accent:#4f46e5;--on-accent:#fff;
+  --success:#047857;--success-soft:#ecfdf5;--danger:#b91c1c;--danger-soft:#fef2f2;
+  --warning:#92400e;--warning-soft:#fffbeb;--success-border:#a7f3d0;--danger-border:#fecaca;--warning-border:#fde68a;
+  --field-bg:#fff;--field-border:rgba(23,23,23,.16);--radius:16px;--radius-sm:8px;
+  --font-ui:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI','PingFang SC',sans-serif;
 }
 *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
 body{font-family:var(--font-ui);background:var(--bg);color:var(--text);min-height:100vh;display:flex;justify-content:center;padding:24px 16px}
 .container{max-width:720px;width:100%}
 .card{background:var(--elevated);border-radius:var(--radius);padding:28px 32px;border:1px solid var(--border);box-shadow:none}
@@ -568,11 +552,11 @@ input:focus{border-color:var(--accent)}
 .range-row input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;background:var(--accent);border-radius:50%;cursor:pointer}
 .range-val{font-size:13px;color:var(--text);min-width:32px;text-align:right}
 .actions{display:flex;gap:10px;margin-top:24px;flex-wrap:wrap}
 .btn{padding:8px 20px;border-radius:var(--radius-sm);font-size:13px;font-weight:500;cursor:pointer;border:none;font-family:inherit;transition:opacity 0.2s}
 .btn:hover{opacity:0.85}
-.btn-primary{background:var(--accent);color:var(--on-accent)}
+.btn-primary{background:#242424;color:var(--on-accent)}
 .btn-outline{background:transparent;border:1px solid var(--accent);color:var(--accent)}
 .btn-ghost{background:transparent;border:1px solid var(--border-strong);color:var(--muted)}
 .result{margin-top:12px;padding:10px 14px;border-radius:var(--radius-sm);font-size:13px;display:none}
 .result.success{display:block;background:var(--success-soft);color:var(--success);border:1px solid var(--success-border)}
 .result.error{display:block;background:var(--danger-soft);color:var(--danger);border:1px solid var(--danger-border)}
@@ -596,11 +580,11 @@ button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid
 </style>
 </head>
 <body>
 <div class="container">
   <div class="card">
-    <h1>&#9881; CMspark Global Settings <span class="status-dot" id="statusDot"></span></h1>
+    <h1>CMspark 设置 <span class="status-dot" id="statusDot"></span></h1>
     <div class="subtitle">Companion global LLM config &mdash; fallback for threads without override</div>
 
     <div class="divider"></div>
     <div class="section-title">LLM Config</div>
 
diff --git a/companion/src/summoner-web.ts b/companion/src/summoner-web.ts
index 5df4fa21..7b80158a 100644
--- a/companion/src/summoner-web.ts
+++ b/companion/src/summoner-web.ts
@@ -1301,15 +1301,10 @@ body{
 .meeting-actions button:focus-visible{outline:none;box-shadow:var(--focus)}
 .meeting-actions button:disabled{opacity:.45;cursor:not-allowed}
 #meetingRec{background:var(--indigo);color:#fff;font-weight:500;flex:1}
 .meeting-desk.recording #meetingRec{background:#dc2626;color:#fff}
 #meetingMinutesBtn{background:var(--indigo-soft);color:var(--indigo)}
-.mark{
-  width:52px;height:52px;border-radius:50%;background:#171717;color:#fff;
-  display:grid;place-items:center;font-size:20px;font-weight:600;margin:0 auto 10px;
-}
-.mark.sm{width:26px;height:26px;font-size:11px;margin:0}
 .log{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;padding:20px 22px;display:flex;flex-direction:column;gap:16px}
 .msg{max-width:46rem;font-size:14px;line-height:1.7;word-break:break-word}
 .msg.user{align-self:flex-end;background:var(--canvas);padding:8px 12px;border-radius:12px 12px 4px 12px;white-space:pre-wrap}
 .msg.assistant{align-self:flex-start;color:var(--text);white-space:normal}
 .msg.assistant p{margin:0 0 8px}
@@ -1399,10 +1394,27 @@ body{
 
 /* #469 shared workspace craft; transport and capture ACL are unchanged. */
 button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid var(--indigo);outline-offset:2px}
 @media(min-width:760px){.log,.composer{width:100%;max-width:780px;margin-left:auto;margin-right:auto}.brand{padding:16px 24px 12px}}
 @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
+
+/* #471: same conversation hierarchy as the extension workspace. */
+.brand{padding:12px 16px;border-bottom:1px solid var(--line);font-size:13px}
+.brand-actions button{background:transparent}.brand-actions button:hover{background:var(--canvas)}
+.cruise-chip{max-width:104px;font-weight:400;background:var(--canvas)!important;color:var(--secondary)!important}
+.empty{max-width:360px;padding:24px 12px;gap:4px}.empty strong{font-size:22px;font-weight:500;letter-spacing:-.03em}
+.msg.user{background:#f3f3f1;border:1px solid var(--line);border-radius:14px;padding:12px 16px}
+.msg.assistant{padding:8px 0;line-height:1.75}
+.log{gap:24px;padding:24px 20px}
+.composer{padding:12px 16px 8px}.composer-row{width:100%}
+.field{width:100%;display:flex;flex-direction:column;align-items:stretch;gap:6px;padding:10px 12px;border-radius:20px;box-shadow:0 1px 2px rgba(0,0,0,.03)}
+.field textarea{box-sizing:border-box;flex:none;font-family:inherit;font-size:14px;line-height:1.6;padding:2px;min-height:42px}
+.field:focus-within{box-shadow:0 0 0 2px rgba(79,70,229,.12);border-color:var(--indigo)}
+.composer-actions{display:flex;align-items:center;gap:6px}.composer-actions .icon-btn{width:36px;height:36px;color:var(--secondary)}
+#mic{margin-left:auto}#sendGo{border-radius:50%;background:#242424;color:#fff}
+.capture-row{padding:0 16px 12px;gap:8px}.capture-row button{background:transparent;border:1px solid var(--line);font-size:12px;color:var(--secondary)}
+@media(max-width:380px){.brand{flex-wrap:wrap;gap:4px;padding:10px 12px}.brand-actions{margin-left:auto}.brand-actions button{padding:6px}.log{padding:16px}.composer{padding:8px 12px}.empty strong{font-size:20px}}
 </style>
 </head>
 <body>
 <div class="hud expanded" id="hud">
   <div class="body">
@@ -1431,20 +1443,19 @@ button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px soli
         <div id="composeList"></div>
       </div>
     </aside>
     <section class="main">
       <div class="brand">
-        <span class="brand-id"><span class="mark sm" aria-hidden="true">山</span>CMspark</span>
+        <span class="brand-id">CMspark</span>
         <span class="brand-actions">
           <button type="button" id="cruiseChip" class="cruise-chip" title="点此打开侧栏调整档位">%%CRUISE_LABEL%%</button>
           <button type="button" id="historyOpen">历史</button>
           <button type="button" id="newChat">新对话</button>
         </span>
       </div>
       <div class="log" id="log">
         <div class="empty" id="empty">
-          <div class="mark" aria-hidden="true">山</div>
           <strong>${CHAT_SHELL_TITLE_NONE}</strong>
           回车发送。附件和听写不用开浏览器。
         </div>
       </div>
     </section>
@@ -1452,16 +1463,17 @@ button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px soli
   <div class="composer">
     <div class="composer-row">
       <button class="icon-btn" id="newThreadBar" type="button" title="新对话" aria-label="新对话">
         <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
       </button>
-      <label class="icon-btn" for="files" title="📎 添加附件" aria-label="添加附件">
-        <svg viewBox="0 0 24 24"><path d="M8.2 12.8 14 7a2.8 2.8 0 0 1 4 4l-7.4 7.4a4 4 0 0 1-5.7-5.7l7.1-7.1"/></svg>
-      </label>
       <input type="file" id="files" multiple hidden>
       <div class="field">
         <textarea id="text" rows="1" placeholder="问 CMspark…" aria-label="发送到当前对话"></textarea>
+        <div class="composer-actions">
+      <button type="button" class="icon-btn" id="attachFile" title="📎 添加附件" aria-label="添加附件">
+        <svg viewBox="0 0 24 24"><path d="M8.2 12.8 14 7a2.8 2.8 0 0 1 4 4l-7.4 7.4a4 4 0 0 1-5.7-5.7l7.1-7.1"/></svg>
+      </button>
         <button class="icon-btn" id="mic" type="button" title="听写" aria-label="听写" aria-pressed="false">
           <svg viewBox="0 0 24 24"><rect x="9" y="4" width="6" height="10" rx="3"/><path d="M6.5 11a5.5 5.5 0 0 0 11 0M12 16.5V20"/></svg>
         </button>
         <button class="icon-btn" id="sendGo" type="button" title="发送" aria-label="发送">
           <svg viewBox="0 0 24 24"><path d="M5 12h12M13 6l6 6-6 6"/></svg>
@@ -1470,10 +1482,11 @@ button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px soli
           <svg viewBox="0 0 24 24"><path d="M6 14l6-6 6 6"/></svg>
         </button>
         <button class="icon-btn" id="settings" type="button" hidden title="设置（快捷键等）" aria-label="设置">
           <svg viewBox="0 0 24 24"><path d="M12.2 2.2a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V3a.8.8 0 0 1 .8-.8zm0 16a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V19a.8.8 0 0 1 .8-.8zM19.1 7.4a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1l-2.6 2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zM4.9 16.6a.8.8 0 0 1 0-1.1l2.6-2.6a.8.8 0 0 1 1.1 0 .8.8 0 0 1 0 1.1L7.1 15.5l1.5 1.5a.8.8 0 0 1 0 1.1l-1.9 1.9a.8.8 0 0 1-1.1 0zm0-9.2a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1L7.3 13l2.6 2.6a.8.8 0 0 1-1.1 0l-1.9-1.9a.8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zm14.2 9.2a.8.8 0 0 1 0-1.1l-2.6-2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0 1.1l1.5 1.5-1.5 1.5a.8.8 0 0 1 0 1.1l1.9 1.9a.8.8 0 0 1 1.1 0z"/></svg>
         </button>
+        </div>
       </div>
     </div>
     <div class="capture-row">
       <button type="button" id="meetingStart" aria-pressed="false">开始会议</button>
       <button type="button" id="operateOpen">打开浏览器并打开侧栏</button>
@@ -1923,11 +1936,11 @@ try{
     });
     if(!n){
       var empty=document.createElement("div");
       empty.className="empty";
       empty.id="empty";
-      empty.innerHTML="<div class=\\"mark\\" aria-hidden=\\"true\\">山</div><strong>${CHAT_SHELL_TITLE_NONE}</strong>回车发送。附件和听写不用开浏览器。";
+      empty.innerHTML="<strong>${CHAT_SHELL_TITLE_NONE}</strong>回车发送。附件和听写不用开浏览器。";
       log.appendChild(empty);
     }
     log.scrollTop=log.scrollHeight;
   }
   function syncBusyUi(){
@@ -2420,10 +2433,11 @@ try{
       if(!id){setStatus("新建失败");return}
       showHistory(false);
       return refresh().then(function(){return selectThread(id)});
     });
   };
+  $("attachFile").addEventListener("click",function(){ $("files").click(); });
   $("text").addEventListener("keydown",function(e){
     if(e.key!=="Enter" || e.isComposing || e.keyCode===229) return;
     if(e.shiftKey && !e.metaKey && !e.ctrlKey){
       if(busy){e.preventDefault();send("enqueue")}
       return;


AST HANDLER INVENTORY
{
  "baselineCount": 134,
  "currentCount": 130,
  "removed": [
    {
      "handler": "onClick={() => { dispatch({ type: \"OPEN_SETTINGS_SECTION\", section: id }) requestAnimationFrame(() => requestAnimationFrame(() => { const heading = document.querySelector<HTMLElement>(`[data-settings-section=\"${label}\"] > button`) heading?.focus(); heading?.scrollIntoView({ block: \"start\" }) })) }}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"connection\")}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"model\")}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"secrets\")}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"security\")}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"integrations\")}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"export\")}",
      "count": 1
    },
    {
      "handler": "onToggle={() => handleToggleSection(\"experimental\")}",
      "count": 1
    }
  ],
  "added": [
    {
      "handler": "onClick={() => selectSettingsPage(\"connection\", true)}",
      "count": 1
    },
    {
      "handler": "onClick={() => selectSettingsPage(\"security\", true)}",
      "count": 1
    },
    {
      "handler": "onClick={() => selectSettingsPage(page.id, true)}",
      "count": 1
    },
    {
      "handler": "onChange={event => selectSettingsPage(event.target.value as SettingsSectionId)}",
      "count": 1
    }
  ]
}


FULL chrome-extension/src/sidepanel/components/SettingsPage.tsx
import type { ReactNode } from "react"
import type { SettingsSectionId } from "../utils/settings-sections"

/** Stable ids preserve existing settings deep links. Display order is task order. */
export const SETTINGS_PAGES: { id: SettingsSectionId; title: string; description: string }[] = [
  { id: "model", title: "模型与推理", description: "配置对话与视觉模型，以及上下文和推理预算。更改后点击保存。" },
  { id: "voice", title: "输入与语音", description: "管理发送快捷键、听写方式和语音模型。偏好即时生效；下载与启用需分别操作。" },
  { id: "export", title: "文件与知识", description: "管理附件限制、会话索引和笔记导出。配置更改后点击保存。" },
  { id: "connection", title: "连接与配对", description: "连接本机 Companion，配对操作在此单独完成。" },
  { id: "security", title: "安全与信任", description: "查看运行自主度与各项权限。每项开关沿用各自的确认和生效规则。" },
  { id: "integrations", title: "本机与工具", description: "管理本机能力、网络授权、MCP 和编程助手。授权操作需单独确认。" },
  { id: "secrets", title: "密钥与环境", description: "管理工具使用的密钥和环境变量。各条目单独保存。" },
  { id: "experimental", title: "实验功能", description: "配置本地视觉定位等实验能力。模型下载、许可和启用分别确认。" },
]

/** Parent hides inactive pages, preserving every child form and draft. */
export function SettingsPage({ id, title, badge, children }: {
  id: SettingsSectionId; title: string; badge?: ReactNode; children: ReactNode
}) {
  return <section data-settings-section={title} aria-labelledby={`settings-page-${id}`}>
    <header className="cm-settings-page-heading">
      <h3 id={`settings-page-${id}`} tabIndex={-1}>{title}</h3>{badge}
      <p>{SETTINGS_PAGES.find(page => page.id === id)?.description}</p>
    </header>
    {children}
  </section>
}


FULL chrome-extension/scripts/test-settings-pages-ui.py
"""Actual App settings pages with synthetic transport; no live config changes."""
from pathlib import Path
import subprocess,tempfile
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(6000)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
  page.evaluate("window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'model'})")
  settings=page.get_by_role('dialog',name='设置',exact=True);settings.wait_for()
  model=page.get_by_placeholder('输入模型名称或从列表选择',exact=True);model.fill('fixture-model-draft')
  pages=['model','voice','export','connection','security','integrations','secrets','experimental']
  for width,height in [(1440,900),(800,700),(390,740),(320,480)]:
   page.set_viewport_size({'width':width,'height':height})
   for id in pages:
    if width>=760:
     settings.locator('.cm-settings-nav button').nth(pages.index(id)).click()
    else:settings.get_by_role('combobox',name='设置分类',exact=True).select_option(id)
    panel=settings.locator('[data-settings-page="'+id+'"]');panel.wait_for(state='visible')
    assert settings.locator('[data-settings-page]:visible').count()==1
    assert settings.evaluate('(el)=>el.scrollWidth<=el.clientWidth'),(width,id,'horizontal overflow')
    save=settings.get_by_role('button',name='保存全部配置',exact=True).bounding_box();assert save and save['y']+save['height']<=height,(width,id,save)
   page.evaluate("window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'model'})")
   model.wait_for();assert model.input_value()=='fixture-model-draft'
   page.wait_for_function('document.activeElement?.id==="settings-page-model"')
   page.screenshot(path=str(shots/f'settings-model-{width}.png'))
  assert not page.evaluate('window.sent.some(x=>x.type==="config.set" || x.type.includes("license_response") || x.type==="terminal.start")')
  page.evaluate("window.dispatchUI({type:'SET_CONFIG',config:{auto_approve_dangerous:true}});window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'voice'})")
  settings.get_by_role('button',name='有高权限开关已开启 · 查看安全设置',exact=True).wait_for()
  assert not model.is_visible()
  settings.get_by_role('button',name='有高权限开关已开启 · 查看安全设置',exact=True).click()
  settings.locator('[data-settings-page="security"]').wait_for(state='visible')
  assert not errors,errors
  b.close()
print('PASS: settings pages responsive, all categories, retained model draft, stable deep links+focus, cross-page safety status, no implicit writes.')


FULL companion/scripts/test-summoner-workspace-ui.py
"""Actual summoner HTML script, synthetic HTTP responses; no installed Companion."""
from pathlib import Path
from urllib.parse import urlparse
import json,subprocess,tempfile
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-web-surface-fixtures.cjs',out],cwd=root,check=True)
 html=(Path(out)/'capture.html').read_text().replace('%%CRUISE_LABEL%%','每次确认')
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':390,'height':740});page.set_default_timeout(6000)
  errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.add_init_script('window.EventSource=class {addEventListener(){} close(){}};window.resizeTo=()=>{};window.moveTo=()=>{};')
  def route(r):
   req=r.request;path=urlparse(req.url).path;requests.append((req.method,path))
   if path=='/':r.fulfill(content_type='text/html',body=html);return
   if path=='/api/threads':data={'thread':{'id':'fixture-1'}} if req.method=='POST' else {'threads':[{'id':'fixture-1','alias':'演示对话'}]}
   elif path=='/api/thread':data={'messages':[],'run_status':'idle'}
   else:data={'ok':True}
   r.fulfill(content_type='application/json',body=json.dumps(data))
  page.route('http://fixture.test/**',route);page.goto('http://fixture.test/')
  text=page.get_by_role('textbox',name='发送到当前对话',exact=True);text.wait_for()
  page.wait_for_timeout(200);assert not errors,errors
  page.get_by_role('button',name='新对话',exact=True).first.click()
  page.wait_for_function('document.querySelector("#empty strong")')
  assert page.locator('.mark').count()==0 and '山' not in page.locator('#empty').inner_text()
  assert ('POST','/api/threads') in requests
  page.get_by_role('button',name='历史',exact=True).click();assert page.locator('.hud.history .list').is_visible()
  page.get_by_role('button',name='完成',exact=True).click()
  for width,height in [(320,420),(390,740),(1000,800)]:
   page.set_viewport_size({'width':width,'height':height})
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   field=text.bounding_box();send=page.get_by_role('button',name='发送',exact=True).bounding_box()
   assert field and send and field['y']+field['height']<=send['y']+1 and send['y']+send['height']<=height
   page.screenshot(path=str(shots/f'summoner-{width}.png'))
  with page.expect_file_chooser():page.get_by_role('button',name='添加附件',exact=True).click()
  text.fill('请整理变更材料');page.get_by_role('button',name='发送',exact=True).click()
  page.wait_for_timeout(200);assert ('POST','/api/chat') in requests
  assert not errors,errors
  b.close()
print('PASS: real summoner script, reset without mark, history, input/action DOM order, keyboard-native attachment, send; synthetic HTTP/SSE only.')


FULL chrome-extension/src/sidepanel/utils/settings-sections.ts
// Settings accordion expand state — pure helpers (settings-thread-compact W1).
// Spec: docs/superpowers/specs/2026-08-06-settings-thread-compact-ux.md

export const LS_SETTINGS_EXPAND = "cmspark.settings.expandSections"

/** Canonical section ids (order = IA). */
export const SETTINGS_SECTION_IDS = [
  "connection",
  "model",
  "voice",
  "secrets",
  "security",
  "integrations",
  "export",
  "experimental",
] as const

export type SettingsSectionId = (typeof SETTINGS_SECTION_IDS)[number]

export type SettingsExpandInput = {
  /** User LS preference (section open). */
  userOpen: Set<SettingsSectionId>
  /** WS pairing known + paired */
  wsPaired: boolean | null
  /** F-S3 elevated trust */
  elevatedTrust: boolean
}

/** Default open set when LS empty (before force rules). */
export function defaultUserOpenSections(wsPaired: boolean | null): Set<SettingsSectionId> {
  // Unpaired / unknown: connection + model. Paired: model only (F-UX3).
  if (wsPaired === true) return new Set<SettingsSectionId>(["model"])
  return new Set<SettingsSectionId>(["connection", "model"])
}

export function parseSettingsExpand(raw: string | null): Set<SettingsSectionId> | null {
  if (!raw) return null
  try {
    const arr = JSON.parse(raw)
    if (!Array.isArray(arr)) return null
    const next = new Set<SettingsSectionId>()
    for (const x of arr) {
      if (typeof x === "string" && (SETTINGS_SECTION_IDS as readonly string[]).includes(x)) {
        next.add(x as SettingsSectionId)
      }
    }
    return next
  } catch {
    return null
  }
}

export function serializeSettingsExpand(open: Set<SettingsSectionId>): string {
  return JSON.stringify([...open])
}

/** Elevated trust flags (F-S3 set) — used for armed header badge, not force-open. */
export function isElevatedTrust(flags: {
  auto_approve_dangerous?: boolean
  auto_approve_enterprise_tools?: boolean
  allow_all_schemes?: boolean
  unattendedArmed?: boolean
}): boolean {
  return (
    flags.auto_approve_dangerous === true ||
    flags.auto_approve_enterprise_tools === true ||
    flags.allow_all_schemes === true ||
    flags.unattendedArmed === true
  )
}

/**
 * Effective open map: force rules beat LS (F-UX3 unpaired connection only).
 * - unpaired → force connection open
 * - elevatedTrust no longer force-opens security (2026-08-08 UX): section stays
 *   collapsible; SettingsSlideout still shows armed badge on the header (F-S2).
 * - model default-open on first load via defaultUserOpenSections
 *
 * `elevatedTrust` remains on the input for callers / future soft-open policies.
 */
export function isSectionEffectivelyOpen(
  id: SettingsSectionId,
  input: SettingsExpandInput,
): boolean {
  if (id === "connection" && input.wsPaired !== true) return true
  // elevatedTrust: badge only (SettingsSlideout); do not force-open security
  return input.userOpen.has(id)
}

export function toggleSectionOpen(
  id: SettingsSectionId,
  userOpen: Set<SettingsSectionId>,
): Set<SettingsSectionId> {
  const next = new Set(userOpen)
  if (next.has(id)) next.delete(id)
  else next.add(id)
  return next
}


FULL chrome-extension/src/sidepanel/components/ui/Modal.tsx
// Shared modal/overlay primitive (audit M18).
//
// Wraps useModalDialog (focus trap + Escape + focus restore) and applies the
// dialog ARIA contract (role + aria-modal + aria-label/labelledby) so every
// overlay dialog gets consistent keyboard + screen-reader behavior.
//
// Callers pass their OWN overlay + panel styles (position fixed vs absolute,
// z-index, backdrop color, alignment differ per dialog and are kept verbatim)
// and their panel content as children. The outer overlay receives role/aria and
// the backdrop-dismiss click; the inner panel stops propagation so clicks inside
// don't close the dialog.
//
// NOTE: this is for DIALOGS only — things that take focus and trap it. Popovers
// that should NOT steal focus (e.g. SlashCommandPopover, a combobox/listbox) must
// NOT use this; they need listbox semantics instead. See ARIA guidance in WCAG.

import type { CSSProperties, ReactNode, RefObject } from "react"
import { useModalDialog, type UseModalDialogOptions } from "../../hooks/useModalDialog"

export interface ModalProps {
  /** Gate visibility + focus management. Renders null when false. */
  open: boolean
  /** Called on Escape, and on overlay click when backdropDismiss is true. */
  onClose: () => void
  /** Accessible role. Use "alertdialog" for destructive-action gates. */
  role?: "dialog" | "alertdialog"
  /** Accessible name when there's no visible title to point at. */
  ariaLabel?: string
  /** Accessible name pointing at a visible title element's id. Preferred over ariaLabel. */
  ariaLabelledBy?: string
  /** Click on the overlay/backdrop calls onClose. Default true. */
  backdropDismiss?: boolean
  /** Element to focus on open (passed through to useModalDialog). */
  initialFocusRef?: RefObject<HTMLElement>
  /** Restore focus on close (passed through to useModalDialog). */
  restoreFocus?: boolean
  /** Extra effect deps (e.g. a dialog id) — passed through to useModalDialog. */
  deps?: UseModalDialogOptions["deps"]
  /** Style for the overlay/backdrop element (position, z-index, bg, alignment). */
  overlayStyle?: CSSProperties
  /** Style for the inner panel. */
  panelStyle?: CSSProperties
  /** Extra className on the panel if a caller uses CSS classes. */
  panelClassName?: string
  children: ReactNode
}

export function Modal(props: ModalProps) {
  const {
    open,
    onClose,
    role = "dialog",
    ariaLabel,
    ariaLabelledBy,
    backdropDismiss = true,
    initialFocusRef,
    restoreFocus,
    deps,
    overlayStyle,
    panelStyle,
    panelClassName,
    children,
  } = props

  const overlayRef = useModalDialog({ open, onClose, initialFocusRef, restoreFocus, deps })

  if (!open) return null

  const aria = ariaLabelledBy ? { "aria-labelledby": ariaLabelledBy } : { "aria-label": ariaLabel }

  return (
    <div
      ref={overlayRef}
      role={role}
      aria-modal="true"
      {...aria}
      style={overlayStyle}
      onClick={backdropDismiss ? onClose : undefined}
    >
      <div style={panelStyle} className={panelClassName} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  )
}


SETTINGS HOOKS + HANDLERS (full prefix before return markup)
// Settings slideout panel for LLM configuration + NetSec (migrated from 场景 panel)

import { useState, useEffect, useCallback, useRef } from "react"
import { useAgentStore } from "../store/agentStore"
import { Modal } from "./ui/Modal"
import { tokens } from "../ui/tokens"
import { UserEnvSection } from "./UserEnvSection"
import { NetSecSettingsSection } from "./NetSecSettingsSection"
import { CapabilityProfileSection } from "./CapabilityProfileSection"
import { OutboundMcpSettingsSection } from "./OutboundMcpSettingsSection"
import { CodingHandoffSettingsSection } from "./CodingHandoffSettingsSection"
import { SettingsPage, SETTINGS_PAGES } from "./SettingsPage"
import { SettingsIntentBar } from "./SettingsIntentBar"
import { HotkeyCaptureField } from "./HotkeyCaptureField"
import { useContextPanelHostOptional } from "./ContextPanelHost"
import type { SettingsIntent } from "../utils/settings-intent"
import { DICTATION_HOTKEY_DEFAULT_CHORD } from "../voice/hotkey-chord"
import {
  isElevatedTrust,
  SETTINGS_SECTION_IDS,
  type SettingsSectionId,
} from "../utils/settings-sections"
import {
  contextWindowHelpText,
  settingsSaveDisabled,
  settingsSaveDisabledTitle,
} from "../utils/context-window-copy"
// WP5-I4 实验功能段:组件纯渲染,文案/判定全部来自 logic 纯函数(镜像
// companion 单一真源);发送固定 source:"settings"(companion 双层围栏)。
import {
  MODEL_SWITCH_COPY,
  QWEN_VL_VARIANT_TIPS,
  licenseDoorShouldOpen,
  modelStatusLine,
  modelSwitchDisabledReason,
  modelSwitchHint,
  modelSwitchRunningNote,
  variantResourceTip,
} from "./model-switch-logic"
import {
  UNATTENDED_MATRIX_FOOTNOTES,
  type AutopilotArmPick,
  type AutopilotTier,
  deriveDisplayTier,
  disarmAllFlags,
  flagsNeedingArm,
  flagsNeedingDisarm,
  targetFlagsForTier,
  tierShortLabel,
  trustStatusChip,
} from "./autopilot-tier"
import { AutopilotConsequenceMatrix } from "./AutopilotConsequenceMatrix"
// Path B M0: pure copy + recommended model id for local STT settings progressive disclosure.
import {
  BTN_CANCEL,
  BTN_DELETE,
  BTN_DOWNLOAD,
  BTN_ENABLE_LOCAL,
  BTN_ENABLE_SYSTEM,
  BTN_LOCAL_ENABLED,
  BTN_SET_ACTIVE,
  BTN_SWITCH_BROWSER,
  BTN_SYSTEM_ENABLED,
  ENGINE_BROWSER_HINT,
  ENGINE_BROWSER_LABEL,
  ENGINE_LOCAL_HINT,
  ENGINE_LOCAL_LABEL,
  ENGINE_SECTION_LABEL,
  ENGINE_SYSTEM_HINT,
  ENGINE_SYSTEM_LABEL,
  OTHER_MODELS_TOGGLE,
  OTHER_WHISPER_MODEL_IDS,
  RECOMMENDED_ROW_PREFIX,
  RECOMMENDED_WHISPER_MODEL_ID,
  SYSTEM_UNAVAILABLE_REASON_LABEL,
  VOICE_AUTO_FALLBACK_HINT,
  VOICE_AUTO_FALLBACK_LABEL,
  VOICE_DOWNLOAD_ENDPOINT_HINT,
  VOICE_DOWNLOAD_ENDPOINT_LABEL,
  VOICE_DOWNLOAD_ENDPOINT_PLACEHOLDER,
  VOICE_ERR_DOWNLOAD_NO_PROGRESS,
  VOICE_ERR_STATE_TIMEOUT,
  VOICE_STATUS_QUERYING,
  VOICE_STATUS_STARTING_DOWNLOAD,
  whisperModelMetaLine,
  binaryStatusLine,
  canDownloadWhisperBinary,
  engineChainRows,
  formatDiskUsage,
  modelProbeErrorLabel,
  modelStatusLabel,
  parseVoiceSettingsSendResponse,
  privacyCopyForEngine,
  progressPercent,
  type WhisperSettingsModelId,
} from "../voice/whisper-settings-copy"
import { detectSpeechRecognition } from "../voice/detect"
import {
  VISION_COPY,
  applyVisionReuseFromMain,
  bannerBodyForHost,
  extractHostname,
  isCustomVisionConfig,
  isVisionReusingMain,
  shouldOfferVisionReuse,
} from "./vision-reuse-logic"

// P1-1 / PR-B: typed-confirmation phrase for arming dangerous security flags.
// Lock-step with companion/src/security-arm.ts SECURITY_ARM_CONFIRM_PHRASE —
// companion rejects false→true without this top-level confirmation_phrase.
// UI phrase alone is theater; arm path must forward phrase on config.set.
// Alias kept as SECURITY_ARM_CONFIRM_PHRASE semantics; not a product "God" noun.
const GODMODE_CONFIRM_PHRASE = "我了解风险"
const SECURITY_ARM_PHRASE = GODMODE_CONFIRM_PHRASE

// #259 引擎链路状态 row 2: Web Speech availability (pure feature detect; node tests → missing).
const BROWSER_STT_SUPPORT = detectSpeechRecognition(
  typeof window !== "undefined" ? (window as any) : {},
)

const SAFETY_SKILLS = [
  { id: "cookie_guard", label: "Cookie 守卫" },
  { id: "eval_guard", label: "代码执行守卫" },
  { id: "nav_guard", label: "导航守卫" },
  { id: "input_guard", label: "输入守卫" },
]

export function SettingsSlideout() {
  const { state, dispatch } = useAgentStore()
  const host = useContextPanelHostOptional()
  const [showKey, setShowKey] = useState(false)
  const [showAuditLog, setShowAuditLog] = useState(false)
  const [trustedDomainsConfirm, setTrustedDomainsConfirm] = useState(false)
  const [autoApprovedConfirm, setAutoApprovedConfirm] = useState(false)
  const [wsSecretInput, setWsSecretInput] = useState("")
  const [wsPaired, setWsPaired] = useState<boolean | null>(null)
  const [wsPairingMsg, setWsPairingMsg] = useState<{ ok: boolean; text: string } | null>(null)
  // PR-B God-mode: the typed-confirmation sub-panel + its input + feedback.
  const [godmodeConfirm, setGodmodeConfirm] = useState(false)
  const [godmodePhrase, setGodmodePhrase] = useState("")
  const [godmodeMsg, setGodmodeMsg] = useState<string | null>(null)
  // Plan B enterprise auto-approve phrase gate
  const [entBConfirm, setEntBConfirm] = useState(false)
  const [entBPhrase, setEntBPhrase] = useState("")
  const [entBMsg, setEntBMsg] = useState<string | null>(null)
  // Alias of GODMODE_CONFIRM_PHRASE (companion SECURITY_ARM_CONFIRM_PHRASE) — one literal in this file.
  const ENT_B_PHRASE = GODMODE_CONFIRM_PHRASE
  // auto_approve_dangerous phrase gate (P1-1 — companion requires step-up on arm)
  const [autoDangerConfirm, setAutoDangerConfirm] = useState(false)
  const [autoDangerPhrase, setAutoDangerPhrase] = useState("")
  const [autoDangerMsg, setAutoDangerMsg] = useState<string | null>(null)
  // Trust IA + ADR-021: Autopilot package arm / unattended
  const [autopilotTierPick, setAutopilotTierPick] = useState<AutopilotArmPick>("browser")
  const [autopilotConfirm, setAutopilotConfirm] = useState(false)
  const [autopilotPhrase, setAutopilotPhrase] = useState("")
  const [autopilotMsg, setAutopilotMsg] = useState<string | null>(null)
  const [autopilotBusy, setAutopilotBusy] = useState(false)
  const [advancedGatesOpen, setAdvancedGatesOpen] = useState(false)
  // Vision reuse UX (multi-adversarial P0): banner session + advanced collapse when reused
  const [visionReuseBanner, setVisionReuseBanner] = useState(false)
  const [visionReuseBannerDismissed, setVisionReuseBannerDismissed] = useState(false)
  const [visionReuseHint, setVisionReuseHint] = useState<string | null>(null)
  const [visionAdvancedOpen, setVisionAdvancedOpen] = useState(false)
  const [unattendedAckDesktop, setUnattendedAckDesktop] = useState(false)
  const [unattendedAckSession, setUnattendedAckSession] = useState(false)
  const [unattendedIncludeProtocol, setUnattendedIncludeProtocol] = useState(false)
  // WP5-I4 实验区:删除模型两步确认按钮的待命态(非 store——纯组件内 UI 态)。
  const [modelDeleteArmed, setModelDeleteArmed] = useState(false)
  // Path B M0: engine radio is UI draft until ready model + explicit "启用本机转写".
  const [engineDraft, setEngineDraft] = useState<"browser" | "local" | "system">("browser")
  const [otherWhisperOpen, setOtherWhisperOpen] = useState(false)
  /** Local-only: modelId user clicked download on, until companion state/progress arrives. */
  const [voicePendingDownload, setVoicePendingDownload] = useState<string | null>(null)
  const voicePendingDownloadRef = useRef<string | null>(null)
  voicePendingDownloadRef.current = voicePendingDownload
  /** 模型下载源输入草稿；null = 未编辑，跟随 voiceModel 镜像。 */
  const [voiceEndpointDraft, setVoiceEndpointDraft] = useState<string | null>(null)
  const [activeSettingsPage, setActiveSettingsPage] = useState<SettingsSectionId>("model")
  const settingsPageChosen = useRef(false)
  const selectSettingsPage = useCallback((id: SettingsSectionId, focus = false) => {
    settingsPageChosen.current = true
    setActiveSettingsPage(id)
    requestAnimationFrame(() => {
      const body = document.querySelector<HTMLElement>(".cm-settings-body")
      if (body) body.scrollTop = 0
      if (focus) document.querySelector<HTMLElement>(`[data-settings-page="${id}"] h3`)?.focus()
    })
  }, [])

  const elevatedTrust = isElevatedTrust({
    auto_approve_dangerous: state.config.auto_approve_dangerous,
    auto_approve_enterprise_tools: state.config.auto_approve_enterprise_tools,
    allow_all_schemes: state.config.allow_all_schemes,
    unattendedArmed: state.unattended?.armed === true,
  })

  // P0-2B: check on open whether a WS pairing secret is already stored, so the
  // status badge reflects the real pairing state (not just connection state).
  useEffect(() => {
    if (!state.settingsOpen) return
    // Reset stale pairing feedback + re-check stored-secret presence each open.
    setWsPairingMsg(null)
    // Reset any stale security arm confirmation panels from a previous open.
    setGodmodeConfirm(false)
    setGodmodePhrase("")
    setGodmodeMsg(null)
    setEntBConfirm(false)
    setEntBPhrase("")
    setEntBMsg(null)
    setAutoDangerConfirm(false)
    setAutoDangerPhrase("")
    setAutoDangerMsg(null)
    setAutopilotConfirm(false)
    setAutopilotPhrase("")
    setAutopilotMsg(null)
    setAutopilotBusy(false)
    setUnattendedAckDesktop(false)
    setUnattendedAckSession(false)
    setUnattendedIncludeProtocol(false)
    // Hydrate unattended grant for chip / disarm
    chrome.runtime.sendMessage({ type: "security.unattended.status" })
    // WP5-I4 实验区:打开设置页拉一次模型状态(后续由 state 广播驱动,
    // 无乐观更新);清掉上次打开残留的错误与删除待命态。
    setModelDeleteArmed(false)
    dispatch({ type: "SET_COMPUTER_MODEL_ERROR", error: null })
    chrome.runtime.sendMessage({ type: "computer.model.get_state" })
    // Path B M0: mirror voice.model state on settings open (UI Task 7).
    // Do not blank voiceModelError here — get_state / WS lastDownloadError hydrates it.
    setVoicePendingDownload(null)
    setVoiceEndpointDraft(null)
    chrome.runtime.sendMessage({ type: "voice.model.get_state" }, (resp: unknown) => {
      const lastErr =
        typeof chrome.runtime.lastError?.message === "string"
          ? chrome.runtime.lastError.message
          : null
      const parsed = parseVoiceSettingsSendResponse(resp, lastErr)
      if (parsed.ok === false) {
        dispatch({ type: "SET_VOICE_MODEL_ERROR", error: parsed.error })
      }
    })
    // #259: Windows SAPI probe (win32 → helper/System.Speech rows; other → no-op).
    chrome.runtime.sendMessage({ type: "voice.system.state" })
    chrome.runtime.sendMessage({ type: "ws.getPairingStatus" }, (resp: { paired?: boolean } | undefined) => {
      const paired = !!resp?.paired
      setWsPaired(paired)
      if (!settingsPageChosen.current) setActiveSettingsPage(paired ? "model" : "connection")
    })
    // Coding agents: list even when acp.enabled=false (discovery ≠ feature gate)
    chrome.runtime.sendMessage({ type: "acp.list" }, () => {
      void chrome.runtime.lastError
    })
  }, [state.settingsOpen])

  // Path B M0: sync engine draft from companion SoT when state arrives.
  // - sttEngine local → pull draft to local (committed)
  // - companion local→browser (delete active / set_engine) → reset draft browser
  // - selecting local radio alone never writes set_engine (draft until enable)
  // - do not clobber local draft while companion still reports browser
  const prevVoiceEngineRef = useRef<"browser" | "local" | "system" | null>(null)
  useEffect(() => {
    const eng = state.voiceModel?.sttEngine
    if (!eng) return
    if (eng === "local" || eng === "system") {
      setEngineDraft(eng)
    } else if (
      (prevVoiceEngineRef.current === "local" || prevVoiceEngineRef.current === "system") &&
      eng === "browser"
    ) {
      setEngineDraft("browser")
    }
    prevVoiceEngineRef.current = eng
  }, [state.voiceModel?.sttEngine])

  // Clear local pending-download once companion reports downloading/ready or progress.
  useEffect(() => {
    const pending = voicePendingDownload
    if (!pending) return
    const st = state.voiceModel?.models?.[pending]?.status
    if (st === "downloading" || st === "ready") {
      setVoicePendingDownload(null)
      return
    }
    if (state.voiceModelProgress?.modelId === pending) {
      setVoicePendingDownload(null)
    }
  }, [state.voiceModel, state.voiceModelProgress, voicePendingDownload])

  // Settings open but voice.model.state never arrives → surface timeout (was silent forever).
  useEffect(() => {
    if (!state.settingsOpen) return
    if (state.voiceModel !== null) return
    const t = window.setTimeout(() => {
      dispatch({ type: "SET_VOICE_MODEL_ERROR", error: VOICE_ERR_STATE_TIMEOUT })
    }, 6000)
    return () => window.clearTimeout(t)
  }, [state.settingsOpen, state.voiceModel, dispatch])

  // Download click accepted by SW but no companion progress → surface (was silent).
  useEffect(() => {
    if (!voicePendingDownload) return
    const modelId = voicePendingDownload
    const t = window.setTimeout(() => {
      if (voicePendingDownloadRef.current !== modelId) return
      setVoicePendingDownload(null)
      dispatch({ type: "SET_VOICE_MODEL_ERROR", error: VOICE_ERR_DOWNLOAD_NO_PROGRESS })
      dispatch({ type: "SET_VOICE_MODEL_PROGRESS", progress: null })
    }, 8000)
    return () => window.clearTimeout(t)
  }, [voicePendingDownload, dispatch])

  // Auto-expand advanced gates when any arm flag is on (user can still collapse).
  // Parent「安全与信任」is collapsible; elevated trust only shows header badge.
  useEffect(() => {
    if (!state.settingsOpen) return
    const c = state.config
    if (
      c.auto_approve_dangerous === true ||
      c.auto_approve_enterprise_tools === true ||
      c.allow_all_schemes === true ||
      state.unattended?.armed === true
    ) {
      setAdvancedGatesOpen(true)
    }
  }, [
    state.settingsOpen,
    state.config.auto_approve_dangerous,
    state.config.auto_approve_enterprise_tools,
    state.config.allow_all_schemes,
    state.unattended?.armed,
  ])

  // F-UX7 deep-link: open target accordion section once settings opens.
  useEffect(() => {
    if (!state.settingsOpen || !state.settingsFocusSection) return
    const id = state.settingsFocusSection as SettingsSectionId
    if (!(SETTINGS_SECTION_IDS as readonly string[]).includes(id)) {
      dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
      return
    }
    selectSettingsPage(id, true)
    dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
  }, [state.settingsOpen, state.settingsFocusSection, dispatch, selectSettingsPage])

  /**
   * Text / voice commands for configuring this extension (D2+ UX).
   * MUST stay above the settingsOpen early-return — React #310 if hooks run only when open.
   */
  const applySettingsIntent = useCallback(
    (intent: SettingsIntent): string => {
      if (intent.type.startsWith("set_") || intent.type === "enable_hotkey_default") selectSettingsPage("voice")
      switch (intent.type) {
        case "set_dictation_mode":
          dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: intent.mode })
          return intent.mode === "continuous"
            ? "已开启连续听写"
            : "已切换为经典短听"
        case "set_hotkey_enabled":
          dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: intent.enabled })
          return intent.enabled ? "已启用按住说话热键" : "已关闭按住说话热键"
        case "set_asr_refiner":
          dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: intent.enabled })
          return intent.enabled ? "已开启 ASR 纠错" : "已关闭 ASR 纠错"
        case "set_realtime_streaming":
          dispatch({
            type: "SET_VOICE_REALTIME_STREAMING",
            enabled: intent.enabled,
            preferContinuous: intent.enabled === true,
          })
          return intent.enabled
            ? "已开启实时出字（浏览器字级 interim；本机约 8 秒一段）"
            : "已关闭实时出字优先"
        case "set_stt_engine":
          if (intent.engine === "browser") {
            try {
              chrome.runtime.sendMessage({
                type: "voice.model.set_engine",
                engine: "browser",
                source: "settings",
              })
            } catch {
              /* */
            }
            setEngineDraft("browser")
            return "已切换为浏览器听写（支持字级实时）"
          }
          setEngineDraft("local")
          return "请在「输入与语音 → 听写方式」下载模型后点「启用本机转写」"
        case "enable_hotkey_default":
          dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: true })
          dispatch({
            type: "SET_DICTATION_HOTKEY_CHORD",
            chord: DICTATION_HOTKEY_DEFAULT_CHORD,
          })
          return `已启用热键：${DICTATION_HOTKEY_DEFAULT_CHORD}`
        case "open_meeting":
          dispatch({ type: "SET_SETTINGS_OPEN", open: false })
          host?.openPanelForce("meeting")
          return "已打开会议工作台"
        case "open_packs":
          dispatch({ type: "SET_SETTINGS_OPEN", open: false })
          host?.openPanelForce("packs")
          return "已打开场景面板"
        case "unknown":
        default:
          return "未识别。试试：开启连续听写 / 开启实时出字 / 打开会议 / 浏览器听写"
      }
    },
    [dispatch, host, selectSettingsPage],
  )

  if (!state.settingsOpen) return null

  const config = state.config

  const handleSave = () => {
    if (settingsSaveDisabled(state.configHydratedFromCompanion)) return
    // Probe bit is session-only; never persist native_vision_detected.
    const { native_vision_detected: _drop, ...toSave } = config
    chrome.runtime.sendMessage({ type: "config.set", config: toSave }, () => {
      dispatch({ type: "TOGGLE_SETTINGS" })
    })
  }

  // P0-2B: store the WS shared secret (out-of-band, pasted from
  // `cmspark-agent settings --ws-secret` first-run output) and reconnect so the
  // background WSClient authenticates against the companion's challenge.
  const handleWsPair = () => {
    const secret = wsSecretInput.trim()
    if (!secret) {
      setWsPairingMsg({ ok: false, text: "请粘贴 Companion 输出的配对密钥" })
      return
    }
    setWsPairingMsg({ ok: true, text: "配对中，正在重连…" })
    chrome.runtime.sendMessage({ type: "ws.setSecret", secret }, (resp: { ok?: boolean; error?: string }) => {
      if (resp?.ok) {
        setWsPaired(true)
        setWsSecretInput("")
        setWsPairingMsg({ ok: true, text: "已配对，正在鉴权重连…" })
      } else {
        setWsPairingMsg({ ok: false, text: resp?.error || "配对失败" })
      }
    })
  }

  const handleTrustedDomainsChange = (value: string) => {
    const trusted_domains = value
      .split(/\n|,/)
      .map(domain => domain.trim())
      .filter(Boolean)
    dispatch({ type: "SET_CONFIG", config: { trusted_domains } })
  }

  const handleAutoApprovedDomainsChange = (value: string) => {
    const auto_approved_domains = value
      .split(/\n|,/)
      .map(domain => domain.trim())
      .filter(Boolean)
    dispatch({ type: "SET_CONFIG", config: { auto_approved_domains } })
  }

  // P1-1: arm paths send focused config.set + confirmation_phrase so companion
  // step-up is not UI theater. Disarm needs no phrase. handleSave re-sends
  // already-true flags without phrase (transition-only gate).
  const sendSecurityFlagConfig = (
    partial: Record<string, boolean>,
    confirmation_phrase?: string,
  ) => {
    chrome.runtime.sendMessage({
      type: "config.set",
      config: partial,
      ...(confirmation_phrase != null ? { confirmation_phrase } : {}),
    })
  }

  const handleAutoApproveDangerousChange = (checked: boolean) => {
    if (!checked) {
      dispatch({ type: "SET_CONFIG", config: { auto_approve_dangerous: false } })
      sendSecurityFlagConfig({ auto_approve_dangerous: false })
      setAutoDangerConfirm(false)
      setAutoDangerPhrase("")
      setAutoDangerMsg(null)
      return
    }
    setAutoDangerConfirm(true)
    setAutoDangerPhrase("")
    setAutoDangerMsg(null)
  }

  const handleAutoApproveDangerousConfirm = () => {
    if (autoDangerPhrase.trim() !== GODMODE_CONFIRM_PHRASE) {
      setAutoDangerMsg(`请输入「${GODMODE_CONFIRM_PHRASE}」`)
      return
    }
    const phrase = autoDangerPhrase.trim()
    dispatch({ type: "SET_CONFIG", config: { auto_approve_dangerous: true } })
    sendSecurityFlagConfig({ auto_approve_dangerous: true }, phrase)
    setAutoDangerConfirm(false)
    setAutoDangerPhrase("")
    setAutoDangerMsg(null)
  }

  const handleEnterpriseAutoApproveToggle = (checked: boolean) => {
    if (!checked) {
      dispatch({ type: "SET_CONFIG", config: { auto_approve_enterprise_tools: false } })
      sendSecurityFlagConfig({ auto_approve_enterprise_tools: false })
      setEntBConfirm(false)
      setEntBPhrase("")
      setEntBMsg(null)
      return
    }
    setEntBConfirm(true)
    setEntBPhrase("")
    setEntBMsg(null)
  }

  const handleEnterpriseAutoApproveConfirm = () => {
    if (entBPhrase.trim() !== ENT_B_PHRASE) {
      setEntBMsg(`请输入「${ENT_B_PHRASE}」`)
      return
    }
    const phrase = entBPhrase.trim()
    dispatch({ type: "SET_CONFIG", config: { auto_approve_enterprise_tools: true } })
    sendSecurityFlagConfig({ auto_approve_enterprise_tools: true }, phrase)
    setEntBConfirm(false)
    setEntBPhrase("")
    setEntBMsg(null)
  }

  // PR-B God-mode (security.allow_all_schemes). Bypasses BOTH layers — strictly
  // stronger than auto_approve_dangerous. Arming requires a typed phrase; disarming
  // is frictionless (safe direction). Either direction is recorded as an audit entry
  // (design §B godmode_enabled_changed, source = ui_phrase_confirmed).
  const handleGodModeToggle = (checked: boolean) => {
    if (checked) {
      // Arming: open the typed-confirmation panel, do NOT flip yet.
      setGodmodeConfirm(true)
      setGodmodePhrase("")
      setGodmodeMsg(null)
      return
    }
    // Disarming is safe — flip immediately + audit + companion config.set (no phrase).
    dispatch({ type: "SET_CONFIG", config: { allow_all_schemes: false } })
    sendSecurityFlagConfig({ allow_all_schemes: false })
    dispatch({
      type: "ADD_SECURITY_AUDIT",
      entry: {
        id: `godmode-off-${crypto.randomUUID()}`,
        ts: new Date().toISOString(),
        level: "info",
        tool_name: "allow_all_schemes",
        action: "changed",
        risk_level: "low",
        risk_score: 0,
        source: "ui_phrase_confirmed",
        message: "已关闭协议解锁（恢复协议保护：L1 scheme 硬阻断 + 网页 L2 确认门重新生效）",
      },
    })
  }

  const handleGodModeConfirm = () => {
    if (godmodePhrase.trim() !== SECURITY_ARM_PHRASE) {
      setGodmodeMsg(`确认短语不匹配，请输入「${SECURITY_ARM_PHRASE}」`)
      return
    }
    const phrase = godmodePhrase.trim()
    dispatch({ type: "SET_CONFIG", config: { allow_all_schemes: true } })
    // P1-1: companion requires confirmation_phrase on false→true (not theater).
    sendSecurityFlagConfig({ allow_all_schemes: true }, phrase)
    dispatch({
      type: "ADD_SECURITY_AUDIT",
      entry: {
        id: `protocol-unlock-on-${crypto.randomUUID()}`,
        ts: new Date().toISOString(),
        level: "error",
        tool_name: "allow_all_schemes",
        action: "changed",
        risk_level: "high",
        risk_score: 100,
        source: "ui_phrase_confirmed",
        message:
          "已启用协议解锁（allow_all_schemes）— L1 scheme 硬阻断 + 部分网页 L2 已绕过；不含 shell/CU/spawn forceConfirm",
      },
    })
    setGodmodeConfirm(false)
    setGodmodePhrase("")
    setGodmodeMsg(null)
  }

  const applySecurityFlagsTarget = (
    target: {
      auto_approve_dangerous: boolean
      auto_approve_enterprise_tools: boolean
      allow_all_schemes: boolean
    },
    phrase: string | undefined,
    auditMessage: string,
  ) => {
    const current = {
      auto_approve_dangerous: config.auto_approve_dangerous === true,
      auto_approve_enterprise_tools: config.auto_approve_enterprise_tools === true,
      allow_all_schemes: config.allow_all_schemes === true,
    }
    const toDisarm = flagsNeedingDisarm(current, target)
    const toArm = flagsNeedingArm(current, target)
    for (const k of toDisarm) {
      sendSecurityFlagConfig({ [k]: false })
    }
    for (const k of toArm) {
      if (!phrase) return
      sendSecurityFlagConfig({ [k]: true }, phrase)
    }
    dispatch({ type: "SET_CONFIG", config: { ...target } })
    dispatch({
      type: "ADD_SECURITY_AUDIT",
      entry: {
        id: `autopilot-${crypto.randomUUID()}`,
        ts: new Date().toISOString(),
        level: toArm.length > 0 ? "error" : "info",
        tool_name: "autopilot_packaging",
        action: "changed",
        risk_level: toArm.length > 0 ? "high" : "low",
        risk_score: toArm.length > 0 ? 80 : 0,
        source: "ui_phrase_confirmed",
        message: `${auditMessage} [${[...toArm, ...toDisarm.map((k) => `-${k}`)].join(", ") || "noop"}]`,
      },
    })
  }

  const handleAutopilotArmConfirm = () => {
    if (autopilotPhrase.trim() !== SECURITY_ARM_PHRASE) {
      setAutopilotMsg(`请输入「${SECURITY_ARM_PHRASE}」`)
      return
    }
    if (autopilotTierPick === "unattended") {
      if (!unattendedAckDesktop || !unattendedAckSession) {
        setAutopilotMsg("请勾选两项确认（桌面值守静默 + 会话失效）")
        return
      }
    }
    const phrase = autopilotPhrase.trim()
    setAutopilotBusy(true)

    if (autopilotTierPick === "unattended") {
      // ADR-021: process grant via companion; dual-writes cruise flags server-side.
      // Background ACKs {ok:true|false}; real status arrives via WS broadcast
      // (security.unattended.status → SET_UNATTENDED_STATUS). Do not invent armed:true.
      chrome.runtime.sendMessage(
        {
          type: "security.unattended.arm",
          confirmation_phrase: phrase,
          include_protocol: unattendedIncludeProtocol === true,
          ack_desktop: true,
          ack_session: true,
        },
        (resp?: { ok?: boolean; error?: string }) => {
          const channelErr = chrome.runtime.lastError?.message
          if (channelErr) {
            // Classic MV3: SW did not answer (dead worker / no sendResponse).
            // Still probe status — a prior grant or delayed SW wake may succeed.
            setAutopilotMsg(
              channelErr.includes("message port closed")
                ? "扩展后台未响应（可能已休眠）。请：① 确认 Side Panel 顶部为「已连接」② chrome://extensions 点 CMspark「重新加载」后再试"
                : channelErr,
            )
            setAutopilotBusy(false)
            chrome.runtime.sendMessage({ type: "security.unattended.status" })
            return
          }
          if (resp && resp.ok === false) {
            setAutopilotMsg(resp.error || "武装失败")
            setAutopilotBusy(false)
            return
          }
          dispatch({
            type: "ADD_SECURITY_AUDIT",
            entry: {
              id: `unattended-on-${crypto.randomUUID()}`,
              ts: new Date().toISOString(),
              level: "error",
              tool_name: "unattended_desktop",
              action: "changed",
              risk_level: "high",
              risk_score: 100,
              source: "ui_phrase_confirmed",
              message:
                "已请求武装无人值守 — 进程内桌面 grant 生效（重启失效）。host_computer 的任务级 L2 与 mid-task re-L2 均静默通过（须 App 已允许坐标）。支付/验证码等硬拒绝仍直接失败、无确认窗。自担 prompt 注入与桌面键鼠风险。",
            },
          })
          setAutopilotConfirm(false)
          setAutopilotPhrase("")
          setAutopilotMsg(null)
          setAutopilotBusy(false)
          setAdvancedGatesOpen(true)
          // Reconcile flags + grant from companion (source of truth)
          chrome.runtime.sendMessage({ type: "config.get" })
          chrome.runtime.sendMessage({ type: "security.unattended.status" })
        },
      )
      return
    }

    // Non-unattended: dual-write flags only; clear any leftover unattended grant.
    // Do not invent armed:false — wait for security.unattended.status.
    chrome.runtime.sendMessage({ type: "security.unattended.disarm", clear_cruise: false }, () => {
      chrome.runtime.sendMessage({ type: "security.unattended.status" })
    })
    const target = targetFlagsForTier(
      autopilotTierPick,
      {
        auto_approve_dangerous: config.auto_approve_dangerous,
        auto_approve_enterprise_tools: config.auto_approve_enterprise_tools,
        allow_all_schemes: config.allow_all_schemes,
      },
    )
    applySecurityFlagsTarget(
      target,
      phrase,
      `武装运行自主度：${tierShortLabel(autopilotTierPick as AutopilotTier)}`,
    )
    setAutopilotConfirm(false)
    setAutopilotPhrase("")
    setAutopilotMsg(null)
    setAutopilotBusy(false)
    setAdvancedGatesOpen(true)
  }

  const handleAutopilotDisarm = () => {
    setAutopilotBusy(true)
    // Full disarm: companion SoT for grant + cruise; no optimistic SET_UNATTENDED_STATUS.
    chrome.runtime.sendMessage(
      { type: "security.unattended.disarm", clear_cruise: true },
      () => {
        if (chrome.runtime.lastError) {
          setAutopilotMsg(chrome.runtime.lastError.message || "解除失败（扩展通道）")
          setAutopilotBusy(false)
          return
        }
        applySecurityFlagsTarget(
          disarmAllFlags(),
          undefined,
          "解除运行自主度 / 无人值守（已关闭网页/企业/协议三类自动批准 + 桌面值守；进行中的桌面任务已请求中止）",
        )
        chrome.runtime.sendMessage({ type: "config.get" })
        chrome.runtime.sendMessage({ type: "security.unattended.status" })
        setAutopilotBusy(false)
        setAutopilotConfirm(false)
        setAutopilotPhrase("")
        setAutopilotMsg(null)
      },
    )
  }

  const handleShortcutChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    dispatch({ type: "SET_SEND_SHORTCUT", shortcut: e.target.value as any })
  }

  const handleTest = () => {
    // Reset both result channels — main LLM test always runs, vision test runs
    // only when the user has enabled 截图视觉分析. Showing both side-by-side
    // (instead of overwriting one result) lets the user see e.g. "主 API ✓ /
    // 视觉 ✗" without re-clicking.
    dispatch({ type: "SET_TEST_RESULT", result: "测试中..." })
    if (config.vision_enabled) {
      dispatch({ type: "SET_TEST_VISION_RESULT", result: "测试视觉模型中..." })
    } else {
      dispatch({ type: "SET_TEST_VISION_RESULT", result: null })
    }
    // Pass unsaved UI fields so the probe uses the same protocol/profile/url as Save.
    // api_key only when the user typed a real key; otherwise companion uses stored key.
    const llmOverride: Record<string, string> = {
      base_url: config.base_url,
      model_name: config.model_name,
      protocol: config.protocol === "anthropic" ? "anthropic" : "openai",
      client_header_profile:
        config.protocol === "anthropic" && config.client_header_profile === "claude_code_compat"
          ? "claude_code_compat"
          : "none",
    }
    if (config.api_key && config.api_key !== "***") {
      llmOverride.api_key = config.api_key
    }
    chrome.runtime.sendMessage({ type: "config.test", llmOverride })
    if (config.vision_enabled) {
      chrome.runtime.sendMessage({ type: "config.testVision" })
    }
  }

  const toggleSafetySkill = (skillId: string) => {
    const current = config.safety_skills_enabled || []
    const next = current.includes(skillId)
      ? current.filter(id => id !== skillId)
      : [...current, skillId]
    dispatch({ type: "SET_CONFIG", config: { safety_skills_enabled: next } })
  }

