Final independent closure review #471, READ ONLY. Both reviewers independently reviewed full implementation r1 (base4fd4919b). Now review latest design plus all deltas from that EXACT frozen implementation, and full supporting files. Close/reject outstanding design and implementation findings explicitly; final verdict covers BOTH design and implementation. Do not re-review unchanged 3000-line relocation; event handlers preserved by AST inventory. Reply at most 1500 words, concise actionable findings P0/P1/MAJOR/NIT and explicit final VERDICT APPROVE / APPROVE_WITH_NITS / REJECT. No edits. Distinguish inspected/actual machine observations/assumptions. No invented unseen code. Native platform UX not certified.
Capability: T3 presentation intersects trust; no new L2 classes, protocols, defaults or Agent execution. Existing explicit grant/save handlers unchanged. Changes: category IA, voice/keyboard capture cancellation when hidden, license settings-content inert+post-close focus restoration, status text separate from buttons, scoped save-and-close label, notes grouping, correct settings pointer name, summoner three-action DOM with legacy hidden targets outside composer.
Process correction: r1 packet prematurely claimed Companion all-green, but a stale legacy mark test was still failing then; its review is provisional, NOT gate evidence. The assertion was corrected for intentional no-mark design; latest complete Companion run now actually passes, see exact log tails below. Do not inherit r1 machine claim. No live user configuration or installedapp touched.
Prior open Grok design r2: split live region/buttons; name license modal+inert/Tab/Escape/focus; save scope+closesettings; hide unused nav/select from AT; active/hover/focus recipe; autonomy stays security; pointer display text and session-index note. All now specified/implemented, inspect. DeepSeek design r2 condition autonomy clarified. Prior Grok implementation P1 composer duplicate: #newThreadBar CSS display:none and #chev hidden existed even r1 (false visible assumption), now ALL old hidden targets are outside composer and browser asserts only one visible newthread + exact attach/mic/send row. M1 disclosure spec/36px, M2 notes heading, M3 button sizes addressed. Remaining NIT choices: common status action remains even on its page (intentional consistent status); native select label retains aria-label redundantly but same name; panel/page same h3 existing hierarchy retained (not newly introducing heading omission).

CURRENT DESIGN
# 召唤器与设置重设计

GitHub: #471 · Base:4fd4919b · 2026-09-08

召唤器与主聊天保持同一套浅色、文字层级、圆角输入区和底部操作排布。删除页头、初始及动态空态的“山”，不替换成其他大图标。空态以一句提示开始；历史/新对话保留；附件、听写、发送在输入框下，会议/打开浏览器为次要动作。保留全部 id、协议、状态及确认边界。独立设置网页也改浅色配置表面。

设置改为命名分类导航与单个当前内容页，宽屏左导航、窄屏紧凑分类选择。分类：模型与推理、输入与语音、文件与知识、连接与配对、安全与信任、本机与工具、密钥与环境、实验功能。模型页仅含模型/视觉/推理预算；语音与快捷键独立；上传、笔记导出与会话索引集中到文件与知识；既有权限/集成控件保留并加清楚子标题。

稳定设置 id 保持：model/connection/security/integrations/secrets/experimental；export 显示为文件与知识，新增 voice。旧深链继续可用；语音入口指向 voice。各配置页保持挂载，仅隐藏非当前页，保证未保存输入、权限确认短语和下载状态不因切页丢失。原有控件保存时机保持：全局保存仍统一提交config草稿并关闭设置，立即生效项目保留原语义和说明。配对/高权限状态跨分类可见且可定位。保存/测试只一处常驻，键盘 DOM 顺序与视觉一致，废除 CSS order 排列。

验证：实际 React 页320/390/800/1440与短屏，无横向溢出；每类可达；字段草稿切页保留；旧深链/voice深链；安全标识与原确认控件；真实召唤HTML脚本在隔离传输下新建对话/输入/历史，山不会恢复；生产构建及相关全量套件。Grok4.6 + DeepSeekV4Pro设计/实现独立复审，最终CI全绿后合并；无发布安装。

## 设计门禁补充（首轮意见逐项落实）

### 公共状态与确认可达性

设置标题下、分类/内容区外常驻状态行（320与1440同一DOM，窄屏换行；无状态不占位）。文案：检测中“正在检测连接”；未配对“尚未配对 · 前往连接设置”；已有高权限“有高权限开关已开启 · 查看安全设置”。原生按钮分别切到connection/security并聚焦标题；仅状态文字span使用role=status/aria-live=polite，原生导航按钮作为同级元素，状态更新不抢焦点。高权限沿用isElevatedTrust，不引入新的权限判断。正在编辑的安全确认短语保留在security页，用户可用“安全与信任”分类导航返回（未启用的待确认态不会产生公共高权限提示）；真正的模态许可确认提升到公共内容区外，保持原按钮/顺序/处理器和焦点陷阱，避免被隐藏页遮蔽。

### 保存范围（“一处”指公共配置栏，不删除独立表单按钮）

| 类别 | 保存与测试 | 切页时未保存内容 |
|---|---|---|
| config模型/视觉/上下文/文件/会话索引/白名单/实验标志 | 公共“保存并关闭”调用原handleSave一次，保存完整state.config（剔除只读探测字段），沿用回调关闭设置；公共“测试模型连接”调用原handleTest，测当前草稿模型/视觉参数，与所在页无关 | 留在同一store，切页不保存 |
| 语音/快捷键等本机偏好 | 原即时处理器，页说明标明即时生效；下载/启用各自按钮保留 | React本地草稿保持挂载，不自动提交 |
| UserEnv/MCP/网络/编程开关 | 原独立保存/确认按钮保留，各页说明其独立语义 | 不纳入虚假的“保存所有独立表单”；组件保持挂载 |
| 许可/授权短语 | 原确认流程，公共保存不替代 | 切页不批准；Modal不埋在hidden树 |

公共栏始终展示“保存并关闭”“测试模型连接”，不使用“取消全部更改”承诺。页说明明确独立保存与即时生效，原config hydration门禁不动。

### 完整移动清单与稳定标识

| id（旧入口仍兼容） | 展示名 | 原控件归属 |
|---|---|---|
| model | 模型与推理 | 原model中协议/端点/key/预设/模型/主模型看图/温度 + Context Window/压缩/思考 + 完整视觉模型块；删除语音/文件块 |
| voice（新增） | 输入与语音 | 原model中“发送快捷键”起，到“Context Window”前的完整语音块（浏览器/本机/系统引擎、隐私、refiner、热键、下载/说话人模型） |
| export | 文件与知识 | 原model的File Upload Settings整个块 + 原experimental的Thread History IA session index块 + 原export所有笔记导出字段 |
| connection | 连接与配对 | 原connection完整块 |
| security | 安全与信任 | 原security完整块，所有arm/disarm/短语/警告/白名单不变 |
| integrations | 本机与工具 | 原integrations完整CapabilityProfile/NetSec/OutboundMcp/CodingHandoff及全部props；“下方自主度”改明确指向安全分类 |
| secrets | 密钥与环境 | 完整UserEnvSection |
| experimental | 实验功能 | 原实验本地视觉模型/许可证/下载管理；会话索引移出 |

useComposerVoice的原model深链改voice；所有设置自然语言的语音intent选voice，open_meeting/open_scene继续离开设置。其余model/integrations/export旧深链仍选同id页。旧折叠偏好不删除，新的单页布局不再消费它；会话首次默认model，未知/未配对回调在用户尚未选页时选connection；明确深链/人工选页不被迟到配对回调覆盖。分类选择在当前设置组件会话内保留。

### 导航与视觉规格

>=760：172px浅灰左侧nav，原生button（Tab/Enter/Space），aria-current=page；激活聚焦内容h3 tabindex=-1并将内容滚动归零。<760：有可见“设置分类”标签的原生select（系统键盘行为），选择后保留select焦点，内容标题同步；非当前页hidden，仍挂载且不进入Tab。对话框高度88dvh（窄屏94dvh），中间内容独立滚动，底部配置栏常驻。标题20px（窄屏18）、正文13–14、说明12、控件>=36px；浅色表面、8px控件圆角、16px外框、24/16px边距，沿用tokens。

召唤HTML以CSS变量镜像chat：paper #fff、canvas #f7f7f5、text #171717、secondary #666、focus #4f46e5、send #242424、user bubble #f3f3f1；系统字体14px/1.7，输入圆角20px、操作36px。页头纯文字CMspark+历史/新对话/既有档位，空态沿用CHAT_SHELL_TITLE_NONE，副行“回车发送。附件和听写不用开浏览器。”。输入textarea在前，附件→听写→发送按真实DOM排列；会议/打开浏览器留在输入区下方描边次按钮。不藏进菜单。山全源搜索：只在页头、初始空态、renderMsgs空态三个位置，无其他loading/error图标路径；三处全部删除。

独立settings-web是只配置全局模型的备用网页，不伪造扩展八类能力；沿用浅色表面、中文页名和表单层级，原端点/权限范围不扩展。

### 收口澄清

运行自主度原本就在security，继续完整留在“安全与信任”；integrations只有指向说明，不移动或复制该控件。原安全页badge保留，公共状态行补足隐藏该页时的可见性。分类选择保留于SettingsSlideout的React挂载生命周期（关闭重开不重置），重载应用后重新按连接状态选择。深链仍是原有section级入口，没有新增/承诺字段级锚点。自然语言分类器不扩展，open_meeting/open_packs沿用原操作入口，其余现有set_*与enable_hotkey_default才定位语音页。独立settings-web此前固定深色，本次按用户要求统一为固定浅色，不声称保留并不存在的主题切换。

折叠设置助手和关闭设置时取消未结束语音识别，以代际编号忽略迟到的result/error/end回调；取消不能执行设置命令。保留原显式停止后处理已识别文本的行为。实际合成SpeechRecognition验证“开始→折叠→迟到结束”无设置变更。

## 末轮明确约定

公共保存按钮为“保存并关闭”，提示“保存配置草稿；独立表单与授权需分别提交。”它保存原state.config范围并关闭，不提交UserEnv、独立网络授权、许可、模型下载或尚未确认的arm短语。安全页的白名单等config草稿属于公共保存；arm/disarm保留各自立即确认；实验页的config标志属于公共保存，但许可证和下载不属于。

许可证门具体指“实验层许可证与免责声明”。从任意分类收到license_required都显示；常规设置内容（含页头/导航/保存）保持挂载但inert，许可Modal在其外。Tab/Shift+Tab仅在许可拒绝/接受之间，Escape只关闭许可不关闭设置、不发accepted:true；关闭后下一帧恢复到先前设置焦点，避免inert撤销前焦点丢失。许可期间设置深链排队至关闭后执行。许可语义与原按钮顺序不变，不改变共享Modal或全局键盘框架。

宽屏select为display:none，窄屏nav为display:none，因此两套选择器不会同时进入Tab或可访问树。桌面选中背景navSelected、字重600；悬停bgHover；按钮/select/summary与内容h3的focus-visible均为2px accent轮廓。配置标题与说明保持页面层级；控制按钮最小36px。h3聚焦是页面切换反馈；原生select保持自身焦点并宣告选中分类。

“用一句话调整设置”作为各分类上方始终可见的summary，默认折叠，以减少每页固定说明占用；36px目标。展开可用原文字/语音设置助手，折叠、关闭或许可覆盖时取消语音。主设置表单仍是首要操作方式。

文件与知识补“笔记导出”子标题，导出思考选项也移动到此处；会话索引旧experimental注释移除。本机与工具保留能力档位/网络扫描/对外MCP/编程助手子组件自己的标题，并更新settings-pointer可见路径为“设置 → 本机与工具 → 网络扫描（NetSec）”。稳定integrations id不变。

召唤器原newThreadBar、chev、settings均是旧版已隐藏的处理器目标，本次将它们集中到composer外hidden容器保留绑定；可见输入操作严格为附件、听写、发送，只有页头一个新对话。真实浏览器断言三按钮顺序与新对话唯一性。浅色chat tokens为视觉基准；本轮不新增暗色开关。

快捷键录制仅在语音分类可见且无许可证覆盖时监听键盘；切分类取消录制，避免隐藏控件截获其他分类输入。

EXACT DELTA FROM FROZEN R1
--- reviewed-r1/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
+++ current/chrome-extension/src/sidepanel/components/SettingsSlideout.tsx
@@ -175,7 +175,18 @@
   voicePendingDownloadRef.current = voicePendingDownload
   /** 模型下载源输入草稿；null = 未编辑，跟随 voiceModel 镜像。 */
   const [voiceEndpointDraft, setVoiceEndpointDraft] = useState<string | null>(null)
+  const [settingsAssistantOpen, setSettingsAssistantOpen] = useState(false)
   const [activeSettingsPage, setActiveSettingsPage] = useState<SettingsSectionId>("model")
+  const lastSettingsFocus = useRef<HTMLElement | null>(null)
+  const licenseWasOpen = useRef(false)
+  useEffect(() => {
+    const open = licenseDoorShouldOpen(state.computerModelLicenseDoor)
+    const restore = licenseWasOpen.current && !open && state.settingsOpen && !state.settingsFocusSection
+    licenseWasOpen.current = open
+    if (!restore) return
+    const frame = requestAnimationFrame(() => lastSettingsFocus.current?.focus())
+    return () => cancelAnimationFrame(frame)
+  }, [state.computerModelLicenseDoor, state.settingsOpen, state.settingsFocusSection])
   const settingsPageChosen = useRef(false)
   const selectSettingsPage = useCallback((id: SettingsSectionId, focus = false) => {
     settingsPageChosen.current = true
@@ -331,7 +342,7 @@
 
   // F-UX7 deep-link: open target accordion section once settings opens.
   useEffect(() => {
-    if (!state.settingsOpen || !state.settingsFocusSection) return
+    if (!state.settingsOpen || !state.settingsFocusSection || licenseDoorShouldOpen(state.computerModelLicenseDoor)) return
     const id = state.settingsFocusSection as SettingsSectionId
     if (!(SETTINGS_SECTION_IDS as readonly string[]).includes(id)) {
       dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
@@ -339,7 +350,7 @@
     }
     selectSettingsPage(id, true)
     dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
-  }, [state.settingsOpen, state.settingsFocusSection, dispatch, selectSettingsPage])
+  }, [state.settingsOpen, state.settingsFocusSection, state.computerModelLicenseDoor, dispatch, selectSettingsPage])
 
   /**
    * Text / voice commands for configuring this extension (D2+ UX).
@@ -802,12 +813,14 @@
       panelClassName="cm-settings-panel"
       ariaLabel="设置"
     >
+        <div className="cm-settings-content" onFocusCapture={event => { lastSettingsFocus.current = event.target as HTMLElement }} {...(licenseDoorShouldOpen(state.computerModelLicenseDoor) ? { inert: "" } : {})}>
         <div className="cm-settings-header" style={styles.header}>
           <h3 style={{ margin: 0, fontSize: 15 }}>设置</h3>
           <button type="button" aria-label="关闭设置" className="cm-icon-button" style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
         </div>
 
-        <div className="cm-settings-status" role="status" aria-live="polite">
+        <div className="cm-settings-status">
+          <span className="cm-sr-only" role="status" aria-live="polite">{[wsPaired === null ? "正在检测连接" : wsPaired === false ? "尚未配对" : "", elevatedTrust ? "有高权限开关已开启" : ""].filter(Boolean).join("；")}</span>
           {wsPaired !== true && <button type="button" onClick={() => selectSettingsPage("connection", true)}>{wsPaired === null ? "正在检测连接" : "尚未配对 · 前往连接设置"}</button>}
           {elevatedTrust && <button type="button" onClick={() => selectSettingsPage("security", true)}>有高权限开关已开启 · 查看安全设置</button>}
         </div>
@@ -819,7 +832,7 @@
             <select aria-label="设置分类" value={activeSettingsPage} onChange={event => selectSettingsPage(event.target.value as SettingsSectionId)}>{SETTINGS_PAGES.map(page => <option value={page.id} key={page.id}>{page.title}</option>)}</select>
           </label>
           <div className="cm-settings-body" style={styles.body}>
-            <details className="cm-settings-assistant"><summary>用一句话调整设置</summary><SettingsIntentBar onIntent={applySettingsIntent} /></details>
+            <details className="cm-settings-assistant" onToggle={event => setSettingsAssistantOpen(event.currentTarget.open)}><summary>用一句话调整设置</summary><SettingsIntentBar onIntent={applySettingsIntent} active={settingsAssistantOpen && state.settingsOpen && !licenseDoorShouldOpen(state.computerModelLicenseDoor)} /></details>
 
           <div data-settings-page="connection" hidden={activeSettingsPage !== "connection"}>
             <SettingsPage
@@ -882,7 +895,7 @@
             )}
           </div>
 
-          
+
             </SettingsPage>
           </div>
 
@@ -1136,6 +1149,12 @@
             </div>
           </div>
 
+              <div style={styles.field}>
+                <div style={styles.helpText}>
+                  上下文窗口过大时，长对话压缩会来不及触发（新默认 512000 是 Agent 工作预算）。建议按模型真实上限设置。
+                </div>
+              </div>
+
           <div style={styles.field}>
             <label style={styles.label}>长对话上下文预算</label>
             <select
@@ -1202,22 +1221,6 @@
             </select>
             <div style={styles.helpText}>
               仅影响 Side Panel 显示。历史消息不会把思考回灌给模型（省 token / 兼容 Anthropic）。
-            </div>
-          </div>
-
-          <div style={styles.field}>
-            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
-              <input
-                type="checkbox"
-                checked={state.exportIncludeReasoning === true}
-                onChange={(e) =>
-                  dispatch({ type: "SET_EXPORT_INCLUDE_REASONING", enabled: e.target.checked })
-                }
-              />
-              导出 Markdown 时包含思考过程
-            </label>
-            <div style={styles.helpText}>
-              默认关闭。开启后以折叠块写入笔记；请注意思考可能含中间假设，勿默认分享。
             </div>
           </div>
 
@@ -1479,11 +1482,6 @@
             )
           })()}
 
-              <div style={styles.field}>
-                <div style={styles.helpText}>
-                  上下文窗口过大时，长对话压缩会来不及触发（新默认 512000 是 Agent 工作预算）。建议按模型真实上限设置。
-                </div>
-              </div>
             </SettingsPage>
           </div>
 
@@ -1666,6 +1664,7 @@
                 <div style={{ marginTop: 8, fontSize: 11, color: tokens.textSecondary }}>
                   <div style={{ marginBottom: 2 }}>组合键（按键盘录制或点预设）</div>
                   <HotkeyCaptureField
+                    active={activeSettingsPage === "voice" && state.settingsOpen && !licenseDoorShouldOpen(state.computerModelLicenseDoor)}
                     value={state.dictationHotkeyChord || DICTATION_HOTKEY_DEFAULT_CHORD}
                     disabled={!state.dictationHotkeyEnabled}
                     onChange={(chord) =>
@@ -2541,7 +2540,7 @@
           {/* --- User env / Secrets (ADR-019) — independent of bottom config Save --- */}
           <UserEnvSection />
 
-          
+
             </SettingsPage>
           </div>
 
@@ -3162,7 +3161,7 @@
             )}
           </div>
 
-          
+
             </SettingsPage>
           </div>
 
@@ -3306,7 +3305,7 @@
             }}
           />
 
-          
+
             </SettingsPage>
           </div>
 
@@ -3364,7 +3363,7 @@
             </div>
           </div>
 
-          {/* Thread History IA Wave B — session index (thread-list IA, not export) */}
+          {/* Thread History IA Wave B — session index (file and knowledge settings) */}
           <div style={styles.sectionTitle}>会话索引（标签 / 要点）</div>
           <div style={styles.field}>
             <label style={styles.label}>打开列表时惰性提取要点</label>
@@ -3441,6 +3440,24 @@
           <div style={styles.divider} />
 
           {/* --- Markdown export (optional note-folder conventions) --- */}
+          <div style={styles.sectionTitle}>笔记导出</div>
+          <div style={styles.field}>
+            <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
+              <input
+                type="checkbox"
+                checked={state.exportIncludeReasoning === true}
+                onChange={(e) =>
+                  dispatch({ type: "SET_EXPORT_INCLUDE_REASONING", enabled: e.target.checked })
+                }
+              />
+              导出 Markdown 时包含思考过程
+            </label>
+            <div style={styles.helpText}>
+              默认关闭。开启后以折叠块写入笔记；请注意思考可能含中间假设，勿默认分享。
+            </div>
+          </div>
+
+
           <div style={styles.field}>
             <label style={styles.label}>笔记库路径（可选）</label>
             <input
@@ -4135,6 +4152,51 @@
 
         </div>
 
+        <div className="cm-settings-footer" style={styles.footer}>
+          <div style={{ display: "flex", flexDirection: "column", gap: 2, marginRight: "auto", textAlign: "left" }}>
+            <span className="cm-settings-save-scope">保存配置草稿；独立表单与授权需分别提交。</span>
+            {state.testResult && (
+              <span style={{
+                fontSize: 12,
+                color: state.testResult.includes("成功") ? tokens.success : tokens.danger,
+              }}>{state.testResult}</span>
+            )}
+            {state.testVisionResult && (
+              <span style={{
+                fontSize: 12,
+                color: state.testVisionResult.includes("成功") ? tokens.success : tokens.danger,
+              }}>{state.testVisionResult}</span>
+            )}
+          </div>
+          <button style={styles.testBtn} onClick={handleTest}>
+            {config.vision_enabled ? "测试模型连接（含视觉）" : "测试模型连接"}
+          </button>
+          <button
+            style={{
+              ...styles.saveBtn,
+              ...(settingsSaveDisabled(state.configHydratedFromCompanion)
+                ? { opacity: 0.5, cursor: "not-allowed" }
+                : {}),
+            }}
+            className="cm-settings-save"
+            onClick={handleSave}
+            disabled={settingsSaveDisabled(state.configHydratedFromCompanion)}
+            title={settingsSaveDisabledTitle(state.configHydratedFromCompanion)}
+          >保存并关闭</button>
+        </div>
+
+        {state.companionConfig && (
+          <div style={{
+            fontSize: 11,
+            color: tokens.textMuted,
+            padding: "8px 16px",
+            borderTop: `1px solid ${tokens.border}`,
+            textAlign: "center",
+          }}>
+            Companion 全局配置已同步{state.companionConfig.model_name ? ` (${state.companionConfig.model_name})` : ""}
+          </div>
+        )}
+        </div>
           {/* 许可证门:渲染 license_required 载荷原文(LICENSE_DOOR_TEXT 单一真源
               在 companion model-license.ts,扩展不复制不私编) */}
           {licenseDoorShouldOpen(state.computerModelLicenseDoor) && (
@@ -4177,49 +4239,7 @@
             </Modal>
           )}
 
-          
-        <div className="cm-settings-footer" style={styles.footer}>
-          <div style={{ display: "flex", flexDirection: "column", gap: 2, marginRight: "auto", textAlign: "left" }}>
-            {state.testResult && (
-              <span style={{
-                fontSize: 12,
-                color: state.testResult.includes("成功") ? tokens.success : tokens.danger,
-              }}>{state.testResult}</span>
-            )}
-            {state.testVisionResult && (
-              <span style={{
-                fontSize: 12,
-                color: state.testVisionResult.includes("成功") ? tokens.success : tokens.danger,
-              }}>{state.testVisionResult}</span>
-            )}
-          </div>
-          <button style={styles.testBtn} onClick={handleTest}>
-            {config.vision_enabled ? "测试模型连接（含视觉）" : "测试模型连接"}
-          </button>
-          <button
-            style={{
-              ...styles.saveBtn,
-              ...(settingsSaveDisabled(state.configHydratedFromCompanion)
-                ? { opacity: 0.5, cursor: "not-allowed" }
-                : {}),
-            }}
-            onClick={handleSave}
-            disabled={settingsSaveDisabled(state.configHydratedFromCompanion)}
-            title={settingsSaveDisabledTitle(state.configHydratedFromCompanion)}
-          >保存全部配置</button>
-        </div>
-
-        {state.companionConfig && (
-          <div style={{
-            fontSize: 11,
-            color: tokens.textMuted,
-            padding: "8px 16px",
-            borderTop: `1px solid ${tokens.border}`,
-            textAlign: "center",
-          }}>
-            Companion 全局配置已同步{state.companionConfig.model_name ? ` (${state.companionConfig.model_name})` : ""}
-          </div>
-        )}
+
     </Modal>
   )
 }
--- reviewed-r1/chrome-extension/src/sidepanel/ui/workspace-styles.ts
+++ current/chrome-extension/src/sidepanel/ui/workspace-styles.ts
@@ -31,8 +31,6 @@
 .cm-composer-capsule:focus-within{border-color:${tokens.accent}!important;box-shadow:${tokens.shadowFocus}!important}
 .cm-workspace button:focus-visible,.cm-workspace [role="button"]:focus-visible,.cm-workspace input:focus-visible,.cm-workspace textarea:focus-visible,[role="dialog"] button:focus-visible,[role="dialog"] input:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
 .cm-workspace button:disabled{cursor:not-allowed}
-.cm-settings-categories{display:flex;gap:6px;flex-wrap:wrap;padding:12px 24px;border-bottom:1px solid ${tokens.border};flex-shrink:0}
-.cm-settings-categories button{font:inherit;font-size:12px;border:1px solid ${tokens.border};background:${tokens.bgMuted};color:${tokens.text};border-radius:8px;min-height:32px;padding:4px 10px;cursor:pointer}
 .cm-settings-panel{width:min(780px,100vw - 32px)!important;max-height:88dvh!important;border-radius:${tokens.radiusSheet}px!important;box-shadow:${tokens.shadowLg}}
 .cm-settings-header{padding:20px 24px!important}
 .cm-settings-body{padding:8px 24px 24px!important}
@@ -42,11 +40,16 @@
 .cm-history-panel{max-width:720px;margin:0 auto}
 .cm-history-panel button:focus-visible,.cm-history-panel [role="button"]:focus-visible{outline:2px solid ${tokens.accent};outline-offset:-2px}
 @media(min-width:760px){.cm-navigation-toggle{display:none!important}.cm-status-rail{padding:12px 24px!important;border-bottom:1px solid ${tokens.border}!important}.cm-chat-scroll{padding:28px 32px!important}.cm-composer-dock{padding-bottom:24px!important}}
-@media(max-width:759px){.cm-workspace{flex-direction:column}.cm-navigation-disclosure{flex-shrink:0;max-height:28dvh;overflow:auto;border-bottom:1px solid ${tokens.border}}.cm-navigation-disclosure .cm-navigation{height:auto;width:100%}.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-panel{align-self:flex-end;width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-categories{padding:8px 16px;max-height:100px;overflow:auto}.cm-settings-body{padding:8px 16px 16px!important}}
+@media(max-width:759px){.cm-workspace{flex-direction:column}.cm-navigation-disclosure{flex-shrink:0;max-height:28dvh;overflow:auto;border-bottom:1px solid ${tokens.border}}.cm-navigation-disclosure .cm-navigation{height:auto;width:100%}.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-panel{align-self:flex-end;width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-body{padding:8px 16px 16px!important}}
 @media(max-height:560px){.cm-context-panel{max-height:28dvh!important}.cm-composer-dock{padding-top:4px!important;padding-bottom:6px!important}.cm-navigation{padding-top:10px}.cm-nav-brand{padding-bottom:8px}.cm-nav-resources{margin-bottom:4px}.cm-nav-new{margin-bottom:2px}}
 @media(prefers-reduced-motion:reduce){.cm-workspace *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
 
 .cm-settings-panel{width:min(980px,100vw - 32px)!important;height:88dvh;max-height:88dvh!important}
+.cm-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap;border:0}
+.cm-settings-content{display:flex;flex-direction:column;flex:1;min-height:0}
+.cm-settings-save-scope{font-size:11px;color:${tokens.textSecondary};line-height:1.5}
+.cm-settings-panel button{min-height:36px}
+.cm-settings-page-heading h3:focus-visible,.cm-settings-panel select:focus-visible,.cm-settings-panel summary:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
 .cm-settings-layout{display:flex;flex:1;min-height:0;overflow:hidden}
 .cm-settings-nav{box-sizing:border-box;width:172px;flex-shrink:0;padding:16px 10px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};overflow-y:auto}
 .cm-settings-nav button{display:block;width:100%;min-height:40px;padding:10px 12px;margin:2px 0;border:0;border-radius:8px;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:13px;text-align:left;cursor:pointer}
@@ -54,17 +57,18 @@
 .cm-settings-nav button:hover{background:${tokens.bgHover}}
 .cm-settings-layout .cm-settings-body{flex:1;min-width:0;padding:20px 28px 28px!important;overflow:auto}
 .cm-settings-page-heading{padding:0 0 20px;margin-bottom:16px;border-bottom:1px solid ${tokens.border}}
+.cm-settings-page-title{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
 .cm-settings-page-heading h3{font-size:20px;font-weight:600;letter-spacing:-.03em;margin:0 0 8px}
 .cm-settings-page-heading p{font-size:12px;line-height:1.7;color:${tokens.textSecondary};margin:8px 0 0}
 .cm-settings-status{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 8px}
-.cm-settings-status:empty{display:none}
-.cm-settings-status button{background:${tokens.warningSoft};color:${tokens.text};border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;min-height:32px;font:inherit;font-size:12px;cursor:pointer}
+.cm-settings-status:not(:has(button)){padding:0}
+.cm-settings-status button{background:${tokens.warningSoft};color:${tokens.text};border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;min-height:36px;font:inherit;font-size:12px;cursor:pointer}
 .cm-settings-assistant{margin-bottom:20px;font-size:12px;color:${tokens.textSecondary}}
-.cm-settings-assistant summary{cursor:pointer;min-height:28px}
+.cm-settings-assistant summary{cursor:pointer;min-height:36px}
 .cm-settings-mobile-category{display:none}
 .cm-settings-footer{flex-wrap:wrap;padding:12px 24px!important;gap:8px!important}
 .cm-settings-footer button{min-height:36px}
-.cm-settings-footer button:last-child{background:${tokens.actionPrimary}!important}
+.cm-settings-footer .cm-settings-save{background:${tokens.actionPrimary}!important}
 .cm-settings-body input,.cm-settings-body select,.cm-settings-body textarea{max-width:100%;box-sizing:border-box}
 @media(max-width:759px){.cm-settings-panel{height:94dvh;max-height:94dvh!important;width:100%!important}.cm-settings-layout{flex-direction:column}.cm-settings-nav{display:none}.cm-settings-mobile-category{display:flex;align-items:center;gap:12px;padding:10px 16px;background:${tokens.bgMuted};border-bottom:1px solid ${tokens.border};font-size:12px;color:${tokens.textSecondary}}.cm-settings-mobile-category select{flex:1;min-width:0;min-height:36px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;background:${tokens.bg};color:${tokens.text};font:inherit}.cm-settings-layout .cm-settings-body{padding:16px!important}.cm-settings-status{padding:0 16px 8px}.cm-settings-page-heading h3{font-size:18px}.cm-settings-footer{padding:10px 16px!important}}
 .cm-settings-body input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),.cm-settings-body select{min-height:36px}
--- reviewed-r1/chrome-extension/src/sidepanel/utils/settings-sections.ts
+++ current/chrome-extension/src/sidepanel/utils/settings-sections.ts
@@ -1,9 +1,9 @@
-// Settings accordion expand state — pure helpers (settings-thread-compact W1).
+// Stable settings deep-link IDs. Legacy accordion preference helpers remain for compatibility.
 // Spec: docs/superpowers/specs/2026-08-06-settings-thread-compact-ux.md
 
 export const LS_SETTINGS_EXPAND = "cmspark.settings.expandSections"
 
-/** Canonical section ids (order = IA). */
+/** Canonical ids; SettingsPage.SETTINGS_PAGES owns presentation order. */
 export const SETTINGS_SECTION_IDS = [
   "connection",
   "model",
--- reviewed-r1/companion/src/settings-web.ts
+++ current/companion/src/settings-web.ts
@@ -517,11 +517,11 @@
 <style>
 /*
  * Settings dark-surface tokens — single source mirroring the Side Panel
- * tokens.ts dark family (chrome-extension/src/sidepanel/ui/tokens.ts).
+ * tokens.ts light family (chrome-extension/src/sidepanel/ui/tokens.ts).
  * Companion cannot import the extension's TS tokens (package boundary), so
  * these CSS variables are a hand-mirrored copy — same pattern as the other
  * non-extension HTML surface summoner-web.ts (:root block, summoner-web.ts
- * ~1157; it mirrors the light family, this surface mirrors the dark family).
+ * ~1157; it mirrors the light family, this surface also mirrors the light family).
  * NEVER reintroduce Material palette hexes here (tokens.ts:185 bans them on
  * the side panel; same rule now applies to this surface).
  */
@@ -583,10 +583,10 @@
 <div class="container">
   <div class="card">
     <h1>CMspark 设置 <span class="status-dot" id="statusDot"></span></h1>
-    <div class="subtitle">Companion global LLM config &mdash; fallback for threads without override</div>
+    <div class="subtitle">Companion 全局模型配置 · 用于未单独配置模型的对话</div>
 
     <div class="divider"></div>
-    <div class="section-title">LLM Config</div>
+    <div class="section-title">对话模型</div>
 
     <div class="field">
       <label>API Key</label>
--- reviewed-r1/companion/src/summoner-web.ts
+++ current/companion/src/summoner-web.ts
@@ -1394,7 +1394,7 @@
 
 /* #469 shared workspace craft; transport and capture ACL are unchanged. */
 button:focus-visible,input:focus-visible,textarea:focus-visible{outline:2px solid var(--indigo);outline-offset:2px}
-@media(min-width:760px){.log,.composer{width:100%;max-width:780px;margin-left:auto;margin-right:auto}.brand{padding:16px 24px 12px}}
+@media(min-width:760px){.log,.composer{width:100%;max-width:780px;margin-left:auto;margin-right:auto}}
 @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
 
 /* #471: same conversation hierarchy as the extension workspace. */
@@ -1460,11 +1460,20 @@
       </div>
     </section>
   </div>
-  <div class="composer">
-    <div class="composer-row">
+  <!-- Retained handler targets, excluded from the composer and accessibility tree. -->
+  <div hidden>
       <button class="icon-btn" id="newThreadBar" type="button" title="新对话" aria-label="新对话">
         <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
       </button>
+        <button class="icon-btn" id="chev" type="button" hidden aria-pressed="true" title="${SUMMONER_CHEVRON_COLLAPSE}" aria-label="${SUMMONER_CHEVRON_COLLAPSE}">
+          <svg viewBox="0 0 24 24"><path d="M6 14l6-6 6 6"/></svg>
+        </button>
+        <button class="icon-btn" id="settings" type="button" hidden title="设置（快捷键等）" aria-label="设置">
+          <svg viewBox="0 0 24 24"><path d="M12.2 2.2a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V3a.8.8 0 0 1 .8-.8zm0 16a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V19a.8.8 0 0 1 .8-.8zM19.1 7.4a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1l-2.6 2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zM4.9 16.6a.8.8 0 0 1 0-1.1l2.6-2.6a.8.8 0 0 1 1.1 0 .8.8 0 0 1 0 1.1L7.1 15.5l1.5 1.5a.8.8 0 0 1 0 1.1l-1.9 1.9a.8.8 0 0 1-1.1 0zm0-9.2a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1L7.3 13l2.6 2.6a.8.8 0 0 1-1.1 0l-1.9-1.9a.8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zm14.2 9.2a.8.8 0 0 1 0-1.1l-2.6-2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0 1.1l1.5 1.5-1.5 1.5a.8.8 0 0 1 0 1.1l1.9 1.9a.8.8 0 0 1 1.1 0z"/></svg>
+        </button>
+  </div>
+  <div class="composer">
+    <div class="composer-row">
       <input type="file" id="files" multiple hidden>
       <div class="field">
         <textarea id="text" rows="1" placeholder="问 CMspark…" aria-label="发送到当前对话"></textarea>
@@ -1477,12 +1486,6 @@
         </button>
         <button class="icon-btn" id="sendGo" type="button" title="发送" aria-label="发送">
           <svg viewBox="0 0 24 24"><path d="M5 12h12M13 6l6 6-6 6"/></svg>
-        </button>
-        <button class="icon-btn" id="chev" type="button" hidden aria-pressed="true" title="${SUMMONER_CHEVRON_COLLAPSE}" aria-label="${SUMMONER_CHEVRON_COLLAPSE}">
-          <svg viewBox="0 0 24 24"><path d="M6 14l6-6 6 6"/></svg>
-        </button>
-        <button class="icon-btn" id="settings" type="button" hidden title="设置（快捷键等）" aria-label="设置">
-          <svg viewBox="0 0 24 24"><path d="M12.2 2.2a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V3a.8.8 0 0 1 .8-.8zm0 16a.8.8 0 0 1 .8.8v2.6a.8.8 0 0 1-.8.8H11.8a.8.8 0 0 1-.8-.8V19a.8.8 0 0 1 .8-.8zM19.1 7.4a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1l-2.6 2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zM4.9 16.6a.8.8 0 0 1 0-1.1l2.6-2.6a.8.8 0 0 1 1.1 0 .8.8 0 0 1 0 1.1L7.1 15.5l1.5 1.5a.8.8 0 0 1 0 1.1l-1.9 1.9a.8.8 0 0 1-1.1 0zm0-9.2a.8.8 0 0 1 1.1 0l1.9 1.9a.8.8 0 0 1 0 1.1L7.3 13l2.6 2.6a.8.8 0 0 1-1.1 0l-1.9-1.9a.8.8 0 0 1 0-1.1l1.5-1.5-1.5-1.5a.8.8 0 0 1 0-1.1zm14.2 9.2a.8.8 0 0 1 0-1.1l-2.6-2.6a.8.8 0 0 1-1.1 0 .8.8 0 0 1 0 1.1l1.5 1.5-1.5 1.5a.8.8 0 0 1 0 1.1l1.9 1.9a.8.8 0 0 1 1.1 0z"/></svg>
         </button>
         </div>
       </div>
diff --git a/chrome-extension/src/sidepanel/components/HotkeyCaptureField.tsx b/chrome-extension/src/sidepanel/components/HotkeyCaptureField.tsx
index 13d10d2d..74c84f02 100644
--- a/chrome-extension/src/sidepanel/components/HotkeyCaptureField.tsx
+++ b/chrome-extension/src/sidepanel/components/HotkeyCaptureField.tsx
@@ -10,6 +10,7 @@ import { tokens } from "../ui/tokens"
 export type HotkeyCaptureFieldProps = {
   value: string
   disabled?: boolean
+  active?: boolean
   onChange: (chord: string) => void
   /** Optional presets shown as chips */
   presets?: string[]
@@ -18,6 +19,7 @@ export type HotkeyCaptureFieldProps = {
 export function HotkeyCaptureField({
   value,
   disabled,
+  active = true,
   onChange,
   presets = [
     "Control+Shift+Space",
@@ -35,6 +37,7 @@ export function HotkeyCaptureField({
   }, [])
 
   useEffect(() => {
+    if (!active) { setCapturing(false); return }
     if (!capturing) return
     const onKeyDown = (e: KeyboardEvent) => {
       e.preventDefault()
@@ -70,7 +73,7 @@ export function HotkeyCaptureField({
       window.removeEventListener("keydown", onKeyDown, true)
       window.removeEventListener("blur", onBlur)
     }
-  }, [capturing, onChange, stopCapture])
+  }, [active, capturing, onChange, stopCapture])
 
   useEffect(() => {
     if (capturing) boxRef.current?.focus()
diff --git a/chrome-extension/src/sidepanel/components/SettingsIntentBar.tsx b/chrome-extension/src/sidepanel/components/SettingsIntentBar.tsx
index 37f22143..f3a01d12 100644
--- a/chrome-extension/src/sidepanel/components/SettingsIntentBar.tsx
+++ b/chrome-extension/src/sidepanel/components/SettingsIntentBar.tsx
@@ -3,7 +3,7 @@
  * Uses browser SpeechRecognition when available; never auto-sends chat.
  */
 
-import { useCallback, useRef, useState, type CSSProperties } from "react"
+import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react"
 import {
   parseSettingsIntent,
   SETTINGS_INTENT_HELP,
@@ -16,13 +16,26 @@ export type SettingsIntentBarProps = {
   /** Apply a parsed intent; return user-visible result string. */
   onIntent: (intent: SettingsIntent) => string
   disabled?: boolean
+  active?: boolean
 }
 
-export function SettingsIntentBar({ onIntent, disabled }: SettingsIntentBarProps) {
+export function SettingsIntentBar({ onIntent, disabled, active = true }: SettingsIntentBarProps) {
   const [text, setText] = useState("")
   const [status, setStatus] = useState<string | null>(null)
   const [listening, setListening] = useState(false)
   const recRef = useRef<{ stop: () => void; abort: () => void } | null>(null)
+  const generationRef = useRef(0)
+  useEffect(() => {
+    const cancel = () => {
+      generationRef.current += 1
+      const recognizer = recRef.current
+      recRef.current = null
+      try { recognizer?.abort() } catch { /* already ended */ }
+    }
+    if (!active) { cancel(); setListening(false); setStatus(previous => previous === "请说出设置命令…" ? "语音输入已取消" : previous) }
+    return cancel
+  }, [active])
+
 
   const run = useCallback(
     (raw: string) => {
@@ -45,7 +58,7 @@ export function SettingsIntentBar({ onIntent, disabled }: SettingsIntentBarProps
   }, [])
 
   const startVoice = useCallback(() => {
-    if (disabled || listening) return
+    if (disabled || !active || listening) return
     const Ctor = getSpeechRecognitionCtor(
       typeof globalThis !== "undefined" ? (globalThis as any) : {},
     )
@@ -53,6 +66,7 @@ export function SettingsIntentBar({ onIntent, disabled }: SettingsIntentBarProps
       setStatus("此环境不支持语音识别，请直接输入文字命令")
       return
     }
+    const generation = ++generationRef.current
     const r = new Ctor()
     r.lang = VOICE_DEFAULT_LANG
     r.continuous = false
@@ -60,6 +74,7 @@ export function SettingsIntentBar({ onIntent, disabled }: SettingsIntentBarProps
     r.maxAlternatives = 1
     let finalText = ""
     r.onresult = (ev: any) => {
+      if (generation !== generationRef.current) return
       let interim = ""
       const results = ev?.results
       if (!results) return
@@ -72,11 +87,13 @@ export function SettingsIntentBar({ onIntent, disabled }: SettingsIntentBarProps
       setText((finalText + interim).trim())
     }
     r.onerror = () => {
+      if (generation !== generationRef.current) return
       setListening(false)
       recRef.current = null
       setStatus("语音识别失败，请改用文字")
     }
     r.onend = () => {
+      if (generation !== generationRef.current) return
       setListening(false)
       recRef.current = null
       const phrase = (finalText || text).trim()
@@ -91,7 +108,7 @@ export function SettingsIntentBar({ onIntent, disabled }: SettingsIntentBarProps
       setListening(false)
       setStatus("无法启动麦克风")
     }
-  }, [disabled, listening, run, text])
+  }, [disabled, active, listening, run, text])
 
   return (
     <div style={styles.wrap} data-testid="settings-intent-bar">
diff --git a/companion/src/capability/settings-pointer.ts b/companion/src/capability/settings-pointer.ts
index 8bfb64a8..d2010aba 100644
--- a/companion/src/capability/settings-pointer.ts
+++ b/companion/src/capability/settings-pointer.ts
@@ -37,7 +37,7 @@ export type SettingsPointer = {
 export const TOOL_SETTINGS_POINTERS: Record<string, SettingsPointer> = {
   netsec_port_scan: {
     settings_section: "integrations",
-    settings_path: "设置 → 本机与集成 → 网络扫描（NetSec）",
+    settings_path: "设置 → 本机与工具 → 网络扫描（NetSec）",
   },
 }
 

FULL FILE chrome-extension/src/sidepanel/components/SettingsIntentBar.tsx
/**
 * Text + one-shot voice commands to configure CMspark settings (D2+ UX).
 * Uses browser SpeechRecognition when available; never auto-sends chat.
 */

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react"
import {
  parseSettingsIntent,
  SETTINGS_INTENT_HELP,
  type SettingsIntent,
} from "../utils/settings-intent"
import { getSpeechRecognitionCtor, VOICE_DEFAULT_LANG } from "../voice/detect"
import { tokens } from "../ui/tokens"

export type SettingsIntentBarProps = {
  /** Apply a parsed intent; return user-visible result string. */
  onIntent: (intent: SettingsIntent) => string
  disabled?: boolean
  active?: boolean
}

export function SettingsIntentBar({ onIntent, disabled, active = true }: SettingsIntentBarProps) {
  const [text, setText] = useState("")
  const [status, setStatus] = useState<string | null>(null)
  const [listening, setListening] = useState(false)
  const recRef = useRef<{ stop: () => void; abort: () => void } | null>(null)
  const generationRef = useRef(0)
  useEffect(() => {
    const cancel = () => {
      generationRef.current += 1
      const recognizer = recRef.current
      recRef.current = null
      try { recognizer?.abort() } catch { /* already ended */ }
    }
    if (!active) { cancel(); setListening(false); setStatus(previous => previous === "请说出设置命令…" ? "语音输入已取消" : previous) }
    return cancel
  }, [active])


  const run = useCallback(
    (raw: string) => {
      const intent = parseSettingsIntent(raw)
      const msg = onIntent(intent)
      setStatus(msg)
      if (intent.type !== "unknown") setText("")
    },
    [onIntent],
  )

  const stopVoice = useCallback(() => {
    try {
      recRef.current?.stop()
    } catch {
      /* */
    }
    recRef.current = null
    setListening(false)
  }, [])

  const startVoice = useCallback(() => {
    if (disabled || !active || listening) return
    const Ctor = getSpeechRecognitionCtor(
      typeof globalThis !== "undefined" ? (globalThis as any) : {},
    )
    if (!Ctor) {
      setStatus("此环境不支持语音识别，请直接输入文字命令")
      return
    }
    const generation = ++generationRef.current
    const r = new Ctor()
    r.lang = VOICE_DEFAULT_LANG
    r.continuous = false
    r.interimResults = true
    r.maxAlternatives = 1
    let finalText = ""
    r.onresult = (ev: any) => {
      if (generation !== generationRef.current) return
      let interim = ""
      const results = ev?.results
      if (!results) return
      for (let i = 0; i < results.length; i++) {
        const row = results[i]
        const t = row?.[0]?.transcript || ""
        if (row?.isFinal) finalText += t
        else interim += t
      }
      setText((finalText + interim).trim())
    }
    r.onerror = () => {
      if (generation !== generationRef.current) return
      setListening(false)
      recRef.current = null
      setStatus("语音识别失败，请改用文字")
    }
    r.onend = () => {
      if (generation !== generationRef.current) return
      setListening(false)
      recRef.current = null
      const phrase = (finalText || text).trim()
      if (phrase) run(phrase)
    }
    recRef.current = r
    setListening(true)
    setStatus("请说出设置命令…")
    try {
      r.start()
    } catch {
      setListening(false)
      setStatus("无法启动麦克风")
    }
  }, [disabled, active, listening, run, text])

  return (
    <div style={styles.wrap} data-testid="settings-intent-bar">
      <div style={styles.title}>文字 / 语音改设置</div>
      <div style={styles.hint}>{SETTINGS_INTENT_HELP}</div>
      <div style={styles.row}>
        <input
          type="text"
          value={text}
          disabled={disabled}
          placeholder="例如：开启连续听写"
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && text.trim()) {
              e.preventDefault()
              run(text)
            }
          }}
          style={styles.input}
        />
        <button
          type="button"
          disabled={disabled || !text.trim()}
          style={styles.btn}
          onClick={() => run(text)}
        >
          执行
        </button>
        <button
          type="button"
          disabled={disabled}
          style={{
            ...styles.btn,
            ...(listening ? styles.btnLive : null),
          }}
          onClick={() => (listening ? stopVoice() : startVoice())}
          title="用语音说设置命令"
        >
          {listening ? "停止" : "语音"}
        </button>
      </div>
      {status && <div style={styles.status}>{status}</div>}
    </div>
  )
}

const styles: Record<string, CSSProperties> = {
  wrap: {
    marginBottom: 14,
    padding: 10,
    borderRadius: 8,
    border: `1px solid ${tokens.border}`,
    background: tokens.bgMuted,
  },
  title: { fontSize: 12, fontWeight: 600, color: tokens.text, marginBottom: 4 },
  hint: { fontSize: 10, color: tokens.textMuted, lineHeight: 1.4, marginBottom: 8 },
  row: { display: "flex", gap: 6, alignItems: "center" },
  input: {
    flex: 1,
    minWidth: 0,
    fontSize: 12,
    padding: "6px 8px",
    borderRadius: 6,
    border: `1px solid ${tokens.borderStrong}`,
  },
  btn: {
    fontSize: 11,
    padding: "6px 8px",
    borderRadius: 6,
    border: `1px solid ${tokens.borderStrong}`,
    background: tokens.bgElevated,
    cursor: "pointer",
    whiteSpace: "nowrap",
  },
  btnLive: {
    background: tokens.warningSoft,
    borderColor: tokens.warning,
  },
  status: {
    marginTop: 6,
    fontSize: 11,
    color: tokens.accent,
    lineHeight: 1.4,
  },
}

FULL FILE chrome-extension/src/sidepanel/components/HotkeyCaptureField.tsx
/**
 * D2 UX — click to record a hold-to-talk chord from the keyboard.
 * Side Panel focus required; validates via hotkey-chord (no bare fn / Win+V).
 */

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react"
import { chordFromKeyboardEvent, parseHotkeyChord } from "../voice/hotkey-chord"
import { tokens } from "../ui/tokens"

export type HotkeyCaptureFieldProps = {
  value: string
  disabled?: boolean
  active?: boolean
  onChange: (chord: string) => void
  /** Optional presets shown as chips */
  presets?: string[]
}

export function HotkeyCaptureField({
  value,
  disabled,
  active = true,
  onChange,
  presets = [
    "Control+Shift+Space",
    "Alt+Space",
    "Control+Alt+Space",
    "Control+Shift+D",
  ],
}: HotkeyCaptureFieldProps) {
  const [capturing, setCapturing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const boxRef = useRef<HTMLButtonElement>(null)

  const stopCapture = useCallback(() => {
    setCapturing(false)
  }, [])

  useEffect(() => {
    if (!active) { setCapturing(false); return }
    if (!capturing) return
    const onKeyDown = (e: KeyboardEvent) => {
      e.preventDefault()
      e.stopPropagation()
      if (e.key === "Escape") {
        stopCapture()
        setError(null)
        return
      }
      if (e.repeat) return
      const chord = chordFromKeyboardEvent(e)
      if (!chord) {
        // Still holding only modifiers — keep waiting
        if (e.ctrlKey || e.altKey || e.shiftKey || e.metaKey) {
          setError("请继续按住修饰键并按下主键（如 Space / 字母）")
          return
        }
        setError("需要组合键（至少一个修饰键 + 主键）。禁止单独 Fn / Meta+V。")
        return
      }
      if (!parseHotkeyChord(chord)) {
        setError("无效或禁止的组合（禁止 bare Fn / 单独 Meta+V）")
        return
      }
      onChange(chord)
      setError(null)
      stopCapture()
    }
    const onBlur = () => stopCapture()
    window.addEventListener("keydown", onKeyDown, true)
    window.addEventListener("blur", onBlur)
    return () => {
      window.removeEventListener("keydown", onKeyDown, true)
      window.removeEventListener("blur", onBlur)
    }
  }, [active, capturing, onChange, stopCapture])

  useEffect(() => {
    if (capturing) boxRef.current?.focus()
  }, [capturing])

  return (
    <div style={styles.wrap}>
      <div style={styles.row}>
        <code style={styles.chord}>{value || "—"}</code>
        <button
          ref={boxRef}
          type="button"
          disabled={disabled}
          style={{
            ...styles.captureBtn,
            ...(capturing ? styles.captureBtnActive : null),
            ...(disabled ? styles.captureBtnDisabled : null),
          }}
          onClick={() => {
            if (disabled) return
            setError(null)
            setCapturing((v) => !v)
          }}
          aria-pressed={capturing}
        >
          {capturing ? "按下组合键…（Esc 取消）" : "按键盘录制"}
        </button>
      </div>
      {error && <div style={styles.error}>{error}</div>}
      {!capturing && (
        <div style={styles.presets}>
          {presets.map((p) => (
            <button
              key={p}
              type="button"
              disabled={disabled}
              style={styles.presetChip}
              onClick={() => {
                if (parseHotkeyChord(p)) {
                  onChange(p)
                  setError(null)
                }
              }}
            >
              {p}
            </button>
          ))}
        </div>
      )}
      <div style={styles.hint}>
        点击「按键盘录制」后按下组合键自动识别。需 Side Panel 焦点。禁止 bare Fn / 单独
        Meta+V。
      </div>
    </div>
  )
}

const styles: Record<string, CSSProperties> = {
  wrap: { marginTop: 6 },
  row: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" },
  chord: {
    fontSize: 12,
    padding: "6px 8px",
    background: "#f4f4f5",
    borderRadius: 6,
    border: "1px solid #e4e4e7",
    minWidth: 120,
    fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  },
  captureBtn: {
    fontSize: 12,
    padding: "6px 10px",
    borderRadius: 6,
    border: `1px solid ${tokens.border || "#ddd"}`,
    background: "#fff",
    cursor: "pointer",
    color: "#333",
  },
  captureBtnActive: {
    background: "#fef3c7",
    borderColor: "#f59e0b",
    fontWeight: 600,
  },
  captureBtnDisabled: {
    opacity: 0.5,
    cursor: "not-allowed",
  },
  error: { marginTop: 4, fontSize: 11, color: "#b91c1c", lineHeight: 1.4 },
  presets: { display: "flex", flexWrap: "wrap", gap: 4, marginTop: 6 },
  presetChip: {
    fontSize: 10,
    padding: "3px 6px",
    borderRadius: 999,
    border: "1px solid #e4e4e7",
    background: "#fafafa",
    cursor: "pointer",
    color: "#555",
  },
  hint: { marginTop: 4, fontSize: 10, color: "#999", lineHeight: 1.4 },
}

FULL FILE chrome-extension/src/sidepanel/components/SettingsPage.tsx
import type { ReactNode } from "react"
import type { SettingsSectionId } from "../utils/settings-sections"

/** Stable ids preserve existing settings deep links. Display order is task order. */
export const SETTINGS_PAGES: { id: SettingsSectionId; title: string; description: string }[] = [
  { id: "model", title: "模型与推理", description: "配置对话与视觉模型，以及上下文和推理预算。更改后点击保存。" },
  { id: "voice", title: "输入与语音", description: "管理发送快捷键、听写方式和语音模型。偏好即时生效；下载与启用需分别操作。" },
  { id: "export", title: "文件与知识", description: "管理附件限制、会话索引和笔记导出。配置更改后点击保存。" },
  { id: "connection", title: "连接与配对", description: "连接本机 Companion，配对操作在此单独完成。" },
  { id: "security", title: "安全与信任", description: "查看运行自主度与各项权限。每项开关沿用各自的确认和生效规则。" },
  { id: "integrations", title: "本机与工具", description: "管理本机能力、网络授权、MCP 和编程助手。授权操作需单独确认。" },
  { id: "secrets", title: "密钥与环境", description: "管理工具使用的密钥和环境变量。各条目单独保存。" },
  { id: "experimental", title: "实验功能", description: "配置本地视觉定位等实验能力。模型下载、许可和启用分别确认。" },
]

/** Parent hides inactive pages, preserving every child form and draft. */
export function SettingsPage({ id, title, badge, children }: {
  id: SettingsSectionId; title: string; badge?: ReactNode; children: ReactNode
}) {
  return <section data-settings-section={title} aria-labelledby={`settings-page-${id}`}>
    <header className="cm-settings-page-heading">
      <div className="cm-settings-page-title"><h3 id={`settings-page-${id}`} tabIndex={-1}>{title}</h3>{badge}</div>
      <p>{SETTINGS_PAGES.find(page => page.id === id)?.description}</p>
    </header>
    {children}
  </section>
}

FULL FILE chrome-extension/src/sidepanel/components/ui/Modal.tsx
// Shared modal/overlay primitive (audit M18).
//
// Wraps useModalDialog (focus trap + Escape + focus restore) and applies the
// dialog ARIA contract (role + aria-modal + aria-label/labelledby) so every
// overlay dialog gets consistent keyboard + screen-reader behavior.
//
// Callers pass their OWN overlay + panel styles (position fixed vs absolute,
// z-index, backdrop color, alignment differ per dialog and are kept verbatim)
// and their panel content as children. The outer overlay receives role/aria and
// the backdrop-dismiss click; the inner panel stops propagation so clicks inside
// don't close the dialog.
//
// NOTE: this is for DIALOGS only — things that take focus and trap it. Popovers
// that should NOT steal focus (e.g. SlashCommandPopover, a combobox/listbox) must
// NOT use this; they need listbox semantics instead. See ARIA guidance in WCAG.

import type { CSSProperties, ReactNode, RefObject } from "react"
import { useModalDialog, type UseModalDialogOptions } from "../../hooks/useModalDialog"

export interface ModalProps {
  /** Gate visibility + focus management. Renders null when false. */
  open: boolean
  /** Called on Escape, and on overlay click when backdropDismiss is true. */
  onClose: () => void
  /** Accessible role. Use "alertdialog" for destructive-action gates. */
  role?: "dialog" | "alertdialog"
  /** Accessible name when there's no visible title to point at. */
  ariaLabel?: string
  /** Accessible name pointing at a visible title element's id. Preferred over ariaLabel. */
  ariaLabelledBy?: string
  /** Click on the overlay/backdrop calls onClose. Default true. */
  backdropDismiss?: boolean
  /** Element to focus on open (passed through to useModalDialog). */
  initialFocusRef?: RefObject<HTMLElement>
  /** Restore focus on close (passed through to useModalDialog). */
  restoreFocus?: boolean
  /** Extra effect deps (e.g. a dialog id) — passed through to useModalDialog. */
  deps?: UseModalDialogOptions["deps"]
  /** Style for the overlay/backdrop element (position, z-index, bg, alignment). */
  overlayStyle?: CSSProperties
  /** Style for the inner panel. */
  panelStyle?: CSSProperties
  /** Extra className on the panel if a caller uses CSS classes. */
  panelClassName?: string
  children: ReactNode
}

export function Modal(props: ModalProps) {
  const {
    open,
    onClose,
    role = "dialog",
    ariaLabel,
    ariaLabelledBy,
    backdropDismiss = true,
    initialFocusRef,
    restoreFocus,
    deps,
    overlayStyle,
    panelStyle,
    panelClassName,
    children,
  } = props

  const overlayRef = useModalDialog({ open, onClose, initialFocusRef, restoreFocus, deps })

  if (!open) return null

  const aria = ariaLabelledBy ? { "aria-labelledby": ariaLabelledBy } : { "aria-label": ariaLabel }

  return (
    <div
      ref={overlayRef}
      role={role}
      aria-modal="true"
      {...aria}
      style={overlayStyle}
      onClick={backdropDismiss ? onClose : undefined}
    >
      <div style={panelStyle} className={panelClassName} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  )
}

FULL FILE chrome-extension/src/sidepanel/hooks/useModalDialog.ts
// Reusable modal-dialog behavior: focus trap + Escape-to-close + focus restore.
//
// Extracted 1:1 from the inline effect that shipped in SecurityConfirmationDialog
// (audit H10 / PR #19). Generalized so every overlay dialog (settings, MCP form,
// skill craft, security confirm) shares one correctness-checked implementation
// instead of each rolling its own — or (as most did) shipping with none at all.
//
// The focus-wrap logic lives in two PURE helpers below (getFocusableEdges /
// computeTabWrap) plus the FOCUSABLE_SELECTOR constant, all unit-tested without
// a DOM dep (see tests/use-modal-dialog.test.ts — computeTabWrap is
// identity-based; getFocusableEdges takes a stubbed root; the selector is pinned
// as an exact string). The hook itself is a thin, manually-verified effect shell
// over them (its listener wiring is identical to the effect that shipped in
// SecurityConfirmationDialog PR #19).

import { useEffect, useRef } from "react"

export interface UseModalDialogOptions {
  /** Gate: when false the effect is a no-op (and <Modal> renders null). */
  open: boolean
  /** Invoked on Escape. Use a ref-backed handler (this hook stores the latest). */
  onClose: () => void
  /**
   * Element to focus when the dialog opens. Defaults to the first focusable
   * element inside the overlay. SecurityConfirmationDialog points this at the
   * safe non-destructive action ("拒绝") to preserve its shipped behavior.
   */
  initialFocusRef?: React.RefObject<HTMLElement>
  /** Restore focus to the element that was focused before opening. Default true. */
  restoreFocus?: boolean
  /**
   * Extra deps that re-run the effect (re-trap + re-focus) without toggling
   * `open`. Used by SecurityConfirmationDialog to re-focus on each new
   * confirmation_id while the dialog stays open across a queue.
   */
  deps?: ReadonlyArray<unknown>
}

// Focusable elements inside a modal. Mirrors the original query selector, plus
// textarea/select/link for the broader set of dialogs this now serves.
export const FOCUSABLE_SELECTOR =
  'button, input, textarea, select, a[href], [tabindex]:not([tabindex="-1"])'

/**
 * Return the first and last focusable elements under `root`, or null if none.
 * Pure + DOM-driven so it can be unit-tested without React.
 */
export function getFocusableEdges(
  root: HTMLElement,
): { first: HTMLElement; last: HTMLElement } | null {
  const list = root.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)
  if (!list.length) return null
  return { first: list[0], last: list[list.length - 1] }
}

/**
 * Decide whether a Tab keypress at the edge of the focus cycle should wrap.
 * Returns "first" (move focus to first), "last" (move to last), or null (let
 * the browser handle it natively). Pure for testability.
 */
export function computeTabWrap(
  active: Element | null,
  first: HTMLElement,
  last: HTMLElement,
  shiftKey: boolean,
): "first" | "last" | null {
  if (shiftKey && active === first) return "last"
  if (!shiftKey && active === last) return "first"
  return null
}

export function useModalDialog(opts: UseModalDialogOptions) {
  const overlayRef = useRef<HTMLDivElement>(null)
  // Keep the latest onClose without re-subscribing the listener each render
  // (mirrors the denyRef pattern the security dialog already used).
  const onCloseRef = useRef(opts.onClose)
  onCloseRef.current = opts.onClose

  const { open, initialFocusRef, restoreFocus = true, deps = [] } = opts

  useEffect(() => {
    if (!open) return
    const overlay = overlayRef.current
    if (!overlay) return

    const prevFocus = document.activeElement as HTMLElement | null

    // Initial focus: caller-specified element, else first focusable in the overlay.
    if (initialFocusRef?.current) {
      initialFocusRef.current.focus()
    } else {
      const edges = getFocusableEdges(overlay)
      edges?.first.focus()
    }

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault()
        e.stopPropagation()
        onCloseRef.current()
        return
      }
      if (e.key === "Tab") {
        const edges = getFocusableEdges(overlay)
        if (!edges) return
        const wrap = computeTabWrap(document.activeElement, edges.first, edges.last, e.shiftKey)
        if (wrap === "last") {
          e.preventDefault()
          edges.last.focus()
        } else if (wrap === "first") {
          e.preventDefault()
          edges.first.focus()
        }
      }
    }

    overlay.addEventListener("keydown", onKeyDown)
    return () => {
      overlay.removeEventListener("keydown", onKeyDown)
      if (restoreFocus) prevFocus?.focus()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialFocusRef, ...deps])

  return overlayRef
}

FULL FILE chrome-extension/scripts/test-settings-pages-ui.py
"""Actual App settings pages with synthetic transport; no live config changes."""
from pathlib import Path
import subprocess,tempfile
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(6000)
  page.add_init_script('window.recEvents=[];window.SpeechRecognition=class { constructor(){window.fakeRecognition=this} start(){window.activeRecognition=this} stop(){window.recEvents.push("stop");this.onend?.()} abort(){window.recEvents.push("abort");this.aborted=true;this.onend?.()} };')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
  page.evaluate("window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'model'})")
  settings=page.get_by_role('dialog',name='设置',exact=True);settings.wait_for()
  model=page.get_by_placeholder('输入模型名称或从列表选择',exact=True);model.fill('fixture-model-draft')
  pages=['model','voice','export','connection','security','integrations','secrets','experimental']
  for width,height in [(1440,900),(800,700),(390,740),(320,480)]:
   page.set_viewport_size({'width':width,'height':height})
   for id in pages:
    if width>=760:
     settings.locator('.cm-settings-nav button').nth(pages.index(id)).click()
    else:settings.get_by_role('combobox',name='设置分类',exact=True).select_option(id)
    panel=settings.locator('[data-settings-page="'+id+'"]');panel.wait_for(state='visible')
    assert settings.locator('[data-settings-page]:visible').count()==1
    assert settings.evaluate('(el)=>el.scrollWidth<=el.clientWidth'),(width,id,'horizontal overflow')
    save=settings.get_by_role('button',name='保存并关闭',exact=True).bounding_box();assert save and save['y']+save['height']<=height,(width,id,save)
   page.evaluate("window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'model'})")
   model.wait_for();assert model.input_value()=='fixture-model-draft'
   page.wait_for_function('document.activeElement?.id==="settings-page-model"')
   page.screenshot(path=str(shots/f'settings-model-{width}.png'))
  assert not page.evaluate('window.sent.some(x=>x.type==="config.set" || x.type.includes("license_response") || x.type==="terminal.start")')
  page.evaluate("window.dispatchUI({type:'SET_CONFIG',config:{auto_approve_dangerous:true}});window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'voice'})")
  settings.get_by_role('button',name='有高权限开关已开启 · 查看安全设置',exact=True).wait_for()
  assert not model.is_visible()
  settings.get_by_role('button',name='有高权限开关已开启 · 查看安全设置',exact=True).click()
  settings.locator('[data-settings-page="security"]').wait_for(state='visible')
  assistant=settings.get_by_test_id('settings-intent-bar')
  settings.locator('.cm-settings-assistant summary').click()
  assistant.get_by_role('button',name='语音',exact=True).click()
  page.evaluate('window.commandRecognition=window.activeRecognition')
  before=page.evaluate('window.fixtureState.voiceDictationMode')
  page.evaluate('window.commandRecognition=window.activeRecognition;window.commandRecognition.onresult({results:[Object.assign([{transcript:"开启连续听写"}],{isFinal:true})]});window.lateEnd=window.commandRecognition.onend;void 0')
  settings.locator('.cm-settings-assistant summary').click()
  page.wait_for_timeout(150)
  page.wait_for_function('window.commandRecognition.aborted===true')
  page.evaluate('window.lateEnd()');page.wait_for_timeout(100)
  assert page.evaluate('window.fixtureState.voiceDictationMode')==before, 'Collapsed voice must not execute queued result'
  settings.locator('.cm-settings-assistant summary').click()
  assistant.get_by_text('语音输入已取消',exact=True).wait_for()
  assistant.get_by_role('button',name='语音',exact=True).click()
  page.evaluate('window.commandRecognition=window.activeRecognition;window.commandRecognition.onresult({results:[Object.assign([{transcript:"开启连续听写"}],{isFinal:true})]})')
  assistant.get_by_role('button',name='停止',exact=True).click()
  page.wait_for_function('window.fixtureState.voiceDictationMode==="continuous"')
  # A real store license payload is global to settings, independent of current category.
  page.set_viewport_size({'width':800,'height':700})
  page.evaluate("window.dispatchUI({type:'SET_DICTATION_HOTKEY_ENABLED',enabled:true})")
  settings.get_by_role('button',name='输入与语音',exact=True).click()
  settings.get_by_role('button',name='按键盘录制',exact=True).click()
  settings.get_by_role('button',name='模型与推理',exact=True).click()
  settings.get_by_role('button',name='输入与语音',exact=True).click()
  settings.get_by_role('button',name='按键盘录制',exact=True).wait_for()
  settings.get_by_role('button',name='模型与推理',exact=True).click()
  page.wait_for_function('document.activeElement?.id==="settings-page-model"')
  model.focus()
  page.evaluate("window.dispatchUI({type:'SET_COMPUTER_MODEL_LICENSE_DOOR',door:{licenseText:'Fixture license text',notice:'Fixture notice'}})")
  license=page.get_by_role('dialog',name='实验层许可证与免责声明',exact=True);license.wait_for()
  assert settings.locator('.cm-settings-content').get_attribute('inert') is not None
  for _ in range(5):
   page.keyboard.press('Tab')
   assert license.evaluate('(el)=>el.contains(document.activeElement)')
  page.keyboard.press('Shift+Tab')
  assert license.evaluate('(el)=>el.contains(document.activeElement)')
  page.keyboard.press('Escape');license.wait_for(state='hidden')
  assert settings.is_visible()
  page.wait_for_function('document.activeElement?.placeholder=== "输入模型名称或从列表选择"')
  assert not page.evaluate('window.sent.some(x=>x.type.includes("license_response"))')
  assert not errors,errors
  b.close()
print('PASS: settings pages responsive, all categories, retained model draft, stable deep links+focus, cross-page safety status, no implicit writes; cancelled voice callbacks, hidden hotkey capture, license keyboard isolation and focus restoration.')

FULL FILE companion/scripts/test-summoner-workspace-ui.py
"""Actual summoner HTML script, synthetic HTTP responses; no installed Companion."""
from pathlib import Path
from urllib.parse import urlparse
import json,subprocess,tempfile
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-web-surface-fixtures.cjs',out],cwd=root,check=True)
 html=(Path(out)/'capture.html').read_text().replace('%%CRUISE_LABEL%%','每次确认')
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':390,'height':740});page.set_default_timeout(6000)
  errors=[];requests=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.add_init_script('window.EventSource=class {addEventListener(){} close(){}};window.resizeTo=()=>{};window.moveTo=()=>{};')
  def route(r):
   req=r.request;path=urlparse(req.url).path;requests.append((req.method,path))
   if path=='/':r.fulfill(content_type='text/html',body=html);return
   if path=='/api/threads':data={'thread':{'id':'fixture-1'}} if req.method=='POST' else {'threads':[{'id':'fixture-1','alias':'演示对话'}]}
   elif path=='/api/thread':data={'messages':[],'run_status':'idle'}
   else:data={'ok':True}
   r.fulfill(content_type='application/json',body=json.dumps(data))
  page.route('http://fixture.test/**',route);page.goto('http://fixture.test/')
  text=page.get_by_role('textbox',name='发送到当前对话',exact=True);text.wait_for()
  page.wait_for_timeout(200);assert not errors,errors
  page.get_by_role('button',name='新对话',exact=True).first.click()
  page.wait_for_function('document.querySelector("#empty strong")')
  assert page.locator('.mark').count()==0 and '山' not in page.locator('#empty').inner_text()
  assert ('POST','/api/threads') in requests
  page.get_by_role('button',name='历史',exact=True).click();assert page.locator('.hud.history .list').is_visible()
  page.get_by_role('button',name='完成',exact=True).click()
  for width,height in [(320,420),(390,740),(1000,800)]:
   page.set_viewport_size({'width':width,'height':height})
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   assert page.locator('.composer-actions button:visible').evaluate_all('(els)=>els.map(el=>el.id)')==['attachFile','mic','sendGo']
   assert page.get_by_role('button',name='新对话',exact=True).count()==1
   field=text.bounding_box();send=page.get_by_role('button',name='发送',exact=True).bounding_box()
   assert field and send and field['y']+field['height']<=send['y']+1 and send['y']+send['height']<=height
   page.screenshot(path=str(shots/f'summoner-{width}.png'))
  with page.expect_file_chooser():page.get_by_role('button',name='添加附件',exact=True).click()
  text.fill('请整理变更材料');page.get_by_role('button',name='发送',exact=True).click()
  page.wait_for_timeout(200);assert ('POST','/api/chat') in requests
  assert not errors,errors
  b.close()
print('PASS: real summoner script, reset without mark, history, input/action DOM order, keyboard-native attachment, send; synthetic HTTP/SSE only.')

FULL FILE chrome-extension/src/sidepanel/ui/tokens.ts
// Shared React palette. Root DESIGN.md owns the current workspace direction.
// Neutral conversation surfaces; indigo links/focus; semantic risk colors.

export const tokens = {
  font:
    "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', 'PingFang SC', 'Helvetica Neue', sans-serif",
  fontMono: "ui-monospace, 'SF Mono', Menlo, Consolas, monospace",

  // Light companion canvas
  bg: "#ffffff",
  bgElevated: "#ffffff",
  bgMuted: "#f7f7f5",
  bgHover: "#eeeeec",
  actionPrimary: "#242424",
  navSelected: "#e9e9e6",
  bgActive: "#eef2ff",
  border: "rgba(23, 23, 23, 0.10)",
  borderStrong: "rgba(23, 23, 23, 0.14)",
  text: "#171717",
  textSecondary: "#666666",
  textMuted: "#767676",
  /** Empty-state hero only — not chrome. */
  emptyTitle: 22,

  // Indigo accent — links, focus and secondary highlighted controls
  accent: "#4f46e5",
  accentSoft: "#eef2ff",
  accentText: "#3730a3",
  accentHover: "#4338ca",
  /** Hairline indigo border on soft accent surfaces (status bubble). */
  accentBorderSoft: "rgba(79, 70, 229, 0.12)",

  /**
   * Brand red (terracotta / coral) — empty-state calf mark ONLY.
   * Independent of the danger family: hue 15° vs danger 0°, lighter + higher
   * chroma, so protanopia/deuteranopia simulation keeps ΔE00 ≫ 5 from
   * danger (#c96033 previously collapsed to ~3 under deutan). NEVER reuse
   * danger / dangerSoft / dangerSurface as brand red. Value pinned by
   * tests/calf-mark-323.test.ts (normal ≥10 AND Machado-deutan ≥5).
   */
  brandRed: "#d97757",

  success: "#059669",
  successSoft: "#ecfdf5",
  warning: "#d97706",
  warningSoft: "#fffbeb",
  /** Amber-200 border on warning surfaces (fakeEnd / compact banner). */
  warningBorder: "#fde68a",
  /** Amber-800 text on warningSoft surfaces. */
  warningText: "#92400e",
  danger: "#dc2626",
  dangerSoft: "#fef2f2",
  /** Soft confirm / FocusBand tint (G3; defined early for one SoT) */
  dangerSurface: "rgba(220, 38, 38, 0.08)",
  /** Danger border on light confirm surfaces (FocusBand confirm card). */
  dangerBorder: "rgba(220, 38, 38, 0.28)",
  /** Deep danger border on dark surfaces (急停 / abort buttons). */
  dangerDeep: "#7f1d1d",
  /** Mic-pulse keyframe ring (rgba of danger, start / fade-out end). */
  dangerPulse: "rgba(220, 38, 38, 0.35)",
  dangerPulseFade: "rgba(220, 38, 38, 0)",

  // Mode chips (badge only — no full-rail fill on L0/L1)
  modeChatBg: "#f1f5f9",
  modeChatText: "#334155",
  modeBrowserBg: "#eef2ff",
  modeBrowserText: "#3730a3",
  modeComputerBg: "#052e16",
  modeComputerText: "#6ee7b7",
  /** 3–4px accent line under StatusRail when L1/L2 (not full tint fill) */
  modeBrowserLine: "rgba(79, 70, 229, 0.35)",
  modeComputerLine: "rgba(52, 211, 153, 0.45)",

  // Dark surface (L2 / Cockpit)
  darkBg: "#171717",
  darkElevated: "#222222",
  darkBorder: "rgba(255, 255, 255, 0.08)",
  darkText: "#f1f5f9",
  darkMuted: "#94a3b8",
  darkAccent: "#818cf8",
  darkLive: "#34d399",
  darkDanger: "#f87171",
  darkDangerBg: "#3b1f1f",
  darkWarning: "#fbbf24",
  darkWarningBg: "#422006",
  darkSuccess: "#34d399",

  // Quiet neutral user bubble; assistant prose remains unboxed.
  userBubbleBg: "#f3f3f1",
  /** User-bubble copy. Distinct from userBubbleText (on-accent/on-danger glyphs). */
  userBubbleInk: "#171717",
  userBubbleBorder: "rgba(23, 23, 23, 0.04)",
  /**
   * On-accent / on-danger glyph (send armed, filled buttons). Historical name
   * `userBubbleText` kept so Settings/danger buttons do not silently go dark.
   * User bubble copy uses `userBubbleInk`.
   */
  userBubbleText: "#ffffff",
  assistantBubbleBg: "#ffffff",
  assistantBubbleText: "#0f172a",

  // Motion (Phase 3 — tightened from 150/220)
  transitionFast: "120ms",
  transition: "180ms",

  // Shape: controls 6/8/12; composer matches 看山 invitation (16)
  radiusSm: 6,
  radiusMd: 8,
  radiusLg: 12,
  radiusComposer: 20,
  radiusBubble: 14,
  /** Bottom sheet / 装配 drawer top corners */
  radiusSheet: 16,
  /** Popup menus (StatusRail ⋯ / panel ⋮) */
  radiusMenu: 10,
  radiusPill: 999,

  // One soft elevation ladder — hairline borders do most of the work
  shadowSm: "0 1px 2px rgba(15, 23, 42, 0.04)",
  shadowMd: "0 1px 3px rgba(15, 23, 42, 0.06), 0 4px 12px rgba(15, 23, 42, 0.04)",
  shadowLg: "0 4px 16px rgba(15, 23, 42, 0.08), 0 12px 28px rgba(15, 23, 42, 0.05)",
  shadowFocus: "0 0 0 3px rgba(79, 70, 229, 0.16)",
  /** Quiet indigo glow for accent controls. Not a user-bubble fill. */
  shadowAccent: "0 2px 10px rgba(79, 70, 229, 0.20)",
  /** Lightweight popover/dialog elevation (summary card). */
  shadowPopover: "0 4px 16px rgba(0, 0, 0, 0.08)",

  /** Near-transparent tint for quiet containers (reasoning wrap). */
  bgSubtle: "rgba(15, 23, 42, 0.03)",
  /** Mono output surfaces inside bubbles (shell stdout / tool-progress tail). */
  shellOutputBg: "rgba(0, 0, 0, 0.28)",
  toolTailBg: "rgba(0, 0, 0, 0.25)",

  /**
   * Unarmed send button SoT (#321 PR-4). Dedicated zinc fill — not `bgMuted`
   * (canvas mute). FINAL-SYNTHESIS said "bgMuted"; PR-1 added this token for
   * the circular send and it remains the button-specific SoT.
   */
  sendDisabledBg: "#e4e4e7",

  /** Thin, quiet global scrollbar (App global css). */
  scrollbar: "rgba(15, 23, 42, 0.18)",
  scrollbarThumb: "rgba(15, 23, 42, 0.16)",

  /** Modal / drawer scrim */
  scrim: "rgba(15, 23, 42, 0.28)",
  /** Stronger scrim for blocking import/confirm overlays. */
  scrimStrong: "rgba(0, 0, 0, 0.35)",
} as const

export type Tokens = typeof tokens

/** Risk level → light-surface color (never color-only; pair with text label). */
export function riskColor(level?: string): string {
  if (level === "low") return tokens.warning
  if (level === "medium") return tokens.warning
  return tokens.danger
}

/** Risk level → dark-surface color (SafetyStrip / MinimalConfirm). */
export function riskColorDark(level?: string): string {
  if (level === "low") return tokens.darkWarning
  if (level === "medium") return "#fb923c"
  return tokens.darkDanger
}

export function riskLabel(level?: string): string {
  if (level === "low") return "低风险"
  if (level === "medium") return "中风险"
  return "高风险"
}

/** Tool / task status → semantic color. */
export function statusColor(status?: string): string {
  if (status === "error" || status === "failed") return tokens.danger
  if (status === "success" || status === "ok" || status === "finished") return tokens.success
  if (status === "running" || status === "paused") return tokens.warning
  return tokens.textMuted
}

/** WS connection state — StatusRail / popup dots. Never Material #4CAF50/#FF9800/#F44336. */
export type ConnectionStatus = "connected" | "connecting" | "disconnected"

export function connectionColor(state: ConnectionStatus): string {
  if (state === "connected") return tokens.success
  if (state === "connecting") return tokens.warning
  return tokens.danger
}

export function connectionLabel(state: ConnectionStatus): string {
  if (state === "connected") return "已连接"
  if (state === "connecting") return "连接中"
  return "未连接"
}

/** Soft glow under connected dot (rgba of tokens.success #059669). */
export function connectionDotShadow(state: ConnectionStatus): string {
  if (state === "connected") return "0 0 0 3px rgba(5, 150, 105, 0.18)"
  return "none"
}

/**
 * Connection colors for dark surfaces (Cockpit title bar / L2 chrome).
 */
export function connectionColorDark(state: ConnectionStatus): string {
  if (state === "connected") return tokens.darkLive
  if (state === "connecting") return tokens.darkWarning
  return tokens.darkDanger
}

/** Soft glow under connected dot on dark (rgba of tokens.darkLive #34d399). */
export function connectionDotShadowDark(state: ConnectionStatus): string {
  if (state === "connected") return "0 0 0 3px rgba(52, 211, 153, 0.22)"
  return "none"
}

SETTINGS HOOKS AND NAV FULL PREFIX
// Settings slideout panel for LLM configuration + NetSec (migrated from 场景 panel)

import { useState, useEffect, useCallback, useRef } from "react"
import { useAgentStore } from "../store/agentStore"
import { Modal } from "./ui/Modal"
import { tokens } from "../ui/tokens"
import { UserEnvSection } from "./UserEnvSection"
import { NetSecSettingsSection } from "./NetSecSettingsSection"
import { CapabilityProfileSection } from "./CapabilityProfileSection"
import { OutboundMcpSettingsSection } from "./OutboundMcpSettingsSection"
import { CodingHandoffSettingsSection } from "./CodingHandoffSettingsSection"
import { SettingsPage, SETTINGS_PAGES } from "./SettingsPage"
import { SettingsIntentBar } from "./SettingsIntentBar"
import { HotkeyCaptureField } from "./HotkeyCaptureField"
import { useContextPanelHostOptional } from "./ContextPanelHost"
import type { SettingsIntent } from "../utils/settings-intent"
import { DICTATION_HOTKEY_DEFAULT_CHORD } from "../voice/hotkey-chord"
import {
  isElevatedTrust,
  SETTINGS_SECTION_IDS,
  type SettingsSectionId,
} from "../utils/settings-sections"
import {
  contextWindowHelpText,
  settingsSaveDisabled,
  settingsSaveDisabledTitle,
} from "../utils/context-window-copy"
// WP5-I4 实验功能段:组件纯渲染,文案/判定全部来自 logic 纯函数(镜像
// companion 单一真源);发送固定 source:"settings"(companion 双层围栏)。
import {
  MODEL_SWITCH_COPY,
  QWEN_VL_VARIANT_TIPS,
  licenseDoorShouldOpen,
  modelStatusLine,
  modelSwitchDisabledReason,
  modelSwitchHint,
  modelSwitchRunningNote,
  variantResourceTip,
} from "./model-switch-logic"
import {
  UNATTENDED_MATRIX_FOOTNOTES,
  type AutopilotArmPick,
  type AutopilotTier,
  deriveDisplayTier,
  disarmAllFlags,
  flagsNeedingArm,
  flagsNeedingDisarm,
  targetFlagsForTier,
  tierShortLabel,
  trustStatusChip,
} from "./autopilot-tier"
import { AutopilotConsequenceMatrix } from "./AutopilotConsequenceMatrix"
// Path B M0: pure copy + recommended model id for local STT settings progressive disclosure.
import {
  BTN_CANCEL,
  BTN_DELETE,
  BTN_DOWNLOAD,
  BTN_ENABLE_LOCAL,
  BTN_ENABLE_SYSTEM,
  BTN_LOCAL_ENABLED,
  BTN_SET_ACTIVE,
  BTN_SWITCH_BROWSER,
  BTN_SYSTEM_ENABLED,
  ENGINE_BROWSER_HINT,
  ENGINE_BROWSER_LABEL,
  ENGINE_LOCAL_HINT,
  ENGINE_LOCAL_LABEL,
  ENGINE_SECTION_LABEL,
  ENGINE_SYSTEM_HINT,
  ENGINE_SYSTEM_LABEL,
  OTHER_MODELS_TOGGLE,
  OTHER_WHISPER_MODEL_IDS,
  RECOMMENDED_ROW_PREFIX,
  RECOMMENDED_WHISPER_MODEL_ID,
  SYSTEM_UNAVAILABLE_REASON_LABEL,
  VOICE_AUTO_FALLBACK_HINT,
  VOICE_AUTO_FALLBACK_LABEL,
  VOICE_DOWNLOAD_ENDPOINT_HINT,
  VOICE_DOWNLOAD_ENDPOINT_LABEL,
  VOICE_DOWNLOAD_ENDPOINT_PLACEHOLDER,
  VOICE_ERR_DOWNLOAD_NO_PROGRESS,
  VOICE_ERR_STATE_TIMEOUT,
  VOICE_STATUS_QUERYING,
  VOICE_STATUS_STARTING_DOWNLOAD,
  whisperModelMetaLine,
  binaryStatusLine,
  canDownloadWhisperBinary,
  engineChainRows,
  formatDiskUsage,
  modelProbeErrorLabel,
  modelStatusLabel,
  parseVoiceSettingsSendResponse,
  privacyCopyForEngine,
  progressPercent,
  type WhisperSettingsModelId,
} from "../voice/whisper-settings-copy"
import { detectSpeechRecognition } from "../voice/detect"
import {
  VISION_COPY,
  applyVisionReuseFromMain,
  bannerBodyForHost,
  extractHostname,
  isCustomVisionConfig,
  isVisionReusingMain,
  shouldOfferVisionReuse,
} from "./vision-reuse-logic"

// P1-1 / PR-B: typed-confirmation phrase for arming dangerous security flags.
// Lock-step with companion/src/security-arm.ts SECURITY_ARM_CONFIRM_PHRASE —
// companion rejects false→true without this top-level confirmation_phrase.
// UI phrase alone is theater; arm path must forward phrase on config.set.
// Alias kept as SECURITY_ARM_CONFIRM_PHRASE semantics; not a product "God" noun.
const GODMODE_CONFIRM_PHRASE = "我了解风险"
const SECURITY_ARM_PHRASE = GODMODE_CONFIRM_PHRASE

// #259 引擎链路状态 row 2: Web Speech availability (pure feature detect; node tests → missing).
const BROWSER_STT_SUPPORT = detectSpeechRecognition(
  typeof window !== "undefined" ? (window as any) : {},
)

const SAFETY_SKILLS = [
  { id: "cookie_guard", label: "Cookie 守卫" },
  { id: "eval_guard", label: "代码执行守卫" },
  { id: "nav_guard", label: "导航守卫" },
  { id: "input_guard", label: "输入守卫" },
]

export function SettingsSlideout() {
  const { state, dispatch } = useAgentStore()
  const host = useContextPanelHostOptional()
  const [showKey, setShowKey] = useState(false)
  const [showAuditLog, setShowAuditLog] = useState(false)
  const [trustedDomainsConfirm, setTrustedDomainsConfirm] = useState(false)
  const [autoApprovedConfirm, setAutoApprovedConfirm] = useState(false)
  const [wsSecretInput, setWsSecretInput] = useState("")
  const [wsPaired, setWsPaired] = useState<boolean | null>(null)
  const [wsPairingMsg, setWsPairingMsg] = useState<{ ok: boolean; text: string } | null>(null)
  // PR-B God-mode: the typed-confirmation sub-panel + its input + feedback.
  const [godmodeConfirm, setGodmodeConfirm] = useState(false)
  const [godmodePhrase, setGodmodePhrase] = useState("")
  const [godmodeMsg, setGodmodeMsg] = useState<string | null>(null)
  // Plan B enterprise auto-approve phrase gate
  const [entBConfirm, setEntBConfirm] = useState(false)
  const [entBPhrase, setEntBPhrase] = useState("")
  const [entBMsg, setEntBMsg] = useState<string | null>(null)
  // Alias of GODMODE_CONFIRM_PHRASE (companion SECURITY_ARM_CONFIRM_PHRASE) — one literal in this file.
  const ENT_B_PHRASE = GODMODE_CONFIRM_PHRASE
  // auto_approve_dangerous phrase gate (P1-1 — companion requires step-up on arm)
  const [autoDangerConfirm, setAutoDangerConfirm] = useState(false)
  const [autoDangerPhrase, setAutoDangerPhrase] = useState("")
  const [autoDangerMsg, setAutoDangerMsg] = useState<string | null>(null)
  // Trust IA + ADR-021: Autopilot package arm / unattended
  const [autopilotTierPick, setAutopilotTierPick] = useState<AutopilotArmPick>("browser")
  const [autopilotConfirm, setAutopilotConfirm] = useState(false)
  const [autopilotPhrase, setAutopilotPhrase] = useState("")
  const [autopilotMsg, setAutopilotMsg] = useState<string | null>(null)
  const [autopilotBusy, setAutopilotBusy] = useState(false)
  const [advancedGatesOpen, setAdvancedGatesOpen] = useState(false)
  // Vision reuse UX (multi-adversarial P0): banner session + advanced collapse when reused
  const [visionReuseBanner, setVisionReuseBanner] = useState(false)
  const [visionReuseBannerDismissed, setVisionReuseBannerDismissed] = useState(false)
  const [visionReuseHint, setVisionReuseHint] = useState<string | null>(null)
  const [visionAdvancedOpen, setVisionAdvancedOpen] = useState(false)
  const [unattendedAckDesktop, setUnattendedAckDesktop] = useState(false)
  const [unattendedAckSession, setUnattendedAckSession] = useState(false)
  const [unattendedIncludeProtocol, setUnattendedIncludeProtocol] = useState(false)
  // WP5-I4 实验区:删除模型两步确认按钮的待命态(非 store——纯组件内 UI 态)。
  const [modelDeleteArmed, setModelDeleteArmed] = useState(false)
  // Path B M0: engine radio is UI draft until ready model + explicit "启用本机转写".
  const [engineDraft, setEngineDraft] = useState<"browser" | "local" | "system">("browser")
  const [otherWhisperOpen, setOtherWhisperOpen] = useState(false)
  /** Local-only: modelId user clicked download on, until companion state/progress arrives. */
  const [voicePendingDownload, setVoicePendingDownload] = useState<string | null>(null)
  const voicePendingDownloadRef = useRef<string | null>(null)
  voicePendingDownloadRef.current = voicePendingDownload
  /** 模型下载源输入草稿；null = 未编辑，跟随 voiceModel 镜像。 */
  const [voiceEndpointDraft, setVoiceEndpointDraft] = useState<string | null>(null)
  const [settingsAssistantOpen, setSettingsAssistantOpen] = useState(false)
  const [activeSettingsPage, setActiveSettingsPage] = useState<SettingsSectionId>("model")
  const lastSettingsFocus = useRef<HTMLElement | null>(null)
  const licenseWasOpen = useRef(false)
  useEffect(() => {
    const open = licenseDoorShouldOpen(state.computerModelLicenseDoor)
    const restore = licenseWasOpen.current && !open && state.settingsOpen && !state.settingsFocusSection
    licenseWasOpen.current = open
    if (!restore) return
    const frame = requestAnimationFrame(() => lastSettingsFocus.current?.focus())
    return () => cancelAnimationFrame(frame)
  }, [state.computerModelLicenseDoor, state.settingsOpen, state.settingsFocusSection])
  const settingsPageChosen = useRef(false)
  const selectSettingsPage = useCallback((id: SettingsSectionId, focus = false) => {
    settingsPageChosen.current = true
    setActiveSettingsPage(id)
    requestAnimationFrame(() => {
      const body = document.querySelector<HTMLElement>(".cm-settings-body")
      if (body) body.scrollTop = 0
      if (focus) document.querySelector<HTMLElement>(`[data-settings-page="${id}"] h3`)?.focus()
    })
  }, [])

  const elevatedTrust = isElevatedTrust({
    auto_approve_dangerous: state.config.auto_approve_dangerous,
    auto_approve_enterprise_tools: state.config.auto_approve_enterprise_tools,
    allow_all_schemes: state.config.allow_all_schemes,
    unattendedArmed: state.unattended?.armed === true,
  })

  // P0-2B: check on open whether a WS pairing secret is already stored, so the
  // status badge reflects the real pairing state (not just connection state).
  useEffect(() => {
    if (!state.settingsOpen) return
    // Reset stale pairing feedback + re-check stored-secret presence each open.
    setWsPairingMsg(null)
    // Reset any stale security arm confirmation panels from a previous open.
    setGodmodeConfirm(false)
    setGodmodePhrase("")
    setGodmodeMsg(null)
    setEntBConfirm(false)
    setEntBPhrase("")
    setEntBMsg(null)
    setAutoDangerConfirm(false)
    setAutoDangerPhrase("")
    setAutoDangerMsg(null)
    setAutopilotConfirm(false)
    setAutopilotPhrase("")
    setAutopilotMsg(null)
    setAutopilotBusy(false)
    setUnattendedAckDesktop(false)
    setUnattendedAckSession(false)
    setUnattendedIncludeProtocol(false)
    // Hydrate unattended grant for chip / disarm
    chrome.runtime.sendMessage({ type: "security.unattended.status" })
    // WP5-I4 实验区:打开设置页拉一次模型状态(后续由 state 广播驱动,
    // 无乐观更新);清掉上次打开残留的错误与删除待命态。
    setModelDeleteArmed(false)
    dispatch({ type: "SET_COMPUTER_MODEL_ERROR", error: null })
    chrome.runtime.sendMessage({ type: "computer.model.get_state" })
    // Path B M0: mirror voice.model state on settings open (UI Task 7).
    // Do not blank voiceModelError here — get_state / WS lastDownloadError hydrates it.
    setVoicePendingDownload(null)
    setVoiceEndpointDraft(null)
    chrome.runtime.sendMessage({ type: "voice.model.get_state" }, (resp: unknown) => {
      const lastErr =
        typeof chrome.runtime.lastError?.message === "string"
          ? chrome.runtime.lastError.message
          : null
      const parsed = parseVoiceSettingsSendResponse(resp, lastErr)
      if (parsed.ok === false) {
        dispatch({ type: "SET_VOICE_MODEL_ERROR", error: parsed.error })
      }
    })
    // #259: Windows SAPI probe (win32 → helper/System.Speech rows; other → no-op).
    chrome.runtime.sendMessage({ type: "voice.system.state" })
    chrome.runtime.sendMessage({ type: "ws.getPairingStatus" }, (resp: { paired?: boolean } | undefined) => {
      const paired = !!resp?.paired
      setWsPaired(paired)
      if (!settingsPageChosen.current) setActiveSettingsPage(paired ? "model" : "connection")
    })
    // Coding agents: list even when acp.enabled=false (discovery ≠ feature gate)
    chrome.runtime.sendMessage({ type: "acp.list" }, () => {
      void chrome.runtime.lastError
    })
  }, [state.settingsOpen])

  // Path B M0: sync engine draft from companion SoT when state arrives.
  // - sttEngine local → pull draft to local (committed)
  // - companion local→browser (delete active / set_engine) → reset draft browser
  // - selecting local radio alone never writes set_engine (draft until enable)
  // - do not clobber local draft while companion still reports browser
  const prevVoiceEngineRef = useRef<"browser" | "local" | "system" | null>(null)
  useEffect(() => {
    const eng = state.voiceModel?.sttEngine
    if (!eng) return
    if (eng === "local" || eng === "system") {
      setEngineDraft(eng)
    } else if (
      (prevVoiceEngineRef.current === "local" || prevVoiceEngineRef.current === "system") &&
      eng === "browser"
    ) {
      setEngineDraft("browser")
    }
    prevVoiceEngineRef.current = eng
  }, [state.voiceModel?.sttEngine])

  // Clear local pending-download once companion reports downloading/ready or progress.
  useEffect(() => {
    const pending = voicePendingDownload
    if (!pending) return
    const st = state.voiceModel?.models?.[pending]?.status
    if (st === "downloading" || st === "ready") {
      setVoicePendingDownload(null)
      return
    }
    if (state.voiceModelProgress?.modelId === pending) {
      setVoicePendingDownload(null)
    }
  }, [state.voiceModel, state.voiceModelProgress, voicePendingDownload])

  // Settings open but voice.model.state never arrives → surface timeout (was silent forever).
  useEffect(() => {
    if (!state.settingsOpen) return
    if (state.voiceModel !== null) return
    const t = window.setTimeout(() => {
      dispatch({ type: "SET_VOICE_MODEL_ERROR", error: VOICE_ERR_STATE_TIMEOUT })
    }, 6000)
    return () => window.clearTimeout(t)
  }, [state.settingsOpen, state.voiceModel, dispatch])

  // Download click accepted by SW but no companion progress → surface (was silent).
  useEffect(() => {
    if (!voicePendingDownload) return
    const modelId = voicePendingDownload
    const t = window.setTimeout(() => {
      if (voicePendingDownloadRef.current !== modelId) return
      setVoicePendingDownload(null)
      dispatch({ type: "SET_VOICE_MODEL_ERROR", error: VOICE_ERR_DOWNLOAD_NO_PROGRESS })
      dispatch({ type: "SET_VOICE_MODEL_PROGRESS", progress: null })
    }, 8000)
    return () => window.clearTimeout(t)
  }, [voicePendingDownload, dispatch])

  // Auto-expand advanced gates when any arm flag is on (user can still collapse).
  // Parent「安全与信任」is collapsible; elevated trust only shows header badge.
  useEffect(() => {
    if (!state.settingsOpen) return
    const c = state.config
    if (
      c.auto_approve_dangerous === true ||
      c.auto_approve_enterprise_tools === true ||
      c.allow_all_schemes === true ||
      state.unattended?.armed === true
    ) {
      setAdvancedGatesOpen(true)
    }
  }, [
    state.settingsOpen,
    state.config.auto_approve_dangerous,
    state.config.auto_approve_enterprise_tools,
    state.config.allow_all_schemes,
    state.unattended?.armed,
  ])

  // F-UX7 deep-link: open target accordion section once settings opens.
  useEffect(() => {
    if (!state.settingsOpen || !state.settingsFocusSection || licenseDoorShouldOpen(state.computerModelLicenseDoor)) return
    const id = state.settingsFocusSection as SettingsSectionId
    if (!(SETTINGS_SECTION_IDS as readonly string[]).includes(id)) {
      dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
      return
    }
    selectSettingsPage(id, true)
    dispatch({ type: "CLEAR_SETTINGS_FOCUS" })
  }, [state.settingsOpen, state.settingsFocusSection, state.computerModelLicenseDoor, dispatch, selectSettingsPage])

  /**
   * Text / voice commands for configuring this extension (D2+ UX).
   * MUST stay above the settingsOpen early-return — React #310 if hooks run only when open.
   */
  const applySettingsIntent = useCallback(
    (intent: SettingsIntent): string => {
      if (intent.type.startsWith("set_") || intent.type === "enable_hotkey_default") selectSettingsPage("voice")
      switch (intent.type) {
        case "set_dictation_mode":
          dispatch({ type: "SET_VOICE_DICTATION_MODE", mode: intent.mode })
          return intent.mode === "continuous"
            ? "已开启连续听写"
            : "已切换为经典短听"
        case "set_hotkey_enabled":
          dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: intent.enabled })
          return intent.enabled ? "已启用按住说话热键" : "已关闭按住说话热键"
        case "set_asr_refiner":
          dispatch({ type: "SET_ASR_REFINER_ENABLED", enabled: intent.enabled })
          return intent.enabled ? "已开启 ASR 纠错" : "已关闭 ASR 纠错"
        case "set_realtime_streaming":
          dispatch({
            type: "SET_VOICE_REALTIME_STREAMING",
            enabled: intent.enabled,
            preferContinuous: intent.enabled === true,
          })
          return intent.enabled
            ? "已开启实时出字（浏览器字级 interim；本机约 8 秒一段）"
            : "已关闭实时出字优先"
        case "set_stt_engine":
          if (intent.engine === "browser") {
            try {
              chrome.runtime.sendMessage({
                type: "voice.model.set_engine",
                engine: "browser",
                source: "settings",
              })
            } catch {
              /* */
            }
            setEngineDraft("browser")
            return "已切换为浏览器听写（支持字级实时）"
          }
          setEngineDraft("local")
          return "请在「输入与语音 → 听写方式」下载模型后点「启用本机转写」"
        case "enable_hotkey_default":
          dispatch({ type: "SET_DICTATION_HOTKEY_ENABLED", enabled: true })
          dispatch({
            type: "SET_DICTATION_HOTKEY_CHORD",
            chord: DICTATION_HOTKEY_DEFAULT_CHORD,
          })
          return `已启用热键：${DICTATION_HOTKEY_DEFAULT_CHORD}`
        case "open_meeting":
          dispatch({ type: "SET_SETTINGS_OPEN", open: false })
          host?.openPanelForce("meeting")
          return "已打开会议工作台"
        case "open_packs":
          dispatch({ type: "SET_SETTINGS_OPEN", open: false })
          host?.openPanelForce("packs")
          return "已打开场景面板"
        case "unknown":
        default:
          return "未识别。试试：开启连续听写 / 开启实时出字 / 打开会议 / 浏览器听写"
      }
    },
    [dispatch, host, selectSettingsPage],
  )

  if (!state.settingsOpen) return null

  const config = state.config

  const handleSave = () => {
    if (settingsSaveDisabled(state.configHydratedFromCompanion)) return
    // Probe bit is session-only; never persist native_vision_detected.
    const { native_vision_detected: _drop, ...toSave } = config
    chrome.runtime.sendMessage({ type: "config.set", config: toSave }, () => {
      dispatch({ type: "TOGGLE_SETTINGS" })
    })
  }

  // P0-2B: store the WS shared secret (out-of-band, pasted from
  // `cmspark-agent settings --ws-secret` first-run output) and reconnect so the
  // background WSClient authenticates against the companion's challenge.
  const handleWsPair = () => {
    const secret = wsSecretInput.trim()
    if (!secret) {
      setWsPairingMsg({ ok: false, text: "请粘贴 Companion 输出的配对密钥" })
      return
    }
    setWsPairingMsg({ ok: true, text: "配对中，正在重连…" })
    chrome.runtime.sendMessage({ type: "ws.setSecret", secret }, (resp: { ok?: boolean; error?: string }) => {
      if (resp?.ok) {
        setWsPaired(true)
        setWsSecretInput("")
        setWsPairingMsg({ ok: true, text: "已配对，正在鉴权重连…" })
      } else {
        setWsPairingMsg({ ok: false, text: resp?.error || "配对失败" })
      }
    })
  }

  const handleTrustedDomainsChange = (value: string) => {
    const trusted_domains = value
      .split(/\n|,/)
      .map(domain => domain.trim())
      .filter(Boolean)
    dispatch({ type: "SET_CONFIG", config: { trusted_domains } })
  }

  const handleAutoApprovedDomainsChange = (value: string) => {
    const auto_approved_domains = value
      .split(/\n|,/)
      .map(domain => domain.trim())
      .filter(Boolean)
    dispatch({ type: "SET_CONFIG", config: { auto_approved_domains } })
  }

  // P1-1: arm paths send focused config.set + confirmation_phrase so companion
  // step-up is not UI theater. Disarm needs no phrase. handleSave re-sends
  // already-true flags without phrase (transition-only gate).
  const sendSecurityFlagConfig = (
    partial: Record<string, boolean>,
    confirmation_phrase?: string,
  ) => {
    chrome.runtime.sendMessage({
      type: "config.set",
      config: partial,
      ...(confirmation_phrase != null ? { confirmation_phrase } : {}),
    })
  }

  const handleAutoApproveDangerousChange = (checked: boolean) => {
    if (!checked) {
      dispatch({ type: "SET_CONFIG", config: { auto_approve_dangerous: false } })
      sendSecurityFlagConfig({ auto_approve_dangerous: false })
      setAutoDangerConfirm(false)
      setAutoDangerPhrase("")
      setAutoDangerMsg(null)
      return
    }
    setAutoDangerConfirm(true)
    setAutoDangerPhrase("")
    setAutoDangerMsg(null)
  }

  const handleAutoApproveDangerousConfirm = () => {
    if (autoDangerPhrase.trim() !== GODMODE_CONFIRM_PHRASE) {
      setAutoDangerMsg(`请输入「${GODMODE_CONFIRM_PHRASE}」`)
      return
    }
    const phrase = autoDangerPhrase.trim()
    dispatch({ type: "SET_CONFIG", config: { auto_approve_dangerous: true } })
    sendSecurityFlagConfig({ auto_approve_dangerous: true }, phrase)
    setAutoDangerConfirm(false)
    setAutoDangerPhrase("")
    setAutoDangerMsg(null)
  }

  const handleEnterpriseAutoApproveToggle = (checked: boolean) => {
    if (!checked) {
      dispatch({ type: "SET_CONFIG", config: { auto_approve_enterprise_tools: false } })
      sendSecurityFlagConfig({ auto_approve_enterprise_tools: false })
      setEntBConfirm(false)
      setEntBPhrase("")
      setEntBMsg(null)
      return
    }
    setEntBConfirm(true)
    setEntBPhrase("")
    setEntBMsg(null)
  }

  const handleEnterpriseAutoApproveConfirm = () => {
    if (entBPhrase.trim() !== ENT_B_PHRASE) {
      setEntBMsg(`请输入「${ENT_B_PHRASE}」`)
      return
    }
    const phrase = entBPhrase.trim()
    dispatch({ type: "SET_CONFIG", config: { auto_approve_enterprise_tools: true } })
    sendSecurityFlagConfig({ auto_approve_enterprise_tools: true }, phrase)
    setEntBConfirm(false)
    setEntBPhrase("")
    setEntBMsg(null)
  }

  // PR-B God-mode (security.allow_all_schemes). Bypasses BOTH layers — strictly
  // stronger than auto_approve_dangerous. Arming requires a typed phrase; disarming
  // is frictionless (safe direction). Either direction is recorded as an audit entry
  // (design §B godmode_enabled_changed, source = ui_phrase_confirmed).
  const handleGodModeToggle = (checked: boolean) => {
    if (checked) {
      // Arming: open the typed-confirmation panel, do NOT flip yet.
      setGodmodeConfirm(true)
      setGodmodePhrase("")
      setGodmodeMsg(null)
      return
    }
    // Disarming is safe — flip immediately + audit + companion config.set (no phrase).
    dispatch({ type: "SET_CONFIG", config: { allow_all_schemes: false } })
    sendSecurityFlagConfig({ allow_all_schemes: false })
    dispatch({
      type: "ADD_SECURITY_AUDIT",
      entry: {
        id: `godmode-off-${crypto.randomUUID()}`,
        ts: new Date().toISOString(),
        level: "info",
        tool_name: "allow_all_schemes",
        action: "changed",
        risk_level: "low",
        risk_score: 0,
        source: "ui_phrase_confirmed",
        message: "已关闭协议解锁（恢复协议保护：L1 scheme 硬阻断 + 网页 L2 确认门重新生效）",
      },
    })
  }

  const handleGodModeConfirm = () => {
    if (godmodePhrase.trim() !== SECURITY_ARM_PHRASE) {
      setGodmodeMsg(`确认短语不匹配，请输入「${SECURITY_ARM_PHRASE}」`)
      return
    }
    const phrase = godmodePhrase.trim()
    dispatch({ type: "SET_CONFIG", config: { allow_all_schemes: true } })
    // P1-1: companion requires confirmation_phrase on false→true (not theater).
    sendSecurityFlagConfig({ allow_all_schemes: true }, phrase)
    dispatch({
      type: "ADD_SECURITY_AUDIT",
      entry: {
        id: `protocol-unlock-on-${crypto.randomUUID()}`,
        ts: new Date().toISOString(),
        level: "error",
        tool_name: "allow_all_schemes",
        action: "changed",
        risk_level: "high",
        risk_score: 100,
        source: "ui_phrase_confirmed",
        message:
          "已启用协议解锁（allow_all_schemes）— L1 scheme 硬阻断 + 部分网页 L2 已绕过；不含 shell/CU/spawn forceConfirm",
      },
    })
    setGodmodeConfirm(false)
    setGodmodePhrase("")
    setGodmodeMsg(null)
  }

  const applySecurityFlagsTarget = (
    target: {
      auto_approve_dangerous: boolean
      auto_approve_enterprise_tools: boolean
      allow_all_schemes: boolean
    },
    phrase: string | undefined,
    auditMessage: string,
  ) => {
    const current = {
      auto_approve_dangerous: config.auto_approve_dangerous === true,
      auto_approve_enterprise_tools: config.auto_approve_enterprise_tools === true,
      allow_all_schemes: config.allow_all_schemes === true,
    }
    const toDisarm = flagsNeedingDisarm(current, target)
    const toArm = flagsNeedingArm(current, target)
    for (const k of toDisarm) {
      sendSecurityFlagConfig({ [k]: false })
    }
    for (const k of toArm) {
      if (!phrase) return
      sendSecurityFlagConfig({ [k]: true }, phrase)
    }
    dispatch({ type: "SET_CONFIG", config: { ...target } })
    dispatch({
      type: "ADD_SECURITY_AUDIT",
      entry: {
        id: `autopilot-${crypto.randomUUID()}`,
        ts: new Date().toISOString(),
        level: toArm.length > 0 ? "error" : "info",
        tool_name: "autopilot_packaging",
        action: "changed",
        risk_level: toArm.length > 0 ? "high" : "low",
        risk_score: toArm.length > 0 ? 80 : 0,
        source: "ui_phrase_confirmed",
        message: `${auditMessage} [${[...toArm, ...toDisarm.map((k) => `-${k}`)].join(", ") || "noop"}]`,
      },
    })
  }

  const handleAutopilotArmConfirm = () => {
    if (autopilotPhrase.trim() !== SECURITY_ARM_PHRASE) {
      setAutopilotMsg(`请输入「${SECURITY_ARM_PHRASE}」`)
      return
    }
    if (autopilotTierPick === "unattended") {
      if (!unattendedAckDesktop || !unattendedAckSession) {
        setAutopilotMsg("请勾选两项确认（桌面值守静默 + 会话失效）")
        return
      }
    }
    const phrase = autopilotPhrase.trim()
    setAutopilotBusy(true)

    if (autopilotTierPick === "unattended") {
      // ADR-021: process grant via companion; dual-writes cruise flags server-side.
      // Background ACKs {ok:true|false}; real status arrives via WS broadcast
      // (security.unattended.status → SET_UNATTENDED_STATUS). Do not invent armed:true.
      chrome.runtime.sendMessage(
        {
          type: "security.unattended.arm",
          confirmation_phrase: phrase,
          include_protocol: unattendedIncludeProtocol === true,
          ack_desktop: true,
          ack_session: true,
        },
        (resp?: { ok?: boolean; error?: string }) => {
          const channelErr = chrome.runtime.lastError?.message
          if (channelErr) {
            // Classic MV3: SW did not answer (dead worker / no sendResponse).
            // Still probe status — a prior grant or delayed SW wake may succeed.
            setAutopilotMsg(
              channelErr.includes("message port closed")
                ? "扩展后台未响应（可能已休眠）。请：① 确认 Side Panel 顶部为「已连接」② chrome://extensions 点 CMspark「重新加载」后再试"
                : channelErr,
            )
            setAutopilotBusy(false)
            chrome.runtime.sendMessage({ type: "security.unattended.status" })
            return
          }
          if (resp && resp.ok === false) {
            setAutopilotMsg(resp.error || "武装失败")
            setAutopilotBusy(false)
            return
          }
          dispatch({
            type: "ADD_SECURITY_AUDIT",
            entry: {
              id: `unattended-on-${crypto.randomUUID()}`,
              ts: new Date().toISOString(),
              level: "error",
              tool_name: "unattended_desktop",
              action: "changed",
              risk_level: "high",
              risk_score: 100,
              source: "ui_phrase_confirmed",
              message:
                "已请求武装无人值守 — 进程内桌面 grant 生效（重启失效）。host_computer 的任务级 L2 与 mid-task re-L2 均静默通过（须 App 已允许坐标）。支付/验证码等硬拒绝仍直接失败、无确认窗。自担 prompt 注入与桌面键鼠风险。",
            },
          })
          setAutopilotConfirm(false)
          setAutopilotPhrase("")
          setAutopilotMsg(null)
          setAutopilotBusy(false)
          setAdvancedGatesOpen(true)
          // Reconcile flags + grant from companion (source of truth)
          chrome.runtime.sendMessage({ type: "config.get" })
          chrome.runtime.sendMessage({ type: "security.unattended.status" })
        },
      )
      return
    }

    // Non-unattended: dual-write flags only; clear any leftover unattended grant.
    // Do not invent armed:false — wait for security.unattended.status.
    chrome.runtime.sendMessage({ type: "security.unattended.disarm", clear_cruise: false }, () => {
      chrome.runtime.sendMessage({ type: "security.unattended.status" })
    })
    const target = targetFlagsForTier(
      autopilotTierPick,
      {
        auto_approve_dangerous: config.auto_approve_dangerous,
        auto_approve_enterprise_tools: config.auto_approve_enterprise_tools,
        allow_all_schemes: config.allow_all_schemes,
      },
    )
    applySecurityFlagsTarget(
      target,
      phrase,
      `武装运行自主度：${tierShortLabel(autopilotTierPick as AutopilotTier)}`,
    )
    setAutopilotConfirm(false)
    setAutopilotPhrase("")
    setAutopilotMsg(null)
    setAutopilotBusy(false)
    setAdvancedGatesOpen(true)
  }

  const handleAutopilotDisarm = () => {
    setAutopilotBusy(true)
    // Full disarm: companion SoT for grant + cruise; no optimistic SET_UNATTENDED_STATUS.
    chrome.runtime.sendMessage(
      { type: "security.unattended.disarm", clear_cruise: true },
      () => {
        if (chrome.runtime.lastError) {
          setAutopilotMsg(chrome.runtime.lastError.message || "解除失败（扩展通道）")
          setAutopilotBusy(false)
          return
        }
        applySecurityFlagsTarget(
          disarmAllFlags(),
          undefined,
          "解除运行自主度 / 无人值守（已关闭网页/企业/协议三类自动批准 + 桌面值守；进行中的桌面任务已请求中止）",
        )
        chrome.runtime.sendMessage({ type: "config.get" })
        chrome.runtime.sendMessage({ type: "security.unattended.status" })
        setAutopilotBusy(false)
        setAutopilotConfirm(false)
        setAutopilotPhrase("")
        setAutopilotMsg(null)
      },
    )
  }

  const handleShortcutChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    dispatch({ type: "SET_SEND_SHORTCUT", shortcut: e.target.value as any })
  }

  const handleTest = () => {
    // Reset both result channels — main LLM test always runs, vision test runs
    // only when the user has enabled 截图视觉分析. Showing both side-by-side
    // (instead of overwriting one result) lets the user see e.g. "主 API ✓ /
    // 视觉 ✗" without re-clicking.
    dispatch({ type: "SET_TEST_RESULT", result: "测试中..." })
    if (config.vision_enabled) {
      dispatch({ type: "SET_TEST_VISION_RESULT", result: "测试视觉模型中..." })
    } else {
      dispatch({ type: "SET_TEST_VISION_RESULT", result: null })
    }
    // Pass unsaved UI fields so the probe uses the same protocol/profile/url as Save.
    // api_key only when the user typed a real key; otherwise companion uses stored key.
    const llmOverride: Record<string, string> = {
      base_url: config.base_url,
      model_name: config.model_name,
      protocol: config.protocol === "anthropic" ? "anthropic" : "openai",
      client_header_profile:
        config.protocol === "anthropic" && config.client_header_profile === "claude_code_compat"
          ? "claude_code_compat"
          : "none",
    }
    if (config.api_key && config.api_key !== "***") {
      llmOverride.api_key = config.api_key
    }
    chrome.runtime.sendMessage({ type: "config.test", llmOverride })
    if (config.vision_enabled) {
      chrome.runtime.sendMessage({ type: "config.testVision" })
    }
  }

  const toggleSafetySkill = (skillId: string) => {
    const current = config.safety_skills_enabled || []
    const next = current.includes(skillId)
      ? current.filter(id => id !== skillId)
      : [...current, skillId]
    dispatch({ type: "SET_CONFIG", config: { safety_skills_enabled: next } })
  }

  return (
    <Modal
      open={state.settingsOpen}
      onClose={() => dispatch({ type: "TOGGLE_SETTINGS" })}
      overlayStyle={styles.backdrop}
      panelStyle={styles.panel}
      panelClassName="cm-settings-panel"
      ariaLabel="设置"
    >
        <div className="cm-settings-content" onFocusCapture={event => { lastSettingsFocus.current = event.target as HTMLElement }} {...(licenseDoorShouldOpen(state.computerModelLicenseDoor) ? { inert: "" } : {})}>
        <div className="cm-settings-header" style={styles.header}>
          <h3 style={{ margin: 0, fontSize: 15 }}>设置</h3>
          <button type="button" aria-label="关闭设置" className="cm-icon-button" style={styles.closeBtn} onClick={() => dispatch({ type: "TOGGLE_SETTINGS" })}>✕</button>
        </div>

        <div className="cm-settings-status">
          <span className="cm-sr-only" role="status" aria-live="polite">{[wsPaired === null ? "正在检测连接" : wsPaired === false ? "尚未配对" : "", elevatedTrust ? "有高权限开关已开启" : ""].filter(Boolean).join("；")}</span>
          {wsPaired !== true && <button type="button" onClick={() => selectSettingsPage("connection", true)}>{wsPaired === null ? "正在检测连接" : "尚未配对 · 前往连接设置"}</button>}
          {elevatedTrust && <button type="button" onClick={() => selectSettingsPage("security", true)}>有高权限开关已开启 · 查看安全设置</button>}
        </div>
        <div className="cm-settings-layout">
          <nav aria-label="设置分类" className="cm-settings-nav">
            {SETTINGS_PAGES.map(page => <button type="button" key={page.id} aria-current={activeSettingsPage === page.id ? "page" : undefined} onClick={() => selectSettingsPage(page.id, true)}>{page.title}</button>)}
          </nav>
          <label className="cm-settings-mobile-category">设置分类
            <select aria-label="设置分类" value={activeSettingsPage} onChange={event => selectSettingsPage(event.target.value as SettingsSectionId)}>{SETTINGS_PAGES.map(page => <option value={page.id} key={page.id}>{page.title}</option>)}</select>
          </label>
          <div className="cm-settings-body" style={styles.body}>
            <details className="cm-settings-assistant" onToggle={event => setSettingsAssistantOpen(event.currentTarget.open)}><summary>用一句话调整设置</summary><SettingsIntentBar onIntent={applySettingsIntent} active={settingsAssistantOpen && state.settingsOpen && !licenseDoorShouldOpen(state.computerModelLicenseDoor)} /></details>


SETTINGS FOOTER AND LICENSE
        <div className="cm-settings-footer" style={styles.footer}>
          <div style={{ display: "flex", flexDirection: "column", gap: 2, marginRight: "auto", textAlign: "left" }}>
            <span className="cm-settings-save-scope">保存配置草稿；独立表单与授权需分别提交。</span>
            {state.testResult && (
              <span style={{
                fontSize: 12,
                color: state.testResult.includes("成功") ? tokens.success : tokens.danger,
              }}>{state.testResult}</span>
            )}
            {state.testVisionResult && (
              <span style={{
                fontSize: 12,
                color: state.testVisionResult.includes("成功") ? tokens.success : tokens.danger,
              }}>{state.testVisionResult}</span>
            )}
          </div>
          <button style={styles.testBtn} onClick={handleTest}>
            {config.vision_enabled ? "测试模型连接（含视觉）" : "测试模型连接"}
          </button>
          <button
            style={{
              ...styles.saveBtn,
              ...(settingsSaveDisabled(state.configHydratedFromCompanion)
                ? { opacity: 0.5, cursor: "not-allowed" }
                : {}),
            }}
            className="cm-settings-save"
            onClick={handleSave}
            disabled={settingsSaveDisabled(state.configHydratedFromCompanion)}
            title={settingsSaveDisabledTitle(state.configHydratedFromCompanion)}
          >保存并关闭</button>
        </div>

        {state.companionConfig && (
          <div style={{
            fontSize: 11,
            color: tokens.textMuted,
            padding: "8px 16px",
            borderTop: `1px solid ${tokens.border}`,
            textAlign: "center",
          }}>
            Companion 全局配置已同步{state.companionConfig.model_name ? ` (${state.companionConfig.model_name})` : ""}
          </div>
        )}
        </div>
          {/* 许可证门:渲染 license_required 载荷原文(LICENSE_DOOR_TEXT 单一真源
              在 companion model-license.ts,扩展不复制不私编) */}
          {licenseDoorShouldOpen(state.computerModelLicenseDoor) && (
            <Modal
              open={true}
              onClose={() => dispatch({ type: "SET_COMPUTER_MODEL_LICENSE_DOOR", door: null })}
              overlayStyle={styles.backdrop}
              panelStyle={{ ...styles.panel, maxWidth: 520 }}
              ariaLabel="实验层许可证与免责声明"
            >
              <div style={styles.header}>
                <h3 style={{ margin: 0, fontSize: 15 }}>实验层许可证与免责声明</h3>
              </div>
              <div style={{ ...styles.body, maxHeight: 320, overflowY: "auto", whiteSpace: "pre-wrap" }}>
                {state.computerModelLicenseDoor!.licenseText}
              </div>
              <div style={{ ...styles.helpText, padding: "0 16px" }}>
                {state.computerModelLicenseDoor!.notice}
              </div>
              <div style={styles.footer}>
                <button
                  style={styles.secondaryBtn}
                  onClick={() => {
                    dispatch({ type: "SET_COMPUTER_MODEL_LICENSE_DOOR", door: null })
                    chrome.runtime.sendMessage({ type: "computer.model.license_response", accepted: false, source: "settings" })
                  }}
                >
                  拒绝(跳过本层)
                </button>
                <button
                  style={styles.saveBtn}
                  onClick={() => {
                    dispatch({ type: "SET_COMPUTER_MODEL_LICENSE_DOOR", door: null })
                    chrome.runtime.sendMessage({ type: "computer.model.license_response", accepted: true, source: "settings" })
                  }}
                >
                  接受并下载模型
                </button>
              </div>
            </Modal>
          )}


    </Modal>
  )
}

MACHINE ACTUAL LOG TAILS
ext-finalbuild2
  icon_16x16.png (903 bytes)
  icon_16x16@2x.png (3032 bytes)
  icon_32x32.png (3032 bytes)
  icon_32x32@2x.png (10596 bytes)
  icon_128x128.png (36424 bytes)
  icon_128x128@2x.png (116683 bytes)
  icon_256x256.png (116683 bytes)
  icon_256x256@2x.png (328574 bytes)
  icon_512x512.png (328574 bytes)
  icon_512x512@2x.png (788319 bytes)

Portal icon generation complete!

> cmspark-browser-agent@0.6.6 build
> tsc --noEmit && plasmo build

🟣 Plasmo v0.90.5
🔴 The Browser Extension Framework
🔵 INFO   | Prepare to bundle the extension...
🔵 INFO   | Building for target: chrome-mv3
🔵 INFO   | Loaded environment variables from: []
🟢 DONE   | Finished in 8180ms!
ext-finaltest2
  ...
# Subtest: shouldRefuseWsFrame allows an 8MB JSON payload
ok 1280 - shouldRefuseWsFrame allows an 8MB JSON payload
  ---
  duration_ms: 0.044
  type: 'test'
  ...
# Subtest: isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
ok 1281 - isFrameBudgetRefusal: only the stamped SW refusal matches (F6)
  ---
  duration_ms: 0.050167
  type: 'test'
  ...
1..1281
# tests 1281
# suites 0
# pass 1281
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 9357.75775
comp-lastbuild

> cmspark-agent@0.6.6 prebuild
> node scripts/generate-tray-icons.mjs

  tray-icon-green.png (654 bytes)
  tray-icon-red.png (627 bytes)
  tray-icon-yellow.png (683 bytes)

Portal tray icons generated!

> cmspark-agent@0.6.6 build
> tsc && node -e "const fs=require('fs'),p=require('path');fs.mkdirSync('dist/computer',{recursive:true});fs.copyFileSync('src/computer/qwen-vl-worker.py','dist/computer/qwen-vl-worker.py');process.platform!=='win32'&&fs.chmodSync('dist/index.js',0o755)"

comp-lasttest
      ...
    # Subtest: settings-cli: non-sensitive --set still works (model_name)
    ok 4 - settings-cli: non-sensitive --set still works (model_name)
      ---
      duration_ms: 0.230792
      type: 'test'
      ...
    1..4
ok 2 - settings-cli
  ---
  duration_ms: 2.055875
  type: 'suite'
  ...
1..2
# tests 20
# suites 2
# pass 20
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 51.677167
settings-final2
WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpog2ogm0i
PASS: settings pages responsive, all categories, retained model draft, stable deep links+focus, cross-page safety status, no implicit writes; cancelled voice callbacks, hidden hotkey capture, license keyboard isolation and focus restoration.
workspace-last
WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/cmspark-workspace-h7h40clt
PASS: actual App responsive matrix, drawer/history keyboard, settings/context, full-width input, tool disclosure, confirmation no-submit, reflow/reduced motion. Synthetic transport only.
summoner-final
WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpykm9t_20
PASS: real summoner script, reset without mark, history, input/action DOM order, keyboard-native attachment, send; synthetic HTTP/SSE only.
surfaces-final
WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmp5s8hgvxo
PASS: capture/settings real HTML CSS reflow; settings script unchanged and no summoner decorative mark. Scripts not executed.

Companion primary summary
# tests 5019
# pass 4996
# fail 0
# skipped 23
# tests 20
# pass 20
# fail 0
# skipped 0
