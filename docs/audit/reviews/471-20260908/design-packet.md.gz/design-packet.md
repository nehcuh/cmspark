Independent READ-ONLY design gate #471. User explicitly rejects prior superficial styling, wants summoner/chat visual consistency, no 山, logical settings. Evaluate correctness/a11y/trust and completeness. No edits/tools beyond this packet; return severity and VERDICT APPROVE/APPROVE_WITH_NITS/REJECT. No unsupported assertions about unseen code.
# 召唤器与设置重设计

GitHub: #471 · Base:4fd4919b · 2026-09-08

召唤器与主聊天保持同一套浅色、文字层级、圆角输入区和底部操作排布。删除页头、初始及动态空态的“山”，不替换成其他大图标。空态以一句提示开始；历史/新对话保留；附件、听写、发送在输入框下，会议/打开浏览器为次要动作。保留全部 id、协议、状态及确认边界。独立设置网页也改浅色配置表面。

设置改为命名分类导航与单个当前内容页，宽屏左导航、窄屏紧凑分类选择。分类：模型与推理、输入与语音、文件与知识、连接与配对、安全与信任、本机与工具、密钥与环境、实验功能。模型页仅含模型/视觉/推理预算；语音与快捷键独立；上传、笔记导出与会话索引集中到文件与知识；既有权限/集成控件保留并加清楚子标题。

稳定设置 id 保持：model/connection/security/integrations/secrets/experimental；export 显示为文件与知识，新增 voice。旧深链继续可用；语音入口指向 voice。各配置页保持挂载，仅隐藏非当前页，保证未保存输入、权限确认短语和下载状态不因切页丢失。原有控件保存时机保持：全局保存仍统一保存，立即生效项目保留原语义和说明。配对/高权限状态跨分类可见且可定位。保存/测试只一处常驻，键盘 DOM 顺序与视觉一致，废除 CSS order 排列。

验证：实际 React 页320/390/800/1440与短屏，无横向溢出；每类可达；字段草稿切页保留；旧深链/voice深链；安全标识与原确认控件；真实召唤HTML脚本在隔离传输下新建对话/输入/历史，山不会恢复；生产构建及相关全量套件。Grok4.6 + DeepSeekV4Pro设计/实现独立复审，最终CI全绿后合并；无发布安装。

Existing invariants: SettingsSection keeps children mounted when hidden; userOpenSections formerly persisted; current open deep link adds target to open set and clears store request; each form has existing own save handler or unified save. Confirmation handlers/defaults are unchanged. Some integration children own internal drafts. Voice setters require target page update.
// Collapsible settings section shell (settings-thread-compact W1).

import type { ReactNode } from "react"
import { tokens } from "../ui/tokens"

export function SettingsSection({
  title,
  open,
  onToggle,
  badge,
  children,
  forceHint,
}: {
  title: string
  open: boolean
  onToggle: () => void
  /** Always-visible when collapsed (e.g. armed trust). */
  badge?: ReactNode
  children: ReactNode
  /** Optional subline under header when force-open (e.g. 未配对). */
  forceHint?: string | null
}) {
  return (
    <section style={styles.section} data-settings-section={title}>
      <button
        type="button"
        style={styles.header}
        onClick={onToggle}
        aria-expanded={open}
      >
        <span style={styles.chevron} aria-hidden>
          {open ? "▼" : "▶"}
        </span>
        <span style={styles.title}>{title}</span>
        {badge != null && <span style={styles.badgeSlot}>{badge}</span>}
      </button>
      {forceHint && !open && (
        <div style={styles.forceHint}>{forceHint}</div>
      )}
      {/* Keep children mounted when closed so arm phrase panels / forms are not torn down (D-S8). */}
      <div
        style={{
          display: open ? "block" : "none",
          paddingTop: 4,
          paddingBottom: 8,
        }}
        aria-hidden={!open}
      >
        {children}
      </div>
    </section>
  )
}

const styles: Record<string, React.CSSProperties> = {
  section: {
    borderBottom: `1px solid ${tokens.border}`,
    marginBottom: 4,
  },
  header: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 0",
    border: "none",
    background: "transparent",
    cursor: "pointer",
    textAlign: "left",
    minHeight: 40,
  },
  chevron: {
    fontSize: 10,
    color: tokens.textMuted,
    width: 12,
    flexShrink: 0,
  },
  title: {
    fontSize: 13,
    fontWeight: 600,
    color: tokens.text,
    flex: 1,
    letterSpacing: "-0.01em",
  },
  badgeSlot: {
    flexShrink: 0,
  },
  forceHint: {
    fontSize: 11,
    color: tokens.warning,
    padding: "0 0 6px 20px",
  },
}
