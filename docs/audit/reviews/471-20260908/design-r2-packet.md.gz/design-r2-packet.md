Independent READ-ONLY design re-review #471. Close/retain first-round concerns: trust strip placement/content/live/focus/modal reachability; save-scope composition; complete IA/stable IDs/migration/voice setters; nav a11y; concrete visual contract. No implementation approval requested. Return concise VERDICT.
# 召唤器与设置重设计

GitHub: #471 · Base:4fd4919b · 2026-09-08

召唤器与主聊天保持同一套浅色、文字层级、圆角输入区和底部操作排布。删除页头、初始及动态空态的“山”，不替换成其他大图标。空态以一句提示开始；历史/新对话保留；附件、听写、发送在输入框下，会议/打开浏览器为次要动作。保留全部 id、协议、状态及确认边界。独立设置网页也改浅色配置表面。

设置改为命名分类导航与单个当前内容页，宽屏左导航、窄屏紧凑分类选择。分类：模型与推理、输入与语音、文件与知识、连接与配对、安全与信任、本机与工具、密钥与环境、实验功能。模型页仅含模型/视觉/推理预算；语音与快捷键独立；上传、笔记导出与会话索引集中到文件与知识；既有权限/集成控件保留并加清楚子标题。

稳定设置 id 保持：model/connection/security/integrations/secrets/experimental；export 显示为文件与知识，新增 voice。旧深链继续可用；语音入口指向 voice。各配置页保持挂载，仅隐藏非当前页，保证未保存输入、权限确认短语和下载状态不因切页丢失。原有控件保存时机保持：全局保存仍统一保存，立即生效项目保留原语义和说明。配对/高权限状态跨分类可见且可定位。保存/测试只一处常驻，键盘 DOM 顺序与视觉一致，废除 CSS order 排列。

验证：实际 React 页320/390/800/1440与短屏，无横向溢出；每类可达；字段草稿切页保留；旧深链/voice深链；安全标识与原确认控件；真实召唤HTML脚本在隔离传输下新建对话/输入/历史，山不会恢复；生产构建及相关全量套件。Grok4.6 + DeepSeekV4Pro设计/实现独立复审，最终CI全绿后合并；无发布安装。

## 设计门禁补充（首轮意见逐项落实）

### 公共状态与确认可达性

设置标题下、分类/内容区外常驻状态行（320与1440同一DOM，窄屏换行；无状态不占位）。文案：检测中“正在检测连接”；未配对“尚未配对 · 前往连接设置”；已有高权限“有高权限开关已开启 · 查看安全设置”。原生按钮分别切到connection/security并聚焦标题；容器role=status/aria-live=polite，状态更新不抢焦点。高权限沿用isElevatedTrust，不引入新的权限判断。正在编辑的安全确认短语保留在security页，用户可用公共安全入口返回；真正的模态许可确认提升到公共内容区外，保持原按钮/顺序/处理器和焦点陷阱，避免被隐藏页遮蔽。

### 保存范围（“一处”指公共配置栏，不删除独立表单按钮）

| 类别 | 保存与测试 | 切页时未保存内容 |
|---|---|---|
| config模型/视觉/上下文/文件/会话索引 | 公共“保存全部配置”调用原handleSave一次，保存完整state.config；公共“测试模型连接”调用原handleTest，测当前草稿模型/视觉参数，与所在页无关 | 留在同一store，切页不保存 |
| 语音/快捷键等本机偏好 | 原即时处理器，页说明标明即时生效；下载/启用各自按钮保留 | React本地草稿保持挂载，不自动提交 |
| UserEnv/MCP/网络/编程开关 | 原独立保存/确认按钮保留，各页说明其独立语义 | 不纳入虚假的“保存所有独立表单”；组件保持挂载 |
| 许可/授权短语 | 原确认流程，公共保存不替代 | 切页不批准；Modal不埋在hidden树 |

公共栏始终展示“保存全部配置”“测试模型连接”，不使用“取消全部更改”承诺。页说明明确独立保存与即时生效，原config hydration门禁不动。

### 完整移动清单与稳定标识

| id（旧入口仍兼容） | 展示名 | 原控件归属 |
|---|---|---|
| model | 模型与推理 | 原model中协议/端点/key/预设/模型/主模型看图/温度 + Context Window/压缩/思考 + 完整视觉模型块；删除语音/文件块 |
| voice（新增） | 输入与语音 | 原model中“发送快捷键”起，到“Context Window”前的完整语音块（浏览器/本机/系统引擎、隐私、refiner、热键、下载/说话人模型） |
| export | 文件与知识 | 原model的File Upload Settings整个块 + 原experimental的Thread History IA session index块 + 原export所有笔记导出字段 |
| connection | 连接与配对 | 原connection完整块 |
| security | 安全与信任 | 原security完整块，所有arm/disarm/短语/警告/白名单不变 |
| integrations | 本机与工具 | 原integrations完整CapabilityProfile/NetSec/OutboundMcp/CodingHandoff及全部props；“下方自主度”改明确指向安全分类 |
| secrets | 密钥与环境 | 完整UserEnvSection |
| experimental | 实验功能 | 原实验本地视觉模型/许可证/下载管理；会话索引移出 |

useComposerVoice的原model深链改voice；所有设置自然语言的语音intent选voice，open_meeting/open_scene继续离开设置。其余model/integrations/export旧深链仍选同id页。旧折叠偏好不删除，新的单页布局不再消费它；会话首次默认model，未知/未配对回调在用户尚未选页时选connection；明确深链/人工选页不被迟到配对回调覆盖。分类选择在当前设置组件会话内保留。

### 导航与视觉规格

>=760：172px浅灰左侧nav，原生button（Tab/Enter/Space），aria-current=page；激活聚焦内容h3 tabindex=-1并将内容滚动归零。<760：有可见“设置分类”标签的原生select（系统键盘行为），选择后保留select焦点，内容标题同步；非当前页hidden，仍挂载且不进入Tab。对话框高度88dvh（窄屏94dvh），中间内容独立滚动，底部配置栏常驻。标题20px（窄屏18）、正文13–14、说明12、控件>=36px；浅色表面、8px控件圆角、16px外框、24/16px边距，沿用tokens。

召唤HTML以CSS变量镜像chat：paper #fff、canvas #f7f7f5、text #171717、secondary #666、focus #4f46e5、send #242424、user bubble #f3f3f1；系统字体14px/1.7，输入圆角20px、操作36px。页头纯文字CMspark+历史/新对话/既有档位，空态沿用CHAT_SHELL_TITLE_NONE，副行“回车发送。附件和听写不用开浏览器。”。输入textarea在前，附件→听写→发送按真实DOM排列；会议/打开浏览器留在输入区下方描边次按钮。不藏进菜单。山全源搜索：只在页头、初始空态、renderMsgs空态三个位置，无其他loading/error图标路径；三处全部删除。

独立settings-web是只配置全局模型的备用网页，不伪造扩展八类能力；沿用浅色表面、中文页名和表单层级，原端点/权限范围不扩展。
