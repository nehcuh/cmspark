READ-ONLY short closure addendum #471. At most 350 words. Both final reviewers APPROVE_WITH_NITS (design+implementation, no P0/P1/MAJOR). No production source changed since final manifest. Only additional UI test asserts the desktop selected navigation background + font weight. Grok final NIT-1 claimed no selected CSS was evidenced; r1→current delta omitted unchanged selected rule. FULL existing CSS below proves rule present; actual browser computation test passes for each desktop category. Initial immediate assertion sampled pre-transition transparent style; corrected to await stable computed style after pointer leaves. This is fixture timing, not a production change. Verify current selected-nav recipe closes NIT-1 and no new blockers in test delta. Other non-blocking nits accepted: consistent status on current page, shared h3 hierarchy, redundant select aria-label, compact controls36px; existing first-open-license/no-prior-focus fallback and mixed immediate export checkbox copy are tracked residual usability refinements. No new permission or execution. Return VERDICT APPROVE / APPROVE_WITH_NITS / REJECT and explicitly close or retain selected-nav finding. Do not re-review unchanged product scope, do not invent unseen CSS.

FULL FILE chrome-extension/src/sidepanel/ui/workspace-styles.ts
import { tokens } from "./tokens"

/** Scoped shell styles; colors remain owned by tokens.ts. */
export const workspaceCSS = `
.cm-workspace{display:flex;height:100dvh;min-height:0;width:100%;overflow:hidden;background:${tokens.bg};font-family:${tokens.font};color:${tokens.text}}
.cm-workspace-main{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;position:relative}
.cm-navigation{width:220px;height:100%;box-sizing:border-box;flex-shrink:0;display:flex;flex-direction:column;padding:20px 12px 12px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};gap:6px;overflow-y:auto}
[aria-label="工作区导航"] .cm-navigation{width:100%}
.cm-nav-brand{display:flex;align-items:center;gap:10px;padding:0 8px 20px;font-size:15px;letter-spacing:-.03em}
.cm-nav-brand .cm-icon-button{margin-left:auto}
.cm-nav-new,.cm-nav-item,.cm-nav-thread{font:inherit;border:0;border-radius:${tokens.radiusMd}px;cursor:pointer;display:flex;align-items:center;gap:10px;text-align:left;min-height:36px;width:100%;padding:8px 10px;color:${tokens.text};background:transparent;font-size:13px;flex-shrink:0}
.cm-nav-new{background:${tokens.bgElevated};border:1px solid ${tokens.border};margin-bottom:10px;font-weight:500}
.cm-nav-item:hover,.cm-nav-thread:hover,.cm-icon-button:hover{background:${tokens.bgHover}}
.cm-nav-resources{display:grid;grid-template-columns:1fr 1fr;gap:2px;margin-bottom:16px}
.cm-nav-resources .cm-nav-item{font-size:12px;gap:6px;padding:8px 6px;min-width:0}
.cm-nav-resources .cm-nav-item span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cm-nav-section{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:${tokens.textSecondary};padding:0 8px}
.cm-nav-search{box-sizing:border-box;width:100%;border:1px solid ${tokens.border};border-radius:${tokens.radiusMd}px;padding:9px 10px;font:inherit;font-size:12px;background:${tokens.bgElevated};color:${tokens.text}}
.cm-nav-threads{flex:1;min-height:80px;overflow-y:auto;margin-top:4px}
.cm-nav-thread{min-height:38px;color:${tokens.textSecondary}}
.cm-nav-thread>span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.cm-nav-item[aria-current="true"],.cm-nav-thread[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:500}
.cm-nav-running{color:${tokens.success};font-size:20px}
.cm-nav-empty{font-size:12px;color:${tokens.textSecondary};padding:8px}
.cm-nav-settings{margin-top:12px;border-top:1px solid ${tokens.border};border-radius:0;padding-top:14px}
.cm-icon-button{display:inline-flex;align-items:center;justify-content:center;min-width:32px;min-height:32px;border:0;background:transparent;color:${tokens.textSecondary};border-radius:${tokens.radiusMd}px;cursor:pointer;font-size:18px}
.cm-task-title{font-size:13px;font-weight:500;min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-left:8px}
.cm-chat-content,.cm-composer-dock{width:100%;max-width:780px;margin-left:auto;margin-right:auto;box-sizing:border-box}
.cm-composer-dock{padding:12px 20px 18px!important}
.cm-composer-actions{display:flex;align-items:center;gap:8px;min-width:0}
.cm-composer-capsule:focus-within{border-color:${tokens.accent}!important;box-shadow:${tokens.shadowFocus}!important}
.cm-workspace button:focus-visible,.cm-workspace [role="button"]:focus-visible,.cm-workspace input:focus-visible,.cm-workspace textarea:focus-visible,[role="dialog"] button:focus-visible,[role="dialog"] input:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
.cm-workspace button:disabled{cursor:not-allowed}
.cm-settings-panel{width:min(780px,100vw - 32px)!important;max-height:88dvh!important;border-radius:${tokens.radiusSheet}px!important;box-shadow:${tokens.shadowLg}}
.cm-settings-header{padding:20px 24px!important}
.cm-settings-body{padding:8px 24px 24px!important}
.cm-context-panel{max-height:min(36dvh,360px)!important;margin:0 16px;border:1px solid ${tokens.border};border-radius:${tokens.radiusLg}px;box-shadow:${tokens.shadowSm}}
.cm-history-group{flex:1;border:0;background:transparent;color:inherit;font:inherit;text-align:left;min-height:32px;cursor:pointer;padding:4px 0}
.cm-navigation-toggle{gap:4px;flex-shrink:0}
.cm-history-panel{max-width:720px;margin:0 auto}
.cm-history-panel button:focus-visible,.cm-history-panel [role="button"]:focus-visible{outline:2px solid ${tokens.accent};outline-offset:-2px}
@media(min-width:760px){.cm-navigation-toggle{display:none!important}.cm-status-rail{padding:12px 24px!important;border-bottom:1px solid ${tokens.border}!important}.cm-chat-scroll{padding:28px 32px!important}.cm-composer-dock{padding-bottom:24px!important}}
@media(max-width:759px){.cm-workspace{flex-direction:column}.cm-navigation-disclosure{flex-shrink:0;max-height:28dvh;overflow:auto;border-bottom:1px solid ${tokens.border}}.cm-navigation-disclosure .cm-navigation{height:auto;width:100%}.cm-task-title{font-size:12px}.cm-composer-dock{padding:8px 12px 12px!important}.cm-settings-panel{align-self:flex-end;width:100%!important;max-height:90dvh!important;border-radius:16px 16px 0 0!important}.cm-settings-header{padding:16px!important}.cm-settings-body{padding:8px 16px 16px!important}}
@media(max-height:560px){.cm-context-panel{max-height:28dvh!important}.cm-composer-dock{padding-top:4px!important;padding-bottom:6px!important}.cm-navigation{padding-top:10px}.cm-nav-brand{padding-bottom:8px}.cm-nav-resources{margin-bottom:4px}.cm-nav-new{margin-bottom:2px}}
@media(prefers-reduced-motion:reduce){.cm-workspace *{animation:none!important;transition:none!important;scroll-behavior:auto!important}}

.cm-settings-panel{width:min(980px,100vw - 32px)!important;height:88dvh;max-height:88dvh!important}
.cm-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap;border:0}
.cm-settings-content{display:flex;flex-direction:column;flex:1;min-height:0}
.cm-settings-save-scope{font-size:11px;color:${tokens.textSecondary};line-height:1.5}
.cm-settings-panel button{min-height:36px}
.cm-settings-page-heading h3:focus-visible,.cm-settings-panel select:focus-visible,.cm-settings-panel summary:focus-visible{outline:2px solid ${tokens.accent};outline-offset:3px}
.cm-settings-layout{display:flex;flex:1;min-height:0;overflow:hidden}
.cm-settings-nav{box-sizing:border-box;width:172px;flex-shrink:0;padding:16px 10px;background:${tokens.bgMuted};border-right:1px solid ${tokens.border};overflow-y:auto}
.cm-settings-nav button{display:block;width:100%;min-height:40px;padding:10px 12px;margin:2px 0;border:0;border-radius:8px;background:transparent;color:${tokens.textSecondary};font:inherit;font-size:13px;text-align:left;cursor:pointer}
.cm-settings-nav button[aria-current="page"]{background:${tokens.navSelected};color:${tokens.text};font-weight:600}
.cm-settings-nav button:hover{background:${tokens.bgHover}}
.cm-settings-layout .cm-settings-body{flex:1;min-width:0;padding:20px 28px 28px!important;overflow:auto}
.cm-settings-page-heading{padding:0 0 20px;margin-bottom:16px;border-bottom:1px solid ${tokens.border}}
.cm-settings-page-title{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.cm-settings-page-heading h3{font-size:20px;font-weight:600;letter-spacing:-.03em;margin:0 0 8px}
.cm-settings-page-heading p{font-size:12px;line-height:1.7;color:${tokens.textSecondary};margin:8px 0 0}
.cm-settings-status{display:flex;gap:8px;flex-wrap:wrap;padding:0 24px 8px}
.cm-settings-status:not(:has(button)){padding:0}
.cm-settings-status button{background:${tokens.warningSoft};color:${tokens.text};border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;min-height:36px;font:inherit;font-size:12px;cursor:pointer}
.cm-settings-assistant{margin-bottom:20px;font-size:12px;color:${tokens.textSecondary}}
.cm-settings-assistant summary{cursor:pointer;min-height:36px}
.cm-settings-mobile-category{display:none}
.cm-settings-footer{flex-wrap:wrap;padding:12px 24px!important;gap:8px!important}
.cm-settings-footer button{min-height:36px}
.cm-settings-footer .cm-settings-save{background:${tokens.actionPrimary}!important}
.cm-settings-body input,.cm-settings-body select,.cm-settings-body textarea{max-width:100%;box-sizing:border-box}
@media(max-width:759px){.cm-settings-panel{height:94dvh;max-height:94dvh!important;width:100%!important}.cm-settings-layout{flex-direction:column}.cm-settings-nav{display:none}.cm-settings-mobile-category{display:flex;align-items:center;gap:12px;padding:10px 16px;background:${tokens.bgMuted};border-bottom:1px solid ${tokens.border};font-size:12px;color:${tokens.textSecondary}}.cm-settings-mobile-category select{flex:1;min-width:0;min-height:36px;border:1px solid ${tokens.border};border-radius:8px;padding:6px 10px;background:${tokens.bg};color:${tokens.text};font:inherit}.cm-settings-layout .cm-settings-body{padding:16px!important}.cm-settings-status{padding:0 16px 8px}.cm-settings-page-heading h3{font-size:18px}.cm-settings-footer{padding:10px 16px!important}}
.cm-settings-body input:not([type="checkbox"]):not([type="radio"]):not([type="range"]),.cm-settings-body select{min-height:36px}
`

FULL FILE chrome-extension/src/sidepanel/ui/tokens.ts
// Shared React palette. Root DESIGN.md owns the current workspace direction.
// Neutral conversation surfaces; indigo links/focus; semantic risk colors.

export const tokens = {
  font:
    "-apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', 'PingFang SC', 'Helvetica Neue', sans-serif",
  fontMono: "ui-monospace, 'SF Mono', Menlo, Consolas, monospace",

  // Light companion canvas
  bg: "#ffffff",
  bgElevated: "#ffffff",
  bgMuted: "#f7f7f5",
  bgHover: "#eeeeec",
  actionPrimary: "#242424",
  navSelected: "#e9e9e6",
  bgActive: "#eef2ff",
  border: "rgba(23, 23, 23, 0.10)",
  borderStrong: "rgba(23, 23, 23, 0.14)",
  text: "#171717",
  textSecondary: "#666666",
  textMuted: "#767676",
  /** Empty-state hero only — not chrome. */
  emptyTitle: 22,

  // Indigo accent — links, focus and secondary highlighted controls
  accent: "#4f46e5",
  accentSoft: "#eef2ff",
  accentText: "#3730a3",
  accentHover: "#4338ca",
  /** Hairline indigo border on soft accent surfaces (status bubble). */
  accentBorderSoft: "rgba(79, 70, 229, 0.12)",

  /**
   * Brand red (terracotta / coral) — empty-state calf mark ONLY.
   * Independent of the danger family: hue 15° vs danger 0°, lighter + higher
   * chroma, so protanopia/deuteranopia simulation keeps ΔE00 ≫ 5 from
   * danger (#c96033 previously collapsed to ~3 under deutan). NEVER reuse
   * danger / dangerSoft / dangerSurface as brand red. Value pinned by
   * tests/calf-mark-323.test.ts (normal ≥10 AND Machado-deutan ≥5).
   */
  brandRed: "#d97757",

  success: "#059669",
  successSoft: "#ecfdf5",
  warning: "#d97706",
  warningSoft: "#fffbeb",
  /** Amber-200 border on warning surfaces (fakeEnd / compact banner). */
  warningBorder: "#fde68a",
  /** Amber-800 text on warningSoft surfaces. */
  warningText: "#92400e",
  danger: "#dc2626",
  dangerSoft: "#fef2f2",
  /** Soft confirm / FocusBand tint (G3; defined early for one SoT) */
  dangerSurface: "rgba(220, 38, 38, 0.08)",
  /** Danger border on light confirm surfaces (FocusBand confirm card). */
  dangerBorder: "rgba(220, 38, 38, 0.28)",
  /** Deep danger border on dark surfaces (急停 / abort buttons). */
  dangerDeep: "#7f1d1d",
  /** Mic-pulse keyframe ring (rgba of danger, start / fade-out end). */
  dangerPulse: "rgba(220, 38, 38, 0.35)",
  dangerPulseFade: "rgba(220, 38, 38, 0)",

  // Mode chips (badge only — no full-rail fill on L0/L1)
  modeChatBg: "#f1f5f9",
  modeChatText: "#334155",
  modeBrowserBg: "#eef2ff",
  modeBrowserText: "#3730a3",
  modeComputerBg: "#052e16",
  modeComputerText: "#6ee7b7",
  /** 3–4px accent line under StatusRail when L1/L2 (not full tint fill) */
  modeBrowserLine: "rgba(79, 70, 229, 0.35)",
  modeComputerLine: "rgba(52, 211, 153, 0.45)",

  // Dark surface (L2 / Cockpit)
  darkBg: "#171717",
  darkElevated: "#222222",
  darkBorder: "rgba(255, 255, 255, 0.08)",
  darkText: "#f1f5f9",
  darkMuted: "#94a3b8",
  darkAccent: "#818cf8",
  darkLive: "#34d399",
  darkDanger: "#f87171",
  darkDangerBg: "#3b1f1f",
  darkWarning: "#fbbf24",
  darkWarningBg: "#422006",
  darkSuccess: "#34d399",

  // Quiet neutral user bubble; assistant prose remains unboxed.
  userBubbleBg: "#f3f3f1",
  /** User-bubble copy. Distinct from userBubbleText (on-accent/on-danger glyphs). */
  userBubbleInk: "#171717",
  userBubbleBorder: "rgba(23, 23, 23, 0.04)",
  /**
   * On-accent / on-danger glyph (send armed, filled buttons). Historical name
   * `userBubbleText` kept so Settings/danger buttons do not silently go dark.
   * User bubble copy uses `userBubbleInk`.
   */
  userBubbleText: "#ffffff",
  assistantBubbleBg: "#ffffff",
  assistantBubbleText: "#0f172a",

  // Motion (Phase 3 — tightened from 150/220)
  transitionFast: "120ms",
  transition: "180ms",

  // Shape: controls 6/8/12; composer matches 看山 invitation (16)
  radiusSm: 6,
  radiusMd: 8,
  radiusLg: 12,
  radiusComposer: 20,
  radiusBubble: 14,
  /** Bottom sheet / 装配 drawer top corners */
  radiusSheet: 16,
  /** Popup menus (StatusRail ⋯ / panel ⋮) */
  radiusMenu: 10,
  radiusPill: 999,

  // One soft elevation ladder — hairline borders do most of the work
  shadowSm: "0 1px 2px rgba(15, 23, 42, 0.04)",
  shadowMd: "0 1px 3px rgba(15, 23, 42, 0.06), 0 4px 12px rgba(15, 23, 42, 0.04)",
  shadowLg: "0 4px 16px rgba(15, 23, 42, 0.08), 0 12px 28px rgba(15, 23, 42, 0.05)",
  shadowFocus: "0 0 0 3px rgba(79, 70, 229, 0.16)",
  /** Quiet indigo glow for accent controls. Not a user-bubble fill. */
  shadowAccent: "0 2px 10px rgba(79, 70, 229, 0.20)",
  /** Lightweight popover/dialog elevation (summary card). */
  shadowPopover: "0 4px 16px rgba(0, 0, 0, 0.08)",

  /** Near-transparent tint for quiet containers (reasoning wrap). */
  bgSubtle: "rgba(15, 23, 42, 0.03)",
  /** Mono output surfaces inside bubbles (shell stdout / tool-progress tail). */
  shellOutputBg: "rgba(0, 0, 0, 0.28)",
  toolTailBg: "rgba(0, 0, 0, 0.25)",

  /**
   * Unarmed send button SoT (#321 PR-4). Dedicated zinc fill — not `bgMuted`
   * (canvas mute). FINAL-SYNTHESIS said "bgMuted"; PR-1 added this token for
   * the circular send and it remains the button-specific SoT.
   */
  sendDisabledBg: "#e4e4e7",

  /** Thin, quiet global scrollbar (App global css). */
  scrollbar: "rgba(15, 23, 42, 0.18)",
  scrollbarThumb: "rgba(15, 23, 42, 0.16)",

  /** Modal / drawer scrim */
  scrim: "rgba(15, 23, 42, 0.28)",
  /** Stronger scrim for blocking import/confirm overlays. */
  scrimStrong: "rgba(0, 0, 0, 0.35)",
} as const

export type Tokens = typeof tokens

/** Risk level → light-surface color (never color-only; pair with text label). */
export function riskColor(level?: string): string {
  if (level === "low") return tokens.warning
  if (level === "medium") return tokens.warning
  return tokens.danger
}

/** Risk level → dark-surface color (SafetyStrip / MinimalConfirm). */
export function riskColorDark(level?: string): string {
  if (level === "low") return tokens.darkWarning
  if (level === "medium") return "#fb923c"
  return tokens.darkDanger
}

export function riskLabel(level?: string): string {
  if (level === "low") return "低风险"
  if (level === "medium") return "中风险"
  return "高风险"
}

/** Tool / task status → semantic color. */
export function statusColor(status?: string): string {
  if (status === "error" || status === "failed") return tokens.danger
  if (status === "success" || status === "ok" || status === "finished") return tokens.success
  if (status === "running" || status === "paused") return tokens.warning
  return tokens.textMuted
}

/** WS connection state — StatusRail / popup dots. Never Material #4CAF50/#FF9800/#F44336. */
export type ConnectionStatus = "connected" | "connecting" | "disconnected"

export function connectionColor(state: ConnectionStatus): string {
  if (state === "connected") return tokens.success
  if (state === "connecting") return tokens.warning
  return tokens.danger
}

export function connectionLabel(state: ConnectionStatus): string {
  if (state === "connected") return "已连接"
  if (state === "connecting") return "连接中"
  return "未连接"
}

/** Soft glow under connected dot (rgba of tokens.success #059669). */
export function connectionDotShadow(state: ConnectionStatus): string {
  if (state === "connected") return "0 0 0 3px rgba(5, 150, 105, 0.18)"
  return "none"
}

/**
 * Connection colors for dark surfaces (Cockpit title bar / L2 chrome).
 */
export function connectionColorDark(state: ConnectionStatus): string {
  if (state === "connected") return tokens.darkLive
  if (state === "connecting") return tokens.darkWarning
  return tokens.darkDanger
}

/** Soft glow under connected dot on dark (rgba of tokens.darkLive #34d399). */
export function connectionDotShadowDark(state: ConnectionStatus): string {
  if (state === "connected") return "0 0 0 3px rgba(52, 211, 153, 0.22)"
  return "none"
}

FULL FILE chrome-extension/scripts/test-settings-pages-ui.py
"""Actual App settings pages with synthetic transport; no live config changes."""
from pathlib import Path
import subprocess,tempfile
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent.parent
shots=Path('/private/tmp/cmspark-471-shots');shots.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory() as out:
 subprocess.run(['node','scripts/render-workspace-fixture.cjs',out],cwd=root,check=True)
 with sync_playwright() as p:
  b=p.chromium.launch(channel='chrome',headless=True);page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(6000)
  page.add_init_script('window.recEvents=[];window.SpeechRecognition=class { constructor(){window.fakeRecognition=this} start(){window.activeRecognition=this} stop(){window.recEvents.push("stop");this.onend?.()} abort(){window.recEvents.push("abort");this.aborted=true;this.onend?.()} };')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto((Path(out)/'index.html').as_uri());page.wait_for_function('Boolean(window.dispatchUI)')
  page.evaluate("window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'model'})")
  settings=page.get_by_role('dialog',name='设置',exact=True);settings.wait_for()
  model=page.get_by_placeholder('输入模型名称或从列表选择',exact=True);model.fill('fixture-model-draft')
  pages=['model','voice','export','connection','security','integrations','secrets','experimental']
  for width,height in [(1440,900),(800,700),(390,740),(320,480)]:
   page.set_viewport_size({'width':width,'height':height})
   for id in pages:
    if width>=760:
     settings.locator('.cm-settings-nav button').nth(pages.index(id)).click()
    else:settings.get_by_role('combobox',name='设置分类',exact=True).select_option(id)
    if width>=760:
     current=settings.locator('.cm-settings-nav button[aria-current="page"]')
     assert current.count()==1
     page.mouse.move(0,0)
     page.wait_for_function('getComputedStyle(document.querySelector(".cm-settings-nav button[aria-current=page]")).backgroundColor==="rgb(233, 233, 230)"')
     assert current.evaluate('(el)=>getComputedStyle(el).fontWeight')=='600'
    panel=settings.locator('[data-settings-page="'+id+'"]');panel.wait_for(state='visible')
    assert settings.locator('[data-settings-page]:visible').count()==1
    assert settings.evaluate('(el)=>el.scrollWidth<=el.clientWidth'),(width,id,'horizontal overflow')
    save=settings.get_by_role('button',name='保存并关闭',exact=True).bounding_box();assert save and save['y']+save['height']<=height,(width,id,save)
   page.evaluate("window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'model'})")
   model.wait_for();assert model.input_value()=='fixture-model-draft'
   page.wait_for_function('document.activeElement?.id==="settings-page-model"')
   page.screenshot(path=str(shots/f'settings-model-{width}.png'))
  assert not page.evaluate('window.sent.some(x=>x.type==="config.set" || x.type.includes("license_response") || x.type==="terminal.start")')
  page.evaluate("window.dispatchUI({type:'SET_CONFIG',config:{auto_approve_dangerous:true}});window.dispatchUI({type:'OPEN_SETTINGS_SECTION',section:'voice'})")
  settings.get_by_role('button',name='有高权限开关已开启 · 查看安全设置',exact=True).wait_for()
  assert not model.is_visible()
  settings.get_by_role('button',name='有高权限开关已开启 · 查看安全设置',exact=True).click()
  settings.locator('[data-settings-page="security"]').wait_for(state='visible')
  assistant=settings.get_by_test_id('settings-intent-bar')
  settings.locator('.cm-settings-assistant summary').click()
  assistant.get_by_role('button',name='语音',exact=True).click()
  page.evaluate('window.commandRecognition=window.activeRecognition')
  before=page.evaluate('window.fixtureState.voiceDictationMode')
  page.evaluate('window.commandRecognition=window.activeRecognition;window.commandRecognition.onresult({results:[Object.assign([{transcript:"开启连续听写"}],{isFinal:true})]});window.lateEnd=window.commandRecognition.onend;void 0')
  settings.locator('.cm-settings-assistant summary').click()
  page.wait_for_timeout(150)
  page.wait_for_function('window.commandRecognition.aborted===true')
  page.evaluate('window.lateEnd()');page.wait_for_timeout(100)
  assert page.evaluate('window.fixtureState.voiceDictationMode')==before, 'Collapsed voice must not execute queued result'
  settings.locator('.cm-settings-assistant summary').click()
  assistant.get_by_text('语音输入已取消',exact=True).wait_for()
  assistant.get_by_role('button',name='语音',exact=True).click()
  page.evaluate('window.commandRecognition=window.activeRecognition;window.commandRecognition.onresult({results:[Object.assign([{transcript:"开启连续听写"}],{isFinal:true})]})')
  assistant.get_by_role('button',name='停止',exact=True).click()
  page.wait_for_function('window.fixtureState.voiceDictationMode==="continuous"')
  # A real store license payload is global to settings, independent of current category.
  page.set_viewport_size({'width':800,'height':700})
  page.evaluate("window.dispatchUI({type:'SET_DICTATION_HOTKEY_ENABLED',enabled:true})")
  settings.get_by_role('button',name='输入与语音',exact=True).click()
  settings.get_by_role('button',name='按键盘录制',exact=True).click()
  settings.get_by_role('button',name='模型与推理',exact=True).click()
  settings.get_by_role('button',name='输入与语音',exact=True).click()
  settings.get_by_role('button',name='按键盘录制',exact=True).wait_for()
  settings.get_by_role('button',name='模型与推理',exact=True).click()
  page.wait_for_function('document.activeElement?.id==="settings-page-model"')
  model.focus()
  page.evaluate("window.dispatchUI({type:'SET_COMPUTER_MODEL_LICENSE_DOOR',door:{licenseText:'Fixture license text',notice:'Fixture notice'}})")
  license=page.get_by_role('dialog',name='实验层许可证与免责声明',exact=True);license.wait_for()
  assert settings.locator('.cm-settings-content').get_attribute('inert') is not None
  for _ in range(5):
   page.keyboard.press('Tab')
   assert license.evaluate('(el)=>el.contains(document.activeElement)')
  page.keyboard.press('Shift+Tab')
  assert license.evaluate('(el)=>el.contains(document.activeElement)')
  page.keyboard.press('Escape');license.wait_for(state='hidden')
  assert settings.is_visible()
  page.wait_for_function('document.activeElement?.placeholder=== "输入模型名称或从列表选择"')
  assert not page.evaluate('window.sent.some(x=>x.type.includes("license_response"))')
  assert not errors,errors
  b.close()
print('PASS: settings pages responsive, all categories, retained model draft, stable deep links+focus, cross-page safety status, no implicit writes; cancelled voice callbacks, hidden hotkey capture, license keyboard isolation and focus restoration.')

ACTUAL SCRIPT EXIT 0
WARN `--no-project` was provided, but no project was found
/var/folders/f5/f_1l4tl15tnc_rj9gnm4kyfr0000gn/T/tmpaz5xb0zg
PASS: settings pages responsive, all categories, retained model draft, stable deep links+focus, cross-page safety status, no implicit writes; cancelled voice callbacks, hidden hotkey capture, license keyboard isolation and focus restoration.
